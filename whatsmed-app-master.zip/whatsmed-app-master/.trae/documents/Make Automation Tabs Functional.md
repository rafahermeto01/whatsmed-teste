I will make the Reminders and Campaigns tabs fully functional with proper variable support.

### Backend Implementation

1.  **Refine Execution Logic (`packages/backend/convex/automationActions.ts`)**
    - Update `scheduleReminders` to use the robust variable context (patient, clinic, date) instead of the simplified one.
    - Update `sendPostConsultationReminder`, `handleNoShowRecovery`, and `scheduleCampaignExecution` to also use the robust variable context.
    - Ensure all `personalizeMessage` calls are compatible with the new dot-notation variables.

### Frontend Implementation

1.  **Shared Variable Component**
    - Create a new reusable component `VariableInserter` (or `VariablePopover`) based on the implementation in `automation.tsx`. This will be used in:
      - System Prompt editor (AI Tab)
      - Reminder message editors (Reminders Tab)
      - Campaign step editors (Campaigns Tab)

2.  **Update Reminders Tab (`apps/web/src/routes/automation.tsx`)**
    - Fetch real reminder configs using `useQuery(api.automation.getReminderConfigs)`.
    - Implement `handleSaveReminders` to call `updateReminderConfig` mutation for each reminder type.
    - Replace simple `Textarea` with the `VariableInserter`-enabled editor.

3.  **Update Campaigns Tab (`apps/web/src/routes/automation.tsx` & `CampaignBuilderModal.tsx`)**
    - Fetch real campaigns using `useQuery(api.automation.listCampaigns)`.
    - Update `CampaignBuilderModal` to:
      - Use the `VariableInserter` for message steps.
      - Call `createCampaign` mutation on save.
    - Implement delete/edit functionality in the campaigns list.

### Verification

- I will verify that reminder configs are saved to the database.
- I will verify that campaigns are created in the database.
- I will verify that the variable inserter works in all 3 contexts (AI, Reminders, Campaigns).
