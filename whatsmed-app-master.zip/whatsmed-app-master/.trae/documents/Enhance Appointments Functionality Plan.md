I apologize for the confusion. You are right that "CRUD" is a generic term often associated with REST APIs. With Convex, we leverage **Reactive Queries** and **Mutations** to ensure real-time data synchronization and consistency.

My updated plan focuses on using Convex's native capabilities:

## Backend: Convex Functions (`packages/backend/convex/appointments.ts`)

1.  **Reactive Queries (`query`)**:
    - `list`: A reactive query that automatically updates the UI when data changes. It will handle efficient filtering (status, date range) and pagination using Convex's built-in `paginate`.
    - `getById`: Fetch single appointment details with automatic updates.
2.  **Atomic Mutations (`mutation`)**:
    - `create`: Atomic insertion of appointment data.
    - `update`: Granular updates using `db.patch` to modify specific fields (e.g., status changes, rescheduling) without overwriting the entire document.
    - `softDelete`: Mark appointments as cancelled/deleted (preserving history) rather than physical deletion.
3.  **Schema & Index Usage**: Utilize the defined indexes (`by_clinic_date`, `by_clinic_status_date`) for performant queries.

## Frontend Integration (`apps/web/src/hooks/appointments.ts`)

1.  **Convex React Hooks**:
    - Use `useQuery` for the appointment list. This ensures the calendar/list view updates instantly when appointments are modified by any user.
    - Use `useMutation` for actions.

## Frontend UI (`apps/web/src/routes/appointments.tsx`)

1.  **Real-time Data Binding**: Bind the UI directly to the `useQuery` results.
2.  **Shadcn/UI Integration**: Implement the UI components as requested.
3.  **Action Handlers**:
    - "Check-in" -> Calls `update({ status: 'confirmed' })`
    - "Faltou" -> Calls `update({ status: 'cancelled' })` (or specific status)
    - "Reschedule" -> Calls `update({ startAt: ..., endAt: ... })`

## Quality Assurance

1.  **Testing**: Unit tests for the UI components and integration tests verifying the Convex hooks behavior (mocked).

This approach ensures we fully utilize Convex's real-time capabilities rather than treating it like a static database.
