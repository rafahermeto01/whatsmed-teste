# Implementation Plan: Flexible Calendar with Breaks & Multi-Type Support

I will implement a highly flexible calendar system that explicitly supports **breaks (lunch)**, **split shifts**, and **simultaneous appointment types**.

## 1. Database Schema Update

**File:** `packages/backend/convex/schema.ts`

- Update `users` table to include `workingHours`.
- **Structure:**
  ```typescript
  workingHours: v.optional(
    v.array(
      v.object({
        dayOfWeek: v.number(), // 0-6
        // Array of slots allows defining multiple working blocks separated by breaks
        slots: v.array(
          v.object({
            start: v.string(), // "09:00"
            end: v.string(), // "12:00"
            types: v.array(v.string()), // ["in_person", "telemedicine"]
          }),
        ),
      }),
    ),
  );
  ```

## 2. Frontend UI Implementation (Settings)

**File:** `apps/web/src/components/settings/WorkingHoursSettings.tsx`

- **Multi-Slot Interface**:
  - Each day will have an **"Add Time Block"** button.
  - Users can define multiple disjoint blocks for a single day (e.g., 09:00-12:00 AND 14:00-18:00).
  - The empty space between blocks automatically acts as a break/unavailable time.
- **Type Configuration**:
  - Each time block has independent checkboxes for "In-person" and "Telemedicine".
  - This allows a morning block to be "In-person only" and an afternoon block to be "Telemedicine only" or "Both".

## 3. Backend Logic Implementation

**File:** `packages/backend/convex/users.ts`

- **Mutation `updateWorkingHours`**:
  - Accepts the list of slots.
  - **Validation**: Ensures slots within the same day do not overlap (e.g., 11:00-13:00 and 12:00-14:00 is invalid), but allows gaps (breaks).

**File:** `packages/backend/convex/appointments.ts`

- **Query `getAvailableSlots`**:
  - Iterates through _all_ defined slots for the day.
  - Generates availability only within the defined blocks.
  - Skips the gaps (breaks).
  - Filters by the requested appointment type against the `types` array of each slot.

## 4. Verification

- **Scenario**: User configures Mon 9-12 (In-person) and 13-17 (Telemed).
- **Check**: Verify 12:30 (Lunch) is unavailable.
- **Check**: Verify 10:00 is available for In-person only.
- **Check**: Verify 14:00 is available for Telemed only.
