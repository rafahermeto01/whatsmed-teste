# Google Calendar Deep Integration Plan

I will implement a robust two-way integration with Google Calendar, allowing the system to respect external events for availability and publish new appointments to a specific calendar.

## 1. Database Schema Updates (`packages/backend/convex/schema.ts`)

We need to store calendar preferences and a local cache of external events for fast availability calculations.

- **Update `googleOAuthTokens`**:
  - `primaryCalendarId`: ID of the calendar to create events in (default: 'primary').
  - `blockedCalendarIds`: List of calendar IDs to check for conflicts.
  - `lastSyncAt`: Timestamp of the last successful sync.
- **Create `externalEvents` table**:
  - Stores a mirror of Google Calendar events.
  - Fields: `clinicId`, `userId`, `externalId` (Google ID), `calendarId`, `title`, `startTime`, `endTime`, `isAllDay`.
  - Indexed by `by_user_time` for efficient querying during availability checks.

## 2. Backend Logic

### A. Calendar Management (`convex/googleCalendarActions.ts`)

- **`listCalendars` (Action)**: Fetches available calendars from Google API for the dropdown/multi-select UI.
- **`syncEvents` (Action)**:
  - Iterates through `blockedCalendarIds`.
  - Fetches events from Google (window: -1 month to +6 months).
  - Calls `updateExternalEvents` mutation to sync the DB.

### B. Data Persistence (`convex/googleCalendar.ts`)

- **`saveSettings` (Mutation)**: Saves the selected primary and blocked calendars.
- **`updateExternalEvents` (Mutation)**: Batch upsert/delete function to keep `externalEvents` in sync.

### C. Availability Calculation (`convex/appointments.ts`)

- **Update `getAvailableSlots`**:
  - Currently, it only checks internal appointments.
  - **Change**: Query `externalEvents` for the requested date range.
  - Merge "Internal Appointments" + "External Events" into a single list of "Busy Intervals".
  - Calculate free slots based on this merged list.

### D. Appointment Creation (`convex/appointments.ts`)

- **Update `createGoogleMeetEvent`**:
  - Retrieve the `primaryCalendarId` from settings.
  - Use this ID when creating the event (instead of defaulting to 'primary').

### E. Background Synchronization (`convex/crons.ts`)

- Define a Cron job to run `syncEvents` periodically (e.g., every 10-15 minutes) for all connected users to ensure the system stays up-to-date even if the user changes their Google Calendar externally.

## 3. Frontend Implementation (`apps/web`)

### UI Updates (`GoogleConnectModal.tsx`)

- **Post-Connection View**:
  - Once connected, show a "Settings" form instead of just "Connected".
  - **Primary Calendar**: `<Select>` dropdown for where to save new appointments.
  - **Check for Conflicts**: `<MultiSelect>` (or list of checkboxes) for which calendars block availability.
  - **Sync Status**: Show "Last synced: X mins ago" with a "Sync Now" button.

## 4. Execution Steps

1.  **Schema**: Add tables and fields.
2.  **Backend**: Implement list/sync actions and mutations.
3.  **Logic**: Update availability algorithm.
4.  **Cron**: Setup background job.
5.  **Frontend**: Build the configuration UI.
