Yes, the implementation will support scheduling 3 months (or more) in advance. The Calendar picker allows navigating to any future date.

To ensure this works robustly for full-day availability, I will make a small adjustment to the backend query as well.

**1. Backend Adjustment (Crucial for Full Day View)**

- **Modify** **`getAvailableSlots`**: Currently, this query limits results to 20 slots. For a full day of 15-minute appointments (e.g., 8 AM - 6 PM), there could be 40+ slots. I will increase this limit (e.g., to 100) or make it configurable to ensure we don't cut off afternoon slots when a user selects a specific date in the future.

**2. UI Restructuring (Doctor-First Flow)**

- **Reorder Fields**:
  1. **Doctor** (Required first)
  2. **Duration** (Required second, affects slot calculation)
  3. **Date** (Enabled after Doctor selected)
  4. **Time** (Enabled after Date selected)

**3. Integration & Logic**

- **Fetch Slots**: Call `getAvailableSlots` for the _specific selected date_ (Start of Day to End of Day).

- **Populate Time Picker**: The Time dropdown will strictly show the slots returned by the backend.

- **Visual Feedback**:
  - Gray out Date picker if no Doctor is selected.

  - Gray out Time picker if no Date is selected.

  - Show "Loading available times..." when a date is picked.

  - Show "No slots available" if the doctor is fully booked/off that day.

**4. Implementation Steps**

1. **Update Backend**: Increase `getAvailableSlots` limit in `packages/backend/convex/appointments.ts`.
2. **Refactor Frontend**: Reorder inputs in `CreateAppointmentModal.tsx`.
3. **Add Logic**: Implement the `disabled` states and the `useQuery` hook for fetching slots.
4. **Verify**: Test selecting a date 3 months out and ensure all slots for that day appear.
