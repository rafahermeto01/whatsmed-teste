I have refined the plan to clarify that the scheduling flow applies specifically when the user's intent is to schedule a consultation.

### 1. Fix Context Injection (Backend)

**File:** `packages/backend/convex/automationAi.ts`

- Pass the `variableContext` (containing patient info) as a new argument to `mastraModule.getClinicAgent`.

**File:** `packages/backend/mastra/agents.ts`

- Update `createClinicAgent` to accept this `context`.
- Programmatically append a `CONTEXTO DO PACIENTE` block to the system instructions so the AI always knows the user's identity.

### 2. Enforce Prompt Priorities & Conditional Flow

**File:** `packages/backend/mastra/agents.ts`

- **Refine Scheduling Trigger**: Explicitly state that the "Doctor vs. Specialty" question should **only** be asked if the user indicates they want to schedule an appointment.
- **Updated Logic**:
  - **Context**: "You are talking to [Name] (Phone: [Number]). Do not ask for this info."
  - **General Interaction**: Answer questions normally.
  - **IF Intent = Scheduling**:
    1.  "Do you have a preference for a specific doctor?" (Priority #1)
    2.  "If not, what specialty?" (Priority #2)

### 3. Implementation Steps

1.  **Modify `automationAi.ts`**: Update `getClinicAgent` call to pass `variableContext`.
2.  **Modify `mastra/agents.ts`**:
    - Update signature to accept `context`.
    - Inject context into instructions.
    - Rewrite the "Scheduling Flow" section to be conditional: "CASO O USUÁRIO QUEIRA AGENDAR...".
    - Add strict priority rules at the end.
