## Overview

- Upgrade Patients tab to match WhatsApp’s Convex-driven, real-time architecture while adding a configurable data grid, advanced filtering, sorting, pagination, and export.
- Keep existing UX; extend it with visibility controls, persistent preferences, and robust tests.

## Backend Enhancements (Convex)

- Extend `packages/backend/convex/patients.ts:list` to support:
  1. Pagination: add `cursor` and use `paginate()`; return `{ items, cursor, total? }`.
  2. Sorting: accept `sortBy` (e.g., `createdAt`, `name`, `status`, `dateOfBirth`) and `order` (`asc`/`desc`). Default `createdAt desc`.
  3. Filters: accept optional fields:
     - `status`, `search` (existing)
     - `dateStart`/`dateEnd` (range over `createdAt` or `dateOfBirth`)
     - `hasEmail`/`hasPhone` (boolean)
     - `externalId` exact match
     - `orFilters`: when true, apply OR matching within filter set; otherwise AND
  - Implementation: start with clinic index (`by_clinic_createdAt` or `by_clinic_status_createdAt`); apply additional filters in `.filter()`; ensure soft-deleted excluded.
  - Keep indices usage for performance; non-index filters applied in memory within the paginated window.

## Frontend Implementation

### Data Model & Formatting

- Map all available patient fields returned by backend:
  - `name`, `phone`, `email`, `status`, `externalId`, `dateOfBirth` (format `YYYY-MM-DD`), `createdAt`, `updatedAt` (format), `cpf` if present in rows, and `id`.
- Formatting helpers for dates and text truncation.

### Responsive Data Grid

- Replace static table body with a responsive grid-style table that adapts on smaller screens:
  - Column definitions with `id`, `label`, `accessor`, `type` (date/text/boolean), `sortable`, `visible`.
  - Render tooltips for headers describing each field.

### Column Visibility & Persistence

- Add a column selector (Dropdown with checkboxes) to toggle visibility per column.
- Persist preferences in `localStorage` under key `patients.columns.<userId>.<clinicId>`.
- Provide “Reset to Default” to restore built-in visibility set.

### Advanced Filtering UI

- Filters panel above the grid:
  - Status dropdown (active/inactive).
  - Date range picker (for `dateOfBirth` and/or `createdAt`).
  - Text search against name/phone/email/externalId.
  - Toggles: `hasEmail`, `hasPhone`.
  - AND/OR switch controlling filter composition.
- Apply filters to query args; for UI-only fields unsupported by server, apply client-side refinement on the returned page.
- “Clear All Filters” button resets to defaults.

### Sorting

- Clickable headers for sortable columns; indicate sort direction.
- Pass `sortBy`, `order` to Convex query; client-side sort fallback when unsupported.

### Pagination & Caching

- Server-side pagination using Convex `cursor`:
  - Next/Previous controls; disable when unavailable.
  - Show loading indicators during fetch.
- Cache results via TanStack Query/Convex client:
  - Query keys include filter/sort/pagination state.
  - Prefetch next page when near end.

### Export (CSV/Excel)

- Export current filtered view to CSV; optional Excel via a lightweight client lib.
- If exporting across pages, iterate pages until full dataset gathered or limit applied.

### State & Real-time

- Continue using Convex `useQuery` for real-time list changes.
- Derive `clinicId` using `useClinicId` (Better-Auth user fallback to app `users.getByEmail`).

## UI/UX Details

- Maintain accessibility: keyboard navigation in grid, proper labels for selectors, aria attributes.
- Responsive: stack filters on mobile, collapse non-essential columns.
- Tooltips for headers to explain data content.

## Testing Plan

- Unit tests (Vitest + Testing Library):
  - Column visibility toggles and persistence via `localStorage`.
  - Filter combinations including AND/OR logic and edge cases.
  - Sorting behavior across columns.
  - Pagination next/prev and loading state.
  - Export correctness with filtered dataset.
- Integration tests (Testing Library):
  - Render with mocked Convex hooks to simulate pages, filters, and mutations.
- Accessibility checks: ensure roles/labels on selectors, grid headers and controls.

## Incremental Implementation Steps

1. Backend: update `patients.list` to support `cursor`, `sortBy`, `order`, and extended filters.
2. Frontend:
   - Define columns config and persistence utilities.
   - Implement filters panel and wiring to query args.
   - Add sorting handlers and indicators.
   - Implement pagination controls tied to Convex `cursor`.
   - Add export action generating CSV of current filtered dataset.
3. Testing: unit/integration tests for visibility, filters, sorting, pagination, export.
4. Polish: tooltips, responsive styles, accessibility attributes.

## Deliverables

- Enhanced Patients page with configurable columns, advanced filters, sorting, server-side pagination, export, and robust tests.
- Keeps WhatsApp-style Convex architecture and real-time behavior.

Please confirm and I will begin implementing these changes end-to-end.
