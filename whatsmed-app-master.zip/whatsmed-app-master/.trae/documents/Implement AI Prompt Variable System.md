I will implement a robust variable system for AI automation prompts with backend interpolation and frontend autocomplete support.

### Backend Implementation

1.  **Enhance Variable Interpolation (`packages/backend/mastra/workflows.ts`)**
    - Update `personalizeMessage` to support dot notation (e.g., `{{patient.name}}`) and generic context objects.
    - Implement deep property access validation to safely resolve variables.

2.  **Enable Dynamic System Prompts (`packages/backend/mastra/agents.ts` & `index.ts`)**
    - Modify `createClinicAgent` to accept a `systemPromptOverride`.
    - Update `getClinicAgent` to bypass the agent cache when a dynamic prompt is provided, ensuring fresh context for every request without memory leaks.

3.  **Context Injection (`packages/backend/convex/automationAi.ts`)**
    - In `generateAiResponse`, fetch the full `patient` and `clinic` records.
    - Construct a secure `variableContext` object containing whitelisted fields:
      - `patient`: name, phone
      - `clinic`: name, phone, address
      - `date`: today, now (formatted)
    - Interpolate the `systemPrompt` before creating the agent.

### Frontend Implementation (`apps/web/src/routes/automation.tsx`)

1.  **Variable Documentation**
    - Add a "Variables Reference" card to the UI listing all available variables (`{{patient.name}}`, `{{clinic.name}}`, etc.) with examples.

2.  **Autocomplete/Insertion UI**
    - Implement a "Insert Variable" button that opens a `Popover` with a searchable list of variables.
    - Clicking a variable will insert it into the `Textarea` at the cursor position.
    - This adheres to the "Library Discipline" by using standard Shadcn components (`Popover`, `Command`) instead of complex custom editors.

### Verification

- I will verify the interpolation logic with a test case.
- I will verify the frontend UI allows inserting variables.
