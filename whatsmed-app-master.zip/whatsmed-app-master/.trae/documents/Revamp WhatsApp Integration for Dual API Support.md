# Implementation Plan: Dual WhatsApp API Architecture (Evolution & Phantom Meta)

## 1. Backend Architecture & Abstraction

- **Create Provider Interface** (`packages/backend/convex/lib/whatsapp/types.ts`):
  - Define `IWhatsAppProvider` with standardized methods (`sendText`, `sendMedia`, etc.).
- **Refactor Evolution Client**:
  - Update `packages/backend/convex/lib/evolution.ts` to implement `IWhatsAppProvider`.
- **Create Phantom Meta Client** (`packages/backend/convex/lib/whatsapp/metaPhantom.ts`):
  - Implement `IWhatsAppProvider` with logging/simulation logic.
  - This serves as the placeholder for the future full implementation.
- **Provider Factory** (`packages/backend/convex/lib/whatsapp/factory.ts`):
  - Logic to instantiate Evolution or Phantom Meta client based on `whatsappInstances.provider`.

## 2. Database Schema Updates (`schema.ts`)

- Update `whatsappInstances` table:
  - Add `provider`: `v.union(v.literal("evolution"), v.literal("meta"))` (default "evolution").
  - Add placeholder fields for Meta: `metaPhoneNumberId`, `metaWabaId`, `metaAccessToken`.

## 3. Backend Logic Updates

- **Update `whatsapp.ts`**:
  - Modify `sendTextAction` to use the Provider Factory.
- **Update `integrations.ts`**:
  - Add `switchProvider` mutation to toggle between Evolution and Meta modes.
  - Add `updateMetaConfig` mutation to save Meta credentials.

## 4. Frontend Revamp

- **WhatsApp Inbox (`apps/web/src/routes/whatsapp.tsx`)**:
  - Add "API Mode" toggle (Official/Unofficial).
  - Connect toggle to `switchProvider` mutation.
  - Display current mode status.
- **Connection Modal (`apps/web/src/components/integrations/WhatsAppConnectModal.tsx`)**:
  - Add tabs/sections for "Evolution (QR)" and "Meta (API Key)".
  - Allow saving Meta credentials (even if using Phantom mode for now).

## 5. Documentation

- Create `docs/META_API_INTEGRATION_GUIDE.md`:
  - Detailed instructions on how to replace `metaPhantom.ts` with the real Meta Cloud API implementation.
  - Guide on webhook setup and verification.

## 6. Verification

- Verify Evolution mode continues to work unchanged.
- Verify switching to Meta mode persists state.
- Verify "sending" in Meta mode logs correctly (Phantom behavior).
