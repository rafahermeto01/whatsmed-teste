# Implement "Create New Clinic" Feature

## 1. Backend Implementation (`packages/backend/convex/clinics.ts`)

Create a new mutation `createOwnClinic` that allows any authenticated user to create a clinic.

### Logic Flow:

1.  **Authenticate**: Verify user identity.
2.  **Generate ID**: Create a unique `clinicId` (using `crypto.randomUUID()` or similar).
3.  **Create Clinic**: Insert new record into `clinics` table with provided data (Name, CNPJ).
4.  **Add Membership**: Insert into `clinicMembers` table with `role: "admin"`.
5.  **Update User's Clinic List**:
    - Fetch `userClinics` for the user.
    - If exists: Add new clinic to the array.
    - If missing: Create new record with the clinic.
6.  **Switch Context**: Update the `users` table record for this user to set `clinicId` to the new clinic and `role` to "admin", effectively switching them to the new clinic immediately.

## 2. Frontend Implementation

### A. New Route: Create Clinic Page

Create `apps/web/src/routes/create-clinic.tsx`:

- **UI**: A clean form centered on screen.
- **Fields**:
  - Clinic Name (Required)
  - CNPJ (Required, with masking ideally)
  - Phone/Address (Optional)
- **Action**: Calls `createOwnClinic` mutation.
- **Redirect**: On success, navigate to `/dashboard`.

### B. Sidebar Update (`apps/web/src/components/MainLayout.tsx`)

- Update the "Criar nova clínica" dropdown item.
- Wrap it in a `<Link to="/create-clinic">` component to make it functional.

## 3. Verification

- **Manual Test**: Click button in sidebar -> Fill form -> Submit -> Verify redirection to dashboard -> Verify new clinic name appears in sidebar switcher.
