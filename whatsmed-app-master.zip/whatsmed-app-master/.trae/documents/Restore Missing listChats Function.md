I will fix the "Function not found" error by re-implementing the missing `listChats` query and updating all references to it.

### **Root Cause**

The `whatsapp.ts` file was recently converted to a Node.js action file (marked with `"use node"`) to support AI features. Convex queries (like `listChats`) cannot exist in Node.js environment files. The `listChats` function was likely removed or lost during this refactor, but it is still referenced by the frontend and other backend functions.

### **Implementation Plan**

1.  **Implement `listChats` in `packages/backend/convex/whatsappQueries.ts`**
    - I will add the `listChats` query to this file, which is the correct place for standard Convex queries related to WhatsApp.
    - The query will:
      - Authenticate the user.
      - Fetch chats for the user's clinic using the `by_clinic_lastMessageAt` index (descending order).
      - Implement basic in-memory filtering if a `search` term is provided (filtering by chat title or WhatsApp ID).

2.  **Update Frontend Reference (`apps/web/src/routes/whatsapp.tsx`)**
    - Change `api.whatsapp.listChats` to `api.whatsappQueries.listChats`.

3.  **Update Backend References**
    - Update `packages/backend/convex/appointments.ts` to use `internal.whatsappQueries.listChats`.
    - Update `packages/backend/convex/waitlists.ts` to use `internal.whatsappQueries.listChats`.

This will restore the functionality for the chat list sidebar and the internal lookups used by appointments and waitlists.
