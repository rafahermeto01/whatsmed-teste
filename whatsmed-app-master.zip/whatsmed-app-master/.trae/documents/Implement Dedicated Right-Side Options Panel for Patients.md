## Overview

- Refactor `PatientsPage` to introduce a dedicated, responsive right-side panel (`OptionsPanel`) that consolidates all actions, filters, and view settings.
- Desktop: Fixed/Sticky sidebar on the right.
- Mobile: "Opções & Filtros" button opening a modal (Dialog) containing the same panel.
- Enhance UI with consistent styling, grouping, and visual hierarchy.

## Layout Changes

- Update `apps/web/src/routes/patients.tsx`:
  - Change main container to `flex flex-col lg:flex-row gap-6`.
  - Left column (`flex-1`): The Patients Table (Card).
  - Right column (`w-full lg:w-80`): The `OptionsPanel` component.
  - Remove the top toolbar (inputs/buttons) from the main flow.

## New Component: `OptionsPanel`

- Create `apps/web/src/components/patients/OptionsPanel.tsx`.
- Props: All state setters (`setSearchTerm`, `setStatusFilter`, etc.) and current values.
- Structure:
  - **Header**: Title "Controles" with Icon.
  - **Section 1: Ações**: Buttons for "Novo Paciente" and "Importar CSV" (Full width).
  - **Section 2: Busca**: Search Input with Icon.
  - **Section 3: Filtros**:
    - Status Select.
    - Date Range (Start/End inputs).
    - Email/Phone toggles (Selects or Switches).
    - Logic Switch (AND/OR).
    - "Limpar Filtros" button.
  - **Section 4: Visualização**:
    - Column Visibility control (reuse existing or inline).
  - **Section 5: Exportação**:
    - Export CSV button.
- Styling:
  - Use `Card` as container.
  - `Separator` between sections.
  - `Label` for inputs.
  - Consistent spacing (`space-y-4`).

## Mobile Responsiveness

- In `PatientsPage`:
  - Hide the desktop `OptionsPanel` on small screens (`hidden lg:block`).
  - Add a mobile-only `Button` ("Filtros e Opções") at the top that opens a `Dialog`.
  - Render `OptionsPanel` content inside the `DialogContent`.

## Visual Harmony

- Use `lucide-react` icons (Search, Filter, Eye, Download, Plus, Upload).
- Match system colors (`bg-card`, `border-border`).
- Add hover states and transitions to interactive elements.

## Testing

- Verify layout on Desktop (Sidebar visible) and Mobile (Button + Modal).
- Test all interactive controls within the new panel.
- Ensure persistency and state updates work as before.

## Implementation Steps

1. Create `OptionsPanel.tsx` with the defined structure and props.
2. Refactor `PatientsPage` to adopt the split layout and integrate `OptionsPanel`.
3. Adjust mobile view to use `Dialog` for the panel.
4. Verify accessibility and responsiveness.
