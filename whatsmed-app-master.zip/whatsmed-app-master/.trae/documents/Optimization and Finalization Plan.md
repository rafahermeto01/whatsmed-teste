I have analyzed the current implementation and identified the necessary steps to complete the user management and multi-tenancy features, addressing performance concerns and ID mismatches.

### 1. Optimize Database Schema (`convex/schema.ts`)

- **Action:** Add an index `by_auth_user_id` to the `users` table.
- **Reason:** The current implementation of the user list performs a full table scan for every member of a clinic to resolve their profile. This is O(N\*M) complexity. Adding this index will make it O(1) per user, significantly improving performance as the user base grows.

### 2. Update Backend Logic (`convex/users.ts`)

- **Action:** Refactor the `list` query to use the new `by_auth_user_id` index.
- **Action:** Verify and finalize the `switchClinic` and `getUserClinics` logic (which already appears to have the fixes for the ID mismatch issue) to ensure robustness.

### 3. Verification

- **Frontend:** Confirm `MainLayout.tsx` correctly renders clinic names (logic is already present, backend fix should resolve the ID display issue).
- **Invites:** `UserManagement.tsx` already includes visual indicators for pending invites and active status.
- **Flow:** Ensure the end-to-end flow of Invite -> Accept -> Switch Clinic works seamlessly.

I will proceed with applying the schema change and updating the query optimization.
