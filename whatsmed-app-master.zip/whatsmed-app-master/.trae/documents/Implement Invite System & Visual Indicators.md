# Scalable Multi-Tenant Invite System & Clinic Switcher

## Overview

Implement a scalable multi-tenant architecture with a `clinicMembers` table for performance and `userClinics` for user context. Add a clinic switcher dropdown to the sidebar and a robust invite acceptance flow.

## 1. Schema Updates (`convex/schema.ts`)

- [ ] **`clinicMembers` Table**:
  - `clinicId`: string.
  - `userId`: string.
  - `role`: string.
  - Indexes: `by_clinic`, `by_user_clinic`.
- [ ] **`userClinics` Table**:
  - `userId`: string.
  - `clinics`: `v.array(v.object({ clinicId: v.string(), role: v.string() }))`.
  - Index: `by_user`.
- [ ] **`invites` Table**:
  - `token`, `email`, `clinicId`, `role`, `expiresAt`, `status`.

## 2. Backend Implementation

### A. Invite Logic (`convex/invites.ts`)

- [ ] **`create`**: Generate token, store in `invites`, trigger email.
- [ ] **`accept`**:
  - **New User**: Create Auth User -> Create `users` (singleton) -> Create `userClinics` -> Create `clinicMembers`.
  - **Existing User**: Update `userClinics` (push) -> Create `clinicMembers`.

### B. User Logic (`convex/users.ts`)

- [ ] **`switchClinic`**: Verify `userClinics` membership -> Update singleton `users` record (`clinicId`, `role`).
- [ ] **`list`**: Optimized to query `clinicMembers` by `clinicId` + fetch profiles.

### C. Email Logic (`convex/emailActions.ts`)

- [ ] Add `sendInviteEmail`.

## 3. Frontend Implementation

### A. Sidebar Clinic Switcher (`components/MainLayout.tsx`)

- [ ] Fetch `userClinics` for current user.
- [ ] Add Dropdown at top of Sidebar:
  - Lists all available clinics.
  - Highlights current clinic.
  - `onClick` -> Calls `switchClinic` mutation.

### B. Invite Management (`components/UserManagement.tsx`)

- [ ] Use `api.invites.create`.
- [ ] Display pending invites.
- [ ] Display active members using new `api.users.list`.

### C. Acceptance Flow (`routes/accept-invite.tsx`)

- [ ] Route `/accept-invite`.
- [ ] Handle token validation.
- [ ] "Join" (existing) or "Register" (new) screens.

## 4. Verification

- [ ] **Invite Flow**: Invite -> Email -> Accept -> Verify tables.
- [ ] **Switcher**: Select different clinic -> Verify global context updates (e.g. member list changes).
- [ ] **Performance**: Verify `list` uses index.
