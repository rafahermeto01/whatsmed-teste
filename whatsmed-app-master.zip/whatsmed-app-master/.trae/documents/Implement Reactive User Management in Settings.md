# User Management Implementation Plan

## Overview

Refactor the User Management settings to strictly use Convex's reactive architecture instead of REST endpoints. This ensures real-time updates, proper authentication, and direct database integration as requested.

## 1. Backend Enhancements (`packages/backend/convex/users.ts`)

- [ ] **Audit Logging**: Add `ctx.db.insert("auditLogs", ...)` to `create`, `updateRole`, and `softDelete` mutations to track administrative actions.
- [ ] **Validation**: Ensure `updateRole` enforces `clinicId` checks to prevent cross-clinic modifications.

## 2. Frontend Refactoring (`apps/web/src/components/UserManagement.tsx`)

- [ ] **Data Fetching**: Replace `fetch("/api/users")` with `useQuery(api.users.list, ...)`.
  - Implement arguments: `clinicId`, `search` (state), `role` (filter state).
- [ ] **Mutations**: Replace `fetch` POST/DELETE with Convex mutations:
  - `api.users.create` for inviting users.
  - `api.users.updateRole` for changing permissions.
  - `api.users.softDelete` for removing users.
- [ ] **State Management**:
  - Add `search` string state.
  - Add `roleFilter` state.
- [ ] **UI Components**:
  - **List View**: Update map to use live query data.
  - **Loading State**: Add Skeleton loader while query is `undefined`.
  - **Status Indicators**: Show "Online" (based on recent `lastLoginAt`), "Active", or "Invited".
  - **Role Editor**: Add a Dialog or Select inside the row to modify user roles.
  - **Search Bar**: Add input field to filter the list.

## 3. Verification

- [ ] **Test List**: Verify users for the specific `clinicId` appear.
- [ ] **Test Invite**: Create a new user and verify they appear instantly (reactivity).
- [ ] **Test Edit**: Change a user's role and verify persistence.
- [ ] **Test Delete**: Soft delete a user and verify they disappear from the list.
- [ ] **Test Search**: Type in the search bar and verify filtering works.
