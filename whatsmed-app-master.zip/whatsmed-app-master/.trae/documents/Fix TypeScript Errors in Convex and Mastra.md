I will fix the TypeScript errors in the project.

1. **Fix Schema & Types**:
   - Read `convex/schema.ts` to check `messages` table definition.

   - Add `extractedData` field to `messages` table in `convex/schema.ts` if missing.

2. **Fix Convex Functions**:
   - **`convex/automationAi.ts`**: Add missing `aiResponse: null` to return objects.

   - **`convex/documentProcessing.ts`**: Add missing `aiResponse: null` to return objects.

   - **`convex/documents.ts`**:
     - Fix missing `await` for `ctx.storage.getUrl()`.

     - Add explicit type annotations to fix implicit `any` errors.

   - **`convex/nps.ts`**:
     - Convert `cleanupOldSurveys` from `internalAction` to `internalMutation` to allow direct DB access (`ctx.db`), or use `ctx.runQuery` if it must remain an action. Given the logic, `internalMutation` is more efficient.

3. **Fix Mastra/AI SDK Integration**:
   - **`mastra/agents.ts`**: Remove or relocate invalid `temperature` and `maxRetries` properties from `Agent` config.

   - **`mastra/tools.ts`**:
     - Fix `generateText` message format (replace `image_url` with correct `image` content part).

     - Fix `file_url` usage (likely needs to be text content or specific file part if supported).

     - Resolve `LanguageModel` type mismatch (cast if necessary due to version skew).

4. **Verification**:
   - I will run `npm run typecheck` (or `tsc`) to verify all errors are resolved.
