I will implement a comprehensive Form Management System as requested. This involves backend schema updates, a new Form Builder interface, appointment integration, and patient portal enhancements.

### 1. Backend & Schema Changes (Convex)

- **Create** **`forms`** **table**: To store form templates (Anamnesis, Post-Op, Return) with a flexible JSON schema for questions.

- **Create** **`patientForms`** **table**: To track form submissions, linking them to patients and appointments with statuses (pending/completed).

- **Update** **`appointments`** **table**: Add a field to store `requiredFormIds` to link specific forms to an appointment.

- **Backend Functions**: Implement `forms.ts` for CRUD operations and `patientForms.ts` for handling submissions and retrieval.

### 2. Form Management Interface (Admin/Doctor)

- **Sidebar Update**: Add a "Forms" tab to the left navigation in `MainLayout.tsx`.

- **Forms Dashboard**: Create a new page (`/forms`) to list all available forms, categorized by type.

- **Form Builder**: Develop a drag-and-drop style UI to create and edit forms.
  - Support question types: Text, Long Text, Number, Select, Checkbox, Date.

  - Preview mode to see how the form looks to patients.

### 3. Appointment Integration

- **Update Appointment Modal**: Modify `CreateAppointmentModal.tsx` to allow selecting "Anamnesis" or other forms when scheduling.

- **Automatic Assignment**: When an appointment is created with selected forms, automatically generate `patientForms` records for the patient.

### 4. Patient Portal & Access

- **Dynamic Form Rendering**: Replace the hardcoded `AnamnesisForm.tsx` with a generic `FormRenderer` that builds the UI based on the database schema.

- **Pre-Consultation Flow**: Update `checkin.tsx` to check for assigned pending forms. Patients must complete mandatory forms before proceeding to the "Ready" state.

- **Return Forms**: Implement a special flow for "Return Forms" that, upon completion, triggers a prompt to "Schedule Return Visit".

### 5. Technical & Testing

- **Validation**: Ensure all required fields in dynamic forms are validated before submission.

- **Security**: Use existing token-based authentication for patient access.

- **Audit**: Log form creations and submissions in the existing `auditLogs` table.
