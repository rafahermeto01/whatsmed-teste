I have researched the existing schema and code. Here is the plan to implement the "doctor" role functionality.

## Backend Implementation

1. **Schema Updates (`packages/backend/convex/schema.ts`)**:
   - Update `users` table: Add `v.literal("doctor")` to the `role` union.

   - Update `appointments` table: Add `doctorId: v.optional(v.id("users"))`. Ideally, we should migrate existing `doctor: v.string()` to `doctorId` reference, but for now, we'll keep `doctor` field for backward compatibility or display name, and add `doctorId` for the reference. The requirement says "include a doctorId field", so I will add it.

2. **User Functions (`packages/backend/convex/users.ts`)**:
   - Update `create` mutation to accept "doctor" role.

   - Update `list` query to accept "doctor" role filtering.

   - Create a new query `listDoctors` (or reuse `list` with role="doctor") to fetch doctors for a clinic. I will add a specialized `listDoctors` query for clarity and frontend ease of use.

3. **Appointment Functions (`packages/backend/convex/appointments.ts`)**:
   - Update `create` mutation to accept `doctorId` and validate:
     - The user exists.

     - The user has `role: "doctor"`.

     - The user belongs to the `clinicId`.

   - Update `update` mutation to allow updating `doctorId`.

## Frontend Implementation

1. **Hooks (`apps/web/src/hooks/users.ts`)**:
   - Create `useDoctorsList` hook that calls the new backend query.

2. **Appointment Modal (`apps/web/src/components/CreateAppointmentModal.tsx`)**:
   - Fetch doctors using `useDoctorsList`.

   - Replace or augment the hardcoded "Dr. Demo" with a `Select` component listing the fetched doctors.

   - Pass the selected `doctorId` to the `createAppointment` mutation.

3. **Appointment Details Modal (`apps/web/src/components/AppointmentDetailsModal.tsx`)**:
   - Allow viewing/editing the assigned doctor.

## Testing

- Update schema tests if any.

- Verify via the UI that doctors can be selected and assigned.
