I have updated the plan to ensure the doctor search is fuzzy to handle misspellings.

### 1. Fix Runtime Error (Backend)

**File:** `packages/backend/convex/automationAi.ts`

- Add `users: internalAny.users` to the `ConvexInternal` initialization object.

### 2. Backend Logic (Convex)

**File:** `packages/backend/convex/users.ts`

- Create `searchDoctors` query:
  - Input: `query` (string), `clinicId`.
  - Logic: Fetch all doctors for the clinic and perform a **fuzzy search** on the client-side (within the function) using a simple Levenshtein distance or string similarity heuristic, sorting by relevance, and returning the top 5 matches. This ensures misspelled names like "Dr. Silva" vs "Dr. Sylva" are found.

**File:** `packages/backend/convex/appointments.ts`

- Create `getDoctorAvailability` query:
  - Input: `doctorId`, `startDate`, `endDate`.
  - Logic: Calculate available slots for a single doctor.

### 3. AI Agent Tools (Mastra)

**File:** `packages/backend/mastra/tools.ts`

- **`searchDoctors`**: New tool to fuzzy-search doctors.
- **`checkDoctorAvailability`**: New tool to get slots for a specific doctor.

### 4. AI Agent Instructions (Prompt Engineering)

**File:** `packages/backend/mastra/agents.ts`

- Update the prompt to use `searchDoctors` for name lookups and `checkDoctorAvailability` for scheduling with that specific doctor.

### 5. Implementation Steps

1.  **Fix Crash**: Update `automationAi.ts`.
2.  **Convex**: Implement `searchDoctors` (fuzzy, top 5) and `getDoctorAvailability`.
3.  **Tools**: Register new tools.
4.  **Agent**: Update instructions.
