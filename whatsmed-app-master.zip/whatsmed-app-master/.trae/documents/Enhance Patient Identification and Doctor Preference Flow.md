I have refined the plan based on your feedback. Here is the updated plan:

### 1. Backend Logic (Convex)

**File:** `packages/backend/convex/patients.ts`

- Implement `getPatientByPhone` internal query:
  - Input: `clinicId`, `phone`
  - Output: Patient record if found.
  - Logic: Use the `by_clinic_phone` index to efficiently find a patient. It should handle phone number formatting (e.g., stripping non-digits) to ensure reliable matching.

### 2. AI Agent Tools (Mastra)

**File:** `packages/backend/mastra/tools.ts`

- **`getPatientByPhone`**: New tool for the AI to look up a patient by their phone number.
  - This allows the AI to "know" the patient if they are messaging from a registered number.
  - The tool will call the new `getPatientByPhone` query in Convex.

### 3. AI Agent Instructions (Prompt Engineering)

**File:** `packages/backend/mastra/agents.ts`

- **Update Scheduling Flow**:
  - **Step 1 (Context)**: Explicitly instruct the AI to check if the user is an existing patient using `getPatientByPhone` at the start of the conversation (using the user's phone number from the context). **Do NOT ask the user to confirm their identity immediately.**
  - **Step 2 (Doctor Preference)**: Modify the initial question to prioritize doctor preference: "Você tem preferência por um médico específico?" (Do you have a preference for a specific doctor?). This addresses the user's feedback that doctor preference should be the priority.
  - **Step 3 (Patient Data Verification)**: Instruct the AI to use the loaded patient data silently for context and **only confirm the details (Name, Phone, etc.) at the final confirmation step** alongside the appointment details.

### 4. Implementation Steps

1.  **Convex**: Add `getPatientByPhone` to `packages/backend/convex/patients.ts`.
2.  **Tools**: Add `getPatientByPhoneTool` to `packages/backend/mastra/tools.ts`.
3.  **Agent**: Update the system prompt in `packages/backend/mastra/agents.ts` to:
    - Prioritize asking about doctor preference.
    - Use the new tool to identify patients automatically but confirm details only at the end.
