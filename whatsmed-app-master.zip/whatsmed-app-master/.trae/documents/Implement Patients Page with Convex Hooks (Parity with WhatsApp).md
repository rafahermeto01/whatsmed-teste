## Overview

- Replace REST calls with Convex hooks (`useQuery`, `useMutation`, `useAction`) following `routes/whatsapp.tsx` patterns.
- Ensure authenticated queries/mutations and real-time sync via Convex client.
- Keep UI structure and UX consistent with existing patients layout, but wire data through Convex.

## Files & Structure

- `apps/web/src/routes/patients.tsx`: rewrite to use Convex hooks for list, create, update, delete.
- `apps/web/src/hooks/patients.ts`: custom hooks wrapper mirroring WhatsApp style (optional, for parity and reuse).
- Reuse existing components: `AddPatientModal`, `BulkImportModal`, table UI.
- Tests: `apps/web/src/__tests__/patients.*` for unit/component; `apps/web/src/__tests__/e2e/patients.spec.*` for e2e.

## Convex Integration

- Import `api` from `@whatsmed-app/backend/convex/_generated/api`.
- Authentication: rely on `ConvexBetterAuthProvider` already set in `__root.tsx`, same as WhatsApp.
- Clinic context: fetch current user via `useQuery(api.auth.getCurrentUser)` to read `clinicId`.
- Queries:
  - `useQuery(api.patients.list, { clinicId, status, search, limit })` with `skip` until `clinicId` ready.
- Mutations:
  - `useMutation(api.patients.create)`
  - `useMutation(api.patients.update)`
  - `useMutation(api.patients.softDelete)`
- Actions (optional): add any server actions if needed for batch ops; keep `importBatch` as mutation.

## Real-Time Sync

- Convex `useQuery` provides live updates; the list reflects changes immediately (create/update/delete/import).
- Use `skip` pattern like WhatsApp messages list (avoid calling when prerequisites missing).

## UI, State & UX

- Preserve current patients UI: search input, status filter, table, modals.
- Debounced search (500ms) before updating query args to avoid excessive recomputation.
- Loading state: when `patients === undefined`, render loader similar to WhatsApp (`instance === undefined` check pattern).
- Error handling: wrap mutations in `try/catch`, surface toast messages consistent with existing toasts.

## Authorization

- Respect roles if needed (e.g., restrict delete to admins) by reading current user role from `getCurrentUser` and conditionally enabling actions.
- Backend already enforces via Convex functions; frontend mirrors WhatsApp authorization flow (no manual headers).

## TypeScript Types

- Define `Patient` type aligned to backend: `{ _id, name, phone?, email?, status, dateOfBirth?, externalId?, createdAt, deletedAt? }`.
- Map to existing UI fields (`id`, `nextAppointment` placeholder retained until backend supports it).

## Performance

- `skip` queries until dependencies ready.
- Debounce search/filter changes.
- Minimize re-renders by memoizing mapped items when `patients` changes.
- Use existing `@convex-dev/react-query` integration already optimized in `router.tsx`.

## Accessibility & Responsiveness

- Maintain semantic markup and keyboard nav in table and modals.
- Ensure focus management on opening/closing modals.
- Keep Tailwind responsive classes consistent with current layout.

## Error Boundaries

- Wrap PatientsPage in an error boundary component configurable at route-level (consistent approach to WhatsApp).
- Provide fallback UI and reset mechanism.

## Testing

- Unit/Component (Vitest + Testing Library):
  - Render PatientsPage with mocked Convex client; verify loading, empty, populated states.
  - Test search debounce behavior and status filter.
  - Test create/update/delete flows with mutation mocks and toast results.
- E2E (Playwright or Cypress):
  - Navigate to `/patients`, perform CRUD, search, filter; validate real-time updates.
  - Use a seeded Convex dev deployment or mocked server.
- Performance: capture web-vitals and measure initial render and interaction timings to match WhatsApp benchmarks.

## Implementation Steps

1. Create `useClinicId` hook using `useQuery(api.auth.getCurrentUser)` returning `clinicId`, `role`.
2. Replace data fetching in `patients.tsx` with Convex `useQuery(api.patients.list, args)` using `skip` until `clinicId` ready.
3. Wire `AddPatientModal` save handler to `patients.create`/`patients.update` mutations.
4. Wire delete action to `patients.softDelete` mutation.
5. Keep `BulkImportModal` using `patients.importBatch` directly (Convex mutation), removing HTTP proxy.
6. Implement loading and error states consistent with WhatsApp.
7. Add memoization for mapped items and debounce search.
8. Add unit tests (render states, CRUD flows, search/filter behavior).
9. Add e2e tests with Playwright/Cypress and basic benchmarks using `web-vitals`.

## Deliverables

- Production-ready `patients.tsx` using Convex hooks with real-time sync.
- Custom hooks file (optional) for parity with WhatsApp style.
- Unit and e2e tests with coverage for CRUD, search, filtering.
- Error boundary integration and accessibility checks.
- Performance measurements matching WhatsApp page.

Please confirm, and I will proceed to implement all changes accordingly.
