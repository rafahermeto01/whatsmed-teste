I have analyzed the requirements and the codebase. Here is the plan to enhance the appointment scheduling workflow:

### 1. Database Schema Updates

**File:** `packages/backend/convex/schema.ts`

- Update `users` table to include a multi-value `specialties` field:
  ```typescript
  specialties: v.optional(v.array(v.string())),
  ```
- This allows doctors to have multiple specialties (e.g., "Cardiologia", "Clínica Geral").

### 2. Backend Logic (Convex)

**File:** `packages/backend/convex/users.ts`

- Create `listDoctorsBySpecialty` query:
  - Input: `clinicId`, `specialty`
  - Output: List of doctors matching the specialty.

**File:** `packages/backend/convex/appointments.ts`

- Create `getSpecialtyAvailability` query:
  - Input: `clinicId`, `specialty`, `startDate`, `endDate`
  - Logic: Fetch all doctors with the specialty, aggregate their `workingHours` and existing appointments, and return combined available slots.

### 3. AI Agent Tools (Mastra)

**File:** `packages/backend/mastra/tools.ts`

- **`listSpecialties`**: New tool to list all unique specialties available in the clinic (derived from doctors).
- **`listDoctorsBySpecialty`**: New tool to find doctors for a specific specialty.
- **`checkSpecialtyAvailability`**: New tool to check availability for a specialty (any available doctor).
- **`checkDoctorAvailability`**: Enhance existing availability check to support specific doctor validation.

### 4. AI Agent Instructions (Prompt Engineering)

**File:** `packages/backend/mastra/agents.ts`

- Update the system prompt (`basePrompt`) to strictly enforce the new conversation flow:
  1.  **Initial Inquiry**: "Você tem preferência por algum médico específico ou especialidade?"
  2.  **No Preference**: If user says "No", ask "Qual especialidade você procura?" and use `listSpecialties` if needed.
  3.  **Doctor Selection**: If user picks a doctor, verify they exist and get their specialties.
  4.  **Procedure Check**: "Qual o tipo de procedimento?" (Consultation, Exam, etc.).
  5.  **Availability**: Check slots based on the previous selection (Specific Doctor vs. Any Doctor in Specialty).
  6.  **Confirmation**: Summarize all details before booking.

### 5. Implementation Steps

1.  **Schema**: Add `specialties` to `users` table.
2.  **Convex**: Implement the backend queries for specialty filtering and availability aggregation.
3.  **Tools**: Register the new tools in `mastra/tools.ts`.
4.  **Agent**: Update the prompt in `mastra/agents.ts` to orchestrate these tools according to the requested flow.
