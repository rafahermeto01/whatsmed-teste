I will fix the AI reply issues, add the 24/7 feature, and implement comprehensive decision logging to pinpoint why messages are (or aren't) being answered.

### 1. Enhanced Logging & Debugging (Root Cause Analysis)

- **Detailed Decision Logs**: Modify `convex/automationAi.ts` and `convex/whatsappInternal.ts` to log **exactly why** a message is routed to AI or Human.
  - _Log Format_: `[Decision] Chat: <id> | AI Enabled: <bool> | Time Check: <result> (Server: <time>, Clinic: <time>) | Escalation: <bool> -> Result: <AI/Human>`
- **Timezone Debugging**: The logs will explicitly show the server time (UTC) vs. the clinic's intended time (Brazil), confirming the "outside hours" hypothesis.

### 2. Backend Logic Fixes

- **Timezone Correction**: Rewrite `isWithinActiveHours` in `packages/backend/mastra/agents.ts` to strictly use **Brazilian Time (America/Sao_Paulo)**, fixing the issue where the server (UTC) incorrectly thinks the clinic is closed.
- **24/7 Support**:
  - Add `is247` boolean to `aiSettings` in `convex/schema.ts`.
  - Update `convex/automation.ts` to save this setting.
  - Update `isWithinActiveHours` to always return `true` if `is247` is enabled.

### 3. Frontend Implementation

- **Automation Page**: Update `apps/web/src/routes/automation.tsx`:
  - Add "Atendimento 24/7" switch.
  - Hide "Horário Início" and "Horário Fim" inputs when 24/7 is active to prevent confusion.

### 4. Verification

- I will verify the fix by checking the new logs on the next incoming message (or simulated one) to ensure the time check passes correctly during Brazilian business hours.
