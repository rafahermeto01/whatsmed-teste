import { createAnthropic } from "@ai-sdk/anthropic";
import { createOpenAI } from "@ai-sdk/openai";
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";

import { MASTRA_CONFIG } from "./config.js";
import { isImageMimeType, isPdfMimeType } from "./media.js";

const DEFAULT_OPENCODE_GO_BASE_URL = "https://opencode.ai/zen/go/v1";
type OpenCodeProtocol = "openai" | "anthropic" | "auto";

function requireEnv(name: string): string {
  const value = process.env[name]?.trim();
  if (!value) {
    throw new Error(`Missing ${name}`);
  }
  return value;
}

function createOpenCodeGoOpenAiProvider() {
  return createOpenAICompatible({
    name: "opencode-go",
    apiKey: requireEnv("OPENCODE_GO_API_KEY"),
    baseURL: process.env.OPENCODE_GO_OPENAI_BASE_URL || DEFAULT_OPENCODE_GO_BASE_URL,
  });
}

function createOpenCodeGoAnthropicProvider() {
  return createAnthropic({
    apiKey: requireEnv("OPENCODE_GO_API_KEY"),
    baseURL: process.env.OPENCODE_GO_ANTHROPIC_BASE_URL || DEFAULT_OPENCODE_GO_BASE_URL,
  });
}

function resolveOpenCodeProtocol(
  modelId: string,
  preferredProtocol?: string | null,
): Exclude<OpenCodeProtocol, "auto"> {
  const normalizedPreferred = String(preferredProtocol || "")
    .trim()
    .toLowerCase();

  if (normalizedPreferred === "anthropic") return "anthropic";
  if (normalizedPreferred === "openai") return "openai";

  return modelId.startsWith("minimax") ? "anthropic" : "openai";
}

function getOpenCodeGoModel(modelId: string, preferredProtocol?: string | null) {
  const normalizedId = modelId.replace(/^opencode-go\//, "");

  const protocol = resolveOpenCodeProtocol(normalizedId, preferredProtocol);
  if (protocol === "anthropic") {
    return createOpenCodeGoAnthropicProvider()(normalizedId);
  }

  // Kimi and GLM default to OpenAI-compatible /chat/completions endpoint.
  return createOpenCodeGoOpenAiProvider().chatModel(normalizedId);
}

function createOpenAiFallbackProvider() {
  return createOpenAI({
    apiKey: requireEnv("OPENAI_API_KEY"),
  });
}

export function getPrimaryChatModelId(): string {
  return MASTRA_CONFIG.models.agent;
}

export function getToolCallingChatModelId(): string {
  return MASTRA_CONFIG.models.toolAgent;
}

export function getReminderModelId(): string {
  return MASTRA_CONFIG.models.reminder;
}

export function getImageVisionModelId(): string {
  return MASTRA_CONFIG.models.vision;
}

export function getDocumentFallbackModelId(): string {
  return MASTRA_CONFIG.models.pdfVisionFallback;
}

export function getVisionModelIdForMimeType(mimeType?: string | null): string {
  return isPdfMimeType(mimeType) || !isImageMimeType(mimeType)
    ? getDocumentFallbackModelId()
    : getImageVisionModelId();
}

export function getPrimaryChatModel() {
  return getOpenCodeGoModel(getPrimaryChatModelId(), process.env.OPENCODE_GO_CHAT_PROTOCOL);
}

export function getToolCallingChatModel() {
  return createOpenAiFallbackProvider()(getToolCallingChatModelId());
}

export function getReminderModel() {
  return getOpenCodeGoModel(getReminderModelId(), process.env.OPENCODE_GO_REMINDER_PROTOCOL);
}

export function getImageVisionModel() {
  const modelId = getImageVisionModelId();
  return /^opencode-go\//i.test(modelId)
    ? getOpenCodeGoModel(modelId, process.env.OPENCODE_GO_VISION_PROTOCOL)
    : createOpenAiFallbackProvider()(modelId);
}

export function getDocumentFallbackModel() {
  return createOpenAiFallbackProvider()(getDocumentFallbackModelId());
}
