export const MASTRA_CONFIG = {
  models: {
    // Primary chat runs on OpenCode Go Kimi (OpenAI-compatible API).
    agent: process.env.OPENCODE_GO_CHAT_MODEL || "opencode-go/kimi-k2.5",

    // Tool-calling flows use the more stable OpenAI path.
    toolAgent: process.env.OPENAI_TOOL_MODEL || process.env.OPENAI_CHAT_MODEL || "gpt-4o-mini",

    // Reminders use the same model for consistency.
    reminder: process.env.OPENCODE_GO_REMINDER_MODEL || "opencode-go/kimi-k2.5",

    // Images use the more reliable OpenAI vision path.
    vision: process.env.OPENAI_VISION_MODEL || "gpt-4o",

    // PDFs and generic file analysis still fall back to OpenAI.
    pdfVisionFallback: process.env.OPENAI_VISION_MODEL || "gpt-4o",

    // Audio transcription remains on OpenAI Whisper.
    audio: process.env.OPENAI_WHISPER_MODEL || "whisper-1",
  },

  // Default parameters
  defaults: {
    maxTokens: 1000,
  },
};
