import { MASTRA_CONFIG } from "./config.js";

type OpenAiTranscriptionResponse = {
  text?: string;
  language?: string;
  duration?: number;
};

export type AudioTranscriptionResult = {
  text: string;
  language?: string;
  duration?: number;
  model: string;
};

function normalizeOpenAiModelId(modelId: string): string {
  return modelId.startsWith("openai/") ? modelId.slice("openai/".length) : modelId;
}

function fileNameForContentType(contentType: string): string {
  const normalized = contentType.toLowerCase();
  if (normalized.includes("ogg")) return "audio.ogg";
  if (normalized.includes("wav")) return "audio.wav";
  if (normalized.includes("webm")) return "audio.webm";
  if (normalized.includes("mp4")) return "audio.mp4";
  return "audio.mp3";
}

export async function transcribeAudioFromUrl({
  audioUrl,
  language,
  model,
}: {
  audioUrl: string;
  language?: string;
  model?: string;
}): Promise<AudioTranscriptionResult> {
  const openAiApiKey = process.env.OPENAI_API_KEY;
  if (!openAiApiKey) {
    throw new Error("Missing OPENAI_API_KEY for audio transcription");
  }

  const transcriptionModel = normalizeOpenAiModelId(
    model || process.env.OPENAI_WHISPER_MODEL || MASTRA_CONFIG.models.audio,
  );

  const audioResponse = await fetch(audioUrl);
  if (!audioResponse.ok) {
    throw new Error(`Failed to download audio file (${audioResponse.status})`);
  }

  const contentType = audioResponse.headers.get("content-type") || "audio/mpeg";
  const audioBlob = await audioResponse.blob();
  if (!audioBlob.size) {
    throw new Error("Audio file is empty");
  }

  const formData = new FormData();
  formData.append("model", transcriptionModel);
  formData.append("file", audioBlob, fileNameForContentType(contentType));
  if (language) {
    formData.append("language", language);
  }

  const transcriptionResponse = await fetch("https://api.openai.com/v1/audio/transcriptions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${openAiApiKey}`,
    },
    body: formData,
  });

  if (!transcriptionResponse.ok) {
    const errorBody = await transcriptionResponse.text();
    throw new Error(`OpenAI transcription failed (${transcriptionResponse.status}): ${errorBody}`);
  }

  const payload = (await transcriptionResponse.json()) as OpenAiTranscriptionResponse;
  const text = payload.text?.trim();
  if (!text) {
    throw new Error("OpenAI returned an empty transcription");
  }

  const result: AudioTranscriptionResult = {
    text,
    model: transcriptionModel,
  };

  if (typeof payload.language === "string" && payload.language.trim()) {
    result.language = payload.language;
  }
  if (typeof payload.duration === "number") {
    result.duration = payload.duration;
  }

  return result;
}
