"use node";

import { createTool } from "@mastra/core/tools";
import { generateText } from "ai";
import { z } from "zod";

import { MASTRA_CONFIG } from "./config.js";
import { blobToDataUrl, isImageMimeType } from "./media.js";
import {
  getDocumentFallbackModel,
  getImageVisionModel,
  getVisionModelIdForMimeType,
} from "./providers.js";
import { transcribeAudioFromUrl } from "./transcription.js";
import { internal, api } from "../convex/_generated/api.js";

const apiAny = api as any;
const internalAny = internal as any;

const BRAZIL_TIME_ZONE = "America/Sao_Paulo";
const BRAZIL_UTC_OFFSET_HOURS = 3;
const BRAZIL_UTC_OFFSET_MS = BRAZIL_UTC_OFFSET_HOURS * 60 * 60 * 1000;
const MAX_PRESENTED_AVAILABILITY_SLOTS = 25;
const MAX_FULL_DAY_AVAILABILITY_SLOTS = 200;
const WEEKDAY_NAMES_PT_BR = [
  "domingo",
  "segunda-feira",
  "terça-feira",
  "quarta-feira",
  "quinta-feira",
  "sexta-feira",
  "sábado",
];

type AvailabilityPeriod = "morning" | "afternoon" | "night";

type RankedCandidate<T> = {
  item: T;
  name: string;
  normalizedName: string;
  similarity: number;
  tokenCoverage: number;
  score: number;
};

function parseStartAtToTimestamp(startAtInput: string): number {
  const startAt = startAtInput.trim();
  const hasTimezone = /([zZ]|[+-]\d{2}:\d{2})$/.test(startAt);

  if (hasTimezone) {
    return new Date(startAt).getTime();
  }

  const localIsoMatch = startAt.match(
    /^(\d{4})-(\d{2})-(\d{2})[T\s](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?$/,
  );

  if (!localIsoMatch) {
    return NaN;
  }

  const [, year, month, day, hour, minute, second = "0", millisecond = "0"] = localIsoMatch;
  const normalizedMs = millisecond.padEnd(3, "0").slice(0, 3);

  // Input sem timezone é tratado como horário local do Brasil (UTC-3).
  return Date.UTC(
    Number(year),
    Number(month) - 1,
    Number(day),
    Number(hour) + BRAZIL_UTC_OFFSET_HOURS,
    Number(minute),
    Number(second),
    Number(normalizedMs),
  );
}

function getBrazilIsoDateFromTimestamp(timestamp: number): string {
  return new Date(timestamp - BRAZIL_UTC_OFFSET_MS).toISOString().split("T")[0] ?? "";
}

function getBrazilLocalDateParts(timestamp: number): {
  date: string;
  dayOfWeek: number;
  weekdayName: string;
  hour: number;
} {
  const brazilDate = new Date(timestamp - BRAZIL_UTC_OFFSET_MS);
  const date = brazilDate.toISOString().split("T")[0] ?? "";
  const dayOfWeek = brazilDate.getUTCDay();

  return {
    date,
    dayOfWeek,
    weekdayName: WEEKDAY_NAMES_PT_BR[dayOfWeek] ?? "",
    hour: brazilDate.getUTCHours(),
  };
}

function extractIsoDatePart(value: string): string | null {
  const match = value.trim().match(/^(\d{4}-\d{2}-\d{2})/);
  return match?.[1] ?? null;
}

function brazilDateToUtcStartIso(date: string): string {
  const [yearStr, monthStr, dayStr] = date.split("-");
  const year = Number(yearStr);
  const month = Number(monthStr);
  const day = Number(dayStr);
  return new Date(Date.UTC(year, month - 1, day, BRAZIL_UTC_OFFSET_HOURS, 0, 0, 0)).toISOString();
}

/**
 * Calculate string similarity using Jaro-Winkler distance
 * Returns a value between 0 (completely different) and 1 (identical)
 */
function calculateNameSimilarity(str1: string, str2: string): number {
  if (str1 === str2) return 1.0;
  if (!str1 || !str2) return 0.0;

  const s1 = str1.toLowerCase().trim();
  const s2 = str2.toLowerCase().trim();

  // Exact match
  if (s1 === s2) return 1.0;

  // One contains the other
  if (s1.includes(s2) || s2.includes(s1)) {
    const longer = Math.max(s1.length, s2.length);
    const shorter = Math.min(s1.length, s2.length);
    return shorter / longer;
  }

  // Calculate Jaro distance
  const jaroDistance = (s1: string, s2: string): number => {
    if (s1 === s2) return 1.0;
    if (s1.length === 0 || s2.length === 0) return 0.0;

    const matchDistance = Math.floor(Math.max(s1.length, s2.length) / 2) - 1;
    const s1Matches = new Array(s1.length).fill(false);
    const s2Matches = new Array(s2.length).fill(false);

    let matches = 0;
    let transpositions = 0;

    for (let i = 0; i < s1.length; i++) {
      const start = Math.max(0, i - matchDistance);
      const end = Math.min(i + matchDistance + 1, s2.length);

      for (let j = start; j < end; j++) {
        if (s2Matches[j] || s1[i] !== s2[j]) continue;
        s1Matches[i] = true;
        s2Matches[j] = true;
        matches++;
        break;
      }
    }

    if (matches === 0) return 0.0;

    let k = 0;
    for (let i = 0; i < s1.length; i++) {
      if (!s1Matches[i]) continue;
      while (!s2Matches[k]) k++;
      if (s1[i] !== s2[k]) transpositions++;
      k++;
    }

    return (
      (matches / s1.length + matches / s2.length + (matches - transpositions / 2) / matches) / 3.0
    );
  };

  const jaro = jaroDistance(s1, s2);

  // Jaro-Winkler: boost for common prefix
  let prefixScale = 0.1;
  let prefix = 0;
  const maxPrefix = 4;
  while (prefix < maxPrefix && s1[prefix] && s1[prefix] === s2[prefix]) {
    prefix++;
  }

  return jaro + prefix * prefixScale * (1 - jaro);
}

function normalizeEntityText(value: string, options?: { stripDoctorPrefix?: boolean }): string {
  let normalized = String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  if (options?.stripDoctorPrefix) {
    normalized = normalized.replace(/^(dr|dra|doutor|doutora)\s+/, "").trim();
  }

  return normalized;
}

function getEntityTokens(value: string): string[] {
  return normalizeEntityText(value)
    .split(/\s+/)
    .map((token) => token.trim())
    .filter(Boolean);
}

function detectDoctorGenderHint(value: string): "male" | "female" | null {
  const normalized = normalizeEntityText(value);
  if (/^(dra|doutora)\b/.test(normalized)) return "female";
  if (/^(dr|doutor)\b/.test(normalized)) return "male";
  return null;
}

function getProcedureHints(value: string) {
  const normalized = normalizeEntityText(value);
  return {
    wantsReturn: /\bretorno\b/.test(normalized),
    wantsTelemedicine: /telemed|teleconsulta/.test(normalized),
    wantsInPerson: /presencial/.test(normalized),
  };
}

function rankNamedCandidates<T>(
  query: string,
  items: T[],
  getName: (item: T) => string,
  options?: { stripDoctorPrefix?: boolean },
): RankedCandidate<T>[] {
  const normalizedQuery = normalizeEntityText(query, options);
  const queryTokens = getEntityTokens(normalizedQuery);

  return items
    .map((item) => {
      const name = getName(item);
      const normalizedName = normalizeEntityText(name, options);
      const nameTokens = getEntityTokens(normalizedName);
      const tokenCoverage =
        queryTokens.length === 0
          ? 0
          : queryTokens.filter(
              (token) =>
                nameTokens.some(
                  (nameToken) => nameToken.includes(token) || token.includes(nameToken),
                ) || normalizedName.includes(token),
            ).length / queryTokens.length;
      const similarity = calculateNameSimilarity(normalizedQuery, normalizedName);
      const containsBoost =
        normalizedQuery &&
        (normalizedName.includes(normalizedQuery) || normalizedQuery.includes(normalizedName))
          ? 0.05
          : 0;
      const score = Math.min(1, similarity * 0.75 + tokenCoverage * 0.25 + containsBoost);

      return {
        item,
        name,
        normalizedName,
        similarity,
        tokenCoverage,
        score,
      };
    })
    .sort((a, b) => b.score - a.score);
}

function buildClarificationQuestion(
  label: string,
  originalQuery: string,
  options: string[],
): string {
  const choices = options.filter(Boolean).slice(0, 3);
  const joinedChoices =
    choices.length <= 1
      ? choices[0] || ""
      : `${choices.slice(0, -1).join(", ")} ou ${choices[choices.length - 1]}`;
  return `Encontrei mais de um${label === "especialidade" ? "a" : ""} ${label} parecido com "${originalQuery}". Você quis dizer ${joinedChoices}?`;
}

function getSpecialtyClarificationOptions(specialtyQuery: string, specialties: string[]) {
  const ranked = rankNamedCandidates(specialtyQuery, specialties || [], (specialty) => specialty);
  const bestScore = ranked[0]?.score || 0;
  const normalizedQuery = normalizeEntityText(specialtyQuery);
  const queryRoot = normalizedQuery.replace(/[aeiou]$/g, "").slice(0, 6);
  const rootMatches = (specialties || []).filter((specialty) =>
    normalizeEntityText(specialty).includes(queryRoot),
  );
  return [
    ...new Set([
      ...ranked
        .filter((candidate) => candidate.score >= Math.max(bestScore - 0.08, 0.42))
        .map((candidate) => candidate.item),
      ...rootMatches,
    ]),
  ].slice(0, 3);
}

function resolveDoctorCandidates(doctors: any[], doctorQuery: string) {
  const genderHint = detectDoctorGenderHint(doctorQuery);
  const initialRanked = rankNamedCandidates(doctorQuery, doctors || [], (doctor) => doctor.name, {
    stripDoctorPrefix: true,
  });
  const ranked =
    genderHint === null
      ? initialRanked
      : initialRanked.filter((candidate) => {
          const normalizedName = normalizeEntityText(candidate.name);
          return genderHint === "female"
            ? /^(dra|doutora)\b/.test(normalizedName)
            : /^(dr|doutor)\b/.test(normalizedName);
        });
  const best = ranked[0];
  const normalizedQuery = normalizeEntityText(doctorQuery, { stripDoctorPrefix: true });
  const shortQuery = getEntityTokens(doctorQuery).length <= 1;
  const closeMatches = ranked.filter(
    (candidate) => candidate.score >= Math.max((best?.score || 0) - 0.06, 0.78),
  );
  const prefixMatches = ranked.filter(
    (candidate) =>
      normalizedQuery.length > 0 &&
      (candidate.normalizedName.startsWith(normalizedQuery) ||
        candidate.normalizedName.includes(` ${normalizedQuery}`)),
  );

  if (!best) {
    return {
      status: "no_match" as const,
      ranked,
    };
  }

  const strongTokenMatches = ranked.filter((candidate) => candidate.tokenCoverage >= 1).slice(0, 5);
  if (prefixMatches.length > 1 || strongTokenMatches.length > 1) {
    const ambiguousMatches = prefixMatches.length > 1 ? prefixMatches : strongTokenMatches;
    return {
      status: "ambiguous" as const,
      ranked: ambiguousMatches,
      question: buildClarificationQuestion(
        "médico",
        doctorQuery,
        ambiguousMatches.map((candidate) => candidate.item.name),
      ),
    };
  }

  if (best.score < 0.55 && best.tokenCoverage < 1) {
    return {
      status: "no_match" as const,
      ranked,
    };
  }

  if (
    closeMatches.length > 1 &&
    (shortQuery || (best.score - closeMatches[1].score <= 0.06 && closeMatches[1].score >= 0.8))
  ) {
    return {
      status: "ambiguous" as const,
      ranked: closeMatches,
      question: buildClarificationQuestion(
        "médico",
        doctorQuery,
        closeMatches.map((candidate) => candidate.item.name),
      ),
    };
  }

  return {
    status: "match" as const,
    ranked,
    match: best.item,
  };
}

function resolveProcedureCandidates(procedures: any[], procedureQuery: string) {
  const hints = getProcedureHints(procedureQuery);
  let candidateProcedures = [...(procedures || [])];
  if (hints.wantsTelemedicine) {
    candidateProcedures = candidateProcedures.filter((procedure: any) => procedure.isTelemedicine);
  } else if (hints.wantsInPerson) {
    candidateProcedures = candidateProcedures.filter((procedure: any) => procedure.isInPerson);
  }

  if (hints.wantsReturn) {
    const returnProcedures = candidateProcedures.filter((procedure: any) =>
      /\bretorno\b/.test(normalizeEntityText(procedure.name)),
    );
    if (returnProcedures.length > 0) {
      candidateProcedures = returnProcedures;
    }
  } else {
    const nonReturnProcedures = candidateProcedures.filter(
      (procedure: any) => !/\bretorno\b/.test(normalizeEntityText(procedure.name)),
    );
    if (nonReturnProcedures.length > 0) {
      candidateProcedures = nonReturnProcedures;
    }
  }

  const ranked = rankNamedCandidates(
    procedureQuery,
    candidateProcedures,
    (procedure) => procedure.name,
  );
  const best = ranked[0];
  const normalizedQuery = normalizeEntityText(procedureQuery);
  const exactNameMatches = ranked.filter(
    (candidate) => candidate.normalizedName === normalizedQuery,
  );
  if (exactNameMatches.length === 1) {
    return {
      status: "match" as const,
      ranked,
      match: exactNameMatches[0].item,
    };
  }
  const shortQuery = getEntityTokens(procedureQuery).length <= 1;
  const closeMatches = ranked.filter(
    (candidate) => candidate.score >= Math.max((best?.score || 0) - 0.06, 0.76),
  );
  const prefixMatches = ranked.filter(
    (candidate) =>
      normalizedQuery.length > 0 &&
      (candidate.normalizedName.startsWith(normalizedQuery) ||
        candidate.normalizedName.includes(` ${normalizedQuery}`)),
  );

  if (!best) {
    return {
      status: "no_match" as const,
      ranked,
    };
  }

  const strongTokenMatches = ranked
    .filter(
      (candidate) =>
        candidate.tokenCoverage >= 1 ||
        candidate.normalizedName.includes(normalizedQuery) ||
        normalizedQuery.includes(candidate.normalizedName),
    )
    .slice(0, 5);
  if (prefixMatches.length > 1 || strongTokenMatches.length > 1) {
    const ambiguousMatches = prefixMatches.length > 1 ? prefixMatches : strongTokenMatches;
    return {
      status: "ambiguous" as const,
      ranked: ambiguousMatches,
      question: buildClarificationQuestion(
        "procedimento",
        procedureQuery,
        ambiguousMatches.map((candidate) => candidate.item.name),
      ),
    };
  }

  if (best.score < 0.55 && best.tokenCoverage < 1) {
    return {
      status: "no_match" as const,
      ranked,
    };
  }

  if (
    closeMatches.length > 1 &&
    (shortQuery || closeMatches[0].name !== best.name || best.score - closeMatches[1].score <= 0.06)
  ) {
    return {
      status: "ambiguous" as const,
      ranked: closeMatches,
      question: buildClarificationQuestion(
        "procedimento",
        procedureQuery,
        closeMatches.map((candidate) => candidate.item.name),
      ),
    };
  }

  return {
    status: "match" as const,
    ranked,
    match: best.item,
  };
}

function buildClarificationResult(params: {
  clarificationType: "doctor" | "procedure" | "specialty";
  question: string;
  choices: Array<Record<string, unknown>>;
  successPayload?: Record<string, unknown>;
}) {
  return {
    success: true,
    needsClarification: true,
    clarificationType: params.clarificationType,
    clarificationQuestion: params.question,
    message: params.question,
    choices: params.choices,
    ...(params.successPayload || {}),
  };
}

function addDaysToIsoDate(date: string, days: number): string {
  const [yearStr, monthStr, dayStr] = date.split("-");
  const utcDate = new Date(Date.UTC(Number(yearStr), Number(monthStr) - 1, Number(dayStr)));
  utcDate.setUTCDate(utcDate.getUTCDate() + days);
  return utcDate.toISOString().split("T")[0] ?? date;
}

function normalizeAvailabilityStartBoundary(value: string | undefined): string | undefined {
  if (!value) {
    return undefined;
  }

  const isoDate = extractIsoDatePart(value);
  if (!isoDate) {
    return undefined;
  }

  return brazilDateToUtcStartIso(isoDate);
}

function normalizeAvailabilityEndBoundaryInclusive(value: string | undefined): string | undefined {
  if (!value) {
    return undefined;
  }

  const isoDate = extractIsoDatePart(value);
  if (!isoDate) {
    return undefined;
  }

  return brazilDateToUtcStartIso(addDaysToIsoDate(isoDate, 1));
}

function getAvailabilitySearchDayCount(
  startValue: string | undefined,
  endValue: string | undefined,
): number | null {
  const startIsoDate = extractIsoDatePart(startValue ?? "");
  if (!startIsoDate) {
    return null;
  }

  const endIsoDate = extractIsoDatePart(endValue ?? startValue ?? "") ?? startIsoDate;
  const startDay = Date.parse(`${startIsoDate}T00:00:00.000Z`);
  const endDay = Date.parse(`${endIsoDate}T00:00:00.000Z`);

  if (!Number.isFinite(startDay) || !Number.isFinite(endDay)) {
    return null;
  }

  const diffInDays = Math.round((endDay - startDay) / (24 * 60 * 60 * 1000));
  return Math.max(1, diffInDays + 1);
}

function shouldIncludeNextDayAvailability(
  requestedDate: string | undefined,
  now = Date.now(),
): boolean {
  const requestedIsoDate = extractIsoDatePart(requestedDate ?? "");
  if (!requestedIsoDate) {
    return false;
  }

  const brazilNow = getBrazilLocalDateParts(now);
  return requestedIsoDate === brazilNow.date && brazilNow.hour >= 20;
}

function getAvailabilityPeriodForHour(hour: number): AvailabilityPeriod | null {
  if (hour >= 8 && hour < 12) return "morning";
  if (hour >= 13 && hour < 19) return "afternoon";
  if (hour >= 19 && hour < 22) return "night";
  return null;
}

function slotMatchesRequestedPeriod(slotStartIso: string, period?: AvailabilityPeriod): boolean {
  if (!period) return true;

  const slotHour = Number(
    new Date(slotStartIso).toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      hour12: false,
      timeZone: BRAZIL_TIME_ZONE,
    }),
  );

  return getAvailabilityPeriodForHour(slotHour) === period;
}

function getAvailabilityBucketKey(slotStartIso: string): string {
  const slotDate = new Date(slotStartIso);
  const date = slotDate.toLocaleDateString("en-CA", {
    timeZone: BRAZIL_TIME_ZONE,
  });
  const slotHour = Number(
    slotDate.toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      hour12: false,
      timeZone: BRAZIL_TIME_ZONE,
    }),
  );

  return `${date}|${getAvailabilityPeriodForHour(slotHour) ?? "other"}`;
}

function limitPresentedAvailabilitySlots<T extends { start: string; end: string }>(
  slots: T[],
  period?: AvailabilityPeriod,
): T[] {
  const filtered = slots.filter((slot) => slotMatchesRequestedPeriod(slot.start, period));

  if (filtered.length <= MAX_PRESENTED_AVAILABILITY_SLOTS) {
    return filtered;
  }

  if (period) {
    return filtered.slice(0, MAX_PRESENTED_AVAILABILITY_SLOTS);
  }

  const buckets = new Map<string, T[]>();
  const bucketOrder: string[] = [];

  for (const slot of filtered) {
    const bucketKey = getAvailabilityBucketKey(slot.start);
    if (!buckets.has(bucketKey)) {
      buckets.set(bucketKey, []);
      bucketOrder.push(bucketKey);
    }
    buckets.get(bucketKey)!.push(slot);
  }

  const selected: T[] = [];

  while (selected.length < MAX_PRESENTED_AVAILABILITY_SLOTS) {
    let addedInPass = false;

    for (const bucketKey of bucketOrder) {
      const bucket = buckets.get(bucketKey);
      if (!bucket || bucket.length === 0) {
        continue;
      }

      const slot = bucket.shift();
      if (!slot) {
        continue;
      }

      selected.push(slot);
      addedInPass = true;

      if (selected.length >= MAX_PRESENTED_AVAILABILITY_SLOTS) {
        break;
      }
    }

    if (!addedInPass) {
      break;
    }
  }

  return selected.sort((a, b) => new Date(a.start).getTime() - new Date(b.start).getTime());
}

type AvailabilityRange = {
  start: string;
  end: string;
  date: string;
  dayOfWeek: number;
  weekdayName: string;
  dateFormatted: string;
  startTime: string;
  endTime: string;
  formatted: string;
  displayText: string;
  slotCount: number;
  isNextDayAvailability: boolean;
};

function buildAvailabilityRanges(
  slots: Array<{ start: string; end: string }>,
  options: {
    requestedBrazilDate?: string;
    includeNextDayAvailability?: boolean;
  } = {},
): AvailabilityRange[] {
  const groupedRanges: Array<{
    start: string;
    end: string;
    date: string;
    slotCount: number;
    isNextDayAvailability: boolean;
  }> = [];

  const sortedSlots = [...slots].sort(
    (a, b) => new Date(a.start).getTime() - new Date(b.start).getTime(),
  );

  for (const slot of sortedSlots) {
    const startTimestamp = new Date(slot.start).getTime();
    const endTimestamp = new Date(slot.end).getTime();

    if (!Number.isFinite(startTimestamp) || !Number.isFinite(endTimestamp)) {
      continue;
    }

    const brazilLocal = getBrazilLocalDateParts(startTimestamp);
    const isNextDayAvailability = Boolean(
      options.includeNextDayAvailability &&
      options.requestedBrazilDate &&
      brazilLocal.date !== options.requestedBrazilDate,
    );
    const previousRange = groupedRanges[groupedRanges.length - 1];

    if (
      previousRange &&
      previousRange.date === brazilLocal.date &&
      previousRange.isNextDayAvailability === isNextDayAvailability &&
      new Date(previousRange.end).getTime() === startTimestamp
    ) {
      previousRange.end = slot.end;
      previousRange.slotCount += 1;
      continue;
    }

    groupedRanges.push({
      start: slot.start,
      end: slot.end,
      date: brazilLocal.date,
      slotCount: 1,
      isNextDayAvailability,
    });
  }

  return groupedRanges.map((range) => {
    const startDate = new Date(range.start);
    const endDate = new Date(range.end);
    const brazilLocal = getBrazilLocalDateParts(startDate.getTime());
    const startTime = startDate.toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: BRAZIL_TIME_ZONE,
    });
    const endTime = endDate.toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: BRAZIL_TIME_ZONE,
    });

    return {
      start: range.start,
      end: range.end,
      date: brazilLocal.date,
      dayOfWeek: brazilLocal.dayOfWeek,
      weekdayName: brazilLocal.weekdayName,
      dateFormatted: startDate.toLocaleDateString("pt-BR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        timeZone: BRAZIL_TIME_ZONE,
      }),
      startTime,
      endTime,
      formatted: `${startTime} - ${endTime}`,
      displayText: range.slotCount > 1 ? `das ${startTime} as ${endTime}` : startTime,
      slotCount: range.slotCount,
      isNextDayAvailability: range.isNextDayAvailability,
    };
  });
}

function formatAvailabilityRangesForPatient(ranges: AvailabilityRange[]): string {
  return ranges.map((range) => range.displayText).join(", ");
}

/**
 * Create Mastra tools that wrap Convex operations
 * This allows Mastra agents to interact with Convex database
 * UPDATED: Now supports OpenAI GPT-4o Vision for document/file analysis
 */

// Global Convex internal reference (set when tool executes)
let ConvexInternal: any = null;

function getDefaultConvexInternal() {
  return {
    whatsapp: internalAny.whatsappQueries,
    whatsappActions: internalAny.whatsapp,
    whatsappInternal: internalAny.whatsappInternal,
    patients: internalAny.patients,
    appointments: {
      ...apiAny.appointments,
      ...internalAny.appointments,
    },
    clinics: internalAny.clinics,
    automation: internalAny.automation,
    auditLogs: internalAny.auditLogs,
    users: apiAny.users || internalAny.users,
    tickets: internalAny.tickets,
    nps: internalAny.nps,
    checkin: internalAny.checkin,
  };
}

function initConvex() {
  const globalConvexInternal = (global as any).ConvexInternal;
  if (globalConvexInternal) {
    ConvexInternal = globalConvexInternal;
    return ConvexInternal;
  }

  if (!ConvexInternal) {
    ConvexInternal = getDefaultConvexInternal();
  }

  return ConvexInternal;
}

/**
 * Convex ID prefixes for different tables
 * Used to detect when wrong ID type is passed
 */
const ID_PREFIXES = {
  doctor: ["j"], // users table
  procedure: ["k"], // procedures table
  patient: ["k"], // patients table (same prefix as procedures - need context)
  appointment: ["j"], // appointments table
  storage: ["kg"], // _storage table
  message: ["js"], // messages table
};

/**
 * Common placeholder patterns that AI might generate
 */
const PLACEHOLDER_PATTERNS = [
  "_id_do_",
  "id_do_",
  "_id_da_",
  "id_da_",
  "_example",
  "placeholder",
  "doctor_id",
  "procedure_id",
  "patient_id",
  "id_do_medico",
  "id_do_doutor",
  "id_do_procedimento",
  "id_do_paciente",
  "doctorid",
  "procedureid",
  "patientid",
  "xxx",
  "yyy",
  "zzz",
  "abc123",
  "12345",
  "test_",
  "sample_",
  "fake_",
];

/**
 * Validate Convex ID format and detect placeholder/wrong IDs
 * Throws descriptive error if ID is invalid with recovery instructions
 */
function validateConvexId(
  id: string,
  type: "doctor" | "procedure" | "patient",
  context?: { patientId?: string },
): void {
  const typeLabel = {
    doctor: "doctorId (ID do médico)",
    procedure: "procedureId (ID do procedimento)",
    patient: "patientId (ID do paciente)",
  }[type];

  const sourceTool = {
    doctor: "searchDoctors",
    procedure: "listProcedures",
    patient: "contexto do paciente",
  }[type];

  const idField = {
    doctor: "_id",
    procedure: "id",
    patient: "_id",
  }[type];

  // Check if ID exists
  if (!id || typeof id !== "string") {
    throw new Error(
      `❌ ERRO: ${typeLabel} está vazio ou inválido.\n\n` +
        `🔧 AÇÃO OBRIGATÓRIA:\n` +
        `1. Chame a ferramenta '${sourceTool}' para obter um ID real\n` +
        `2. Use EXATAMENTE o valor do campo '${idField}' do resultado\n` +
        `3. NÃO invente IDs - use apenas IDs retornados pelas ferramentas`,
    );
  }

  // Check minimum length (Convex IDs are typically 32+ characters, but accept 10+ for test environments)
  if (id.length < 10) {
    throw new Error(
      `❌ ERRO: ${typeLabel} muito curto (${id.length} caracteres).\n` +
        `Recebido: "${id}"\n` +
        `Esperado: ID Convex com 10+ caracteres\n\n` +
        `🔧 AÇÃO OBRIGATÓRIA:\n` +
        `1. Chame a ferramenta '${sourceTool}' para obter um ID real\n` +
        `2. Use EXATAMENTE o valor do campo '${idField}' do resultado`,
    );
  }

  // Check for placeholder patterns
  const lowerId = id.toLowerCase();
  const foundPlaceholder = PLACEHOLDER_PATTERNS.find((p) => lowerId.includes(p.toLowerCase()));
  if (foundPlaceholder) {
    throw new Error(
      `❌ ERRO CRÍTICO: ID placeholder detectado!\n` +
        `Recebido: "${id}"\n` +
        `Padrão proibido: "${foundPlaceholder}"\n\n` +
        `🔧 AÇÃO OBRIGATÓRIA:\n` +
        `1. NUNCA use IDs que você inventar\n` +
        `2. Chame a ferramenta '${sourceTool}' AGORA\n` +
        `3. Use EXATAMENTE o valor do campo '${idField}' do resultado\n` +
        `4. O ID real será algo como "j7fzw9x241qvrk1asdtwdfcyn7yq4rc"`,
    );
  }

  // Check for valid Convex ID format:
  // - Production: alphanumeric 20+ chars (e.g., "j7fzw9x241qvrk1asdtwdfcyn7yq4rc")
  const validProductionIdPattern = /^[a-zA-Z0-9]{20,}$/;

  if (!validProductionIdPattern.test(id)) {
    throw new Error(
      `❌ ERRO: Formato de ID inválido.\n` +
        `Recebido: "${id}"\n` +
        `Esperado: ID Convex válido (formato alphanumeric com 20+ caracteres)\n\n` +
        `🔧 AÇÃO OBRIGATÓRIA:\n` +
        `1. Chame a ferramenta '${sourceTool}' para obter um ID real\n` +
        `2. Copie EXATAMENTE o valor do campo '${idField}'`,
    );
  }

  // Cross-validation: Check if patientId is being used as procedureId
  if (type === "procedure" && context?.patientId && id === context.patientId) {
    throw new Error(
      `❌ ERRO CRÍTICO: Você está usando o patientId como procedureId!\n` +
        `patientId e procedureId são IDs DIFERENTES de tabelas DIFERENTES.\n\n` +
        `🔧 AÇÃO OBRIGATÓRIA:\n` +
        `1. patientId: use o ID do contexto do paciente\n` +
        `2. procedureId: chame 'listProcedures' e use o campo 'id'\n` +
        `3. NUNCA use o mesmo valor para ambos\n\n` +
        `Os IDs devem ser diferentes!`,
    );
  }
}

/**
 * Zod schema refinement for Convex IDs
 * Use this in inputSchema for automatic validation
 */
const convexIdSchema = (type: "doctor" | "procedure" | "patient", description: string) =>
  z
    .string()
    .superRefine((val, ctx) => {
      try {
        validateConvexId(val, type);
      } catch (e: any) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: e.message,
        });
      }
    })
    .describe(description);

/**
 * WhatsApp sending tool
 * Sends a WhatsApp message to a patient
 */
export const sendWhatsAppTool = (_ctx: any) =>
  createTool({
    id: "send-whatsapp",
    description: "Send a WhatsApp message to a patient",
    inputSchema: z.object({
      chatId: z.string().describe("The WhatsApp chat ID"),
      message: z.string().describe("The message to send"),
    }),
    execute: async ({ context }) => {
      try {
        // Call internal Convex mutation to send WhatsApp message
        const messageId = await _ctx.runMutation(internal.whatsappQueries.sendMessageAction, {
          chatId: context.chatId,
          text: context.message,
        });

        return {
          success: true,
          messageId,
          channel: "whatsapp",
        };
      } catch (error) {
        console.error("[sendWhatsAppTool] Error:", error);
        throw new Error(`Failed to send WhatsApp message: ${error}`);
      }
    },
  });

/**
 * Patient info tool
 * Fetches patient information from the database
 */
export const getPatientInfoTool = (ctx: any) =>
  createTool({
    id: "get-patient-info",
    description: "Get detailed information about a patient by their ID",
    inputSchema: z.object({
      patientId: z.string().describe("The patient ID"),
    }),
    execute: async ({ context }) => {
      try {
        const { internal } = await import("../convex/_generated/api.js");
        const internalAny = internal as any;

        const patient = await ctx.runQuery(internalAny.patients.getByIdInternal, {
          id: context.patientId,
        });

        if (!patient) {
          throw new Error(`Patient not found: ${context.patientId}`);
        }

        return {
          patient,
          found: true,
        };
      } catch (error) {
        console.error("[getPatientInfoTool] Error:", error);
        throw error;
      }
    },
  });

/**
 * Appointment info tool
 * Fetches appointment details from the database
 */
export const getAppointmentTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "get-appointment",
    description: "Get detailed information about an appointment",
    inputSchema: z.object({
      appointmentId: z.string().describe("The appointment ID"),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        const appointment = await ctx.runQuery(ConvexInternal.appointments.getByIdInternal, {
          id: context.appointmentId,
          clinicId,
        });

        if (!appointment) {
          throw new Error(`Appointment not found: ${context.appointmentId}`);
        }

        return {
          appointment,
          found: true,
        };
      } catch (error) {
        console.error("[getAppointmentTool] Error:", error);
        throw error;
      }
    },
  });

/**
 * List appointments tool
 * Queries appointments with filters
 */
export const listAppointmentsTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "list-appointments",
    description:
      "List EXISTING/BOOKED appointments. WARNING: This does NOT show available/free slots - it only shows appointments that are already booked! To check availability and find free slots, use checkDoctorAvailability instead. This tool is for viewing the patient's current appointments or clinic schedule.",
    inputSchema: z.object({
      status: z
        .string()
        .nullable()
        .optional()
        .describe(
          "Filter by appointment status (pending, confirmed, cancelled, completed, arrived)",
        ),
      patientId: z.string().nullable().optional().describe("Filter by patient ID"),
      startDate: z.number().nullable().optional().describe("Start date filter (timestamp)"),
      endDate: z.number().nullable().optional().describe("End date filter (timestamp)"),
    }),
    execute: async ({ context }) => {
      try {
        const { internal } = await import("../convex/_generated/api.js");
        const internalAny = internal as any;

        // Convert null to undefined for optional parameters
        const status = context.status === null ? undefined : context.status;
        const patientId = context.patientId === null ? undefined : context.patientId;
        const startAt = context.startDate === null ? undefined : context.startDate;
        const endAt = context.endDate === null ? undefined : context.endDate;

        const result = await ctx.runQuery(internalAny.appointments.listInternal, {
          clinicId,
          status: status as any,
          patientId: patientId as any,
          startAt,
          endAt,
        });

        return {
          appointments: result.items || [],
          count: result.items?.length || 0,
          message:
            (result.items?.length || 0) > 0
              ? `Encontrei ${result.items?.length || 0} agendamento(s).`
              : "Nenhum agendamento encontrado para os filtros informados. NOTA: Esta ferramenta só mostra agendamentos EXISTENTES. Para verificar horários DISPONÍVEIS para agendamento futuro, use a ferramenta checkDoctorAvailability.",
        };
      } catch (error) {
        console.error("[listAppointmentsTool] Error:", error);
        throw error;
      }
    },
  });

export const cancelAppointmentTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "cancel-appointment",
    description: `Cancel an existing appointment.

Use this ONLY after confirming with the patient.
Recommended flow:
1. Use listAppointments or getAppointment to identify the real appointmentId
2. Confirm the cancellation with the patient
3. Call cancelAppointment with the exact appointmentId`,
    inputSchema: z.object({
      appointmentId: z.string().describe("The exact appointment ID to cancel"),
      patientId: z
        .string()
        .optional()
        .nullable()
        .describe("Optional patient ID from context to validate ownership before cancelling"),
      reason: z.string().optional().nullable().describe("Optional cancellation reason"),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        const appointment = await ctx.runQuery(ConvexInternal.appointments.getByIdInternal, {
          id: context.appointmentId as any,
          clinicId,
        });

        if (!appointment) {
          throw new Error(`Agendamento não encontrado: ${context.appointmentId}`);
        }

        if (context.patientId && appointment.patientId !== context.patientId) {
          throw new Error("O appointmentId informado não pertence ao paciente atual");
        }

        if (appointment.status === "cancelled") {
          return {
            success: true,
            appointmentId: appointment._id,
            status: appointment.status,
            appointment: {
              id: appointment._id,
              startAt: new Date(appointment.startAt).toISOString(),
              endAt: new Date(appointment.endAt).toISOString(),
              doctor: appointment.doctor,
              procedure: appointment.procedure,
              isTelemedicine: appointment.isTelemedicine,
            },
            alreadyCancelled: true,
            message: "Agendamento já estava cancelado.",
          };
        }

        const existingNotes = typeof appointment.notes === "string" ? appointment.notes.trim() : "";
        const cancellationNote = context.reason
          ? `[Cancelamento via IA] ${context.reason.trim()}`
          : "[Cancelamento via IA]";

        const updatedAppointment = await ctx.runMutation(api.appointments.update, {
          id: context.appointmentId as any,
          clinicId,
          status: "cancelled",
          notes: [existingNotes, cancellationNote].filter(Boolean).join("\n"),
        });

        return {
          success: true,
          appointmentId: updatedAppointment?._id || context.appointmentId,
          status: updatedAppointment?.status || "cancelled",
          appointment: {
            id: appointment._id,
            startAt: new Date(appointment.startAt).toISOString(),
            endAt: new Date(appointment.endAt).toISOString(),
            doctor: appointment.doctor,
            procedure: appointment.procedure,
            isTelemedicine: appointment.isTelemedicine,
          },
          message: "Agendamento cancelado com sucesso.",
        };
      } catch (error) {
        console.error("[cancelAppointmentTool] Error:", error);
        throw error;
      }
    },
  });

/**
 * Schedule reminder tool
 * Sets a reminder timestamp on an appointment
 */
export const scheduleReminderTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "schedule-reminder",
    description: "Mark an appointment as having received a reminder",
    inputSchema: z.object({
      appointmentId: z.string().describe("The appointment ID"),
      reminderType: z.string().describe("Type of reminder sent"),
    }),
    execute: async ({ context }) => {
      try {
        const appointment = await ctx.runQuery(internalAny.appointments.getByIdInternal, {
          id: context.appointmentId as any,
          clinicId,
        });

        if (!appointment) {
          throw new Error(`Appointment not found: ${context.appointmentId}`);
        }

        await ctx.runMutation(internalAny.appointmentsInternal.markReminderSent, {
          id: context.appointmentId as any,
          reminderAt: Date.now(),
        });

        return {
          success: true,
          reminderType: context.reminderType,
          scheduledAt: Date.now(),
        };
      } catch (error) {
        console.error("[scheduleReminderTool] Error:", error);
        throw error;
      }
    },
  });

/**
 * Clinic info tool
 * Fetches clinic information
 */
export const getClinicInfoTool = (_ctx: any, clinicId: string) =>
  createTool({
    id: "get-clinic-info",
    description: "Get detailed information about a clinic",
    inputSchema: z.object({}),
    execute: async () => {
      try {
        initConvex();
        // Use internal query to avoid authentication requirements
        const clinic = await _ctx.runQuery(internalAny.clinics.getClinicInternal, {
          clinicId,
        });

        if (!clinic) {
          console.warn(`[getClinicInfoTool] Clinic not found for clinicId: ${clinicId}`);
          return {
            clinic: null,
            found: false,
          };
        }

        return {
          clinic,
          found: true,
        };
      } catch (error) {
        console.error("[getClinicInfoTool] Error:", error);
        throw error;
      }
    },
  });

/**
 * Get AI settings tool
 * Fetches AI configuration for a clinic
 */
export const getAiSettingsTool = (_ctx: any, clinicId: string) =>
  createTool({
    id: "get-ai-settings",
    description: "Get AI settings configuration for a clinic",
    inputSchema: z.object({}),
    execute: async () => {
      try {
        const settings = await _ctx.runQuery(internal.automation.getAiSettingsInternal, {
          clinicId,
        });

        return {
          settings: settings || null,
          found: !!settings,
        };
      } catch (error) {
        console.error("[getAiSettingsTool] Error:", error);
        throw error;
      }
    },
  });

/**
 * Escalate to staff tool
 * Sends emergency notification to clinic staff
 * ONLY use this for problems, emergencies, or issues the AI cannot solve
 * DO NOT use for routine appointment requests - handle those normally
 */
export const escalateToStaffTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "escalate-to-staff",
    description:
      "Transfer the conversation to a human attendant. Call this tool whenever you intend to tell the patient you are transferring them to staff (e.g. 'transferindo para atendente', 'encaminhando para a equipe'). DO NOT say you are transferring without calling this tool. Do not escalate on generic 'help/ajuda' wording alone; first try to solve the request or clarify. Use for: explicit handover to human, emergencies, problems the AI cannot solve, or when the flow requires human follow-up.",
    inputSchema: z.object({
      patientId: z.string().optional().nullable().describe("The patient ID involved"),
      reason: z.string().describe("Reason for escalation"),
      severity: z
        .enum(["low", "medium", "high", "emergency"])
        .optional()
        .nullable()
        .describe("Severity level"),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        console.warn("[escalateToStaffTool] Starting escalation:", {
          clinicId,
          patientId: context.patientId,
          reason: context.reason,
          severity: context.severity || "high",
        });

        // Log escalation to audit logs
        try {
          await ctx.runMutation(api.auditLogs.insert, {
            action: "ai_escalation",
            clinicId,
            metadata: {
              reason: context.reason,
              severity: context.severity || "high",
              patientId: context.patientId,
              escalatedAt: Date.now(),
            },
            createdAt: Date.now(),
          });
          console.warn("[escalateToStaffTool] Audit log created successfully");
        } catch (auditError) {
          console.error("[escalateToStaffTool] Failed to create audit log:", auditError);
          // Continue even if audit log fails
        }

        // Operational handoff: create internal ticket so staff has a concrete queue item.
        if (context.patientId) {
          try {
            const severityToPriority: Record<string, "low" | "medium" | "high" | "urgent"> = {
              low: "low",
              medium: "medium",
              high: "high",
              emergency: "urgent",
            };

            await ctx.runMutation(internalAny.tickets.createTicket, {
              clinicId,
              patientId: context.patientId,
              title: "Escalação de atendimento por IA",
              description: context.reason,
              priority: severityToPriority[context.severity || "high"] || "high",
              source: "other",
            });
            console.warn("[escalateToStaffTool] Ticket created successfully");
          } catch (ticketError) {
            console.warn("[escalateToStaffTool] Failed to create escalation ticket:", ticketError);
            // Continue even if ticket creation fails
          }
        }

        console.warn("[escalateToStaffTool] Escalation completed successfully");

        return {
          success: true,
          escalatedAt: Date.now(),
          severity: context.severity || "high",
        };
      } catch (error) {
        console.error("[escalateToStaffTool] Fatal error:", error);
        throw error;
      }
    },
  });

/**
 * NEW: Analyze Document Tool
 * Uses OpenAI GPT-4o Vision to analyze documents, images, and files
 * This enables the agent to understand medical records, prescriptions, lab results, etc.
 */
export const analyzeDocumentTool = (_ctx: any) =>
  createTool({
    id: "analyze-document",
    description:
      "Analyze medical document, image, or file using GPT-4o Vision. Can extract patient info, dates, diagnoses, prescriptions, lab results, and important medical data. Set identifyType=true to automatically detect if image is insurance_card, id_card, or referral.",
    inputSchema: z.object({
      fileId: z
        .string()
        .describe(
          "Convex storage ID (starts with 'kg') of the document/file. MUST be mediaStorageId, NOT messageId.",
        ),
      documentType: z
        .enum(["document", "image", "audio"])
        .optional()
        .nullable()
        .describe("Type of content (document, image, audio)"),
      language: z
        .string()
        .optional()
        .nullable()
        .describe("Language code (e.g., pt for Portuguese)"),
      extractFields: z
        .array(z.string())
        .nullish()
        .transform((val) => val ?? [])
        .describe('Specific fields to extract (e.g., ["patientName", "date", "diagnosis"])'),
      identifyType: z
        .boolean()
        .optional()
        .nullable()
        .describe(
          "Set to true to identify the document type (insurance_card, id_card, referral, other)",
        ),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        // Validate that fileId is a storage ID, not a message ID
        const isStorageId = ID_PREFIXES.storage.some((prefix) => context.fileId.startsWith(prefix));
        if (!isStorageId) {
          const isMessageId = ID_PREFIXES.message.some((prefix) =>
            context.fileId.startsWith(prefix),
          );
          throw new Error(
            isMessageId
              ? `Invalid fileId: received message ID (${context.fileId}), expected storage ID (mediaStorageId). Use currentMessage.mediaStorageId instead of messageId.`
              : `Invalid storage ID format: ${context.fileId}. Storage IDs start with '${ID_PREFIXES.storage.join(" or ")}'`,
          );
        }

        // Fetch document URL from Convex storage
        const documentUrl = await _ctx.storage.getUrl(context.fileId);
        if (!documentUrl) {
          throw new Error(`File not found: ${context.fileId}`);
        }

        // Download file content
        const response = await fetch(documentUrl);
        const blob = await response.blob();
        const contentType =
          blob.type || response.headers.get("content-type") || "application/octet-stream";
        const isImage = context.documentType === "image" || isImageMimeType(contentType);

        let content: string;
        let extractedData: Record<string, any> = {};

        if (context.identifyType && isImage) {
          const imageDataUrl = await blobToDataUrl(blob, contentType);
          const visionResponse = await generateText({
            model: getImageVisionModel() as any,
            messages: [
              {
                role: "user",
                content: [
                  {
                    type: "image",
                    image: imageDataUrl,
                  } as any,
                  {
                    type: "text",
                    text: `Identifique o tipo deste documento médico brasileiro. Responda APENAS com JSON:
- "insurance_card": Carteirinha de convênio/plano de saúde
- "id_card": Documento de identidade (RG, CNH)
- "referral": Guia de encaminhamento médico
- "other": Outro tipo

Formato: {"type": "insurance_card" | "id_card" | "referral" | "other", "confidence": 0-100, "description": "breve descrição"}`,
                  },
                ],
              },
            ] as any,
          });

          content = visionResponse.text || "";
          try {
            const cleanContent = content.replace(/```json\n?|\n?```/g, "").trim();
            extractedData = JSON.parse(cleanContent);
          } catch {
            extractedData = {
              type: "other",
              confidence: 50,
              description: content.substring(0, 200),
              rawResponse: content,
            };
          }
          extractedData.identificationMode = true;
          console.warn("[analyzeDocumentTool] Image type identified:", extractedData);
        } else if (isImage) {
          const imageDataUrl = await blobToDataUrl(blob, contentType);
          const visionResponse = await generateText({
            model: getImageVisionModel() as any,
            messages: [
              {
                role: "user",
                content: [
                  {
                    type: "image",
                    image: imageDataUrl,
                  } as any,
                  {
                    type: "text",
                    text:
                      context.extractFields && context.extractFields.length > 0
                        ? `Extraia as seguintes informações deste documento: ${context.extractFields.join(", ")}`
                        : "Analise este documento médico e extraia informações importantes como nome do paciente, datas, diagnósticos, receitas, resultados de exames, etc.",
                  },
                ],
              },
            ] as any,
          });

          content = visionResponse.text || "";
          extractedData.analyzed = true;

          if (content) {
            console.warn(
              "[analyzeDocumentTool] Vision analysis complete:",
              content.substring(0, 200),
            );
          }
        } else {
          const fallbackModelId = getVisionModelIdForMimeType(contentType);
          const analysisResponse = await generateText({
            model: getDocumentFallbackModel() as any,
            messages: [
              {
                role: "user",
                content: [
                  {
                    type: "text",
                    text: "Analise este arquivo médico cuidadosamente.",
                  },
                  {
                    type: "text",
                    text:
                      context.extractFields && context.extractFields.length > 0
                        ? `Extraia as seguintes informações específicas: ${context.extractFields.join(", ")}`
                        : "Extraia informações importantes deste documento médico como: nome do paciente, CPF, data de nascimento, datas de consultas, diagnósticos, medicamentos prescritos, exames laboratoriais, alergias, histórico médico.",
                  },
                  {
                    type: "file",
                    data: documentUrl,
                    mediaType: contentType,
                  },
                ],
              },
            ] as any,
          });

          content = analysisResponse.text || "";
          extractedData.analyzed = true;

          if (content) {
            console.warn(
              `[analyzeDocumentTool] Document analysis complete via ${fallbackModelId}:`,
              content.substring(0, 200),
            );
          }
        }

        return {
          content,
          extractedData,
          documentUrl,
          fileType: context.documentType || "unknown",
        };
      } catch (error) {
        console.error("[analyzeDocumentTool] Error:", error);
        throw new Error(`Failed to analyze document: ${error}`);
      }
    },
  });

/**
 * NEW: Transcribe Audio Tool using OpenAI Whisper
 * Transcribes audio messages from WhatsApp to text
 * Enables agents to understand voice notes
 */
export const transcribeAudioTool = (ctx: any) =>
  createTool({
    id: "transcribe-audio",
    description:
      "Transcribe audio file using OpenAI Whisper. Converts voice messages to text for the agent to process.",
    inputSchema: z.object({
      fileId: z.string().describe("Convex storage ID of the audio file"),
      language: z
        .string()
        .optional()
        .nullable()
        .describe("Language code (e.g., pt for Portuguese)"),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        // Fetch audio URL from Convex storage
        const audioUrl = await ctx.storage.getUrl(context.fileId);
        if (!audioUrl) {
          throw new Error(`Audio file not found: ${context.fileId}`);
        }

        const transcription = await transcribeAudioFromUrl({
          audioUrl,
          model: process.env.OPENAI_WHISPER_MODEL || MASTRA_CONFIG.models.audio,
          ...(context.language ? { language: context.language } : {}),
        });

        console.warn("[transcribeAudioTool] Transcription complete", {
          fileId: context.fileId,
          preview: transcription.text.substring(0, 120),
          model: transcription.model,
        });

        return {
          transcribedText: transcription.text,
          language: transcription.language || context.language || "unknown",
          duration: transcription.duration || 0,
          fileId: context.fileId,
          model: transcription.model,
          success: true,
        };
      } catch (error) {
        console.error("[transcribeAudioTool] Error:", error);
        throw new Error(`Failed to transcribe audio: ${error}`);
      }
    },
  });

/**
 * List specialties tool
 * Lists all unique specialties available in the clinic
 */
export const listSpecialtiesTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "list-specialties",
    description: "List all medical specialties available in the clinic",
    inputSchema: z.object({}),
    execute: async () => {
      try {
        initConvex();

        const specialties = await ctx.runQuery(ConvexInternal.users.listSpecialties, {
          clinicId,
        });

        return {
          specialties,
          count: specialties.length,
        };
      } catch (error) {
        console.error("[listSpecialtiesTool] Error:", error);
        throw error;
      }
    },
  });

/**
 * List doctors by specialty tool
 * Finds doctors that have a specific specialty with fuzzy matching
 * Returns top 3 contenders with match scores when no exact match found
 */
export const listDoctorsBySpecialtyTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "list-doctors-by-specialty",
    description: `Find doctors who practice a specific specialty.

Supports flexible matching - will find doctors even with variations like:
- "cardiologia" matches "cardiologista"
- "pediatria" matches "pediatra"

Returns top 3 doctors with match scores when no exact match is found.

⚠️ IMPORTANT - HOW TO USE THE RESULT:
The result contains:
- exactMatch: true if doctors with exact specialty found
- doctors: array with top 3 doctors (each has _id, name, specialties, matchScore, matchReason)
- suggestion: message to show user if no exact match

If suggestion is not null, inform the user about the best matches available.`,
    inputSchema: z.object({
      specialty: z.string().optional().nullable().describe("Specialty to filter by"),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        const result = await ctx.runQuery(ConvexInternal.users.listDoctorsBySpecialty, {
          clinicId,
          specialty: context.specialty ?? undefined,
        });

        const allSpecialties = await ctx.runQuery(ConvexInternal.users.listSpecialties, {
          clinicId,
        });

        const uniqueSpecialties = getSpecialtyClarificationOptions(
          context.specialty || "",
          (allSpecialties || []).filter((specialty: string | undefined) => {
            const normalized = normalizeEntityText(specialty || "");
            return Boolean(normalized) && normalized !== "telemedicina";
          }),
        );

        if (!result.exactMatch && uniqueSpecialties.length > 0) {
          return {
            ...result,
            ...buildClarificationResult({
              clarificationType: "specialty",
              question: buildClarificationQuestion(
                "especialidade",
                context.specialty || "essa especialidade",
                uniqueSpecialties,
              ),
              choices: uniqueSpecialties.map((specialty) => ({ specialty })),
            }),
          };
        }

        return result;
      } catch (error) {
        console.error("[listDoctorsBySpecialtyTool] Error:", error);
        throw error;
      }
    },
  });

/**
 * Check specialty availability tool
 * Checks aggregated availability for all doctors in a specialty
 */
export const checkSpecialtyAvailabilityTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "check-specialty-availability",
    description:
      "Check available appointment slots for a specific specialty (aggregates all doctors). Optionally pass period as morning, afternoon, or night to avoid mixing times from other parts of the day.",
    inputSchema: z.object({
      specialty: z.string().describe("Specialty to check availability for"),
      startDate: z.string().describe("Start date (ISO string)"),
      endDate: z.string().optional().nullable().describe("End date (ISO string)"),
      period: z.enum(["morning", "afternoon", "night"]).optional().nullable(),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        const specialtyResult = await ctx.runQuery(ConvexInternal.users.listDoctorsBySpecialty, {
          clinicId,
          specialty: context.specialty,
        });

        const allSpecialties = await ctx.runQuery(ConvexInternal.users.listSpecialties, {
          clinicId,
        });

        const uniqueSpecialties = getSpecialtyClarificationOptions(
          context.specialty,
          (allSpecialties || []).filter((specialty: string | undefined) => {
            const normalized = normalizeEntityText(specialty || "");
            return Boolean(normalized) && normalized !== "telemedicina";
          }),
        );

        if (!specialtyResult.exactMatch && uniqueSpecialties.length > 0) {
          return buildClarificationResult({
            clarificationType: "specialty",
            question: buildClarificationQuestion(
              "especialidade",
              context.specialty,
              uniqueSpecialties,
            ),
            choices: uniqueSpecialties.map((specialty) => ({ specialty })),
            successPayload: {
              slots: [],
              count: 0,
            },
          });
        }

        const slots = await ctx.runQuery(ConvexInternal.appointments.getSpecialtyAvailability, {
          clinicId,
          specialty: context.specialty,
          startDate: context.startDate,
          endDate: context.endDate ?? undefined,
          period: context.period ?? undefined,
          maxSlots: MAX_PRESENTED_AVAILABILITY_SLOTS,
        });

        return {
          slots,
          count: slots.length,
        };
      } catch (error) {
        console.error("[checkSpecialtyAvailabilityTool] Error:", error);
        throw error;
      }
    },
  });

/**
 * Create internal ticket tool
 * Creates support ticket for non-promoter NPS responses
 */
export const createInternalTicketTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "create-internal-ticket",
    description:
      "Create an internal support ticket for non-promoter NPS responses. Use this when a patient gives a low NPS score (0-8) to ensure the clinic can follow up.",
    inputSchema: z.object({
      patientId: z.string().describe("The patient ID"),
      appointmentId: z
        .string()
        .optional()
        .nullable()
        .describe("The appointment ID (if related to appointment)"),
      title: z.string().describe("Ticket title (e.g., 'NPS Detractor - Score 6')"),
      description: z.string().describe("Ticket description with patient feedback"),
      priority: z
        .enum(["low", "medium", "high", "urgent"])
        .describe("Ticket priority based on NPS score (lower scores = higher priority)"),
      npsScore: z.number().describe("The NPS score (0-10)"),
      npsFeedback: z.string().optional().nullable().describe("Patient feedback text"),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        const ticket = await ctx.runMutation(ConvexInternal.tickets.createTicket, {
          clinicId,
          patientId: context.patientId as any,
          appointmentId: (context.appointmentId ?? undefined) as any,
          title: context.title,
          description: context.description,
          priority: context.priority,
          source: "nps",
          npsScore: context.npsScore,
          npsFeedback: context.npsFeedback ?? undefined,
        });

        return {
          success: true,
          ticketId: ticket._id,
          message: "Internal ticket created successfully",
        };
      } catch (error) {
        console.error("[createInternalTicketTool] Error:", error);
        throw new Error(`Failed to create ticket: ${error}`);
      }
    },
  });

/**
 * Save NPS score tool
 * Records NPS response to database
 */
export const saveNpsScoreTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "save-nps-score",
    description:
      "Save an NPS response to the database. Use this after extracting the score (0-10) and classifying the promoter type.",
    inputSchema: z.object({
      patientId: z.string().describe("The patient ID"),
      appointmentId: z.string().describe("The appointment ID"),
      score: z.number().min(0).max(10).describe("The NPS score (0-10)"),
      feedback: z.string().describe("Patient feedback text (can be empty string)"),
      promoterType: z
        .enum(["promoter", "passive", "detractor"])
        .describe("Classification: promoter (9-10), passive (7-8), detractor (0-6)"),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        await ctx.runMutation(ConvexInternal.nps.recordNpsResponse, {
          clinicId,
          patientId: context.patientId as any,
          appointmentId: context.appointmentId as any,
          score: context.score,
          messageText: context.feedback,
          promoterType: context.promoterType,
          channel: "whatsapp",
        });

        return {
          success: true,
          message: "NPS score saved successfully",
        };
      } catch (error) {
        console.error("[saveNpsScoreTool] Error:", error);
        throw new Error(`Failed to save NPS score: ${error}`);
      }
    },
  });

/**
 * Request Google review tool
 * Sends Google Maps review link to promoter
 */
export const requestGoogleReviewTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "request-google-review",
    description:
      "Send Google Maps review link to a promoter (NPS score 9-10). Use this after saving the NPS score for promoters. Requires patientId to find the chat.",
    inputSchema: z.object({
      patientId: z.string().describe("The patient ID (to find the chat)"),
      googleMapsLink: z.string().describe("The Google Maps review link"),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        // Get patient with chat to find chatId
        const result = await ctx.runQuery(ConvexInternal.nps.getPatientWithChat, {
          patientId: context.patientId as any,
          clinicId,
        });

        if (!result || !result.chat) {
          throw new Error("Chat not found for patient");
        }

        await ctx.runAction(internal.nps.sendGoogleReviewFollowUp, {
          clinicId,
          chatId: result.chat._id,
          googleMapsLink: context.googleMapsLink,
        });

        return {
          success: true,
          message: "Google review link sent successfully",
        };
      } catch (error) {
        console.error("[requestGoogleReviewTool] Error:", error);
        throw new Error(`Failed to send Google review link: ${error}`);
      }
    },
  });

/**
 * Get NPS settings tool
 * Queries NPS configuration for the clinic
 */
export const getNpsSettingsTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "get-nps-settings",
    description:
      "Get NPS configuration settings including thresholds (promoter, passive, detractor) and Google Maps review link.",
    inputSchema: z.object({}),
    execute: async () => {
      try {
        initConvex();

        const settings = await ctx.runQuery(ConvexInternal.nps.getNpsSettingsInternal, {
          clinicId,
        });

        return {
          settings: settings || null,
          thresholds: settings?.thresholds || {
            promoter: 9,
            passive: 7,
            detractor: 6,
          },
          googleMapsLink: settings?.googleMapsLink || null,
        };
      } catch (error) {
        console.error("[getNpsSettingsTool] Error:", error);
        throw new Error(`Failed to get NPS settings: ${error}`);
      }
    },
  });

/**
 * Get Google Review Link tool
 * Returns only the Google Maps review link from NPS settings
 * Simplified tool for promoter flow
 */
export const getReviewLinkTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "get-review-link",
    description:
      "Get the Google Maps review link from NPS settings. Returns the link if configured, null otherwise. Use this to check if a review link is available before thanking a promoter.",
    inputSchema: z.object({}),
    execute: async () => {
      try {
        initConvex();

        const settings = await ctx.runQuery(ConvexInternal.nps.getNpsSettingsInternal, {
          clinicId,
        });

        return {
          googleMapsLink: settings?.googleMapsLink || null,
          hasLink: !!settings?.googleMapsLink,
        };
      } catch (error) {
        console.error("[getReviewLinkTool] Error:", error);
        throw new Error(`Failed to get review link: ${error}`);
      }
    },
  });

/**
 * Tool factory for dynamic context injection
 * Creates all tools with Convex context bound
 */
export function createConvexTools(ctx: any, clinicId: string) {
  return {
    getPatientInfo: getPatientInfoTool(ctx),
    getAppointment: getAppointmentTool(ctx, clinicId),
    listAppointments: listAppointmentsTool(ctx, clinicId),
    cancelAppointment: cancelAppointmentTool(ctx, clinicId),
    scheduleReminder: scheduleReminderTool(ctx, clinicId),
    getClinicInfo: getClinicInfoTool(ctx, clinicId),
    getAiSettings: getAiSettingsTool(ctx, clinicId),
    escalateToStaff: escalateToStaffTool(ctx, clinicId),
    analyzeDocument: analyzeDocumentTool(ctx),
    transcribeAudio: transcribeAudioTool(ctx),
    listSpecialties: listSpecialtiesTool(ctx, clinicId),
    listDoctorsBySpecialty: listDoctorsBySpecialtyTool(ctx, clinicId),
    checkSpecialtyAvailability: checkSpecialtyAvailabilityTool(ctx, clinicId),
    getPatientByPhone: getPatientByPhoneTool(ctx, clinicId),
    searchDoctors: searchDoctorsTool(ctx, clinicId),
    checkDoctorAvailability: checkDoctorAvailabilityTool(ctx, clinicId),
    listProcedures: listProceduresTool(ctx, clinicId),
    getAvailableDays: getAvailableDaysTool(ctx, clinicId),
    getAvailableHours: getAvailableHoursTool(ctx, clinicId),
    createAppointment: createAppointmentTool(ctx, clinicId),
    createInternalTicket: createInternalTicketTool(ctx, clinicId),
    saveNpsScore: saveNpsScoreTool(ctx, clinicId),
    requestGoogleReview: requestGoogleReviewTool(ctx, clinicId),
    getNpsSettings: getNpsSettingsTool(ctx, clinicId),
    getReviewLink: getReviewLinkTool(ctx, clinicId),
    savePatientImage: savePatientImageTool(ctx, clinicId),
    updatePatientData: updatePatientDataTool(ctx, clinicId),
  };
}

/**
 * Search doctors tool
 * Fuzzy search for doctors by name
 */
export const searchDoctorsTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "search-doctors",
    description: `Search for doctors by name (supports fuzzy matching).

⚠️ CRITICAL - HOW TO USE THE RESULT:
The result contains a 'doctors' array. Each doctor has an '_id' field.
You MUST copy the EXACT value of '_id' to use as doctorId in other tools.

Example result:
{
  "success": true,
  "doctors": [{ "_id": "j7fzw9x241qvrk1asdtwdfcyn7yq4rc", "name": "Dr. Josefino", ... }],
  "count": 1
}

To get doctorId: result.doctors[0]._id = "j7fzw9x241qvrk1asdtwdfcyn7yq4rc"
Then use this EXACT string in getAvailableDays, getAvailableHours, createAppointment.

⚠️ NEVER:
- Use placeholder IDs like "id_do_medico" or "doctorId"
- Make up IDs - always use the exact '_id' from the result
- Use patient ID as doctor ID`,
    inputSchema: z.object({
      query: z.string().describe("Doctor name to search for"),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        // Use ctx.runQuery instead of direct call
        const doctors = await ctx.runQuery(ConvexInternal.users.searchDoctors, {
          clinicId,
          query: context.query,
        });

        const resolved = resolveDoctorCandidates(doctors || [], context.query);
        if (resolved.status === "ambiguous") {
          return buildClarificationResult({
            clarificationType: "doctor",
            question: resolved.question,
            choices: resolved.ranked.slice(0, 3).map((candidate) => ({
              _id: candidate.item._id,
              name: candidate.item.name,
              specialties: candidate.item.specialties || [],
            })),
            successPayload: {
              doctors: resolved.ranked.slice(0, 3).map((candidate) => ({
                _id: candidate.item._id,
                name: candidate.item.name,
                specialties: candidate.item.specialties || [],
                email: candidate.item.email,
                phone: candidate.item.phone,
              })),
              count: resolved.ranked.length,
            },
          });
        }

        return {
          success: true,
          needsClarification: false,
          doctors: doctors.map((d: any) => ({
            _id: d._id,
            name: d.name,
            specialties: d.specialties || [],
            email: d.email,
            phone: d.phone,
          })),
          count: doctors.length,
          note: "⚠️ Copy the EXACT '_id' value (e.g., 'j7fzw9x241qvrk1asdtwdfcyn7yq4rc') and use it as doctorId. Do NOT use placeholder strings.",
        };
      } catch (error) {
        console.error("[searchDoctorsTool] Error:", error);
        throw error;
      }
    },
  });

/**
 * Check doctor availability tool
 * Checks available appointment slots for a specific doctor by name
 */
export const checkDoctorAvailabilityTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "check-doctor-availability",
    description:
      "CRITICAL: USE THIS TOOL FIRST for ALL availability questions. Check available appointment slots for a specific doctor by name. This is the PRIMARY tool for finding when a doctor is free - use it when patients ask about ANY time including specific hours (e.g., 'as 15h', 'as 10h'), periods ('manha', 'tarde', 'noite'), or general availability. Simply provide the doctor's name and date. Returns available slots with times like '08:00', '15:00', etc. DO NOT use listAppointments for availability - that only shows booked appointments, not free slots. Use this tool to find FREE slots.",
    inputSchema: z.object({
      doctorName: z
        .string()
        .describe(
          "The doctor's name to search for (e.g., 'Josefino', 'dr josefino', 'Dr. Josefino'). The tool will automatically find the doctor and check their availability.",
        ),
      startDate: z
        .string()
        .describe(
          "Start date in ISO 8601 format (e.g., '2026-01-10T00:00:00Z'). CRITICAL: You MUST use TODAY's date or a FUTURE date. The date must NOT be in the past. Current date format is day-month-year (e.g., 10/01/2026 means January 10, 2026). Always use the current year or later. If the validation fails, check the error message which will show the current date - use that date or later.",
        ),
      endDate: z
        .string()
        .optional()
        .nullable()
        .describe(
          "End date in ISO 8601 format (e.g., '2024-01-22T00:00:00Z'). Optional. If not provided, returns availability only for the startDate day.",
        ),
      procedureName: z
        .string()
        .optional()
        .nullable()
        .describe(
          "Optional: Name of the procedure to check availability for. If provided, slots will be filtered based on the procedure's duration. Use listProcedures tool first to get available procedures for the doctor.",
        ),
      period: z
        .enum(["morning", "afternoon", "night"])
        .optional()
        .nullable()
        .describe(
          "Optional: Filter results to morning (08-12), afternoon (13-18), or night (19-22).",
        ),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        // Validate clinicId
        if (!clinicId || clinicId.trim() === "") {
          throw new Error("clinicId is required but was not provided. This is a system error.");
        }

        // Validate doctorName and search for doctor
        const doctorName = context.doctorName;
        if (!doctorName || typeof doctorName !== "string" || doctorName.trim() === "") {
          throw new Error(
            "doctorName is required. Provide the doctor's name (e.g., 'Josefino', 'dr josefino').",
          );
        }

        // Search for the doctor first
        console.warn("[checkDoctorAvailabilityTool] Searching for doctor:", {
          query: doctorName.trim(),
          clinicId,
          timestamp: new Date().toISOString(),
        });

        const doctors = await ctx.runQuery(ConvexInternal.users.searchDoctors, {
          clinicId,
          query: doctorName.trim(),
        });

        console.warn("[checkDoctorAvailabilityTool] Search results:", {
          query: doctorName.trim(),
          resultsCount: doctors?.length || 0,
          results: doctors?.map((d: any) => ({
            name: d.name,
            id: d._id,
            specialties: d.specialties,
          })),
        });

        if (!doctors || doctors.length === 0) {
          return {
            success: false,
            needsClarification: false,
            message: `Nao encontrei um medico com o nome "${doctorName}". Pode confirmar o nome completo?`,
            slots: [],
            ranges: [],
            count: 0,
            requestedPeriod: context.period ?? null,
            requestedPeriodSlots: [],
            requestedPeriodRanges: [],
            requestedPeriodCount: 0,
            doctor: null,
            procedure: null,
          };
        }

        const resolvedDoctor = resolveDoctorCandidates(doctors || [], doctorName.trim());
        if (resolvedDoctor.status === "ambiguous") {
          return buildClarificationResult({
            clarificationType: "doctor",
            question: resolvedDoctor.question,
            choices: resolvedDoctor.ranked.slice(0, 3).map((candidate) => ({
              _id: candidate.item._id,
              name: candidate.item.name,
              specialties: candidate.item.specialties || [],
            })),
            successPayload: {
              slots: [],
              ranges: [],
              count: 0,
              requestedPeriod: context.period ?? null,
              requestedPeriodSlots: [],
              requestedPeriodRanges: [],
              requestedPeriodCount: 0,
              doctor: null,
              procedure: null,
            },
          });
        }

        if (resolvedDoctor.status !== "match") {
          return {
            success: false,
            needsClarification: false,
            message: `Nao encontrei um medico com o nome "${doctorName}". Pode confirmar o nome completo?`,
            slots: [],
            ranges: [],
            count: 0,
            requestedPeriod: context.period ?? null,
            requestedPeriodSlots: [],
            requestedPeriodRanges: [],
            requestedPeriodCount: 0,
            doctor: null,
            procedure: null,
          };
        }

        const doctor = resolvedDoctor.match;
        const doctorId = doctor._id;
        const similarity = calculateNameSimilarity(
          normalizeEntityText(doctorName.trim(), { stripDoctorPrefix: true }),
          normalizeEntityText(doctor.name, { stripDoctorPrefix: true }),
        );

        console.warn("[checkDoctorAvailabilityTool] Selected doctor:", {
          name: doctor.name,
          id: doctorId,
          query: doctorName.trim(),
          similarity,
          totalMatches: doctors.length,
        });

        // Strict validation: if similarity is too low, warn but still proceed (we'll make this stricter later)
        if (similarity < 0.6) {
          console.warn(
            `[checkDoctorAvailabilityTool] WARNING: Low similarity match (${similarity.toFixed(2)}). Query: "${doctorName.trim()}" matched "${doctor.name}"`,
          );
        }

        // Validate startDate (required)
        if (
          !context.startDate ||
          typeof context.startDate !== "string" ||
          context.startDate.trim() === ""
        ) {
          throw new Error(
            "startDate is required. Provide a date in ISO 8601 format (e.g., '2024-01-15T00:00:00Z'). For 'tomorrow', calculate tomorrow's date. The date must be in the future.",
          );
        }

        // Validate date format
        const startDateObj = new Date(context.startDate);
        if (isNaN(startDateObj.getTime())) {
          throw new Error(
            `Invalid startDate format: "${context.startDate}". Use ISO 8601 format (e.g., '2024-01-15T00:00:00Z').`,
          );
        }

        // Validate date is not in the past (compare by date only, not time)
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const startDateOnly = new Date(
          startDateObj.getFullYear(),
          startDateObj.getMonth(),
          startDateObj.getDate(),
        );
        if (startDateOnly < today) {
          const currentDateStr = now.toISOString().split("T")[0];
          throw new Error(
            `startDate "${context.startDate}" is in the past. The current date is ${currentDateStr}. Use today's date or a future date in ISO 8601 format (e.g., '${now.toISOString().split("T")[0]}T00:00:00Z' for today).`,
          );
        }

        // Normalize availability search boundaries to Brazil-local day starts.
        // This prevents UTC midnight inputs from shifting to the previous Brazil day.
        const endDateInput = context.endDate ?? undefined;
        const procedureName = context.procedureName ?? undefined;
        const extendToNextDay =
          !endDateInput && shouldIncludeNextDayAvailability(context.startDate);
        const effectiveEndDateInput = endDateInput
          ? endDateInput
          : extendToNextDay
            ? addDaysToIsoDate(extractIsoDatePart(context.startDate) ?? context.startDate, 1)
            : context.startDate;
        const requestedPeriod = context.period ?? undefined;
        const availabilityDayCount = getAvailabilitySearchDayCount(
          context.startDate,
          effectiveEndDateInput,
        );
        const requestedMaxSlots = MAX_FULL_DAY_AVAILABILITY_SLOTS;
        const queryPeriod = undefined;
        const normalizedStartDate =
          normalizeAvailabilityStartBoundary(context.startDate) || startDateObj.toISOString();
        const normalizedEndDate =
          normalizeAvailabilityEndBoundaryInclusive(effectiveEndDateInput) ||
          (effectiveEndDateInput ? new Date(effectiveEndDateInput).toISOString() : undefined);

        // If procedureName is provided, find the procedure
        let procedureId = undefined;
        let procedureInfo = null;
        if (procedureName) {
          const procedures = await ctx.runQuery(apiAny.procedures.listByDoctor, {
            doctorId,
          });
          const resolvedProcedure = resolveProcedureCandidates(procedures || [], procedureName);
          if (resolvedProcedure.status === "ambiguous") {
            return buildClarificationResult({
              clarificationType: "procedure",
              question: resolvedProcedure.question,
              choices: resolvedProcedure.ranked.slice(0, 3).map((candidate) => ({
                id: candidate.item._id,
                name: candidate.item.name,
                durationMinutes: candidate.item.durationMinutes,
              })),
              successPayload: {
                slots: [],
                ranges: [],
                count: 0,
                requestedPeriod: context.period ?? null,
                requestedPeriodSlots: [],
                requestedPeriodRanges: [],
                requestedPeriodCount: 0,
                doctor: { id: doctorId, name: doctor.name },
                procedure: null,
              },
            });
          }

          const procedure = resolvedProcedure.status === "match" ? resolvedProcedure.match : null;
          if (procedure) {
            procedureId = procedure._id;
            procedureInfo = {
              id: procedure._id,
              name: procedure.name,
              durationMinutes: procedure.durationMinutes,
            };
          }
        }

        // Log the call for debugging
        console.warn("[checkDoctorAvailabilityTool] Calling getDoctorAvailability with:", {
          clinicId,
          doctorId,
          doctorName: doctor.name,
          startDate: normalizedStartDate,
          endDate: normalizedEndDate,
          procedureId,
          period: queryPeriod,
          maxSlots: requestedMaxSlots,
        });

        // Use ctx.runQuery to get availability (use api directly since it's a public query)
        const slots = await ctx.runQuery(api.appointments.getDoctorAvailability, {
          clinicId,
          doctorId,
          startDate: normalizedStartDate,
          endDate: normalizedEndDate,
          procedureId,
          period: queryPeriod,
          maxSlots: requestedMaxSlots,
        });

        console.warn("[checkDoctorAvailabilityTool] Received slots:", {
          count: slots.length,
          firstSlot: slots[0] || null,
          lastSlot: slots[slots.length - 1] || null,
        });

        const presentedSlots = slots;
        const requestedPeriodSlots = requestedPeriod
          ? presentedSlots.filter((slot: { start: string; end: string }) =>
              slotMatchesRequestedPeriod(slot.start, requestedPeriod),
            )
          : presentedSlots;

        const formattedSlots = presentedSlots.map((slot: { start: string; end: string }) => {
          const slotDate = new Date(slot.start);
          const brazilLocal = getBrazilLocalDateParts(slotDate.getTime());

          return {
            ...slot,
            date: brazilLocal.date,
            dayOfWeek: brazilLocal.dayOfWeek,
            weekdayName: brazilLocal.weekdayName,
            time: slotDate.toLocaleTimeString("pt-BR", {
              hour: "2-digit",
              minute: "2-digit",
              timeZone: BRAZIL_TIME_ZONE,
            }),
            dateFormatted: slotDate.toLocaleDateString("pt-BR", {
              day: "2-digit",
              month: "2-digit",
              year: "numeric",
              timeZone: BRAZIL_TIME_ZONE,
            }),
          };
        });
        const availabilityRanges = buildAvailabilityRanges(presentedSlots, {
          requestedBrazilDate: extractIsoDatePart(context.startDate) ?? undefined,
          includeNextDayAvailability: extendToNextDay,
        });
        const requestedPeriodRanges = requestedPeriod
          ? buildAvailabilityRanges(requestedPeriodSlots, {
              requestedBrazilDate: extractIsoDatePart(context.startDate) ?? undefined,
              includeNextDayAvailability: extendToNextDay,
            })
          : availabilityRanges;

        // When a period is requested, only return filtered results to avoid confusing the AI
        const shouldReturnFilteredOnly = !!requestedPeriod;

        return {
          success: true,
          needsClarification: false,
          slots: shouldReturnFilteredOnly ? requestedPeriodSlots : formattedSlots,
          ranges: shouldReturnFilteredOnly ? requestedPeriodRanges : availabilityRanges,
          count: shouldReturnFilteredOnly ? requestedPeriodSlots.length : formattedSlots.length,
          requestedPeriod: requestedPeriod ?? null,
          requestedPeriodSlots,
          requestedPeriodRanges,
          requestedPeriodCount: requestedPeriodSlots.length,
          doctor: { id: doctorId, name: doctor.name },
          procedure: procedureInfo,
          note: `IMPORTANT: Days of week in JavaScript Date.getDay(): 0=domingo (Sunday), 1=segunda-feira (Monday), 2=terça-feira (Tuesday), 3=quarta-feira (Wednesday), 4=quinta-feira (Thursday), 5=sexta-feira (Friday), 6=sábado (Saturday). Each slot includes 'dayOfWeek' (0-6), 'weekdayName' (Portuguese name), and formatted date/time information. Prefer 'ranges[].displayText' when listing adjacent availability to the patient.${requestedPeriod ? " The 'slots' and 'ranges' fields already contain ONLY the requested period results." : ""}${extendToNextDay ? " Because it is already 20:00 or later in Brasilia for the requested date, the returned slots also include the next day." : ""}`,
        };
      } catch (error) {
        console.error("[checkDoctorAvailabilityTool] Error:", error);
        throw error;
      }
    },
  });

/**
 * List procedures for a doctor tool
 * Returns available medical procedures for a specific doctor
 */
export const listProceduresTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "list-procedures",
    description: `List available medical procedures for a specific doctor.

⚠️ CRITICAL - HOW TO USE THE RESULT:
The result contains a 'procedures' array. Each procedure has an 'id' field.
You MUST copy the EXACT value of 'id' to use as procedureId in other tools.

Example result:
{
  "success": true,
  "procedures": [{ "id": "k172ey7yh5hqy7f0m1syg7khvn7yq32s", "name": "Postata", ... }],
  "count": 1
}

To get procedureId: result.procedures[0].id = "k172ey7yh5hqy7f0m1syg7khvn7yq32s"
Then use this EXACT string in getAvailableDays, getAvailableHours, createAppointment.

⚠️ NEVER:
- Use placeholder IDs like "id_do_procedimento" or "procedureId"
- Make up IDs - always use the exact 'id' from the result
- Use patient ID as procedure ID - they are DIFFERENT tables!`,
    inputSchema: z.object({
      doctorName: z.string().describe("Name of the doctor to list procedures for"),
      procedureQuery: z
        .string()
        .optional()
        .nullable()
        .describe(
          "Optional procedure name mentioned by the patient. Use this to auto-select only when the match is unique; ask for clarification when ambiguous.",
        ),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        // Search for the doctor first
        const doctors = await ctx.runQuery(ConvexInternal.users.searchDoctors, {
          clinicId,
          query: context.doctorName.trim(),
        });

        if (!doctors || doctors.length === 0) {
          return {
            success: false,
            message: `No doctor found with name "${context.doctorName}".`,
            procedures: [],
          };
        }

        const resolvedDoctor = resolveDoctorCandidates(doctors || [], context.doctorName.trim());
        if (resolvedDoctor.status === "ambiguous") {
          return buildClarificationResult({
            clarificationType: "doctor",
            question: resolvedDoctor.question,
            choices: resolvedDoctor.ranked.slice(0, 3).map((candidate) => ({
              _id: candidate.item._id,
              name: candidate.item.name,
              specialties: candidate.item.specialties || [],
            })),
            successPayload: {
              procedures: [],
              count: 0,
              doctor: null,
            },
          });
        }

        if (resolvedDoctor.status !== "match") {
          return {
            success: false,
            message: `No doctor found with name "${context.doctorName}".`,
            procedures: [],
          };
        }

        const doctor = resolvedDoctor.match;

        // Get procedures for this doctor
        const procedures = await ctx.runQuery(apiAny.procedures.listByDoctor, {
          doctorId: doctor._id,
        });

        if (context.procedureQuery) {
          const resolvedProcedure = resolveProcedureCandidates(
            procedures || [],
            context.procedureQuery,
          );
          if (resolvedProcedure.status === "ambiguous") {
            return buildClarificationResult({
              clarificationType: "procedure",
              question: resolvedProcedure.question,
              choices: resolvedProcedure.ranked.slice(0, 3).map((candidate) => ({
                id: candidate.item._id,
                name: candidate.item.name,
                durationMinutes: candidate.item.durationMinutes,
                isTelemedicine: candidate.item.isTelemedicine || false,
                isInPerson: candidate.item.isInPerson || false,
              })),
              successPayload: {
                doctor: { id: doctor._id, name: doctor.name },
                procedures: procedures.map((p: any) => ({
                  id: p._id,
                  name: p.name,
                  durationMinutes: p.durationMinutes,
                  description: p.description,
                  price: p.price,
                  isTelemedicine: p.isTelemedicine || false,
                  isInPerson: p.isInPerson || false,
                })),
                count: procedures.length,
                selectedProcedure: null,
              },
            });
          }

          if (resolvedProcedure.status === "match") {
            return {
              success: true,
              needsClarification: false,
              doctor: { id: doctor._id, name: doctor.name },
              procedures: procedures.map((p: any) => ({
                id: p._id,
                name: p.name,
                durationMinutes: p.durationMinutes,
                description: p.description,
                price: p.price,
                isTelemedicine: p.isTelemedicine || false,
                isInPerson: p.isInPerson || false,
              })),
              selectedProcedure: {
                id: resolvedProcedure.match._id,
                name: resolvedProcedure.match.name,
                durationMinutes: resolvedProcedure.match.durationMinutes,
                isTelemedicine: resolvedProcedure.match.isTelemedicine || false,
                isInPerson: resolvedProcedure.match.isInPerson || false,
              },
              count: procedures.length,
              note: "Quando selectedProcedure estiver presente, use esse procedimento. Se needsClarification=true, faça a pergunta ao paciente antes de continuar.",
            };
          }
        }

        return {
          success: true,
          needsClarification: false,
          doctor: { id: doctor._id, name: doctor.name },
          procedures: procedures.map((p: any) => ({
            id: p._id,
            name: p.name,
            durationMinutes: p.durationMinutes,
            description: p.description,
            price: p.price,
            isTelemedicine: p.isTelemedicine || false,
            isInPerson: p.isInPerson || false,
          })),
          count: procedures.length,
          note: "⚠️ Copy the EXACT 'id' value (e.g., 'k172ey7yh5hqy7f0m1syg7khvn7yq32s') and use it as procedureId. Do NOT use patientId or placeholder strings.",
        };
      } catch (error) {
        console.error("[listProceduresTool] Error:", error);
        throw error;
      }
    },
  });

/**
 * Get available days tool
 * Returns available days for appointment scheduling (next 7 days)
 */
export const getAvailableDaysTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "get-available-days",
    description: `Get available days for appointment scheduling.
RETURNS: { success: true, dates: [{ date: "2026-01-12", weekdayName: "segunda-feira", formatted: "segunda-feira, 12/01" }], count: number, note: "Use one of these dates" }
IMPORTANT: Use the 'date' field (YYYY-MM-DD format) when calling getAvailableHours

⚠️ CRITICAL ID REQUIREMENTS:
- doctorId: MUST be the EXACT '_id' value from searchDoctors result (e.g., "j7fzw9x241qvrk1asdtwdfcyn7yq4rc")
- procedureId: MUST be the EXACT 'id' value from listProcedures result (e.g., "k172ey7yh5hqy7f0m1syg7khvn7yq32s")
- NEVER use placeholder IDs like "id_do_medico", "doctorId", or any invented value
- NEVER use patientId as procedureId - they are DIFFERENT IDs from DIFFERENT tables`,
    inputSchema: z.object({
      doctorId: z
        .string()
        .min(5, "doctorId must be a valid Convex ID")
        .describe(
          "The doctor ID - MUST be exact '_id' value from searchDoctors result (e.g., 'j7fzw9x241qvrk1asdtwdfcyn7yq4rc'). Do NOT use placeholders or invented IDs.",
        ),
      procedureId: z
        .string()
        .min(5, "procedureId must be a valid Convex ID")
        .describe(
          "The procedure ID - MUST be exact 'id' value from listProcedures result (e.g., 'k172ey7yh5hqy7f0m1syg7khvn7yq4rc'). Do NOT use placeholders or invented IDs.",
        ),
      isTelemedicine: z
        .boolean()
        .optional()
        .nullable()
        .describe(
          "Whether this is a telemedicine appointment. If not provided (null/undefined), returns days for both types.",
        ),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();
        const requestedMaxSlots = MAX_FULL_DAY_AVAILABILITY_SLOTS;

        // Validate IDs before proceeding
        validateConvexId(context.doctorId, "doctor");
        validateConvexId(context.procedureId, "procedure");

        let availableDates: string[] = [];

        // If isTelemedicine is provided, make single query
        if (context.isTelemedicine !== undefined && context.isTelemedicine !== null) {
          const result = await ctx.runQuery(api.appointments.getAvailableSlots, {
            clinicId,
            doctorId: context.doctorId as any,
            procedureId: context.procedureId as any,
            isTelemedicine: context.isTelemedicine,
            maxSlots: MAX_PRESENTED_AVAILABILITY_SLOTS,
          });

          availableDates = (result as any).dates || [];
        } else {
          // No preference - check procedure first to see what types it supports
          // Get procedure details to check supported types
          const procedure = await ctx.runQuery(api.procedures.getById, {
            id: context.procedureId as any,
            clinicId,
          });

          if (!procedure) {
            throw new Error("Procedimento não encontrado");
          }

          // Build queries based on what the procedure supports
          const queries: Promise<any>[] = [];

          if (procedure.isTelemedicine) {
            queries.push(
              ctx.runQuery(api.appointments.getAvailableSlots, {
                clinicId,
                doctorId: context.doctorId as any,
                procedureId: context.procedureId as any,
                isTelemedicine: true,
                maxSlots: MAX_PRESENTED_AVAILABILITY_SLOTS,
              }),
            );
          }

          if (procedure.isInPerson) {
            queries.push(
              ctx.runQuery(api.appointments.getAvailableSlots, {
                clinicId,
                doctorId: context.doctorId as any,
                procedureId: context.procedureId as any,
                isTelemedicine: false,
                maxSlots: MAX_PRESENTED_AVAILABILITY_SLOTS,
              }),
            );
          }

          if (queries.length === 0) {
            throw new Error("Procedimento não suporta nenhum tipo de atendimento");
          }

          // Execute queries in parallel
          const results = await Promise.all(queries);

          // Combine and deduplicate dates
          const allDates = new Set<string>();
          results.forEach((result: any) => {
            const dates = result?.dates || [];
            dates.forEach((date: string) => allDates.add(date));
          });

          availableDates = Array.from(allDates).sort();
        }

        // Format dates with Portuguese weekday names
        const weekdayNames = [
          "domingo",
          "segunda-feira",
          "terça-feira",
          "quarta-feira",
          "quinta-feira",
          "sexta-feira",
          "sábado",
        ];

        const formattedDates = availableDates.map((dateStr: string) => {
          const date = new Date(dateStr + "T00:00:00Z");
          const dayOfWeek = date.getUTCDay();
          const weekdayName = weekdayNames[dayOfWeek];
          const formattedDate = date.toLocaleDateString("pt-BR", {
            day: "2-digit",
            month: "2-digit",
          });

          return {
            date: dateStr,
            weekdayName,
            formatted: `${weekdayName}, ${formattedDate}`,
          };
        });

        return {
          success: true,
          dates: formattedDates,
          count: formattedDates.length,
          message:
            formattedDates.length > 0
              ? `Encontrei ${formattedDates.length} dia(s) com disponibilidade.`
              : "Nenhum horário disponível nos próximos dias para este médico e procedimento.",
          note: "Use one of these dates with getAvailableHours tool",
        };
      } catch (error: any) {
        console.error("[getAvailableDaysTool] Error:", error);

        // Check if it's an ID validation error
        if (
          error.message?.includes("ArgumentValidationError") ||
          error.message?.includes("does not match validator") ||
          error.message?.includes("doctorId") ||
          error.message?.includes("procedureId") ||
          error.message?.includes("from table `patients`") ||
          error.message?.includes("from table `procedures`")
        ) {
          // Check if the error specifically mentions patients table (common mistake)
          if (
            error.message?.includes("from table `patients`") &&
            error.message?.includes("procedures")
          ) {
            throw new Error(
              "ERRO CRÍTICO: Você está usando um ID de PACIENTE (tabela patients) como procedureId. " +
                "O procedureId DEVE vir do campo 'id' retornado por 'listProcedures' (tabela procedures). " +
                "AÇÃO OBRIGATÓRIA: " +
                "1. Chame 'listProcedures' NOVAMENTE com o nome do médico " +
                "2. Use APENAS o valor do campo 'id' do procedimento retornado " +
                "3. NUNCA use o patientId como procedureId - eles são IDs diferentes de tabelas diferentes.",
            );
          }

          throw new Error(
            "ERRO: ID inválido detectado. Você deve usar o ID EXATO retornado pelas ferramentas anteriores. " +
              "Para doctorId: use o valor exato do campo '_id' retornado por 'searchDoctors' (o ID real, não um exemplo). " +
              "Para procedureId: use o valor exato do campo 'id' retornado por 'listProcedures' (o ID real, não um exemplo). " +
              "⚠️ CRÍTICO: procedureId é da tabela PROCEDURES, NÃO da tabela PATIENTS. " +
              "NUNCA use IDs de exemplo como 'j123abc456def' ou 'k789xyz012abc' - esses são apenas exemplos de formato. " +
              "NUNCA invente IDs como '_id_do_dr_josefino' ou 'id_do_procedimento'. " +
              "NUNCA use o patientId como procedureId - eles são diferentes. " +
              "Chame 'searchDoctors' novamente para obter o doctorId REAL, e 'listProcedures' para obter o procedureId REAL. " +
              "Use APENAS os IDs que aparecem no resultado real das ferramentas.",
          );
        }

        throw new Error(`Falha ao obter dias disponíveis: ${error.message || error}`);
      }
    },
  });

/**
 * Get available hours tool
 * Returns available time slots for a specific day
 */
export const getAvailableHoursTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "get-available-hours",
    description: `Get available time slots for a specific day.
RETURNS: { success: true, slots: [{ start: "2026-01-12T14:00:00Z", end: "2026-01-12T15:00:00Z", formatted: "14:00 - 15:00", date: "2026-01-12", weekdayName: "segunda-feira", ... }], ranges: [{ displayText: "das 14:00 as 15:00", ... }], count: number, note: "Use one of these time slots" }
IMPORTANT: Use the 'start' field (ISO format) as startAt when calling createAppointment
IMPORTANT: This returns all available slots for the requested day. If the requested date is today and it is already 20:00 or later in Brasilia, it also includes next-day slots and marks them with their own date fields.
IMPORTANT: Use 'ranges[].displayText' when you need to present adjacent slots as a continuous window like "das 14:00 as 15:00", but always keep using the exact 'slots[].start' value when creating the appointment.

⚠️ CRITICAL ID REQUIREMENTS:
- doctorId: MUST be the EXACT '_id' value from searchDoctors result (e.g., "j7fzw9x241qvrk1asdtwdfcyn7yq4rc")
- procedureId: MUST be the EXACT 'id' value from listProcedures result (e.g., "k172ey7yh5hqy7f0m1syg7khvn7yq32s")
- NEVER use placeholder IDs like "id_do_medico", "doctorId", or any invented value
- NEVER use patientId as procedureId - they are DIFFERENT IDs from DIFFERENT tables`,
    inputSchema: z.object({
      doctorId: z
        .string()
        .min(5, "doctorId must be a valid Convex ID")
        .describe(
          "The doctor ID - MUST be exact '_id' value from searchDoctors result (e.g., 'j7fzw9x241qvrk1asdtwdfcyn7yq4rc'). Do NOT use placeholders or invented IDs.",
        ),
      procedureId: z
        .string()
        .min(5, "procedureId must be a valid Convex ID")
        .describe(
          "The procedure ID - MUST be exact 'id' value from listProcedures result (e.g., 'k172ey7yh5hqy7f0m1syg7khvn7yq4rc'). Do NOT use placeholders or invented IDs.",
        ),
      date: z.string().describe("Date in ISO format (YYYY-MM-DD)"),
      period: z
        .enum(["morning", "afternoon", "night"])
        .optional()
        .nullable()
        .describe(
          "Optional period filter. Use morning for 08:00-12:00, afternoon for 13:00-18:00, night for 19:00-22:00.",
        ),
      isTelemedicine: z
        .boolean()
        .optional()
        .nullable()
        .describe(
          "Whether this is a telemedicine appointment. If not provided (null/undefined), returns slots for both types.",
        ),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();
        const requestedMaxSlots = MAX_FULL_DAY_AVAILABILITY_SLOTS;
        const requestedBrazilDate = extractIsoDatePart(context.date) ?? context.date;
        const includeNextDayAvailability = shouldIncludeNextDayAvailability(context.date);
        const requestedPeriod = context.period ?? undefined;
        const nextBrazilDate = includeNextDayAvailability
          ? addDaysToIsoDate(requestedBrazilDate, 1)
          : null;
        const datesToQuery = nextBrazilDate
          ? [requestedBrazilDate, nextBrazilDate]
          : [requestedBrazilDate];

        // Validate IDs before proceeding
        validateConvexId(context.doctorId, "doctor");
        validateConvexId(context.procedureId, "procedure");

        let availableSlots: Array<{ start: string; end: string }> = [];

        // If isTelemedicine is provided, make single query
        if (context.isTelemedicine !== undefined && context.isTelemedicine !== null) {
          const results = await Promise.all(
            datesToQuery.map((date) =>
              ctx.runQuery(api.appointments.getAvailableSlots, {
                clinicId,
                doctorId: context.doctorId as any,
                procedureId: context.procedureId as any,
                date,
                isTelemedicine: context.isTelemedicine,
                maxSlots: requestedMaxSlots,
              }),
            ),
          );

          availableSlots = results
            .flatMap((slots) => (slots as any) || [])
            .sort((a, b) => new Date(a.start).getTime() - new Date(b.start).getTime());
        } else {
          // No preference - check procedure first to see what types it supports
          // Get procedure details to check supported types
          const procedure = await ctx.runQuery(api.procedures.getById, {
            id: context.procedureId as any,
            clinicId,
          });

          if (!procedure) {
            throw new Error("Procedimento não encontrado");
          }

          // Build queries based on what the procedure supports
          const queries: Promise<any>[] = [];

          for (const date of datesToQuery) {
            if (procedure.isTelemedicine) {
              queries.push(
                ctx.runQuery(api.appointments.getAvailableSlots, {
                  clinicId,
                  doctorId: context.doctorId as any,
                  procedureId: context.procedureId as any,
                  date,
                  isTelemedicine: true,
                  maxSlots: requestedMaxSlots,
                }),
              );
            }

            if (procedure.isInPerson) {
              queries.push(
                ctx.runQuery(api.appointments.getAvailableSlots, {
                  clinicId,
                  doctorId: context.doctorId as any,
                  procedureId: context.procedureId as any,
                  date,
                  isTelemedicine: false,
                  maxSlots: requestedMaxSlots,
                }),
              );
            }
          }

          if (queries.length === 0) {
            throw new Error("Procedimento não suporta nenhum tipo de atendimento");
          }

          // Execute queries in parallel
          const results = await Promise.all(queries);

          // Combine and deduplicate slots by start time
          const slotMap = new Map<string, { start: string; end: string }>();
          results.forEach((result: any) => {
            const slots = result || [];
            slots.forEach((slot: { start: string; end: string }) => {
              slotMap.set(slot.start, slot);
            });
          });

          availableSlots = Array.from(slotMap.values()).sort(
            (a, b) => new Date(a.start).getTime() - new Date(b.start).getTime(),
          );
        }

        const periodFilter = requestedPeriod;
        const requestedPeriodSlots = periodFilter
          ? availableSlots.filter((slot) => slotMatchesRequestedPeriod(slot.start, periodFilter))
          : availableSlots;

        // Format slots with Portuguese time formatting
        const formattedSlots = availableSlots.map((slot: { start: string; end: string }) => {
          const startDate = new Date(slot.start);
          const endDate = new Date(slot.end);
          const brazilLocal = getBrazilLocalDateParts(startDate.getTime());
          const isNextDayAvailability =
            includeNextDayAvailability && brazilLocal.date !== requestedBrazilDate;

          return {
            start: slot.start,
            end: slot.end,
            date: brazilLocal.date,
            dayOfWeek: brazilLocal.dayOfWeek,
            weekdayName: brazilLocal.weekdayName,
            dateFormatted: startDate.toLocaleDateString("pt-BR", {
              day: "2-digit",
              month: "2-digit",
              year: "numeric",
              timeZone: BRAZIL_TIME_ZONE,
            }),
            isNextDayAvailability,
            startTime: startDate.toLocaleTimeString("pt-BR", {
              hour: "2-digit",
              minute: "2-digit",
              timeZone: BRAZIL_TIME_ZONE,
            }),
            endTime: endDate.toLocaleTimeString("pt-BR", {
              hour: "2-digit",
              minute: "2-digit",
              timeZone: BRAZIL_TIME_ZONE,
            }),
            formatted: `${startDate.toLocaleTimeString("pt-BR", {
              hour: "2-digit",
              minute: "2-digit",
              timeZone: BRAZIL_TIME_ZONE,
            })} - ${endDate.toLocaleTimeString("pt-BR", {
              hour: "2-digit",
              minute: "2-digit",
              timeZone: BRAZIL_TIME_ZONE,
            })}`,
          };
        });
        const availabilityRanges = buildAvailabilityRanges(availableSlots, {
          requestedBrazilDate,
          includeNextDayAvailability,
        });
        const requestedPeriodRanges = periodFilter
          ? buildAvailabilityRanges(requestedPeriodSlots, {
              requestedBrazilDate,
              includeNextDayAvailability,
            })
          : availabilityRanges;

        const periodMessageMap: Record<string, string> = {
          morning: "no período da manhã",
          afternoon: "no período da tarde",
          night: "no período da noite",
        };
        const nextDaySlots = formattedSlots.filter((slot) => slot.isNextDayAvailability);
        const nextDayMessage =
          nextDaySlots.length > 0
            ? ` Como já passou das 20h em Brasília, incluí também ${nextDaySlots.length} horário(s) de ${nextDaySlots[0]?.dateFormatted}.`
            : "";

        return {
          success: true,
          slots: formattedSlots,
          ranges: availabilityRanges,
          count: formattedSlots.length,
          requestedPeriod: periodFilter ?? null,
          requestedPeriodSlots: periodFilter
            ? formattedSlots.filter((slot) => slotMatchesRequestedPeriod(slot.start, periodFilter))
            : formattedSlots,
          requestedPeriodRanges,
          requestedPeriodCount: requestedPeriodSlots.length,
          message:
            formattedSlots.length > 0
              ? `Encontrei ${formattedSlots.length} horário(s) disponíveis${nextDaySlots.length > 0 ? " nesta data e no próximo dia" : " para esta data"}${periodFilter ? `. Desses, ${requestedPeriodSlots.length} ficam ${periodMessageMap[periodFilter]}` : ""}.${nextDayMessage}`
              : `Nenhum horário disponível para esta data${periodFilter ? ` ${periodMessageMap[periodFilter]}` : ""}. Informe isso ao paciente e ofereça outra data.`,
          note: `Use one of these time slots with createAppointment tool. Each slot includes 'date', 'dateFormatted', 'dayOfWeek', 'weekdayName', and 'isNextDayAvailability' so you can tell whether it belongs to the requested day or the next day. Prefer 'ranges[].displayText' when answering with adjacent availability windows, but use the exact 'slots[].start' value when booking.${periodFilter ? " When 'period' is provided, 'slots'/'ranges' still contain the full-day context while 'requestedPeriodSlots'/'requestedPeriodRanges' contain the focused subset for that period." : ""}${nextDaySlots.length > 0 ? " Slots marked with isNextDayAvailability=true belong to the next day." : ""}`,
        };
      } catch (error: any) {
        console.error("[getAvailableHoursTool] Error:", error);

        // Check if it's an ID validation error
        if (
          error.message?.includes("ArgumentValidationError") ||
          error.message?.includes("does not match validator") ||
          error.message?.includes("doctorId") ||
          error.message?.includes("procedureId") ||
          error.message?.includes("from table `patients`") ||
          error.message?.includes("from table `procedures`")
        ) {
          // Check if the error specifically mentions patients table (common mistake)
          if (
            error.message?.includes("from table `patients`") &&
            error.message?.includes("procedures")
          ) {
            throw new Error(
              "ERRO CRÍTICO: Você está usando um ID de PACIENTE (tabela patients) como procedureId. " +
                "O procedureId DEVE vir do campo 'id' retornado por 'listProcedures' (tabela procedures). " +
                "AÇÃO OBRIGATÓRIA: " +
                "1. Chame 'listProcedures' NOVAMENTE com o nome do médico " +
                "2. Use APENAS o valor do campo 'id' do procedimento retornado " +
                "3. NUNCA use o patientId como procedureId - eles são IDs diferentes de tabelas diferentes.",
            );
          }

          throw new Error(
            "ERRO: ID inválido detectado. Você deve usar o ID EXATO retornado pelas ferramentas anteriores. " +
              "Para doctorId: use o valor exato do campo '_id' retornado por 'searchDoctors' (o ID real, não um exemplo). " +
              "Para procedureId: use o valor exato do campo 'id' retornado por 'listProcedures' (o ID real, não um exemplo). " +
              "⚠️ CRÍTICO: procedureId é da tabela PROCEDURES, NÃO da tabela PATIENTS. " +
              "NUNCA use IDs de exemplo como 'j123abc456def' ou 'k789xyz012abc' - esses são apenas exemplos de formato. " +
              "NUNCA invente IDs como '_id_do_dr_josefino' ou 'id_do_procedimento'. " +
              "NUNCA use o patientId como procedureId - eles são diferentes. " +
              "Chame 'searchDoctors' novamente para obter o doctorId REAL, e 'listProcedures' para obter o procedureId REAL. " +
              "Use APENAS os IDs que aparecem no resultado real das ferramentas.",
          );
        }

        throw new Error(`Falha ao obter horários disponíveis: ${error.message || error}`);
      }
    },
  });

/**
 * Create appointment tool
 * Creates a new appointment with full validation
 */
export const createAppointmentTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "create-appointment",
    description: `Create a new appointment OR reschedule an existing one. This is the correct tool for reagendar/remarcar consultas. Requires doctorId, procedureId, startAt (ISO string), isTelemedicine, and patientEmail (if telemedicine). Calculates endAt automatically from procedure duration. Use ONLY after confirming with patient.

RESCHEDULE RULE:
- To reschedule, first use listAppointments/getAppointment to identify the real existing appointment
- Then use getAvailableDays/getAvailableHours to confirm a real available slot
- Finally call this tool with the new slot and include appointmentId to update the existing appointment instead of creating a second one
- If appointmentId is omitted, this tool can still complete a reschedule when there is an appointment awaiting reschedule response for the current patient

⚠️ CRITICAL ID REQUIREMENTS - READ CAREFULLY:
- doctorId: MUST be the EXACT '_id' value from searchDoctors result (e.g., "j7fzw9x241qvrk1asdtwdfcyn7yq4rc")
- procedureId: MUST be the EXACT 'id' value from listProcedures result (e.g., "k172ey7yh5hqy7f0m1syg7khvn7yq32s")
- patientId: Use the patientId from the conversation context (different from procedureId!)

⚠️ NEVER DO THIS:
- NEVER use placeholder IDs like "id_do_medico", "doctorId", "id_do_procedimento"
- NEVER use patientId as procedureId - they are DIFFERENT IDs from DIFFERENT tables
- NEVER invent or guess IDs - always get them from tool results`,
    inputSchema: z.object({
      doctorId: z
        .string()
        .min(5, "doctorId must be a valid Convex ID")
        .describe(
          "The doctor ID - MUST be exact '_id' value from searchDoctors result (e.g., 'j7fzw9x241qvrk1asdtwdfcyn7yq4rc'). Do NOT use placeholders or invented IDs.",
        ),
      procedureId: z
        .string()
        .min(5, "procedureId must be a valid Convex ID")
        .describe(
          "The procedure ID - MUST be exact 'id' value from listProcedures result (e.g., 'k172ey7yh5hqy7f0m1syg7khvn7yq4rc'). Do NOT use patientId, placeholders, or invented IDs.",
        ),
      startAt: z
        .string()
        .describe(
          "Start time in ISO 8601 format. ⚠️ CRITICAL: Use the EXACT 'start' value from getAvailableHours results. Do NOT construct your own timestamp based on the time the user mentioned (e.g., if user says '9h' and getAvailableHours returns '2026-04-01T12:00:00Z', use '2026-04-01T12:00:00Z' - NOT '2026-04-01T09:00:00Z').",
        ),
      isTelemedicine: z.boolean().describe("Whether this is a telemedicine appointment"),
      patientEmail: z
        .string()
        .optional()
        .nullable()
        .describe("Patient email (REQUIRED if telemedicine)"),
      notes: z.string().optional().nullable().describe("Optional notes for the appointment"),
      patientId: z
        .string()
        .min(5, "patientId must be a valid Convex ID")
        .describe(
          "The patient ID from context. This is DIFFERENT from procedureId. Do NOT use procedureId here.",
        ),
      appointmentId: z
        .string()
        .optional()
        .nullable()
        .describe(
          "Existing appointment ID to update when this is a reschedule. If omitted, the tool also checks for a patient appointment awaiting reschedule response.",
        ),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();
        const patientEmail = context.patientEmail ?? undefined;
        const appointmentId = context.appointmentId ?? undefined;

        // Cross-validation: Check if procedureId is the same as patientId
        if (context.procedureId === context.patientId) {
          throw new Error(
            `❌ ERRO CRÍTICO: procedureId e patientId são IGUAIS!\n` +
              `Você passou: "${context.procedureId}" para AMBOS\n` +
              `Mas eles devem ser IDs DIFERENTES de tabelas DIFERENTES!\n\n` +
              `🔧 AÇÃO OBRIGATÓRIA:\n` +
              `1. patientId: use o ID do contexto do paciente\n` +
              `2. procedureId: chame 'listProcedures' e use o campo 'id' do procedimento\n` +
              `3. NUNCA use o mesmo valor para ambos`,
          );
        }

        // Validate all IDs with cross-validation
        validateConvexId(context.doctorId, "doctor");
        validateConvexId(context.procedureId, "procedure", { patientId: context.patientId });
        validateConvexId(context.patientId, "patient");

        // Validate patientId is provided
        if (!context.patientId) {
          throw new Error("ID do paciente é obrigatório");
        }

        // Validate procedureId is provided
        if (!context.procedureId) {
          throw new Error("ID do procedimento é obrigatório");
        }

        // Fetch procedure to get duration
        const procedure = await ctx.runQuery(apiAny.procedures.getById, {
          id: context.procedureId as any,
          clinicId,
        });

        if (!procedure) {
          throw new Error(
            `❌ Procedimento não encontrado.\n` +
              `procedureId: "${context.procedureId}"\n\n` +
              `🔧 AÇÃO: Chame 'listProcedures' novamente para obter um procedureId válido`,
          );
        }

        if (!procedure.isActive) {
          throw new Error("Procedimento não está ativo");
        }

        // Validate procedure belongs to doctor
        if (procedure.doctorId !== context.doctorId) {
          throw new Error(
            `❌ Procedimento não pertence ao médico selecionado.\n` +
              `doctorId usado: "${context.doctorId}"\n` +
              `doctorId do procedimento: "${procedure.doctorId}"\n\n` +
              `🔧 AÇÃO: Chame 'searchDoctors' e 'listProcedures' novamente para obter IDs corretos`,
          );
        }

        // Validate telemedicine flag matches procedure support
        if (context.isTelemedicine && !procedure.isTelemedicine) {
          throw new Error("Este procedimento não suporta telemedicina");
        }

        if (!context.isTelemedicine && !procedure.isInPerson) {
          throw new Error("Este procedimento não suporta atendimento presencial");
        }

        // Validate email if telemedicine
        if (context.isTelemedicine && !patientEmail) {
          throw new Error("E-mail é obrigatório para telemedicina");
        }

        // Parse startAt (sempre interpretar sem timezone como horário local de Brasília)
        const startAtTimestamp = parseStartAtToTimestamp(context.startAt);
        if (isNaN(startAtTimestamp)) {
          throw new Error("Formato de data/hora inválido");
        }

        // Validate date is not in the past
        const now = Date.now();
        if (startAtTimestamp < now) {
          throw new Error("Não é possível agendar no passado");
        }

        // IDEMPOTÊNCIA: Verificar se já existe agendamento idêntico ativo (evita duplicação em retries)
        const existingAppointments = await ctx.runQuery(
          ConvexInternal.appointments.listInternal || api.appointments.listInternal,
          {
            clinicId,
            patientId: context.patientId as any,
            startAt: startAtTimestamp,
            endAt: startAtTimestamp + 1,
            limit: 10,
          },
        );

        const duplicateAppointment = (existingAppointments?.items || []).find(
          (apt: any) =>
            !apt.deletedAt &&
            apt.status !== "cancelled" &&
            apt.doctorId === context.doctorId &&
            apt.procedureId === context.procedureId &&
            apt.startAt === startAtTimestamp,
        );

        if (duplicateAppointment) {
          const requestedDateFormatted = new Date(startAtTimestamp).toLocaleDateString("pt-BR", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
            timeZone: BRAZIL_TIME_ZONE,
          });
          const requestedTimeFormatted = new Date(startAtTimestamp).toLocaleTimeString("pt-BR", {
            hour: "2-digit",
            minute: "2-digit",
            timeZone: BRAZIL_TIME_ZONE,
          });

          console.warn(
            "[createAppointmentTool] Idempotency check: appointment already exists",
            duplicateAppointment._id,
          );

          return {
            success: true,
            appointmentId: duplicateAppointment._id,
            appointment: {
              id: duplicateAppointment._id,
              startAt: new Date(duplicateAppointment.startAt).toISOString(),
              endAt: new Date(duplicateAppointment.endAt).toISOString(),
              status: duplicateAppointment.status,
              doctor: duplicateAppointment.doctor,
              procedure: duplicateAppointment.procedure,
            },
            message: `Agendamento confirmado: ${requestedDateFormatted} às ${requestedTimeFormatted}.`,
            idempotent: true,
          };
        }

        let appointmentToReschedule: any = null;

        if (appointmentId) {
          const existingAppointments = (await ctx.runQuery(
            ConvexInternal.appointments.listInternal || api.appointments.listInternal,
            {
              clinicId,
              patientId: context.patientId as any,
              limit: 20,
            },
          )) as { items?: any[] };

          appointmentToReschedule = (existingAppointments.items || []).find(
            (appointment: any) => appointment._id === appointmentId,
          );

          if (!appointmentToReschedule) {
            throw new Error(`Appointment not found: ${appointmentId}`);
          }

          if (appointmentToReschedule.patientId !== context.patientId) {
            throw new Error("O appointmentId informado não pertence ao paciente atual");
          }
        } else {
          const pendingReschedules = (await ctx.runQuery(
            ConvexInternal.appointments.listInternal || api.appointments.listInternal,
            {
              clinicId,
              patientId: context.patientId as any,
              statuses: ["pending", "confirmed"],
              limit: 20,
            },
          )) as { items?: any[] };

          appointmentToReschedule = (pendingReschedules.items || [])
            .filter(
              (appointment) =>
                !appointment.deletedAt &&
                appointment.rescheduleStatus === "awaiting_response" &&
                appointment.startAt >= now,
            )
            .sort((a, b) => a.startAt - b.startAt)[0];
        }

        // BLOQUEIO ESTRITO: startAt precisa estar exatamente na lista de horários disponíveis
        const requestedDate = getBrazilIsoDateFromTimestamp(startAtTimestamp);

        console.warn("[createAppointmentTool] Checking slot availability:", {
          requestedDate,
          startAtTimestamp,
          startAtLocal: new Date(startAtTimestamp).toLocaleString("pt-BR", {
            timeZone: BRAZIL_TIME_ZONE,
          }),
          doctorId: context.doctorId,
          procedureId: context.procedureId,
          isTelemedicine: context.isTelemedicine,
          patientId: context.patientId,
        });

        const availableSlots = (await ctx.runQuery(api.appointments.getAvailableSlots, {
          clinicId,
          doctorId: context.doctorId as any,
          procedureId: context.procedureId as any,
          date: requestedDate,
          isTelemedicine: context.isTelemedicine,
          maxSlots: 200,
        })) as Array<{ start: string; end: string }>;

        console.warn("[createAppointmentTool] Available slots found:", {
          count: availableSlots.length,
          isTelemedicine: context.isTelemedicine,
          firstSlot: availableSlots[0] || null,
          lastSlot: availableSlots[availableSlots.length - 1] || null,
        });

        const matchingSlot = availableSlots.find(
          (slot) => new Date(slot.start).getTime() === startAtTimestamp,
        );

        if (!matchingSlot) {
          const alternatives = formatAvailabilityRangesForPatient(
            buildAvailabilityRanges(availableSlots, { requestedBrazilDate: requestedDate }),
          );

          const requestedDateFormatted = new Date(startAtTimestamp).toLocaleDateString("pt-BR", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
            timeZone: BRAZIL_TIME_ZONE,
          });

          const requestedTimeFormatted = new Date(startAtTimestamp).toLocaleTimeString("pt-BR", {
            hour: "2-digit",
            minute: "2-digit",
            timeZone: BRAZIL_TIME_ZONE,
          });

          console.error("[createAppointmentTool] SLOT UNAVAILABLE - strict check failed:", {
            requestedDate,
            requestedTime: requestedTimeFormatted,
            requestedTimestamp: startAtTimestamp,
            availableSlotsCount: availableSlots.length,
            isTelemedicine: context.isTelemedicine,
          });

          const error = new Error(
            alternatives.length > 0
              ? `SLOT_UNAVAILABLE: O horário solicitado (${requestedTimeFormatted}) não está mais disponível para ${requestedDateFormatted}. Horários disponíveis: ${alternatives}. Escolha um desses horários.`
              : `SLOT_UNAVAILABLE: Não há horários disponíveis para ${requestedDateFormatted}${context.isTelemedicine ? " em telemedicina" : " presencial"}. Escolha outro horário ou outra data.`,
          );
          (error as any).isFunctionalError = true;
          throw error;
        }

        console.warn("[createAppointmentTool] Slot validated successfully:", {
          matchingSlot,
          isTelemedicine: context.isTelemedicine,
        });

        const endAtTimestamp = new Date(matchingSlot.end).getTime();

        if (appointmentToReschedule) {
          const updatedAppointment = await ctx.runMutation(api.appointments.update, {
            id: appointmentToReschedule._id,
            clinicId,
            doctorId: context.doctorId as any,
            startAt: startAtTimestamp,
            endAt: endAtTimestamp,
            procedureId: context.procedureId as any,
            procedure: procedure.name,
            isTelemedicine: context.isTelemedicine,
            patientEmail,
            notes: context.notes || undefined,
            rescheduleStatus: "rescheduled" as const,
          });

          return {
            success: true,
            appointmentId: updatedAppointment._id,
            appointment: {
              id: updatedAppointment._id,
              startAt: new Date(updatedAppointment.startAt).toISOString(),
              endAt: new Date(updatedAppointment.endAt).toISOString(),
              status: updatedAppointment.status,
              doctor: updatedAppointment.doctor,
              procedure: updatedAppointment.procedure,
            },
            message: "Agendamento reagendado com sucesso!",
            rescheduled: true,
          };
        }

        // Create appointment
        const appointment = await ctx.runMutation(api.appointments.create, {
          clinicId,
          patientId: context.patientId as any,
          doctorId: context.doctorId as any,
          startAt: startAtTimestamp,
          endAt: endAtTimestamp,
          procedure: procedure.name,
          procedureId: context.procedureId as any,
          isTelemedicine: context.isTelemedicine,
          patientEmail,
          notes: context.notes || undefined,
          status: "pending" as const,
        });

        return {
          success: true,
          appointmentId: appointment._id,
          appointment: {
            id: appointment._id,
            startAt: new Date(appointment.startAt).toISOString(),
            endAt: new Date(appointment.endAt).toISOString(),
            status: appointment.status,
            doctor: appointment.doctor,
            procedure: appointment.procedure,
          },
          message: "Agendamento criado com sucesso!",
        };
      } catch (error: any) {
        console.error("[createAppointmentTool] Error:", error);

        // Check if it's an ID validation error
        if (
          error.message?.includes("ArgumentValidationError") ||
          error.message?.includes("does not match validator") ||
          error.message?.includes("doctorId") ||
          error.message?.includes("procedureId") ||
          error.message?.includes("from table `patients`") ||
          error.message?.includes("from table `procedures`")
        ) {
          // Check if the error specifically mentions patients table (common mistake)
          if (
            error.message?.includes("from table `patients`") &&
            error.message?.includes("procedures")
          ) {
            throw new Error(
              "ERRO CRÍTICO: Você está usando um ID de PACIENTE (tabela patients) como procedureId. " +
                "O procedureId DEVE vir do campo 'id' retornado por 'listProcedures' (tabela procedures). " +
                "AÇÃO OBRIGATÓRIA: " +
                "1. Chame 'listProcedures' NOVAMENTE com o nome do médico " +
                "2. Use APENAS o valor do campo 'id' do procedimento retornado (exemplo: se listProcedures retorna { id: 'k123...', name: 'Consulta' }, use 'k123...' como procedureId) " +
                "3. NUNCA use o patientId como procedureId - eles são IDs diferentes de tabelas diferentes. " +
                "4. O patientId vem do contexto do paciente, o procedureId vem de listProcedures.",
            );
          }

          throw new Error(
            "ERRO: ID inválido detectado. Você deve usar o ID EXATO retornado pelas ferramentas anteriores. " +
              "Para doctorId: use o valor exato do campo '_id' retornado por 'searchDoctors' (o ID real, não um exemplo). " +
              "Para procedureId: use o valor exato do campo 'id' retornado por 'listProcedures' (o ID real, não um exemplo). " +
              "⚠️ CRÍTICO: procedureId é da tabela PROCEDURES, NÃO da tabela PATIENTS. " +
              "NUNCA use IDs de exemplo como 'j123abc456def' ou 'k789xyz012abc' - esses são apenas exemplos de formato. " +
              "NUNCA invente IDs como '_id_do_dr_josefino' ou 'id_do_procedimento'. " +
              "NUNCA use o patientId como procedureId - eles são diferentes. " +
              "Chame 'searchDoctors' novamente para obter o doctorId REAL, e 'listProcedures' para obter o procedureId REAL. " +
              "Use APENAS os IDs que aparecem no resultado real das ferramentas.",
          );
        }

        // Convert common errors to user-friendly Portuguese messages
        if (error.message?.includes("rate limit") || error.message?.includes("rateLimit")) {
          throw new Error("Muitas tentativas. Aguarde um momento.");
        }

        if (error.message?.includes("overlap") || error.message?.includes("ocupado")) {
          throw new Error("Este horário já está ocupado. Escolha outro.");
        }

        if (error.message?.includes("não encontrado") || error.message?.includes("not found")) {
          throw new Error(error.message);
        }

        // Return the error message as-is if it's already in Portuguese, otherwise provide generic message
        throw new Error(error.message || "Erro ao criar agendamento. Tente novamente.");
      }
    },
  });

/**
 * Get patient by phone tool
 * Finds patient record using their phone number
 */
export const getPatientByPhoneTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "get-patient-by-phone",
    description: "Find patient information using their phone number",
    inputSchema: z.object({
      phone: z.string().describe("Patient phone number"),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        const patient = await ctx.runQuery(ConvexInternal.patients.getByPhoneInternal, {
          clinicId,
          phone: context.phone,
        });

        return {
          found: !!patient,
          patient,
        };
      } catch (error) {
        console.error("[getPatientByPhoneTool] Error:", error);
        throw error;
      }
    },
  });

/**
 * Save patient image tool
 * Saves an image (insurance card, ID card, or referral) to the patient's record
 * For insurance_card: requires 2 images (front and back)
 */
export const savePatientImageTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "save-patient-image",
    description: `Salva imagem do paciente (carteirinha, documento ou encaminhamento).

USE QUANDO: Paciente enviou imagem E você tem o mediaStorageId do contexto.
NÃO CHAME analyzeDocument ANTES - salve direto, a imagem já foi identificada.

IMPORTANTE: Use mediaStorageId do contexto (currentMessage.mediaStorageId ou recentImages[].mediaStorageId).
SEMPRE envie também messageId do contexto para rastreio correto da coleta.
NÃO invente IDs - use EXATAMENTE o Storage ID fornecido no contexto.

CARTEIRINHA (insurance_card): salva automaticamente como frente (1ª) ou verso (2ª).

RETORNA: { success, imageType, side, guidance, isComplete }`,
    inputSchema: z.object({
      patientId: z.string().describe("Patient ID do contexto"),
      messageId: z
        .string()
        .optional()
        .nullable()
        .describe("Message ID do contexto (recomendado para idempotência da coleta)"),
      mediaStorageId: z
        .string()
        .describe("Storage ID EXATO do contexto (ex: kg2ca4kyesr5je0687a6j6xqh581ve7t)"),
      imageType: z
        .enum(["insurance_card", "id_card", "referral"])
        .describe("Tipo identificado: insurance_card, id_card, ou referral"),
    }),
    execute: async ({ context }) => {
      try {
        initConvex();

        const storageId = context.mediaStorageId;
        const messageId = context.messageId;
        const hasValidMessageId =
          typeof messageId === "string" &&
          ID_PREFIXES.message.some((prefix) => messageId.startsWith(prefix));

        if (!storageId) {
          return {
            success: false,
            error: "No storage ID provided",
            guidance: "Forneça mediaStorageId para salvar a imagem. Use o Storage ID do contexto.",
          };
        }

        // Get image URL for reference
        const imageUrl = await ctx.storage.getUrl(storageId);

        let identifiedTypeFromMessage: "insurance_card" | "id_card" | "referral" | "other" | null =
          null;

        if (hasValidMessageId && ConvexInternal?.whatsappInternal?.getMessage) {
          try {
            const sourceMessage = await ctx.runQuery(ConvexInternal.whatsappInternal.getMessage, {
              id: messageId as any,
            });

            const detectedType = sourceMessage?.extractedData?.imageIdentification?.type;
            if (
              detectedType === "insurance_card" ||
              detectedType === "id_card" ||
              detectedType === "referral" ||
              detectedType === "other"
            ) {
              identifiedTypeFromMessage = detectedType;
            }
          } catch (err) {
            console.warn(
              "[savePatientImageTool] Could not read source message identification:",
              err,
            );
          }
        }

        if (identifiedTypeFromMessage === "other") {
          return {
            success: false,
            error: "IMAGE_TYPE_UNCERTAIN",
            guidance:
              "A imagem foi identificada como tipo indefinido (other). Não salvei automaticamente. Pergunte ao paciente se é carteirinha, documento ou encaminhamento.",
          };
        }

        if (identifiedTypeFromMessage && identifiedTypeFromMessage !== context.imageType) {
          return {
            success: false,
            error: "IMAGE_TYPE_MISMATCH",
            detectedType: identifiedTypeFromMessage,
            expectedImageType: identifiedTypeFromMessage,
            guidance: `Tipo informado (${context.imageType}) diverge do tipo detectado (${identifiedTypeFromMessage}). Use o tipo detectado para salvar.`,
          };
        }

        const defaultResult = {
          success: false,
          receivedCount: 1,
          requiredCount: 1,
          isComplete: true,
          hasPendingRequest: false,
        };
        let collectionResult: any = { ...defaultResult };

        // Mark data collection as received only when we have a real messageId.
        // Using storageId here breaks validator (expects messages table ID).
        if (hasValidMessageId) {
          try {
            const result = await ctx.runMutation(
              ConvexInternal.checkin.markDataCollectionReceived,
              {
                patientId: context.patientId as any,
                type: context.imageType,
                messageId: messageId as any,
              },
            );
            collectionResult = {
              ...defaultResult,
              ...result,
              hasPendingRequest: result.success !== false,
            };
            console.log("[savePatientImageTool] Collection result:", collectionResult);
          } catch (err) {
            console.warn("[savePatientImageTool] Could not mark request as received:", err);
          }
        } else {
          console.warn(
            "[savePatientImageTool] valid messageId not provided; skipping dataCollection idempotency tracking",
          );
        }

        // If already counted (duplicate), return early
        if (collectionResult.alreadyCounted) {
          return {
            success: true,
            imageType: context.imageType,
            alreadyCounted: true,
            receivedCount: collectionResult.receivedCount,
            requiredCount: collectionResult.requiredCount,
            isComplete: collectionResult.isComplete,
            guidance: collectionResult.isComplete
              ? "Esta imagem já foi processada anteriormente."
              : "Esta imagem já foi processada. Aguarde a próxima.",
          };
        }

        // Determine side for insurance_card
        let side: "front" | "back" | undefined;
        if (context.imageType === "insurance_card") {
          // First image is front (receivedCount=1), second is back (receivedCount=2)
          side = collectionResult.receivedCount === 1 ? "front" : "back";
        }

        // Save to patient record
        const result = await ctx.runMutation(ConvexInternal.patients.savePatientImage, {
          patientId: context.patientId as any,
          imageType: context.imageType,
          storageId: storageId,
          side,
        });

        // Build guidance message for the agent
        let guidance = "";
        if (context.imageType === "insurance_card") {
          if (!collectionResult.hasPendingRequest) {
            // No pending request - just confirm save (could be front or back, we don't know)
            guidance = "Carteirinha salva com sucesso!";
          } else if (collectionResult.isComplete) {
            guidance = "Frente e verso da carteirinha salvos com sucesso! Coleta concluída.";
          } else {
            guidance =
              "Frente da carteirinha recebida! Por favor, envie também o VERSO da carteirinha.";
          }
        } else {
          guidance = `${context.imageType === "id_card" ? "Documento" : "Encaminhamento"} salvo com sucesso!`;
        }

        return {
          success: true,
          imageType: context.imageType,
          side: result.side,
          url: result.url || imageUrl,
          imageUrl,
          receivedCount: collectionResult.receivedCount || 1,
          requiredCount: collectionResult.requiredCount || 1,
          isComplete:
            collectionResult.isComplete !== undefined ? collectionResult.isComplete : true,
          guidance,
        };
      } catch (error) {
        console.error("[savePatientImageTool] Error:", error);
        throw error;
      }
    },
  });

/**
 * Update patient data tool
 * Allows the AI agent to update patient information
 *
 * IMPORTANT: This tool should be called IMMEDIATELY when patient provides data.
 * Do NOT wait for confirmation - auto-save as soon as data is collected.
 */
const PATIENT_UPDATE_FIELD_SCHEMAS = {
  name: z.string().optional().nullable(),
  email: z.string().optional().nullable(),
  phone: z.string().optional().nullable(),
  cpf: z.string().optional().nullable(),
  dateOfBirth: z.union([z.string(), z.number()]).optional().nullable(),
  gender: z.enum(["male", "female", "other"]).optional().nullable(),
  address: z.string().optional().nullable(),
  city: z.string().optional().nullable(),
  state: z.string().optional().nullable(),
  zip: z.string().optional().nullable(),
  country: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
  tags: z.array(z.string()).optional().nullable(),
  paymentType: z.enum(["insurance", "private"]).optional().nullable(),
  insurance: z.string().optional().nullable(),
};

const PATIENT_UPDATE_FIELDS = Object.keys(PATIENT_UPDATE_FIELD_SCHEMAS) as Array<
  keyof typeof PATIENT_UPDATE_FIELD_SCHEMAS
>;

const updatePatientDataInputSchema = z
  .object({
    patientId: z
      .string()
      .min(5, "patientId must be a valid Convex ID")
      .describe("The patient ID to update"),
    updates: z
      .record(z.string(), z.any())
      .optional()
      .describe(
        'Object with ONLY the fields to update. Example: { "dateOfBirth": "2000-07-11" } - do NOT include fields you don\'t want to change.',
      ),
    ...PATIENT_UPDATE_FIELD_SCHEMAS,
  })
  .superRefine((value, ctx) => {
    const hasNestedUpdates =
      value.updates !== undefined &&
      value.updates !== null &&
      typeof value.updates === "object" &&
      Object.keys(value.updates).length > 0;
    const hasFlatUpdates = PATIENT_UPDATE_FIELDS.some((field) => value[field] !== undefined);

    if (!hasNestedUpdates && !hasFlatUpdates) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["updates"],
        message: "Required",
      });
    }
  });

export const updatePatientDataTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "update-patient-data",
    description: `Update patient information in the database.

⚠️ CRITICAL - ONLY INCLUDE FIELDS YOU WANT TO UPDATE:
- Include ONLY the fields that have NEW values to save
- Do NOT include fields with null, empty strings, or placeholder values
- OMIT fields you don't want to change (don't pass them at all)

✅ CORRECT EXAMPLE:
{ "patientId": "k179...", "updates": { "dateOfBirth": "2000-07-11" } }

❌ WRONG EXAMPLE (causes validation error):
{ "patientId": "k179...", "updates": { "dateOfBirth": "2000-07-11", "name": null, "email": null, ... } }

Supported fields: name, email, phone, cpf, dateOfBirth (YYYY-MM-DD), gender (male/female/other), address, city, state, zip, country, notes, tags, paymentType (insurance/private), insurance (company name like "Unimed", "Bradesco")

This tool accepts either the explicit format with { "updates": { ... } } or flat fields at the top level, but always prefer the explicit format.

AUTO-SAVE: Call this IMMEDIATELY when the patient provides ANY data - do NOT wait for confirmation.`,
    inputSchema: updatePatientDataInputSchema,
    execute: async ({ context }) => {
      try {
        initConvex();

        const rawUpdates = {
          ...(context.updates && typeof context.updates === "object" ? context.updates : {}),
        } as Record<string, unknown>;
        for (const key of PATIENT_UPDATE_FIELDS) {
          if (rawUpdates[key] === undefined && context[key] !== undefined) {
            rawUpdates[key] = context[key];
          }
        }

        const updates: any = {};
        const validFields = PATIENT_UPDATE_FIELDS;

        const validGenderValues = ["male", "female", "other"];
        const validPaymentTypeValues = ["insurance", "private"];

        for (const key of validFields) {
          const value = (rawUpdates as any)[key];
          if (value !== undefined && value !== null && value !== "") {
            if (key === "gender" && !validGenderValues.includes(value)) {
              throw new Error(
                `Invalid gender value: "${value}". Must be one of: ${validGenderValues.join(", ")}`,
              );
            }
            if (key === "paymentType" && !validPaymentTypeValues.includes(value)) {
              throw new Error(
                `Invalid paymentType value: "${value}". Must be one of: ${validPaymentTypeValues.join(", ")}`,
              );
            }
            updates[key] = value;
          }
        }

        if (updates.dateOfBirth !== undefined) {
          const timestamp =
            typeof updates.dateOfBirth === "number"
              ? updates.dateOfBirth
              : new Date(updates.dateOfBirth).getTime();
          if (isNaN(timestamp)) {
            throw new Error("Invalid date format. Use YYYY-MM-DD");
          }
          updates.dateOfBirth = timestamp;
        }

        if (Object.keys(updates).length === 0) {
          throw new Error(
            "No valid fields to update. Provide at least one of: " + validFields.join(", "),
          );
        }

        await ctx.runMutation(ConvexInternal.patients.updatePatientDataInternal, {
          patientId: context.patientId as any,
          updates,
        });

        return {
          success: true,
          message: "Dados do paciente atualizados com sucesso",
          updatedFields: Object.keys(updates),
        };
      } catch (error) {
        console.error("[updatePatientDataTool] Error:", error);
        throw error;
      }
    },
  });
