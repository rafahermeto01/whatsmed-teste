"use node";

import { agentCache, clearAgentCache } from "./agentCache.js";
import { createClinicAgent, isWithinActiveHours, detectEscalation } from "./agents.js";
import { createConvexTools } from "./tools.js";
import {
  campaignExecutionSchema,
  reminderWorkflowSchema as reminderWorkflow,
  personalizeMessage,
  hoursToMs,
  formatDate,
  formatTime,
} from "./workflows.js";

/**
 * Get or create a clinic-specific agent
 * Caches agents to avoid re-initialization
 * @param clinicId - Clinic ID
 * @param settings - AI settings
 * @param ctx - Convex context
 * @param systemPromptOverride - Optional interpolated system prompt
 * @param context - Variable context for interpolation
 * @param toolProfile - Optional tool profile from classifier (e.g., "availability", "booking")
 * @param allowedTools - Optional explicit list of allowed tool names
 */
export function getClinicAgent(
  clinicId: string,
  settings: any,
  ctx: any,
  systemPromptOverride?: string,
  context?: any,
  toolProfile?: string,
  allowedTools?: string[],
) {
  // Cache key includes toolProfile for classifier-based agents
  const ci = settings.customInstructions ?? "";
  const ciSig =
    ci.length +
    "-" +
    (ci.split("").reduce((a: number, b: string) => a + b.charCodeAt(0), 0) % 10000);
  const profileKey = toolProfile || "default";
  const allowedSig = allowedTools ? `-${allowedTools.length}tools` : "";
  const cacheKey = `${clinicId}-${settings.updatedAt || 0}-v13-ci${ciSig}-${profileKey}${allowedSig}`;

  const hasCurrentImage = Boolean(context?.currentMessage?.hasImage);

  if (!systemPromptOverride && !hasCurrentImage && agentCache.has(cacheKey)) {
    return agentCache.get(cacheKey);
  }

  // Create tools and filter if needed
  const allTools = createConvexTools(ctx, clinicId);
  const tools = allowedTools
    ? Object.fromEntries(Object.entries(allTools).filter(([name]) => allowedTools.includes(name)))
    : allTools;

  console.warn(
    `[getClinicAgent] Created agent with ${Object.keys(tools).length} tools (profile: ${profileKey})`,
  );

  const agent = createClinicAgent(settings, tools, systemPromptOverride, context);

  if (!systemPromptOverride && !hasCurrentImage) {
    agentCache.set(cacheKey, agent);
    if (agentCache.size > 100) {
      const keysArray = Array.from(agentCache.keys());
      agentCache.delete(keysArray[0]);
    }
  }

  return agent;
}

export {
  createClinicAgent,
  createReminderAgent,
  isWithinActiveHours,
  detectEscalation,
} from "./agents.js";
export { clearAgentCache };
export { createConvexTools } from "./tools.js";
export {
  campaignExecutionSchema,
  reminderWorkflow,
  personalizeMessage,
  hoursToMs,
  formatDate,
  formatTime,
} from "./workflows.js";

// Export agent utilities as object
export const agents = {
  isWithinActiveHours,
  detectEscalation,
};

// Export workflow utilities as object
export const workflows = {
  campaignExecutionSchema,
  reminderWorkflow,
  personalizeMessage,
  hoursToMs,
  formatDate,
  formatTime,
};
