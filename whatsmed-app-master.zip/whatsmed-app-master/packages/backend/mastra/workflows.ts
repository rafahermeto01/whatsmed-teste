"use node";

/**
 * Mastra workflows for campaign and reminder execution
 * Simplified implementation to avoid bundling issues with Mastra submodules
 * The workflows are defined here and executed via automation actions
 */

import { z } from "zod";

/**
 * Campaign execution workflow schema
 * Orchestrates multi-step campaign delivery with delays between steps
 */
export const campaignExecutionSchema = {
  id: "campaign-execution",
  description: "Execute multi-step campaign with automated delays",

  inputSchema: z.object({
    campaignId: z.string(),
    clinicId: z.string(),
    patientId: z.string(),
    steps: z.array(
      z.object({
        order: z.number(),
        delayHours: z.number(),
        channel: z.enum(["whatsapp", "sms", "email", "call"]),
        message: z.string(),
      }),
    ),
    context: z
      .object({
        patientName: z.string().optional(),
        patientPhone: z.string().optional(),
        appointmentDate: z.string().optional(),
        appointmentTime: z.string().optional(),
        clinicName: z.string().optional(),
        doctorName: z.string().optional(),
      })
      .optional(),
  }),
};

/**
 * Reminder workflow schema
 * Handles single-step reminder with personalization
 */
export const reminderWorkflowSchema = {
  id: "reminder-sending",
  description: "Send personalized reminder to patient",

  inputSchema: z.object({
    reminderType: z.enum([
      "sevenDay",
      "twentyFourHour",
      "oneHour",
      "postConsultation",
      "noShowRecovery",
    ]),
    clinicId: z.string(),
    patientId: z.string(),
    appointmentId: z.string().optional(),
    messageTemplate: z.string(),
    channel: z.enum(["whatsapp", "sms", "email", "call"]),
    context: z
      .object({
        patientName: z.string().optional(),
        patientPhone: z.string().optional(),
        appointmentDate: z.string().optional(),
        appointmentTime: z.string().optional(),
        clinicName: z.string().optional(),
        doctorName: z.string().optional(),
      })
      .optional(),
  }),
};

/**
 * Personalize message with template variables
 * Replaces {{variable}} placeholders with actual values
 * Supports dot notation (e.g., {{patient.name}})
 */
export function personalizeMessage(template: string, context: Record<string, any>): string {
  if (!template) return "";

  // Helper to resolve dot notation
  const resolvePath = (obj: any, path: string): string => {
    return path.split(".").reduce((acc, part) => {
      return acc && acc[part] !== undefined ? acc[part] : undefined;
    }, obj);
  };

  // Replace {{path.to.variable}}
  return template.replace(/{{([\w.]+)}}/g, (match, path) => {
    // 1. Try resolving exact path in context (e.g., "patient.name")
    const value = resolvePath(context, path);
    if (value !== undefined && value !== null) {
      return String(value);
    }

    // 2. Backward compatibility for snake_case variables (e.g., "patient_name")
    // Map old vars to new context structure if needed
    const legacyMap: Record<string, string> = {
      patient_name: "patient.name",
      appointment_date: "appointment.date",
      appointment_time: "appointment.time",
      clinic_name: "clinic.name",
      doctor_name: "doctor.name",
    };

    if (legacyMap[path]) {
      const legacyValue = resolvePath(context, legacyMap[path]);
      if (legacyValue !== undefined && legacyValue !== null) {
        return String(legacyValue);
      }
    }

    // Return original placeholder if not found (graceful handling)
    return match;
  });
}

/**
 * Calculate delay in milliseconds from hours
 */
export function hoursToMs(hours: number): number {
  return hours * 60 * 60 * 1000;
}

/**
 * Format date for Portuguese locale
 */
export function formatDate(date: Date | number): string {
  const d = typeof date === "number" ? new Date(date) : date;
  return d.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
}

/**
 * Format time for Portuguese locale
 */
export function formatTime(date: Date | number): string {
  const d = typeof date === "number" ? new Date(date) : date;
  return d.toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

export const reminderWorkflow = reminderWorkflowSchema;
