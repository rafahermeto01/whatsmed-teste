# Mastra AI Integration for WhatsMed

This document describes the integration of Mastra AI agents with Convex backend for intelligent automation.

## Overview

Mastra is a TypeScript framework for building AI applications with agents, workflows, RAG, and integrations. In WhatsMed, it's used to:

1. Create clinic-specific AI assistants with custom personas
2. Execute multi-step campaigns with intelligent delays
3. Generate personalized reminder messages
4. Handle escalation detection for emergency situations
5. Provide fallback models for resilience

## Architecture

```
Frontend UI
    ↓
Convex Backend (Authentication, RBAC, Persistence)
    ↓
Mastra Module (Agents, Workflows, Tools)
    ↓
AI Providers (OpenAI, Anthropic, Google)
```

### Key Components

- **`mastra/index.ts`**: Mastra instance initialization and agent factory
- **`mastra/agents.ts`**: Clinic agent creation with tone-based prompts
- **`mastra/tools.ts`**: Convex operations wrapped as Mastra tools
- **`mastra/workflows.ts`**: Campaign and reminder workflow definitions
- **`convex/automation.ts`**: AI settings, campaign CRUD, reminder configs
- **`convex/automationActions.ts`**: Scheduled tasks using Mastra
- **`convex/automationAi.ts`**: AI chat integration for WhatsApp
- **`convex/automationInternal.ts`**: Internal queries and helpers
- **`convex/automationHelpers.ts`**: Helper functions for templates
- **`convex/cron.ts`**: Cron jobs for automation execution

## Features

### 1. AI Settings Management

**Frontend**: `apps/web/src/routes/automation.tsx`
**Backend**: `convex/automation.ts`

Features:

- Custom system prompt/persona per clinic
- Tone selection (Empathetic, Formal, Casual, Direct)
- Temperature control (0-1) for creativity
- Active hours configuration (e.g., 08:00-18:00)
- Response delay (seconds) for natural feel
- Escalation keywords (max 20) for emergency detection
- Voice notes transcription toggle

**APIs**:

- `getAiSettings(clinicId)` - Query
- `updateAiSettings(...)` - Mutation (upsert)
- `toggleAiEnabled(clinicId, enabled)` - Mutation
- `updateFallbackChannels(clinicId, escalationKeywords, escalationEnabled)` - Mutation

### 2. Reminder Configuration

**Reminder Types**:

- 7-day reminder (pre-appointment)
- 24-hour reminder (confirmation)
- 1-hour reminder (urgency)
- Post-consultation (NPS survey)
- No-show recovery (reschedule offer)

**Features**:

- Custom message templates with variables
- Channel selection (WhatsApp, SMS, Email, Call)
- Enable/disable per reminder type
- Official API toggle
- Delay configuration in minutes

**APIs**:

- `getReminderConfigs(clinicId)` - Query
- `updateReminderConfig(...)` - Mutation (upsert)
- `toggleReminder(clinicId, type, enabled)` - Mutation

### 3. Campaign Builder

**Trigger Types**:

- `time_after_appointment`: X hours after appointment completion
- `time_after_procedure`: X hours after procedure
- `birthday`: Daily check for patient birthdays
- `no_show`: When patient misses appointment
- `custom`: Manual trigger only

**Features**:

- Multi-step campaigns with delays between steps
- Step ordering and channel selection
- Campaign status management (Draft, Active, Paused)
- Trigger count tracking
- Idempotency (prevent duplicate sends)

**APIs**:

- `listCampaigns(clinicId, status?)` - Query
- `getCampaign(clinicId, campaignId)` - Query
- `createCampaign(...)` - Mutation
- `updateCampaign(...)` - Mutation
- `deleteCampaign(clinicId, campaignId)` - Mutation
- `toggleCampaignStatus(clinicId, campaignId)` - Mutation

### 4. Scheduled Automation

**Cron Jobs** (in `convex/cron.ts`):

- `checkReminders` - Every hour
- `checkCampaigns` - Every 30 minutes
- `checkBirthdays` - Daily at 9 AM

**Actions**:

- `scheduleReminders()` - Finds and sends due reminders
- `scheduleCampaignExecution()` - Triggers campaigns based on conditions
- `sendPostConsultationReminder()` - Sends NPS after appointment
- `handleNoShowRecovery()` - Handles missed appointments
- `checkBirthdayCampaigns()` - Checks for birthdays

### 5. WhatsApp AI Chat Integration

**Features**:

- Automatic AI responses when enabled
- Active hours enforcement
- Response delay simulation
- Escalation detection and notification
- Conversation memory via thread IDs

**APIs**:

- `generateAiResponse(clinicId, message, threadId?, patientId?)` - Action
- `processIncomingAiMessage(clinicId, chatId, messageId, patientId?)` - Action
- `getClinicAgentStatus(clinicId)` - Query

### 6. Model Fallbacks & Resilience

**Primary**: OpenAI GPT-4o
**Secondary**: Anthropic Claude 3.5 Sonnet
**Tertiary**: Google Gemini 2.5 Pro

Each model has `maxRetries: 2` for automatic retry on failure.

## Message Templating

**Variables** (replaced in real-time by AI):

- `{{patient_name}}` - Patient's name
- `{{appointment_date}}` - Appointment date (formatted)
- `{{appointment_time}}` - Appointment time (formatted)
- `{{clinic_name}}` - Clinic name
- `{{doctor_name}}` - Doctor's name

**Helper Functions** (in `automationHelpers.ts`):

- `personalizeMessage(template, context)` - Replace variables
- `formatDate(date)` - Format date in Portuguese
- `formatTime(date)` - Format time in Portuguese
- `detectEscalation(message, keywords)` - Check for emergency keywords
- `isValidTimeFormat(time)` - Validate HH:MM format

## Security & RBAC

All mutations require `admin` or `staff` role:

- AI settings mutations: Admin/Staff only
- Campaign mutations: Admin/Staff only
- Reminder mutations: Admin/Staff only

Queries are accessible to authenticated users from the same clinic.

Internal actions (cron jobs) bypass auth checks.

## Escalation Flow

When escalation keywords are detected:

1. AI agent detects keywords in incoming message
2. Uses `escalateToStaff` tool
3. Logs to `auditLogs` table
4. In production: Sends notification to clinic staff (SMS/WhatsApp)
5. Returns `escalated: true` to skip auto-response

**Default Keywords**: "processo", "advogado", "procon", "urgência médica"

## Active Hours

AI only responds between configured hours:

- Default: 08:00-18:00
- Outside hours: Returns "Estamos fora do horário de atendimento. Por favor, deixe uma mensagem e responderemos assim que possível."
- Implemented via `isWithinActiveHours()` helper

## Error Handling

### Mastra-Level:

- Model fallbacks: Automatic retry with next model
- `maxRetries: 2` per model attempt
- Graceful degradation on all failures

### Convex-Level:

- All mutations use `try/catch` with detailed error logging
- Actions return error reasons for debugging
- Retry logic with `ctx.scheduler.runAfter()`

### Idempotency:

- Reminders: `reminderAt` field prevents duplicates
- Campaigns: Track sent logs to prevent re-execution
- Query before send: Check for existing records

## Performance Optimizations

1. **Agent Caching**: Agents cached by clinic ID + settings version
   - Reduces initialization overhead
   - Cache cleared when settings updated

2. **In-Memory Storage**: Mastra uses LibSQL with `:memory:`
   - Fast for ephemeral state
   - Convex handles persistence

3. **Conversation History Limit**: Last 20 messages per thread
   - Reduces token usage
   - Improves response times

## Frontend Hooks

**File**: `apps/web/src/hooks/automation.ts`

**Hooks**:

- `useAiSettings(clinicId?)` - Fetch AI settings
- `useUpdateAiSettings()` - Update settings mutation
- `useToggleAiEnabled()` - Enable/disable AI
- `useReminderConfigs(clinicId?)` - Fetch reminder configs
- `useUpdateReminderConfig()` - Update reminder config
- `useToggleReminder()` - Toggle reminder
- `useCampaigns(clinicId?, status?)` - List campaigns
- `useCampaign(clinicId, campaignId)` - Get campaign
- `useCampaignManager(clinicId?)` - Complete campaign management
- `useAutomation(clinicId?)` - All automation in one hook

## Environment Variables

```bash
# AI Model API Keys (Required)
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_API_KEY=AIza...

# Mastra Configuration (Optional)
MASTRA_LOG_LEVEL=info
MASTRA_ENABLE_TELEMETRY=false
```

## Dependencies

**Added to `packages/backend/package.json`**:

```json
{
  "@mastra/core": "^0.4.0",
  "@mastra/libsql": "^0.4.0",
  "@ai-sdk/openai": "^0.0.47",
  "@ai-sdk/anthropic": "^0.0.28",
  "@ai-sdk/google": "^0.0.37",
  "zod": "^3.23.8"
}
```

## Migration Steps

### For Development:

1. Run `bun install` to install new dependencies
2. Run `npx convex dev` to start backend
3. Test AI settings in automation page
4. Test campaign creation and execution
5. Test reminder scheduling

### For Production:

1. Set AI API keys in environment
2. Configure Mastra instance (if needed)
3. Deploy to Convex Cloud
4. Monitor cron job execution logs
5. Set up alerting for failures

## Testing

**Unit Tests**: Test tool validation and agent factory
**Integration Tests**: Test full campaign and reminder flows
**Manual Testing**: Test via dashboard UI
**Load Testing**: Test with multiple clinics and concurrent campaigns

## Troubleshooting

**AI not responding**:

1. Check AI settings enabled
2. Verify active hours (current time within range)
3. Check API keys in environment
4. Check `automationAi.ts` logs

**Reminders not sending**:

1. Check reminder config enabled
2. Verify cron job running in `cron.ts`
3. Check `appointment.reminderAt` field
4. Review `scheduleReminders` logs

**Campaigns not executing**:

1. Check campaign status is "active"
2. Verify trigger conditions
3. Review `scheduleCampaignExecution` logs
4. Check WhatsApp instance connection

## Future Enhancements

- [ ] Add SMS and Email channel support
- [ ] Implement knowledge base (RAG) for clinic documents
- [ ] Add voice message transcription (whisper)
- [ ] Implement multi-language support
- [ ] Add campaign analytics and performance tracking
- [ ] Implement A/B testing for campaigns
- [ ] Add conversation history viewer
- [ ] Implement sentiment analysis for incoming messages
- [ ] Add intent classification for routing

## Support

For issues or questions:

1. Check Mastra documentation: https://github.com/mastra-ai/mastra
2. Review generated Convex API: `convex/_generated/api.d.ts`
3. Check logs in Convex dashboard
4. Review this document for implementation details
