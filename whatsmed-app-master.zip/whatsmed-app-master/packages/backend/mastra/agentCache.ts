"use node";

/**
 * Agent cache module
 * Separated from Mastra core to avoid pulling in Node.js dependencies
 */

// Agent cache for clinic-specific agents
export const agentCache = new Map<string, any>();

// Classification agent cache (shared across all clinics)
export const classificationAgentCache = new Map<string, any>();

/**
 * Clear agent cache (call when settings are updated)
 */
export function clearAgentCache(clinicId?: string) {
  if (clinicId) {
    // Clear only agents for specific clinic
    const keysToDelete = Array.from(agentCache.keys()).filter((key) =>
      key.startsWith(`${clinicId}-`),
    );
    keysToDelete.forEach((key) => agentCache.delete(key));
  } else {
    // Clear all agents including classification agent
    agentCache.clear();
    classificationAgentCache.clear();
    console.warn("[Mastra] Cleared all agent caches including classification agent");
  }
}
