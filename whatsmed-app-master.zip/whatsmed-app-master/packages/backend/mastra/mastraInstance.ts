"use node";

/**
 * Lazy initialization of Mastra to avoid bundling issues
 * Only instantiated at runtime in Node.js environment (actions)
 */

let mastraInstance: any = null;

/**
 * Get or create the Mastra instance
 * This is only called from Node.js actions, not during bundling
 */
export function getMastraInstance() {
  if (!mastraInstance) {
    // Dynamic import to avoid bundling LibSQL dependencies
    const { Mastra } = require("@mastra/core");
    mastraInstance = new Mastra({});
  }
  return mastraInstance;
}
