import { z } from "zod";

/**
 * TypeScript types for Mastra integration
 */

/**
 * AI settings configuration
 */
export type AiSettings = {
  clinicId: string;
  enabled: boolean;
  systemPrompt?: string;
  customInstructions?: string;
  activePromptId?: string;
  tone: "empathetic" | "formal" | "casual" | "direct";
  temperature: number;
  escalationEnabled: boolean;
  escalationKeywords: string[];
  activeHoursStart: string;
  activeHoursEnd: string;
  is247?: boolean;
  voiceNotesEnabled: boolean;
  responseDelaySeconds: number;
  updatedAt?: number;
};

export type AiSystemPrompt = {
  _id?: string;
  clinicId: string;
  name: string;
  content: string;
  isActive?: boolean;
  createdAt: number;
  updatedAt: number;
};

/**
 * Reminder configuration
 */
export type ReminderConfig = {
  clinicId: string;
  type: "sevenDay" | "twentyFourHour" | "oneHour" | "postConsultation" | "noShowRecovery";
  enabled: boolean;
  message: string;
  channels: Array<"whatsapp" | "sms" | "email" | "call">;
  useOfficialApi: boolean;
  delayMinutes?: number;
};

/**
 * Campaign configuration
 */
export type Campaign = {
  clinicId: string;
  name: string;
  triggerType:
    | "time_after_appointment"
    | "time_after_procedure"
    | "birthday"
    | "no_show"
    | "custom";
  triggerDelayHours?: number;
  status: "active" | "paused" | "draft";
  steps: Array<{
    order: number;
    delayHours: number;
    channel: "whatsapp" | "sms" | "email" | "call";
    message: string;
  }>;
  triggerCount: number;
  createdAt: number;
  updatedAt: number;
};

/**
 * Template variables context
 */
export type TemplateContext = {
  patientName?: string;
  patientPhone?: string;
  appointmentDate?: string;
  appointmentTime?: string;
  clinicName?: string;
  doctorName?: string;
};

/**
 * WhatsApp tool result
 */
export type WhatsAppToolResult = {
  success: boolean;
  messageId?: string;
  channel: "whatsapp";
};

/**
 * Patient info tool result
 */
export type PatientInfoResult = {
  patient?: any;
  found: boolean;
};

/**
 * Appointment info tool result
 */
export type AppointmentInfoResult = {
  appointment?: any;
  found: boolean;
};

/**
 * List appointments tool result
 */
export type ListAppointmentsResult = {
  appointments?: any[];
  count?: number;
};

/**
 * Schedule reminder tool result
 */
export type ScheduleReminderResult = {
  success: boolean;
  reminderType: string;
  scheduledAt: number;
};

/**
 * Clinic info tool result
 */
export type ClinicInfoResult = {
  clinic?: any;
  found: boolean;
};

/**
 * AI settings tool result
 */
export type AiSettingsToolResult = {
  settings?: any | null;
  found: boolean;
};

/**
 * Escalate to staff tool result
 */
export type EscalateToStaffResult = {
  success: boolean;
  escalatedAt: number;
  severity: "low" | "medium" | "high" | "emergency";
};

/**
 * Campaign execution input
 */
export type CampaignExecutionInput = {
  campaignId: string;
  clinicId: string;
  patientId: string;
  steps: Campaign["steps"];
  context?: TemplateContext;
};

/**
 * Reminder execution input
 */
export type ReminderExecutionInput = {
  reminderType: ReminderConfig["type"];
  clinicId: string;
  patientId: string;
  appointmentId?: string;
  messageTemplate: string;
  channel: ReminderConfig["channels"][number];
  context?: TemplateContext;
};

/**
 * AI response result
 */
export type AiResponseResult = {
  response?: string;
  model: string;
  escalated: boolean;
  reason?: string;
};

/**
 * Agent status result
 */
export type ClinicAgentStatus = {
  enabled: boolean;
  agentName: string;
  lastUsedModel: string;
  activeHours: string;
  tone: string;
  escalationEnabled: boolean;
};

/**
 * Reminder sending result
 */
export type ReminderSendingResult = {
  sent: boolean;
  messageId?: string;
  channel: string;
};

/**
 * Campaign step result
 */
export type CampaignStepResult = {
  sent: boolean;
  messageId?: string;
  stepNumber: number;
};

/**
 * Zod schemas for validation
 */
export const Schemas = {
  // AI settings schema
  updateAiSettings: z.object({
    clinicId: z.string(),
    enabled: z.boolean().optional(),
    systemPrompt: z.string().optional(),
    tone: z.enum(["empathetic", "formal", "casual", "direct"]).optional(),
    temperature: z.number().optional(),
    escalationEnabled: z.boolean().optional(),
    escalationKeywords: z.array(z.string()).optional(),
    activeHoursStart: z.string().optional(),
    activeHoursEnd: z.string().optional(),
    is247: z.boolean().optional(),
    voiceNotesEnabled: z.boolean().optional(),
    responseDelaySeconds: z.number().optional(),
    customInstructions: z.string().optional(),
    activePromptId: z.string().optional(),
  }),

  // Reminder config schema
  updateReminderConfig: z.object({
    clinicId: z.string(),
    type: z.enum(["sevenDay", "twentyFourHour", "oneHour", "postConsultation", "noShowRecovery"]),
    enabled: z.boolean().optional(),
    message: z.string().optional(),
    channels: z.array(z.enum(["whatsapp", "sms", "email", "call"])).optional(),
    useOfficialApi: z.boolean().optional(),
    delayMinutes: z.number().optional(),
  }),

  // Campaign schema
  createCampaign: z.object({
    clinicId: z.string(),
    name: z.string(),
    triggerType: z.enum([
      "time_after_appointment",
      "time_after_procedure",
      "birthday",
      "no_show",
      "custom",
    ]),
    triggerDelayHours: z.number().optional(),
    steps: z.array(
      z.object({
        order: z.number(),
        delayHours: z.number(),
        channel: z.enum(["whatsapp", "sms", "email", "call"]),
        message: z.string(),
      }),
    ),
  }),

  // Message template schema
  messageTemplate: z.object({
    message: z.string(),
    patientName: z.string().optional(),
    appointmentDate: z.string().optional(),
    appointmentTime: z.string().optional(),
    clinicName: z.string().optional(),
    doctorName: z.string().optional(),
  }),
};
