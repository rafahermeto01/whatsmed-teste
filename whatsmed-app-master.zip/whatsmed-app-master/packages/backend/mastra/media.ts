import { Buffer } from "node:buffer";

export function isImageMimeType(value?: string | null): boolean {
  return typeof value === "string" && value.startsWith("image/");
}

export function isPdfMimeType(value?: string | null): boolean {
  return value === "application/pdf";
}

export async function blobToDataUrl(
  blob: Blob,
  fallbackMimeType = "application/octet-stream",
): Promise<string> {
  const bytes = Buffer.from(await blob.arrayBuffer());
  const mimeType = blob.type || fallbackMimeType;
  return `data:${mimeType};base64,${bytes.toString("base64")}`;
}

export async function downloadUrlToDataUrl(
  url: string,
  fallbackMimeType = "application/octet-stream",
): Promise<string> {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to download media (${response.status})`);
  }

  const blob = await response.blob();
  const contentType = response.headers.get("content-type") || blob.type || fallbackMimeType;
  return blobToDataUrl(blob, contentType);
}
