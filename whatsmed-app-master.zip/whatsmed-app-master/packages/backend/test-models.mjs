const apiKey = process.env.OPENCODE_GO_API_KEY;
if (!apiKey) {
  throw new Error("Missing OPENCODE_GO_API_KEY");
}

const response = await fetch("https://api.opencode.ai/v1/models", {
  headers: {
    Authorization: `Bearer ${apiKey}`,
    "Content-Type": "application/json",
  },
});

const data = await response.json();
console.log(JSON.stringify(data, null, 2));
