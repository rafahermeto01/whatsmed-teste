import { describe, it, expect } from "vitest";
import { formatToE164, isValidE164, cleanPhone } from "../convex/lib/phoneUtils";

describe("phoneUtils", () => {
  it("cleans phone numbers", () => {
    expect(cleanPhone("(11) 99999-9999")).toBe("11999999999");
    expect(cleanPhone("+55 11 99999-9999")).toBe("5511999999999");
  });

  it("formats to E.164 (Brazil default)", () => {
    // Mobile with DDD
    expect(formatToE164("11999999999")).toBe("+5511999999999");
    // Landline with DDD
    expect(formatToE164("1133334444")).toBe("+551133334444");
    // Already E.164
    expect(formatToE164("+5511999999999")).toBe("+5511999999999");
    // International
    expect(formatToE164("+15551234567")).toBe("+15551234567");
    // Ambiguous large number (assume Brazil default if no +)
    expect(formatToE164("5511999999999")).toBe("+5511999999999");
  });

  it("validates E.164", () => {
    expect(isValidE164("+5511999999999")).toBe(true);
    expect(isValidE164("11999999999")).toBe(false); // Missing +
    expect(isValidE164("+123")).toBe(false); // Too short
    expect(isValidE164("+1234567890123456")).toBe(false); // Too long
  });
});
