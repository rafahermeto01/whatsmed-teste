import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { api, internal } from "../convex/_generated/api";
import type { Convex } from "convex-devtools";
import { createTestConvex } from "./harness";

describe("Documents Module", () => {
  let convex: Awaited<ReturnType<typeof createTestConvex>>;

  beforeEach(async () => {
    convex = await createTestConvex();
  });

  afterEach(async () => {
    // convex-test might not have .close() depending on version, check docs
    // usually t.finish() or nothing.
    // await convex.close();
  });

  const createStorageId = async (mimeType = "application/pdf") => {
    return await convex.run(async (ctx: any) => {
      const blob = new Blob(["test-file"], { type: mimeType });
      return await ctx.storage.store(blob);
    });
  };

  const saveDocumentForTest = async (args: {
    clinicId: string;
    filename: string;
    size: number;
    mimeType: string;
  }) => {
    const storageId = await createStorageId(args.mimeType);
    return await convex.mutation(api.documents.saveDocument, {
      ...args,
      storageId,
    });
  };

  describe("saveDocument mutation", () => {
    it("should save valid PDF document metadata", async () => {
      const clinicId = "test-clinic-1";
      const fileData = {
        filename: "test.pdf",
        size: 1024 * 1024, // 1MB
        mimeType: "application/pdf",
      };

      const result = await saveDocumentForTest({ clinicId, ...fileData });

      expect(result).toBeDefined();
      expect(result.filename).toBe("test.pdf");
      expect(result.size).toBe(1024 * 1024);
      expect(result.mimeType).toBe("application/pdf");
      expect(result.downloads).toBe(0);
      expect(result.expiresAt).toBeGreaterThan(Date.now());
      expect(result.expiresAt).toBeLessThanOrEqual(Date.now() + 48 * 60 * 60 * 1000 + 1000);
      expect(result.storageId).toBeDefined();
    });

    it("should save valid JPG document metadata", async () => {
      const clinicId = "test-clinic-2";
      const fileData = {
        filename: "test.jpg",
        size: 512 * 1024, // 512KB
        mimeType: "image/jpeg",
      };

      const result = await saveDocumentForTest({ clinicId, ...fileData });

      expect(result).toBeDefined();
      expect(result.mimeType).toBe("image/jpeg");
      expect(result.downloads).toBe(0);
    });

    it("should save valid PNG document metadata", async () => {
      const clinicId = "test-clinic-3";
      const fileData = {
        filename: "test.png",
        size: 256 * 1024, // 256KB
        mimeType: "image/png",
      };

      const result = await saveDocumentForTest({ clinicId, ...fileData });

      expect(result).toBeDefined();
      expect(result.mimeType).toBe("image/png");
    });

    it("should reject files larger than 10MB", async () => {
      const clinicId = "test-clinic-4";
      const storageId = await createStorageId("application/pdf");
      const fileData = {
        filename: "large.pdf",
        size: 11 * 1024 * 1024, // 11MB
        mimeType: "application/pdf",
        storageId,
      };

      await expect(
        convex.mutation(api.documents.saveDocument, {
          clinicId,
          ...fileData,
        }),
      ).rejects.toThrow("Arquivo muito grande");
    });

    it("should reject invalid MIME types", async () => {
      const clinicId = "test-clinic-5";
      const storageId = await createStorageId("text/plain");
      const fileData = {
        filename: "test.txt",
        size: 1024,
        mimeType: "text/plain",
        storageId,
      };

      await expect(
        convex.mutation(api.documents.saveDocument, {
          clinicId,
          ...fileData,
        }),
      ).rejects.toThrow("Formato inválido");
    });

    it("should set expiresAt to 48 hours from now", async () => {
      const clinicId = "test-clinic-6";
      const now = Date.now();
      const fileData = {
        filename: "test.pdf",
        size: 1024,
        mimeType: "application/pdf",
      };

      const result = await saveDocumentForTest({ clinicId, ...fileData });

      const expectedExpiry = now + 48 * 60 * 60 * 1000;
      const timeDiff = Math.abs(result.expiresAt - expectedExpiry);
      expect(timeDiff).toBeLessThan(1000); // Allow 1 second margin
    });
  });

  describe("listDocuments query", () => {
    it("should return only clinic's documents", async () => {
      const clinicId1 = "test-clinic-list-1";
      const clinicId2 = "test-clinic-list-2";

      // Upload documents for clinic 1
      await saveDocumentForTest({
        clinicId: clinicId1,
        filename: "clinic1-doc.pdf",
        size: 1024,
        mimeType: "application/pdf",
      });

      // Upload documents for clinic 2
      await saveDocumentForTest({
        clinicId: clinicId2,
        filename: "clinic2-doc.pdf",
        size: 1024,
        mimeType: "application/pdf",
      });

      // Query documents for clinic 1
      const clinic1Docs = await convex.query(api.documents.listDocuments, {
        clinicId: clinicId1,
      });

      expect(clinic1Docs).toHaveLength(1);
      expect(clinic1Docs[0].filename).toBe("clinic1-doc.pdf");

      // Query documents for clinic 2
      const clinic2Docs = await convex.query(api.documents.listDocuments, {
        clinicId: clinicId2,
      });

      expect(clinic2Docs).toHaveLength(1);
      expect(clinic2Docs[0].filename).toBe("clinic2-doc.pdf");
    });

    it("should return empty array for clinic with no documents", async () => {
      const clinicId = "test-clinic-empty";

      const result = await convex.query(api.documents.listDocuments, {
        clinicId,
      });

      expect(result).toHaveLength(0);
    });

    it("should order documents by createdAt descending", async () => {
      const clinicId = "test-clinic-order";

      // Upload first document
      await saveDocumentForTest({
        clinicId,
        filename: "first.pdf",
        size: 1024,
        mimeType: "application/pdf",
      });

      await new Promise((resolve) => setTimeout(resolve, 10)); // Small delay

      // Upload second document
      await saveDocumentForTest({
        clinicId,
        filename: "second.pdf",
        size: 1024,
        mimeType: "application/pdf",
      });

      const docs = await convex.query(api.documents.listDocuments, {
        clinicId,
      });

      expect(docs).toHaveLength(2);
      expect(docs[0].filename).toBe("second.pdf"); // Most recent first
      expect(docs[1].filename).toBe("first.pdf");
    });
  });

  describe("getDocument query", () => {
    it("should return document when it exists and not expired", async () => {
      const clinicId = "test-clinic-get";
      const fileData = {
        filename: "test.pdf",
        size: 1024,
        mimeType: "application/pdf",
      };

      const uploaded = await saveDocumentForTest({ clinicId, ...fileData });

      const result = await convex.query(api.documents.getDocument, {
        documentId: uploaded._id,
      });

      expect(result).toBeDefined();
      expect(result!._id).toBe(uploaded._id);
      expect(result!.filename).toBe("test.pdf");
    });

    it("should return null for non-existent document", async () => {
      const uploaded = await saveDocumentForTest({
        clinicId: "test-clinic-non-existent",
        filename: "to-delete.pdf",
        size: 1024,
        mimeType: "application/pdf",
      });

      await convex.mutation(api.documents.deleteDocument, {
        documentId: uploaded._id,
      });

      const result = await convex.query(api.documents.getDocument, {
        documentId: uploaded._id,
      });

      expect(result).toBeNull();
    });

    it("should return null for expired document", async () => {
      const clinicId = "test-clinic-expired";
      const fileData = {
        filename: "test.pdf",
        size: 1024,
        mimeType: "application/pdf",
      };

      const uploaded = await saveDocumentForTest({ clinicId, ...fileData });

      // Manually expire the document
      await saveDocumentForTest({
        clinicId: "test-clinic-modify",
        filename: "other.pdf",
        size: 1024,
        mimeType: "application/pdf",
      });

      // Patch the uploaded document to be expired
      await convex.run(async (ctx: any) => {
        ctx.db.patch(uploaded._id, {
          expiresAt: Date.now() - 1000, // Expired 1 second ago
        });
        return uploaded._id;
      });

      const result = await convex.query(api.documents.getDocument, {
        documentId: uploaded._id,
      });

      expect(result).toBeNull();
    });
  });

  describe("getSecureDocumentUrl mutation", () => {
    it("should return URL for valid document and increment downloads", async () => {
      const clinicId = "test-clinic-url";
      const fileData = {
        filename: "test.pdf",
        size: 1024,
        mimeType: "application/pdf",
      };

      const uploaded = await saveDocumentForTest({ clinicId, ...fileData });

      const result1 = await convex.mutation(api.documents.getSecureDocumentUrl, {
        documentId: uploaded._id,
      });

      expect(result1.url).toBeDefined();
      expect(result1.url).toBeTruthy();
      expect(result1.error).toBeUndefined();

      // Fetch document to check downloads
      const doc1 = await convex.query(api.documents.getDocument, {
        documentId: uploaded._id,
      });

      expect(doc1!.downloads).toBe(1);

      // Call again
      const result2 = await convex.mutation(api.documents.getSecureDocumentUrl, {
        documentId: uploaded._id,
      });

      expect(result2.url).toBeTruthy();

      // Check downloads incremented again
      const doc2 = await convex.query(api.documents.getDocument, {
        documentId: uploaded._id,
      });

      expect(doc2!.downloads).toBe(2);
    });

    it("should return error for expired document", async () => {
      const clinicId = "test-clinic-url-expired";
      const fileData = {
        filename: "test.pdf",
        size: 1024,
        mimeType: "application/pdf",
      };

      const uploaded = await saveDocumentForTest({ clinicId, ...fileData });

      // Manually expire the document
      await convex.run(async (ctx: any) => {
        ctx.db.patch(uploaded._id, {
          expiresAt: Date.now() - 1000,
        });
        return uploaded._id;
      });

      const result = await convex.mutation(api.documents.getSecureDocumentUrl, {
        documentId: uploaded._id,
      });

      expect(result.url).toBeNull();
      expect(result.error).toBe("Documento expirado");
    });

    it("should return error for non-existent document", async () => {
      const uploaded = await saveDocumentForTest({
        clinicId: "test-clinic-missing-url",
        filename: "to-delete.pdf",
        size: 1024,
        mimeType: "application/pdf",
      });

      await convex.mutation(api.documents.deleteDocument, {
        documentId: uploaded._id,
      });

      const result = await convex.mutation(api.documents.getSecureDocumentUrl, {
        documentId: uploaded._id,
      });

      expect(result.url).toBeNull();
      expect(result.error).toBe("Documento não encontrado");
    });
  });

  describe("deleteDocument mutation", () => {
    it("should delete document successfully", async () => {
      const clinicId = "test-clinic-delete";
      const fileData = {
        filename: "test.pdf",
        size: 1024,
        mimeType: "application/pdf",
      };

      const uploaded = await saveDocumentForTest({ clinicId, ...fileData });

      // Verify document exists
      const beforeDelete = await convex.query(api.documents.getDocument, {
        documentId: uploaded._id,
      });
      expect(beforeDelete).toBeDefined();

      // Delete document
      await convex.mutation(api.documents.deleteDocument, {
        documentId: uploaded._id,
      });

      // Verify document no longer exists
      const afterDelete = await convex.query(api.documents.getDocument, {
        documentId: uploaded._id,
      });
      expect(afterDelete).toBeNull();
    });

    it("should handle deletion of non-existent document", async () => {
      const uploaded = await saveDocumentForTest({
        clinicId: "test-clinic-non-existent-delete",
        filename: "to-delete.pdf",
        size: 1024,
        mimeType: "application/pdf",
      });

      await convex.mutation(api.documents.deleteDocument, {
        documentId: uploaded._id,
      });

      await expect(
        convex.mutation(api.documents.deleteDocument, {
          documentId: uploaded._id,
        }),
      ).rejects.toThrow("Documento não encontrado");
    });
  });

  describe("cleanupExpiredDocuments action", () => {
    it("should delete expired documents", async () => {
      const clinicId = "test-clinic-cleanup";

      // Create an expired document
      const expiredFileData = {
        filename: "expired.pdf",
        size: 1024,
        mimeType: "application/pdf",
      };

      const expiredDoc = await saveDocumentForTest({ clinicId, ...expiredFileData });

      // Manually expire it
      await convex.run(async (ctx: any) => {
        ctx.db.patch(expiredDoc._id, {
          expiresAt: Date.now() - 1000,
        });
        return expiredDoc._id;
      });

      // Create a non-expired document
      const validFileData = {
        filename: "valid.pdf",
        size: 1024,
        mimeType: "application/pdf",
      };

      const validDoc = await saveDocumentForTest({ clinicId, ...validFileData });

      // Run cleanup
      const result = await convex.action(internal.documents.cleanupExpiredDocuments, {});

      expect(result.cleanedCount).toBeGreaterThanOrEqual(1);

      // Verify expired document is deleted
      const expiredCheck = await convex.query(api.documents.getDocument, {
        documentId: expiredDoc._id,
      });
      expect(expiredCheck).toBeNull();

      // Verify valid document still exists
      const validCheck = await convex.query(api.documents.getDocument, {
        documentId: validDoc._id,
      });
      expect(validCheck).toBeDefined();
    });

    it("should return zero when no expired documents exist", async () => {
      const clinicId = "test-clinic-no-expired";

      // Create a valid document
      const fileData = {
        filename: "valid.pdf",
        size: 1024,
        mimeType: "application/pdf",
      };

      await saveDocumentForTest({ clinicId, ...fileData });

      // Run cleanup
      const result = await convex.action(internal.documents.cleanupExpiredDocuments, {});

      expect(result.cleanedCount).toBe(0);
    });
  });

  describe("File size and type validation", () => {
    const MAX_FILE_SIZE = 10 * 1024 * 1024;
    const ALLOWED_MIME_TYPES = new Set(["application/pdf", "image/jpeg", "image/png"]);

    it("should enforce 10MB limit", () => {
      const oversized = MAX_FILE_SIZE + 1;
      const validSize = MAX_FILE_SIZE - 1;

      expect(oversized).toBeGreaterThan(MAX_FILE_SIZE);
      expect(validSize).toBeLessThanOrEqual(MAX_FILE_SIZE);
    });

    it("should only allow PDF, JPG, PNG types", () => {
      expect(ALLOWED_MIME_TYPES.has("application/pdf")).toBe(true);
      expect(ALLOWED_MIME_TYPES.has("image/jpeg")).toBe(true);
      expect(ALLOWED_MIME_TYPES.has("image/png")).toBe(true);
      expect(ALLOWED_MIME_TYPES.has("text/plain")).toBe(false);
      expect(ALLOWED_MIME_TYPES.has("application/msword")).toBe(false);
      expect(ALLOWED_MIME_TYPES.has("image/gif")).toBe(false);
    });

    it("should set 48 hour expiry", () => {
      const EXPIRY_HOURS = 48;
      const EXPIRY_MS = EXPIRY_HOURS * 60 * 60 * 1000;
      const now = Date.now();
      const expectedExpiry = now + EXPIRY_MS;

      const hoursFromNow = (expectedExpiry - now) / (60 * 60 * 1000);
      expect(hoursFromNow).toBe(EXPIRY_HOURS);
    });
  });
});
