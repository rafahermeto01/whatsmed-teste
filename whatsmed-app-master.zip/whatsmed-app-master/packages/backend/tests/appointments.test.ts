// @ts-nocheck
import { describe, it, expect, beforeEach, vi } from "vitest";
import { api, internal } from "../convex/_generated/api.js";
import { formatGoogleCalendarDateTime } from "../convex/appointments.js";
import { createTestConvex, ensureClinic } from "./harness.js";

const sendMailMock = vi.fn(async () => ({ messageId: "mock-message-id" }));

vi.mock("nodemailer", () => ({
  default: {
    createTransport: () => ({
      sendMail: sendMailMock,
    }),
  },
}));

describe("Appointments", () => {
  let t: Awaited<ReturnType<typeof createTestConvex>>;

  beforeEach(async () => {
    vi.useRealTimers();
    sendMailMock.mockClear();
    process.env.SMTP_HOST = "smtp.test.local";
    process.env.SMTP_USER = "test-user";
    process.env.SMTP_PASS = "test-pass";
    t = await createTestConvex();
  });

  async function insertAppointment(values: Record<string, unknown>) {
    return await t.run(async (ctx) => {
      const now = Date.now();
      const appointmentId = await ctx.db.insert("appointments", {
        createdAt: now,
        updatedAt: now,
        status: "confirmed",
        ...values,
      } as any);
      return (await ctx.db.get(appointmentId))!;
    });
  }

  it("aligns same-day availability to the next slot boundary", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-03-16T17:07:00.000Z"));

    const clinicId = "test-clinic-same-day";
    await ensureClinic(t, clinicId);
    await t.mutation(api.patients.create, { clinicId, name: "Same Day Patient" });
    const doctor = await t.mutation(api.users.create, {
      authUserId: "doctor-same-day",
      clinicId,
      name: "Doctor Same Day",
      email: "doctor-same-day@example.com",
      role: "doctor",
    });

    await t.mutation(api.users.updateWorkingHours, {
      id: doctor._id,
      workingHours: [
        {
          dayOfWeek: 1,
          slots: [{ start: "14:00", end: "18:00", types: ["in_person"] }],
        },
      ],
    });

    const procedureId = await t.run(async (ctx) => {
      return await ctx.db.insert("procedures", {
        clinicId,
        doctorId: doctor._id,
        name: "Consulta 30 min",
        durationMinutes: 30,
        isActive: true,
        isTelemedicine: false,
        isInPerson: true,
        createdAt: Date.now(),
      });
    });

    const slots = await t.query(api.appointments.getAvailableSlots, {
      clinicId,
      doctorId: doctor._id,
      procedureId,
      date: "2026-03-16",
      isTelemedicine: false,
    });

    expect(slots[0]?.start).toBe("2026-03-16T17:15:00.000Z");
    expect(slots.some((slot: { start: string }) => slot.start === "2026-03-16T17:07:00.000Z")).toBe(
      false,
    );
  });

  it("keeps afternoon and evening slots when querying a Brazil-local day", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-03-17T12:00:00.000Z"));

    const clinicId = "test-clinic-afternoon";
    await ensureClinic(t, clinicId);
    const doctor = await t.mutation(api.users.create, {
      authUserId: "doctor-afternoon",
      clinicId,
      name: "Doctor Afternoon",
      email: "doctor-afternoon@example.com",
      role: "doctor",
    });

    await t.mutation(api.users.updateWorkingHours, {
      id: doctor._id,
      workingHours: [
        {
          dayOfWeek: 3,
          slots: [{ start: "14:00", end: "20:00", types: ["in_person"] }],
        },
      ],
    });

    const procedureId = await t.run(async (ctx) => {
      return await ctx.db.insert("procedures", {
        clinicId,
        doctorId: doctor._id,
        name: "Consulta Tarde",
        durationMinutes: 60,
        isActive: true,
        isTelemedicine: false,
        isInPerson: true,
        createdAt: Date.now(),
      });
    });

    const slots = await t.query(api.appointments.getDoctorAvailability, {
      clinicId,
      doctorId: doctor._id,
      procedureId,
      startDate: "2026-03-18T03:00:00.000Z",
      endDate: "2026-03-19T03:00:00.000Z",
    });

    const starts = slots.map((slot: { start: string }) => slot.start);

    expect(starts[0]).toBe("2026-03-18T17:00:00.000Z");
    expect(starts.at(-1)).toBe("2026-03-18T22:00:00.000Z");
    expect(starts).toContain("2026-03-18T18:15:00.000Z");
    expect(starts).toContain("2026-03-18T21:45:00.000Z");
  });

  it("should mark an appointment as arrived and add it to the waitlist", async () => {
    const clinicId = "test-clinic-1";
    const authUserId = "auth-123";
    const email = "doctor@example.com";
    await ensureClinic(t, clinicId);

    // 1. Create Patient
    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Test Patient",
      email: "patient@example.com",
    });

    // 2. Create Doctor
    const doctor = await t.mutation(api.users.create, {
      authUserId,
      clinicId,
      name: "Test Doctor",
      email,
      role: "doctor",
    });

    // 3. Create Appointment
    const appointment = await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: doctor._id,
      startAt: Date.now() + 3600000,
      endAt: Date.now() + 7200000,
      status: "confirmed",
      doctor: "Test Doctor",
    });

    expect(appointment.status).toBe("confirmed");

    const checkedIn = await t.run(async (ctx) => {
      await ctx.db.patch(appointment._id, {
        status: "arrived",
        actualArrivalTime: Date.now(),
        updatedAt: Date.now(),
      });

      await ctx.runMutation(internal.waitlists.upsertWaitlistForCheckin, {
        clinicId,
        appointmentId: appointment._id,
        patientId: patient._id,
        doctorId: doctor._id,
      });

      return await ctx.db.get(appointment._id);
    });

    expect(checkedIn.status).toBe("arrived");
    expect(checkedIn.actualArrivalTime).toBeDefined();
  });

  it("should list appointments", async () => {
    const clinicId = "test-clinic-1";
    await ensureClinic(t, clinicId);

    // Create data
    const patient = await t.mutation(api.patients.create, { clinicId, name: "P1" });
    const doctor = await t.mutation(api.users.create, {
      authUserId: "d1",
      clinicId,
      name: "D1",
      email: "d1@e.com",
      role: "doctor",
    });

    await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: doctor._id,
      startAt: Date.now(),
      endAt: Date.now() + 30 * 60 * 1000,
      status: "pending",
      doctor: "D1",
    });

    // List
    const result = await t
      .withIdentity({ subject: "d1", email: "d1@e.com", name: "D1" })
      .query(api.appointments.list, { clinicId });
    expect(result.items.length).toBe(1);
    expect(result.items[0].patientName).toBe("P1");
  });

  it("should add patient to waitlist when an appointment arrives", async () => {
    const clinicId = "test-clinic-2";
    const authUserId = "auth-456";
    const email = "doctor2@example.com";
    await ensureClinic(t, clinicId);

    // 1. Create Patient
    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Test Patient 2",
      email: "patient2@example.com",
    });

    // 2. Create Doctor
    const doctor = await t.mutation(api.users.create, {
      authUserId,
      clinicId,
      name: "Test Doctor 2",
      email,
      role: "doctor",
    });

    // 3. Create Appointment
    const appointment = await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: doctor._id,
      startAt: Date.now() + 3600000,
      endAt: Date.now() + 7200000,
      status: "confirmed",
      doctor: "Test Doctor 2",
    });

    const checkedIn = await t.run(async (ctx) => {
      await ctx.db.patch(appointment._id, {
        status: "arrived",
        actualArrivalTime: Date.now(),
        updatedAt: Date.now(),
      });

      await ctx.runMutation(internal.waitlists.upsertWaitlistForCheckin, {
        clinicId,
        appointmentId: appointment._id,
        patientId: patient._id,
        doctorId: doctor._id,
      });

      return await ctx.db.get(appointment._id);
    });

    expect(checkedIn.status).toBe("arrived");

    // 5. Verify patient appears in waitlist
    const waitlistResult = await t.query(api.waitlists.listWaitlist, {
      clinicId,
      status: "waiting",
      paginationOpts: { numItems: 50, cursor: undefined },
    });

    expect(waitlistResult.items.length).toBe(1);
    expect(waitlistResult.items[0].patientId).toBe(patient._id);
    expect(waitlistResult.items[0].appointmentId).toBe(appointment._id);
    expect(waitlistResult.items[0].status).toBe("waiting");
  });

  it("should be idempotent when the waitlist upsert runs twice", async () => {
    const clinicId = "test-clinic-3";
    const authUserId = "auth-789";
    const email = "doctor3@example.com";
    await ensureClinic(t, clinicId);

    // 1. Create Patient
    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Test Patient 3",
      email: "patient3@example.com",
    });

    // 2. Create Doctor
    const doctor = await t.mutation(api.users.create, {
      authUserId,
      clinicId,
      name: "Test Doctor 3",
      email,
      role: "doctor",
    });

    // 3. Create Appointment
    const appointment = await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: doctor._id,
      startAt: Date.now() + 3600000,
      endAt: Date.now() + 7200000,
      status: "confirmed",
      doctor: "Test Doctor 3",
    });

    await t.run(async (ctx) => {
      await ctx.db.patch(appointment._id, {
        status: "arrived",
        actualArrivalTime: Date.now(),
        updatedAt: Date.now(),
      });

      await ctx.runMutation(internal.waitlists.upsertWaitlistForCheckin, {
        clinicId,
        appointmentId: appointment._id,
        patientId: patient._id,
        doctorId: doctor._id,
      });

      await ctx.runMutation(internal.waitlists.upsertWaitlistForCheckin, {
        clinicId,
        appointmentId: appointment._id,
        patientId: patient._id,
        doctorId: doctor._id,
      });
    });

    // 6. Verify only one waitlist entry exists
    const waitlistResult = await t.query(api.waitlists.listWaitlist, {
      clinicId,
      status: "waiting",
      paginationOpts: { numItems: 50, cursor: undefined },
    });

    expect(waitlistResult.items.length).toBe(1);
    expect(waitlistResult.items[0].appointmentId).toBe(appointment._id);
  });

  it("should not return overlapping slot when busy appointment starts before range", async () => {
    const clinicId = "test-clinic-overlap";
    await ensureClinic(t, clinicId);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Overlap Patient",
      email: "overlap@example.com",
    });

    const doctor = await t.mutation(api.users.create, {
      authUserId: "doctor-overlap",
      clinicId,
      name: "Doctor Overlap",
      email: "doctor-overlap@example.com",
      role: "doctor",
    });

    const procedureId = await t.run(async (ctx) => {
      return await ctx.db.insert("procedures", {
        clinicId,
        doctorId: doctor._id,
        name: "Consulta",
        durationMinutes: 15,
        isActive: true,
        isTelemedicine: false,
        isInPerson: true,
        createdAt: Date.now(),
      });
    });

    const base = new Date();
    base.setUTCDate(base.getUTCDate() + 7);
    base.setUTCHours(13, 0, 0, 0);
    while (base.getUTCDay() === 0 || base.getUTCDay() === 6) {
      base.setUTCDate(base.getUTCDate() + 1);
    }

    const busyStart = base.getTime();
    const busyEnd = busyStart + 30 * 60 * 1000;
    const rangeStart = busyStart + 15 * 60 * 1000;
    const rangeEnd = busyStart + 2 * 60 * 60 * 1000;

    await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: doctor._id,
      procedureId,
      startAt: busyStart,
      endAt: busyEnd,
      status: "confirmed",
      doctor: doctor.name,
      procedure: "Consulta",
      isTelemedicine: false,
    });

    const slots = await t.query(api.appointments.getAvailableSlots, {
      clinicId,
      doctorId: doctor._id,
      procedureId,
      startTime: new Date(rangeStart).toISOString(),
      endTime: new Date(rangeEnd).toISOString(),
      isTelemedicine: false,
    });

    const hasOverlappingStart = slots.some(
      (slot: { start: string }) => new Date(slot.start).getTime() === rangeStart,
    );

    expect(hasOverlappingStart).toBe(false);
  });

  it("should format Google Calendar datetimes in Sao Paulo local time", () => {
    const appointmentAtUtc = Date.UTC(2026, 0, 15, 12, 0, 0);

    expect(formatGoogleCalendarDateTime(appointmentAtUtc, "America/Sao_Paulo")).toBe(
      "2026-01-15T09:00:00",
    );
  });

  it("blocks telemedicine appointment creation when the doctor has no Google Calendar", async () => {
    const clinicId = "test-clinic-telemedicine-create-blocked";
    await ensureClinic(t, clinicId);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Telemedicine Patient",
      email: "telemedicine-create@example.com",
    });

    const doctor = await t.mutation(api.users.create, {
      authUserId: "doctor-telemedicine-create-blocked",
      clinicId,
      name: "Doctor No Google",
      email: "doctor-no-google@example.com",
      role: "doctor",
    });

    const error = await t
      .mutation(api.appointments.create, {
        clinicId,
        patientId: patient._id,
        doctorId: doctor._id,
        startAt: Date.now() + 24 * 60 * 60 * 1000,
        endAt: Date.now() + 25 * 60 * 60 * 1000,
        status: "pending",
        procedure: "Teleconsulta",
        isTelemedicine: true,
        patientEmail: patient.email,
        timeZone: "America/Sao_Paulo",
      })
      .catch((err) => err);

    expect(error).toBeInstanceOf(Error);
    expect(error.message).toBe(
      "Conecte o Google Calendar do médico em Integrações para usar teleconsulta.",
    );
  });

  it("blocks telemedicine rescheduling when the doctor has no Google Calendar", async () => {
    const clinicId = "test-clinic-telemedicine-update-blocked";
    await ensureClinic(t, clinicId);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Telemedicine Update Patient",
      email: "telemedicine-update@example.com",
    });

    const doctor = await t.mutation(api.users.create, {
      authUserId: "doctor-telemedicine-update-blocked",
      clinicId,
      name: "Doctor Update No Google",
      email: "doctor-update-no-google@example.com",
      role: "doctor",
    });

    const appointment = await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: doctor._id,
      startAt: Date.now() + 24 * 60 * 60 * 1000,
      endAt: Date.now() + 25 * 60 * 60 * 1000,
      status: "confirmed",
      doctor: doctor.name,
      procedure: "Consulta",
      isTelemedicine: false,
    });

    const error = await t
      .mutation(api.appointments.update, {
        id: appointment._id,
        clinicId,
        doctorId: doctor._id,
        startAt: appointment.startAt + 2 * 60 * 60 * 1000,
        endAt: appointment.endAt + 2 * 60 * 60 * 1000,
        isTelemedicine: true,
        rescheduleStatus: "rescheduled",
      })
      .catch((err) => err);

    expect(error).toBeInstanceOf(Error);
    expect(error.message).toBe(
      "Conecte o Google Calendar do médico em Integrações para usar teleconsulta.",
    );
  });

  it("creates a fallback telemedicine link when Google Calendar is unavailable", async () => {
    const clinicId = "test-clinic-telemedicine-fallback";
    await ensureClinic(t, clinicId);
    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Telemed Patient",
      email: "telemed@example.com",
      phone: "5511999991111",
    });

    const doctor = await t.mutation(api.users.create, {
      authUserId: "doctor-telemed-fallback",
      clinicId,
      name: "Doctor Telemed",
      email: "doctor-telemed@example.com",
      role: "doctor",
    });

    const appointment = await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: doctor._id,
      startAt: Date.now() + 24 * 60 * 60 * 1000,
      endAt: Date.now() + 25 * 60 * 60 * 1000,
      status: "confirmed",
      doctor: doctor.name,
      procedure: "Teleconsulta",
      isTelemedicine: true,
      patientEmail: patient.email,
      timeZone: "America/Sao_Paulo",
    });

    await t.action(internal.appointments.createGoogleMeetEvent, {
      appointmentId: appointment._id,
      summary: "Teleconsulta - Telemed Patient",
      startAt: appointment.startAt,
      endAt: appointment.endAt,
      timeZone: "America/Sao_Paulo",
      patientEmail: patient.email,
      doctorEmail: doctor.email,
    });

    const updatedAppointment = await t.run(async (ctx) => ctx.db.get(appointment._id));

    expect(updatedAppointment?.meetingLink).toBeUndefined();
    expect(updatedAppointment?.meetingError).toContain("Google Calendar not connected");
  });

  it("skips stale Google Meet creation when the appointment is no longer telemedicine", async () => {
    const clinicId = "test-clinic-telemedicine-stale-create";
    await ensureClinic(t, clinicId);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Stale Create Patient",
      email: "stale-create@example.com",
    });

    const doctor = await t.mutation(api.users.create, {
      authUserId: "doctor-stale-create",
      clinicId,
      name: "Doctor Stale Create",
      email: "doctor-stale-create@example.com",
      role: "doctor",
    });

    const appointment = await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: doctor._id,
      startAt: Date.now() + 24 * 60 * 60 * 1000,
      endAt: Date.now() + 25 * 60 * 60 * 1000,
      doctor: doctor.name,
      procedure: "Consulta",
      isTelemedicine: false,
    });

    const originalFetch = globalThis.fetch;
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock as typeof fetch);

    try {
      const result = await t.action(internal.appointments.createGoogleMeetEvent, {
        appointmentId: appointment._id,
        summary: "Teleconsulta - Stale Create Patient",
        startAt: appointment.startAt,
        endAt: appointment.endAt,
        timeZone: "America/Sao_Paulo",
        patientEmail: patient.email,
        doctorEmail: doctor.email,
      });

      expect(result.synced).toBe(false);
      expect(result.reason).toBe("not_telemedicine");
      expect(fetchMock).not.toHaveBeenCalled();
    } finally {
      vi.stubGlobal("fetch", originalFetch as typeof fetch);
    }
  });

  it("syncs the Google Meet event when a telemedicine appointment changes time", async () => {
    const clinicId = "test-clinic-telemedicine-sync";
    await ensureClinic(t, clinicId);
    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Telemed Sync Patient",
      email: "telemed-sync@example.com",
      phone: "5511999992222",
    });

    const doctor = await t.mutation(api.users.create, {
      authUserId: "doctor-telemed-sync",
      clinicId,
      name: "Doctor Telemed Sync",
      email: "doctor-telemed-sync@example.com",
      role: "doctor",
    });

    const originalStartAt = Date.now() + 24 * 60 * 60 * 1000;
    const appointment = await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: doctor._id,
      startAt: originalStartAt,
      endAt: originalStartAt + 60 * 60 * 1000,
      status: "confirmed",
      doctor: doctor.name,
      procedure: "Teleconsulta",
      isTelemedicine: true,
      patientEmail: patient.email,
      timeZone: "America/Sao_Paulo",
    });

    const rescheduledStartAt = originalStartAt + 2 * 60 * 60 * 1000;
    await t.run(async (ctx) => {
      await ctx.db.patch(appointment._id, {
        startAt: rescheduledStartAt,
        endAt: rescheduledStartAt + 60 * 60 * 1000,
        meetingLink: "https://meet.google.com/old-meet-link",
        calendarEventId: "google-event-123",
        conferenceData: {
          entryPoints: [
            {
              entryPointType: "video",
              uri: "https://meet.google.com/old-meet-link",
            },
          ],
        },
        meetingError: "stale error",
        updatedAt: Date.now(),
      });

      await ctx.db.insert("googleOAuthTokens", {
        clinicId,
        userId: doctor._id,
        accessToken: "google-access-token",
        refreshToken: "google-refresh-token",
        tokenType: "Bearer",
        primaryCalendarId: "primary",
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
    });

    const originalFetch = globalThis.fetch;
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            id: "google-event-123",
            conferenceData: {
              entryPoints: [
                {
                  entryPointType: "video",
                  uri: "https://meet.google.com/old-meet-link",
                },
              ],
            },
          }),
          {
            status: 200,
            headers: { "Content-Type": "application/json" },
          },
        ),
      )
      .mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            id: "google-event-123",
            conferenceData: {
              entryPoints: [
                {
                  entryPointType: "video",
                  uri: "https://meet.google.com/new-meet-link",
                },
              ],
            },
          }),
          {
            status: 200,
            headers: { "Content-Type": "application/json" },
          },
        ),
      );

    vi.stubGlobal("fetch", fetchMock as typeof fetch);

    try {
      const result = await t.action(internal.appointments.syncTelemedicineMeeting, {
        appointmentId: appointment._id,
      });

      expect(result.synced).toBe(true);
      expect(fetchMock).toHaveBeenCalledTimes(2);

      const patchUrl = fetchMock.mock.calls[1]?.[0];
      const patchInit = fetchMock.mock.calls[1]?.[1] as RequestInit;
      const patchBody = JSON.parse(String(patchInit.body));

      expect(String(patchUrl)).toContain("google-event-123");
      expect(String(patchUrl)).toContain("conferenceDataVersion=1");
      expect(patchInit.method).toBe("PATCH");
      expect(patchBody.start.dateTime).toBe(
        formatGoogleCalendarDateTime(rescheduledStartAt, "America/Sao_Paulo"),
      );
      expect(patchBody.end.dateTime).toBe(
        formatGoogleCalendarDateTime(rescheduledStartAt + 60 * 60 * 1000, "America/Sao_Paulo"),
      );
      expect(patchBody.conferenceData.entryPoints[0].uri).toBe(
        "https://meet.google.com/old-meet-link",
      );

      const updatedAppointment = await t.run(async (ctx) => ctx.db.get(appointment._id));
      expect(updatedAppointment?.meetingLink).toBe("https://meet.google.com/new-meet-link");
      expect(updatedAppointment?.calendarEventId).toBe("google-event-123");
      expect(updatedAppointment?.meetingError).toBeUndefined();
    } finally {
      vi.stubGlobal("fetch", originalFetch as typeof fetch);
    }
  });

  it("emails the updated telemedicine link when a rescheduled meeting is synced", async () => {
    const clinicId = "test-clinic-telemedicine-reschedule-email";
    await ensureClinic(t, clinicId);
    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Telemed Email Patient",
      email: "telemed-email@example.com",
      phone: "5511999994444",
    });

    const doctor = await t.mutation(api.users.create, {
      authUserId: "doctor-telemed-email",
      clinicId,
      name: "Doctor Email",
      email: "doctor-telemed-email@example.com",
      role: "doctor",
    });

    const originalStartAt = Date.now() + 24 * 60 * 60 * 1000;
    const appointment = await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: doctor._id,
      startAt: originalStartAt,
      endAt: originalStartAt + 60 * 60 * 1000,
      status: "confirmed",
      doctor: doctor.name,
      procedure: "Teleconsulta",
      isTelemedicine: true,
      rescheduleStatus: "rescheduled",
      patientEmail: patient.email,
      timeZone: "America/Sao_Paulo",
      meetingLink: "https://meet.google.com/old-meet-link",
      calendarEventId: "google-event-email-123",
      conferenceData: {
        entryPoints: [
          {
            entryPointType: "video",
            uri: "https://meet.google.com/old-meet-link",
          },
        ],
      },
    });

    await t.run(async (ctx) => {
      const now = Date.now();
      await ctx.db.patch(appointment._id, {
        startAt: originalStartAt + 2 * 60 * 60 * 1000,
        endAt: originalStartAt + 3 * 60 * 60 * 1000,
      });
      await ctx.db.insert("googleOAuthTokens", {
        clinicId,
        userId: doctor._id,
        accessToken: "google-access-token",
        refreshToken: "google-refresh-token",
        tokenType: "Bearer",
        primaryCalendarId: "primary",
        createdAt: now,
        updatedAt: now,
      });
    });

    const originalFetch = globalThis.fetch;
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            id: "google-event-email-123",
            conferenceData: {
              entryPoints: [
                {
                  entryPointType: "video",
                  uri: "https://meet.google.com/old-meet-link",
                },
              ],
            },
          }),
          { status: 200, headers: { "Content-Type": "application/json" } },
        ),
      )
      .mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            id: "google-event-email-123",
            conferenceData: {
              entryPoints: [
                {
                  entryPointType: "video",
                  uri: "https://meet.google.com/new-meet-link",
                },
              ],
            },
          }),
          { status: 200, headers: { "Content-Type": "application/json" } },
        ),
      );
    vi.stubGlobal("fetch", fetchMock as typeof fetch);

    try {
      const result = await t.action(internal.appointments.syncTelemedicineMeeting, {
        appointmentId: appointment._id,
        notifyPatientEmail: true,
      });

      expect(result.synced).toBe(true);
      expect(result.meetingLink).toBe("https://meet.google.com/new-meet-link");
      expect(sendMailMock).toHaveBeenCalledTimes(1);
      expect(sendMailMock.mock.calls[0]?.[0]).toMatchObject({
        to: patient.email,
        subject: "Novo link da teleconsulta reagendada - WhatsMed",
      });
      expect(String(sendMailMock.mock.calls[0]?.[0]?.html)).toContain(
        "https://meet.google.com/new-meet-link",
      );
    } finally {
      vi.stubGlobal("fetch", originalFetch as typeof fetch);
    }
  });

  it("emails the fallback telemedicine link when reschedule sync cannot reach Google", async () => {
    const clinicId = "test-clinic-telemedicine-reschedule-fallback-email";
    await ensureClinic(t, clinicId);
    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Telemed Fallback Patient",
      email: "telemed-fallback@example.com",
      phone: "5511999995555",
    });

    const doctor = await t.mutation(api.users.create, {
      authUserId: "doctor-telemed-fallback-email",
      clinicId,
      name: "Doctor Fallback",
      email: "doctor-telemed-fallback@example.com",
      role: "doctor",
    });

    const startAt = Date.now() + 24 * 60 * 60 * 1000;
    const appointment = await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: doctor._id,
      startAt,
      endAt: startAt + 60 * 60 * 1000,
      status: "confirmed",
      doctor: doctor.name,
      procedure: "Teleconsulta",
      isTelemedicine: true,
      rescheduleStatus: "rescheduled",
      patientEmail: patient.email,
      timeZone: "America/Sao_Paulo",
    });

    const result = await t.action(internal.appointments.syncTelemedicineMeeting, {
      appointmentId: appointment._id,
      notifyPatientEmail: true,
    });

    expect(result.synced).toBe(false);
    expect(result.meetingLink).toBeUndefined();
    expect(sendMailMock).not.toHaveBeenCalled();
  });

  it("keeps the existing Google Meet link when reschedule sync fails", async () => {
    const clinicId = "test-clinic-telemedicine-reschedule-preserve-link";
    await ensureClinic(t, clinicId);
    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Telemed Preserve Patient",
      email: "telemed-preserve@example.com",
      phone: "5511999995566",
    });

    const doctor = await t.mutation(api.users.create, {
      authUserId: "doctor-telemed-preserve-link",
      clinicId,
      name: "Doctor Preserve",
      email: "doctor-telemed-preserve@example.com",
      role: "doctor",
    });

    const startAt = Date.now() + 24 * 60 * 60 * 1000;
    const appointment = await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: doctor._id,
      startAt,
      endAt: startAt + 60 * 60 * 1000,
      status: "confirmed",
      doctor: doctor.name,
      procedure: "Teleconsulta",
      isTelemedicine: true,
      rescheduleStatus: "rescheduled",
      patientEmail: patient.email,
      timeZone: "America/Sao_Paulo",
      meetingLink: "https://meet.google.com/existing-meet-link",
    });

    const result = await t.action(internal.appointments.syncTelemedicineMeeting, {
      appointmentId: appointment._id,
      notifyPatientEmail: true,
    });

    expect(result.synced).toBe(false);
    expect(result.meetingLink).toBe("https://meet.google.com/existing-meet-link");
    expect(sendMailMock).toHaveBeenCalledTimes(1);
    expect(String(sendMailMock.mock.calls[0]?.[0]?.html)).toContain(
      "https://meet.google.com/existing-meet-link",
    );

    const updatedAppointment = await t.run(async (ctx) => ctx.db.get(appointment._id));
    expect(updatedAppointment?.meetingLink).toBe("https://meet.google.com/existing-meet-link");
    expect(updatedAppointment?.calendarEventId).toBeUndefined();
    expect(updatedAppointment?.conferenceData).toBeUndefined();
  });

  it("deletes the previous Google event and recreates it when the doctor changes", async () => {
    const clinicId = "test-clinic-telemedicine-doctor-change";
    await ensureClinic(t, clinicId);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Doctor Change Patient",
      email: "doctor-change@example.com",
      phone: "5511999993333",
    });

    const previousDoctor = await t.mutation(api.users.create, {
      authUserId: "doctor-old",
      clinicId,
      name: "Doctor Old",
      email: "doctor-old@example.com",
      role: "doctor",
    });

    const newDoctor = await t.mutation(api.users.create, {
      authUserId: "doctor-new",
      clinicId,
      name: "Doctor New",
      email: "doctor-new@example.com",
      role: "doctor",
    });

    const appointment = await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: newDoctor._id,
      startAt: Date.now() + 24 * 60 * 60 * 1000,
      endAt: Date.now() + 25 * 60 * 60 * 1000,
      doctor: newDoctor.name,
      procedure: "Teleconsulta",
      isTelemedicine: true,
      patientEmail: patient.email,
      doctorEmail: newDoctor.email,
      timeZone: "America/Sao_Paulo",
      calendarEventId: "old-google-event",
      meetingLink: "https://meet.google.com/old-meet-link",
    });

    await t.run(async (ctx) => {
      const now = Date.now();
      await ctx.db.insert("googleOAuthTokens", {
        clinicId,
        userId: previousDoctor._id,
        accessToken: "old-access-token",
        refreshToken: "old-refresh-token",
        tokenType: "Bearer",
        primaryCalendarId: "primary",
        createdAt: now,
        updatedAt: now,
      });
      await ctx.db.insert("googleOAuthTokens", {
        clinicId,
        userId: newDoctor._id,
        accessToken: "new-access-token",
        refreshToken: "new-refresh-token",
        tokenType: "Bearer",
        primaryCalendarId: "primary",
        createdAt: now,
        updatedAt: now,
      });
    });

    const originalFetch = globalThis.fetch;
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(new Response(null, { status: 204 }))
      .mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            id: "new-google-event",
            conferenceData: {
              entryPoints: [
                {
                  entryPointType: "video",
                  uri: "https://meet.google.com/new-meet-link",
                },
              ],
            },
          }),
          { status: 200, headers: { "Content-Type": "application/json" } },
        ),
      );

    vi.stubGlobal("fetch", fetchMock as typeof fetch);

    try {
      const result = await t.action(internal.appointments.syncTelemedicineMeeting, {
        appointmentId: appointment._id,
        previousDoctorId: previousDoctor._id,
        previousCalendarEventId: "old-google-event",
        previousWasTelemedicine: true,
      });

      expect(result.synced).toBe(true);
      expect(fetchMock).toHaveBeenCalledTimes(2);
      expect(String(fetchMock.mock.calls[0]?.[0])).toContain("old-google-event");
      expect(String(fetchMock.mock.calls[0]?.[0])).toContain("sendUpdates=all");
      expect((fetchMock.mock.calls[0]?.[1] as RequestInit)?.method).toBe("DELETE");
      expect(String(fetchMock.mock.calls[1]?.[0])).toContain("conferenceDataVersion=1");
      expect((fetchMock.mock.calls[1]?.[1] as RequestInit)?.method).toBe("POST");

      const updatedAppointment = await t.run(async (ctx) => ctx.db.get(appointment._id));
      expect(updatedAppointment?.calendarEventId).toBe("new-google-event");
      expect(updatedAppointment?.meetingLink).toBe("https://meet.google.com/new-meet-link");
    } finally {
      vi.stubGlobal("fetch", originalFetch as typeof fetch);
    }
  });

  it("deletes the Google event and clears local meeting data when telemedicine is removed", async () => {
    const clinicId = "test-clinic-telemedicine-disable";
    await ensureClinic(t, clinicId);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Disable Telemedicine Patient",
      email: "disable-telemed@example.com",
    });

    const doctor = await t.mutation(api.users.create, {
      authUserId: "doctor-disable-telemed",
      clinicId,
      name: "Doctor Disable",
      email: "doctor-disable@example.com",
      role: "doctor",
    });

    const appointment = await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: doctor._id,
      startAt: Date.now() + 24 * 60 * 60 * 1000,
      endAt: Date.now() + 25 * 60 * 60 * 1000,
      doctor: doctor.name,
      procedure: "Consulta",
      isTelemedicine: false,
      calendarEventId: "event-to-delete",
      meetingLink: "https://meet.google.com/remove-link",
      conferenceData: {
        entryPoints: [{ entryPointType: "video", uri: "https://meet.google.com/remove-link" }],
      },
    });

    await t.run(async (ctx) => {
      const now = Date.now();
      await ctx.db.insert("googleOAuthTokens", {
        clinicId,
        userId: doctor._id,
        accessToken: "disable-access-token",
        refreshToken: "disable-refresh-token",
        tokenType: "Bearer",
        primaryCalendarId: "primary",
        createdAt: now,
        updatedAt: now,
      });
    });

    const originalFetch = globalThis.fetch;
    const fetchMock = vi.fn().mockResolvedValueOnce(new Response(null, { status: 204 }));
    vi.stubGlobal("fetch", fetchMock as typeof fetch);

    try {
      const result = await t.action(internal.appointments.syncTelemedicineMeeting, {
        appointmentId: appointment._id,
        previousDoctorId: doctor._id,
        previousCalendarEventId: "event-to-delete",
        previousWasTelemedicine: true,
      });

      expect(result.synced).toBe(false);
      expect(result.reason).toBe("not_telemedicine");
      expect(fetchMock).toHaveBeenCalledTimes(1);
      expect((fetchMock.mock.calls[0]?.[1] as RequestInit)?.method).toBe("DELETE");

      const updatedAppointment = await t.run(async (ctx) => ctx.db.get(appointment._id));
      expect(updatedAppointment?.calendarEventId).toBeUndefined();
      expect(updatedAppointment?.meetingLink).toBeUndefined();
      expect(updatedAppointment?.conferenceData).toBeUndefined();
    } finally {
      vi.stubGlobal("fetch", originalFetch as typeof fetch);
    }
  });

  it("should update the same appointment when rescheduling", async () => {
    const clinicId = "test-clinic-reschedule";
    await ensureClinic(t, clinicId);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Reschedule Patient",
      email: "reschedule@example.com",
    });

    const doctor = await t.mutation(api.users.create, {
      authUserId: "doctor-reschedule",
      clinicId,
      name: "Doctor Reschedule",
      email: "doctor-reschedule@example.com",
      role: "doctor",
    });

    const procedureId = await t.run(async (ctx) => {
      return await ctx.db.insert("procedures", {
        clinicId,
        doctorId: doctor._id,
        name: "Consulta Retorno",
        durationMinutes: 30,
        isActive: true,
        isTelemedicine: false,
        isInPerson: true,
        createdAt: Date.now(),
      });
    });

    const originalStartAt = Date.now() + 24 * 60 * 60 * 1000;
    const appointment = await insertAppointment({
      clinicId,
      patientId: patient._id,
      doctorId: doctor._id,
      procedureId,
      startAt: originalStartAt,
      endAt: originalStartAt + 30 * 60 * 1000,
      status: "confirmed",
      doctor: doctor.name,
      procedure: "Consulta Retorno",
      isTelemedicine: false,
    });

    const rescheduledStartAt = originalStartAt + 2 * 60 * 60 * 1000;
    const updatedAppointment = await t.mutation(api.appointments.update, {
      id: appointment._id,
      clinicId,
      doctorId: doctor._id,
      procedureId,
      procedure: "Consulta Retorno",
      startAt: rescheduledStartAt,
      endAt: rescheduledStartAt + 30 * 60 * 1000,
    });

    expect(updatedAppointment?._id).toBe(appointment._id);
    expect(updatedAppointment?.startAt).toBe(rescheduledStartAt);

    const appointments = await t.run(async (ctx) => {
      return await ctx.db
        .query("appointments")
        .filter((q) =>
          q.and(q.eq(q.field("clinicId"), clinicId), q.eq(q.field("patientId"), patient._id)),
        )
        .collect();
    });

    expect(appointments).toHaveLength(1);
    expect(appointments[0]?._id).toBe(appointment._id);
    expect(appointments[0]?.startAt).toBe(rescheduledStartAt);
  });
});
