import { describe, expect, it, vi } from "vitest";

import { ensureEvolutionInstanceRecord } from "../convex/integrations.js";

const webhookUrl = "https://example.convex.site/api/webhooks/evolution";

describe("ensureEvolutionInstanceRecord", () => {
  it("reuses an existing evolution instance with credentials", async () => {
    const runMutation = vi.fn();
    const createInstance = vi.fn();
    const existing = {
      clinicId: "clinic-1",
      instanceName: "clinic_clinic-1",
      apikey: "api-key",
      provider: "evolution",
      status: "connected",
    };

    const result = await ensureEvolutionInstanceRecord({
      ctx: { runMutation },
      clinicId: "clinic-1",
      instance: existing as any,
      client: { createInstance },
      webhookUrl,
    });

    expect(createInstance).not.toHaveBeenCalled();
    expect(runMutation).not.toHaveBeenCalled();
    expect(result).toBe(existing);
  });

  it("reuses a legacy evolution instance name when credentials already exist", async () => {
    const runMutation = vi.fn();
    const createInstance = vi.fn();
    const existing = {
      clinicId: "clinic-legacy",
      instanceName: "legacy_evolution_name",
      apikey: "api-key",
      provider: "evolution",
      status: "connected",
    };

    const result = await ensureEvolutionInstanceRecord({
      ctx: { runMutation },
      clinicId: "clinic-legacy",
      instance: existing as any,
      client: { createInstance },
      webhookUrl,
    });

    expect(createInstance).not.toHaveBeenCalled();
    expect(runMutation).not.toHaveBeenCalled();
    expect(result).toBe(existing);
  });

  it("bootstraps a new evolution instance when none exists", async () => {
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const createInstance = vi.fn().mockResolvedValue({
      hash: { apikey: "new-api-key" },
    });

    const result = await ensureEvolutionInstanceRecord({
      ctx: { runMutation },
      clinicId: "clinic-2",
      instance: null,
      client: { createInstance },
      webhookUrl,
    });

    expect(createInstance).toHaveBeenCalledWith("clinic_clinic-2", webhookUrl);
    expect(runMutation).toHaveBeenCalledWith(expect.anything(), {
      clinicId: "clinic-2",
      instanceName: "clinic_clinic-2",
      apikey: "new-api-key",
      status: "disconnected",
    });
    expect(result).toMatchObject({
      clinicId: "clinic-2",
      instanceName: "clinic_clinic-2",
      apikey: "new-api-key",
      provider: "evolution",
      status: "disconnected",
    });
  });

  it("replaces a meta placeholder before connecting evolution", async () => {
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const createInstance = vi.fn().mockResolvedValue({
      hash: { apikey: "evolution-key" },
    });

    const result = await ensureEvolutionInstanceRecord({
      ctx: { runMutation },
      clinicId: "clinic-3",
      instance: {
        clinicId: "clinic-3",
        instanceName: "meta_clinic-3",
        provider: "meta",
        status: "disconnected",
      } as any,
      client: { createInstance },
      webhookUrl,
    });

    expect(createInstance).toHaveBeenCalledWith("clinic_clinic-3", webhookUrl);
    expect(result).toMatchObject({
      clinicId: "clinic-3",
      instanceName: "clinic_clinic-3",
      apikey: "evolution-key",
      provider: "evolution",
      status: "disconnected",
    });
  });

  it("reuses an already existing evolution instance when the API says the name is in use", async () => {
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const createInstance = vi
      .fn()
      .mockRejectedValue(
        new Error(
          'Evolution API error: 403 Forbidden - {"status":403,"error":"Forbidden","response":{"message":["This name \"clinic_clinic-4\" is already in use."]}}',
        ),
      );

    const result = await ensureEvolutionInstanceRecord({
      ctx: { runMutation },
      clinicId: "clinic-4",
      instance: {
        clinicId: "clinic-4",
        instanceName: "meta_clinic-4",
        provider: "meta",
        status: "disconnected",
      } as any,
      client: { createInstance },
      webhookUrl,
    });

    expect(createInstance).toHaveBeenCalledWith("clinic_clinic-4", webhookUrl);
    expect(runMutation).toHaveBeenCalledWith(expect.anything(), {
      clinicId: "clinic-4",
      instanceName: "clinic_clinic-4",
      apikey: undefined,
      status: "disconnected",
    });
    expect(result).toMatchObject({
      clinicId: "clinic-4",
      instanceName: "clinic_clinic-4",
      apikey: undefined,
      provider: "evolution",
      status: "disconnected",
    });
  });
});
