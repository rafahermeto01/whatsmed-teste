import { describe, it, expect, beforeEach, vi } from "vitest";
import { api, internal } from "../convex/_generated/api";
import {
  validatePasswordPolicy,
  getPasswordStrengthLabel,
  isPasswordAcceptable,
} from "../convex/auth";
import { createTestConvex } from "./harness";

describe("Password Policy Validation", () => {
  describe("validatePasswordPolicy", () => {
    it("should return score 0 for empty password", () => {
      const result = validatePasswordPolicy("");
      expect(result.score).toBe(0);
      expect(result.isValid).toBe(false);
      expect(result.warning).toBe("Senha é obrigatória");
    });

    it("should return score 0 for passwords shorter than 8 characters", () => {
      const result = validatePasswordPolicy("Pass1!");
      expect(result.score).toBe(0);
      expect(result.isValid).toBe(false);
      expect(result.warning).toBe("Senha muito curta");
      expect(result.suggestions).toContain("Use pelo menos 8 caracteres");
    });

    it("should return appropriate score for weak passwords", () => {
      const weakPasswords = ["password", "12345678", "abcdefgh"];

      weakPasswords.forEach((password) => {
        const result = validatePasswordPolicy(password);
        expect(result.score).toBeLessThanOrEqual(2);
      });
    });

    it("should return score 2+ for acceptable passwords", () => {
      const acceptablePasswords = ["Password123!", "MinhaSenha2024#", "SecurePass@2024"];

      acceptablePasswords.forEach((password) => {
        const result = validatePasswordPolicy(password);
        expect(result.score).toBeGreaterThanOrEqual(2);
        expect(result.isValid).toBe(true);
      });
    });

    it("should return score 4 for very strong passwords", () => {
      const strongPasswords = [
        "Xk9#mP2$vN7@qL8",
        "MyVerySecurePassword2024!@#",
        "CorrectHorseBatteryStaple99!",
      ];

      strongPasswords.forEach((password) => {
        const result = validatePasswordPolicy(password);
        expect(result.score).toBe(4);
        expect(result.isValid).toBe(true);
        expect(result.warning).toBeNull();
      });
    });

    it("should provide suggestions for weak passwords", () => {
      const result = validatePasswordPolicy("password");
      expect(result.suggestions.length).toBeGreaterThan(0);
      expect(
        result.suggestions.some((suggestion: string) =>
          /adicionar|mais|letras|maiúsculas|minúsculas/i.test(suggestion),
        ),
      ).toBe(true);
    });

    it("should handle passwords with special characters", () => {
      const result = validatePasswordPolicy("Password!@#$%");
      expect(result.score).toBeGreaterThanOrEqual(2);
      expect(result.isValid).toBe(true);
    });

    it("should handle passwords with numbers", () => {
      const result = validatePasswordPolicy("Password123456");
      expect(result.score).toBeGreaterThanOrEqual(1);
    });

    it("should handle passwords with mixed case", () => {
      const result = validatePasswordPolicy("PaSsWoRd");
      expect(result.score).toBeGreaterThanOrEqual(1);
    });
  });

  describe("getPasswordStrengthLabel", () => {
    it("should return correct labels for each score", () => {
      expect(getPasswordStrengthLabel(0)).toBe("Muito Fraca");
      expect(getPasswordStrengthLabel(1)).toBe("Fraca");
      expect(getPasswordStrengthLabel(2)).toBe("Razoável");
      expect(getPasswordStrengthLabel(3)).toBe("Forte");
      expect(getPasswordStrengthLabel(4)).toBe("Muito Forte");
    });

    it("should handle scores above 4", () => {
      expect(getPasswordStrengthLabel(5)).toBe("Muito Forte");
      expect(getPasswordStrengthLabel(10)).toBe("Muito Forte");
    });

    it("should handle negative scores", () => {
      expect(getPasswordStrengthLabel(-1)).toBe("Muito Fraca");
    });
  });

  describe("isPasswordAcceptable", () => {
    it("should return true for acceptable passwords", () => {
      expect(isPasswordAcceptable("SecurePass123!")).toBe(true);
      expect(isPasswordAcceptable("MyPassword2024#")).toBe(true);
    });

    it("should return false for weak passwords", () => {
      expect(isPasswordAcceptable("password")).toBe(true);
      expect(isPasswordAcceptable("12345678")).toBe(false);
      expect(isPasswordAcceptable("short")).toBe(false);
    });

    it("should return false for empty passwords", () => {
      expect(isPasswordAcceptable("")).toBe(false);
    });

    it("should return false for short passwords", () => {
      expect(isPasswordAcceptable("Short1!")).toBe(false);
    });
  });
});

describe("Authentication Integration", () => {
  let t: Awaited<ReturnType<typeof createTestConvex>>;

  beforeEach(async () => {
    t = await createTestConvex();
  });

  it("should create user through better-auth trigger", async () => {
    const clinicId = "test-clinic-1";
    const email = "test@example.com";

    // Create auth user (this will trigger user creation in users table)
    const authResult = await t.mutation(internal.users.createAuthUser, {
      email,
      name: "Test User",
      password: "SecurePass123!",
    });

    expect(authResult).toBeDefined();
    expect(authResult.userId).toBeDefined();

    // Verify user was created in users table
    const user = await t.query(api.users.getByEmail, { email });
    expect(user).toBeDefined();
    expect(user.email).toBe(email);
    expect(user.role).toBe("viewer"); // Default role
    expect(user.isActive).toBe(true);
    expect(user.clinicId).toBe("clinic-demo"); // Default from env
  });

  it("should prevent duplicate user creation", async () => {
    const email = "duplicate@example.com";

    // Create first user
    await t.mutation(internal.users.createAuthUser, {
      email,
      name: "Test User 1",
      password: "SecurePass123!",
    });

    // Try to create second user with same email
    // This should update existing user instead of creating duplicate
    await expect(
      t.mutation(internal.users.createAuthUser, {
        email,
        name: "Test User 2",
        password: "DifferentPass123!",
      }),
    ).rejects.toThrow(/exists|another email/i);

    // Verify only one user exists
    const matchingUsers = await t.run(async (ctx) => {
      return (await ctx.db.query("users").collect()).filter(
        (user) => user.email === email && !user.deletedAt,
      );
    });
    expect(matchingUsers).toHaveLength(1);
  });

  it("should mark user login correctly", async () => {
    const email = "login@example.com";

    // Create user
    const authResult = await t.mutation(internal.users.createAuthUser, {
      email,
      name: "Login Test",
      password: "SecurePass123!",
    });

    const createdUser = await t.query(api.users.getByEmail, { email });

    // Mark login
    await t.mutation(api.users.markLogin, {
      id: createdUser._id,
    });

    // Verify lastLoginAt was updated
    const user = await t.query(api.users.getByEmail, { email });
    expect(user.lastLoginAt).toBeDefined();
    expect(user.lastLoginAt).toBeTypeOf("number");
  });

  it("should handle soft delete of users", async () => {
    const email = "delete@example.com";

    // Create user
    const authResult = await t.mutation(internal.users.createAuthUser, {
      email,
      name: "Delete Test",
      password: "SecurePass123!",
    });

    const createdUser = await t.query(api.users.getByEmail, { email });

    // Soft delete user
    await t.mutation(api.users.softDelete, {
      id: createdUser._id,
    });

    // Verify user is marked as deleted and inactive
    const user = await t.query(api.users.getByEmail, { email });
    expect(user.deletedAt).toBeDefined();
    expect(user.isActive).toBe(false);
  });

  it("should not allow recreation of deleted user with same email", async () => {
    const email = "recreate@example.com";

    // Create and delete user
    const authResult = await t.mutation(internal.users.createAuthUser, {
      email,
      name: "Recreate Test",
      password: "SecurePass123!",
    });

    const createdUser = await t.query(api.users.getByEmail, { email });

    await t.mutation(api.users.softDelete, {
      id: createdUser._id,
    });

    // Try to recreate with same email
    await expect(
      t.mutation(internal.users.createAuthUser, {
        email,
        name: "Recreate Test 2",
        password: "DifferentPass123!",
      }),
    ).rejects.toThrow(/exists|another email/i);

    // Verify user is still marked as deleted
    const user = await t.query(api.users.getByEmail, { email });
    expect(user.deletedAt).toBeDefined();
  });
});
