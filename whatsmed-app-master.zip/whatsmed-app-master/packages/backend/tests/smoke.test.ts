import { describe, expect, it } from "vitest";

describe("backend smoke", () => {
  it("runs", () => {
    expect(1).toBe(1);
  });
});
