import { describe, expect, it, vi } from "vitest";

import {
  checkDoctorAvailabilityTool,
  createInternalTicketTool,
  getAiSettingsTool,
  getAvailableHoursTool,
  getClinicInfoTool,
  listDoctorsBySpecialtyTool,
  scheduleReminderTool,
  updatePatientDataTool,
} from "../mastra/tools.js";

describe("Mastra clinic-scoped tools", () => {
  it("binds getClinicInfo to the backend clinicId instead of model-provided args", async () => {
    const runQuery = vi.fn().mockResolvedValue({ clinicId: "clinic-real", name: "Clinica Real" });
    const tool = getClinicInfoTool({ runQuery } as any, "clinic-real") as any;

    const result = await tool.execute({ context: { clinicId: "Clinica Teste Rafael H" } });

    expect(runQuery).toHaveBeenCalledWith(expect.anything(), { clinicId: "clinic-real" });
    expect(result).toEqual({
      clinic: { clinicId: "clinic-real", name: "Clinica Real" },
      found: true,
    });
  });

  it("returns found false instead of throwing when clinic record is missing", async () => {
    const runQuery = vi.fn().mockResolvedValue(null);
    const tool = getClinicInfoTool({ runQuery } as any, "clinic-missing") as any;

    const result = await tool.execute({ context: { clinicId: "wrong-name" } });

    expect(result).toEqual({
      clinic: null,
      found: false,
    });
  });

  it("binds getAiSettings to the backend clinicId instead of model-provided args", async () => {
    const runQuery = vi.fn().mockResolvedValue({ clinicId: "clinic-real", enabled: true });
    const tool = getAiSettingsTool({ runQuery } as any, "clinic-real") as any;

    const result = await tool.execute({ context: { clinicId: "Clinica Teste Rafael H" } });

    expect(runQuery).toHaveBeenCalledWith(expect.anything(), { clinicId: "clinic-real" });
    expect(result).toEqual({
      settings: { clinicId: "clinic-real", enabled: true },
      found: true,
    });
  });

  it("returns all slots for inclusive two-day doctor availability searches", async () => {
    const doctorId = "jabcdefghi67890klmnopqrstu78901";
    const slots = Array.from({ length: 30 }, (_, index) => {
      const baseTimestamp = Date.parse(
        index < 15 ? "2026-04-10T12:00:00.000Z" : "2026-04-11T12:00:00.000Z",
      );
      const startTimestamp = baseTimestamp + (index % 15) * 15 * 60 * 1000;

      return {
        start: new Date(startTimestamp).toISOString(),
        end: new Date(startTimestamp + 15 * 60 * 1000).toISOString(),
        doctorId,
        doctorName: "Dr. Josefino",
      };
    });

    (global as any).ConvexInternal = { users: { searchDoctors: "searchDoctors" } };

    const runQuery = vi
      .fn()
      .mockResolvedValueOnce([{ _id: doctorId, name: "Dr. Josefino" }])
      .mockResolvedValueOnce(slots);

    const tool = checkDoctorAvailabilityTool({ runQuery } as any, "clinic-real") as any;
    const result = await tool.execute({
      context: {
        doctorName: "Josefino",
        startDate: "2026-04-10T00:00:00Z",
        endDate: "2026-04-11T00:00:00Z",
      },
    });

    expect(runQuery).toHaveBeenNthCalledWith(
      2,
      expect.anything(),
      expect.objectContaining({
        startDate: "2026-04-10T03:00:00.000Z",
        endDate: "2026-04-12T03:00:00.000Z",
        maxSlots: 200,
      }),
    );
    expect(result.count).toBe(30);
    expect(result.slots).toHaveLength(30);
    expect(result.ranges).toHaveLength(2);
    expect(result.ranges[0]).toEqual(
      expect.objectContaining({
        date: "2026-04-10",
        displayText: "das 09:00 as 12:45",
        slotCount: 15,
      }),
    );
    expect(new Set(result.slots.map((slot: { date: string }) => slot.date))).toEqual(
      new Set(["2026-04-10", "2026-04-11"]),
    );
  });

  it("accepts null optional args in doctor availability tool", async () => {
    const doctorId = "jnullsafe67890klmnopqrstu7890123";
    (global as any).ConvexInternal = { users: { searchDoctors: "searchDoctors" } };

    const runQuery = vi
      .fn()
      .mockResolvedValueOnce([{ _id: doctorId, name: "Dr. Rafael" }])
      .mockResolvedValueOnce([]);

    const tool = checkDoctorAvailabilityTool({ runQuery } as any, "clinic-real") as any;
    const result = await tool.execute({
      context: {
        doctorName: "Dr Rafael",
        startDate: "2026-04-25T00:00:00Z",
        endDate: null,
        procedureName: null,
        period: "night",
      },
    });

    expect(runQuery).toHaveBeenNthCalledWith(
      2,
      expect.anything(),
      expect.objectContaining({
        startDate: "2026-04-25T03:00:00.000Z",
        endDate: "2026-04-26T03:00:00.000Z",
        procedureId: undefined,
        period: undefined,
      }),
    );
    expect(result.count).toBe(0);
    expect(result.requestedPeriod).toBe("night");
    expect(result.requestedPeriodCount).toBe(0);
  });

  it("keeps full-day doctor availability while returning a focused period subset", async () => {
    const doctorId = "jperiodfocus67890klmnopqrstu7890";
    const slots = [
      {
        start: "2026-04-25T12:00:00.000Z",
        end: "2026-04-25T12:15:00.000Z",
        doctorId,
        doctorName: "Dr. Rafael",
      },
      {
        start: "2026-04-25T16:00:00.000Z",
        end: "2026-04-25T16:15:00.000Z",
        doctorId,
        doctorName: "Dr. Rafael",
      },
      {
        start: "2026-04-25T22:00:00.000Z",
        end: "2026-04-25T22:15:00.000Z",
        doctorId,
        doctorName: "Dr. Rafael",
      },
    ];

    (global as any).ConvexInternal = { users: { searchDoctors: "searchDoctors" } };

    const runQuery = vi
      .fn()
      .mockResolvedValueOnce([{ _id: doctorId, name: "Dr. Rafael" }])
      .mockResolvedValueOnce(slots);

    const tool = checkDoctorAvailabilityTool({ runQuery } as any, "clinic-real") as any;
    const result = await tool.execute({
      context: {
        doctorName: "Dr Rafael",
        startDate: "2026-04-25T00:00:00Z",
        period: "afternoon",
      },
    });

    expect(runQuery).toHaveBeenNthCalledWith(
      2,
      expect.anything(),
      expect.objectContaining({
        period: undefined,
        maxSlots: 200,
      }),
    );
    expect(result.count).toBe(3);
    expect(result.requestedPeriod).toBe("afternoon");
    expect(result.requestedPeriodCount).toBe(1);
    expect(result.requestedPeriodSlots).toHaveLength(1);
    expect(result.requestedPeriodSlots[0]).toEqual(
      expect.objectContaining({
        time: "13:00",
      }),
    );
    expect(result.requestedPeriodRanges).toEqual([
      expect.objectContaining({
        displayText: "13:00",
      }),
    ]);
  });

  it("normalizes null specialty filters before listDoctorsBySpecialty query", async () => {
    (global as any).ConvexInternal = {
      users: { listDoctorsBySpecialty: "listDoctorsBySpecialty" },
    };
    const runQuery = vi.fn().mockResolvedValue({ exactMatch: true, doctors: [], suggestion: null });

    const tool = listDoctorsBySpecialtyTool({ runQuery } as any, "clinic-real") as any;
    await tool.execute({
      context: {
        specialty: null,
      },
    });

    expect(runQuery).toHaveBeenCalledWith(expect.anything(), {
      clinicId: "clinic-real",
      specialty: undefined,
    });
  });

  it("returns all available hours for a day without trimming to 25 slots", async () => {
    const doctorId = "jabcdefghijk67890lmnopqrstuv678";
    const procedureId = "kabcdefghijk67890lmnopqrstuv678";
    const telemedicineSlots = Array.from({ length: 20 }, (_, index) => {
      const startTimestamp = Date.parse("2026-04-12T12:00:00.000Z") + index * 15 * 60 * 1000;
      return {
        start: new Date(startTimestamp).toISOString(),
        end: new Date(startTimestamp + 15 * 60 * 1000).toISOString(),
      };
    });
    const inPersonSlots = Array.from({ length: 20 }, (_, index) => {
      const startTimestamp = Date.parse("2026-04-12T17:00:00.000Z") + index * 15 * 60 * 1000;
      return {
        start: new Date(startTimestamp).toISOString(),
        end: new Date(startTimestamp + 15 * 60 * 1000).toISOString(),
      };
    });

    const runQuery = vi
      .fn()
      .mockResolvedValueOnce({ isTelemedicine: true, isInPerson: true })
      .mockResolvedValueOnce(telemedicineSlots)
      .mockResolvedValueOnce(inPersonSlots);

    const tool = getAvailableHoursTool({ runQuery } as any, "clinic-real") as any;
    const result = await tool.execute({
      context: {
        doctorId,
        procedureId,
        date: "2026-04-12",
      },
    });

    expect(runQuery.mock.calls[1]?.[1]).toEqual(expect.objectContaining({ maxSlots: 200 }));
    expect(runQuery.mock.calls[2]?.[1]).toEqual(expect.objectContaining({ maxSlots: 200 }));
    expect(result.count).toBe(40);
    expect(result.slots).toHaveLength(40);
    expect(result.ranges).toEqual([
      expect.objectContaining({
        date: "2026-04-12",
        displayText: "das 09:00 as 19:00",
        slotCount: 40,
      }),
    ]);
    expect(result.slots.some((slot: { startTime: string }) => slot.startTime === "18:45")).toBe(
      true,
    );
  });

  it("includes next-day slots after 20:00 in Brasilia and marks them for the AI", async () => {
    const dateNowSpy = vi
      .spyOn(Date, "now")
      .mockReturnValue(new Date("2026-04-12T23:30:00.000Z").getTime());

    const doctorId = "jabcdeffedcba67890lmnopqrstuv67";
    const procedureId = "kabcdeffedcba67890lmnopqrstuv67";
    const sameDaySlots = [
      {
        start: "2026-04-12T23:45:00.000Z",
        end: "2026-04-13T00:00:00.000Z",
      },
    ];
    const nextDaySlots = [
      {
        start: "2026-04-13T12:00:00.000Z",
        end: "2026-04-13T12:15:00.000Z",
      },
      {
        start: "2026-04-13T12:15:00.000Z",
        end: "2026-04-13T12:30:00.000Z",
      },
    ];

    const runQuery = vi
      .fn()
      .mockResolvedValueOnce(sameDaySlots)
      .mockResolvedValueOnce(nextDaySlots);

    const tool = getAvailableHoursTool({ runQuery } as any, "clinic-real") as any;
    const result = await tool.execute({
      context: {
        doctorId,
        procedureId,
        date: "2026-04-12",
        isTelemedicine: true,
      },
    });

    expect(runQuery.mock.calls[0]?.[1]).toEqual(expect.objectContaining({ date: "2026-04-12" }));
    expect(runQuery.mock.calls[1]?.[1]).toEqual(expect.objectContaining({ date: "2026-04-13" }));
    expect(result.count).toBe(3);
    expect(result.ranges).toEqual([
      expect.objectContaining({
        date: "2026-04-12",
        displayText: "20:45",
        isNextDayAvailability: false,
      }),
      expect.objectContaining({
        date: "2026-04-13",
        displayText: "das 09:00 as 09:30",
        isNextDayAvailability: true,
      }),
    ]);
    expect(
      result.slots.some(
        (slot: { date: string; isNextDayAvailability: boolean }) =>
          slot.date === "2026-04-13" && slot.isNextDayAvailability,
      ),
    ).toBe(true);
    expect(result.message).toContain("próximo dia");

    dateNowSpy.mockRestore();
  });

  it("keeps full-day slots in getAvailableHours while exposing the requested period subset", async () => {
    const doctorId = "jfullperiod67890klmnopqrstu78901";
    const procedureId = "kfullperiod67890klmnopqrstu78901";
    const sameDaySlots = [
      {
        start: "2026-04-12T12:00:00.000Z",
        end: "2026-04-12T12:15:00.000Z",
      },
      {
        start: "2026-04-12T16:00:00.000Z",
        end: "2026-04-12T16:15:00.000Z",
      },
      {
        start: "2026-04-12T22:00:00.000Z",
        end: "2026-04-12T22:15:00.000Z",
      },
    ];

    const runQuery = vi.fn().mockResolvedValueOnce(sameDaySlots);

    const tool = getAvailableHoursTool({ runQuery } as any, "clinic-real") as any;
    const result = await tool.execute({
      context: {
        doctorId,
        procedureId,
        date: "2026-04-12",
        isTelemedicine: true,
        period: "afternoon",
      },
    });

    expect(runQuery.mock.calls[0]?.[1]).toEqual(
      expect.objectContaining({
        date: "2026-04-12",
        maxSlots: 200,
      }),
    );
    expect(runQuery.mock.calls[0]?.[1]).not.toHaveProperty("period");
    expect(result.count).toBe(3);
    expect(result.requestedPeriod).toBe("afternoon");
    expect(result.requestedPeriodCount).toBe(1);
    expect(result.slots).toHaveLength(3);
    expect(result.requestedPeriodSlots).toHaveLength(1);
    expect(result.requestedPeriodSlots[0]).toEqual(
      expect.objectContaining({
        startTime: "13:00",
      }),
    );
    expect(result.requestedPeriodRanges).toEqual([
      expect.objectContaining({
        displayText: "13:00",
      }),
    ]);
  });

  it("accepts flat patient update arguments and converts them into updates", async () => {
    const patientId = "kfedcbaabcde67890lmnopqrstuv678";
    const runMutation = vi.fn().mockResolvedValue({ success: true });
    (global as any).ConvexInternal = {
      patients: { updatePatientDataInternal: "updatePatientDataInternal" },
    };

    const tool = updatePatientDataTool({ runMutation } as any, "clinic-real") as any;
    const result = await tool.execute({
      context: {
        patientId,
        insurance: "Unimed",
      },
    });

    expect(runMutation).toHaveBeenCalledWith(expect.anything(), {
      patientId,
      updates: { insurance: "Unimed" },
    });
    expect(result).toEqual({
      success: true,
      message: "Dados do paciente atualizados com sucesso",
      updatedFields: ["insurance"],
    });
  });

  it("marks reminder sent without depending on global ConvexInternal", async () => {
    const appointmentId = "jd7eaz9v5rm6hcdnff50j2wysx81xnp4";
    const nowSpy = vi.spyOn(Date, "now").mockReturnValue(1774799542840);
    const runQuery = vi.fn().mockResolvedValue({
      _id: appointmentId,
      clinicId: "clinic-real",
    });
    const runMutation = vi.fn().mockResolvedValue(undefined);

    const tool = scheduleReminderTool({ runQuery, runMutation } as any, "clinic-real") as any;
    const result = await tool.execute({
      context: {
        appointmentId,
        reminderType: "confirmation",
      },
    });

    expect(runQuery).toHaveBeenCalledWith(expect.anything(), {
      id: appointmentId,
      clinicId: "clinic-real",
    });
    expect(runMutation).toHaveBeenCalledWith(expect.anything(), {
      id: appointmentId,
      reminderAt: 1774799542840,
    });
    expect(result).toEqual({
      success: true,
      reminderType: "confirmation",
      scheduledAt: 1774799542840,
    });

    nowSpy.mockRestore();
  });

  it("normalizes null optional fields before creating internal tickets", async () => {
    const patientId = "kfedcbaticket67890lmnopqrstuv67";
    (global as any).ConvexInternal = { tickets: { createTicket: "createTicket" } };
    const runMutation = vi.fn().mockResolvedValue({ _id: "ticket-1" });

    const tool = createInternalTicketTool({ runMutation } as any, "clinic-real") as any;
    const result = await tool.execute({
      context: {
        patientId,
        appointmentId: null,
        title: "Ticket",
        description: "Desc",
        priority: "high",
        npsScore: 3,
        npsFeedback: null,
      },
    });

    expect(runMutation).toHaveBeenCalledWith(expect.anything(), {
      clinicId: "clinic-real",
      patientId,
      appointmentId: undefined,
      title: "Ticket",
      description: "Desc",
      priority: "high",
      source: "nps",
      npsScore: 3,
      npsFeedback: undefined,
    });
    expect(result).toEqual({
      success: true,
      ticketId: "ticket-1",
      message: "Internal ticket created successfully",
    });
  });
});
