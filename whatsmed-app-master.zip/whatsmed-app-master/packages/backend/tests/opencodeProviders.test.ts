import { Buffer } from "node:buffer";

import { afterEach, describe, expect, it, vi } from "vitest";

import { MASTRA_CONFIG } from "../mastra/config.js";
import { downloadUrlToDataUrl, isImageMimeType, isPdfMimeType } from "../mastra/media.js";
import {
  getPrimaryChatModelId,
  getReminderModelId,
  getVisionModelIdForMimeType,
} from "../mastra/providers.js";

describe("OpenCode provider routing", () => {
  it("uses OpenCode Go for primary text models", () => {
    expect(getPrimaryChatModelId()).toBe(MASTRA_CONFIG.models.agent);
    expect(getReminderModelId()).toBe(MASTRA_CONFIG.models.reminder);
    expect(getPrimaryChatModelId()).toContain("opencode-go/");
    expect(getReminderModelId()).toContain("opencode-go/");
  });

  it("routes images to Kimi and PDFs to OpenAI fallback", () => {
    expect(getVisionModelIdForMimeType("image/png")).toBe(MASTRA_CONFIG.models.vision);
    expect(getVisionModelIdForMimeType("application/pdf")).toBe(
      MASTRA_CONFIG.models.pdfVisionFallback,
    );
    expect(getVisionModelIdForMimeType("audio/mpeg")).toBe(MASTRA_CONFIG.models.pdfVisionFallback);
  });
});

describe("OpenCode media helpers", () => {
  afterEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
  });

  it("detects image and pdf mime types", () => {
    expect(isImageMimeType("image/jpeg")).toBe(true);
    expect(isImageMimeType("application/pdf")).toBe(false);
    expect(isPdfMimeType("application/pdf")).toBe(true);
    expect(isPdfMimeType("image/png")).toBe(false);
  });

  it("converts remote images to data URLs for Kimi vision", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(Buffer.from("abc"), {
        status: 200,
        headers: {
          "content-type": "image/png",
        },
      }),
    );

    vi.stubGlobal("fetch", fetchMock);

    const result = await downloadUrlToDataUrl("https://example.com/image.png");

    expect(fetchMock).toHaveBeenCalledWith("https://example.com/image.png");
    expect(result).toBe("data:image/png;base64,YWJj");
  });
});
