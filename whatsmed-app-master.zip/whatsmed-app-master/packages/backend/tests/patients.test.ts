// @ts-nocheck
import { beforeEach, describe, expect, it } from "vitest";

import { api } from "../convex/_generated/api.js";
import { createTestConvex, ensureClinic } from "./harness.js";

describe("Patients", () => {
  let t: Awaited<ReturnType<typeof createTestConvex>>;

  beforeEach(async () => {
    t = await createTestConvex();
  });

  it("returns older matching patients when search is combined with status", async () => {
    const clinicId = "test-clinic-patient-search";
    await ensureClinic(t, clinicId);

    await t.run(async (ctx) => {
      await ctx.db.insert("patients", {
        clinicId,
        name: "Maria Legacy",
        status: "active",
        phone: "+5511999990000",
        createdAt: 1,
      });

      for (let i = 0; i < 140; i += 1) {
        await ctx.db.insert("patients", {
          clinicId,
          name: `Recent Patient ${i}`,
          status: "active",
          createdAt: 1000 + i,
        });
      }
    });

    const result = await t.query(api.patients.list, {
      clinicId,
      status: "active",
      search: "Maria Legacy",
      limit: 25,
    });

    expect(result.items).toHaveLength(1);
    expect(result.items[0]?.name).toBe("Maria Legacy");
  });
});
