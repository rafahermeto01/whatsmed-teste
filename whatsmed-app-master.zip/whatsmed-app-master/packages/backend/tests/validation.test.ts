import { describe, it, expect } from "vitest";
import {
  isValidCPF,
  formatCPF,
  isValidBrazilianPhone,
  formatBrazilianPhone,
  isValidEmail,
  sanitizeString,
  sanitizeHTML,
  isValidDateRange,
  isValidAppointmentDuration,
  doRangesOverlap,
  isValidCNPJ,
  isValidCpfCnpj,
  formatCNPJ,
  isValidCEP,
  normalizeCpfCnpj,
  formatCEP,
  validateRequiredFields,
  createValidationError,
  matchesSpecialty,
  isGenericSpecialty,
  normalizeSpecialtyForMatch,
} from "../convex/lib/validators";

describe("CPF Validation", () => {
  it("should validate correct CPF numbers", () => {
    const validCPFs = ["529.982.247-25", "52998224725", "123.456.789-09", "12345678909"];

    validCPFs.forEach((cpf) => {
      expect(isValidCPF(cpf)).toBe(true);
    });
  });

  it("should reject invalid CPF numbers", () => {
    const invalidCPFs = [
      "111.111.111-11", // All same digits
      "123.456.789-00", // Invalid check digits
      "123.456.789", // Wrong length
      "123.456.789-123", // Too long
      "123.456.789-AB", // Non-numeric
    ];

    invalidCPFs.forEach((cpf) => {
      expect(isValidCPF(cpf)).toBe(false);
    });
  });

  it("should format CPF correctly", () => {
    expect(formatCPF("52998224725")).toBe("529.982.247-25");
    expect(formatCPF("12345678909")).toBe("123.456.789-09");
    expect(formatCPF("invalid")).toBe("invalid");
  });
});

describe("Brazilian Phone Validation", () => {
  it("should validate valid phone numbers", () => {
    const validPhones = [
      "(11) 99999-9999", // Mobile
      "11999999999",
      "11 9999-9999", // Landline
      "1199999999",
    ];

    validPhones.forEach((phone) => {
      expect(isValidBrazilianPhone(phone)).toBe(true);
    });
  });

  it("should reject invalid phone numbers", () => {
    const invalidPhones = [
      "12345678", // Too short (8 digits)
      "123456789012", // Too long (12 digits)
      "00 9999-9999", // Invalid DDD (00)
      "100 9999-9999", // Invalid DDD (100)
      "9 9999-9999", // Too short after DDD removal
      "+55 11 99999-9999", // Includes country code (not supported)
    ];

    invalidPhones.forEach((phone) => {
      expect(isValidBrazilianPhone(phone)).toBe(false);
    });
  });

  it("should format phone numbers correctly", () => {
    expect(formatBrazilianPhone("11999999999")).toBe("(11) 99999-9999");
    expect(formatBrazilianPhone("1199999999")).toBe("(11) 9999-9999");
    expect(formatBrazilianPhone("invalid")).toBe("invalid");
  });
});

describe("Email Validation", () => {
  it("should validate correct email addresses", () => {
    const validEmails = [
      "test@example.com",
      "user.name+tag@example.co.uk",
      "user_name@example.com",
      "user-name@example.com",
      "user@sub.example.com",
    ];

    validEmails.forEach((email) => {
      expect(isValidEmail(email)).toBe(true);
    });
  });

  it("should reject invalid email addresses", () => {
    const invalidEmails = [
      "plainaddress", // Missing @
      "@example.com", // Missing local part
      "user@.com", // Missing domain name
      "user@..com", // Invalid domain
      "user@example..com", // Invalid domain
      "user@.example.com", // Dot at start
      "user@example.", // Trailing dot
      "a" + "@".repeat(50) + "b.com", // Too long local part
      "", // Empty
    ];

    invalidEmails.forEach((email) => {
      expect(isValidEmail(email)).toBe(false);
    });
  });
});

describe("String Sanitization", () => {
  it("should sanitize strings correctly", () => {
    const input = "  Hello World  \n\r";
    const sanitized = sanitizeString(input, 20);
    expect(sanitized).toBe("Hello World");
  });

  it("should truncate to max length", () => {
    const longInput = "A".repeat(2000);
    const sanitized = sanitizeString(longInput, 100);
    expect(sanitized).toBe("A".repeat(100));
  });

  it("should remove control characters", () => {
    const input = "Hello\u0000World\u200B";
    const sanitized = sanitizeString(input);
    expect(sanitized).toBe("HelloWorld");
  });

  it("should remove bidirectional override characters", () => {
    const input = "Hello\u202AWorld\u202C";
    const sanitized = sanitizeString(input);
    expect(sanitized).toBe("HelloWorld");
  });
});

describe("HTML Sanitization", () => {
  it("should remove script tags", () => {
    const input = "<p>Hello</p><script>alert('xss')</script>";
    const sanitized = sanitizeHTML(input);
    expect(sanitized).not.toContain("<script>");
    expect(sanitized).toContain("<p>Hello</p>");
  });

  it("should remove dangerous event handlers", () => {
    const input = '<div onclick="alert(1)">Click me</div>';
    const sanitized = sanitizeHTML(input);
    expect(sanitized).not.toContain("onclick");
  });

  it("should remove javascript: protocol", () => {
    const input = '<a href="javascript:alert(1)">Link</a>';
    const sanitized = sanitizeHTML(input);
    expect(sanitized).not.toContain("javascript:");
    expect(sanitized).toContain('href="#"');
  });

  it("should remove iframe tags", () => {
    const input = "<p>Content</p><iframe src='malicious'></iframe>";
    const sanitized = sanitizeHTML(input);
    expect(sanitized).not.toContain("<iframe>");
    expect(sanitized).toContain("<p>Content</p>");
  });
});

describe("Date Validation", () => {
  it("should validate correct date ranges", () => {
    const now = Date.now();
    const future = now + 3600000;

    expect(isValidDateRange(now, future)).toBe(true);
    expect(isValidDateRange(now, now + 60000)).toBe(true);
  });

  it("should reject invalid date ranges", () => {
    const now = Date.now();

    expect(isValidDateRange(now, now)).toBe(false);
    expect(isValidDateRange(now, now - 3600000)).toBe(false);
  });

  it("should validate appointment duration", () => {
    const now = Date.now();
    const oneHour = 60 * 60 * 1000;

    expect(isValidAppointmentDuration(now, now + oneHour)).toBe(true);
    expect(isValidAppointmentDuration(now, now + 15 * 60 * 1000)).toBe(true);
  });

  it("should reject invalid appointment duration", () => {
    const now = Date.now();
    const tooShort = 14 * 60 * 1000; // 14 minutes
    const tooLong = 8 * 60 * 60 * 1000 + 1; // 8 hours + 1ms

    expect(isValidAppointmentDuration(now, now + tooShort)).toBe(false);
    expect(isValidAppointmentDuration(now, now + tooLong)).toBe(false);
  });

  it("should detect overlapping ranges", () => {
    expect(doRangesOverlap(1000, 2000, 1500, 2500)).toBe(true);
    expect(doRangesOverlap(1500, 2500, 1000, 2000)).toBe(true);
    expect(doRangesOverlap(1000, 2000, 1000, 2000)).toBe(true); // Exact overlap
  });

  it("should not detect non-overlapping ranges", () => {
    expect(doRangesOverlap(1000, 2000, 2000, 3000)).toBe(false);
    expect(doRangesOverlap(1000, 2000, 3000, 4000)).toBe(false);
    expect(doRangesOverlap(2000, 3000, 1000, 2000)).toBe(false);
  });
});

describe("CNPJ Validation", () => {
  it("should validate correct CNPJ numbers", () => {
    const validCNPJs = [
      "11.444.777/0001-61",
      "11444777000161",
      "00.000.000/0001-91",
      "00000000000191",
    ];

    validCNPJs.forEach((cnpj) => {
      expect(isValidCNPJ(cnpj)).toBe(true);
    });
  });

  it("should reject invalid CNPJ numbers", () => {
    const invalidCNPJs = [
      "11.111.111/1111-11", // All same digits
      "11.444.777/0001-00", // Invalid check digits
      "123.456.789", // Wrong length
      "123.456.789/0123-45", // Too long
      "12.345.678/0001-AB", // Non-numeric
    ];

    invalidCNPJs.forEach((cnpj) => {
      expect(isValidCNPJ(cnpj)).toBe(false);
    });
  });

  it("should format CNPJ correctly", () => {
    expect(formatCNPJ("11444777000161")).toBe("11.444.777/0001-61");
    expect(formatCNPJ("00000000000191")).toBe("00.000.000/0001-91");
    expect(formatCNPJ("invalid")).toBe("invalid");
  });
});

describe("CPF/CNPJ helpers", () => {
  it("should normalize CPF/CNPJ digits", () => {
    expect(normalizeCpfCnpj("529.982.247-25")).toBe("52998224725");
    expect(normalizeCpfCnpj("11.444.777/0001-61")).toBe("11444777000161");
  });

  it("should validate CPF and CNPJ with a single helper", () => {
    expect(isValidCpfCnpj("529.982.247-25")).toBe(true);
    expect(isValidCpfCnpj("11.444.777/0001-61")).toBe(true);
    expect(isValidCpfCnpj("123.456.789-00")).toBe(false);
    expect(isValidCpfCnpj("11.444.777/0001-00")).toBe(false);
  });
});

describe("CEP Validation", () => {
  it("should validate correct CEP numbers", () => {
    const validCEPs = ["01310-100", "01310100", "01234-567", "01234567"];

    validCEPs.forEach((cep) => {
      expect(isValidCEP(cep)).toBe(true);
    });
  });

  it("should reject invalid CEP numbers", () => {
    const invalidCEPs = [
      "01310-1000", // Too long
      "0131010", // Too short
      "01310-10A", // Non-numeric
      "abcde-fgh", // Non-numeric
    ];

    invalidCEPs.forEach((cep) => {
      expect(isValidCEP(cep)).toBe(false);
    });
  });

  it("should format CEP correctly", () => {
    expect(formatCEP("01310100")).toBe("01310-100");
    expect(formatCEP("01234567")).toBe("01234-567");
    expect(formatCEP("invalid")).toBe("invalid");
  });
});

describe("Required Field Validation", () => {
  it("should pass validation when all required fields are present", () => {
    const data = {
      name: "John Doe",
      email: "john@example.com",
      phone: "11999999999",
    };

    const result = validateRequiredFields(data, ["name", "email", "phone"]);
    expect(result.isValid).toBe(true);
    expect(result.missingFields).toHaveLength(0);
  });

  it("should fail validation when required fields are missing", () => {
    const data = {
      name: "John Doe",
      email: "john@example.com",
    };

    const result = validateRequiredFields(data, ["name", "email", "phone", "cpf"]);
    expect(result.isValid).toBe(false);
    expect(result.missingFields).toEqual(["phone", "cpf"]);
  });

  it("should handle empty object", () => {
    const data = {};
    const result = validateRequiredFields(data, ["name", "email"]);
    expect(result.isValid).toBe(false);
    expect(result.missingFields).toEqual(["name", "email"]);
  });
});

describe("Error Message Creation", () => {
  it("should create validation error messages in Portuguese", () => {
    expect(createValidationError("cpf", "invalid format")).toBe("CPF inválido: invalid format");
    expect(createValidationError("phone", "invalid DDD")).toBe("Telefone inválido: invalid DDD");
    expect(createValidationError("email", "missing @")).toBe("E-mail inválido: missing @");
  });

  it("should handle unknown field names", () => {
    const result = createValidationError("unknownField", "some error");
    expect(result).toBe("UnknownField inválido: some error");
  });
});

describe("Specialty Matching", () => {
  describe("matchesSpecialty", () => {
    it("should match exact specialty names", () => {
      expect(matchesSpecialty("cardiologia", "cardiologia")).toBe(true);
      expect(matchesSpecialty("Cardiologia", "cardiologia")).toBe(true);
      expect(matchesSpecialty("CARDIOLOGIA", "cardiologia")).toBe(true);
    });

    it("should match with extra spaces", () => {
      expect(matchesSpecialty(" cardiologia ", "cardiologia")).toBe(true);
      expect(matchesSpecialty("cardiologia", " cardiologia ")).toBe(true);
      expect(matchesSpecialty("  cardiologia  ", "cardiologia")).toBe(true);
    });

    it("should match with accents normalized", () => {
      expect(matchesSpecialty("cardiologia", "cardiologia")).toBe(true);
      expect(matchesSpecialty("cardiológia", "cardiologia")).toBe(true);
      expect(matchesSpecialty("cardiologia", "cardiológia")).toBe(true);
    });

    it("should match specialty aliases (practitioner -> specialty)", () => {
      expect(matchesSpecialty("cardiologia", "cardiologista")).toBe(true);
      expect(matchesSpecialty("cardiologista", "cardiologia")).toBe(true);
      expect(matchesSpecialty("pediatria", "pediatra")).toBe(true);
      expect(matchesSpecialty("pediatra", "pediatria")).toBe(true);
      expect(matchesSpecialty("dermatologia", "dermatologista")).toBe(true);
      expect(matchesSpecialty("neurologia", "neurologista")).toBe(true);
      expect(matchesSpecialty("ortopedia", "ortopedista")).toBe(true);
      expect(matchesSpecialty("urologia", "urologista")).toBe(true);
      expect(matchesSpecialty("ginecologia", "ginecologista")).toBe(true);
    });

    it("should not match different specialties", () => {
      expect(matchesSpecialty("cardiologia", "pediatria")).toBe(false);
      expect(matchesSpecialty("dermatologia", "neurologia")).toBe(false);
      expect(matchesSpecialty("cardiologista", "pediatra")).toBe(false);
    });

    it("should match with typos using fuzzy matching", () => {
      expect(matchesSpecialty("cardiologia", "cardiolgia")).toBe(true);
      expect(matchesSpecialty("cardiologia", "cardiologa")).toBe(true);
      expect(matchesSpecialty("pediatria", "pediatri")).toBe(true);
      expect(matchesSpecialty("dermatologia", "dermatologi")).toBe(true);
    });
  });

  describe("isGenericSpecialty", () => {
    it("should identify generic terms", () => {
      expect(isGenericSpecialty("qualquer")).toBe(true);
      expect(isGenericSpecialty("Qualquer")).toBe(true);
      expect(isGenericSpecialty("QUALQUER")).toBe(true);
      expect(isGenericSpecialty("qualquer um")).toBe(true);
      expect(isGenericSpecialty("sem preferencia")).toBe(true);
      expect(isGenericSpecialty("sem preferência")).toBe(true);
      expect(isGenericSpecialty("tanto faz")).toBe(true);
      expect(isGenericSpecialty("indiferente")).toBe(true);
    });

    it("should not identify specific specialties as generic", () => {
      expect(isGenericSpecialty("cardiologia")).toBe(false);
      expect(isGenericSpecialty("pediatria")).toBe(false);
      expect(isGenericSpecialty("dermatologista")).toBe(false);
    });
  });

  describe("normalizeSpecialtyForMatch", () => {
    it("should normalize accents", () => {
      expect(normalizeSpecialtyForMatch("cardiológia")).toBe("cardiologia");
      expect(normalizeSpecialtyForMatch("neurológica")).toBe("neurologia");
    });

    it("should trim and lowercase", () => {
      expect(normalizeSpecialtyForMatch("  Cardiologia  ")).toBe("cardiologia");
      expect(normalizeSpecialtyForMatch("CARDIOLOGIA")).toBe("cardiologia");
    });

    it("should collapse multiple spaces", () => {
      expect(normalizeSpecialtyForMatch("clinica   geral")).toBe("clinica geral");
    });

    it("should resolve aliases", () => {
      expect(normalizeSpecialtyForMatch("cardiologista")).toBe("cardiologia");
      expect(normalizeSpecialtyForMatch("pediatra")).toBe("pediatria");
      expect(normalizeSpecialtyForMatch("dermatologista")).toBe("dermatologia");
    });

    it("should resolve adjective forms to specialty", () => {
      expect(normalizeSpecialtyForMatch("pediatrica")).toBe("pediatria");
      expect(normalizeSpecialtyForMatch("cardiologico")).toBe("cardiologia");
    });
  });
});
