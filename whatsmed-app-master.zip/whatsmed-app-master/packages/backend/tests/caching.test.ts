import { describe, it, expect, beforeEach, vi } from "vitest";
import {
  getCache,
  setCache,
  clearCache,
  clearCachePattern,
  clearAllCache,
  getCacheStats,
  resetCacheStats,
  CacheKeys,
} from "../convex/lib/cache";

describe("Caching System", () => {
  beforeEach(() => {
    // Clear all cache before each test
    clearAllCache();
    resetCacheStats();
  });

  describe("getCache and setCache", () => {
    it("should store and retrieve values", () => {
      const key = "test:key";
      const value = { data: "test" };

      setCache(key, value);
      const retrieved = getCache(key);

      expect(retrieved).toEqual(value);
      expect(getCacheStats().hits).toBe(1);
    });

    it("should return null for non-existent keys", () => {
      const result = getCache("nonexistent:key");
      expect(result).toBeNull();
      expect(getCacheStats().misses).toBe(1);
    });

    it("should handle different types of values", () => {
      const stringValue = "test string";
      const numberValue = 12345;
      const objectValue = { name: "test", id: 1 };
      const arrayValue = [1, 2, 3, 4];

      setCache("string", stringValue);
      setCache("number", numberValue);
      setCache("object", objectValue);
      setCache("array", arrayValue);

      expect(getCache("string")).toBe(stringValue);
      expect(getCache("number")).toBe(numberValue);
      expect(getCache("object")).toEqual(objectValue);
      expect(getCache("array")).toEqual(arrayValue);
    });

    it("should update existing keys", () => {
      const key = "test:key";
      const oldValue = { version: 1 };
      const newValue = { version: 2 };

      setCache(key, oldValue);
      setCache(key, newValue);

      const retrieved = getCache(key);
      expect(retrieved).toEqual(newValue);
      expect(getCacheStats().size).toBe(1);
    });
  });

  describe("Cache TTL (Time To Live)", () => {
    it("should expire entries after TTL", () => {
      const key = "test:expiring";
      const value = { data: "test" };
      const ttl = 100; // 100ms

      setCache(key, value);

      // Should be available immediately
      expect(getCache(key, ttl)).toEqual(value);

      // Wait for expiration
      return new Promise((resolve) => {
        setTimeout(() => {
          const result = getCache(key, ttl);
          expect(result).toBeNull();
          expect(getCacheStats().misses).toBeGreaterThanOrEqual(1);
          expect(getCacheStats().evictions).toBe(1);
          resolve(true);
        }, 150);
      });
    });

    it("should use default TTL when not specified", () => {
      const key = "test:default";
      const value = { data: "test" };

      setCache(key, value);

      // Should be available immediately with default TTL (60s)
      expect(getCache(key)).toEqual(value);
    });
  });

  describe("clearCache", () => {
    it("should remove specific cache entries", () => {
      const key1 = "test:key1";
      const key2 = "test:key2";

      setCache(key1, "value1");
      setCache(key2, "value2");

      expect(getCache(key1)).toBe("value1");
      expect(getCache(key2)).toBe("value2");
      expect(getCacheStats().size).toBe(2);

      clearCache(key1);

      expect(getCache(key1)).toBeNull();
      expect(getCache(key2)).toBe("value2");
      expect(getCacheStats().size).toBe(1);
    });

    it("should handle clearing non-existent keys", () => {
      expect(() => clearCache("nonexistent:key")).not.toThrow();
    });
  });

  describe("clearCachePattern", () => {
    it("should clear entries matching pattern", () => {
      const keys = ["user:123", "user:456", "clinic:789", "user:999"];

      keys.forEach((key) => {
        setCache(key, `value:${key}`);
      });

      expect(getCacheStats().size).toBe(4);

      // Clear all user keys
      clearCachePattern("user:*");

      expect(getCache("user:123")).toBeNull();
      expect(getCache("user:456")).toBeNull();
      expect(getCache("clinic:789")).toEqual("value:clinic:789");
      expect(getCache("user:999")).toBeNull();
      expect(getCacheStats().size).toBe(1);
    });

    it("should handle patterns with wildcards", () => {
      const keys = ["cache:key1", "cache:key2", "cache:key3", "other:key4"];

      keys.forEach((key) => {
        setCache(key, `value:${key}`);
      });

      // Clear all cache keys
      clearCachePattern("cache:*");

      expect(getCacheStats().size).toBe(1);
      expect(getCache("other:key4")).toEqual("value:other:key4");
    });

    it("should handle pattern with no matches", () => {
      setCache("test:key1", "value1");
      setCache("test:key2", "value2");

      expect(getCacheStats().size).toBe(2);

      // Clear non-existent pattern
      clearCachePattern("nonexistent:*");

      expect(getCacheStats().size).toBe(2);
    });
  });

  describe("clearAllCache", () => {
    it("should clear all cache entries", () => {
      const keys = ["key1", "key2", "key3", "key4", "key5"];

      keys.forEach((key) => {
        setCache(key, `value:${key}`);
      });

      expect(getCacheStats().size).toBe(5);

      clearAllCache();

      expect(getCacheStats().size).toBe(0);
      expect(getCache("key1")).toBeNull();
      expect(getCache("key5")).toBeNull();
    });

    it("should handle clearing empty cache", () => {
      expect(() => clearAllCache()).not.toThrow();
      expect(getCacheStats().size).toBe(0);
    });
  });

  describe("Cache Statistics", () => {
    it("should track cache hits correctly", () => {
      const key = "test:key";
      const value = { data: "test" };

      setCache(key, value);

      getCache(key);
      getCache(key);
      getCache(key);

      expect(getCacheStats().hits).toBe(3);
      expect(getCacheStats().misses).toBe(0);
    });

    it("should track cache misses correctly", () => {
      getCache("nonexistent1");
      getCache("nonexistent2");
      getCache("nonexistent3");

      expect(getCacheStats().hits).toBe(0);
      expect(getCacheStats().misses).toBe(3);
    });

    it("should track cache evictions correctly", () => {
      const key = "test:key";
      const value = { data: "test" };
      const shortTtl = 50;

      setCache(key, value);

      return new Promise((resolve) => {
        setTimeout(() => {
          // Trigger expiration
          getCache(key, shortTtl);

          expect(getCacheStats().evictions).toBe(1);
          resolve(true);
        }, 100);
      });
    });

    it("should calculate hit rate correctly", () => {
      const key = "test:key";
      const value = { data: "test" };

      setCache(key, value);

      // 3 hits
      getCache(key);
      getCache(key);
      getCache(key);

      // 2 misses
      getCache("miss1");
      getCache("miss2");

      const stats = getCacheStats();
      const expectedHitRate = 3 / (3 + 2);

      expect(stats.hits).toBe(3);
      expect(stats.misses).toBe(2);
      expect(stats.hitRate).toBeCloseTo(expectedHitRate, 0.0001);
    });

    it("should handle hit rate with zero total requests", () => {
      const stats = getCacheStats();
      expect(stats.hitRate).toBe(0);
    });
  });

  describe("resetCacheStats", () => {
    it("should reset all statistics", () => {
      const key = "test:key";
      const value = { data: "test" };

      setCache(key, value);

      // Generate some stats
      getCache(key); // hit
      getCache("miss"); // miss

      expect(getCacheStats().hits).toBe(1);
      expect(getCacheStats().misses).toBe(1);

      resetCacheStats();

      expect(getCacheStats().hits).toBe(0);
      expect(getCacheStats().misses).toBe(0);
      expect(getCacheStats().evictions).toBe(0);
      // Size should remain the same
      expect(getCacheStats().size).toBe(1);
    });
  });

  describe("CacheKeys", () => {
    it("should generate correct keys for users", () => {
      const email = "test@example.com";
      const key = CacheKeys.user(email);
      expect(key).toBe(`user:${email}`);
    });

    it("should generate correct keys for clinics", () => {
      const clinicId = "clinic-123";
      const key = CacheKeys.clinic(clinicId);
      expect(key).toBe(`clinic:${clinicId}`);
    });

    it("should generate correct keys for patients", () => {
      const clinicId = "clinic-123";
      const key = CacheKeys.patients(clinicId, "active");
      expect(key).toBe(`patients:${clinicId}:active`);
    });

    it("should generate correct keys for appointments", () => {
      const clinicId = "clinic-123";
      const key = CacheKeys.appointments(clinicId, "confirmed");
      expect(key).toBe(`appointments:${clinicId}:confirmed`);
    });

    it("should generate correct keys for analytics", () => {
      const clinicId = "clinic-123";
      const dateRange = "2024-01";
      const key = CacheKeys.analytics(clinicId, dateRange);
      expect(key).toBe(`analytics:${clinicId}:${dateRange}`);
    });

    it("should generate correct keys without filters", () => {
      const clinicId = "clinic-123";
      const key = CacheKeys.patients(clinicId);
      expect(key).toBe(`patients:${clinicId}`);
    });
  });

  describe("Cache Size Limits", () => {
    it("should evict oldest entries when cache is full", () => {
      // Fill cache to MAX_CACHE_SIZE (1000 entries)
      for (let i = 0; i < 1001; i++) {
        setCache(`key:${i}`, `value:${i}`);
      }

      expect(getCacheStats().size).toBeLessThanOrEqual(1000);
      expect(getCacheStats().evictions).toBeGreaterThan(0);
    });
  });
});
