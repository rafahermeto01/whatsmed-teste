import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { api, internal } from "../convex/_generated/api";
import { createTestConvex } from "./harness";

const sendTextMock = vi.fn(async () => undefined);

vi.mock("../convex/lib/whatsapp/factory", () => ({
  WhatsAppProviderFactory: {
    getProvider: () => ({
      sendText: sendTextMock,
    }),
  },
}));

describe("Automation actions", () => {
  let t: Awaited<ReturnType<typeof createTestConvex>>;

  beforeEach(async () => {
    vi.useFakeTimers();
    sendTextMock.mockClear();
    t = await createTestConvex();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  async function seedConnectedWhatsApp(clinicId: string, now: number) {
    await t.run(async (ctx) => {
      await ctx.db.insert("whatsappInstances", {
        clinicId,
        instanceName: `meta_${clinicId}`,
        status: "connected",
        webhookConfigured: false,
        createdAt: now,
        provider: "meta",
        metaPhoneNumberId: `phone-${clinicId}`,
      });
    });
  }

  async function flushScheduled() {
    await t.finishAllScheduledFunctions(() => {
      vi.advanceTimersByTime(31 * 60 * 1000);
    });
  }

  it("sends a confirmation request for pending appointments and creates a chat", async () => {
    const clinicId = "test-clinic-confirmation";
    const now = Date.now();

    await seedConnectedWhatsApp(clinicId, now);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Maria Silva",
      phone: "(11) 99999-9999",
      email: "maria@example.com",
    });

    const appointmentId = await t.run(async (ctx) => {
      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "appointmentConfirmation",
        enabled: true,
        message: "Olá {{patient.name}}, sua consulta está confirmada.",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      return await ctx.db.insert("appointments", {
        clinicId,
        patientId: patient._id,
        startAt: now + 60 * 60 * 1000,
        endAt: now + 2 * 60 * 60 * 1000,
        status: "pending",
        doctor: "Dra. Teste",
        procedure: "Consulta",
        createdAt: now,
      });
    });

    const result = await t.action(internal.automationActions.sendAppointmentConfirmation, {
      appointmentId,
      clinicId,
    });
    await flushScheduled();

    expect(result.sent).toBe(true);

    const { chats, messages } = await t.run(async (ctx) => {
      const chats = (await ctx.db.query("chats").collect()).filter(
        (chat) => chat.clinicId === clinicId,
      );
      const messages = (await ctx.db.query("messages").collect()).filter(
        (message) => message.clinicId === clinicId,
      );

      return { chats, messages };
    });

    expect(chats).toHaveLength(1);
    expect(chats[0].patientId).toBe(patient._id);
    expect(chats[0].whatsappChatId).toBe("5511999999999@s.whatsapp.net");
    expect(messages).toHaveLength(1);
    expect(messages[0].chatId).toBe(chats[0]._id);
    expect(messages[0].body).toContain("Maria Silva");
    expect(messages[0].automationKind).toBe("confirmationRequest");
    expect(messages[0].appointmentId).toBe(appointmentId);
  });

  it("auto-seeds missing reminder configs before sending confirmation requests", async () => {
    const clinicId = "test-clinic-auto-seed-confirmation";
    const now = Date.now();

    await seedConnectedWhatsApp(clinicId, now);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Lia Souza",
      phone: "5511999992222",
      email: "lia@example.com",
    });

    const appointmentId = await t.run(async (ctx) => {
      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "confirmationReply",
        enabled: true,
        message: "Template customizado: consulta confirmada para {{patient.name}}.",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      return await ctx.db.insert("appointments", {
        clinicId,
        patientId: patient._id,
        startAt: now + 60 * 60 * 1000,
        endAt: now + 2 * 60 * 60 * 1000,
        status: "pending",
        doctor: "Dra. Default",
        procedure: "Consulta",
        createdAt: now,
      });
    });

    const result = await t.action(internal.automationActions.sendAppointmentConfirmation, {
      appointmentId,
      clinicId,
    });
    await flushScheduled();

    expect(result.sent).toBe(true);

    const { reminderConfigs, messages } = await t.run(async (ctx) => {
      const reminderConfigs = (await ctx.db.query("reminderConfigs").collect()).filter(
        (config) => config.clinicId === clinicId,
      );
      const messages = (await ctx.db.query("messages").collect()).filter(
        (message) => message.clinicId === clinicId,
      );

      return { reminderConfigs, messages };
    });

    expect(reminderConfigs.length).toBeGreaterThanOrEqual(6);
    expect(reminderConfigs.some((config) => config.type === "appointmentConfirmation")).toBe(true);
    expect(messages).toHaveLength(1);
    expect(messages[0]?.automationKind).toBe("confirmationRequest");
  });

  it("includes the telemedicine meeting URL in the WhatsApp confirmation message", async () => {
    const clinicId = "test-clinic-telemedicine-confirmation";
    const now = Date.now();

    await seedConnectedWhatsApp(clinicId, now);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Paula Lima",
      phone: "5511999993333",
      email: "paula@example.com",
    });

    const appointmentId = await t.run(async (ctx) => {
      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "appointmentConfirmation",
        enabled: true,
        message:
          "Ola {{patient.name}}! Sua consulta online esta marcada para {{appointment.date}} as {{appointment.time}}.",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      return await ctx.db.insert("appointments", {
        clinicId,
        patientId: patient._id,
        startAt: now + 60 * 60 * 1000,
        endAt: now + 2 * 60 * 60 * 1000,
        status: "pending",
        doctor: "Dr. Video",
        procedure: "Teleconsulta",
        isTelemedicine: true,
        meetingLink: "https://meet.google.com/abc-defg-hij",
        createdAt: now,
      });
    });

    const result = await t.action(internal.automationActions.sendAppointmentConfirmation, {
      appointmentId,
      clinicId,
    });
    await flushScheduled();

    expect(result.sent).toBe(true);

    const messages = await t.run(async (ctx) => {
      return (await ctx.db.query("messages").collect()).filter(
        (message) => message.clinicId === clinicId,
      );
    });

    expect(messages).toHaveLength(1);
    expect(messages[0]?.body).toContain(
      "Link da teleconsulta: https://meet.google.com/abc-defg-hij",
    );
  });

  it("schedules confirmation jobs for pending appointments and reminder jobs for all active appointments", async () => {
    const clinicId = "test-clinic-confirmation-dedupe";
    const now = Date.now();

    await seedConnectedWhatsApp(clinicId, now);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "João Silva",
      phone: "5511999990000",
      email: "joao@example.com",
    });

    const { pendingAppointmentId, confirmedAppointmentId } = await t.run(async (ctx) => {
      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "appointmentConfirmation",
        enabled: true,
        message: "Olá {{patient.name}}, sua consulta está confirmada.",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "twentyFourHour",
        enabled: true,
        message: "Lembrete 24h {{patient.name}}",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "oneHour",
        enabled: true,
        message: "Lembrete 1h {{patient.name}}",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      const pendingAppointmentId = await ctx.db.insert("appointments", {
        clinicId,
        patientId: patient._id,
        startAt: now + 48 * 60 * 60 * 1000,
        endAt: now + 49 * 60 * 60 * 1000,
        status: "pending",
        doctor: "Dra. Teste",
        procedure: "Consulta",
        createdAt: now,
      });

      const confirmedAppointmentId = await ctx.db.insert("appointments", {
        clinicId,
        patientId: patient._id,
        startAt: now + 48 * 60 * 60 * 1000,
        endAt: now + 49 * 60 * 60 * 1000,
        status: "confirmed",
        doctor: "Dra. Teste",
        procedure: "Consulta",
        createdAt: now,
      });

      return { pendingAppointmentId, confirmedAppointmentId };
    });

    await t.mutation(internal.automationInternal.syncAppointmentScheduledJobs, {
      appointmentId: pendingAppointmentId,
    });
    await t.mutation(internal.automationInternal.syncAppointmentScheduledJobs, {
      appointmentId: confirmedAppointmentId,
    });

    const jobs = await t.run(async (ctx) => {
      return (await ctx.db.query("appointmentScheduledJobs").collect()).filter(
        (job) => job.clinicId === clinicId,
      );
    });

    const pendingJobs = jobs.filter((job) => job.appointmentId === pendingAppointmentId);
    const confirmedJobs = jobs.filter((job) => job.appointmentId === confirmedAppointmentId);

    expect(pendingJobs.some((job) => job.jobKind === "appointmentConfirmation")).toBe(true);
    expect(pendingJobs.some((job) => job.jobKind === "twentyFourHour")).toBe(true);
    expect(pendingJobs.some((job) => job.jobKind === "oneHour")).toBe(true);
    expect(confirmedJobs.some((job) => job.jobKind === "appointmentConfirmation")).toBe(false);
    expect(confirmedJobs.some((job) => job.jobKind === "twentyFourHour")).toBe(true);
    expect(confirmedJobs.some((job) => job.jobKind === "oneHour")).toBe(true);
  });

  it("does not schedule a fresh confirmation request while waiting for reschedule reply, but keeps reminders", async () => {
    const clinicId = "test-clinic-awaiting-reschedule";
    const now = Date.now();

    await seedConnectedWhatsApp(clinicId, now);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Bruna Reply",
      phone: "5511991110000",
      email: "bruna.reply@example.com",
    });

    const appointmentId = await t.run(async (ctx) => {
      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "appointmentConfirmation",
        enabled: true,
        message: "Confirme sua consulta",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "twentyFourHour",
        enabled: true,
        message: "Lembrete 24h",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "oneHour",
        enabled: true,
        message: "Lembrete 1h",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      return await ctx.db.insert("appointments", {
        clinicId,
        patientId: patient._id,
        startAt: now + 48 * 60 * 60 * 1000,
        endAt: now + 49 * 60 * 60 * 1000,
        status: "pending",
        rescheduleStatus: "awaiting_response",
        rescheduleOfferedSlots: [
          { startAt: now + 72 * 60 * 60 * 1000, endAt: now + 73 * 60 * 60 * 1000 },
        ],
        doctor: "Dra. Resposta",
        procedure: "Consulta",
        createdAt: now,
      });
    });

    await t.mutation(internal.automationInternal.syncAppointmentScheduledJobs, {
      appointmentId,
    });

    const jobs = await t.run(async (ctx) => {
      return (await ctx.db.query("appointmentScheduledJobs").collect()).filter(
        (job) => job.appointmentId === appointmentId,
      );
    });

    expect(jobs.some((job) => job.jobKind === "appointmentConfirmation")).toBe(false);
    expect(jobs.some((job) => job.jobKind === "rescheduleTimeout")).toBe(true);
    expect(jobs.some((job) => job.jobKind === "twentyFourHour")).toBe(true);
    expect(jobs.some((job) => job.jobKind === "oneHour")).toBe(true);
  });

  it("runs a scheduled one-hour reminder job for confirmed appointments", async () => {
    const clinicId = "test-clinic-reminder-window";
    const now = Date.now();

    await seedConnectedWhatsApp(clinicId, now);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Ana Souza",
      phone: "(11) 98888-7777",
      email: "ana@example.com",
    });

    const appointmentId = await t.run(async (ctx) => {
      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "oneHour",
        enabled: true,
        message: "Olá {{patient.name}}, sua consulta é às {{appointment.time}}.",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      return await ctx.db.insert("appointments", {
        clinicId,
        patientId: patient._id,
        startAt: now + 80 * 60 * 1000,
        endAt: now + 110 * 60 * 1000,
        status: "confirmed",
        doctor: "Dr. Lembrete",
        procedure: "Retorno",
        createdAt: now,
      });
    });

    await t.action(internal.automationActions.runScheduledAppointmentJob, {
      clinicId,
      appointmentId,
      jobKind: "oneHour",
    });
    await flushScheduled();

    const { chats, messages } = await t.run(async (ctx) => {
      const chats = (await ctx.db.query("chats").collect()).filter(
        (chat) => chat.clinicId === clinicId,
      );
      const messages = (await ctx.db.query("messages").collect()).filter(
        (message) => message.clinicId === clinicId,
      );

      return { chats, messages };
    });

    expect(chats).toHaveLength(1);
    expect(chats[0].whatsappChatId).toBe("5511988887777@s.whatsapp.net");
    expect(messages).toHaveLength(1);
    expect(messages[0].body).toContain("Ana Souza");
    expect(sendTextMock).toHaveBeenCalled();
  });

  it("does not run scheduled reminders for cancelled or completed appointments", async () => {
    const clinicId = "test-clinic-reminder-status-coverage";
    const now = Date.now();

    await seedConnectedWhatsApp(clinicId, now);

    const completedPatient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Caio Completed",
      phone: "5511991111111",
      email: "caio@example.com",
    });

    const cancelledPatient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Clara Cancelled",
      phone: "5511993333333",
      email: "clara@example.com",
    });

    const { completedAppointmentId, cancelledAppointmentId } = await t.run(async (ctx) => {
      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "oneHour",
        enabled: true,
        message: "Olá {{patient.name}}, sua consulta é às {{appointment.time}}.",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      const completedAppointmentId = await ctx.db.insert("appointments", {
        clinicId,
        patientId: completedPatient._id,
        startAt: now + 80 * 60 * 1000,
        endAt: now + 110 * 60 * 1000,
        status: "completed",
        doctor: "Dra. Status",
        procedure: "Retorno",
        createdAt: now,
      });

      const cancelledAppointmentId = await ctx.db.insert("appointments", {
        clinicId,
        patientId: cancelledPatient._id,
        startAt: now + 90 * 60 * 1000,
        endAt: now + 120 * 60 * 1000,
        status: "cancelled",
        doctor: "Dra. Status",
        procedure: "Retorno",
        createdAt: now,
      });

      return { completedAppointmentId, cancelledAppointmentId };
    });

    const completedResult = await t.action(internal.automationActions.runScheduledAppointmentJob, {
      clinicId,
      appointmentId: completedAppointmentId,
      jobKind: "oneHour",
    });
    const cancelledResult = await t.action(internal.automationActions.runScheduledAppointmentJob, {
      clinicId,
      appointmentId: cancelledAppointmentId,
      jobKind: "oneHour",
    });
    await flushScheduled();

    const messages = await t.run(async (ctx) => {
      return (await ctx.db.query("messages").collect()).filter(
        (message) => message.clinicId === clinicId,
      );
    });

    expect(completedResult?.sent).toBe(false);
    expect(cancelledResult?.sent).toBe(false);
    expect(messages).toHaveLength(0);
    expect(messages.some((message) => message.body.includes("Clara Cancelled"))).toBe(false);
  });

  it("runs a scheduled reminder job for pending appointments too", async () => {
    const clinicId = "test-clinic-pending-reminder";
    const now = Date.now();

    await seedConnectedWhatsApp(clinicId, now);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Paula Pending",
      phone: "5511970010000",
      email: "paula@example.com",
    });

    const appointmentId = await t.run(async (ctx) => {
      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "oneHour",
        enabled: true,
        message: "Lembrete {{patient.name}}",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      return await ctx.db.insert("appointments", {
        clinicId,
        patientId: patient._id,
        startAt: now + 80 * 60 * 1000,
        endAt: now + 110 * 60 * 1000,
        status: "pending",
        doctor: "Dra. Lembrete",
        procedure: "Consulta",
        createdAt: now,
      });
    });

    const result = await t.action(internal.automationActions.runScheduledAppointmentJob, {
      clinicId,
      appointmentId,
      jobKind: "oneHour",
    });
    await flushScheduled();

    const messages = await t.run(async (ctx) => {
      return (await ctx.db.query("messages").collect()).filter(
        (message) => message.clinicId === clinicId,
      );
    });

    expect(result?.sent).toBe(true);
    expect(messages).toHaveLength(1);
    expect(messages[0]?.body).toContain("Paula Pending");
  });

  it("auto-seeds reminder configs before a scheduled reminder job runs", async () => {
    const clinicId = "test-clinic-global-reminder-bootstrap";
    const now = Date.now();

    await seedConnectedWhatsApp(clinicId, now);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Bruna Lima",
      phone: "5511988881234",
      email: "bruna@example.com",
    });

    const appointmentId = await t.run(async (ctx) => {
      return await ctx.db.insert("appointments", {
        clinicId,
        patientId: patient._id,
        startAt: now + 80 * 60 * 1000,
        endAt: now + 110 * 60 * 1000,
        status: "confirmed",
        doctor: "Dr. Cron",
        procedure: "Retorno",
        createdAt: now,
      });
    });

    await t.action(internal.automationActions.runScheduledAppointmentJob, {
      clinicId,
      appointmentId,
      jobKind: "oneHour",
    });
    await flushScheduled();

    const { reminderConfigs, messages } = await t.run(async (ctx) => {
      const reminderConfigs = (await ctx.db.query("reminderConfigs").collect()).filter(
        (config) => config.clinicId === clinicId,
      );
      const messages = (await ctx.db.query("messages").collect()).filter(
        (message) => message.clinicId === clinicId,
      );

      return { reminderConfigs, messages };
    });

    expect(reminderConfigs.length).toBeGreaterThanOrEqual(6);
    expect(reminderConfigs.some((config) => config.type === "oneHour")).toBe(true);
    expect(messages).toHaveLength(1);
    expect(messages[0].body).toContain("Bruna Lima");
  });

  it("sends scheduled reminders without needing clinic bootstrap scans", async () => {
    const clinicId = "test-clinic-instance-only-bootstrap";
    const now = Date.now();

    await seedConnectedWhatsApp(clinicId, now);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Helena Costa",
      phone: "5511977771234",
      email: "helena@example.com",
    });

    const appointmentId = await t.run(async (ctx) => {
      return await ctx.db.insert("appointments", {
        clinicId,
        patientId: patient._id,
        startAt: now + 80 * 60 * 1000,
        endAt: now + 110 * 60 * 1000,
        status: "confirmed",
        doctor: "Dra. Scanner",
        procedure: "Retorno",
        createdAt: now,
      });
    });

    await t.action(internal.automationActions.runScheduledAppointmentJob, {
      clinicId,
      appointmentId,
      jobKind: "oneHour",
    });
    await flushScheduled();

    const messages = await t.run(async (ctx) => {
      return (await ctx.db.query("messages").collect()).filter(
        (message) => message.clinicId === clinicId,
      );
    });

    expect(messages).toHaveLength(1);
    expect(messages[0].body).toContain("Helena Costa");
  });

  it("matches chats across Brazilian phone variations", async () => {
    const clinicId = "test-clinic-phone-variations";

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Carlos Lima",
      phone: "(11) 8888-7777",
      email: "carlos@example.com",
    });

    const chatId = await t.run(async (ctx) => {
      return await ctx.db.insert("chats", {
        clinicId,
        patientId: patient._id,
        whatsappChatId: "5511988887777@s.whatsapp.net",
        title: "Carlos Lima",
        unreadCount: 0,
        status: "open",
        isAiActive: true,
        createdAt: Date.now(),
      });
    });

    const chat = await t.query(internal.whatsappQueries.findChatByPhone, {
      clinicId,
      phone: "(11) 8888-7777",
    });

    expect(chat?._id).toBe(chatId);
  });

  it("tracks reminder delivery only after provider success", async () => {
    const clinicId = "test-clinic-reminder-tracking";
    const now = Date.now();

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Paula Reis",
      phone: "5511999991234",
      email: "paula@example.com",
    });

    const appointmentId = await t.run(async (ctx) => {
      const appointmentId = await ctx.db.insert("appointments", {
        clinicId,
        patientId: patient._id,
        startAt: now + 24 * 60 * 60 * 1000,
        endAt: now + 25 * 60 * 60 * 1000,
        status: "confirmed",
        doctor: "Dra. Provider",
        procedure: "Consulta",
        createdAt: now,
      });

      const chatId = await ctx.db.insert("chats", {
        clinicId,
        patientId: patient._id,
        whatsappChatId: "5511999991234@s.whatsapp.net",
        title: "Paula Reis",
        unreadCount: 0,
        status: "open",
        isAiActive: true,
        createdAt: now,
      });

      const messageId = await ctx.db.insert("messages", {
        clinicId,
        chatId,
        direction: "out",
        type: "text",
        body: "Lembrete de consulta",
        status: "sending",
        sentAt: now,
        createdAt: now,
      });

      await ctx.db.insert("whatsappInstances", {
        clinicId,
        instanceName: `meta_${clinicId}`,
        status: "connected",
        webhookConfigured: false,
        createdAt: now,
        provider: "meta",
        metaPhoneNumberId: "phone-number-id",
      });

      return { appointmentId, chatId, messageId };
    });

    await t.action(internal.whatsapp.sendTextAction, {
      chatId: appointmentId.chatId,
      text: "Lembrete de consulta",
      messageId: appointmentId.messageId,
      tracking: {
        clinicId,
        appointmentId: appointmentId.appointmentId,
        reminderType: "twentyFourHour",
      },
    });

    const { message, reminder } = await t.run(async (ctx) => {
      const message = await ctx.db.get(appointmentId.messageId);
      const reminder = (await ctx.db.query("appointmentReminders").collect()).find(
        (entry) =>
          entry.appointmentId === appointmentId.appointmentId &&
          entry.reminderType === "twentyFourHour",
      );

      return { message, reminder };
    });

    expect(message?.status).toBe("sent");
    expect(reminder?.status).toBe("sent");
    expect(reminder?.channels).toEqual(["whatsapp"]);
  });

  it("marks pending appointments as confirmed when the patient replies positively", async () => {
    const clinicId = "test-clinic-pending-to-confirmed";
    const now = Date.now();

    await seedConnectedWhatsApp(clinicId, now);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Patricia Confirmed",
      phone: "5511994444444",
      email: "patricia@example.com",
    });

    const doctorId = await t.run(async (ctx) => {
      return await ctx.db.insert("users", {
        authUserId: `auth-${clinicId}-doctor`,
        createdAt: now,
        clinicId,
        isActive: true,
        name: "Dr. Pending",
        email: "dr.pending@example.com",
        role: "doctor",
      });
    });

    const appointmentId = await t.run(async (ctx) => {
      return await ctx.db.insert("appointments", {
        clinicId,
        patientId: patient._id,
        startAt: now + 24 * 60 * 60 * 1000,
        endAt: now + 25 * 60 * 60 * 1000,
        status: "pending",
        doctorId,
        doctor: "Dr. Pending",
        procedure: "Consulta",
        createdAt: now,
      });
    });

    await t.action(internal.automationActions.sendAppointmentConfirmation, {
      appointmentId,
      clinicId,
    });
    await flushScheduled();

    const { chat, outboundMessage } = await t.run(async (ctx) => {
      const chat = (await ctx.db.query("chats").collect()).find(
        (entry) => entry.clinicId === clinicId,
      )!;
      const outboundMessage = (await ctx.db.query("messages").collect()).find(
        (message) =>
          message.clinicId === clinicId &&
          message.direction === "out" &&
          message.automationKind === "confirmationRequest",
      )!;

      return { chat, outboundMessage };
    });

    const inboundMessageId = await t.run(async (ctx) => {
      return await ctx.db.insert("messages", {
        clinicId,
        chatId: chat._id,
        patientId: patient._id,
        appointmentId,
        direction: "in",
        type: "text",
        body: "Sim",
        status: "delivered",
        replyToId: outboundMessage._id,
        sentAt: now + 1000,
        createdAt: now + 1000,
      });
    });

    const replyResult = await t.action(internal.automationActions.handleAppointmentReply, {
      clinicId,
      chatId: chat._id,
      messageId: inboundMessageId,
      patientId: patient._id,
    });
    await flushScheduled();

    expect(replyResult.handled).toBe(true);
    expect(replyResult.outcome).toBe("confirmed");

    const { appointment, jobs, messages } = await t.run(async (ctx) => {
      const appointment = await ctx.db.get(appointmentId);
      const jobs = (await ctx.db.query("appointmentScheduledJobs").collect()).filter(
        (job) => job.appointmentId === appointmentId,
      );
      const messages = (await ctx.db.query("messages").collect()).filter(
        (message) => message.clinicId === clinicId,
      );

      return { appointment, jobs, messages };
    });

    expect(appointment?.status).toBe("confirmed");
    expect(jobs.some((job) => job.jobKind === "appointmentConfirmation")).toBe(false);
    expect(jobs.some((job) => job.jobKind === "oneHour" && job.status === "scheduled")).toBe(true);
    expect(messages.some((message) => message.automationKind === "confirmationReply")).toBe(true);
  });

  it("cancels the appointment when the patient declines and rescheduling is not possible", async () => {
    const clinicId = "test-clinic-decline-cancel";
    const now = Date.now();

    await seedConnectedWhatsApp(clinicId, now);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Renata Cancel",
      phone: "5511995555555",
      email: "renata@example.com",
    });

    const appointmentId = await t.run(async (ctx) => {
      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "cancellationConfirmation",
        enabled: true,
        message: "Template customizado: consulta cancelada{{cancellation.reason}}.",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      return await ctx.db.insert("appointments", {
        clinicId,
        patientId: patient._id,
        startAt: now + 24 * 60 * 60 * 1000,
        endAt: now + 25 * 60 * 60 * 1000,
        status: "pending",
        doctor: "Dra. Cancel",
        procedure: "Consulta",
        createdAt: now,
      });
    });

    await t.action(internal.automationActions.sendAppointmentConfirmation, {
      appointmentId,
      clinicId,
    });
    await flushScheduled();

    const { chat, outboundMessage } = await t.run(async (ctx) => {
      const chat = (await ctx.db.query("chats").collect()).find(
        (entry) => entry.clinicId === clinicId,
      )!;
      const outboundMessage = (await ctx.db.query("messages").collect()).find(
        (message) =>
          message.clinicId === clinicId &&
          message.direction === "out" &&
          message.automationKind === "confirmationRequest",
      )!;

      return { chat, outboundMessage };
    });

    const inboundMessageId = await t.run(async (ctx) => {
      return await ctx.db.insert("messages", {
        clinicId,
        chatId: chat._id,
        patientId: patient._id,
        appointmentId,
        direction: "in",
        type: "text",
        body: "Nao",
        status: "delivered",
        replyToId: outboundMessage._id,
        sentAt: now + 1000,
        createdAt: now + 1000,
      });
    });

    const replyResult = await t.action(internal.automationActions.handleAppointmentReply, {
      clinicId,
      chatId: chat._id,
      messageId: inboundMessageId,
      patientId: patient._id,
    });
    await flushScheduled();

    expect(replyResult.handled).toBe(true);
    expect(replyResult.outcome).toBe("cancelled");

    const { appointment, messages } = await t.run(async (ctx) => {
      const appointment = await ctx.db.get(appointmentId);
      const messages = (await ctx.db.query("messages").collect()).filter(
        (message) => message.clinicId === clinicId,
      );

      return { appointment, messages };
    });

    expect(appointment?.status).toBe("cancelled");
    expect(
      messages.some(
        (message) =>
          message.automationKind === "cancellationConfirmation" &&
          message.body.includes("Template customizado: consulta cancelada"),
      ),
    ).toBe(true);
  });

  it("uses the saved Google review follow-up template and queues delivery via WhatsApp action", async () => {
    const clinicId = "test-clinic-google-follow-up";
    const now = Date.now();

    await seedConnectedWhatsApp(clinicId, now);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Julia Review",
      phone: "5511991231234",
      email: "julia@example.com",
    });

    const chatId = await t.run(async (ctx) => {
      await ctx.db.insert("clinics", {
        clinicId,
        name: "Clinica Review",
        createdAt: now,
      });

      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "googleReviewFollowUp",
        enabled: true,
        message: "Template review: {{patient.name}} -> {{nps.googleMapsLink}}",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      return await ctx.db.insert("chats", {
        clinicId,
        patientId: patient._id,
        whatsappChatId: "5511991231234@s.whatsapp.net",
        title: "Julia Review",
        unreadCount: 0,
        status: "open",
        isAiActive: true,
        createdAt: now,
      });
    });

    await t.action(internal.nps.sendGoogleReviewFollowUp, {
      clinicId,
      chatId,
      googleMapsLink: "https://g.page/r/test-review",
    });
    await flushScheduled();

    const messages = await t.run(async (ctx) => {
      return (await ctx.db.query("messages").collect()).filter(
        (message) => message.clinicId === clinicId,
      );
    });

    expect(messages).toHaveLength(1);
    expect(messages[0]?.body).toBe("Template review: Julia Review -> https://g.page/r/test-review");
    expect(sendTextMock).toHaveBeenCalled();
  });

  it("uses the saved detractor alert template and creates an admin chat when needed", async () => {
    const clinicId = "test-clinic-detractor-alert";
    const now = Date.now();

    await seedConnectedWhatsApp(clinicId, now);

    const patient = await t.mutation(api.patients.create, {
      clinicId,
      name: "Carlos Feedback",
      phone: "5511988880001",
      email: "carlos@example.com",
    });

    const appointmentId = await t.run(async (ctx) => {
      await ctx.db.insert("clinics", {
        clinicId,
        name: "Clinica NPS",
        createdAt: now,
      });

      await ctx.db.insert("users", {
        authUserId: `auth-${clinicId}-admin`,
        createdAt: now,
        clinicId,
        isActive: true,
        name: "Admin NPS",
        email: "admin@example.com",
        phone: "5511990000000",
        role: "admin",
      });

      await ctx.db.insert("reminderConfigs", {
        clinicId,
        type: "detractorAlert",
        enabled: true,
        message:
          "Template alerta: {{patient.name}} deu nota {{nps.score}} e disse {{nps.feedback}}.",
        channels: ["whatsapp"],
        useOfficialApi: false,
        createdAt: now,
        updatedAt: now,
      });

      return await ctx.db.insert("appointments", {
        clinicId,
        patientId: patient._id,
        startAt: now + 60 * 60 * 1000,
        endAt: now + 2 * 60 * 60 * 1000,
        status: "completed",
        doctor: "Dra. NPS",
        procedure: "Consulta",
        createdAt: now,
      });
    });

    await t.action(internal.nps.sendDetractorAlert, {
      clinicId,
      patientId: patient._id,
      appointmentId,
      score: 3,
      feedback: "demorou muito",
    });
    await flushScheduled();

    const { chats, messages } = await t.run(async (ctx) => {
      const chats = (await ctx.db.query("chats").collect()).filter(
        (chat) => chat.clinicId === clinicId,
      );
      const messages = (await ctx.db.query("messages").collect()).filter(
        (message) => message.clinicId === clinicId,
      );
      return { chats, messages };
    });

    expect(chats.some((chat) => chat.title === "Admin NPS")).toBe(true);
    expect(messages).toHaveLength(1);
    expect(messages[0]?.body).toBe(
      "Template alerta: Carlos Feedback deu nota 3 e disse demorou muito.",
    );
    expect(sendTextMock).toHaveBeenCalled();
  });
});
