import { register as registerBetterAuth } from "@convex-dev/better-auth/test";
import { convexTest } from "convex-test";

import schema from "../convex/schema";
import { modules } from "./modules";

export async function createTestConvex() {
  const t = convexTest(schema, modules);
  registerBetterAuth(t, "betterAuth");

  const defaultClinicId = process.env.DEFAULT_CLINIC_ID || "clinic-demo";
  await ensureClinic(t, defaultClinicId);

  return t;
}

export function withTestIdentity(
  t: ReturnType<typeof convexTest>,
  identity: Parameters<ReturnType<typeof convexTest>["withIdentity"]>[0],
) {
  const scoped = t.withIdentity(identity);
  registerBetterAuth(scoped, "betterAuth");
  return scoped;
}

export async function ensureClinic(t: ReturnType<typeof convexTest>, clinicId: string) {
  await t.run(async (ctx) => {
    const existing = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", clinicId))
      .first();

    if (!existing) {
      await ctx.db.insert("clinics", {
        clinicId,
        name: clinicId,
        plan: "professional",
        planStatus: "active",
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
    }
  });
}
