import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";

import { beforeEach, vi } from "vitest";

const envPath = resolve(process.cwd(), ".env.local");
if (existsSync(envPath)) {
  const raw = readFileSync(envPath, "utf8");
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const separator = trimmed.indexOf("=");
    if (separator <= 0) continue;
    const key = trimmed.slice(0, separator).trim();
    const value = trimmed.slice(separator + 1).trim();
    if (!(key in process.env)) {
      process.env[key] = value;
    }
  }
}

// Mock Mastra modules that cause import errors
vi.mock("@mastra/core", () => ({
  Mastra: vi.fn(),
}));

vi.mock("@mastra/core/workflow", () => ({
  workflow: vi.fn(),
  step: vi.fn(),
}));

vi.mock("@mastra/libsql", () => ({
  LibsqlVector: vi.fn(),
  LibSQLStore: class {
    constructor(config: any) {
      // Mock constructor
    }
  },
}));

vi.mock("@mastra/voice-openai", () => ({
  OpenAIVoice: vi.fn(),
}));

// Setup global test configuration
beforeEach(async () => {
  // Reset any global state before each test
  // This is where you can add test database cleanup, mocks, etc.
});
