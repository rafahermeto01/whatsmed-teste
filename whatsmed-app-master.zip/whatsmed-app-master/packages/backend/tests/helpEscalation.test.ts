import { describe, expect, it } from "vitest";

import { shouldEscalateToHumanSupport } from "../convex/whatsapp/escalationGuards.js";

describe("shouldEscalateToHumanSupport", () => {
  it("does not escalate on generic help wording alone", () => {
    const genericHelpMessages = [
      "ajuda",
      "preciso de ajuda",
      "help",
      "i need help with my appointment",
      "pode me ajudar com o agendamento?",
    ];

    genericHelpMessages.forEach((message) => {
      expect(shouldEscalateToHumanSupport(message)).toBe(false);
    });
  });

  it("escalates explicit human handoff requests", () => {
    const handoffMessages = [
      "quero falar com um humano",
      "me transfere para um atendente",
      "preciso falar com alguém da equipe",
      "I want to talk to a human",
      "connect me to a live agent",
    ];

    handoffMessages.forEach((message) => {
      expect(shouldEscalateToHumanSupport(message)).toBe(true);
    });
  });

  it("escalates clear emergency signals", () => {
    const emergencyMessages = [
      "isso é uma emergência",
      "não consigo respirar",
      "dor no peito e sangrando muito",
      "this is an emergency",
      "I can't breathe",
    ];

    emergencyMessages.forEach((message) => {
      expect(shouldEscalateToHumanSupport(message)).toBe(true);
    });
  });
});
