import { beforeEach, describe, expect, it } from "vitest";

import { internal } from "../convex/_generated/api";
import {
  hasPatientFacingTransferIntent,
  isNewConversationStartMessage,
  trimConversationToActiveSession,
} from "../convex/automationAi";
import { sanitizePatientFacingResponse } from "../convex/lib/patientResponse";
import { createTestConvex } from "./harness";

async function seedAiSettings(t: Awaited<ReturnType<typeof createTestConvex>>, clinicId: string) {
  await t.run(async (ctx) => {
    await ctx.db.insert("aiSettings", {
      clinicId,
      enabled: true,
      tone: "empathetic",
      activeHoursStart: "00:00",
      activeHoursEnd: "23:59",
      is247: true,
      voiceNotesEnabled: true,
      responseDelaySeconds: 0,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });
  });
}

/**
 * Creates complete test fixtures for AI scheduling tests
 * Returns real IDs that can be used with tools
 */
async function createSchedulingFixtures(
  t: Awaited<ReturnType<typeof createTestConvex>>,
  clinicId: string,
) {
  // Create doctor with working hours
  const doctorId = await t.run(async (ctx) => {
    const did = await ctx.db.insert("users", {
      clinicId,
      authUserId: `auth-test-doctor-${clinicId}-${Date.now()}`,
      email: `doctor.test.${clinicId}@example.com`,
      name: "Dr. Rafael Test",
      role: "doctor",
      isActive: true,
      specialties: ["Cardiologia"],
      workingHours: [
        {
          dayOfWeek: 1, // Monday
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
        {
          dayOfWeek: 2, // Tuesday
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
        {
          dayOfWeek: 3, // Wednesday
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
        {
          dayOfWeek: 4, // Thursday
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
        {
          dayOfWeek: 5, // Friday
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
      ],
      createdAt: Date.now(),
    });
    return did;
  });

  // Create procedure for the doctor
  const procedureId = await t.run(async (ctx) => {
    const pid = await ctx.db.insert("procedures", {
      clinicId,
      doctorId,
      name: "Consulta em Cardiologia",
      durationMinutes: 30,
      price: 20000, // R$ 200.00 in cents
      isTelemedicine: true,
      isInPerson: true,
      isActive: true,
      createdAt: Date.now(),
    });
    return pid;
  });

  // Create test patient
  const patientId = await t.run(async (ctx) => {
    const pid = await ctx.db.insert("patients", {
      clinicId,
      name: "Rafael Hermeto Test",
      phone: "5511999999999",
      email: "rafael.test@example.com",
      status: "active",
      createdAt: Date.now(),
    });
    return pid;
  });

  return { doctorId, procedureId, patientId };
}

describe("Automation AI triage guards", () => {
  let t: Awaited<ReturnType<typeof createTestConvex>>;

  beforeEach(async () => {
    t = await createTestConvex();
  });

  it("returns emergency guidance for severe symptoms before calling the model", async () => {
    const clinicId = "triage-emergency-clinic";
    await seedAiSettings(t, clinicId);

    const result = await t.action(internal.automationAi.generateAiResponse, {
      clinicId,
      message: "Estou com muita dor no peito e falta de ar.",
    });

    expect(result.reason).toBe("medical_emergency_guard");
    expect(result.response).toContain("emergência");
    expect(result.response).toContain("pronto-socorro");
  });

  it("returns high-priority guidance for moderate symptoms before calling the model", async () => {
    const clinicId = "triage-priority-clinic";
    await seedAiSettings(t, clinicId);

    const result = await t.action(internal.automationAi.generateAiResponse, {
      clinicId,
      message: "Estou com febre ha 3 dias e dor de cabeca forte.",
    });

    expect(result.reason).toBe("high_priority_triage_guard");
    expect(result.response).toContain("prioridade elevada");
    expect(result.response).toContain("encaixe");
  });
});

describe("Automation AI conversation session trimming", () => {
  it("drops old resolved scheduling context when a new conversation starts", () => {
    const baseTimestamp = Date.now();
    const messages = [
      {
        direction: "in",
        body: "sim",
        sentAt: baseTimestamp,
      },
      {
        direction: "out",
        body: "Agendamento confirmado! Consulta presencial com Dr. Rafael na sexta, 13/03/2026 às 10:00. ID do agendamento: abc123.",
        sentAt: baseTimestamp + 1000,
      },
    ];

    expect(isNewConversationStartMessage("Ola quero marcar uma consulta")).toBe(true);
    expect(trimConversationToActiveSession(messages, "Ola quero marcar uma consulta")).toEqual([]);
  });

  it("keeps the current context for follow-up questions inside the same flow", () => {
    const baseTimestamp = Date.now();
    const messages = [
      {
        direction: "out",
        body: "Qual a sua data de nascimento? Por favor no formato DD/MM/AAAA.",
        sentAt: baseTimestamp,
      },
      {
        direction: "in",
        body: "Tem horário de tarde pra cardiologia com dr rafael?",
        sentAt: baseTimestamp + 1000,
      },
    ];

    expect(trimConversationToActiveSession(messages, "Segunda nao tem de tarde?")).toEqual(
      messages,
    );
  });

  it("starts from the most recent activity block after a long inactivity gap", () => {
    const baseTimestamp = Date.now();
    const messages = [
      {
        direction: "out",
        body: "Mensagem antiga",
        sentAt: baseTimestamp,
      },
      {
        direction: "in",
        body: "Mensagem recente",
        sentAt: baseTimestamp + 7 * 60 * 60 * 1000,
      },
      {
        direction: "out",
        body: "Resposta recente",
        sentAt: baseTimestamp + 7 * 60 * 60 * 1000 + 1000,
      },
    ];

    expect(trimConversationToActiveSession(messages, "tem horario?")).toEqual(messages.slice(1));
  });
});

describe("Patient-facing response sanitizer", () => {
  it("removes internal IDs and field names from patient replies", () => {
    const result = sanitizePatientFacingResponse(
      'Agendamento confirmado. ID do agendamento: j7fzw9x241qvrk1asdtwdfcyn7yq4rc. doctorId: "j7fzw9x241qvrk1asdtwdfcyn7yq4rc" procedureId: "k172ey7yh5hqy7f0m1syg7khvn7yq32s"',
    );

    expect(result).toContain("Agendamento confirmado");
    expect(result).not.toMatch(/doctorId|procedureId|appointmentId|_id/i);
    expect(result).not.toMatch(/[A-Za-z0-9]{24,}/);
  });

  it("rewrites common English tool text into patient-friendly Portuguese", () => {
    const result = sanitizePatientFacingResponse(
      "Appointment not found. Please check the spelling or try a different name. Use one of these dates.",
    );

    expect(result).toContain("Nao consegui localizar esse agendamento");
    expect(result).toContain("confira o nome");
    expect(result).toContain("datas disponiveis");
    expect(result).not.toContain("Appointment not found");
    expect(result).not.toContain("Use one of these dates");
  });

  it("removes leaked tool traces before sending replies to patients", () => {
    const result = sanitizePatientFacingResponse(
      "Ferramenta chamada updatePatientData args= patientId :, updates : name : Rafael Hermeto da Rocha Resultado persistido da ferramenta updatePatientData success :, message : Dados do paciente atualizados com sucesso, updatedFields : name Obrigado, Rafael! Qual a sua data de nascimento (DD/MM/AAAA)?",
    );

    expect(result).toBe("Obrigado, Rafael! Qual a sua data de nascimento (DD/MM/AAAA)?");
    expect(result).not.toMatch(/ferramenta chamada|resultado persistido|updatedfields|args=/i);
  });
});

describe("Internal chat message filtering", () => {
  let t: Awaited<ReturnType<typeof createTestConvex>>;

  beforeEach(async () => {
    t = await createTestConvex();
  });

  it("excludes internal tool messages from AI conversation history", async () => {
    const clinicId = "internal-message-filter-clinic";
    await seedAiSettings(t, clinicId);

    const chatId = await t.run(async (ctx) => {
      const createdAt = Date.now();
      const chatId = await ctx.db.insert("chats", {
        clinicId,
        whatsappChatId: "5511999999999@c.us",
        unreadCount: 0,
        status: "open",
        isAiActive: true,
        createdAt,
        updatedAt: createdAt,
      });

      await ctx.db.insert("messages", {
        clinicId,
        chatId,
        direction: "in",
        type: "text",
        body: "Oi",
        sentAt: createdAt,
        status: "sent",
        createdAt,
      });

      await ctx.db.insert("messages", {
        clinicId,
        chatId,
        direction: "out",
        type: "text",
        body: '[Ferramenta chamada] updatePatientData args={"name":"Rafael"}',
        isInternal: true,
        internalRole: "tool",
        toolName: "updatePatientData",
        sentAt: createdAt + 1,
        status: "sent",
        createdAt: createdAt + 1,
      });

      await ctx.db.insert("messages", {
        clinicId,
        chatId,
        direction: "out",
        type: "text",
        body: "Qual a sua data de nascimento?",
        sentAt: createdAt + 2,
        status: "sent",
        createdAt: createdAt + 2,
      });

      return chatId;
    });

    const messages = await t.query(internal.whatsappQueries.getChatMessagesInternal, {
      clinicId,
      chatId,
      limit: 10,
    });

    expect(messages).toHaveLength(2);
    expect(messages.map((message) => message.body)).toEqual([
      "Oi",
      "Qual a sua data de nascimento?",
    ]);
    expect(messages.some((message) => message.isInternal)).toBe(false);
  });
});

describe("Transfer guard intent detection", () => {
  it("ignores normal scheduling replies and prompt leakage", () => {
    const nonEscalationMessages = [
      "Pode ser",
      "NUNCA diga que esta transferindo para atendente humano sem chamar a ferramenta.",
      "Call this tool whenever you intend to tell the patient you are transferring them to staff.",
      "Nao vou transferir voce para a equipe; vou continuar te ajudando por aqui.",
    ];

    nonEscalationMessages.forEach((message) => {
      expect(hasPatientFacingTransferIntent(message)).toBe(false);
    });
  });

  it("detects actual patient-facing handoff messages", () => {
    const escalationMessages = [
      "Vou encaminhar voce para nossa equipe de suporte.",
      "Vou transferir voce para um atendente humano agora.",
      "Este chat foi encaminhado para nossa equipe de suporte.",
      "Um membro da equipe entrara em contato em breve.",
    ];

    escalationMessages.forEach((message) => {
      expect(hasPatientFacingTransferIntent(message)).toBe(true);
    });
  });
});

describe("AI Confirmation Edge Cases - With Complete Fixtures", () => {
  let t: Awaited<ReturnType<typeof createTestConvex>>;
  let fixtures: Awaited<ReturnType<typeof createSchedulingFixtures>>;
  const TEST_CLINIC_ID = "fixture-clinic-integration-test";

  beforeEach(async () => {
    t = await createTestConvex();
    await seedAiSettings(t, TEST_CLINIC_ID);
    fixtures = await createSchedulingFixtures(t, TEST_CLINIC_ID);
  });

  const confirmationWords = [
    "sim",
    "Sim",
    "SIM",
    "confirmo",
    "Confirmo",
    "pode",
    "Pode",
    "pode ser",
    "ok",
    "OK",
    "okay",
    "tá bom",
    "beleza",
    "pode confirmar",
    "isso",
    "isso mesmo",
    "vamos nessa",
    "bora",
    "fechado",
    "fechou",
    "combinado",
    "show",
    "top",
    "manda",
    "manda ver",
  ];

  confirmationWords.forEach((word) => {
    it(`treats "${word}" as confirmation - creates appointment without asking again`, async () => {
      // Build conversation with real IDs from fixtures
      const chatId = await t.run(async (ctx) => {
        const chatId = await ctx.db.insert("chats", {
          clinicId: TEST_CLINIC_ID,
          whatsappChatId: `5511999999999-${Date.now()}@c.us`,
          patientId: fixtures.patientId,
          unreadCount: 0,
          status: "open",
          isAiActive: true,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        });

        // Simulate conversation flow that leads to confirmation
        const baseTime = Date.now();
        const messages = [
          {
            dir: "out" as const,
            body: `Olá! O ${fixtures.doctorId} tem disponibilidade. Qual especialidade?`,
            delay: 0,
          },
          { dir: "in" as const, body: "Cardiologia", delay: 1000 },
          {
            dir: "out" as const,
            body: `O Dr. Rafael Test realiza Consulta em Cardiologia. Vou verificar os horários.`,
            delay: 2000,
          },
          { dir: "in" as const, body: "Quarta", delay: 3000 },
          {
            dir: "out" as const,
            body: "Na quarta-feira temos 09:00, 10:00, 11:00. Qual horário?",
            delay: 4000,
          },
          { dir: "in" as const, body: "9h", delay: 5000 },
          {
            dir: "out" as const,
            body: `Perfeito! Vou confirmar:\n- Paciente: Rafael Test\n- Consulta em Cardiologia\n- Dr. Rafael Test\n- Quarta-feira, 02/04 às 09:00\n- Presencial\n- Particular: R$ 200,00\n\nTudo certo? Posso confirmar?`,
            delay: 6000,
          },
        ];

        for (const msg of messages) {
          await ctx.db.insert("messages", {
            clinicId: TEST_CLINIC_ID,
            chatId,
            direction: msg.dir,
            type: "text",
            body: msg.body,
            sentAt: baseTime + msg.delay,
            status: "sent",
            createdAt: baseTime + msg.delay,
          });
        }

        return chatId;
      });

      // Patient confirms with the test word
      const result = await t.action(internal.automationAi.generateAiResponse, {
        clinicId: TEST_CLINIC_ID,
        message: word,
        threadId: chatId,
        patientId: fixtures.patientId,
      });

      // THOROUGH ASSERTIONS:
      expect(result.response).toBeTruthy();
      expect(typeof result.response).toBe("string");

      const responseLower = result.response.toLowerCase();

      // AI should NOT ask for confirmation again
      expect(responseLower).not.toMatch(/confirma.*\?/i);
      expect(responseLower).not.toMatch(/tudo certo.*\?/i);
      expect(responseLower).not.toMatch(/posso.*(confirmar|agendar).*\?/i);

      // AI should indicate success or acknowledgment
      const hasSuccessIndicator =
        responseLower.includes("confirm") ||
        responseLower.includes("agend") ||
        responseLower.includes("marcado") ||
        responseLower.includes("ok") ||
        responseLower.includes("ótimo") ||
        responseLower.includes("perfeito");

      expect(hasSuccessIndicator).toBe(true);

      // Verify appointment was actually created
      const appointments = await t.query(internal.appointments.listInternal, {
        clinicId: TEST_CLINIC_ID,
        patientId: fixtures.patientId,
        limit: 10,
      });

      // Should have at least one appointment created
      expect(appointments.items.length).toBeGreaterThan(0);

      // Verify it's with the right doctor
      const recentAppointment = appointments.items[0];
      expect(recentAppointment.doctorId).toBe(fixtures.doctorId);
      expect(recentAppointment.procedureId).toBe(fixtures.procedureId);
    });
  });

  const denialWords = [
    "não",
    "Não",
    "NÃO",
    "nao",
    "cancela",
    "Cancela",
    "muda",
    "Muda",
    "troca",
    "Troca",
    "altera",
    "Altera",
    "outro horário",
    "outro dia",
    "não quero",
    "desiste",
    "cancelar",
  ];

  denialWords.forEach((word) => {
    it(`treats "${word}" as denial - asks what to change without creating appointment`, async () => {
      const chatId = await t.run(async (ctx) => {
        const chatId = await ctx.db.insert("chats", {
          clinicId: TEST_CLINIC_ID,
          whatsappChatId: `5511999999999-${Date.now()}@c.us`,
          patientId: fixtures.patientId,
          unreadCount: 0,
          status: "open",
          isAiActive: true,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        });

        // Add confirmation request to context
        await ctx.db.insert("messages", {
          clinicId: TEST_CLINIC_ID,
          chatId,
          direction: "out",
          type: "text",
          body: `Confirmo: Dr. Rafael Test, Consulta em Cardiologia, 02/04 às 09:00. Confirma?`,
          sentAt: Date.now() - 1000,
          status: "sent",
          createdAt: Date.now() - 1000,
        });

        return chatId;
      });

      // Count appointments before
      const appointmentsBefore = await t.query(internal.appointments.listInternal, {
        clinicId: TEST_CLINIC_ID,
        patientId: fixtures.patientId,
        limit: 100,
      });
      const countBefore = appointmentsBefore.items.length;

      // Patient denies
      const result = await t.action(internal.automationAi.generateAiResponse, {
        clinicId: TEST_CLINIC_ID,
        message: word,
        threadId: chatId,
        patientId: fixtures.patientId,
      });

      // THOROUGH ASSERTIONS:
      expect(result.response).toBeTruthy();

      const responseLower = result.response.toLowerCase();

      // AI should offer to change something or ask what to adjust
      const offersChange =
        responseLower.match(/mudar|alterar|trocar|ajustar|mudança/i) ||
        responseLower.match(/qual|quais|o que|como|onde/i) ||
        responseLower.match(/posso|vou|gostaria/i);

      expect(offersChange).toBeTruthy();

      // AI should NOT confirm appointment
      expect(responseLower).not.toMatch(/confirmado.*agendamento/i);
      expect(responseLower).not.toMatch(/está.*marcado/i);

      // Verify NO new appointment was created
      const appointmentsAfter = await t.query(internal.appointments.listInternal, {
        clinicId: TEST_CLINIC_ID,
        patientId: fixtures.patientId,
        limit: 100,
      });

      expect(appointmentsAfter.items.length).toBe(countBefore);
    });
  });

  it("handles ambiguous responses by asking for clarification", async () => {
    const chatId = await t.run(async (ctx) => {
      const chatId = await ctx.db.insert("chats", {
        clinicId: TEST_CLINIC_ID,
        whatsappChatId: `5511999999999-${Date.now()}@c.us`,
        patientId: fixtures.patientId,
        unreadCount: 0,
        status: "open",
        isAiActive: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });

      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: `Confirmo: Consulta em Cardiologia, 02/04 às 09:00. Confirma?`,
        sentAt: Date.now() - 1000,
        status: "sent",
        createdAt: Date.now() - 1000,
      });

      return chatId;
    });

    const ambiguousResponses = ["talvez", "vou pensar", "depois eu vejo", "quase", "mais ou menos"];

    for (const response of ambiguousResponses) {
      const result = await t.action(internal.automationAi.generateAiResponse, {
        clinicId: TEST_CLINIC_ID,
        message: response,
        threadId: chatId,
        patientId: fixtures.patientId,
      });

      expect(result.response).toBeTruthy();
      // Should ask for clarification
      expect(result.response.toLowerCase()).toMatch(/(confirma|certeza|claro|ajuda|posso)/i);
    }
  });

  it("does not ask for confirmation again when patient already confirmed", async () => {
    const chatId = await t.run(async (ctx) => {
      const chatId = await ctx.db.insert("chats", {
        clinicId: TEST_CLINIC_ID,
        whatsappChatId: `5511999999999-${Date.now()}@c.us`,
        patientId: fixtures.patientId,
        unreadCount: 0,
        status: "open",
        isAiActive: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });

      // Simulate that confirmation was already processed
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: "Tudo certo? Posso confirmar o agendamento?",
        sentAt: Date.now() - 3000,
        status: "sent",
        createdAt: Date.now() - 3000,
      });

      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "in",
        type: "text",
        body: "sim",
        sentAt: Date.now() - 2000,
        status: "sent",
        createdAt: Date.now() - 2000,
      });

      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: "Perfeito! Agendamento confirmado.",
        sentAt: Date.now() - 1000,
        status: "sent",
        createdAt: Date.now() - 1000,
      });

      return chatId;
    });

    // Patient sends another confirmation
    const result = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "sim",
      threadId: chatId,
      patientId: fixtures.patientId,
    });

    expect(result.response).toBeTruthy();
    expect(result.response.toLowerCase()).not.toMatch(/(confirma|tudo certo|posso).*agendar/i);
  });
});

/**
 * Creates complete test fixtures for the full scheduling flow test
 * Simulates a real clinic with doctors, procedures, and patient data
 */
async function createFullSchedulingFixtures(
  t: Awaited<ReturnType<typeof createTestConvex>>,
  clinicId: string,
) {
  // Create clinic if not exists
  await t.run(async (ctx) => {
    const existing = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", clinicId))
      .first();
    if (!existing) {
      await ctx.db.insert("clinics", {
        clinicId,
        name: "Clínica Teste Full Flow",
        plan: "professional",
        planStatus: "active",
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
    }
  });

  // Create cardiologista doctor
  const doctorId = await t.run(async (ctx) => {
    const did = await ctx.db.insert("users", {
      clinicId,
      authUserId: `auth-test-dr-rafael-${Date.now()}`,
      email: "dr.rafael@test.com",
      name: "Dr Rafael",
      role: "doctor",
      isActive: true,
      specialties: ["Cardiologia"],
      workingHours: [
        {
          dayOfWeek: 1,
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
        {
          dayOfWeek: 2,
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
        {
          dayOfWeek: 3,
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
        {
          dayOfWeek: 4,
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
        {
          dayOfWeek: 5,
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
      ],
      createdAt: Date.now(),
    });
    return did;
  });

  // Create urologist doctor
  const doctorIdUro = await t.run(async (ctx) => {
    const did = await ctx.db.insert("users", {
      clinicId,
      authUserId: `auth-test-dr-josefino-${Date.now()}`,
      email: "dr.josefino@test.com",
      name: "Dr Josefino",
      role: "doctor",
      isActive: true,
      specialties: ["Urologia"],
      workingHours: [
        {
          dayOfWeek: 1,
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
        {
          dayOfWeek: 2,
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
        {
          dayOfWeek: 3,
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
        {
          dayOfWeek: 4,
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
        {
          dayOfWeek: 5,
          slots: [{ start: "09:00", end: "18:00", types: ["in_person", "telemedicine"] }],
        },
      ],
      createdAt: Date.now(),
    });
    return did;
  });

  // Create cardiologia procedure
  const procedureId = await t.run(async (ctx) => {
    const pid = await ctx.db.insert("procedures", {
      clinicId,
      doctorId,
      name: "Consulta em Cardiologia",
      durationMinutes: 30,
      price: 20000,
      isTelemedicine: true,
      isInPerson: true,
      isActive: true,
      createdAt: Date.now(),
    });
    return pid;
  });

  // Create urologia procedure
  const procedureIdUro = await t.run(async (ctx) => {
    const pid = await ctx.db.insert("procedures", {
      clinicId,
      doctorId: doctorIdUro,
      name: "Consulta em Urologia",
      durationMinutes: 30,
      price: 25000,
      isTelemedicine: true,
      isInPerson: true,
      isActive: true,
      createdAt: Date.now(),
    });
    return pid;
  });

  // Create test patient
  const patientId = await t.run(async (ctx) => {
    const pid = await ctx.db.insert("patients", {
      clinicId,
      name: "Rafael Hermeto da Rocha",
      phone: "5511999999999",
      email: "rafahermeto@test.com",
      dateOfBirth: new Date("2000-07-11").getTime(),
      gender: "male",
      paymentType: "private",
      status: "active",
      createdAt: Date.now(),
    });
    return pid;
  });

  return {
    clinicId,
    doctorId,
    doctorIdUro,
    procedureId,
    procedureIdUro,
    patientId,
  };
}

describe("Full Scheduling Messaging Flow - End to End", () => {
  let t: Awaited<ReturnType<typeof createTestConvex>>;
  let fixtures: Awaited<ReturnType<typeof createFullSchedulingFixtures>>;
  const TEST_CLINIC_ID = "full-scheduling-flow-test-" + Date.now();

  beforeEach(async () => {
    t = await createTestConvex();
    fixtures = await createFullSchedulingFixtures(t, TEST_CLINIC_ID);
  });

  it("completes full patient intake flow and creates appointment", async () => {
    // Create chat
    const chatId = await t.run(async (ctx) => {
      return await ctx.db.insert("chats", {
        clinicId: TEST_CLINIC_ID,
        whatsappChatId: `5511999999999-${Date.now()}@c.us`,
        patientId: fixtures.patientId,
        unreadCount: 0,
        status: "open",
        isAiActive: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
    });

    let baseTime = Date.now();

    // Step 1: Patient initiates scheduling
    const r1 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "Marcar consulta",
      threadId: chatId,
      patientId: fixtures.patientId,
    });
    expect(r1.response).toBeTruthy();
    expect(r1.response.toLowerCase()).toMatch(/(dentista|paciente|parceiro)/i);
    console.log("[Step 1] Initiate scheduling:", r1.response.substring(0, 100));

    // Step 2: Patient says they're a patient
    await t.run(async (ctx) => {
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: r1.response,
        sentAt: baseTime + 100,
        status: "sent",
        createdAt: baseTime + 100,
      });
    });

    const r2 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "Paciente",
      threadId: chatId,
      patientId: fixtures.patientId,
    });
    expect(r2.response).toBeTruthy();
    expect(r2.response.toLowerCase()).toMatch(/(nome|data de nascimento|nasc)/i);
    console.log("[Step 2] Ask for name:", r2.response.substring(0, 100));

    // Step 3: Patient provides name
    baseTime += 1000;
    await t.run(async (ctx) => {
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: r2.response,
        sentAt: baseTime + 100,
        status: "sent",
        createdAt: baseTime + 100,
      });
    });

    const r3 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "Rafael Hermeto da Rocha",
      threadId: chatId,
      patientId: fixtures.patientId,
    });
    expect(r3.response).toBeTruthy();
    expect(r3.response.toLowerCase()).toMatch(/(data de nascimento|nasc|DD\/MM)/i);
    console.log("[Step 3] Name provided:", r3.response.substring(0, 100));

    // Step 4: Patient provides date of birth
    baseTime += 1000;
    await t.run(async (ctx) => {
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: r3.response,
        sentAt: baseTime + 100,
        status: "sent",
        createdAt: baseTime + 100,
      });
    });

    const r4 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "11072000",
      threadId: chatId,
      patientId: fixtures.patientId,
    });
    expect(r4.response).toBeTruthy();
    expect(r4.response.toLowerCase()).toMatch(/(sexo|gênero|masculino|feminino)/i);
    console.log("[Step 4] DOB provided:", r4.response.substring(0, 100));

    // Step 5: Patient provides gender
    baseTime += 1000;
    await t.run(async (ctx) => {
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: r4.response,
        sentAt: baseTime + 100,
        status: "sent",
        createdAt: baseTime + 100,
      });
    });

    const r5 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "Masculino",
      threadId: chatId,
      patientId: fixtures.patientId,
    });
    expect(r5.response).toBeTruthy();
    expect(r5.response.toLowerCase()).toMatch(/(consulta|exame|agendar)/i);
    console.log("[Step 5] Gender provided:", r5.response.substring(0, 100));

    // Step 6: Patient says consultation
    baseTime += 1000;
    await t.run(async (ctx) => {
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: r5.response,
        sentAt: baseTime + 100,
        status: "sent",
        createdAt: baseTime + 100,
      });
    });

    const r6 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "Consulta",
      threadId: chatId,
      patientId: fixtures.patientId,
    });
    expect(r6.response).toBeTruthy();
    expect(r6.response.toLowerCase()).toMatch(/(convênio|particular|plano)/i);
    console.log("[Step 6] Type confirmed:", r6.response.substring(0, 100));

    // Step 7: Patient says private
    baseTime += 1000;
    await t.run(async (ctx) => {
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: r6.response,
        sentAt: baseTime + 100,
        status: "sent",
        createdAt: baseTime + 100,
      });
    });

    const r7 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "Particular",
      threadId: chatId,
      patientId: fixtures.patientId,
    });
    expect(r7.response).toBeTruthy();
    expect(r7.response.toLowerCase()).toMatch(/(especialidade|cardiologia|urologia|qual)/i);
    console.log("[Step 7] Payment type:", r7.response.substring(0, 100));

    // Step 8: Patient chooses cardiology
    baseTime += 1000;
    await t.run(async (ctx) => {
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: r7.response,
        sentAt: baseTime + 100,
        status: "sent",
        createdAt: baseTime + 100,
      });
    });

    const r8 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "Cardio",
      threadId: chatId,
      patientId: fixtures.patientId,
    });
    expect(r8.response).toBeTruthy();
    console.log("[Step 8] Specialty:", r8.response.substring(0, 150));

    // Step 9: Patient chooses doctor
    baseTime += 1000;
    await t.run(async (ctx) => {
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: r8.response,
        sentAt: baseTime + 100,
        status: "sent",
        createdAt: baseTime + 100,
      });
    });

    const r9 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "Dr rafael",
      threadId: chatId,
      patientId: fixtures.patientId,
    });
    expect(r9.response).toBeTruthy();
    expect(r9.response.toLowerCase()).toMatch(/(telemedicina|presencial)/i);
    console.log("[Step 9] Doctor:", r9.response.substring(0, 100));

    // Step 10: Patient chooses telemedicine
    baseTime += 1000;
    await t.run(async (ctx) => {
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: r9.response,
        sentAt: baseTime + 100,
        status: "sent",
        createdAt: baseTime + 100,
      });
    });

    const r10 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "Telemedicina",
      threadId: chatId,
      patientId: fixtures.patientId,
    });
    expect(r10.response).toBeTruthy();
    expect(r10.response.toLowerCase()).toMatch(/(e-mail|email)/i);
    console.log("[Step 10] Type:", r10.response.substring(0, 100));

    // Step 11: Patient provides email
    baseTime += 1000;
    await t.run(async (ctx) => {
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: r10.response,
        sentAt: baseTime + 100,
        status: "sent",
        createdAt: baseTime + 100,
      });
    });

    const r11 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "Rafahermeto@test.com",
      threadId: chatId,
      patientId: fixtures.patientId,
    });
    expect(r11.response).toBeTruthy();
    console.log("[Step 11] Email provided:", r11.response.substring(0, 150));

    // Check that patient data was saved
    const patientData = await t.query(internal.patients.getByIdInternal, {
      id: fixtures.patientId,
      clinicId: TEST_CLINIC_ID,
    });

    expect(patientData).toBeTruthy();
    expect(patientData?.name).toBe("Rafael Hermeto da Rocha");
    expect(patientData?.email).toBe("Rafahermeto@test.com");
    expect(patientData?.gender).toBe("male");
    expect(patientData?.paymentType).toBe("private");

    console.log("✅ Patient data saved correctly:", {
      name: patientData?.name,
      email: patientData?.email,
      gender: patientData?.gender,
      paymentType: patientData?.paymentType,
    });
  });

  it("handles availability check with telemedicine preference", async () => {
    const chatId = await t.run(async (ctx) => {
      return await ctx.db.insert("chats", {
        clinicId: TEST_CLINIC_ID,
        whatsappChatId: `5511999999999-${Date.now()}@c.us`,
        patientId: fixtures.patientId,
        unreadCount: 0,
        status: "open",
        isAiActive: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
    });

    // Simulate full flow completed
    await t.run(async (ctx) => {
      const baseTime = Date.now();
      // Add some context messages
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: "Ótimo! Vou verificar a disponibilidade para cardiologia com Dr Rafael.",
        sentAt: baseTime,
        status: "sent",
        createdAt: baseTime,
      });
    });

    // Patient asks about availability
    const result = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "Tem horário de manhã?",
      threadId: chatId,
      patientId: fixtures.patientId,
    });

    expect(result.response).toBeTruthy();
    // Should use availability tool and return real slots
    console.log("[Availability check] Response:", result.response.substring(0, 200));
  });

  it("validates telemedicine vs in-person toggle correctly", async () => {
    const chatId = await t.run(async (ctx) => {
      return await ctx.db.insert("chats", {
        clinicId: TEST_CLINIC_ID,
        whatsappChatId: `5511999999999-${Date.now()}@c.us`,
        patientId: fixtures.patientId,
        unreadCount: 0,
        status: "open",
        isAiActive: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
    });

    // Add conversation context where patient chose telemedicine
    await t.run(async (ctx) => {
      const baseTime = Date.now();
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: "Você gostaria de agendar uma consulta ou um exame?",
        sentAt: baseTime,
        status: "sent",
        createdAt: baseTime,
      });
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "in",
        type: "text",
        body: "Consulta",
        sentAt: baseTime + 1000,
        status: "sent",
        createdAt: baseTime + 1000,
      });
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: "O atendimento será por convênio ou particular?",
        sentAt: baseTime + 2000,
        status: "sent",
        createdAt: baseTime + 2000,
      });
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "in",
        type: "text",
        body: "Particular",
        sentAt: baseTime + 3000,
        status: "sent",
        createdAt: baseTime + 3000,
      });
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: "Cardiologia ou urologista? Qual especialidade você procura?",
        sentAt: baseTime + 4000,
        status: "sent",
        createdAt: baseTime + 4000,
      });
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "in",
        type: "text",
        body: "Cardio",
        sentAt: baseTime + 5000,
        status: "sent",
        createdAt: baseTime + 5000,
      });
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: "Temos o Dr Rafael em cardiologia. Prefere ele ou pode ser qualquer um?",
        sentAt: baseTime + 6000,
        status: "sent",
        createdAt: baseTime + 6000,
      });
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "in",
        type: "text",
        body: "Dr Rafael",
        sentAt: baseTime + 7000,
        status: "sent",
        createdAt: baseTime + 7000,
      });
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: "Ótimo! O Dr Rafael atende em cardiologia. Será telemedicina ou presencial?",
        sentAt: baseTime + 8000,
        status: "sent",
        createdAt: baseTime + 8000,
      });
    });

    // Patient chooses telemedicine
    const r1 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "Telemedicina",
      threadId: chatId,
      patientId: fixtures.patientId,
    });

    expect(r1.response).toBeTruthy();
    expect(r1.response.toLowerCase()).toMatch(/(e-mail|email)/i);
    console.log("[Telemedicine selected]", r1.response.substring(0, 100));

    // Now patient changes to presencial
    await t.run(async (ctx) => {
      const baseTime = Date.now();
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: r1.response,
        sentAt: baseTime,
        status: "sent",
        createdAt: baseTime,
      });
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "in",
        type: "text",
        body: "rafahermeto@test.com",
        sentAt: baseTime + 1000,
        status: "sent",
        createdAt: baseTime + 1000,
      });
    });

    // Bot would typically show unavailable, then patient asks for presencial
    const r2 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "Pode ser presencial",
      threadId: chatId,
      patientId: fixtures.patientId,
    });

    // Should check presencial availability
    expect(r2.response).toBeTruthy();
    console.log("[Changed to presencial]", r2.response.substring(0, 150));
  });

  it("saves patient data correctly during intake flow", async () => {
    // Create new patient for this test
    const newPatientId = await t.run(async (ctx) => {
      return await ctx.db.insert("patients", {
        clinicId: TEST_CLINIC_ID,
        name: "Novo Paciente",
        phone: "5511888888888",
        status: "active",
        createdAt: Date.now(),
      });
    });

    const chatId = await t.run(async (ctx) => {
      return await ctx.db.insert("chats", {
        clinicId: TEST_CLINIC_ID,
        whatsappChatId: `5511888888888-${Date.now()}@c.us`,
        patientId: newPatientId,
        unreadCount: 0,
        status: "open",
        isAiActive: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
    });

    // Simulate name collection
    await t.run(async (ctx) => {
      const baseTime = Date.now();
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: "Olá! Qual o seu nome completo?",
        sentAt: baseTime,
        status: "sent",
        createdAt: baseTime,
      });
    });

    const r1 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "João Silva Santos",
      threadId: chatId,
      patientId: newPatientId,
    });

    // Check patient was updated
    const updatedPatient = await t.query(internal.patients.getByIdInternal, {
      id: newPatientId,
      clinicId: TEST_CLINIC_ID,
    });

    expect(updatedPatient?.name).toBe("João Silva Santos");
    console.log("✅ Patient name updated:", updatedPatient?.name);

    // Continue with DOB
    await t.run(async (ctx) => {
      const baseTime = Date.now();
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: r1.response,
        sentAt: baseTime,
        status: "sent",
        createdAt: baseTime,
      });
    });

    const r2 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "15051990",
      threadId: chatId,
      patientId: newPatientId,
    });

    // Check DOB was saved
    const updatedPatient2 = await t.query(internal.patients.getByIdInternal, {
      id: newPatientId,
      clinicId: TEST_CLINIC_ID,
    });

    expect(updatedPatient2?.dateOfBirth).toBeTruthy();
    const dobDate = new Date(updatedPatient2?.dateOfBirth || 0);
    expect(dobDate.getDate()).toBe(15);
    expect(dobDate.getMonth()).toBe(4); // May = 4
    expect(dobDate.getFullYear()).toBe(1990);
    console.log("✅ Patient DOB saved:", dobDate.toLocaleDateString("pt-BR"));

    // Continue with gender
    await t.run(async (ctx) => {
      const baseTime = Date.now();
      await ctx.db.insert("messages", {
        clinicId: TEST_CLINIC_ID,
        chatId,
        direction: "out",
        type: "text",
        body: r2.response,
        sentAt: baseTime,
        status: "sent",
        createdAt: baseTime,
      });
    });

    const r3 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId: TEST_CLINIC_ID,
      message: "Masculino",
      threadId: chatId,
      patientId: newPatientId,
    });

    // Check gender was saved
    const updatedPatient3 = await t.query(internal.patients.getByIdInternal, {
      id: newPatientId,
      clinicId: TEST_CLINIC_ID,
    });

    expect(updatedPatient3?.gender).toBe("male");
    console.log("✅ Patient gender saved:", updatedPatient3?.gender);
  });

  it("handles lowercase doctor name and continues flow after presencial selection", async () => {
    // This test specifically verifies the fix for lowercase doctor names like "Dr rafael"
    // The issue was that extractDoctorName regex required uppercase first letter
    // Increase timeout for AI operations
    const clinicId = `lowercase-doctor-test-${Date.now()}`;

    // Seed AI settings first
    await seedAiSettings(t, clinicId);

    // Create fixtures
    const fixtures = await createSchedulingFixtures(t, clinicId);

    const chatId = await t.run(async (ctx) => {
      return await ctx.db.insert("chats", {
        clinicId,
        whatsappChatId: `5511999999999-${Date.now()}-lowercase@c.us`,
        patientId: fixtures.patientId,
        unreadCount: 0,
        status: "open",
        isAiActive: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
    });

    // Setup conversation context
    let baseTime = Date.now();
    await t.run(async (ctx) => {
      // Bot asks about doctor preference
      await ctx.db.insert("messages", {
        clinicId,
        chatId,
        direction: "out",
        type: "text",
        body: "Temos o Dr. Josefino em cardiologia. Tem preferência por ele ou pode ser qualquer um disponível?",
        sentAt: baseTime,
        status: "sent",
        createdAt: baseTime,
      });
    });

    // Patient chooses doctor with lowercase name (this was the bug)
    const r1 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId,
      message: "Dr rafael", // lowercase 'r' - this should still be recognized
      threadId: chatId,
      patientId: fixtures.patientId,
    });

    expect(r1.response).toBeTruthy();
    // Bot should acknowledge Dr. Rafael and ask about appointment type
    console.log("[Lowercase doctor name] Response:", r1.response.substring(0, 150));

    // Store user message and bot response for context
    baseTime += 1000;
    await t.run(async (ctx) => {
      await ctx.db.insert("messages", {
        clinicId,
        chatId,
        direction: "in",
        type: "text",
        body: "Dr rafael",
        sentAt: baseTime - 500,
        status: "sent",
        createdAt: baseTime - 500,
      });
      await ctx.db.insert("messages", {
        clinicId,
        chatId,
        direction: "out",
        type: "text",
        body: r1.response,
        sentAt: baseTime,
        status: "sent",
        createdAt: baseTime,
      });
    });

    expect(r1.response).toBeTruthy();
    // Bot should acknowledge Dr. Rafael and ask about appointment type
    console.log("[Lowercase doctor name] Response:", r1.response.substring(0, 150));

    // Store bot response
    baseTime += 1000;
    await t.run(async (ctx) => {
      await ctx.db.insert("messages", {
        clinicId,
        chatId,
        direction: "out",
        type: "text",
        body: r1.response,
        sentAt: baseTime,
        status: "sent",
        createdAt: baseTime,
      });
    });

    // Patient selects presencial - this is where the original bug caused the bot to stop responding
    const r2 = await t.action(internal.automationAi.generateAiResponse, {
      clinicId,
      message: "Presencial",
      threadId: chatId,
      patientId: fixtures.patientId,
    });

    expect(r2.response).toBeTruthy();
    // The bot should NOT stop - it should continue and either:
    // 1. Ask for a date if it needs one
    // 2. Show available days/hours if it has all the info
    console.log("[Presencial selected] Response:", r2.response.substring(0, 150));

    // The response should indicate the bot is continuing the flow
    // It should NOT be empty or a generic "thanks" message
    const isGenericResponse = /obrigado pela sua mensagem|nossa equipe responderá|aguarde/i.test(
      r2.response,
    );
    expect(isGenericResponse).toBe(false);
  }, 60000);
});
