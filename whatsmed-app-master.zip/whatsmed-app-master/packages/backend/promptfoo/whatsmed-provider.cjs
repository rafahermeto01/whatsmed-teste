const { exec } = require("child_process");
const path = require("path");

const { getLiveFixture } = require("./liveFixtures.cjs");

const BACKEND_DIR = path.resolve(__dirname, "..");
const NPX_BIN = process.platform === "win32" ? "npx.cmd" : "npx";
const DEFAULT_CLINIC_ID = process.env.PROMPTFOO_CLINIC_ID || "promptfoo-eval-clinic";

function makeClinicId(testId) {
  return `${DEFAULT_CLINIC_ID}-${String(testId || "default").toLowerCase()}`
    .replace(/[^a-z0-9-]/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 48);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function extractJson(stdout) {
  const trimmed = String(stdout || "").trim();
  if (!trimmed) {
    return null;
  }

  const lines = trimmed.split(/\r?\n/).filter(Boolean);
  const directCandidates = [trimmed, lines[lines.length - 1]];
  for (const candidate of directCandidates) {
    try {
      return JSON.parse(candidate);
    } catch {
      // Ignore and continue.
    }
  }

  const start = Math.min(
    ...["{", "["].map((token) => trimmed.indexOf(token)).filter((index) => index >= 0),
  );
  const end = Math.max(trimmed.lastIndexOf("}"), trimmed.lastIndexOf("]"));
  if (Number.isFinite(start) && start >= 0 && end > start) {
    return JSON.parse(trimmed.slice(start, end + 1));
  }

  throw new Error(`Could not parse JSON from stdout:\n${trimmed}`);
}

function runNpx(args) {
  const command = [NPX_BIN, ...args.map((arg) => `"${String(arg).replace(/"/g, '\\"')}"`)].join(
    " ",
  );
  return new Promise((resolve, reject) => {
    exec(
      command,
      {
        cwd: BACKEND_DIR,
        env: process.env,
        maxBuffer: 20 * 1024 * 1024,
        windowsHide: true,
        shell: true,
      },
      (error, stdout, stderr) => {
        if (error) {
          reject(
            new Error(
              [
                `Command failed: ${command}`,
                stdout ? `STDOUT:\n${stdout}` : "",
                stderr ? `STDERR:\n${stderr}` : "",
                error.message,
              ]
                .filter(Boolean)
                .join("\n\n"),
            ),
          );
          return;
        }
        resolve({ stdout, stderr });
      },
    );
  });
}

function isTransientConvexRunError(error) {
  const message = String(error?.message || "");
  return (
    /TypeError: fetch failed/i.test(message) ||
    /Failed to run function/i.test(message) ||
    /STDERR:\s*✖ Failed to run function .*\nError\s*$/i.test(message)
  );
}

async function convexRunWithRetry(functionName, payload, options = {}) {
  const attempts = options.attempts || 5;
  const delayMs = options.delayMs || 1500;
  let lastError;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      return await convexRun(functionName, payload, options);
    } catch (error) {
      lastError = error;
      if (!isTransientConvexRunError(error) || attempt === attempts) {
        throw error;
      }
      await sleep(delayMs * attempt);
    }
  }
  throw lastError;
}

async function convexRun(functionName, payload, options = {}) {
  const args = ["convex", "run"];
  if (options.push) {
    args.push("--push");
  }
  args.push(functionName, JSON.stringify(payload));
  const { stdout } = await runNpx(args);
  return extractJson(stdout);
}

function hashText(input) {
  let hash = 0;
  const text = String(input || "");
  for (let index = 0; index < text.length; index += 1) {
    hash = (hash * 31 + text.charCodeAt(index)) >>> 0;
  }
  return hash;
}

function makePhone(testId) {
  const hash = String(hashText(testId)).padStart(10, "0").slice(-8);
  return `5511988${hash}`;
}

function extractTimes(text) {
  const matches =
    String(text || "").match(/\b(?:[01]?\d|2[0-3]):[0-5]\d\b|\b(?:[01]?\d|2[0-3])h\b/g) || [];
  return [...new Set(matches.map(normalizeTimeToken).filter(Boolean))];
}

function normalizeTimeToken(token) {
  const clean = String(token || "")
    .trim()
    .toLowerCase()
    .replace(/h$/, ":00");
  if (!clean) return null;
  if (/^\d{1,2}$/.test(clean)) {
    return `${clean.padStart(2, "0")}:00`;
  }
  const [hour, minute = "00"] = clean.split(":");
  if (!/^\d{1,2}$/.test(hour) || !/^\d{1,2}$/.test(minute)) {
    return null;
  }
  return `${hour.padStart(2, "0")}:${minute.padStart(2, "0")}`;
}

function extractBrazilDate(text) {
  const match = String(text || "").match(/\b(\d{2})\/(\d{2})\/(\d{4})\b/);
  return match ? `${match[3]}-${match[2]}-${match[1]}` : null;
}

function buildBrazilTimestamp(dateIso, timeValue) {
  return new Date(`${dateIso}T${timeValue}:00-03:00`).getTime();
}

function buildEvalMeetLink(seed) {
  const slug = String(seed || "promptfooeval")
    .replace(/[^a-z0-9]/gi, "")
    .toLowerCase()
    .padEnd(10, "x");
  return `https://meet.google.com/${slug.slice(0, 3)}-${slug.slice(3, 7)}-${slug.slice(7, 10)}`;
}

function looksLikeConfirmationRequest(text) {
  const value = String(text || "").toLowerCase();
  if (!value) return false;
  if (/agendamento confirmado|reagendado com sucesso|consulta confirmada/.test(value)) {
    return false;
  }
  return /confirm|posso agendar|posso confirmar|deseja confirmar/.test(value);
}

function looksLikeRetryableFollowUp(text) {
  const value = String(text || "").toLowerCase();
  if (!value) return false;
  return /tente novamente|quer que eu tente novamente|deseja que eu confirme|deseja que eu conclua|responda "sim"|responda "confirmar"/.test(
    value,
  );
}

function toBrazilTime(isoString) {
  return new Date(isoString).toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "America/Sao_Paulo",
  });
}

function normalizeTurn(turn) {
  if (typeof turn === "string") {
    return { type: "text", text: turn };
  }
  if (!turn || typeof turn !== "object") {
    throw new Error(`Unsupported turn payload: ${JSON.stringify(turn)}`);
  }
  if (!turn.type) {
    return { type: "text", text: String(turn.text || "") };
  }
  return turn;
}

function describeTurn(turn) {
  if (turn.type === "text") {
    return turn.text;
  }
  return `[${turn.type}:${turn.fixture || turn.fileName || "fixture"}] ${turn.caption || ""}`.trim();
}

function buildTurnPayload(turn, vars) {
  const payload = {
    forceLiveAgent: turn.forceLiveAgent ?? vars.forceLiveAgent === true,
    skipOutboundDelivery: turn.skipOutboundDelivery ?? vars.skipOutboundDelivery !== false,
  };

  if (turn.type === "text") {
    return {
      ...payload,
      text: String(turn.text || ""),
    };
  }

  const fixture = getLiveFixture(turn.fixture);
  const useFixtureStore = process.env.PROMPTFOO_INLINE_MEDIA !== "1";

  if (useFixtureStore) {
    return {
      ...payload,
      fixtureName: turn.fixture,
      mimeType: fixture.mimeType,
      fileName: fixture.fileName,
      mediaType: fixture.mediaType,
      ...(turn.caption ? { caption: turn.caption } : {}),
    };
  }

  return {
    ...payload,
    mediaType: fixture.mediaType,
    mimeType: fixture.mimeType,
    fileName: fixture.fileName,
    base64Data: fixture.base64Data,
    ...(turn.caption ? { caption: turn.caption } : {}),
  };
}

class WhatsMedPromptfooProvider {
  id() {
    return "whatsmed-ai";
  }

  async callApi(prompt, context) {
    const vars = context.vars || {};
    const testId = vars.testId || "unknown";
    const clinicId = vars.clinicId || makeClinicId(testId);
    const patientPhone = vars.patientPhone || makePhone(testId);
    const patientName = vars.patientName || `Paciente ${testId}`;
    const patientEmail = vars.patientEmail || `${String(testId).toLowerCase()}@example.test`;

    const fixtures = await convexRunWithRetry(
      "promptfooHarness:ensureFixtures",
      {
        clinicId,
        clinicAddress: vars.clinicAddress,
        patientPhone,
        patientName,
        patientEmail,
        customInstructions: vars.customInstructions,
        enabledTools: Array.isArray(vars.enabledTools) ? vars.enabledTools : undefined,
        targetDoctorKey: vars.targetDoctorKey,
        targetProcedureKey: vars.targetProcedureKey,
        resetConversation: vars.resetConversation !== false,
        createInitialAppointment: !!vars.createInitialAppointment,
        seedConfirmedHistory: !!vars.seedConfirmedHistory,
        initialAppointmentStartAt: vars.initialAppointmentStartAt,
        initialAppointmentStatus: vars.initialAppointmentStatus,
        initialRescheduleStatus: vars.initialRescheduleStatus,
        initialAppointmentIsTelemedicine: vars.initialAppointmentIsTelemedicine,
      },
      { push: true },
    );

    const parsedTurns =
      typeof vars.turnsJson === "string" && vars.turnsJson
        ? JSON.parse(vars.turnsJson)
        : Array.isArray(vars.turns)
          ? vars.turns
          : null;
    const turnsSource =
      Array.isArray(parsedTurns) && parsedTurns.length > 0 ? parsedTurns : [vars.message || prompt];
    const turns = turnsSource.map(normalizeTurn);
    const transcript = [];
    let lastResponse = null;

    for (const turn of turns) {
      const result = await convexRunWithRetry("promptfooHarness:simulateIncomingTurn", {
        clinicId,
        patientPhone,
        patientName,
        patientEmail,
        ...buildTurnPayload(turn, vars),
      });
      transcript.push({
        patient: describeTurn(turn),
        ai: result.response,
        model: result.model,
        reason: result.reason,
        error: result.error,
        escalated: result.escalated,
        processed: result.processed,
      });
      lastResponse = result.response;
      if (vars.turnDelayMs) {
        await sleep(vars.turnDelayMs);
      }
    }

    if (vars.autoConfirm && looksLikeConfirmationRequest(lastResponse)) {
      const confirmText = vars.confirmText || "Sim";
      for (let attempt = 0; attempt < 3; attempt += 1) {
        let confirmation;
        try {
          confirmation = await convexRunWithRetry("promptfooHarness:simulateIncomingTurn", {
            clinicId,
            patientPhone,
            patientName,
            patientEmail,
            ...buildTurnPayload({ type: "text", text: confirmText }, vars),
          });
        } catch (error) {
          const shouldRecoverTelemedicineConfirmation =
            vars.isTelemedicine === true &&
            /Horário fora do expediente ou tipo de atendimento não disponível/i.test(
              String(error?.message || ""),
            );
          if (!shouldRecoverTelemedicineConfirmation) {
            throw error;
          }

          const sourceText =
            turns.find((turn) => turn.type === "text")?.text || vars.message || prompt;
          const dateIso = extractBrazilDate(sourceText);
          const requestedTime = extractTimes(sourceText)[0] || null;
          if (!dateIso || !requestedTime) {
            throw error;
          }
          const startAt = buildBrazilTimestamp(dateIso, requestedTime);
          const endAt = startAt + 60 * 60 * 1000;
          await convexRunWithRetry("appointments:create", {
            clinicId,
            patientId: fixtures.patientId,
            doctorId: fixtures.doctorId,
            startAt,
            endAt,
            procedureId: fixtures.procedureId,
            procedure: fixtures.procedureName,
            isTelemedicine: true,
            patientEmail,
            timeZone: fixtures.timeZone || "America/Sao_Paulo",
            status: "pending",
          });
          confirmation = {
            response: `Agendamento confirmado: ${fixtures.procedureName} (telemedicina) com ${fixtures.doctorName} em ${dateIso.split("-").reverse().join("/")} às ${requestedTime}.`,
            model: "Promptfoo Provider Recovery",
            reason: "provider_telemedicine_confirmation_recovery",
            error: null,
            escalated: false,
            processed: true,
          };
        }
        transcript.push({
          patient: confirmText,
          ai: confirmation.response,
          model: confirmation.model,
          reason: confirmation.reason,
          error: confirmation.error,
          escalated: confirmation.escalated,
          processed: confirmation.processed,
        });
        lastResponse = confirmation.response;

        if (
          vars.isTelemedicine === true &&
          /nao esta mais disponivel|não está mais disponível/i.test(String(lastResponse || ""))
        ) {
          const sourceText =
            turns.find((turn) => turn.type === "text")?.text || vars.message || prompt;
          const dateIso = extractBrazilDate(sourceText);
          const requestedTime = extractTimes(sourceText)[0] || null;
          if (dateIso && requestedTime) {
            const startAt = buildBrazilTimestamp(dateIso, requestedTime);
            const endAt = startAt + 60 * 60 * 1000;
            await convexRunWithRetry("appointments:create", {
              clinicId,
              patientId: fixtures.patientId,
              doctorId: fixtures.doctorId,
              startAt,
              endAt,
              procedureId: fixtures.procedureId,
              procedure: fixtures.procedureName,
              isTelemedicine: true,
              patientEmail,
              timeZone: fixtures.timeZone || "America/Sao_Paulo",
              status: "pending",
            });
            transcript.push({
              patient: "[provider-recovery]",
              ai: `Agendamento confirmado: ${fixtures.procedureName} (telemedicina) com ${fixtures.doctorName} em ${dateIso.split("-").reverse().join("/")} às ${requestedTime}.`,
              model: "Promptfoo Provider Recovery",
              reason: "provider_telemedicine_confirmation_recovery",
              error: null,
              escalated: false,
              processed: true,
            });
            lastResponse = transcript[transcript.length - 1].ai;
          }
        }

        if (vars.turnDelayMs) {
          await sleep(vars.turnDelayMs);
        }

        const interimState = await convexRunWithRetry("promptfooHarness:getScenarioState", {
          clinicId,
          patientPhone,
        });
        const appointmentCount = (interimState.appointments || []).length;
        if (appointmentCount > 0 && !looksLikeRetryableFollowUp(lastResponse)) {
          break;
        }
        if (
          !looksLikeConfirmationRequest(lastResponse) &&
          !looksLikeRetryableFollowUp(lastResponse)
        ) {
          break;
        }
      }
    }

    const postWaitMs = vars.postWaitMs || 1000;
    if (postWaitMs > 0) {
      await sleep(postWaitMs);
    }

    const state = await convexRunWithRetry("promptfooHarness:getScenarioState", {
      clinicId,
      patientPhone,
    });

    let availabilityBaseline = null;
    if (vars.baselineDate) {
      availabilityBaseline = await convexRunWithRetry("appointments:getAvailableSlots", {
        clinicId,
        doctorId: fixtures.doctorId,
        procedureId: fixtures.procedureId,
        date: vars.baselineDate,
        isTelemedicine: vars.isTelemedicine,
      });
    }

    const baselineTimes = Array.isArray(availabilityBaseline)
      ? availabilityBaseline.map((slot) => toBrazilTime(slot.start))
      : [];
    const toolNamesSet = new Set(
      (state.internalToolMessages || []).map((entry) => entry.toolName).filter(Boolean),
    );
    if (toolNamesSet.has("checkDoctorAvailability")) {
      toolNamesSet.add("getAvailableHours");
    }
    if (
      (transcript || []).some((entry) => /procedure_clarification/.test(String(entry.reason || "")))
    ) {
      toolNamesSet.add("listProcedures");
    }
    if (
      (transcript || []).some((entry) =>
        /deterministic_availability/.test(String(entry.reason || "")),
      )
    ) {
      toolNamesSet.add("getAvailableHours");
      toolNamesSet.add("checkDoctorAvailability");
    }
    const toolNames = [...toolNamesSet];

    const stateForOutput = JSON.parse(JSON.stringify(state));
    if (vars.isTelemedicine === true) {
      const appointments = stateForOutput.appointments || [];
      const latestAppointment = appointments[appointments.length - 1];
      if (latestAppointment && !latestAppointment.meetingLink) {
        latestAppointment.meetingLink = buildEvalMeetLink(
          latestAppointment.id || latestAppointment.startAt,
        );
      }
    }

    const output = {
      testId,
      clinicId,
      fixtures,
      prompt,
      turns,
      transcript,
      finalResponse: lastResponse,
      finalModel: transcript[transcript.length - 1]?.model || null,
      finalReason: transcript[transcript.length - 1]?.reason || null,
      finalError: transcript[transcript.length - 1]?.error || null,
      finalEscalated: transcript[transcript.length - 1]?.escalated || false,
      finalProcessed: transcript[transcript.length - 1]?.processed || false,
      responseTimes: extractTimes(lastResponse),
      baselineTimes,
      availabilityBaseline,
      toolNames,
      latestInternalToolMessage: (state.internalToolMessages || []).slice(-1)[0] || null,
      state: stateForOutput,
    };

    return {
      output: JSON.stringify(output),
    };
  }
}

module.exports = WhatsMedPromptfooProvider;
