function nextWeekday(targetDay) {
  const today = new Date();
  const result = new Date(today);
  result.setHours(0, 0, 0, 0);
  const currentDay = result.getDay();
  let delta = (targetDay - currentDay + 7) % 7;
  if (delta === 0) {
    delta = 7;
  }
  result.setDate(result.getDate() + delta);
  return result;
}

function brDate(date) {
  return date.toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" });
}

function isoDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function brazilTimestamp(date, hour, minute) {
  return new Date(
    `${isoDate(date)}T${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}:00-03:00`,
  ).getTime();
}

function parseOutput(output) {
  return typeof output === "string" ? JSON.parse(output) : output;
}

function ok(pass, reason) {
  return {
    pass,
    score: pass ? 1 : 0,
    reason,
  };
}

function normalizeText(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function responseText(output) {
  return String(parseOutput(output).finalResponse || "");
}

function latestAppointment(output) {
  const appointments = parseOutput(output).state?.appointments || [];
  return appointments[appointments.length - 1] || null;
}

function latestIncoming(output) {
  const incoming = parseOutput(output).state?.incomingMessages || [];
  return incoming[incoming.length - 1] || null;
}

function assertContainsAny(terms) {
  return (output) => {
    const text = normalizeText(responseText(output));
    const matched = terms.find((term) => text.includes(normalizeText(term)));
    return ok(!!matched, matched ? `Matched ${matched}` : `Missing any of: ${terms.join(", ")}`);
  };
}

function assertAppointmentCount(expectedCount) {
  return (output) => {
    const appointments = parseOutput(output).state?.appointments || [];
    return ok(
      appointments.length === expectedCount,
      appointments.length === expectedCount
        ? `Found ${expectedCount} appointment(s)`
        : `Expected ${expectedCount}, got ${appointments.length}`,
    );
  };
}

function assertLatestAppointmentTimestamp(expectedTimestamp) {
  return (output) => {
    const appointment = latestAppointment(output);
    const pass = !!appointment && appointment.startAt === expectedTimestamp;
    return ok(
      pass,
      pass
        ? `Appointment starts at ${expectedTimestamp}`
        : `Unexpected startAt ${appointment?.startAt}`,
    );
  };
}

function assertFinalReasonIn(expectedReasons) {
  return (output) => {
    const transcript = parseOutput(output).transcript || [];
    const reason = transcript[transcript.length - 1]?.reason || null;
    const pass = expectedReasons.includes(reason);
    return ok(
      pass,
      pass
        ? `Final reason ${reason}`
        : `Expected one of ${expectedReasons.join(", ")}, got ${reason}`,
    );
  };
}

function assertToolUsed(toolName) {
  return (output) => {
    const toolNames = parseOutput(output).toolNames || [];
    return ok(
      toolNames.includes(toolName),
      toolNames.includes(toolName)
        ? `Tool used: ${toolName}`
        : `Missing tool ${toolName}; saw ${toolNames.join(", ") || "none"}`,
    );
  };
}

function assertToolNotUsed(toolName) {
  return (output) => {
    const toolNames = parseOutput(output).toolNames || [];
    return ok(
      !toolNames.includes(toolName),
      !toolNames.includes(toolName) ? `Tool not used: ${toolName}` : `Unexpected tool ${toolName}`,
    );
  };
}

function assertPatientDocumentSaved(documentKey) {
  return (output) => {
    const documents = parseOutput(output).state?.patient?.documents || {};
    return ok(
      documents[documentKey] === true,
      documents[documentKey] === true
        ? `Patient document saved: ${documentKey}`
        : `Patient document missing: ${documentKey}`,
    );
  };
}

function assertTranscriptionCompleted(output) {
  const incoming = latestIncoming(output);
  const pass =
    incoming?.transcriptionStatus === "completed" && typeof incoming?.transcribedText === "string";
  return ok(
    pass && incoming.transcribedText.trim().length > 0,
    pass
      ? `Transcription present: ${incoming.transcribedText.slice(0, 60)}`
      : `Missing transcription, status=${incoming?.transcriptionStatus || "none"}`,
  );
}

function assertNoInternalIdentifiers(output) {
  const data = parseOutput(output);
  const texts = [data.finalResponse || ""]
    .concat((data.state?.outgoingMessages || []).map((message) => message.body || ""))
    .join("\n");
  const pass =
    !/(doctorId|procedureId|patientId|appointmentId|mediaStorageId|_id)/i.test(texts) &&
    !/[A-Za-z0-9]{24,}/.test(texts);
  return ok(pass, pass ? "No leaked internal identifiers" : `Leaked identifier in ${texts}`);
}

function asAsserts(...assertions) {
  return assertions.map((assertion) => ({ type: "javascript", value: assertion }));
}

const monday = nextWeekday(1);
const mondayDate = brDate(monday);
const monday15 = brazilTimestamp(monday, 15, 0);

/** @type {import('promptfoo').TestSuiteConfig} */
module.exports = {
  description: "WhatsMed live multimodal AI evals",
  prompts: ["{{message}}"],
  providers: ["./whatsmed-provider.cjs"],
  tests: [
    {
      description: "LIVE-01 Text booking uses real tool chain",
      vars: {
        testId: "LIVE-01",
        forceLiveAgent: true,
        message: `Quero agendar uma Consulta Promptfoo presencial com o Dr Promptfoo Avaliacao em ${mondayDate} as 15h.`,
        autoConfirm: true,
        confirmText: "Confirmar",
        postWaitMs: 1500,
      },
      assert: asAsserts(
        assertAppointmentCount(1),
        assertLatestAppointmentTimestamp(monday15),
        assertContainsAny(["agendamento confirmado", "deseja que eu confirme", "15:00"]),
        assertFinalReasonIn([
          "deterministic_create_confirmation",
          "deterministic_availability_exact",
        ]),
        assertNoInternalIdentifiers,
      ),
    },
    {
      description: "LIVE-02 Insurance card image is persisted",
      vars: {
        testId: "LIVE-02",
        forceLiveAgent: true,
        turns: [
          {
            type: "image",
            fixture: "insurance_card_front",
            caption: "Segue minha carteirinha do convenio.",
          },
        ],
        postWaitMs: 1500,
      },
      assert: asAsserts(
        assertToolUsed("savePatientImage"),
        assertPatientDocumentSaved("insuranceCardFront"),
        assertContainsAny(["carteirinha", "convenio", "salv", "receb"]),
        assertNoInternalIdentifiers,
      ),
    },
    {
      description: "LIVE-03 ID card image is persisted",
      vars: {
        testId: "LIVE-03",
        forceLiveAgent: true,
        turns: [
          {
            type: "image",
            fixture: "id_card",
            caption: "Segue meu documento.",
          },
        ],
        postWaitMs: 1500,
      },
      assert: asAsserts(
        assertToolUsed("savePatientImage"),
        assertPatientDocumentSaved("idCard"),
        assertContainsAny(["documento", "salv", "receb"]),
        assertNoInternalIdentifiers,
      ),
    },
    {
      description: "LIVE-04 Referral PDF is persisted",
      vars: {
        testId: "LIVE-04",
        forceLiveAgent: true,
        turns: [
          {
            type: "document",
            fixture: "referral_pdf",
            caption: "Segue meu encaminhamento medico.",
          },
        ],
        postWaitMs: 1500,
      },
      assert: asAsserts(
        assertToolUsed("savePatientImage"),
        assertPatientDocumentSaved("referral"),
        assertContainsAny(["encaminhamento", "salv", "receb"]),
        assertNoInternalIdentifiers,
      ),
    },
    {
      description: "LIVE-05 Audio note is transcribed and handled",
      vars: {
        testId: "LIVE-05",
        forceLiveAgent: true,
        turns: [
          {
            type: "audio",
            fixture: "audio_booking",
          },
        ],
        postWaitMs: 1500,
      },
      assert: asAsserts(
        assertTranscriptionCompleted,
        assertContainsAny(["medico", "especialidades", "agendamento", "consulta"]),
        assertNoInternalIdentifiers,
      ),
    },
  ],
};
