import { v } from "convex/values";

import { internal } from "./_generated/api";
import { query, internalQuery, mutation, internalMutation } from "./_generated/server";
import { authComponent } from "./auth";
import { getBrazilianPhoneVariations } from "./lib/phoneUtils";

const internalAny = internal as any;

// Helper to get authenticated user and clinicId
async function getAuth(ctx: any) {
  const user = await authComponent.getAuthUser(ctx);
  if (!user) {
    throw new Error("Unauthorized");
  }

  // Try to find app user to get reliable clinicId
  const appUser = await ctx.db
    .query("users")
    .withIndex("by_email", (q: any) => q.eq("email", user.email))
    .first();

  const clinicId = appUser?.clinicId || (user as any).clinicId;

  return { user, appUser, clinicId: clinicId as string };
}

async function getClinicSettings(ctx: any, clinicId: string) {
  const clinic = await ctx.db
    .query("clinics")
    .withIndex("by_clinicId", (q: any) => q.eq("clinicId", clinicId))
    .first();

  if (!clinic) {
    return null;
  }

  return await ctx.db
    .query("clinicSettings")
    .withIndex("by_clinic", (q: any) => q.eq("clinicId", clinic._id))
    .first();
}

/**
 * List chats for the current user's clinic
 */
export const listChats = query({
  args: {
    search: v.optional(v.string()),
    tags: v.optional(v.array(v.string())),
    status: v.optional(v.union(v.literal("open"), v.literal("resolved"))),
    aiMode: v.optional(v.union(v.literal("active"), v.literal("inactive"), v.literal("all"))),
    needsReview: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    let chats = await ctx.db
      .query("chats")
      .withIndex("by_clinic_lastMessageAt", (q) => q.eq("clinicId", clinicId))
      .order("desc")
      .collect();

    // Apply search filter
    if (args.search) {
      const searchLower = args.search.toLowerCase();
      chats = chats.filter((chat) => {
        const titleMatch = chat.title?.toLowerCase().includes(searchLower);
        const phoneMatch = chat.whatsappChatId.includes(searchLower);
        return titleMatch || phoneMatch;
      });
    }

    // Apply status filter
    if (args.status) {
      chats = chats.filter((chat) => chat.status === args.status);
    }

    // Apply tags filter
    if (args.tags && args.tags.length > 0) {
      chats = chats.filter((chat) => {
        const chatTags = chat.tags || [];
        return args.tags!.some((tag) => chatTags.includes(tag));
      });
    }

    // Apply AI mode filter
    if (args.aiMode && args.aiMode !== "all") {
      chats = chats.filter((chat) => {
        const isAiActive = chat.isAiActive !== false; // Default to true
        return args.aiMode === "active" ? isAiActive : !isAiActive;
      });
    }

    // Apply needs review filter
    if (args.needsReview === true) {
      chats = chats.filter((chat) => chat.needsHumanReview === true);
    }

    return chats;
  },
});

/**
 * Get messages for a specific chat
 */
export const getChatMessages = query({
  args: {
    chatId: v.id("chats"),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);
    const limit = args.limit || 50;

    const messages = await ctx.db
      .query("messages")
      .withIndex("by_clinic_chat_sent", (q) => q.eq("clinicId", clinicId).eq("chatId", args.chatId))
      .filter((q) => q.eq(q.field("isInternal"), undefined))
      .order("desc")
      .take(limit);

    return messages.reverse(); // Return in chronological order
  },
});

/**
 * Internal: Get messages for a specific chat (no auth check)
 * Used by AI automation
 */
export const getChatMessagesInternal = internalQuery({
  args: {
    clinicId: v.string(),
    chatId: v.id("chats"),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = args.limit || 10;

    const messages = await ctx.db
      .query("messages")
      .withIndex("by_clinic_chat_sent", (q) =>
        q.eq("clinicId", args.clinicId).eq("chatId", args.chatId),
      )
      .filter((q) => q.eq(q.field("isInternal"), undefined))
      .order("desc")
      .take(limit);

    return messages.reverse();
  },
});

/**
 * Get the last inserted message ID from a chat
 * Used to schedule classification after message is stored
 */
export const getLastMessageId = query({
  args: {
    chatId: v.id("chats"),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    const chat = await ctx.db.get(args.chatId);
    if (!chat) return undefined;
    if (chat.clinicId !== clinicId) {
      throw new Error("Chat not found");
    }

    const message = await ctx.db
      .query("messages")
      .withIndex("by_clinic_chat_sent", (q) =>
        q.eq("clinicId", chat.clinicId).eq("chatId", args.chatId),
      )
      .filter((q) => q.eq(q.field("isInternal"), undefined))
      .order("desc")
      .first();

    return message ? message._id : undefined;
  },
});

/**
 * Internal: Get recent messages with images from a chat
 * Used by AI to find images when patient sends text after images
 */
export const getRecentImagesInternal = internalQuery({
  args: {
    chatId: v.id("chats"),
    clinicId: v.string(),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = args.limit || 10;
    const messages = await ctx.db
      .query("messages")
      .withIndex("by_clinic_chat_sent", (q) =>
        q.eq("clinicId", args.clinicId).eq("chatId", args.chatId),
      )
      .order("desc")
      .take(limit);

    // Filter for incoming image/document-like media only
    const imageMessages = messages.filter(
      (m) =>
        m.direction === "in" &&
        m.mediaStorageId &&
        (m.mediaType === "image" ||
          m.mediaType === "document" ||
          (!!m.mediaMimetype &&
            (m.mediaMimetype.startsWith("image/") || m.mediaMimetype === "application/pdf"))),
    );

    return imageMessages.map((m) => ({
      messageId: m._id,
      mediaStorageId: m.mediaStorageId,
      mediaType: m.mediaType,
      mediaMimetype: m.mediaMimetype,
      extractedData: m.extractedData,
      text: m.body,
      createdAt: m.createdAt,
    }));
  },
});

/**
 * Internal: Get chat by ID
 */
export const getChatInternal = internalQuery({
  args: { chatId: v.id("chats") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.chatId);
  },
});

/**
 * Send a message (Mutation)
 * Stores message in DB and triggers sending via Evolution API
 */
export const sendMessage = mutation({
  args: {
    chatId: v.id("chats"),
    text: v.string(),
  },
  handler: async (ctx, args) => {
    const { clinicId, appUser, user } = await getAuth(ctx);

    const chat = await ctx.db.get(args.chatId);
    if (!chat || chat.clinicId !== clinicId) {
      throw new Error("Chat not found");
    }

    const senderDisplayName = appUser?.name || user.name || user.email;
    const clinicSettings = await getClinicSettings(ctx, clinicId);
    const shouldPrependSenderName =
      clinicSettings?.prependAttendantNameOnManualMessages === true && !!senderDisplayName;
    const messageBody = shouldPrependSenderName
      ? `*${senderDisplayName}*\n${args.text}`
      : args.text;

    const messageId = await ctx.db.insert("messages", {
      clinicId,
      chatId: args.chatId,
      direction: "out",
      type: "text",
      body: messageBody,
      status: "sending",
      sentAt: Date.now(),
      createdAt: Date.now(),
      authorUserId: appUser?._id,
    });

    // Update chat last message and disable AI mode (human intervention)
    await ctx.db.patch(args.chatId, {
      lastMessage: messageBody,
      lastMessageAt: Date.now(),
      lastActivityAt: Date.now(), // Track last activity for timeout monitoring
      updatedAt: Date.now(),
      isAiActive: false,
      needsHumanReview: false, // Clear escalation flag when human responds
      responsibleUserId: appUser?._id,
      responsibleUserName: senderDisplayName,
    });

    // Schedule sending via Provider
    await ctx.scheduler.runAfter(0, internalAny.whatsapp.sendTextAction, {
      chatId: args.chatId,
      text: messageBody,
      messageId: messageId,
    });

    return messageId;
  },
});

/**
 * Toggle AI mode for a chat
 */
export const toggleAiMode = mutation({
  args: {
    chatId: v.id("chats"),
    isAiActive: v.boolean(),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    const chat = await ctx.db.get(args.chatId);
    if (!chat || chat.clinicId !== clinicId) {
      throw new Error("Chat not found");
    }

    const updates: any = {
      isAiActive: args.isAiActive,
      updatedAt: Date.now(),
    };

    if (args.isAiActive) {
      updates.needsHumanReview = false;
      if (chat.status === "open") {
        updates.lockedReason = undefined;
      }
    }

    await ctx.db.patch(args.chatId, updates);
  },
});

/**
 * Alias for automation usage (Mutation)
 * Automation calls this internal mutation to send messages
 */
export const sendMessageAction = internalMutation({
  args: {
    chatId: v.id("chats"),
    text: v.string(),
    tracking: v.optional(
      v.object({
        clinicId: v.string(),
        appointmentId: v.id("appointments"),
        markLegacyReminderAt: v.optional(v.boolean()),
        reminderType: v.optional(
          v.union(
            v.literal("appointmentConfirmation"),
            v.literal("sevenDay"),
            v.literal("twentyFourHour"),
            v.literal("oneHour"),
            v.literal("postConsultation"),
            v.literal("noShowRecovery"),
          ),
        ),
        automationKind: v.optional(
          v.union(
            v.literal("confirmationRequest"),
            v.literal("appointmentReminder"),
            v.literal("rescheduleOptions"),
            v.literal("rescheduleConfirmation"),
            v.literal("confirmationReply"),
            v.literal("cancellationConfirmation"),
          ),
        ),
      }),
    ),
  },
  handler: async (ctx, args) => {
    const chat = await ctx.db.get(args.chatId);
    if (!chat) throw new Error("Chat not found");

    const messageId = await ctx.db.insert("messages", {
      clinicId: chat.clinicId,
      chatId: args.chatId,
      direction: "out",
      type: "text",
      body: args.text,
      status: "sending",
      appointmentId: args.tracking?.appointmentId,
      reminderType: args.tracking?.reminderType,
      automationKind: args.tracking?.automationKind,
      sentAt: Date.now(),
      createdAt: Date.now(),
    });

    await ctx.db.patch(args.chatId, {
      lastMessage: args.text,
      lastMessageAt: Date.now(),
      lastActivityAt: Date.now(), // Track last activity for timeout monitoring
      updatedAt: Date.now(),
    });

    await ctx.scheduler.runAfter(0, internalAny.whatsapp.sendTextAction, {
      chatId: args.chatId,
      text: args.text,
      messageId,
      tracking: args.tracking,
    });

    return messageId;
  },
});

/**
 * Store AI-generated message without disabling AI mode
 * Used by automationAi.ts
 */
export const storeAiMessage = internalMutation({
  args: {
    chatId: v.id("chats"),
    text: v.string(),
    replyToMessageId: v.optional(v.id("messages")),
  },
  handler: async (ctx, args) => {
    const chat = await ctx.db.get(args.chatId);
    if (!chat) throw new Error("Chat not found");

    const messageId = await ctx.db.insert("messages", {
      clinicId: chat.clinicId,
      chatId: args.chatId,
      direction: "out",
      type: "text",
      body: args.text,
      status: "sending",
      replyToId: args.replyToMessageId,
      sentAt: Date.now(),
      createdAt: Date.now(),
    });

    await ctx.db.patch(args.chatId, {
      lastMessage: args.text,
      lastMessageAt: Date.now(),
      lastActivityAt: Date.now(), // Track last activity for timeout monitoring
      updatedAt: Date.now(),
      // Do NOT disable AI mode
    });

    return messageId;
  },
});

export const storeAiToolMessages = internalMutation({
  args: {
    chatId: v.id("chats"),
    entries: v.array(
      v.object({
        body: v.string(),
        role: v.union(v.literal("assistant"), v.literal("tool"), v.literal("system")),
        toolName: v.optional(v.string()),
        toolCallId: v.optional(v.string()),
      }),
    ),
  },
  handler: async (ctx, args) => {
    const chat = await ctx.db.get(args.chatId);
    if (!chat || args.entries.length === 0) {
      return [];
    }

    const baseTimestamp = Date.now();
    const insertedIds = [];

    for (let index = 0; index < args.entries.length; index += 1) {
      const entry = args.entries[index];
      const messageId = await ctx.db.insert("messages", {
        clinicId: chat.clinicId,
        chatId: args.chatId,
        direction: "out",
        type: "text",
        isInternal: true,
        internalRole: entry.role,
        toolName: entry.toolName,
        toolCallId: entry.toolCallId,
        body: entry.body,
        status: "sent",
        sentAt: baseTimestamp + index,
        createdAt: baseTimestamp + index,
      });
      insertedIds.push(messageId);
    }

    return insertedIds;
  },
});

export const updateMessageStatusInternal = internalMutation({
  args: {
    messageId: v.id("messages"),
    status: v.union(
      v.literal("sending"),
      v.literal("sent"),
      v.literal("delivered"),
      v.literal("read"),
      v.literal("failed"),
    ),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.messageId, { status: args.status });
  },
});

/**
 * Internal: Mark chat as needing human review or clear the flag
 */
export const markNeedsHumanReview = internalMutation({
  args: {
    chatId: v.id("chats"),
    needsReview: v.boolean(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.chatId, {
      needsHumanReview: args.needsReview,
      updatedAt: Date.now(),
    });
  },
});

/**
 * Internal: Assign chat to human (escalation state without locking).
 * Sets isAiActive: false and needsHumanReview: true; does not change status.
 */
export const assignChatToHuman = internalMutation({
  args: {
    chatId: v.id("chats"),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.chatId, {
      isAiActive: false,
      needsHumanReview: true,
      updatedAt: Date.now(),
    });
  },
});

/**
 * Unraise chat: return to normal / AI mode (isAiActive: true, needsHumanReview: false).
 */
export const unraiseChat = mutation({
  args: {
    chatId: v.id("chats"),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    const chat = await ctx.db.get(args.chatId);
    if (!chat || chat.clinicId !== clinicId) {
      throw new Error("Chat not found");
    }

    await ctx.db.patch(args.chatId, {
      isAiActive: true,
      needsHumanReview: false,
      status: "open",
      lockedReason: undefined,
      updatedAt: Date.now(),
    });
  },
});

/**
 * Mark chat messages as read
 */
export const markAsRead = mutation({
  args: {
    chatId: v.id("chats"),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    const chat = await ctx.db.get(args.chatId);
    if (!chat || chat.clinicId !== clinicId) {
      throw new Error("Chat not found");
    }

    // Reset unread count
    await ctx.db.patch(args.chatId, {
      unreadCount: 0,
      updatedAt: Date.now(),
    });
  },
});

/**
 * Internal: Create chat
 */
export const createChatInternal = internalMutation({
  args: {
    clinicId: v.string(),
    patientId: v.optional(v.id("patients")),
    whatsappChatId: v.string(),
    title: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("chats", {
      clinicId: args.clinicId,
      patientId: args.patientId,
      whatsappChatId: args.whatsappChatId,
      title: args.title,
      unreadCount: 0,
      status: "open",
      isAiActive: true, // Default to AI active
      createdAt: Date.now(),
    });
  },
});

/**
 * Internal: Find chat by phone
 */
export const findChatByPhone = internalQuery({
  args: {
    clinicId: v.string(),
    phone: v.string(),
  },
  handler: async (ctx, args) => {
    const cleanedPhone = args.phone.replace(/\D/g, "");
    const phonesToTry = new Set<string>([cleanedPhone]);

    if (!cleanedPhone.startsWith("55")) {
      phonesToTry.add(`55${cleanedPhone}`);
    }

    for (const phone of phonesToTry) {
      for (const variation of getBrazilianPhoneVariations(phone)) {
        const chat = await ctx.db
          .query("chats")
          .withIndex("by_clinic_whatsappId", (q) =>
            q.eq("clinicId", args.clinicId).eq("whatsappChatId", `${variation}@s.whatsapp.net`),
          )
          .first();

        if (chat) {
          return chat;
        }
      }
    }

    return null;
  },
});

/**
 * Get media URL for a message
 */
export const getMediaUrl = query({
  args: {
    messageId: v.id("messages"),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    const message = await ctx.db.get(args.messageId);
    if (!message) return null;

    const chat = await ctx.db.get(message.chatId);
    if (!chat || chat.clinicId !== clinicId || message.clinicId !== clinicId) {
      throw new Error("Message not found");
    }

    // If we have a storage ID, return the signed URL
    if (message.mediaStorageId) {
      return await ctx.storage.getUrl(message.mediaStorageId);
    }

    // If it's a Meta/Evolution message without storageId, we might need to fetch it
    // But since this is a query, we can't fetch external APIs easily without an action.
    // For now, return null if not in storage.
    // The MediaMessage component handles null/loading states.

    return null;
  },
});

/**
 * Get or create a chat for a specific patient/phone
 */
export const getOrCreateChat = mutation({
  args: {
    patientId: v.optional(v.id("patients")),
    phone: v.string(),
    patientName: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    // Normalize phone
    // Remove non-digits
    let cleanPhone = args.phone.replace(/\D/g, "");

    // Format whatsappId
    // If it doesn't have country code (less than 12 digits), assume 55 (Brazil)
    if (cleanPhone.length < 12) {
      // 10 or 11 digits
      cleanPhone = "55" + cleanPhone;
    }
    const whatsappChatId = `${cleanPhone}@s.whatsapp.net`;

    // Check if chat exists
    const existingChat = await ctx.db
      .query("chats")
      .withIndex("by_clinic_whatsappId", (q) =>
        q.eq("clinicId", clinicId).eq("whatsappChatId", whatsappChatId),
      )
      .first();

    if (existingChat) {
      // If patientId is provided but chat doesn't have it, update it
      if (args.patientId && !existingChat.patientId) {
        await ctx.db.patch(existingChat._id, { patientId: args.patientId });
      }
      return existingChat._id;
    }

    // Create new chat
    const chatId = await ctx.db.insert("chats", {
      clinicId,
      whatsappChatId,
      patientId: args.patientId,
      title: args.patientName || cleanPhone,
      unreadCount: 0,
      status: "open",
      isAiActive: true, // Default to AI active
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });

    return chatId;
  },
});

/**
 * Search patients for sidebar (avoids frontend clinicId dependency issues)
 */
export const searchPatients = query({
  args: {
    search: v.string(),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);
    const limit = args.limit || 5;

    // Use the same search logic as patients.ts list
    const patients = await ctx.db
      .query("patients")
      .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", clinicId))
      .filter((q) =>
        q.neq(q.field("deletedAt"), undefined) ? q.eq(q.field("deletedAt"), undefined) : true,
      ) // Filter out deleted? Logic in patients.ts is simpler: if (row.deletedAt) return false;
      .collect();

    // In-memory filter (same as patients.ts)
    const term = args.search.toLowerCase();
    const filtered = patients.filter((row) => {
      if (row.deletedAt) return false;
      return (
        row.name?.toLowerCase().includes(term) ||
        (row.phone ?? "").includes(term) ||
        (row.email ?? "").toLowerCase().includes(term) ||
        (row.externalId ?? "").toLowerCase().includes(term) ||
        (row.cpf ?? "").includes(term)
      );
    });

    return filtered.slice(0, limit).map((p) => ({
      _id: p._id,
      name: p.name,
      phone: p.phone,
      avatarUrl: p.avatarUrl,
    }));
  },
});

/**
 * Update tags for a chat
 */
export const updateChatTags = mutation({
  args: {
    chatId: v.id("chats"),
    tags: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    const chat = await ctx.db.get(args.chatId);
    if (!chat || chat.clinicId !== clinicId) {
      throw new Error("Chat not found");
    }

    await ctx.db.patch(args.chatId, {
      tags: args.tags,
      updatedAt: Date.now(),
    });
  },
});

/**
 * Get all unique tags used across chats for the current clinic
 */
export const getUniqueChatTags = query({
  args: {},
  handler: async (ctx) => {
    const { clinicId } = await getAuth(ctx);

    const chats = await ctx.db
      .query("chats")
      .withIndex("by_clinic_lastMessageAt", (q) => q.eq("clinicId", clinicId))
      .collect();

    const tagSet = new Set<string>();
    chats.forEach((chat) => {
      if (chat.tags) {
        chat.tags.forEach((tag) => tagSet.add(tag));
      }
    });

    return Array.from(tagSet).sort();
  },
});
