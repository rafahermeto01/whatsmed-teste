import { v } from "convex/values";

import { MASTRA_CONFIG } from "../mastra/config.js";
import { query } from "./_generated/server";

/**
 * Get clinic agent status (for frontend display)
 */
export const getClinicAgentStatus = query({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const rows = await ctx.db
      .query("aiSettings")
      .withIndex("by_clinic", (q: any) => q.eq("clinicId", args.clinicId))
      .collect();

    const settings = rows.sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0))[0];

    if (!settings) {
      return {
        enabled: false,
        agentName: null,
        lastUsedModel: null,
      };
    }

    return {
      enabled: settings.enabled,
      agentName: `clinic-agent-${args.clinicId}`,
      lastUsedModel: MASTRA_CONFIG.models.agent,
      activeHours: `${settings.activeHoursStart} - ${settings.activeHoursEnd}`,
      tone: settings.tone,
      escalationEnabled: settings.escalationEnabled,
      voiceNotesEnabled: true,
    };
  },
});
