export const reminderTypes = [
  "appointmentConfirmation",
  "sevenDay",
  "twentyFourHour",
  "oneHour",
  "postConsultation",
  "noShowRecovery",
  "rescheduleOptions",
  "rescheduleConfirmation",
  "confirmationReply",
  "cancellationConfirmation",
  "googleReviewFollowUp",
  "detractorAlert",
] as const;

export type ReminderType = (typeof reminderTypes)[number];
export type ReminderChannel = "whatsapp" | "sms" | "email" | "call";

type ReminderConfigSeed = {
  type: ReminderType;
  enabled: boolean;
  message: string;
  channels: ReminderChannel[];
  useOfficialApi: boolean;
  delayMinutes?: number;
};

const defaultReminderConfigSeeds: ReminderConfigSeed[] = [
  {
    type: "appointmentConfirmation",
    enabled: true,
    message:
      "Ola {{patient.name}}! Sua consulta esta marcada para {{appointment.date}}, as {{appointment.time}}, com {{appointment.doctor}}. Responda SIM para confirmar ou NAO se preferir reagendar.",
    channels: ["whatsapp"],
    useOfficialApi: false,
  },
  {
    type: "sevenDay",
    enabled: true,
    message:
      "Ola {{patient.name}}! Lembramos que voce tem uma consulta agendada para {{appointment.date}} as {{appointment.time}}.",
    channels: ["whatsapp"],
    useOfficialApi: false,
  },
  {
    type: "twentyFourHour",
    enabled: true,
    message:
      "Oi {{patient.name}}! Sua consulta e amanha as {{appointment.time}}. Por favor, confirme sua presenca respondendo SIM.",
    channels: ["whatsapp"],
    useOfficialApi: false,
  },
  {
    type: "oneHour",
    enabled: true,
    message:
      "Ola {{patient.name}}! Sua consulta e em 1 hora ({{appointment.time}}). Estamos aguardando voce.",
    channels: ["whatsapp"],
    useOfficialApi: false,
  },
  {
    type: "postConsultation",
    enabled: false,
    message:
      "Ola {{patient.name}}, obrigado pela sua consulta com {{appointment.doctor}}. Gostariamos de ouvir sua opiniao sobre o atendimento.",
    channels: ["whatsapp"],
    useOfficialApi: false,
    delayMinutes: 120,
  },
  {
    type: "noShowRecovery",
    enabled: true,
    message:
      "Ola {{patient.name}}, notamos que voce nao pode comparecer. Gostaria de reagendar sua consulta?",
    channels: ["whatsapp"],
    useOfficialApi: false,
  },
  {
    type: "rescheduleOptions",
    enabled: true,
    message:
      "Sem problema, {{patient.name}}. Posso reagendar sua {{appointment.procedure}} para uma destas opcoes:\n\n{{reschedule.options}}\n\nResponda com 1, 2 ou 3. Se nao quiser nenhuma opcao, responda NAO para cancelar.",
    channels: ["whatsapp"],
    useOfficialApi: false,
  },
  {
    type: "rescheduleConfirmation",
    enabled: true,
    message:
      "Ola {{patient.name}}! Sua {{appointment.procedure}} foi reagendada.\n\nNova data: {{appointment.date}}\nHorario: {{appointment.time}}\nTipo: {{appointment.type}}\n\nCaso precise de algo, estamos a disposicao!",
    channels: ["whatsapp"],
    useOfficialApi: false,
  },
  {
    type: "confirmationReply",
    enabled: true,
    message:
      "Perfeito! Sua consulta esta confirmada. Se precisar de algo antes do atendimento, estou por aqui.",
    channels: ["whatsapp"],
    useOfficialApi: false,
  },
  {
    type: "cancellationConfirmation",
    enabled: true,
    message:
      "Tudo bem. Sua consulta foi cancelada{{cancellation.reason}}. Quando quiser, podemos buscar um novo horario para voce.",
    channels: ["whatsapp"],
    useOfficialApi: false,
  },
  {
    type: "googleReviewFollowUp",
    enabled: true,
    message:
      "Obrigado pela avaliacao, {{patient.name}}! Se voce puder, deixar uma avaliacao no Google ajudaria muito: {{nps.googleMapsLink}}",
    channels: ["whatsapp"],
    useOfficialApi: false,
  },
  {
    type: "detractorAlert",
    enabled: true,
    message:
      'ALERTA DE DETRATOR NPS\n\nPaciente: {{patient.name}}\nNota: {{nps.score}}/10\nFeedback: "{{nps.feedback}}"\nMedico: {{appointment.doctor}}\n\nVerifique o atendimento e entre em contato se necessario.',
    channels: ["whatsapp"],
    useOfficialApi: false,
  },
];

export function buildDefaultReminderConfigs(clinicId: string, now: number) {
  return defaultReminderConfigSeeds.map((config) => ({
    clinicId,
    type: config.type,
    enabled: config.enabled,
    message: config.message,
    channels: config.channels,
    useOfficialApi: config.useOfficialApi,
    delayMinutes: config.delayMinutes,
    createdAt: now,
    updatedAt: now,
  }));
}
