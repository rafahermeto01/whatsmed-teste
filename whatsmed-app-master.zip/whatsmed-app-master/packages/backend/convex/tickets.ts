import { v } from "convex/values";

import { internalMutation, mutation, query } from "./_generated/server";
import { authComponent } from "./auth";

// Helper to get authenticated user and clinicId
async function getAuth(ctx: any): Promise<{ user: any; clinicId: string }> {
  const user: any = await authComponent.getAuthUser(ctx);
  if (!user) {
    throw new Error("Unauthorized");
  }

  const appUser = await ctx.db
    .query("users")
    .withIndex("by_email", (q: any) => q.eq("email", user.email))
    .first();

  const clinicId = appUser?.clinicId || (user as any).clinicId;

  return { user, clinicId: clinicId as string };
}

// ==================== PUBLIC QUERIES ====================

export const getTickets = query({
  args: {
    status: v.optional(v.union(v.literal("open"), v.literal("in_progress"), v.literal("resolved"))),
    priority: v.optional(
      v.union(v.literal("low"), v.literal("medium"), v.literal("high"), v.literal("urgent")),
    ),
  },
  handler: async (ctx: any, { status, priority }): Promise<any[]> => {
    const { clinicId } = await getAuth(ctx);

    let query: any = ctx.db
      .query("tickets")
      .withIndex("by_clinic", (q: any) => q.eq("clinicId", clinicId));

    if (status) {
      query = query.filter((q: any) => q.eq(q.field("status"), status));
    }

    if (priority) {
      query = query.filter((q: any) => q.eq(q.field("priority"), priority));
    }

    const tickets: any[] = await query.order("desc").take(100);

    // Enrich with patient and appointment info
    const enrichedTickets = await Promise.all(
      tickets.map(async (ticket: any) => {
        const patient: any = ticket.patientId ? await ctx.db.get(ticket.patientId) : null;
        const appointment: any = ticket.appointmentId
          ? await ctx.db.get(ticket.appointmentId)
          : null;

        return {
          ...ticket,
          patientName: patient?.name ?? "Unknown",
          appointmentDate: appointment?.startAt
            ? new Date(appointment.startAt).toISOString()
            : null,
        };
      }),
    );

    return enrichedTickets;
  },
});

export const getTicketById = query({
  args: {
    ticketId: v.id("tickets"),
  },
  handler: async (ctx, { ticketId }) => {
    const { clinicId } = await getAuth(ctx);

    const ticket = await ctx.db.get(ticketId);

    if (!ticket || ticket.clinicId !== clinicId) {
      throw new Error("Ticket not found");
    }

    const patient = ticket.patientId ? await ctx.db.get(ticket.patientId) : null;
    const appointment = ticket.appointmentId ? await ctx.db.get(ticket.appointmentId) : null;

    return {
      ...ticket,
      patientName: patient?.name ?? "Unknown",
      appointmentDate: appointment?.startAt ? new Date(appointment.startAt).toISOString() : null,
    };
  },
});

// ==================== PUBLIC MUTATIONS ====================

export const updateTicketStatus = mutation({
  args: {
    ticketId: v.id("tickets"),
    status: v.union(v.literal("open"), v.literal("in_progress"), v.literal("resolved")),
  },
  handler: async (ctx, { ticketId, status }) => {
    const { clinicId } = await getAuth(ctx);

    const ticket = await ctx.db.get(ticketId);

    if (!ticket || ticket.clinicId !== clinicId) {
      throw new Error("Ticket not found");
    }

    await ctx.db.patch(ticketId, {
      status,
      updatedAt: Date.now(),
    });

    return await ctx.db.get(ticketId);
  },
});

// ==================== INTERNAL MUTATIONS ====================

export const createTicket = internalMutation({
  args: {
    clinicId: v.string(),
    patientId: v.id("patients"),
    appointmentId: v.optional(v.id("appointments")),
    title: v.string(),
    description: v.string(),
    priority: v.union(
      v.literal("low"),
      v.literal("medium"),
      v.literal("high"),
      v.literal("urgent"),
    ),
    source: v.union(v.literal("nps"), v.literal("other")),
    npsScore: v.optional(v.number()),
    npsFeedback: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const ticketId = await ctx.db.insert("tickets", {
      clinicId: args.clinicId,
      patientId: args.patientId,
      appointmentId: args.appointmentId,
      title: args.title,
      description: args.description,
      status: "open",
      priority: args.priority,
      source: args.source,
      npsScore: args.npsScore,
      npsFeedback: args.npsFeedback,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });

    return await ctx.db.get(ticketId);
  },
});
