import { httpRouter } from "convex/server";

import { internal as internalApi } from "./_generated/api";
import { api } from "./_generated/api";
import { httpAction } from "./_generated/server";
import { authComponent, createAuth } from "./auth";
import { writeAudit } from "./lib/audit";
import { forbidden, badRequest, unauthorized } from "./lib/errors";
import {
  corsHeadersForRequest,
  errorResponse,
  jsonResponse,
  withCors,
  withRateLimit,
} from "./lib/httpHelpers";

const http = httpRouter();
const internalAny = internalApi as any;

const healthHandler = withCors(
  withRateLimit(
    async () =>
      jsonResponse({
        status: "ok",
        timestamp: new Date().toISOString(),
      }),
    { limit: 100, category: "health" },
  ),
);

const authRateLimited = (handler: any) =>
  withCors(
    withRateLimit(handler, {
      limit: 10,
      category: "auth",
    }),
  );

// Prevent unused variable warning
void authRateLimited;

http.route({
  path: "/api/health",
  method: "GET",
  handler: httpAction(async (ctx: any, request: Request) => {
    const requestId = request.headers.get("x-request-id") ?? undefined;
    try {
      return await healthHandler(ctx, request);
    } catch (error) {
      return errorResponse(error, requestId);
    }
  }),
});

http.route({
  path: "/:path*",
  method: "OPTIONS",
  handler: httpAction(async (_ctx, request) => {
    const { allowed, headers } = corsHeadersForRequest(request);
    if (!allowed) {
      return new Response(null, { status: 403 });
    }
    return new Response(null, { status: 204, headers });
  }),
});

function parseJson<T = any>(body: string): T {
  return JSON.parse(body) as T;
}

function base64ToArrayBuffer(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

function getUserAgent(request: Request) {
  return request.headers.get("user-agent") ?? undefined;
}

function sanitizeMessagePayload(data: any) {
  // Evolution API structure: body.data contains the message, or body.data is an array of messages
  // Handle both cases - if data is already the message object, use it directly
  const messageData = data?.data || data;
  const message = messageData?.message || messageData || {};

  // Debug: Log message structure for media detection
  const hasMedia =
    message.imageMessage ||
    message.videoMessage ||
    message.audioMessage ||
    message.documentMessage ||
    message.stickerMessage;
  if (hasMedia) {
    console.warn(
      `[sanitizeMessagePayload] Message has media, keys: ${Object.keys(message).join(", ")}`,
    );
    console.warn(`[sanitizeMessagePayload] Message structure:`, {
      hasImage: !!message.imageMessage,
      hasVideo: !!message.videoMessage,
      hasAudio: !!message.audioMessage,
      hasDocument: !!message.documentMessage,
      hasSticker: !!message.stickerMessage,
    });
  }

  // Extract media metadata without the actual base64 content
  let mediaInfo: {
    type: "audio" | "video" | "image" | "document" | "sticker";
    mimetype?: string;
    caption?: string;
    fileName?: string;
  } | null = null;

  if (message.audioMessage) {
    mediaInfo = {
      type: "audio",
      mimetype: message.audioMessage.mimetype,
    };
  } else if (message.videoMessage) {
    mediaInfo = {
      type: "video",
      mimetype: message.videoMessage.mimetype,
      caption: message.videoMessage.caption,
    };
  } else if (message.imageMessage) {
    mediaInfo = {
      type: "image",
      mimetype: message.imageMessage.mimetype,
      caption: message.imageMessage.caption,
    };
    console.warn(
      `[sanitizeMessagePayload] Detected image message, mimetype: ${message.imageMessage.mimetype}`,
    );
  } else if (message.documentMessage) {
    mediaInfo = {
      type: "document",
      mimetype: message.documentMessage.mimetype,
      fileName: message.documentMessage.fileName,
      caption: message.documentMessage.caption,
    };
  } else if (message.stickerMessage) {
    mediaInfo = {
      type: "sticker",
      mimetype: message.stickerMessage.mimetype,
    };
  }

  // Build sanitized message object with only necessary fields
  const sanitizedMessage: any = {};
  if (message.conversation) {
    sanitizedMessage.conversation = message.conversation;
  }
  if (message.extendedTextMessage) {
    sanitizedMessage.extendedTextMessage = {
      text: message.extendedTextMessage.text,
      contextInfo: message.extendedTextMessage.contextInfo,
    };
  }

  // Extract key - it might be at different levels
  const key = messageData.key || data?.key || {};

  return {
    key: key,
    pushName: messageData.pushName || data?.pushName,
    messageTimestamp: messageData.messageTimestamp || data?.messageTimestamp,
    contextInfo: messageData.contextInfo || data?.contextInfo,
    message: sanitizedMessage,
    mediaInfo,
  };
}

async function authenticate(ctx: any, request: Request) {
  const auth = createAuth(ctx);
  const session = await (auth as any).api.getSession({
    headers: request.headers,
  });

  if (session?.user) {
    return {
      sub: session.user.id,
      clinicId: session.user.clinicId,
      role: session.user.role,
      email: session.user.email,
    };
  }

  return null;
}

http.route({
  path: "/api/users",
  method: "GET",
  handler: httpAction(
    withCors(async (ctx, request) => {
      const requestId = request.headers.get("x-request-id") ?? undefined;
      try {
        const identity = await authenticate(ctx, request);
        if (!identity) throw unauthorized("Invalid token");
        if (identity.role !== "admin") throw forbidden("Admin only");
        const url = new URL(request.url);
        const role = url.searchParams.get("role") as "admin" | "staff" | "viewer" | null;
        const search = url.searchParams.get("search") ?? undefined;
        const limit = url.searchParams.get("limit");
        const cursor = url.searchParams.get("cursor") ?? undefined;
        const paramClinicId = url.searchParams.get("clinicId");

        const targetClinicId =
          identity.role === "super_admin" && paramClinicId
            ? paramClinicId
            : (identity.clinicId ?? "");

        const result = await ctx.runQuery(internalAny.users.list, {
          clinicId: targetClinicId,
          role: role ?? undefined,
          search,
          limit: limit ? Number(limit) : undefined,
          cursor,
        });
        return jsonResponse({ items: result.items, cursor: result.cursor });
      } catch (error) {
        return errorResponse(error, requestId);
      }
    }),
  ),
});

http.route({
  path: "/api/users",
  method: "POST",
  handler: httpAction(
    withCors(async (ctx, request) => {
      const requestId = request.headers.get("x-request-id") ?? undefined;
      try {
        const identity = await authenticate(ctx, request);
        if (!identity) throw unauthorized("Invalid token");
        if (identity.role !== "admin" && identity.role !== "super_admin")
          throw forbidden("Admin only");

        const body = parseJson<{
          email: string;
          name: string;
          role: "admin" | "staff" | "viewer" | "doctor";
          password: string;
          clinicId?: string; // Only used by super_admin
        }>(await request.text());
        if (!body.email || !body.name || !body.role || !body.password)
          throw badRequest("Missing fields");

        // Super admin can specify clinicId, regular admin uses their own
        const targetClinicId =
          identity.role === "super_admin" && body.clinicId
            ? body.clinicId
            : (identity.clinicId ?? "");

        if (!targetClinicId) throw badRequest("ClinicId is required");

        // Create user using internal mutation that uses authComponent adapter
        let authUserId: string;
        try {
          const result = await ctx.runMutation(internalAny.users.createAuthUser, {
            email: body.email,
            name: body.name,
            password: body.password,
          });
          authUserId = result.userId;
        } catch (error: any) {
          console.error("Create user error:", error);
          throw badRequest(error?.message || "Failed to create user in auth system");
        }

        // The onCreate trigger will automatically create a user in the users table
        // with default values (DEFAULT_CLINIC_ID and role "admin").
        // Wait a bit for the trigger to complete, then update the record with correct values
        await new Promise((resolve) => setTimeout(resolve, 200));

        // The mutation will find the user created by trigger (by email) and update it
        // with the correct clinicId and role
        const userDoc = await ctx.runMutation(
          identity.role === "super_admin"
            ? internalAny.users.createWithClinicId
            : internalAny.users.create,
          {
            authUserId: authUserId,
            clinicId: targetClinicId,
            email: body.email,
            name: body.name,
            role: body.role,
          },
        );

        await writeAudit(ctx, {
          action: "USER_CREATE",
          clinicId: targetClinicId,
          userId: userDoc?._id?.toString(),
          email: body.email,
          userAgent: getUserAgent(request),
          metadata: { role: body.role },
        });

        return jsonResponse({ user: userDoc });
      } catch (error) {
        return errorResponse(error, requestId);
      }
    }),
  ),
});

http.route({
  path: "/api/users/:id",
  method: "PUT",
  handler: httpAction(
    withCors(async (ctx, request) => {
      const requestId = request.headers.get("x-request-id") ?? undefined;
      try {
        const identity = await authenticate(ctx, request);
        if (!identity) throw unauthorized("Invalid token");
        if (identity.role !== "admin" && identity.role !== "super_admin")
          throw forbidden("Admin only");
        const body = parseJson<{ role?: "admin" | "staff" | "viewer" }>(await request.text());
        if (!body.role) throw badRequest("Role is required");
        const id = request.url.split("/").pop();
        if (!id) throw badRequest("User id required");

        const checkClinicId = identity.role === "admin" ? (identity.clinicId ?? "") : undefined;

        await ctx.runMutation(internalAny.users.updateRole, {
          id: id as any,
          role: body.role,
          clinicId: checkClinicId,
        });

        await writeAudit(ctx, {
          action: "USER_UPDATE_ROLE",
          clinicId: identity.clinicId,
          userId: id,
          userAgent: getUserAgent(request),
          metadata: { role: body.role },
        });
        return jsonResponse({ ok: true });
      } catch (error) {
        return errorResponse(error, requestId);
      }
    }),
  ),
});

http.route({
  path: "/api/users/:id",
  method: "DELETE",
  handler: httpAction(
    withCors(async (ctx, request) => {
      const requestId = request.headers.get("x-request-id") ?? undefined;
      try {
        const identity = await authenticate(ctx, request);
        if (!identity) throw unauthorized("Invalid token");
        if (identity.role !== "admin" && identity.role !== "super_admin")
          throw forbidden("Admin only");
        const id = request.url.split("/").pop();
        if (!id) throw badRequest("User id required");

        const checkClinicId = identity.role === "admin" ? (identity.clinicId ?? "") : undefined;

        await ctx.runMutation(internalAny.users.softDelete, {
          id: id as any,
          clinicId: checkClinicId,
        });

        await writeAudit(ctx, {
          action: "USER_DELETE",
          clinicId: identity.clinicId,
          userId: id,
          userAgent: getUserAgent(request),
          metadata: { id },
        });
        return jsonResponse({ ok: true });
      } catch (error) {
        return errorResponse(error, requestId);
      }
    }),
  ),
});

http.route({
  path: "/api/system/clinics",
  method: "GET",
  handler: httpAction(
    withCors(async (ctx, request) => {
      const requestId = request.headers.get("x-request-id") ?? undefined;
      try {
        const identity = await authenticate(ctx, request);
        if (!identity) throw unauthorized("Invalid token");
        if (identity.role !== "super_admin") throw forbidden("Super admin only");

        const clinics = await ctx.runQuery(internalAny.clinics.listAll, {});
        return jsonResponse({ clinics });
      } catch (error) {
        return errorResponse(error, requestId);
      }
    }),
  ),
});

http.route({
  path: "/api/webhooks/evolution",
  method: "POST",
  handler: httpAction(async (ctx, request) => {
    const requestId = request.headers.get("x-request-id") ?? undefined;
    try {
      const body = await request.json();
      const instanceName = body.instance;
      const event = body.event;

      // console.log(`Webhook received: ${event} for ${instanceName}`);

      if (!instanceName) {
        return jsonResponse({ error: "Missing instance name" }, 400);
      }

      // Handle different events
      switch (event.toUpperCase()) {
        case "QRCODE_UPDATED":
        case "QRCODE.UPDATED": {
          // Find instance by name and update QR
          const instanceQr = await ctx.runQuery(internalAny.integrations.findInstanceByName, {
            instanceName,
          });

          if (instanceQr) {
            await ctx.runMutation(internalAny.integrations.updateInstanceStatus, {
              instanceId: instanceQr._id,
              status: "connecting",
              qrcode: body.data.qrcode.base64,
            });
          }
          break;
        }

        case "CONNECTION_UPDATE":
        case "CONNECTION.UPDATE": {
          const state = body.data.state; // Evolution sends state: "open", "close", "connecting", "refused"

          let newStatus: "connected" | "disconnected" | "connecting" = "disconnected";
          if (state === "open") newStatus = "connected";
          else if (state === "connecting") newStatus = "connecting";

          const instanceConn = await ctx.runQuery(internalAny.integrations.findInstanceByName, {
            instanceName,
          });
          if (instanceConn) {
            await ctx.runMutation(internalAny.integrations.updateInstanceStatus, {
              instanceId: instanceConn._id,
              status: newStatus,
              qrcode: newStatus === "connected" ? undefined : instanceConn.qrcode,
            });
          }
          break;
        }

        case "MESSAGES_UPSERT":
        case "MESSAGES.UPSERT": {
          // Evolution API may send messages as an array or single object
          const messages = Array.isArray(body.data) ? body.data : [body.data];

          for (const messageData of messages) {
            // Sanitize payload to remove base64 media data and prevent field limit errors
            const sanitizedPayload = sanitizeMessagePayload(messageData);

            // Debug: Log keys to find base64
            console.warn(`[webhook] Message keys: ${Object.keys(messageData).join(", ")}`);
            if (messageData.base64)
              console.warn(`[webhook] Found base64 at root, length: ${messageData.base64.length}`);
            if (messageData.message?.base64)
              console.warn(
                `[webhook] Found base64 in message, length: ${messageData.message.base64.length}`,
              );

            // Check for media and upload to Convex Storage if present
            let mediaStorageId: string | undefined;

            try {
              const messageContent = messageData.message || messageData;
              const mediaMessage =
                messageContent.imageMessage ||
                messageContent.videoMessage ||
                messageContent.audioMessage ||
                messageContent.documentMessage ||
                messageContent.stickerMessage;

              if (mediaMessage) {
                let buffer: ArrayBuffer | Buffer | undefined;

                // Case 1: Base64 provided directly (if configured in Evolution)
                if (mediaMessage.url && mediaMessage.url.startsWith("data:")) {
                  const base64 = mediaMessage.url.split(",")[1];
                  buffer = base64ToArrayBuffer(base64);
                }
                // Case 2: Base64 in separate field (sometimes 'jpegThumbnail' is small, we want full)
                // Evolution often requires a separate call to get the base64 if not in payload.
                // But if the user says "implement logic to send media", and implies it's in the webhook or accessible.
                // Let's assume for now we might have 'media' or 'base64' field if configured to "include base64".
                else if (messageData.base64 || messageData.message?.base64) {
                  const base64Data = messageData.base64 || messageData.message?.base64;
                  buffer = base64ToArrayBuffer(base64Data);
                }

                // Case 3: URL provided (download it)
                else if (mediaMessage.url && !mediaMessage.url.startsWith("data:")) {
                  // Skip if URL is the generic web.whatsapp.net placeholder (common for stickers)
                  if (mediaMessage.url.includes("web.whatsapp.net")) {
                    console.warn(
                      `[webhook] Skipping download for web.whatsapp.net URL (likely sticker without public URL). Enable base64 in Evolution for stickers.`,
                    );
                  } else {
                    // Use Node.js action to handle download and potential decryption
                    // This allows using 'crypto' module which is not available in default runtime
                    console.warn(
                      `[webhook] Offloading media download/decryption to internal action: ${mediaMessage.url}`,
                    );

                    let type = "image";
                    if (messageContent.videoMessage) type = "video";
                    else if (messageContent.audioMessage) type = "audio";
                    else if (messageContent.documentMessage) type = "document";
                    else if (messageContent.stickerMessage) type = "sticker";

                    try {
                      const storageId = await ctx.runAction(
                        internalAny.whatsappActions.downloadAndDecryptMedia,
                        {
                          url: mediaMessage.url,
                          mediaKey: mediaMessage.mediaKey,
                          mediaType: type,
                          mimetype: mediaMessage.mimetype || "application/octet-stream",
                        },
                      );

                      if (storageId) {
                        mediaStorageId = storageId;
                        console.warn(`[webhook] Media processed and stored: ${mediaStorageId}`);
                      } else {
                        console.warn(`[webhook] Media action returned null storageId`);
                      }
                    } catch (e) {
                      console.error(`[webhook] Media action failed: ${e}`);
                    }
                  }
                }

                if (buffer) {
                  mediaStorageId = await ctx.storage.store(
                    new Blob([buffer as any], { type: mediaMessage.mimetype }),
                  );
                  console.warn(`[webhook] Media uploaded to storage: ${mediaStorageId}`);
                }
              }
            } catch (err) {
              console.error("[webhook] Error processing media upload:", err);
            }

            // Inject storage ID into payload for mutation
            if (mediaStorageId) {
              (sanitizedPayload as any).mediaStorageId = mediaStorageId;
            }

            console.warn(
              `[webhook] MESSAGES_UPSERT received. Payload keys: ${Object.keys(sanitizedPayload).join(", ")}. Has mediaInfo: ${!!sanitizedPayload.mediaInfo}`,
            );

            // Log metadata only (avoid sensitive message content in logs)
            if (sanitizedPayload.message) {
              const messageData = sanitizedPayload.message || {};
              const conversationText =
                messageData.conversation || messageData.extendedTextMessage?.text;
              const captionText =
                sanitizedPayload.mediaInfo?.caption ||
                messageData.imageMessage?.caption ||
                messageData.videoMessage?.caption ||
                "";
              const textLength =
                (typeof conversationText === "string" ? conversationText.length : 0) +
                (typeof captionText === "string" ? captionText.length : 0);
              console.log("[webhook] Message metadata:", {
                hasConversation: Boolean(messageData.conversation),
                hasExtendedText: Boolean(messageData.extendedTextMessage?.text),
                hasMediaInfo: Boolean(sanitizedPayload.mediaInfo),
                textLength,
              });
            }

            const result = await ctx.runMutation(
              internalAny.whatsappInternal.handleIncomingMessage,
              {
                instanceName,
                payload: sanitizedPayload,
                provider: "evolution",
              },
            );

            // Handle if result is null (e.g. status update ignored)
            if (!result) continue;

            // Destructure result (support legacy return of just messageId if needed, though we just changed it)
            const messageId = typeof result === "string" ? result : result.messageId;
            const {
              chatId,
              clinicId,
              patientId,
              isAiActive,
              isDuplicate,
              mediaWasUpdated,
              isFromMe,
            } = typeof result === "object" ? result : ({} as any);

            if (isFromMe) {
              console.log(`[webhook] Skipping AI for outbound-origin message ${messageId}`);
              continue;
            }

            // Skip AI for duplicates unless media was updated (media became ready)
            if (isDuplicate && !mediaWasUpdated) {
              console.log(
                `[webhook] Skipping AI for duplicate message ${messageId} (no new media)`,
              );
              continue;
            }

            if (messageId) {
              const appointmentReplyResult = await ctx.runAction(
                internalAny.automationActions.handleAppointmentReply,
                {
                  clinicId,
                  chatId,
                  messageId,
                  patientId,
                },
              );

              if (appointmentReplyResult?.handled) {
                console.log(
                  `[webhook] Appointment reply handled for chat ${chatId}: ${appointmentReplyResult.outcome}`,
                );
                continue;
              }

              // Trigger AI Response if enabled for this chat
              if (isAiActive) {
                const messageData = sanitizedPayload.message || {};
                const text =
                  messageData.conversation ||
                  messageData.extendedTextMessage?.text ||
                  sanitizedPayload.mediaInfo?.caption ||
                  messageData.imageMessage?.caption ||
                  messageData.videoMessage?.caption ||
                  "";

                const reason = mediaWasUpdated ? "media became ready" : "new message";
                console.warn(
                  `[webhook] Triggering AI for chat ${chatId} (clinic: ${clinicId}, reason: ${reason})`,
                );
                console.log(`[webhook] Message details: ID=${messageId}, length=${text.length}`);

                await ctx.scheduler.runAfter(0, internalAny.automationAi.processIncomingAiMessage, {
                  clinicId,
                  chatId,
                  messageId,
                  patientId,
                  traceId: requestId || String(messageId),
                });
              } else {
                console.log(
                  `[webhook] AI not triggered for chat ${chatId} (isAiActive=${isAiActive})`,
                );
              }
            }
          }
          break;
        }
      }

      return jsonResponse({ received: true });
    } catch (error) {
      console.error("Webhook error:", error);
      return errorResponse(error, requestId);
    }
  }),
});

http.route({
  path: "/api/patients",
  method: "GET",
  handler: httpAction(
    withCors(async (ctx, request) => {
      const requestId = request.headers.get("x-request-id") ?? undefined;
      try {
        const identity = await authenticate(ctx, request);
        if (!identity) throw unauthorized("Invalid token");

        const url = new URL(request.url);
        const search = url.searchParams.get("search") ?? undefined;
        const status = url.searchParams.get("status") as "active" | "inactive" | null;
        const limit = url.searchParams.get("limit");
        const cursor = url.searchParams.get("cursor") ?? undefined;

        const result = await ctx.runQuery(internalAny.patients.list, {
          clinicId: identity.clinicId ?? "",
          status: status ?? undefined,
          search,
          limit: limit ? Number(limit) : undefined,
          cursor,
        });

        return jsonResponse(result);
      } catch (error) {
        return errorResponse(error, requestId);
      }
    }),
  ),
});

http.route({
  path: "/api/patients",
  method: "POST",
  handler: httpAction(
    withCors(async (ctx, request) => {
      const requestId = request.headers.get("x-request-id") ?? undefined;
      try {
        const identity = await authenticate(ctx, request);
        if (!identity) throw unauthorized("Invalid token");

        const body = parseJson<any>(await request.text());
        // Validate required fields
        if (!body.name) throw badRequest("Name is required");

        const patient = await ctx.runMutation(internalAny.patients.create, {
          clinicId: identity.clinicId ?? "",
          name: body.name,
          phone: body.phone,
          email: body.email,
          dateOfBirth: body.dateOfBirth,
          externalId: body.externalId,
          status: body.status,
        });

        await writeAudit(ctx, {
          action: "PATIENT_CREATE",
          clinicId: identity.clinicId,
          userId: identity.sub,
          userAgent: getUserAgent(request),
          metadata: { patientId: patient._id },
        });

        return jsonResponse(patient);
      } catch (error) {
        return errorResponse(error, requestId);
      }
    }),
  ),
});

http.route({
  path: "/api/patients/:id",
  method: "PUT",
  handler: httpAction(
    withCors(async (ctx, request) => {
      const requestId = request.headers.get("x-request-id") ?? undefined;
      try {
        const identity = await authenticate(ctx, request);
        if (!identity) throw unauthorized("Invalid token");

        const id = request.url.split("/").pop();
        if (!id) throw badRequest("Patient id required");

        const body = parseJson<any>(await request.text());

        const patient = await ctx.runMutation(internalAny.patients.update, {
          id: id as any,
          clinicId: identity.clinicId ?? "",
          ...body,
        });

        await writeAudit(ctx, {
          action: "PATIENT_UPDATE",
          clinicId: identity.clinicId,
          userId: identity.sub,
          userAgent: getUserAgent(request),
          metadata: { patientId: id, updates: Object.keys(body) },
        });

        return jsonResponse(patient);
      } catch (error) {
        return errorResponse(error, requestId);
      }
    }),
  ),
});

http.route({
  path: "/api/patients/:id",
  method: "DELETE",
  handler: httpAction(
    withCors(async (ctx, request) => {
      const requestId = request.headers.get("x-request-id") ?? undefined;
      try {
        const identity = await authenticate(ctx, request);
        if (!identity) throw unauthorized("Invalid token");

        const id = request.url.split("/").pop();
        if (!id) throw badRequest("Patient id required");

        await ctx.runMutation(internalAny.patients.softDelete, {
          id: id as any,
          clinicId: identity.clinicId ?? "",
        });

        await writeAudit(ctx, {
          action: "PATIENT_DELETE",
          clinicId: identity.clinicId,
          userId: identity.sub,
          userAgent: getUserAgent(request),
          metadata: { patientId: id },
        });

        return jsonResponse({ ok: true });
      } catch (error) {
        return errorResponse(error, requestId);
      }
    }),
  ),
});

http.route({
  path: "/api/patients/import",
  method: "POST",
  handler: httpAction(
    withCors(async (ctx, request) => {
      const requestId = request.headers.get("x-request-id") ?? undefined;
      try {
        const identity = await authenticate(ctx, request);
        if (!identity) throw unauthorized("Invalid token");

        const body = parseJson<{ patients: any[] }>(await request.text());
        if (!body.patients || !Array.isArray(body.patients)) {
          throw badRequest("Patients array required");
        }

        const result = await ctx.runMutation(internalAny.patients.importBatch, {
          clinicId: identity.clinicId ?? "",
          patients: body.patients,
        });

        await writeAudit(ctx, {
          action: "PATIENT_IMPORT",
          clinicId: identity.clinicId,
          userId: identity.sub,
          userAgent: getUserAgent(request),
          metadata: { count: body.patients.length, success: result.success, failed: result.failed },
        });

        return jsonResponse(result);
      } catch (error) {
        return errorResponse(error, requestId);
      }
    }),
  ),
});

http.route({
  path: "/api/webhooks/asaas",
  method: "POST",
  handler: httpAction(async (ctx, request) => {
    const requestId = request.headers.get("x-request-id") ?? undefined;
    try {
      const accessToken = request.headers.get("asaas-access-token");
      const webhookSecret = process.env.ASAAS_WEBHOOK_SECRET;

      if (!webhookSecret || accessToken !== webhookSecret) {
        throw unauthorized("Invalid webhook token");
      }

      const body = await request.json();
      const event = body.event;
      const payment = body.payment;
      let ignored = false;

      switch (event) {
        case "PAYMENT_CONFIRMED":
        case "PAYMENT_RECEIVED":
          if (payment) {
            const result = await ctx.runMutation(internalAny.billing.processPaymentConfirmed, {
              paymentId: payment.id,
              value: payment.value,
              billingType: payment.billingType,
            });
            ignored = result?.handled === false;
          } else {
            ignored = true;
          }
          break;

        case "PAYMENT_REFUNDED":
          if (payment) {
            const result = await ctx.runMutation(internalAny.billing.processPaymentRefunded, {
              paymentId: payment.id,
              value: payment.value,
            });
            ignored = result?.handled === false;
          } else {
            ignored = true;
          }
          break;

        case "PAYMENT_OVERDUE":
        case "PAYMENT_DELETED":
          if (payment) {
            const result = await ctx.runMutation(internalAny.billing.processPaymentFailed, {
              paymentId: payment.id,
              status: event,
            });
            ignored = result?.handled === false;
          } else {
            ignored = true;
          }
          break;

        case "SUBSCRIPTION_UPDATED":
        case "SUBSCRIPTION_INACTIVATED": // Fallthrough
          // Subscription object might be in body.subscription?
          // Asaas payload for subscription events usually has "subscription" object.
          // Let's check docs or assume standard.
          // Docs say: { "event": "SUBSCRIPTION_UPDATED", "subscription": { ... } }
          if (body.subscription) {
            await ctx.runMutation(internalAny.billing.processSubscriptionEvent, {
              subscriptionId: body.subscription.id,
              status: body.subscription.status,
            });
          } else {
            ignored = true;
          }
          break;

        default:
          ignored = true;
          break;
      }

      return jsonResponse({ received: true, ignored });
    } catch (error) {
      console.error("Asaas Webhook Error:", error);
      return errorResponse(error, requestId);
    }
  }),
});

// Google OAuth 2.0 Callback
http.route({
  path: "/api/oauth/google/callback",
  method: "OPTIONS",
  handler: httpAction(async (_ctx, request) => {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
    });
  }),
});

// Register better-auth routes
// Note: If you see "no available workers" errors, check:
//1. Convex deployment is running (npx convex dev or check dashboard)
//2. HTTP routes are properly configured in convex.json
//3. Environment variables (SITE_URL, CONVEX_SITE_URL) are set correctly
authComponent.registerRoutes(http, createAuth);

export default http;
