import { v } from "convex/values";

import { internal } from "./_generated/api";
import { internalMutation, internalQuery, query } from "./_generated/server";
import { getPlanConfig } from "./lib/plans";

// Query: Get credit status for a clinic
export const getCreditStatus = query({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .unique();

    if (!clinic) {
      throw new Error("Clinic not found");
    }

    const planConfig = getPlanConfig(clinic.plan);
    const used = clinic.conversationCreditsUsed || 0;
    const purchased = clinic.conversationCreditsPurchased || 0;
    const planLimit = planConfig.maxConversations;

    // Available = plan limit - used + purchased
    const available = Math.max(0, planLimit - used) + purchased;

    return {
      used,
      planLimit,
      purchased,
      available,
    };
  },
});

// Internal Query: Check if clinic has available credits
export const checkCreditAvailability = internalQuery({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .unique();

    if (!clinic) {
      return { hasCredit: false, source: "none" as const };
    }

    const planConfig = getPlanConfig(clinic.plan);
    const used = clinic.conversationCreditsUsed || 0;
    const purchased = clinic.conversationCreditsPurchased || 0;
    const planLimit = planConfig.maxConversations;

    // Check plan credits first
    if (used < planLimit) {
      return { hasCredit: true, source: "plan" as const };
    }

    // Check purchased credits
    if (purchased > 0) {
      return { hasCredit: true, source: "purchased" as const };
    }

    return { hasCredit: false, source: "none" as const };
  },
});

// Internal Mutation: Consume a credit (increments used, falls back to purchased)
export const consumeCredit = internalMutation({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .unique();

    if (!clinic) {
      throw new Error("Clinic not found");
    }

    const planConfig = getPlanConfig(clinic.plan);
    const used = clinic.conversationCreditsUsed || 0;
    const purchased = clinic.conversationCreditsPurchased || 0;
    const planLimit = planConfig.maxConversations;

    // If plan limit not reached, increment used
    if (used < planLimit) {
      await ctx.db.patch(clinic._id, {
        conversationCreditsUsed: used + 1,
        updatedAt: Date.now(),
      });
      return;
    }

    // Otherwise, consume from purchased pool
    if (purchased > 0) {
      await ctx.db.patch(clinic._id, {
        conversationCreditsPurchased: purchased - 1,
        updatedAt: Date.now(),
      });
      return;
    }

    // No credits available - this shouldn't happen if checkCreditAvailability was called first
    throw new Error("No credits available");
  },
});

// Internal Mutation: Add purchased credits
export const addPurchasedCredits = internalMutation({
  args: { clinicId: v.string(), amount: v.number() },
  handler: async (ctx, args) => {
    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .unique();

    if (!clinic) {
      throw new Error("Clinic not found");
    }

    const current = clinic.conversationCreditsPurchased || 0;
    await ctx.db.patch(clinic._id, {
      conversationCreditsPurchased: current + args.amount,
      updatedAt: Date.now(),
    });
  },
});

// Internal Mutation: Reset billing cycle
export const resetBillingCycle = internalMutation({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .unique();

    if (!clinic) {
      throw new Error("Clinic not found");
    }

    await ctx.db.patch(clinic._id, {
      conversationCreditsUsed: 0,
      billingCycleStart: Date.now(),
      updatedAt: Date.now(),
    });
  },
});

// Internal Mutation: Check and reset cycles for all clinics (called by cron)
export const checkAndResetCycles = internalMutation({
  args: {},
  handler: async (ctx) => {
    const clinics = await ctx.db.query("clinics").collect();
    const now = Date.now();
    const thirtyDaysInMs = 30 * 24 * 60 * 60 * 1000;

    for (const clinic of clinics) {
      if (!clinic.billingCycleStart) {
        // Initialize cycle start if not set
        await ctx.db.patch(clinic._id, {
          billingCycleStart: now,
          conversationCreditsUsed: 0,
          updatedAt: now,
        });
        continue;
      }

      // Reset if cycle is older than 30 days
      if (now - clinic.billingCycleStart >= thirtyDaysInMs) {
        await ctx.db.patch(clinic._id, {
          conversationCreditsUsed: 0,
          billingCycleStart: now,
          updatedAt: now,
        });
      }
    }
  },
});

// Query: Get credit usage statistics
export const getCreditUsageStats = query({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .unique();

    if (!clinic) {
      throw new Error("Clinic not found");
    }

    const planConfig = getPlanConfig(clinic.plan);
    const used = clinic.conversationCreditsUsed || 0;
    const purchased = clinic.conversationCreditsPurchased || 0;
    const planLimit = planConfig.maxConversations;
    const billingCycleStart = clinic.billingCycleStart || Date.now();

    // Calculate days in current cycle
    const now = Date.now();
    const daysInCycle = Math.floor((now - billingCycleStart) / (24 * 60 * 60 * 1000));
    const cycleLength = 30; // Monthly cycles
    const daysRemaining = Math.max(0, cycleLength - daysInCycle);

    // Calculate average daily usage
    const avgDailyUsage = daysInCycle > 0 ? used / daysInCycle : 0;
    const projectedUsage = avgDailyUsage * cycleLength;

    return {
      current: {
        used,
        planLimit,
        purchased,
        available: Math.max(0, planLimit - used) + purchased,
      },
      cycle: {
        start: billingCycleStart,
        daysInCycle,
        daysRemaining,
        cycleLength,
      },
      projections: {
        avgDailyUsage: Math.round(avgDailyUsage * 10) / 10,
        projectedUsage: Math.round(projectedUsage),
        willExceedLimit: projectedUsage > planLimit,
      },
    };
  },
});
