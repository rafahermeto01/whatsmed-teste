"use node";

import { v } from "convex/values";

import { api, internal } from "./_generated/api";
import { action, internalAction } from "./_generated/server";
import { getSiteUrl } from "./auth";

const internalAny = internal as any;

// Helper for actions
async function getAuthAction(ctx: any) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) {
    throw new Error("Unauthorized");
  }

  // Query user using internal query (can be called from actions)
  let user = await ctx.runQuery(internal.users.getByEmailInternal, {
    email: identity.email!,
  });

  // Auto-provision if user doesn't exist
  if (!user) {
    user = await ctx.runMutation(internalAny.integrations.ensureAppUser, {
      authUserId: identity.subject,
      email: identity.email!,
      name: identity.name || identity.email!.split("@")[0],
    });
  }

  if (!user || !user.clinicId) {
    throw new Error("User is not associated with a clinic");
  }

  return { user, clinicId: user.clinicId as string };
}

// Helper to get valid access token (refreshes if needed)
async function ensureAccessToken(ctx: any, clinicId: string, userId: any): Promise<string> {
  const tokenData = await ctx.runQuery(internal.googleCalendar.getAccessToken, {
    clinicId,
    userId,
  });

  if (!tokenData) {
    throw new Error("Not connected to Google Calendar");
  }

  if (tokenData.expired) {
    console.log("Access token expired, refreshing...");
    const result: { accessToken: string; tokenType: string } = await ctx.runAction(
      internal.googleCalendarActions.refreshAccessToken,
      {
        clinicId,
        userId,
        refreshToken: tokenData.refreshToken!,
      },
    );
    return result.accessToken;
  }

  return tokenData.accessToken;
}

// Generate OAuth 2.0 authorization URL
export const getOAuthUrl = action({
  args: {},
  handler: async (ctx) => {
    const { user, clinicId } = await getAuthAction(ctx);

    const clientId = process.env.GOOGLE_CLIENT_ID;
    if (!clientId) {
      throw new Error("Google OAuth client ID not configured");
    }

    const siteUrl = getSiteUrl();
    const redirectUri = `${siteUrl}/api/oauth/google/callback`;
    console.log("[Action] Redirect URI used for Auth URL:", redirectUri);

    // Generate state parameter (CSRF protection + clinic/user context)
    const state = Buffer.from(
      JSON.stringify({
        clinicId,
        userId: user._id,
        timestamp: Date.now(),
      }),
    ).toString("base64url");

    // Store state temporarily for validation (expires in 10 minutes)
    await ctx.runMutation(internal.googleCalendar.storeOAuthState, {
      state,
      clinicId,
      userId: user._id,
      expiresAt: Date.now() + 10 * 60 * 1000, // 10 minutes
    });

    // Google OAuth 2.0 scopes for Calendar API
    const scopes = [
      "https://www.googleapis.com/auth/calendar.events",
      "https://www.googleapis.com/auth/calendar",
    ].join(" ");

    const authUrl = new URL("https://accounts.google.com/o/oauth2/v2/auth");
    authUrl.searchParams.set("client_id", clientId);
    authUrl.searchParams.set("redirect_uri", redirectUri);
    authUrl.searchParams.set("response_type", "code");
    authUrl.searchParams.set("scope", scopes);
    authUrl.searchParams.set("access_type", "offline"); // Get refresh token
    authUrl.searchParams.set("prompt", "consent"); // Force consent to get refresh token
    authUrl.searchParams.set("state", state);

    return { authUrl: authUrl.toString() };
  },
});

// Exchange authorization code for tokens
export const exchangeCodeForTokens = action({
  args: {
    code: v.string(),
    state: v.string(),
  },
  handler: async (ctx, args) => {
    const { code, state } = args;

    // Optional base64 payload parsing for backward compatibility.
    // Security validation relies on persisted oauthStates records.
    try {
      JSON.parse(Buffer.from(state, "base64url").toString());
    } catch {
      // Ignore non-base64 state formats.
    }

    const persistedState = await ctx.runMutation(internal.googleCalendar.consumeOAuthState, {
      state,
    });

    const clientId = process.env.GOOGLE_CLIENT_ID;
    const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
    const siteUrl = getSiteUrl();
    const redirectUri = `${siteUrl}/api/oauth/google/callback`;
    console.log("[Action] Redirect URI for Token Exchange:", redirectUri);

    if (!clientId || !clientSecret) {
      throw new Error("Google OAuth credentials not configured");
    }

    // Exchange code for tokens
    console.log("[Action] Exchanging code for tokens with Google...");
    const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        code,
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uri: redirectUri,
        grant_type: "authorization_code",
      }),
    });

    if (!tokenResponse.ok) {
      const error = await tokenResponse.text();
      console.error("[Action] Google Token Error:", error);
      throw new Error(`Failed to exchange code: ${error}`);
    }

    const tokens = await tokenResponse.json();

    // Store tokens in database
    await ctx.runMutation(internal.googleCalendar.storeTokens, {
      clinicId: persistedState.clinicId,
      userId: persistedState.userId,
      accessToken: tokens.access_token,
      refreshToken: tokens.refresh_token,
      expiresAt: tokens.expires_in ? Date.now() + tokens.expires_in * 1000 : undefined,
      scope: tokens.scope,
      tokenType: tokens.token_type || "Bearer",
    });

    return { success: true };
  },
});

// Refresh access token
export const refreshAccessToken = internalAction({
  args: {
    clinicId: v.string(),
    userId: v.id("users"),
    refreshToken: v.string(),
  },
  handler: async (ctx, args) => {
    const clientId = process.env.GOOGLE_CLIENT_ID;
    const clientSecret = process.env.GOOGLE_CLIENT_SECRET;

    if (!clientId || !clientSecret) {
      throw new Error("Google OAuth credentials not configured");
    }

    const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        refresh_token: args.refreshToken,
        client_id: clientId,
        client_secret: clientSecret,
        grant_type: "refresh_token",
      }),
    });

    if (!tokenResponse.ok) {
      const error = await tokenResponse.text();
      throw new Error(`Failed to refresh token: ${error}`);
    }

    const tokens = await tokenResponse.json();

    // Update stored tokens
    await ctx.runMutation(internal.googleCalendar.storeTokens, {
      clinicId: args.clinicId,
      userId: args.userId,
      accessToken: tokens.access_token,
      refreshToken: args.refreshToken, // Refresh token doesn't change
      expiresAt: tokens.expires_in ? Date.now() + tokens.expires_in * 1000 : undefined,
      tokenType: tokens.token_type || "Bearer",
    });

    return { accessToken: tokens.access_token, tokenType: tokens.token_type || "Bearer" };
  },
});

// List available calendars
export const listCalendars = action({
  args: {},
  handler: async (ctx): Promise<any[]> => {
    const { user, clinicId } = await getAuthAction(ctx);
    const accessToken = await ensureAccessToken(ctx, clinicId, user._id);

    const response = await fetch("https://www.googleapis.com/calendar/v3/users/me/calendarList", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!response.ok) {
      throw new Error("Failed to fetch calendars from Google");
    }

    const data: any = await response.json();
    return data.items.map((item: any) => ({
      id: item.id,
      summary: item.summary,
      primary: item.primary,
      backgroundColor: item.backgroundColor,
    }));
  },
});

// Sync events from blocked calendars
export const syncEvents = action({
  args: {
    userId: v.optional(v.id("users")), // Optional, can be triggered by cron for specific user
  },
  handler: async (ctx, args) => {
    let user;
    let clinicId;

    if (args.userId) {
      // Internal call (e.g. from Cron)
      // We need to fetch user details differently or assume context
      // For simplicity, we'll fetch the user doc
      user = await ctx.runQuery(api.users.getById, { id: args.userId });
      if (!user) throw new Error("User not found");
      clinicId = user.clinicId;
    } else {
      // Direct call from frontend
      const auth = await getAuthAction(ctx);
      user = auth.user;
      clinicId = auth.clinicId;
    }

    // Get settings
    const tokens = await ctx.runQuery(internal.googleCalendar.getTokensInternal, {
      clinicId: clinicId!,
      userId: user._id,
    });

    if (!tokens || !tokens.blockedCalendarIds || tokens.blockedCalendarIds.length === 0) {
      console.log("No blocked calendars configured for sync");
      return { synced: 0 };
    }

    const accessToken = await ensureAccessToken(ctx, clinicId!, user._id);
    let totalEvents = 0;

    // Time range: Now - 1 month to Now + 6 months
    const timeMin = new Date();
    timeMin.setMonth(timeMin.getMonth() - 1);
    const timeMax = new Date();
    timeMax.setMonth(timeMax.getMonth() + 6);

    for (const calendarId of tokens.blockedCalendarIds) {
      const response = await fetch(
        `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events?` +
          new URLSearchParams({
            timeMin: timeMin.toISOString(),
            timeMax: timeMax.toISOString(),
            singleEvents: "true", // Expand recurring events
            orderBy: "startTime",
          }),
        {
          headers: { Authorization: `Bearer ${accessToken}` },
        },
      );

      if (!response.ok) {
        console.error(`Failed to sync calendar ${calendarId}`);
        continue;
      }

      const data = await response.json();
      const events = data.items || [];
      totalEvents += events.length;

      // Batch update DB
      await ctx.runMutation(internal.googleCalendar.updateExternalEvents, {
        clinicId: clinicId!,
        userId: user._id,
        calendarId,
        events: events.map((e: any) => ({
          externalId: e.id,
          title: e.summary || "(No Title)",
          startTime: new Date(e.start.dateTime || e.start.date).getTime(),
          endTime: new Date(e.end.dateTime || e.end.date).getTime(),
          isAllDay: !!e.start.date,
          transparent: e.transparency === "transparent",
        })),
      });
    }

    // Update last sync time
    await ctx.runMutation(internal.googleCalendar.updateSyncStatus, {
      clinicId: clinicId!,
      userId: user._id,
    });

    return { synced: totalEvents };
  },
});

// Cron job to sync all connected calendars
export const syncAllCalendars = internalAction({
  args: {},
  handler: async (ctx) => {
    const users = await ctx.runQuery(internal.googleCalendar.getAllConnectedUsers);

    console.log(`Starting background sync for ${users.length} users`);

    // Process in batches to avoid timeouts
    const results = await Promise.allSettled(
      users.map((user: any) =>
        ctx.runAction(api.googleCalendarActions.syncEvents, { userId: user.userId }),
      ),
    );

    const succeeded = results.filter((r: any) => r.status === "fulfilled").length;
    console.log(
      `Background sync completed. Success: ${succeeded}, Failed: ${users.length - succeeded}`,
    );
  },
});
