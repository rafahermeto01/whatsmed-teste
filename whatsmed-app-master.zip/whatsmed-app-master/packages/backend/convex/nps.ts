import { v } from "convex/values";

import { internal } from "./_generated/api";
import {
  internalAction,
  internalMutation,
  internalQuery,
  mutation,
  query,
  action,
} from "./_generated/server";
import { authComponent } from "./auth";
import { badRequest } from "./lib/errors";
import { checkFeatureAccess } from "./lib/planEnforcement";

const internalAny = internal as any;

async function getOrCreateChatId(
  ctx: any,
  args: {
    clinicId: string;
    phone: string;
    patientId?: any;
    title?: string;
  },
) {
  const existingChat = await ctx.runQuery(internalAny.whatsappQueries.findChatByPhone, {
    clinicId: args.clinicId,
    phone: args.phone,
  });

  if (existingChat) {
    return existingChat._id;
  }

  const cleanPhone = String(args.phone || "").replace(/\D/g, "");
  if (!cleanPhone) {
    return null;
  }

  const whatsappPhone = cleanPhone.startsWith("55") ? cleanPhone : `55${cleanPhone}`;
  return await ctx.runMutation(internalAny.whatsappQueries.createChatInternal, {
    clinicId: args.clinicId,
    patientId: args.patientId,
    whatsappChatId: `${whatsappPhone}@s.whatsapp.net`,
    title: args.title,
  });
}

async function renderConfiguredReminderMessage(
  ctx: any,
  args: {
    clinicId: string;
    type: "googleReviewFollowUp" | "detractorAlert";
    context: Record<string, any>;
  },
) {
  const config = await ctx.runQuery(
    internalAny.automationInternal.getReminderConfigByClinicAndType,
    {
      clinicId: args.clinicId,
      type: args.type,
    },
  );

  if (!config?.enabled || !config.message?.trim()) {
    return null;
  }

  const { personalizeMessage } = await import("../mastra/workflows");
  return personalizeMessage(config.message, args.context);
}

// Helper to get authenticated user and clinicId
async function getAuth(ctx: any): Promise<{ user: any; clinicId: string }> {
  const user: any = await authComponent.getAuthUser(ctx);
  if (!user) {
    throw new Error("Unauthorized");
  }

  // Try to find app user to get reliable clinicId
  const appUser = await ctx.db
    .query("users")
    .withIndex("by_email", (q: any) => q.eq("email", user.email))
    .first();

  const clinicId = appUser?.clinicId || (user as any).clinicId;

  return { user, clinicId: clinicId as string };
}

// ==================== PUBLIC QUERIES ====================

export const getNpsSettings = query({
  args: {},
  handler: async (ctx: any): Promise<any> => {
    const { clinicId } = await getAuth(ctx);

    const settings: any = await ctx.db
      .query("npsSettings")
      .withIndex("by_clinic", (q: any) => q.eq("clinicId", clinicId))
      .first();

    return settings;
  },
});

export const getNpsResponses = query({
  args: {
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
  },
  handler: async (ctx, { startDate, endDate }) => {
    const { clinicId } = await getAuth(ctx);

    let query = ctx.db
      .query("npsResponses")
      .withIndex("by_clinic_date", (q) => q.eq("clinicId", clinicId));

    if (startDate || endDate) {
      query = query.filter((q: any) => {
        const conditions = [];
        if (startDate) {
          conditions.push(q.gte(q.field("respondedAt"), startDate));
        }
        if (endDate) {
          conditions.push(q.lte(q.field("respondedAt"), endDate));
        }
        return q.and(...conditions);
      });
    }

    const responses = await query.order("desc").take(500);

    // Fetch patient and appointment details
    const enrichedResponses = await Promise.all(
      responses.map(async (response) => {
        const patient = await ctx.db.get(response.patientId);
        const appointment = await ctx.db.get(response.appointmentId);

        return {
          ...response,
          patientName: patient?.name ?? "Unknown",
          doctorName: appointment?.doctor ?? "Unknown",
        };
      }),
    );

    return enrichedResponses;
  },
});

export const getNpsHistory = query({
  args: {
    days: v.optional(v.number()),
  },
  handler: async (ctx, { days = 30 }) => {
    const { clinicId } = await getAuth(ctx);
    const startTime = Date.now() - days * 24 * 60 * 60 * 1000;

    const responses = await ctx.db
      .query("npsResponses")
      .withIndex("by_clinic_date", (q) => q.eq("clinicId", clinicId).gte("respondedAt", startTime))
      .collect();

    // Group by date (YYYY-MM-DD)
    const historyMap = new Map<string, any>();

    // Initialize map with all days in range to ensure no gaps
    for (let i = 0; i < days; i++) {
      const date = new Date(Date.now() - i * 24 * 60 * 60 * 1000);
      const dateStr = date.toISOString().split("T")[0];
      historyMap.set(dateStr, {
        date: dateStr,
        promoters: 0,
        passives: 0,
        detractors: 0,
        total: 0,
        score: 0,
      });
    }

    responses.forEach((r) => {
      const dateStr = new Date(r.respondedAt).toISOString().split("T")[0];
      if (historyMap.has(dateStr)) {
        const day = historyMap.get(dateStr);
        day.total++;
        if (r.promoterType === "promoter") day.promoters++;
        else if (r.promoterType === "passive") day.passives++;
        else if (r.promoterType === "detractor") day.detractors++;
      }
    });

    // Calculate rolling NPS score for each day
    const history = Array.from(historyMap.values())
      .map((day) => {
        if (day.total > 0) {
          const promoterPerc = (day.promoters / day.total) * 100;
          const detractorPerc = (day.detractors / day.total) * 100;
          day.score = Math.round(promoterPerc - detractorPerc);
        }
        return day;
      })
      .sort((a, b) => a.date.localeCompare(b.date));

    return history;
  },
});

export const calculateNpsScore = query({
  args: {
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
  },
  handler: async (ctx, { startDate, endDate }) => {
    const { clinicId } = await getAuth(ctx);

    let query = ctx.db
      .query("npsResponses")
      .withIndex("by_clinic_date", (q) => q.eq("clinicId", clinicId));

    if (startDate || endDate) {
      query = query.filter((q: any) => {
        const conditions = [];
        if (startDate) {
          conditions.push(q.gte(q.field("respondedAt"), startDate));
        }
        if (endDate) {
          conditions.push(q.lte(q.field("respondedAt"), endDate));
        }
        return q.and(...conditions);
      });
    }

    const responses = await query.collect();

    if (responses.length === 0) {
      return {
        score: 0,
        promoters: 0,
        passives: 0,
        detractors: 0,
        totalResponses: 0,
        promoterPercentage: 0,
        detractorPercentage: 0,
      };
    }

    const promoters = responses.filter((r) => r.promoterType === "promoter").length;
    const passives = responses.filter((r) => r.promoterType === "passive").length;
    const detractors = responses.filter((r) => r.promoterType === "detractor").length;

    const promoterPercentage = (promoters / responses.length) * 100;
    const detractorPercentage = (detractors / responses.length) * 100;

    // NPS = % Promoters - % Detractors
    const npsScore = Math.round(promoterPercentage - detractorPercentage);

    return {
      score: npsScore,
      promoters,
      passives,
      detractors,
      totalResponses: responses.length,
      promoterPercentage: Math.round(promoterPercentage),
      detractorPercentage: Math.round(detractorPercentage),
    };
  },
});

// ==================== PUBLIC MUTATIONS ====================

export const updateNpsSettings = mutation({
  args: {
    enabled: v.optional(v.boolean()),
    delayMinutes: v.optional(v.number()),
    sendOnCompletion: v.optional(v.boolean()),
    reviewLink: v.optional(v.string()),
    googleMapsLink: v.optional(v.string()),
    alertOnDetractor: v.optional(v.boolean()),
    thresholds: v.optional(
      v.object({
        promoter: v.optional(v.number()),
        passive: v.optional(v.number()),
        detractor: v.optional(v.number()),
      }),
    ),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    const existing = await ctx.db
      .query("npsSettings")
      .withIndex("by_clinic", (q) => q.eq("clinicId", clinicId))
      .first();

    if (existing) {
      await ctx.db.patch(existing._id, {
        ...args,
        updatedAt: Date.now(),
      });
      return await ctx.db.get(existing._id);
    } else {
      const id = await ctx.db.insert("npsSettings", {
        clinicId,
        enabled: args.enabled ?? true,
        delayMinutes: args.delayMinutes ?? 120,
        sendOnCompletion: args.sendOnCompletion ?? true,
        reviewLink: args.reviewLink ?? "",
        googleMapsLink: args.googleMapsLink ?? "",
        alertOnDetractor: args.alertOnDetractor ?? true,
        thresholds: args.thresholds ?? {
          promoter: 9,
          passive: 7,
          detractor: 6,
        },
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
      return await ctx.db.get(id);
    }
  },
});

export const toggleNpsEnabled = mutation({
  args: {
    enabled: v.boolean(),
  },
  handler: async (ctx, { enabled }) => {
    const { clinicId } = await getAuth(ctx);

    const existing = await ctx.db
      .query("npsSettings")
      .withIndex("by_clinic", (q) => q.eq("clinicId", clinicId))
      .first();

    if (!existing) {
      throw new Error("NPS settings not found. Please configure NPS first.");
    }

    await ctx.db.patch(existing._id, {
      enabled,
      updatedAt: Date.now(),
    });

    return await ctx.db.get(existing._id);
  },
});

// ==================== INTERNAL QUERIES ====================

export const getNpsSettingsInternal = internalQuery({
  args: { clinicId: v.string() },
  handler: async (ctx, { clinicId }) => {
    return await ctx.db
      .query("npsSettings")
      .withIndex("by_clinic", (q) => q.eq("clinicId", clinicId))
      .first();
  },
});

export const getNpsResponseByAppointment = internalQuery({
  args: { appointmentId: v.id("appointments") },
  handler: async (ctx, { appointmentId }) => {
    return await ctx.db
      .query("npsResponses")
      .withIndex("by_appointment", (q) => q.eq("appointmentId", appointmentId))
      .first();
  },
});

export const getClinicInternal = internalQuery({
  args: { clinicId: v.string() },
  handler: async (ctx, { clinicId }) => {
    return await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", clinicId))
      .unique();
  },
});

export const getPatientWithChat = internalQuery({
  args: {
    patientId: v.id("patients"),
    clinicId: v.string(),
  },
  handler: async (ctx, { patientId, clinicId }) => {
    const patient = await ctx.db.get(patientId);
    if (!patient || patient.clinicId !== clinicId) {
      return null;
    }

    // Find chat for this patient
    const chat = await ctx.db
      .query("chats")
      .filter((q) => q.eq(q.field("patientId"), patientId))
      .first();

    return {
      patient,
      chat,
    };
  },
});

// ==================== INTERNAL MUTATIONS ====================

export const recordNpsSurveySent = internalMutation({
  args: {
    appointmentId: v.id("appointments"),
  },
  handler: async (ctx, { appointmentId }) => {
    await ctx.db.patch(appointmentId, {
      npsSurveySentAt: Date.now(),
      updatedAt: Date.now(),
    });
  },
});

export const recordNpsResponse = internalMutation({
  args: {
    clinicId: v.string(),
    patientId: v.id("patients"),
    appointmentId: v.id("appointments"),
    score: v.number(),
    messageText: v.string(),
    promoterType: v.union(v.literal("promoter"), v.literal("passive"), v.literal("detractor")),
    channel: v.union(v.literal("whatsapp"), v.literal("email"), v.literal("sms")),
    checkinSessionId: v.optional(v.id("checkinSessions")),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("npsResponses", {
      clinicId: args.clinicId,
      patientId: args.patientId,
      appointmentId: args.appointmentId,
      score: args.score,
      promoterType: args.promoterType,
      feedback: args.messageText,
      respondedAt: Date.now(),
      channel: args.channel,
      checkinSessionId: args.checkinSessionId,
      createdAt: Date.now(),
    });

    return true;
  },
});

// ==================== ACTIONS ====================

export const sendNpsSurveyAction = internalAction({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
    patientId: v.id("patients"),
    delayMinutes: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const { appointmentId, clinicId, patientId } = args;

    // Check feature access
    const access = await ctx.runQuery(internal.planEnforcement.checkFeatureAccess, {
      clinicId,
      feature: "nps" as const,
    });
    if (!access.allowed) {
      console.warn(`[sendNpsSurveyAction] Feature not available for plan`);
      return;
    }

    try {
      // Check if survey was already sent
      const appointment = await ctx.runQuery(internal.appointments.getAppointmentForMeeting, {
        appointmentId,
      });

      if (!appointment || appointment.clinicId !== clinicId) {
        console.error(`[sendNpsSurveyAction] Appointment not found or access denied`);
        return;
      }

      if (appointment.npsSurveySentAt) {
        console.warn(`[sendNpsSurveyAction] Survey already sent for appointment ${appointmentId}`);
        return;
      }

      // Check if appointment already has an NPS response
      const existingResponse = await ctx.runQuery(internal.nps.getNpsResponseByAppointment, {
        appointmentId,
      });

      if (existingResponse) {
        console.warn(
          `[sendNpsSurveyAction] Appointment ${appointmentId} already has NPS response, skipping survey`,
        );
        return;
      }

      // Get NPS settings
      const npsSettings = await ctx.runQuery(internal.nps.getNpsSettingsInternal, {
        clinicId,
      });

      if (!npsSettings || !npsSettings.enabled) {
        console.warn(`[sendNpsSurveyAction] NPS disabled for clinic ${clinicId}`);
        return;
      }

      // Get patient and chat information
      const result = await ctx.runQuery(internal.nps.getPatientWithChat, {
        patientId,
        clinicId,
      });

      if (!result || !result.patient) {
        console.error(`[sendNpsSurveyAction] Patient not found`);
        return;
      }

      const { patient, chat } = result;

      // Get patient phone number
      const phone = patient.phone?.replace("+", "") || "";

      if (!phone) {
        console.error(`[sendNpsSurveyAction] No phone number for patient`);
        return;
      }

      const chatId =
        chat?._id ||
        (await getOrCreateChatId(ctx, {
          clinicId,
          patientId,
          phone,
          title: patient.name,
        }));

      if (!chatId) {
        console.error(`[sendNpsSurveyAction] Chat not found for patient`);
        return;
      }

      // Get clinic directly from database for variable interpolation
      const clinic = await ctx.runQuery(internal.nps.getClinicInternal, {
        clinicId,
      });

      // Get message template from settings or use default
      const messageTemplate =
        npsSettings.reviewLink ||
        "Olá {{patient.name}}! Como foi sua experiência conosco? Por favor, avalie de 0 a 10 respondendo esta mensagem.";

      // Build context for variable interpolation
      const patientName = patient.name?.split(" ")[0] || "paciente";
      const now = new Date();
      const appointmentDate = appointment?.startAt
        ? new Date(appointment.startAt).toLocaleDateString("pt-BR")
        : "";
      const appointmentTime = appointment?.startAt
        ? new Date(appointment.startAt).toLocaleTimeString("pt-BR", {
            hour: "2-digit",
            minute: "2-digit",
          })
        : "";

      const context = {
        patient: {
          name: patient.name,
          phone: patient.phone,
          email: patient.email,
        },
        clinic: {
          name: clinic?.name || "",
          phone: clinic?.phone || "",
          address: clinic?.address || "",
        },
        appointment: {
          date: appointmentDate,
          time: appointmentTime,
          doctor: appointment?.doctor || "",
        },
        doctor: {
          name: appointment?.doctor || "",
        },
        date: {
          today: now.toLocaleDateString("pt-BR"),
          now: now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
          weekday: now.toLocaleDateString("pt-BR", { weekday: "long" }),
        },
        // Legacy variables for backward compatibility
        patient_name: patientName,
        clinic_name: clinic?.name || "",
        doctor_name: appointment?.doctor || "",
        appointment_date: appointmentDate,
        appointment_time: appointmentTime,
      };

      // Import personalizeMessage from mastra workflows
      const mastraWorkflows = await import("../mastra/workflows");

      // Interpolate message template
      const surveyMessage = mastraWorkflows.personalizeMessage(messageTemplate, context);

      // Get WhatsApp instance
      const instance = await ctx.runQuery(internalAny.integrations.getWhatsAppInstanceInternal, {
        clinicId,
      });

      if (!instance || instance.status !== "connected") {
        console.error(`[sendNpsSurveyAction] WhatsApp instance not connected`);
        return;
      }

      // Save message to messages table first (so agent has context)
      const messageId = await ctx.runMutation(internal.whatsappQueries.sendMessageAction, {
        chatId,
        text: surveyMessage,
      });

      // Record that survey was sent
      await ctx.runMutation(internal.nps.recordNpsSurveySent, {
        appointmentId,
      });

      console.log(`[sendNpsSurveyAction] NPS survey sent to patient ${patientName} (${phone})`);
    } catch (error) {
      console.error(`[sendNpsSurveyAction] Failed to send NPS survey:`, error);
    }
  },
});

export const sendNpsSurveyManual = action({
  args: {
    patientId: v.id("patients"),
    clinicId: v.string(),
    messageTemplate: v.optional(v.string()),
  },
  handler: async (ctx, { patientId, clinicId, messageTemplate }) => {
    // Check feature access
    const access = await ctx.runQuery(internal.planEnforcement.checkFeatureAccess, {
      clinicId,
      feature: "nps" as const,
    });
    if (!access.allowed) {
      throw new Error(`Recurso disponível a partir do plano ${access.requiredPlan}.`);
    }

    try {
      // Get patient and chat information
      const result = await ctx.runQuery(internal.nps.getPatientWithChat, {
        patientId,
        clinicId,
      });

      if (!result || !result.patient) {
        throw new Error("Paciente não encontrado");
      }

      const { patient, chat } = result;

      // Get patient phone number - remove all non-digits
      const phone = patient.phone?.replace(/\D/g, "") || "";

      if (!phone) {
        throw new Error("Paciente não possui telefone cadastrado");
      }

      // Fetch NPS settings for the configured message template
      const npsSettings = await ctx.runQuery(internal.nps.getNpsSettingsInternal, {
        clinicId,
      });

      // Fetch clinic info for variable interpolation
      const clinic = await ctx.runQuery(internal.nps.getClinicInternal, {
        clinicId,
      });

      // CRITICAL: Ensure chat exists - create if missing
      let chatId = chat?._id;
      if (!chatId) {
        // Format phone for WhatsApp
        const formattedPhone = phone.startsWith("55") ? phone : `55${phone}`;
        const whatsappChatId = `${formattedPhone}@s.whatsapp.net`;

        chatId = await ctx.runMutation(internalAny.whatsappQueries.createChatInternal, {
          clinicId,
          patientId,
          whatsappChatId,
          title: patient.name,
        });
      }

      // Use template priority: argument > settings > default
      const templateToUse =
        messageTemplate ||
        npsSettings?.reviewLink ||
        "Olá {{patient.name}}! Como foi sua experiência conosco? Por favor, avalie de 0 a 10 respondendo esta mensagem.";

      // Build context for variable interpolation
      const patientName = patient.name?.split(" ")[0] || "paciente";
      const now = new Date();

      const context = {
        patient: {
          name: patient.name,
          phone: patient.phone,
          email: patient.email,
        },
        clinic: {
          name: clinic?.name || "",
          phone: clinic?.phone || "",
          address: clinic?.address || "",
        },
        appointment: {
          date: "",
          time: "",
          doctor: "",
        },
        doctor: {
          name: "",
        },
        date: {
          today: now.toLocaleDateString("pt-BR"),
          now: now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
          weekday: now.toLocaleDateString("pt-BR", { weekday: "long" }),
        },
        // Legacy variables for backward compatibility
        patient_name: patientName,
        clinic_name: clinic?.name || "",
        doctor_name: "",
        appointment_date: "",
        appointment_time: "",
      };

      // Interpolate variables in the template
      const mastraWorkflows = await import("../mastra/workflows");
      const surveyMessage = mastraWorkflows.personalizeMessage(templateToUse, context);

      // Store message AND schedule WhatsApp send via internal mutation
      await ctx.runMutation(internalAny.whatsappQueries.sendMessageAction, {
        chatId,
        text: surveyMessage,
      });

      console.log(`[sendNpsSurveyManual] NPS survey queued for patient ${patientName}`);

      return { success: true, message: "Pesquisa NPS enviada com sucesso" };
    } catch (error) {
      console.error(`[sendNpsSurveyManual] Failed to send NPS survey:`, error);
      throw error;
    }
  },
});

export const sendGoogleReviewFollowUp = internalAction({
  args: {
    clinicId: v.string(),
    chatId: v.id("chats"),
    googleMapsLink: v.string(),
  },
  handler: async (ctx, { clinicId, chatId, googleMapsLink }) => {
    try {
      if (!googleMapsLink) {
        console.warn(`[sendGoogleReviewFollowUp] No Google Maps link configured`);
        return;
      }

      const chat = await ctx.runQuery(internal.nps.getChatById, { chatId });
      if (!chat || chat.clinicId !== clinicId) {
        console.error(`[sendGoogleReviewFollowUp] Chat not found or access denied`);
        return;
      }

      const clinic = await ctx.runQuery(internal.nps.getClinicInternal, { clinicId });
      const patient = chat.patientId
        ? await ctx.runQuery(internal.nps.getPatientById, { patientId: chat.patientId })
        : null;
      const followUpMessage = await renderConfiguredReminderMessage(ctx, {
        clinicId,
        type: "googleReviewFollowUp",
        context: {
          patient: {
            name: patient?.name || chat.title || "paciente",
            phone: patient?.phone || chat.whatsappChatId.split("@")[0],
            email: patient?.email || "",
          },
          clinic: {
            name: clinic?.name || "",
            phone: clinic?.phone || "",
            address: clinic?.address || "",
            website: clinic?.website || "",
          },
          nps: {
            googleMapsLink,
          },
        },
      });

      if (!followUpMessage) {
        console.warn(`[sendGoogleReviewFollowUp] Template disabled for clinic ${clinicId}`);
        return;
      }

      await ctx.runMutation(internalAny.whatsappQueries.sendMessageAction, {
        chatId,
        text: followUpMessage,
      });

      console.log(`[sendGoogleReviewFollowUp] Google review link queued for chat ${chatId}`);
    } catch (error) {
      console.error(`[sendGoogleReviewFollowUp] Failed to send Google review link:`, error);
    }
  },
});

export const sendDetractorAlert = internalAction({
  args: {
    clinicId: v.string(),
    patientId: v.id("patients"),
    appointmentId: v.id("appointments"),
    score: v.number(),
    feedback: v.string(),
  },
  handler: async (ctx, { clinicId, patientId, appointmentId, score, feedback }) => {
    try {
      // Get patient and appointment details
      const patient = await ctx.runQuery(internal.nps.getPatientById, { patientId });
      const appointment = await ctx.runQuery(internal.nps.getAppointmentById, { appointmentId });
      const clinic = await ctx.runQuery(internal.nps.getClinicInternal, { clinicId });

      if (!patient || !appointment || !clinic) {
        console.error(`[sendDetractorAlert] Patient or appointment not found`);
        return;
      }

      // Find admin user for this clinic to send alert
      const admin = await ctx.runQuery(internal.nps.getAdminByClinicId, { clinicId });

      if (!admin) {
        console.error(`[sendDetractorAlert] No admin user found for clinic`);
        return;
      }

      if (!admin.phone) {
        console.warn(`[sendDetractorAlert] Admin ${admin.name} has no phone`);
        return;
      }

      const adminChatId = await getOrCreateChatId(ctx, {
        clinicId,
        phone: admin.phone,
        title: admin.name,
      });

      if (!adminChatId) {
        console.warn(`[sendDetractorAlert] No WhatsApp chat found for admin ${admin.name}`);
        return;
      }

      const alertMessage = await renderConfiguredReminderMessage(ctx, {
        clinicId,
        type: "detractorAlert",
        context: {
          patient: {
            name: patient.name,
            phone: patient.phone,
            email: patient.email,
          },
          clinic: {
            name: clinic.name,
            phone: clinic.phone || "",
            address: clinic.address || "",
            website: clinic.website || "",
          },
          appointment: {
            doctor: appointment.doctor || "",
            date: appointment.startAt
              ? new Date(appointment.startAt).toLocaleDateString("pt-BR")
              : "",
            time: appointment.startAt
              ? new Date(appointment.startAt).toLocaleTimeString("pt-BR", {
                  hour: "2-digit",
                  minute: "2-digit",
                })
              : "",
          },
          doctor: {
            name: appointment.doctor || "",
          },
          nps: {
            score,
            feedback,
          },
        },
      });

      if (!alertMessage) {
        console.warn(`[sendDetractorAlert] Template disabled for clinic ${clinicId}`);
        return;
      }

      await ctx.runMutation(internalAny.whatsappQueries.sendMessageAction, {
        chatId: adminChatId,
        text: alertMessage,
      });

      console.log(
        `[sendDetractorAlert] Alert sent to admin ${admin.name} for patient ${patient.name}`,
      );
    } catch (error) {
      console.error(`[sendDetractorAlert] Failed to send detractor alert:`, error);
    }
  },
});

export const cleanupOldSurveys = internalMutation({
  args: {},
  handler: async (ctx) => {
    const cutoffTime = Date.now() - 30 * 24 * 60 * 60 * 1000; // 30 days ago

    // Find appointments with NPS survey sent more than 30 days ago
    const oldAppointments = await ctx.db
      .query("appointments")
      .filter((q: any) =>
        q.and(q.lt(q.field("npsSurveySentAt"), cutoffTime), q.eq(q.field("status"), "completed")),
      )
      .take(100);

    for (const apt of oldAppointments) {
      // Clear npsSurveySentAt if no response exists
      const hasResponse = await ctx.db
        .query("npsResponses")
        .withIndex("by_appointment", (q: any) => q.eq("appointmentId", apt._id))
        .first();

      if (!hasResponse && apt.npsSurveySentAt) {
        await ctx.db.patch(apt._id, {
          npsSurveySentAt: undefined,
        });
      }
    }

    console.log(`[cleanupOldSurveys] Cleaned up ${oldAppointments.length} old NPS survey records`);
  },
});

// ==================== INTERNAL HELPERS FOR ACTIONS ====================

export const getChatById = internalQuery({
  args: {
    chatId: v.id("chats"),
  },
  handler: async (ctx, { chatId }) => {
    return await ctx.db.get(chatId);
  },
});

export const getPatientById = internalQuery({
  args: {
    patientId: v.id("patients"),
  },
  handler: async (ctx, { patientId }) => {
    return await ctx.db.get(patientId);
  },
});

export const getAppointmentById = internalQuery({
  args: {
    appointmentId: v.id("appointments"),
  },
  handler: async (ctx, { appointmentId }) => {
    return await ctx.db.get(appointmentId);
  },
});

export const getAdminByClinicId = internalQuery({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, { clinicId }) => {
    return await ctx.db
      .query("users")
      .withIndex("by_clinic_role", (q: any) => q.eq("clinicId", clinicId).eq("role", "admin"))
      .first();
  },
});

export const getChatByPhone = internalQuery({
  args: {
    phone: v.string(),
    clinicId: v.string(),
  },
  handler: async (ctx, { phone, clinicId }) => {
    return await ctx.db
      .query("chats")
      .withIndex("by_clinic_whatsappId", (q: any) =>
        q.eq("clinicId", clinicId).eq("whatsappChatId", `${phone}@c.us`),
      )
      .first();
  },
});

export const patchAppointment = internalMutation({
  args: {
    appointmentId: v.id("appointments"),
    updates: v.any(),
  },
  handler: async (ctx, { appointmentId, updates }) => {
    await ctx.db.patch(appointmentId, updates);
  },
});
