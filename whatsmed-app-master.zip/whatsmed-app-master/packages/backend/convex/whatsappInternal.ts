import { v } from "convex/values";

import { internal } from "./_generated/api";
import { internalMutation, internalQuery } from "./_generated/server";
import { getBrazilianPhoneVariations } from "./lib/phoneUtils";
import { checkConversationCredit } from "./lib/planEnforcement";

/**
 * Internal mutations for WhatsApp AI and document processing
 */

export const getMessage = internalQuery({
  args: { id: v.id("messages") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.id);
  },
});

/**
 * Update message with AI analysis (transcribed text or document data)
 */
export const updateMessageWithAiAnalysis = internalMutation({
  args: {
    messageId: v.id("messages"),
    aiAnalysis: v.optional(v.string()),
    analyzedAt: v.optional(v.number()),
    aiError: v.optional(v.string()),
    transcribedText: v.optional(v.string()),
    extractedData: v.optional(v.any()),
    extractedAt: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.messageId, {
      aiAnalysis: args.aiAnalysis,
      aiAnalyzedAt: args.analyzedAt,
      aiError: args.aiError,
      transcribedText: args.transcribedText,
      extractedData: args.extractedData,
      extractedAt: args.extractedAt,
    });
  },
});

/**
 * Update message with transcribed text
 */
export const updateMessageWithTranscription = internalMutation({
  args: {
    messageId: v.id("messages"),
    transcribedText: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.messageId, {
      transcribedText: args.transcribedText,
      transcriptionStatus: "completed",
      transcriptionError: undefined,
      transcriptionCompletedAt: Date.now(),
    });
  },
});

export const beginAudioTranscription = internalMutation({
  args: {
    messageId: v.id("messages"),
  },
  handler: async (ctx, args) => {
    const message = await ctx.db.get(args.messageId);
    if (!message) {
      return { shouldTranscribe: false, reason: "Message not found" as const };
    }

    if (message.mediaType !== "audio") {
      return { shouldTranscribe: false, reason: "Not an audio message" as const };
    }

    if (message.transcriptionStatus === "completed" && message.transcribedText) {
      return {
        shouldTranscribe: false,
        reason: "Already transcribed" as const,
        transcribedText: message.transcribedText,
      };
    }

    if (!message.mediaStorageId) {
      await ctx.db.patch(args.messageId, {
        transcriptionStatus: "failed",
        transcriptionError: "Audio file unavailable for transcription",
        transcriptionCompletedAt: Date.now(),
      });
      return { shouldTranscribe: false, reason: "Audio file unavailable" as const };
    }

    const now = Date.now();
    if (
      message.transcriptionStatus === "processing" &&
      message.transcriptionStartedAt &&
      now - message.transcriptionStartedAt < 2 * 60 * 1000
    ) {
      return {
        shouldTranscribe: false,
        reason: "Transcription already in progress" as const,
      };
    }

    await ctx.db.patch(args.messageId, {
      transcriptionStatus: "processing",
      transcriptionError: undefined,
      transcriptionStartedAt: now,
      transcriptionCompletedAt: undefined,
    });

    return {
      shouldTranscribe: true,
      mediaStorageId: message.mediaStorageId,
    };
  },
});

export const finishAudioTranscription = internalMutation({
  args: {
    messageId: v.id("messages"),
    status: v.union(v.literal("completed"), v.literal("failed")),
    transcribedText: v.optional(v.string()),
    error: v.optional(v.string()),
    language: v.optional(v.string()),
    duration: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    await ctx.db.patch(args.messageId, {
      transcriptionStatus: args.status,
      transcribedText: args.status === "completed" ? args.transcribedText : undefined,
      transcriptionError: args.status === "failed" ? args.error : undefined,
      transcriptionLanguage: args.status === "completed" ? args.language : undefined,
      transcriptionDuration: args.status === "completed" ? args.duration : undefined,
      transcriptionCompletedAt: now,
      updatedAt: now,
    });
  },
});

export const handleIncomingMessage = internalMutation({
  args: {
    instanceName: v.string(),
    payload: v.any(),
    provider: v.optional(v.union(v.literal("evolution"), v.literal("meta"))),
  },
  handler: async (ctx, args) => {
    const { instanceName, payload, provider } = args;

    // 1. Find clinic by instance name
    const instance = await ctx.db
      .query("whatsappInstances")
      .withIndex("by_instanceName", (q) => q.eq("instanceName", instanceName))
      .first();

    if (!instance) {
      console.warn(`[handleIncomingMessage] Instance not found: ${instanceName}`);
      return;
    }

    const clinicId = instance.clinicId;
    const remoteJid = payload.key?.remoteJid;
    const fromMe = payload.key?.fromMe;

    // Ignore status updates
    if (remoteJid === "status@broadcast") return;

    // Determine message type and body
    const messageData = payload.message || {};
    const contextInfo =
      messageData.extendedTextMessage?.contextInfo ||
      messageData.imageMessage?.contextInfo ||
      messageData.videoMessage?.contextInfo ||
      messageData.documentMessage?.contextInfo ||
      undefined;
    const text =
      messageData.conversation ||
      messageData.extendedTextMessage?.text ||
      payload.mediaInfo?.caption ||
      messageData.imageMessage?.caption ||
      messageData.videoMessage?.caption ||
      messageData.documentMessage?.caption ||
      "";

    const type = messageData.imageMessage
      ? "media"
      : messageData.videoMessage
        ? "media"
        : messageData.audioMessage
          ? "media"
          : messageData.documentMessage
            ? "media"
            : messageData.stickerMessage
              ? "media"
              : payload.mediaInfo || payload.mediaStorageId
                ? "media"
                : "text";

    const replyToMessageId = contextInfo?.stanzaId;
    const replyToText =
      contextInfo?.quotedMessage?.conversation ||
      contextInfo?.quotedMessage?.extendedTextMessage?.text;
    const replyToSender = contextInfo?.participant;
    let replyToId;

    if (replyToMessageId) {
      const repliedMessage = await ctx.db
        .query("messages")
        .withIndex("by_clinic_whatsappId", (q) =>
          q.eq("clinicId", clinicId).eq("whatsappMessageId", replyToMessageId),
        )
        .first();
      replyToId = repliedMessage?._id;
    }

    // 2. Find or create chat
    // Use fuzzy phone matching to find if this patient already exists with a different number variation
    const phone = remoteJid.split("@")[0];
    const phoneVariations = getBrazilianPhoneVariations(phone);

    // Try to find an existing chat with any of the phone variations
    let chat = null;
    for (const p of phoneVariations) {
      const c = await ctx.db
        .query("chats")
        .withIndex("by_clinic_whatsappId", (q) =>
          q.eq("clinicId", clinicId).eq("whatsappChatId", `${p}@s.whatsapp.net`),
        )
        .first();
      if (c) {
        chat = c;
        break;
      }
    }

    // If chat found but with different ID (e.g. found 8-digit chat but incoming is 9-digit),
    // we should ideally merge or stick to the existing one.
    // However, the remoteJid is the primary key for the chat in WhatsApp.
    // If we receive a message from a NEW remoteJid that matches an OLD chat's normalized phone,
    // we might want to treat it as the same chat?
    // But WhatsApp treats them as distinct chats if the JID is different.
    // The user requirement "treating them differently" implies they want them LINKED to the same patient.

    if (!chat) {
      // Check credit availability before creating new chat
      const creditCheck = await checkConversationCredit(ctx, clinicId);

      // Create new chat (always create, but mark as locked if no credits)
      const chatId = await ctx.db.insert("chats", {
        clinicId,
        whatsappChatId: remoteJid,
        unreadCount: 0,
        status: creditCheck.hasCredit ? "open" : "locked",
        lockedReason: creditCheck.hasCredit ? undefined : "no_credits",
        isAiActive: creditCheck.hasCredit,
        needsHumanReview: false,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        title: payload.pushName || phone,
      });
      chat = await ctx.db.get(chatId);

      // Consume credit if available
      if (creditCheck.hasCredit && chat) {
        await ctx.runMutation(internal.conversationCredits.consumeCredit, {
          clinicId,
        });
      }
    }

    if (!chat) return; // Should not happen

    // 3. Check for duplicate message (idempotency by whatsappMessageId)
    const whatsappMessageId = payload.key?.id;
    let messageId: any;
    let isDuplicate = false;
    let mediaWasUpdated = false;

    if (whatsappMessageId) {
      const existingMessages = await ctx.db
        .query("messages")
        .withIndex("by_clinic_whatsappId", (q) =>
          q.eq("clinicId", clinicId).eq("whatsappMessageId", whatsappMessageId),
        )
        .collect();

      if (existingMessages.length > 0) {
        const existingMessage = [...existingMessages].sort((a, b) => {
          const aScore = a.mediaStorageId ? 1 : 0;
          const bScore = b.mediaStorageId ? 1 : 0;
          if (aScore !== bScore) return bScore - aScore;
          return (a.createdAt ?? 0) - (b.createdAt ?? 0);
        })[0];

        isDuplicate = true;
        messageId = existingMessage!._id;

        const hasIncomingCaption = typeof text === "string" && text.trim().length > 0;
        const hasStoredBody =
          typeof existingMessage!.body === "string" && existingMessage!.body.trim().length > 0;

        // If we have new media but existing message doesn't, update it
        if (payload.mediaStorageId && !existingMessage!.mediaStorageId) {
          const isAudio = payload.mediaInfo?.type === "audio";
          await ctx.db.patch(existingMessage!._id, {
            mediaStorageId: payload.mediaStorageId,
            mediaStatus: "ready",
            mediaType: payload.mediaInfo?.type,
            mediaMimetype: payload.mediaInfo?.mimetype,
            mediaFileName: payload.mediaInfo?.fileName,
            transcriptionStatus: isAudio ? "pending" : existingMessage!.transcriptionStatus,
            transcriptionError: isAudio ? undefined : existingMessage!.transcriptionError,
            body: hasStoredBody
              ? existingMessage!.body
              : hasIncomingCaption
                ? text
                : existingMessage!.body,
          });
          mediaWasUpdated = true;
          console.log(`[handleIncomingMessage] Updated existing message ${messageId} with media`);
        } else {
          if (hasIncomingCaption && !hasStoredBody) {
            await ctx.db.patch(existingMessage!._id, {
              body: text,
            });
          }
          console.log(
            `[handleIncomingMessage] Duplicate message ${whatsappMessageId} detected, skipping creation`,
          );
        }
      }
    }

    // Only create new message if not a duplicate
    if (!isDuplicate) {
      const isAudio = payload.mediaInfo?.type === "audio";
      const hasAudioStorage = isAudio && !!payload.mediaStorageId;
      messageId = await ctx.db.insert("messages", {
        clinicId,
        chatId: chat._id,
        direction: fromMe ? "out" : "in",
        type: type as "text" | "media",
        body: text,
        status: "delivered", // Incoming messages are effectively delivered/received
        sentAt: Date.now(),
        createdAt: Date.now(),
        whatsappMessageId: whatsappMessageId,
        mediaType: payload.mediaInfo?.type,
        mediaMimetype: payload.mediaInfo?.mimetype,
        mediaFileName: payload.mediaInfo?.fileName,
        mediaStorageId: payload.mediaStorageId, // Save storage ID
        mediaStatus: payload.mediaStorageId ? "ready" : undefined, // Mark as ready if stored
        transcriptionStatus: isAudio ? (hasAudioStorage ? "pending" : "failed") : undefined,
        transcriptionError:
          isAudio && !hasAudioStorage ? "Audio file unavailable for transcription" : undefined,
        provider: provider || "evolution",
        replyToMessageId,
        replyToText,
        replyToSender,
        replyToId,
      } as any);

      // Best-effort dedupe hardening against concurrent webhook deliveries.
      // If another worker inserted the same WhatsApp message concurrently, keep one canonical record.
      if (whatsappMessageId) {
        const sameMessages = await ctx.db
          .query("messages")
          .withIndex("by_clinic_whatsappId", (q) =>
            q.eq("clinicId", clinicId).eq("whatsappMessageId", whatsappMessageId),
          )
          .collect();

        if (sameMessages.length > 1) {
          const canonical = [...sameMessages].sort((a, b) => {
            const aScore = a.mediaStorageId ? 1 : 0;
            const bScore = b.mediaStorageId ? 1 : 0;
            if (aScore !== bScore) return bScore - aScore;
            return (a.createdAt ?? 0) - (b.createdAt ?? 0);
          })[0];

          if (canonical && canonical._id !== messageId) {
            const insertedMessage = sameMessages.find((m) => m._id === messageId);

            if (insertedMessage?.mediaStorageId && !canonical.mediaStorageId) {
              await ctx.db.patch(canonical._id, {
                mediaStorageId: insertedMessage.mediaStorageId,
                mediaStatus: insertedMessage.mediaStatus,
                mediaType: insertedMessage.mediaType,
                mediaMimetype: insertedMessage.mediaMimetype,
                mediaFileName: insertedMessage.mediaFileName,
                body: canonical.body || insertedMessage.body,
              });
              mediaWasUpdated = true;
            }

            await ctx.db.delete(messageId);
            messageId = canonical._id;
            isDuplicate = true;
          }
        }
      }
    }

    // 5. Try to link patient if not linked (Move step 5 before step 4 to use patient name in title)
    let patientId = chat.patientId;
    let patientName = null;

    if (!patientId) {
      // Try to find patient by phone variations
      for (const p of phoneVariations) {
        const patient = await ctx.db
          .query("patients")
          .withIndex("by_clinic_phone", (q) => q.eq("clinicId", clinicId).eq("phone", p))
          .first();

        if (patient) {
          patientId = patient._id;
          patientName = patient.name;
          await ctx.db.patch(chat._id, {
            patientId: patient._id,
          });
          break;
        }
      }

      // If still no patient found, create one
      if (!patientId) {
        // Use pushName or formatted phone as name
        const newPatientName = payload.pushName || `Cliente ${phone}`;

        patientId = await ctx.db.insert("patients", {
          clinicId,
          name: newPatientName,
          phone: phone, // Store the raw phone from the incoming message (normalized by split)
          status: "active",
          createdAt: Date.now(),
          updatedAt: Date.now(),
        });

        patientName = newPatientName;

        // Link chat to new patient
        await ctx.db.patch(chat._id, {
          patientId: patientId,
        });

        console.log(`[handleIncomingMessage] Auto-created patient ${patientId} for phone ${phone}`);
      }
    } else {
      const patient = await ctx.db.get(patientId);
      patientName = patient?.name;
    }

    // Link message to patient if found
    if (patientId) {
      await ctx.db.patch(messageId, {
        patientId: patientId,
      });
    }

    // 4. Update chat
    // Determine title:
    // 1. If patient is linked, use patient name (Manual override from Patients tab)
    // 2. If no patient, and chat has a title (that isn't just the number), keep it
    // 3. Use pushName if available
    // 4. Fallback to phone number

    let newTitle = chat.title;

    if (patientName) {
      // If linked to a patient, force the title to match patient name
      // This satisfies "if a name has manually been set in the patients tab, do not override it"
      // assuming the Patient entity is the source of truth for "manual name"
      newTitle = patientName;
    } else if (payload.pushName && (!chat.title || chat.title === phone)) {
      // Only update from pushName if we don't have a patient AND current title is empty/generic
      newTitle = payload.pushName;
    }

    await ctx.db.patch(chat._id, {
      lastMessage: text || (type === "media" ? "📎 Mídia" : ""),
      lastMessageAt: Date.now(),
      lastActivityAt: Date.now(),
      unreadCount: fromMe ? chat.unreadCount : chat.unreadCount + 1,
      updatedAt: Date.now(),
      title: newTitle,
    });

    // Log AI active status for debugging
    console.warn(
      `[handleIncomingMessage] Chat ${chat._id} (${chat.whatsappChatId}) - isAiActive: ${chat.isAiActive}`,
    );

    return {
      messageId,
      chatId: chat._id,
      clinicId,
      patientId,
      isAiActive: chat.status === "open" && chat.isAiActive !== false,
      isDuplicate,
      mediaWasUpdated,
      isFromMe: fromMe === true,
    };
  },
});

export const getLastMessageId = internalQuery({
  args: {
    instanceName: v.string(),
  },
  handler: async (ctx, args) => {
    const instance = await ctx.db
      .query("whatsappInstances")
      .withIndex("by_instanceName", (q) => q.eq("instanceName", args.instanceName))
      .first();

    if (!instance) return null;

    // Find the latest message for this clinic (proxy for instance)
    // This is a bit loose, ideally we'd track message ID from the insertion above
    // But since this is called right after handleIncomingMessage in the webhook,
    // we should try to return the most recent incoming message for this clinic

    const message = await ctx.db
      .query("messages")
      .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", instance.clinicId))
      .filter((q) => q.eq(q.field("isInternal"), undefined))
      .order("desc")
      .first();

    return message?._id;
  },
});
