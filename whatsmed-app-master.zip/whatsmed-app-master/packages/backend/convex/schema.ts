import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

// ============================================================================
// Schema Definitions
// ============================================================================

export default defineSchema({
  flows: defineTable({
    clinicId: v.string(), // Multi-tenant isolation
    name: v.string(), // Flow name
    description: v.optional(v.string()), // Flow description
    status: v.union(v.literal("draft"), v.literal("active"), v.literal("archived")), // Flow status
    activeVersionId: v.optional(v.id("flowVersions")), // Points to currently active version
    createdBy: v.string(), // userId who created flow
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic", ["clinicId"])
    .index("by_clinic_status", ["clinicId", "status"])
    .index("by_clinic_createdAt", ["clinicId", "createdAt"]),

  flowVersions: defineTable({
    clinicId: v.string(), // Multi-tenant isolation
    flowId: v.id("flows"), // Reference to parent flow
    versionNumber: v.number(), // Sequential: 1, 2, 3...
    nodes: v.array(
      v.object({
        id: v.string(),
        type: v.string(),
        data: v.any(),
        position: v.object({
          x: v.number(),
          y: v.number(),
        }),
      }),
    ), // Nodes stored inline
    connections: v.array(
      v.object({
        id: v.string(),
        source: v.string(),
        target: v.string(),
        sourceHandle: v.optional(v.string()),
        targetHandle: v.optional(v.string()),
      }),
    ), // React Flow compatible format
    variables: v.array(
      v.object({
        name: v.string(),
        type: v.union(v.literal("string"), v.literal("number"), v.literal("boolean")),
        defaultValue: v.optional(v.any()),
        description: v.optional(v.string()),
      }),
    ), // Flow-level variable definitions
    createdBy: v.string(), // userId who created this version
    createdAt: v.number(),
    // NO updatedAt field - versions are immutable (read-only once created)
  })
    .index("by_flow", ["flowId"])
    .index("by_flow_version", ["flowId", "versionNumber"])
    .index("by_clinic", ["clinicId"])
    .index("by_clinic_createdAt", ["clinicId", "createdAt"]),

  flowExecutions: defineTable({
    clinicId: v.string(), // Multi-tenant isolation
    flowId: v.id("flows"), // Reference to parent flow
    flowVersionId: v.id("flowVersions"), // Pinned version - THIS version started the execution
    chatId: v.optional(v.id("chats")), // Associated WhatsApp conversation, if exists
    patientId: v.optional(v.id("patients")), // Associated patient, if exists
    currentNodeId: v.optional(v.string()), // Current execution state
    nodeContext: v.optional(
      v.object({
        variables: v.record(v.string(), v.any()),
        history: v.array(
          v.object({
            nodeId: v.string(),
            timestamp: v.number(),
            result: v.optional(v.any()),
          }),
        ),
      }),
    ), // Execution context with variable values
    status: v.union(
      v.literal("in_progress"),
      v.literal("completed"),
      v.literal("cancelled"),
      v.literal("error"),
    ),
    startedAt: v.number(),
    completedAt: v.optional(v.number()),
    errorMessage: v.optional(v.string()),
  })
    .index("by_flow_version", ["flowVersionId"])
    .index("by_chat", ["chatId"])
    .index("by_clinic", ["clinicId"])
    .index("by_clinic_status", ["clinicId", "status"])
    .index("by_clinic_startedAt", ["clinicId", "startedAt"]),
  flowWaitStates: defineTable({
    clinicId: v.string(), // Multi-tenant isolation
    flowId: v.id("flows"), // Reference to parent flow
    chatId: v.id("chats"), // Associated WhatsApp conversation
    nodeId: v.string(), // Node that triggered the wait
    duration: v.number(), // Wait duration
    unit: v.union(
      v.literal("seconds"),
      v.literal("minutes"),
      v.literal("hours"),
      v.literal("days"),
    ), // Time unit
    timeoutAction: v.union(v.literal("resume"), v.literal("escalate")), // Action on timeout
    resumeCondition: v.optional(v.string()), // Optional condition to resume early
    status: v.union(
      v.literal("waiting"),
      v.literal("expired"),
      v.literal("cancelled"),
      v.literal("resumed"),
    ), // Wait status
    startedAt: v.number(), // When wait was started
    expiresAt: v.number(), // When wait will expire
    processedAt: v.optional(v.number()), // When wait was processed (expired/resumed/cancelled)
  })
    .index("by_chat_status", ["chatId", "status"])
    .index("by_flow_node", ["flowId", "nodeId"])
    .index("by_expiresAt", ["expiresAt"])
    .index("by_clinic", ["clinicId"]),

  clinics: defineTable({
    clinicId: v.string(), // External/legacy ID
    name: v.string(),
    cpfCnpj: v.optional(v.string()),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    address: v.optional(v.string()),
    website: v.optional(v.string()),
    logoUrl: v.optional(v.string()),
    // Subscription/Plan fields
    plan: v.optional(
      v.union(
        v.literal("free"),
        v.literal("starter"),
        v.literal("professional"),
        v.literal("enterprise"),
      ),
    ),
    planStatus: v.optional(
      v.union(
        v.literal("active"),
        v.literal("past_due"),
        v.literal("canceled"),
        v.literal("trialing"),
      ),
    ),
    asaasSubscriptionId: v.optional(v.string()),
    planValue: v.optional(v.number()),
    planNextDueDate: v.optional(v.string()),
    planCycle: v.optional(v.string()),
    // Conversation credits tracking
    conversationCreditsUsed: v.optional(v.number()), // Credits used in current billing cycle
    conversationCreditsPurchased: v.optional(v.number()), // Purchased credits pool (never expires)
    billingCycleStart: v.optional(v.number()), // Timestamp of current cycle start
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  }).index("by_clinicId", ["clinicId"]),

  clinicSettings: defineTable({
    clinicId: v.id("clinics"), // Reference to clinic (unique)
    defaultFlowId: v.optional(v.id("flows")), // Default active flow for all conversations
    prependAttendantNameOnManualMessages: v.optional(v.boolean()),
  }).index("by_clinic", ["clinicId"]),

  rateLimits: defineTable({
    key: v.string(),
    count: v.number(),
    windowStart: v.number(),
    clinicId: v.string(),
    createdAt: v.number(),
  })
    .index("by_clinic_key", ["clinicId", "key"])
    .index("by_clinic_window", ["clinicId", "windowStart"]),

  clinicMembers: defineTable({
    clinicId: v.string(),
    userId: v.string(), // authUserId
    role: v.string(),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic", ["clinicId"])
    .index("by_user_clinic", ["userId", "clinicId"]),

  userClinics: defineTable({
    userId: v.string(), // authUserId
    clinics: v.array(
      v.object({
        clinicId: v.string(),
        role: v.string(),
      }),
    ),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  }).index("by_user", ["userId"]),

  invites: defineTable({
    email: v.string(),
    clinicId: v.string(),
    role: v.string(),
    token: v.string(),
    expiresAt: v.number(),
    invitedBy: v.string(), // authUserId of inviter
    status: v.union(v.literal("pending"), v.literal("accepted"), v.literal("expired")),
    createdAt: v.number(),
    acceptedAt: v.optional(v.number()),
  })
    .index("by_token", ["token"])
    .index("by_email", ["email"])
    .index("by_clinic", ["clinicId"]),

  users: defineTable({
    authUserId: v.string(),
    email: v.string(),
    name: v.string(),
    role: v.union(
      v.literal("admin"),
      v.literal("staff"),
      v.literal("viewer"),
      v.literal("doctor"),
      v.literal("super_admin"),
    ),
    clinicId: v.string(),
    phone: v.optional(v.string()),
    isActive: v.boolean(),
    lastLoginAt: v.optional(v.number()),
    createdAt: v.number(),
    deletedAt: v.optional(v.number()),
    workingHours: v.optional(
      v.array(
        v.object({
          dayOfWeek: v.number(),
          slots: v.array(
            v.object({
              start: v.string(),
              end: v.string(),
              types: v.array(v.string()),
            }),
          ),
        }),
      ),
    ),
    specialties: v.optional(v.array(v.string())),
  })
    .index("by_authUserId", ["authUserId"])
    .index("by_email", ["email"])
    .index("by_clinic", ["clinicId"])
    .index("by_clinic_role", ["clinicId", "role"])
    .index("by_clinic_email", ["clinicId", "email"])
    .index("by_clinic_phone", ["clinicId", "phone"])
    .index("by_clinic_createdAt", ["clinicId", "createdAt"])
    .index("by_clinic_role_name", ["clinicId", "role", "name"]),

  auditLogs: defineTable({
    action: v.string(),
    clinicId: v.string(),
    userId: v.optional(v.string()),
    email: v.optional(v.string()),
    userAgent: v.optional(v.string()),
    metadata: v.optional(v.any()),
    createdAt: v.number(),
  })
    .index("by_clinic_createdAt", ["clinicId", "createdAt"])
    .index("by_action_createdAt", ["action", "createdAt"])
    .index("by_user_createdAt", ["userId", "createdAt"]),

  patients: defineTable({
    clinicId: v.string(),
    name: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    cpf: v.optional(v.string()),
    dateOfBirth: v.optional(v.number()),
    gender: v.optional(v.union(v.literal("male"), v.literal("female"), v.literal("other"))),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    state: v.optional(v.string()),
    zip: v.optional(v.string()),
    country: v.optional(v.string()),
    status: v.union(v.literal("active"), v.literal("inactive")),
    tags: v.optional(v.array(v.string())),
    notes: v.optional(v.string()),
    externalId: v.optional(v.string()),
    avatarUrl: v.optional(v.string()),
    // Payment and insurance info
    paymentType: v.optional(v.union(v.literal("insurance"), v.literal("private"))),
    insurance: v.optional(v.string()), // Insurance company name (e.g., "Unimed", "Bradesco")
    // Image storage fields - Insurance Card (front/back)
    insuranceCardFrontStorageId: v.optional(v.id("_storage")),
    insuranceCardFrontUrl: v.optional(v.string()),
    insuranceCardFrontUploadedAt: v.optional(v.number()),
    insuranceCardBackStorageId: v.optional(v.id("_storage")),
    insuranceCardBackUrl: v.optional(v.string()),
    insuranceCardBackUploadedAt: v.optional(v.number()),
    // Legacy fields (kept for backward compatibility)
    insuranceCardStorageId: v.optional(v.id("_storage")),
    insuranceCardUrl: v.optional(v.string()),
    insuranceCardUploadedAt: v.optional(v.number()),
    // ID Card and Referral
    idCardStorageId: v.optional(v.id("_storage")),
    idCardUrl: v.optional(v.string()),
    idCardUploadedAt: v.optional(v.number()),
    referralStorageId: v.optional(v.id("_storage")),
    referralUrl: v.optional(v.string()),
    referralUploadedAt: v.optional(v.number()),
    // Kanban stage tracking
    remarketingStage: v.optional(
      v.union(
        v.literal("needs_contact"),
        v.literal("contacted"),
        v.literal("scheduled"),
        v.literal("not_interested"),
      ),
    ),
    leadStage: v.optional(
      v.union(
        v.literal("new_lead"),
        v.literal("contacted"),
        v.literal("scheduled"),
        v.literal("converted"),
      ),
    ),
    // Denormalized appointment summary for efficient Kanban queries
    lastCompletedAppointmentAt: v.optional(v.number()),
    nextScheduledAppointmentAt: v.optional(v.number()),
    hasCompletedAppointment: v.optional(v.boolean()),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
    deletedAt: v.optional(v.number()),
  })
    .index("by_clinic_createdAt", ["clinicId", "createdAt"])
    .index("by_clinic_email", ["clinicId", "email"])
    .index("by_clinic_phone", ["clinicId", "phone"])
    .index("by_clinic_status_createdAt", ["clinicId", "status", "createdAt"])
    .index("by_clinic_name", ["clinicId", "name"])
    .index("by_clinic_name_email_phone", ["clinicId", "name", "email", "phone"])
    // Kanban indexes
    .index("by_clinic_remarketingStage", ["clinicId", "remarketingStage"])
    .index("by_clinic_leadStage", ["clinicId", "leadStage"])
    .index("by_clinic_hasCompleted", ["clinicId", "hasCompletedAppointment"])
    .searchIndex("search_name", {
      searchField: "name",
      filterFields: ["clinicId"],
    }),

  appointments: defineTable({
    clinicId: v.string(),
    patientId: v.id("patients"),
    startAt: v.number(),
    endAt: v.number(),
    status: v.union(
      v.literal("pending"),
      v.literal("confirmed"),
      v.literal("cancelled"),
      v.literal("completed"),
      v.literal("arrived"),
    ),
    doctor: v.optional(v.string()),
    doctorId: v.optional(v.id("users")),
    procedure: v.optional(v.string()),
    procedureId: v.optional(v.id("procedures")),
    notes: v.optional(v.string()),
    reminderAt: v.optional(v.number()),
    // Telemedicine fields
    meetingLink: v.optional(v.string()),
    meetingId: v.optional(v.string()),
    calendarEventId: v.optional(v.string()),
    conferenceData: v.optional(v.any()),
    timeZone: v.optional(v.string()),
    patientEmail: v.optional(v.string()),
    doctorEmail: v.optional(v.string()),
    isTelemedicine: v.optional(v.boolean()),
    meetingError: v.optional(v.string()),
    meetingCreatedAt: v.optional(v.number()),
    // Reschedule and check-in fields
    rescheduleStatus: v.optional(
      v.union(v.literal("none"), v.literal("awaiting_response"), v.literal("rescheduled")),
    ),
    rescheduleOfferedSlots: v.optional(
      v.array(
        v.object({
          startAt: v.number(),
          endAt: v.number(),
        }),
      ),
    ),
    actualArrivalTime: v.optional(v.number()),
    // NPS tracking
    npsSentAt: v.optional(v.number()),
    npsSurveySentAt: v.optional(v.number()),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
    deletedAt: v.optional(v.number()),
  })
    .index("by_clinic_date", ["clinicId", "startAt"])
    .index("by_clinic_status_date", ["clinicId", "status", "startAt"])
    .index("by_clinic_patient_date", ["clinicId", "patientId", "startAt"])
    .index("by_clinic_createdAt", ["clinicId", "createdAt"])
    .index("by_clinic_doctor_date", ["clinicId", "doctorId", "startAt"])
    .index("by_clinic_doctor_start_end", ["clinicId", "doctorId", "startAt", "endAt"])
    .index("by_clinic_patient_start_end", ["clinicId", "patientId", "startAt", "endAt"]),

  chats: defineTable({
    clinicId: v.string(),
    patientId: v.optional(v.id("patients")),
    responsibleUserId: v.optional(v.id("users")),
    responsibleUserName: v.optional(v.string()),
    whatsappChatId: v.string(),
    title: v.optional(v.string()),
    unreadCount: v.number(),
    status: v.union(
      v.literal("open"),
      v.literal("resolved"),
      v.literal("locked"),
      v.literal("abandoned"),
    ),
    lockedReason: v.optional(v.string()),
    lastMessageAt: v.optional(v.number()),
    lastMessage: v.optional(v.string()),
    avatarUrl: v.optional(v.string()),
    online: v.optional(v.boolean()),
    isAiActive: v.optional(v.boolean()),
    needsHumanReview: v.optional(v.boolean()),
    tags: v.optional(v.array(v.string())),
    // Timeout tracking fields
    lastActivityAt: v.optional(v.number()), // Tracks last activity timestamp
    timeoutSentAt: v.optional(v.number()), // Tracks when nudge was sent
    abandonedAt: v.optional(v.number()), // Tracks when chat was abandoned
    // Escalation tracking fields
    lastEscalatedAt: v.optional(v.number()),
    escalationMessageId: v.optional(v.id("messages")),
    escalationReason: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic_whatsappId", ["clinicId", "whatsappChatId"])
    .index("by_clinic_status_updated", ["clinicId", "status", "updatedAt"])
    .index("by_clinic_lastMessageAt", ["clinicId", "lastMessageAt"])
    .index("by_clinic_createdAt", ["clinicId", "createdAt"])
    .index("by_clinic_lastActivity", ["clinicId", "lastActivityAt"]),

  messages: defineTable({
    clinicId: v.string(),
    chatId: v.id("chats"),
    direction: v.union(v.literal("in"), v.literal("out")),
    type: v.union(v.literal("text"), v.literal("media")),
    isInternal: v.optional(v.boolean()),
    internalRole: v.optional(
      v.union(v.literal("assistant"), v.literal("tool"), v.literal("system")),
    ),
    toolName: v.optional(v.string()),
    toolCallId: v.optional(v.string()),
    body: v.optional(v.string()),
    mediaIds: v.optional(v.array(v.string())),
    sentAt: v.number(),
    status: v.union(
      v.literal("sending"),
      v.literal("sent"),
      v.literal("delivered"),
      v.literal("read"),
      v.literal("failed"),
    ),
    authorUserId: v.optional(v.string()),
    whatsappMessageId: v.optional(v.string()),
    patientId: v.optional(v.id("patients")),
    appointmentId: v.optional(v.id("appointments")),
    reminderType: v.optional(
      v.union(
        v.literal("appointmentConfirmation"),
        v.literal("sevenDay"),
        v.literal("twentyFourHour"),
        v.literal("oneHour"),
        v.literal("postConsultation"),
        v.literal("noShowRecovery"),
      ),
    ),
    automationKind: v.optional(
      v.union(
        v.literal("confirmationRequest"),
        v.literal("appointmentReminder"),
        v.literal("rescheduleOptions"),
        v.literal("rescheduleConfirmation"),
        v.literal("confirmationReply"),
        v.literal("cancellationConfirmation"),
      ),
    ),
    // Reply context
    replyToMessageId: v.optional(v.string()), // WhatsApp ID of original message
    replyToText: v.optional(v.string()), // Quoted text
    replyToSender: v.optional(v.string()), // Who sent the original message
    replyToId: v.optional(v.id("messages")), // Internal ID if found
    // Media fields
    mediaStorageId: v.optional(v.id("_storage")),
    mediaType: v.optional(
      v.union(
        v.literal("audio"),
        v.literal("video"),
        v.literal("image"),
        v.literal("document"),
        v.literal("sticker"),
      ),
    ),
    mediaMimetype: v.optional(v.string()),
    mediaFileName: v.optional(v.string()),
    mediaStatus: v.optional(
      v.union(
        v.literal("pending"),
        v.literal("processing"),
        v.literal("ready"),
        v.literal("failed"),
      ),
    ),
    // AI Analysis fields
    aiAnalysis: v.optional(v.string()),
    aiAnalyzedAt: v.optional(v.number()),
    aiError: v.optional(v.string()),
    transcribedText: v.optional(v.string()),
    transcriptionStatus: v.optional(
      v.union(
        v.literal("pending"),
        v.literal("processing"),
        v.literal("completed"),
        v.literal("failed"),
      ),
    ),
    transcriptionError: v.optional(v.string()),
    transcriptionLanguage: v.optional(v.string()),
    transcriptionDuration: v.optional(v.number()),
    transcriptionStartedAt: v.optional(v.number()),
    transcriptionCompletedAt: v.optional(v.number()),
    extractedData: v.optional(v.any()),
    extractedAt: v.optional(v.number()),
    provider: v.optional(v.union(v.literal("evolution"), v.literal("meta"))),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic_chat_sent", ["clinicId", "chatId", "sentAt"])
    .index("by_clinic_sentAt", ["clinicId", "sentAt"])
    .index("by_clinic_createdAt", ["clinicId", "createdAt"])
    .index("by_clinic_whatsappId", ["clinicId", "whatsappMessageId"])
    .index("by_clinic_chat_sent_filtered", ["clinicId", "chatId", "sentAt", "status"]),

  wallets: defineTable({
    clinicId: v.string(),
    balance: v.number(),
    currency: v.string(),
    autoRechargeEnabled: v.boolean(),
    autoRechargeThreshold: v.optional(v.number()),
    autoRechargeAmount: v.optional(v.number()),
    providerCustomerId: v.optional(v.string()),
    asaasCustomerId: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic", ["clinicId"])
    .index("by_clinic_createdAt", ["clinicId", "createdAt"]),

  transactions: defineTable({
    clinicId: v.string(),
    walletId: v.id("wallets"),
    type: v.union(v.literal("topup"), v.literal("debit"), v.literal("refund")),
    amount: v.number(),
    currency: v.string(),
    providerRef: v.optional(v.string()),
    asaasPaymentId: v.optional(v.string()),
    status: v.union(v.literal("pending"), v.literal("succeeded"), v.literal("failed")),
    reason: v.optional(v.string()),
    meta: v.optional(v.any()),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic_createdAt", ["clinicId", "createdAt"])
    .index("by_clinic_type_createdAt", ["clinicId", "type", "createdAt"])
    .index("by_clinic_status_createdAt", ["clinicId", "status", "createdAt"])
    .index("by_asaas_payment_id", ["asaasPaymentId"])
    .index("by_wallet_createdAt", ["walletId", "createdAt"]),

  paymentMethods: defineTable({
    clinicId: v.string(),
    walletId: v.id("wallets"),
    brand: v.string(),
    last4: v.string(),
    expMonth: v.number(),
    expYear: v.number(),
    holder: v.optional(v.string()),
    fingerprint: v.string(),
    providerPaymentMethodId: v.string(),
    asaasCardToken: v.optional(v.string()),
    isDefault: v.boolean(),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic_fingerprint", ["clinicId", "fingerprint"])
    .index("by_clinic_default", ["clinicId", "isDefault"])
    .index("by_wallet_createdAt", ["walletId", "createdAt"])
    .index("by_clinic_createdAt", ["clinicId", "createdAt"]),

  subscriptions: defineTable({
    clinicId: v.string(),
    asaasSubscriptionId: v.string(),
    asaasCustomerId: v.string(),
    status: v.string(),
    billingType: v.string(),
    value: v.number(),
    nextDueDate: v.string(),
    cycle: v.string(),
    description: v.optional(v.string()),
    creditCard: v.optional(
      v.object({
        brand: v.string(),
        last4: v.string(),
      }),
    ),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic", ["clinicId"])
    .index("by_asaas_id", ["asaasSubscriptionId"]),

  apiKeys: defineTable({
    clinicId: v.string(),
    name: v.string(),
    prefix: v.string(),
    hashedSecret: v.string(),
    lastUsedAt: v.optional(v.number()),
    scopes: v.optional(v.array(v.string())),
    rotatedAt: v.optional(v.number()),
    revokedAt: v.optional(v.number()),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic_prefix", ["clinicId", "prefix"])
    .index("by_clinic_lastUsed", ["clinicId", "lastUsedAt"])
    .index("by_clinic_createdAt", ["clinicId", "createdAt"]),

  webhookEvents: defineTable({
    clinicId: v.string(),
    eventType: v.string(),
    payload: v.any(),
    status: v.union(v.literal("pending"), v.literal("delivered"), v.literal("failed")),
    endpointUrl: v.string(),
    signature: v.optional(v.string()),
    attempts: v.number(),
    lastAttemptAt: v.optional(v.number()),
    nextAttemptAt: v.optional(v.number()),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic_status_createdAt", ["clinicId", "status", "createdAt"])
    .index("by_clinic_eventType_createdAt", ["clinicId", "eventType", "createdAt"]),

  uploads: defineTable({
    clinicId: v.string(),
    url: v.string(),
    filename: v.string(),
    size: v.number(),
    mimeType: v.string(),
    checksum: v.optional(v.string()),
    linkedResource: v.optional(
      v.object({
        type: v.string(),
        id: v.string(),
      }),
    ),
    providerKey: v.optional(v.string()),
    storageId: v.id("_storage"),
    expiresAt: v.number(),
    downloads: v.number(),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic_createdAt", ["clinicId", "createdAt"])
    .index("by_clinic_checksum", ["clinicId", "checksum"])
    .index("by_clinic_expiresAt", ["clinicId", "expiresAt"]),

  oauthStates: defineTable({
    state: v.string(),
    clinicId: v.string(),
    userId: v.id("users"),
    expiresAt: v.number(),
    consumedAt: v.optional(v.number()),
    createdAt: v.number(),
  })
    .index("by_state", ["state"])
    .index("by_expiresAt", ["expiresAt"]),

  googleOAuthTokens: defineTable({
    clinicId: v.string(),
    userId: v.id("users"),
    accessToken: v.string(), // Encrypted in production
    refreshToken: v.optional(v.string()), // Encrypted in production
    expiresAt: v.optional(v.number()),
    scope: v.optional(v.string()),
    tokenType: v.optional(v.string()),
    primaryCalendarId: v.optional(v.string()),
    blockedCalendarIds: v.optional(v.array(v.string())),
    lastSyncAt: v.optional(v.number()),
    syncToken: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic", ["clinicId"])
    .index("by_clinic_user", ["clinicId", "userId"]),

  externalEvents: defineTable({
    clinicId: v.string(),
    userId: v.id("users"),
    externalId: v.string(),
    calendarId: v.string(),
    title: v.optional(v.string()),
    startTime: v.number(),
    endTime: v.number(),
    isAllDay: v.boolean(),
    transparent: v.boolean(),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_user_time", ["userId", "startTime"])
    .index("by_user_externalId", ["userId", "externalId"]),

  whatsappInstances: defineTable({
    clinicId: v.string(),
    instanceName: v.string(),
    instanceId: v.optional(v.string()),
    apikey: v.optional(v.string()),
    status: v.union(v.literal("disconnected"), v.literal("connecting"), v.literal("connected")),
    qrcode: v.optional(v.string()),
    phoneNumber: v.optional(v.string()),
    webhookConfigured: v.boolean(),
    groupsIgnore: v.optional(v.boolean()),
    // Dual API Support
    provider: v.optional(v.union(v.literal("evolution"), v.literal("meta"))),
    metaPhoneNumberId: v.optional(v.string()),
    metaWabaId: v.optional(v.string()),
    metaAccessToken: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic", ["clinicId"])
    .index("by_instanceName", ["instanceName"]),

  waitlists: defineTable({
    clinicId: v.string(),
    patientId: v.id("patients"),
    requestedAt: v.number(),
    priority: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    status: v.union(v.literal("waiting"), v.literal("notified"), v.literal("assigned")),
    appointmentId: v.optional(v.id("appointments")),
    notifiedAt: v.optional(v.number()),
    notes: v.optional(v.string()),
    doctorId: v.optional(v.id("users")),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic_status", ["clinicId", "status"])
    .index("by_clinic_requestedAt", ["clinicId", "requestedAt"])
    .index("by_patient", ["patientId"])
    .index("by_clinic_appointment", ["clinicId", "appointmentId"]),

  analyticsData: defineTable({
    clinicId: v.string(),
    metricType: v.union(
      v.literal("funnel_step"),
      v.literal("confirmation_rate"),
      v.literal("cancellation_rate"),
      v.literal("manual_interventions"),
    ),
    value: v.number(),
    periodStart: v.number(),
    periodEnd: v.number(),
    metadata: v.optional(v.any()),
    createdAt: v.number(),
  })
    .index("by_clinic_type_period", ["clinicId", "metricType", "periodStart"])
    .index("by_clinic_date", ["clinicId", "createdAt"]),

  campaigns: defineTable({
    clinicId: v.string(),
    name: v.string(),
    status: v.union(v.literal("active"), v.literal("paused"), v.literal("draft")),
    triggerType: v.union(
      v.literal("time_after_appointment"),
      v.literal("time_after_procedure"),
      v.literal("birthday"),
      v.literal("no_show"),
      v.literal("custom"),
    ),
    triggerDelayHours: v.optional(v.number()),
    steps: v.array(
      v.object({
        order: v.number(),
        delayHours: v.number(),
        channel: v.union(
          v.literal("whatsapp"),
          v.literal("sms"),
          v.literal("email"),
          v.literal("call"),
        ),
        message: v.string(),
      }),
    ),
    triggerCount: v.number(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_clinic_status", ["clinicId", "status"])
    .index("by_clinic_createdAt", ["clinicId", "createdAt"]),

  campaignExecutions: defineTable({
    campaignId: v.id("campaigns"),
    clinicId: v.string(),
    patientId: v.id("patients"),
    appointmentId: v.optional(v.id("appointments")),
    stepOrder: v.number(),
    channel: v.string(),
    sentAt: v.number(),
    status: v.string(),
  })
    .index("by_campaign_patient", ["campaignId", "patientId"])
    .index("by_campaign_appointment", ["campaignId", "appointmentId"])
    .index("by_clinic_sentAt", ["clinicId", "sentAt"]),

  aiSettings: defineTable({
    clinicId: v.string(),
    enabled: v.boolean(),
    systemPrompt: v.optional(v.string()), // Deprecated: now using default prompts based on tone
    tone: v.union(
      v.literal("empathetic"),
      v.literal("formal"),
      v.literal("casual"),
      v.literal("direct"),
    ),
    temperature: v.optional(v.number()), // Deprecated: using fixed value
    escalationEnabled: v.optional(v.boolean()), // Deprecated: now using escalationTopics
    escalationKeywords: v.optional(v.array(v.string())), // Deprecated: migrated to escalationTopics.customKeywords
    activeHoursStart: v.string(),
    activeHoursEnd: v.string(),
    is247: v.optional(v.boolean()),
    voiceNotesEnabled: v.boolean(),
    responseDelaySeconds: v.number(),
    // New structured escalation topics
    escalationTopics: v.optional(
      v.object({
        legal: v.boolean(),
        medicalEmergency: v.boolean(),
        complaints: v.boolean(),
        customKeywords: v.array(v.string()),
      }),
    ),
    // New tool access control
    enabledTools: v.optional(v.array(v.string())),
    // AI Flow integration
    useFlow: v.optional(v.boolean()),
    flowId: v.optional(v.id("flows")),
    // Active saved prompt for the scheduling/triage assistant
    activePromptId: v.optional(v.id("aiSystemPrompts")),
    // Resolved custom instructions appended to system prompt
    customInstructions: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.number(),
  }).index("by_clinic", ["clinicId"]),

  aiSystemPrompts: defineTable({
    clinicId: v.string(),
    name: v.string(),
    content: v.string(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_clinic", ["clinicId"])
    .index("by_clinic_updatedAt", ["clinicId", "updatedAt"]),

  reminderConfigs: defineTable({
    clinicId: v.string(),
    type: v.union(
      v.literal("appointmentConfirmation"),
      v.literal("sevenDay"),
      v.literal("twentyFourHour"),
      v.literal("oneHour"),
      v.literal("postConsultation"),
      v.literal("noShowRecovery"),
      v.literal("rescheduleOptions"),
      v.literal("rescheduleConfirmation"),
      v.literal("confirmationReply"),
      v.literal("cancellationConfirmation"),
      v.literal("googleReviewFollowUp"),
      v.literal("detractorAlert"),
    ),
    enabled: v.boolean(),
    message: v.string(),
    channels: v.array(
      v.union(v.literal("whatsapp"), v.literal("sms"), v.literal("email"), v.literal("call")),
    ),
    useOfficialApi: v.boolean(),
    delayMinutes: v.optional(v.number()),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_clinic_type", ["clinicId", "type"])
    .index("by_clinic_enabled", ["clinicId", "enabled"]),

  appointmentReminders: defineTable({
    clinicId: v.string(),
    appointmentId: v.id("appointments"),
    reminderType: v.union(
      v.literal("appointmentConfirmation"),
      v.literal("sevenDay"),
      v.literal("twentyFourHour"),
      v.literal("oneHour"),
      v.literal("postConsultation"),
      v.literal("noShowRecovery"),
    ),
    status: v.union(v.literal("sent"), v.literal("failed")),
    responseStatus: v.optional(
      v.union(
        v.literal("awaiting"),
        v.literal("confirmed"),
        v.literal("declined"),
        v.literal("reschedule_requested"),
        v.literal("cancelled"),
      ),
    ),
    responseMessageId: v.optional(v.id("messages")),
    respondedAt: v.optional(v.number()),
    channels: v.array(
      v.union(v.literal("whatsapp"), v.literal("sms"), v.literal("email"), v.literal("call")),
    ),
    sentAt: v.optional(v.number()),
    lastError: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_appointment_type", ["appointmentId", "reminderType"])
    .index("by_clinic_type_sentAt", ["clinicId", "reminderType", "sentAt"]),

  appointmentScheduledJobs: defineTable({
    clinicId: v.string(),
    appointmentId: v.id("appointments"),
    jobKind: v.union(
      v.literal("appointmentConfirmation"),
      v.literal("sevenDay"),
      v.literal("twentyFourHour"),
      v.literal("oneHour"),
      v.literal("rescheduleTimeout"),
    ),
    scheduledFor: v.number(),
    scheduledFunctionId: v.id("_scheduled_functions"),
    status: v.union(
      v.literal("scheduled"),
      v.literal("cancelled"),
      v.literal("executed"),
      v.literal("superseded"),
    ),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_appointment", ["appointmentId"])
    .index("by_appointment_jobKind", ["appointmentId", "jobKind"])
    .index("by_clinic_scheduledFor", ["clinicId", "scheduledFor"]),

  checkinSessions: defineTable({
    clinicId: v.string(),
    patientId: v.id("patients"),
    appointmentId: v.id("appointments"),
    token: v.string(),
    expiresAt: v.number(),
    status: v.union(v.literal("pending"), v.literal("in_progress"), v.literal("completed")),
    anamnesisData: v.optional(v.any()),
    consentData: v.optional(v.any()),
    checkedInAt: v.optional(v.number()),
    ipAddress: v.optional(v.string()),
    userAgent: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_token", ["token"])
    .index("by_clinic_status", ["clinicId", "status"])
    .index("by_patient_appointment", ["patientId", "appointmentId"]),

  patientDataUpdates: defineTable({
    clinicId: v.string(),
    patientId: v.id("patients"),
    field: v.string(),
    value: v.any(),
    source: v.union(v.literal("checkin"), v.literal("whatsapp"), v.literal("admin")),
    approved: v.optional(v.boolean()),
    approvedBy: v.optional(v.id("users")),
    approvedAt: v.optional(v.number()),
    checkinSessionId: v.optional(v.id("checkinSessions")),
    createdAt: v.number(),
  })
    .index("by_patient", ["patientId"])
    .index("by_clinic_approved", ["clinicId", "approved"])
    .index("by_checkinSession", ["checkinSessionId"]),

  consents: defineTable({
    clinicId: v.string(),
    patientId: v.id("patients"),
    appointmentId: v.optional(v.id("appointments")),
    consentType: v.union(
      v.literal("treatment"),
      v.literal("data_processing"),
      v.literal("privacy_policy"),
      v.literal("terms_of_service"),
    ),
    signedAt: v.number(),
    ipAddress: v.string(),
    userAgent: v.string(),
    signatureData: v.optional(v.string()),
    documentUrl: v.optional(v.id("_storage")),
    checkinSessionId: v.optional(v.id("checkinSessions")),
    createdAt: v.number(),
  })
    .index("by_patient_appointment", ["patientId", "appointmentId"])
    .index("by_appointment", ["appointmentId"])
    .index("by_clinic_createdAt", ["clinicId", "createdAt"])
    .index("by_patient", ["patientId"]),

  totemQRs: defineTable({
    clinicId: v.string(),
    qrCode: v.string(),
    expiresAt: v.number(),
    createdBy: v.id("users"),
    isActive: v.boolean(),
    scannedAt: v.optional(v.number()),
    scannedBy: v.optional(v.id("patients")),
    linkedCheckinSessionId: v.optional(v.id("checkinSessions")), // Links QR to the session that used it
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic_active", ["clinicId", "isActive"])
    .index("by_qrCode", ["qrCode"])
    .index("by_clinic_createdAt", ["clinicId", "createdAt"]),

  npsSettings: defineTable({
    clinicId: v.string(),
    enabled: v.boolean(),
    delayMinutes: v.number(),
    sendOnCompletion: v.boolean(),
    reviewLink: v.string(),
    googleMapsLink: v.string(),
    alertOnDetractor: v.optional(v.boolean()), // NEW: Enable alerts for low scores
    thresholds: v.optional(
      v.object({
        promoter: v.optional(v.number()), // e.g., 9-10
        passive: v.optional(v.number()), // e.g., 7-8
        detractor: v.optional(v.number()), // e.g., 0-6
      }),
    ),
    createdAt: v.number(),
    updatedAt: v.number(),
  }).index("by_clinic", ["clinicId"]),

  npsResponses: defineTable({
    clinicId: v.string(),
    patientId: v.id("patients"),
    appointmentId: v.id("appointments"),
    score: v.number(), // 0-10
    promoterType: v.union(v.literal("promoter"), v.literal("passive"), v.literal("detractor")),
    feedback: v.optional(v.string()),
    respondedAt: v.number(),
    channel: v.union(v.literal("whatsapp"), v.literal("email"), v.literal("sms")),
    checkinSessionId: v.optional(v.id("checkinSessions")),
    createdAt: v.number(),
  })
    .index("by_clinic_date", ["clinicId", "respondedAt"])
    .index("by_appointment", ["appointmentId"])
    .index("by_patient", ["patientId"])
    .index("by_clinic_promoterType", ["clinicId", "promoterType"]),

  tickets: defineTable({
    clinicId: v.string(),
    patientId: v.id("patients"),
    appointmentId: v.optional(v.id("appointments")),
    title: v.string(),
    description: v.string(),
    status: v.union(v.literal("open"), v.literal("in_progress"), v.literal("resolved")),
    priority: v.union(
      v.literal("low"),
      v.literal("medium"),
      v.literal("high"),
      v.literal("urgent"),
    ),
    source: v.union(v.literal("nps"), v.literal("other")),
    npsScore: v.optional(v.number()),
    npsFeedback: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_clinic", ["clinicId"])
    .index("by_clinic_status", ["clinicId", "status"])
    .index("by_patient", ["patientId"])
    .index("by_appointment", ["appointmentId"]),

  forms: defineTable({
    clinicId: v.string(),
    title: v.string(),
    description: v.optional(v.string()),
    type: v.union(v.literal("anamnesis"), v.literal("post_op"), v.literal("return")),
    questions: v.array(
      v.object({
        id: v.string(),
        type: v.union(
          v.literal("text"),
          v.literal("textarea"),
          v.literal("number"),
          v.literal("select"),
          v.literal("checkbox"),
          v.literal("date"),
        ),
        label: v.string(),
        options: v.optional(v.array(v.string())),
        required: v.boolean(),
      }),
    ),
    isActive: v.boolean(),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_clinic", ["clinicId"])
    .index("by_clinic_type", ["clinicId", "type"]),

  patientForms: defineTable({
    clinicId: v.string(),
    patientId: v.id("patients"),
    appointmentId: v.optional(v.id("appointments")),
    formId: v.id("forms"),
    status: v.union(v.literal("pending"), v.literal("completed")),
    submissionData: v.optional(v.any()),
    submittedAt: v.optional(v.number()),
    token: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_patient_status", ["patientId", "status"])
    .index("by_appointment", ["appointmentId"])
    .index("by_clinic_status", ["clinicId", "status"])
    .index("by_token", ["token"]),

  procedures: defineTable({
    clinicId: v.string(),
    doctorId: v.id("users"),
    name: v.string(),
    description: v.optional(v.string()),
    durationMinutes: v.number(),
    price: v.optional(v.number()),
    isActive: v.boolean(),
    isTelemedicine: v.boolean(),
    isInPerson: v.boolean(),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
    deletedAt: v.optional(v.number()),
  })
    .index("by_clinic", ["clinicId"])
    .index("by_clinic_doctor", ["clinicId", "doctorId"])
    .index("by_clinic_active", ["clinicId", "isActive"])
    .searchIndex("search_name", {
      searchField: "name",
      filterFields: ["clinicId", "doctorId", "isActive"],
    }),

  dataCollectionRequests: defineTable({
    clinicId: v.string(),
    patientId: v.id("patients"),
    type: v.union(v.literal("id_card"), v.literal("insurance_card"), v.literal("referral")),
    status: v.union(v.literal("pending"), v.literal("received"), v.literal("expired")),
    requestedAt: v.number(),
    receivedAt: v.optional(v.number()),
    messageId: v.optional(v.id("messages")),
    // Multi-image tracking (for insurance_card front/back)
    requiredCount: v.optional(v.number()), // 1 for id_card/referral, 2 for insurance_card
    receivedCount: v.optional(v.number()), // How many images received so far
    receivedMessageIds: v.optional(v.array(v.id("messages"))), // IDs of messages with images (for idempotency)
    createdAt: v.number(),
  })
    .index("by_patient_type", ["patientId", "type"])
    .index("by_clinic_status", ["clinicId", "status"]),
});
