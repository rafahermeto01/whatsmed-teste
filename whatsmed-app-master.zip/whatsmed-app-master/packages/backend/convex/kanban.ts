import { v } from "convex/values";

import { query, mutation } from "./_generated/server";
import { notFound } from "./lib/errors";

import type { Id } from "./_generated/dataModel";

// =============================================================================
// TYPE DEFINITIONS
// =============================================================================

const appointmentStatusValidator = v.union(
  v.literal("pending"),
  v.literal("confirmed"),
  v.literal("arrived"),
  v.literal("completed"),
  v.literal("cancelled"),
);

const remarketingStageValidator = v.union(
  v.literal("needs_contact"),
  v.literal("contacted"),
  v.literal("scheduled"),
  v.literal("not_interested"),
);

const leadStageValidator = v.union(
  v.literal("new_lead"),
  v.literal("contacted"),
  v.literal("scheduled"),
  v.literal("converted"),
);

type AppointmentStatus = "pending" | "confirmed" | "arrived" | "completed" | "cancelled";
type RemarketingStage = "needs_contact" | "contacted" | "scheduled" | "not_interested";
type LeadStage = "new_lead" | "contacted" | "scheduled" | "converted";

// =============================================================================
// APPOINTMENTS KANBAN QUERIES
// =============================================================================

/**
 * List appointments grouped by status for Kanban view.
 * Uses parallel indexed queries per status to avoid in-memory filtering.
 */
export const listAppointmentsByStatus = query({
  args: {
    clinicId: v.string(),
    startAt: v.optional(v.number()),
    endAt: v.optional(v.number()),
    limitPerColumn: v.optional(v.number()),
  },
  handler: async (ctx, { clinicId, startAt, endAt, limitPerColumn = 20 }) => {
    const statuses: AppointmentStatus[] = [
      "pending",
      "confirmed",
      "arrived",
      "completed",
      "cancelled",
    ];

    // Execute parallel queries for each status using the by_clinic_status_date index
    const results = await Promise.all(
      statuses.map(async (status) => {
        let q = ctx.db
          .query("appointments")
          .withIndex("by_clinic_status_date", (q) =>
            q.eq("clinicId", clinicId).eq("status", status),
          );

        // Apply date filters if provided
        const appointments = await q
          .filter((q) => {
            const conditions = [q.eq(q.field("deletedAt"), undefined)];
            if (startAt) {
              conditions.push(q.gte(q.field("startAt"), startAt));
            }
            if (endAt) {
              conditions.push(q.lte(q.field("startAt"), endAt));
            }
            return q.and(...conditions);
          })
          .order("asc")
          .take(limitPerColumn);

        // Enrich with patient names
        const enriched = await Promise.all(
          appointments.map(async (apt) => {
            const patient = await ctx.db.get(apt.patientId);
            return {
              ...apt,
              patientName: patient?.name ?? "Desconhecido",
              patientPhone: patient?.phone,
            };
          }),
        );

        return { status, items: enriched };
      }),
    );

    // Convert to object keyed by status
    const grouped: Record<AppointmentStatus, (typeof results)[0]["items"]> = {
      pending: [],
      confirmed: [],
      arrived: [],
      completed: [],
      cancelled: [],
    };

    for (const { status, items } of results) {
      grouped[status] = items;
    }

    return grouped;
  },
});

// =============================================================================
// REMARKETING KANBAN QUERIES
// =============================================================================

/**
 * List remarketing patients grouped by stage.
 * Remarketing = patients with past completed appointments but no future scheduled appointments.
 */
export const listRemarketingPatients = query({
  args: {
    clinicId: v.string(),
    limitPerColumn: v.optional(v.number()),
  },
  handler: async (ctx, { clinicId, limitPerColumn = 20 }) => {
    const now = Date.now();
    const stages: RemarketingStage[] = [
      "needs_contact",
      "contacted",
      "scheduled",
      "not_interested",
    ];

    // Execute parallel queries for each stage
    const results = await Promise.all(
      stages.map(async (stage) => {
        const patients = await ctx.db
          .query("patients")
          .withIndex("by_clinic_remarketingStage", (q) =>
            q.eq("clinicId", clinicId).eq("remarketingStage", stage),
          )
          .filter((q) =>
            q.and(
              q.eq(q.field("deletedAt"), undefined),
              q.eq(q.field("hasCompletedAppointment"), true),
            ),
          )
          .take(limitPerColumn);

        return { stage, items: patients };
      }),
    );

    // Also get unassigned remarketing patients (hasCompletedAppointment=true, no remarketingStage)
    // These are patients who should be in remarketing but haven't been staged yet
    const unstagedPatients = await ctx.db
      .query("patients")
      .withIndex("by_clinic_hasCompleted", (q) =>
        q.eq("clinicId", clinicId).eq("hasCompletedAppointment", true),
      )
      .filter((q) =>
        q.and(
          q.eq(q.field("deletedAt"), undefined),
          q.eq(q.field("remarketingStage"), undefined),
          // No future appointments scheduled
          q.or(
            q.eq(q.field("nextScheduledAppointmentAt"), undefined),
            q.lt(q.field("nextScheduledAppointmentAt"), now),
          ),
        ),
      )
      .take(limitPerColumn);

    // Convert to object keyed by stage
    const grouped: Record<RemarketingStage, (typeof results)[0]["items"]> = {
      needs_contact: [],
      contacted: [],
      scheduled: [],
      not_interested: [],
    };

    for (const { stage, items } of results) {
      grouped[stage] = items;
    }

    // Add unstaged patients to "needs_contact" column
    grouped.needs_contact = [...unstagedPatients, ...grouped.needs_contact].slice(
      0,
      limitPerColumn,
    );

    return grouped;
  },
});

// =============================================================================
// NEW PATIENTS KANBAN QUERIES
// =============================================================================

/**
 * List new patients (leads) grouped by stage.
 * New patients = patients who have never had a completed appointment.
 */
export const listNewPatients = query({
  args: {
    clinicId: v.string(),
    limitPerColumn: v.optional(v.number()),
  },
  handler: async (ctx, { clinicId, limitPerColumn = 20 }) => {
    const stages: LeadStage[] = ["new_lead", "contacted", "scheduled", "converted"];

    // Execute parallel queries for each stage
    const results = await Promise.all(
      stages.map(async (stage) => {
        const patients = await ctx.db
          .query("patients")
          .withIndex("by_clinic_leadStage", (q) =>
            q.eq("clinicId", clinicId).eq("leadStage", stage),
          )
          .filter((q) =>
            q.and(
              q.eq(q.field("deletedAt"), undefined),
              // Only include patients without completed appointments
              q.or(
                q.eq(q.field("hasCompletedAppointment"), undefined),
                q.eq(q.field("hasCompletedAppointment"), false),
              ),
            ),
          )
          .take(limitPerColumn);

        return { stage, items: patients };
      }),
    );

    // Also get unassigned new patients (no leadStage, no completed appointments)
    const unstagedPatients = await ctx.db
      .query("patients")
      .withIndex("by_clinic_hasCompleted", (q) =>
        q.eq("clinicId", clinicId).eq("hasCompletedAppointment", false),
      )
      .filter((q) =>
        q.and(q.eq(q.field("deletedAt"), undefined), q.eq(q.field("leadStage"), undefined)),
      )
      .take(limitPerColumn);

    // Also check patients with undefined hasCompletedAppointment (legacy data)
    const legacyPatients = await ctx.db
      .query("patients")
      .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", clinicId))
      .filter((q) =>
        q.and(
          q.eq(q.field("deletedAt"), undefined),
          q.eq(q.field("hasCompletedAppointment"), undefined),
          q.eq(q.field("leadStage"), undefined),
        ),
      )
      .take(limitPerColumn);

    // Convert to object keyed by stage
    const grouped: Record<LeadStage, (typeof results)[0]["items"]> = {
      new_lead: [],
      contacted: [],
      scheduled: [],
      converted: [],
    };

    for (const { stage, items } of results) {
      grouped[stage] = items;
    }

    // Add unstaged patients to "new_lead" column
    grouped.new_lead = [...unstagedPatients, ...legacyPatients, ...grouped.new_lead].slice(
      0,
      limitPerColumn,
    );

    return grouped;
  },
});

// =============================================================================
// STAGE UPDATE MUTATIONS
// =============================================================================

/**
 * Update a patient's remarketing stage (for Kanban drag-and-drop).
 */
export const updateRemarketingStage = mutation({
  args: {
    patientId: v.id("patients"),
    clinicId: v.string(),
    stage: remarketingStageValidator,
  },
  handler: async (ctx, { patientId, clinicId, stage }) => {
    const patient = await ctx.db.get(patientId);

    if (!patient || patient.clinicId !== clinicId || patient.deletedAt) {
      throw notFound("Paciente não encontrado");
    }

    await ctx.db.patch(patientId, {
      remarketingStage: stage,
      updatedAt: Date.now(),
    });

    return await ctx.db.get(patientId);
  },
});

/**
 * Update a patient's lead stage (for Kanban drag-and-drop).
 */
export const updateLeadStage = mutation({
  args: {
    patientId: v.id("patients"),
    clinicId: v.string(),
    stage: leadStageValidator,
  },
  handler: async (ctx, { patientId, clinicId, stage }) => {
    const patient = await ctx.db.get(patientId);

    if (!patient || patient.clinicId !== clinicId || patient.deletedAt) {
      throw notFound("Paciente não encontrado");
    }

    await ctx.db.patch(patientId, {
      leadStage: stage,
      updatedAt: Date.now(),
    });

    return await ctx.db.get(patientId);
  },
});

/**
 * Update an appointment's status (for Kanban drag-and-drop).
 * This is a simplified version focused on Kanban usage.
 */
export const updateAppointmentStatus = mutation({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
    status: appointmentStatusValidator,
  },
  handler: async (ctx, { appointmentId, clinicId, status }) => {
    const appointment = await ctx.db.get(appointmentId);

    if (!appointment || appointment.clinicId !== clinicId || appointment.deletedAt) {
      throw notFound("Agendamento não encontrado");
    }

    const previousStatus = appointment.status;

    await ctx.db.patch(appointmentId, {
      status,
      updatedAt: Date.now(),
    });

    // Update patient denormalized fields if status changed to/from completed
    if (status === "completed" && previousStatus !== "completed") {
      // Mark patient as having completed appointment
      await ctx.db.patch(appointment.patientId, {
        hasCompletedAppointment: true,
        lastCompletedAppointmentAt: appointment.startAt,
        // Clear lead stage as they are now a patient
        leadStage: undefined,
        // Initialize remarketing stage if needed
        remarketingStage: "needs_contact",
        updatedAt: Date.now(),
      });
    }

    // Update next scheduled appointment if status changed to confirmed/pending
    if ((status === "confirmed" || status === "pending") && appointment.startAt > Date.now()) {
      const patient = await ctx.db.get(appointment.patientId);
      if (
        !patient?.nextScheduledAppointmentAt ||
        appointment.startAt < patient.nextScheduledAppointmentAt
      ) {
        await ctx.db.patch(appointment.patientId, {
          nextScheduledAppointmentAt: appointment.startAt,
          updatedAt: Date.now(),
        });
      }
    }

    return await ctx.db.get(appointmentId);
  },
});
