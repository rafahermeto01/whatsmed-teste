import { paginationOptsValidator } from "convex/server";
import { v } from "convex/values";

import { mutation, query } from "./_generated/server";
import { notFound, forbidden } from "./lib/errors";
import { requireRole } from "./lib/rbac";
import { sanitizeString } from "./lib/validators";

// ===== QUERIES =====
// Read operations accept clinicId as argument (following pattern of other queries like getAvailableSlots)

export const list = query({
  args: {
    clinicId: v.string(),
    doctorId: v.optional(v.id("users")),
    includeInactive: v.optional(v.boolean()),
    paginationOpts: paginationOptsValidator,
  },
  handler: async (ctx, args) => {
    const { clinicId, doctorId } = args;

    // Build query based on filters
    if (doctorId) {
      let q = ctx.db
        .query("procedures")
        .withIndex("by_clinic_doctor", (q) => q.eq("clinicId", clinicId).eq("doctorId", doctorId))
        .filter((q) => q.eq(q.field("deletedAt"), undefined));

      if (!args.includeInactive) {
        q = q.filter((q) => q.eq(q.field("isActive"), true));
      }

      return await q.paginate(args.paginationOpts);
    } else {
      let q = ctx.db
        .query("procedures")
        .withIndex("by_clinic", (q) => q.eq("clinicId", clinicId))
        .filter((q) => q.eq(q.field("deletedAt"), undefined));

      if (!args.includeInactive) {
        q = q.filter((q) => q.eq(q.field("isActive"), true));
      }

      return await q.paginate(args.paginationOpts);
    }
  },
});

export const getById = query({
  args: {
    id: v.id("procedures"),
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const procedure = await ctx.db.get(args.id);
    if (!procedure || procedure.deletedAt || procedure.clinicId !== args.clinicId) {
      return null;
    }

    return procedure;
  },
});

export const listByDoctor = query({
  args: {
    doctorId: v.id("users"),
    clinicId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    // Get doctor to find their clinicId if not provided
    const doctor = await ctx.db.get(args.doctorId);
    if (!doctor) {
      return [];
    }

    const clinicId = args.clinicId || doctor.clinicId;

    return await ctx.db
      .query("procedures")
      .withIndex("by_clinic_doctor", (q) =>
        q.eq("clinicId", clinicId).eq("doctorId", args.doctorId),
      )
      .filter((q) => q.and(q.eq(q.field("isActive"), true), q.eq(q.field("deletedAt"), undefined)))
      .collect();
  },
});

// ===== MUTATIONS =====

export const create = mutation({
  args: {
    doctorId: v.optional(v.id("users")),
    name: v.string(),
    description: v.optional(v.string()),
    durationMinutes: v.number(),
    price: v.optional(v.number()),
    isTelemedicine: v.optional(v.boolean()),
    isInPerson: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const { clinicId, role, identity } = await requireRole(ctx, ["admin", "doctor", "super_admin"]);

    // Get current user for doctor role
    const currentUser = await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", identity.email as string))
      .first();

    // Determine doctor ID
    let doctorId = args.doctorId;
    if (role === "doctor") {
      // Doctors can only create for themselves
      doctorId = currentUser?._id;
    } else if (!doctorId) {
      throw forbidden("Admin must specify doctorId");
    }

    if (!doctorId) {
      throw forbidden("Could not determine doctor");
    }

    // Validate doctor exists
    const doctor = await ctx.db.get(doctorId);
    if (!doctor) {
      throw notFound("Doctor not found");
    }

    // For super_admin, use doctor's clinicId; otherwise validate clinicId matches
    const effectiveClinicId = role === "super_admin" ? doctor.clinicId : clinicId;
    if (!effectiveClinicId) {
      throw forbidden("Clinic context required");
    }
    if (role !== "super_admin" && doctor.clinicId !== clinicId) {
      throw notFound("Doctor not found");
    }

    // Valid "doctor": user is doctor in profile (users.role) OR in clinic membership (clinicMembers.role)
    const isDoctorByProfile = doctor.role === "doctor";
    const isDoctorByMembership = !!(await ctx.db
      .query("clinicMembers")
      .withIndex("by_clinic", (q) => q.eq("clinicId", effectiveClinicId))
      .filter((q) =>
        q.and(q.eq(q.field("userId"), doctor.authUserId), q.eq(q.field("role"), "doctor")),
      )
      .first());
    if (!isDoctorByProfile && !isDoctorByMembership) {
      const roleLabel =
        doctor.role === "viewer"
          ? "visualizador"
          : doctor.role === "admin"
            ? "administrador"
            : doctor.role === "staff"
              ? "equipe"
              : doctor.role;
      throw forbidden(
        `O usuário selecionado não é médico (função atual: ${roleLabel}). Altere a função do usuário para "Médico" em Configurações > Usuários ou selecione outro médico.`,
      );
    }

    // Validate duration (15 min to 480 min / 8 hours)
    if (args.durationMinutes < 15 || args.durationMinutes > 480) {
      throw forbidden("Duration must be between 15 and 480 minutes");
    }

    // Validate appointment type flags
    const isTelemedicine = args.isTelemedicine ?? false;
    const isInPerson = args.isInPerson ?? false;
    if (!isTelemedicine && !isInPerson) {
      throw forbidden("Procedure must support at least one appointment type");
    }

    return await ctx.db.insert("procedures", {
      clinicId: effectiveClinicId,
      doctorId: doctorId,
      name: sanitizeString(args.name, 100),
      description: args.description ? sanitizeString(args.description, 500) : undefined,
      durationMinutes: args.durationMinutes,
      price: args.price,
      isActive: true,
      isTelemedicine,
      isInPerson,
      createdAt: Date.now(),
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("procedures"),
    name: v.optional(v.string()),
    description: v.optional(v.string()),
    durationMinutes: v.optional(v.number()),
    price: v.optional(v.number()),
    isActive: v.optional(v.boolean()),
    isTelemedicine: v.optional(v.boolean()),
    isInPerson: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const { clinicId, role, identity } = await requireRole(ctx, ["admin", "doctor", "super_admin"]);

    const procedure = await ctx.db.get(args.id);
    if (!procedure || procedure.deletedAt) {
      throw notFound("Procedure not found");
    }

    // For super_admin, skip clinicId validation; otherwise validate clinicId matches
    if (role !== "super_admin" && procedure.clinicId !== clinicId) {
      throw notFound("Procedure not found");
    }

    // Doctors can only update their own procedures
    if (role === "doctor") {
      const currentUser = await ctx.db
        .query("users")
        .withIndex("by_email", (q) => q.eq("email", identity.email as string))
        .first();

      if (procedure.doctorId !== currentUser?._id) {
        throw forbidden("You can only update your own procedures");
      }
    }

    // Validate duration if provided
    if (args.durationMinutes !== undefined) {
      if (args.durationMinutes < 15 || args.durationMinutes > 480) {
        throw forbidden("Duration must be between 15 and 480 minutes");
      }
    }

    // Validate appointment type flags if provided
    const isTelemedicine =
      args.isTelemedicine !== undefined ? args.isTelemedicine : procedure.isTelemedicine;
    const isInPerson = args.isInPerson !== undefined ? args.isInPerson : procedure.isInPerson;
    if (!isTelemedicine && !isInPerson) {
      throw forbidden("Procedure must support at least one appointment type");
    }

    const updateData: Record<string, any> = { updatedAt: Date.now() };
    if (args.name !== undefined) updateData.name = sanitizeString(args.name, 100);
    if (args.description !== undefined)
      updateData.description = sanitizeString(args.description, 500);
    if (args.durationMinutes !== undefined) updateData.durationMinutes = args.durationMinutes;
    if (args.price !== undefined) updateData.price = args.price;
    if (args.isActive !== undefined) updateData.isActive = args.isActive;
    if (args.isTelemedicine !== undefined) updateData.isTelemedicine = args.isTelemedicine;
    if (args.isInPerson !== undefined) updateData.isInPerson = args.isInPerson;

    await ctx.db.patch(args.id, updateData);
    return args.id;
  },
});

export const softDelete = mutation({
  args: { id: v.id("procedures") },
  handler: async (ctx, args) => {
    const { clinicId, role, identity } = await requireRole(ctx, ["admin", "doctor", "super_admin"]);

    const procedure = await ctx.db.get(args.id);
    if (!procedure || procedure.deletedAt) {
      throw notFound("Procedure not found");
    }

    // For super_admin, skip clinicId validation; otherwise validate clinicId matches
    if (role !== "super_admin" && procedure.clinicId !== clinicId) {
      throw notFound("Procedure not found");
    }

    // Doctors can only delete their own procedures
    if (role === "doctor") {
      const currentUser = await ctx.db
        .query("users")
        .withIndex("by_email", (q) => q.eq("email", identity.email as string))
        .first();

      if (procedure.doctorId !== currentUser?._id) {
        throw forbidden("You can only delete your own procedures");
      }
    }

    await ctx.db.patch(args.id, { deletedAt: Date.now() });
    return args.id;
  },
});
