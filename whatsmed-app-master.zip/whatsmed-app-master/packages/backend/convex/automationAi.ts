"use node";

import { generateObject, generateText } from "ai";
import { v } from "convex/values";
import { z } from "zod";

import * as mastraModule from "../mastra/index.js";
import { downloadUrlToDataUrl, isPdfMimeType } from "../mastra/media.js";
import {
  getDocumentFallbackModel,
  getDocumentFallbackModelId,
  getImageVisionModel,
  getImageVisionModelId,
  getPrimaryChatModel,
} from "../mastra/providers.js";
import { transcribeAudioFromUrl } from "../mastra/transcription.js";
import { internal, api } from "./_generated/api.js";
import { internalAction } from "./_generated/server.js";
import { sanitizeVariable } from "./flows/sanitization.js";
import { sanitizePatientFacingResponse } from "./lib/patientResponse.js";

const internalAny = internal as any;
const apiAny = api as any;

function withPatientSafeResponse<T extends { response?: string | null }>(payload: T): T {
  if (!("response" in payload)) return payload;
  return {
    ...payload,
    response: sanitizePatientFacingResponse(payload.response),
  };
}

function getToolCallPayload(entry: any) {
  return entry?.payload || entry || {};
}

function formatBrazilDateTime(value: string | number | Date) {
  const date = new Date(value);
  return {
    date: date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      timeZone: "America/Sao_Paulo",
    }),
    time: date.toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "America/Sao_Paulo",
    }),
  };
}

function buildAppointmentConfirmationFromToolResult(params: {
  toolCalls: any[];
  toolResults: any[];
  patient?: any;
  clinic?: any;
}) {
  const { toolCalls, toolResults, patient, clinic } = params;

  for (const toolResult of toolResults) {
    const resultPayload = getToolCallPayload(toolResult);
    const matchingCall = toolCalls.find((toolCall: any) => {
      const callPayload = getToolCallPayload(toolCall);
      return (callPayload.toolCallId || callPayload.id) === resultPayload.toolCallId;
    });
    const callPayload = getToolCallPayload(matchingCall);
    const toolName = callPayload.toolName || matchingCall?.toolName;
    const result = resultPayload.result;

    if (!result?.success || !result?.appointment?.startAt) {
      continue;
    }

    if (toolName !== "createAppointment" && toolName !== "cancelAppointment") {
      continue;
    }

    const { date, time } = formatBrazilDateTime(result.appointment.startAt);
    const procedure = result.appointment.procedure || "sua consulta";
    const doctor = result.appointment.doctor || "seu medico";
    const isTelemedicine =
      typeof result.appointment.isTelemedicine === "boolean"
        ? result.appointment.isTelemedicine
        : Boolean(callPayload.args?.isTelemedicine);
    const insurance = patient?.insurance ? ` Convenio: ${patient.insurance}.` : "";
    const address = !isTelemedicine && clinic?.address ? ` Endereco: ${clinic.address}.` : "";
    const mode = isTelemedicine ? "telemedicina" : "presencial";

    if (toolName === "cancelAppointment") {
      const intro = result.alreadyCancelled
        ? "Este agendamento ja estava cancelado"
        : "Agendamento cancelado";
      return `${intro}: ${procedure} (${mode}) com ${doctor} em ${date} as ${time}.${insurance}`;
    }

    const intro = result.rescheduled ? "Reagendamento confirmado" : "Agendamento confirmado";
    return `${intro}: ${procedure} (${mode}) com ${doctor} em ${date} as ${time}.${insurance}${address}`;
  }

  return null;
}

function normalizeImageIdentification(raw: any): {
  type: "insurance_card" | "id_card" | "referral" | "other";
  side?: "front" | "back";
  confidence: number;
  description: string;
} {
  const validType = ["insurance_card", "id_card", "referral", "other"].includes(raw?.type)
    ? raw.type
    : "other";
  const validSide = raw?.side === "front" || raw?.side === "back" ? raw.side : undefined;
  const confidenceNumber = Number(raw?.confidence);
  const boundedConfidence = Number.isFinite(confidenceNumber)
    ? Math.max(0, Math.min(100, confidenceNumber))
    : 0;

  return {
    type: validType,
    side: validType === "insurance_card" ? validSide : undefined,
    confidence: boundedConfidence,
    description: typeof raw?.description === "string" ? raw.description : "",
  };
}

function normalizeExtractedTimeToken(timeValue: string | null): string | null {
  if (!timeValue) return null;
  const clean = String(timeValue).trim().toLowerCase().replace(/h$/, ":00");
  const match = clean.match(/^(\d{1,2})(?::(\d{2}))?$/);
  if (!match) return null;
  return `${match[1].padStart(2, "0")}:${(match[2] || "00").padStart(2, "0")}`;
}

function getToolResultTime(slot: any): string | null {
  if (typeof slot?.time === "string" && slot.time.trim()) {
    return slot.time.trim();
  }
  if (typeof slot?.start === "string") {
    return new Date(slot.start).toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "America/Sao_Paulo",
    });
  }
  return null;
}

function buildAvailabilityResponseFromToolResult(params: {
  toolCalls: any[];
  toolResults: any[];
  message: string;
}): string | null {
  const { toolCalls, toolResults, message } = params;
  const pairs = toolResults
    .map((toolResult) => {
      const resultPayload = getToolCallPayload(toolResult);
      const matchingCall = toolCalls.find((toolCall: any) => {
        const callPayload = getToolCallPayload(toolCall);
        return (callPayload.toolCallId || callPayload.id) === resultPayload.toolCallId;
      });
      if (!matchingCall) return null;
      return {
        toolName: getToolCallPayload(matchingCall).toolName || matchingCall.toolName,
        result: resultPayload.result,
      };
    })
    .filter(Boolean) as Array<{ toolName: string; result: any }>;

  const clarificationResult = pairs.find(
    (pair) =>
      [
        "checkDoctorAvailability",
        "checkSpecialtyAvailability",
        "listDoctorsBySpecialty",
        "listProcedures",
      ].includes(pair.toolName) &&
      pair.result?.needsClarification &&
      pair.result?.clarificationQuestion,
  );
  if (clarificationResult?.result?.clarificationQuestion) {
    return clarificationResult.result.clarificationQuestion;
  }

  const availabilityResult =
    [...pairs].reverse().find((pair) => pair.toolName === "checkDoctorAvailability") ||
    [...pairs].reverse().find((pair) => pair.toolName === "checkSpecialtyAvailability");
  if (!availabilityResult?.result?.success) {
    return null;
  }

  const result = availabilityResult.result;
  if (result.needsClarification && result.clarificationQuestion) {
    return result.clarificationQuestion;
  }

  const normalizedExactTime = normalizeExtractedTimeToken(extractTimeToken(message));
  const requestedPeriod = result.requestedPeriod || extractPeriod(message);
  const isTelemedicine = /telemed|teleconsulta/.test(normalizeTriageText(message));
  const modalityLabel = isTelemedicine ? "telemedicina" : "consulta presencial";
  const dateIso = extractBrazilDate(message);
  const dateLabel = dateIso ? dateIso.split("-").reverse().join("/") : "essa data";
  const doctorOrSpecialty = result.doctor?.name || result.specialty || "o profissional";
  const slots = Array.isArray(result.slots) ? result.slots : [];
  const slotTimes = [
    ...new Set(slots.map((slot: any) => getToolResultTime(slot)).filter(Boolean)),
  ] as string[];
  const displayTimes = slotTimes.slice(0, requestedPeriod ? 8 : 25);
  const periodLabel =
    requestedPeriod === "morning"
      ? "na manhã"
      : requestedPeriod === "afternoon"
        ? "à tarde"
        : requestedPeriod === "night"
          ? "à noite"
          : "";

  if (normalizedExactTime) {
    const [hour] = normalizedExactTime.split(":").map(Number);
    const outsideHours = hour < 8 || hour >= 22 || hour === 12;
    if (slotTimes.includes(normalizedExactTime)) {
      return `Tenho ${normalizedExactTime} disponível para ${modalityLabel} com ${doctorOrSpecialty} em ${dateLabel}. Confirma o agendamento?`;
    }
    if (outsideHours) {
      return displayTimes.length > 0
        ? `Esse horário está fora do expediente em ${dateLabel}. Tenho estes horários disponíveis: ${displayTimes.join(", ")}.`
        : `Esse horário está fora do expediente em ${dateLabel}.`;
    }
    return displayTimes.length > 0
      ? `Não há disponibilidade às ${normalizedExactTime} em ${dateLabel}. Tenho estes horários disponíveis${periodLabel ? ` ${periodLabel}` : ""}: ${displayTimes.join(", ")}.`
      : `Não há disponibilidade às ${normalizedExactTime} em ${dateLabel}.`;
  }

  if (displayTimes.length === 0) {
    return `Não encontrei horários disponíveis${periodLabel ? ` ${periodLabel}` : ""} em ${dateLabel}.`;
  }

  return `Os horários disponíveis${periodLabel ? ` ${periodLabel}` : ""} para ${modalityLabel} com ${doctorOrSpecialty} em ${dateLabel} são: ${displayTimes.join(", ")}.`;
}

function extractJsonText(text: string): string {
  const trimmed = text.trim();
  if (trimmed.startsWith("{")) return trimmed;

  const fencedMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (fencedMatch?.[1]) return fencedMatch[1].trim();

  const firstBrace = trimmed.indexOf("{");
  const lastBrace = trimmed.lastIndexOf("}");
  if (firstBrace >= 0 && lastBrace > firstBrace) {
    return trimmed.slice(firstBrace, lastBrace + 1);
  }

  return trimmed;
}

function normalizeTriageText(message: string): string {
  return message
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function buildAvailabilityRangeLabels(slots: Array<{ start: string; end: string }>): string[] {
  const ranges: Array<{ start: string; end: string; date: string; slotCount: number }> = [];
  const sortedSlots = [...slots].sort(
    (a, b) => new Date(a.start).getTime() - new Date(b.start).getTime(),
  );

  for (const slot of sortedSlots) {
    const startTimestamp = new Date(slot.start).getTime();
    const endTimestamp = new Date(slot.end).getTime();

    if (!Number.isFinite(startTimestamp) || !Number.isFinite(endTimestamp)) {
      continue;
    }

    const date = new Date(slot.start).toLocaleDateString("en-CA", {
      timeZone: "America/Sao_Paulo",
    });
    const previousRange = ranges[ranges.length - 1];

    if (
      previousRange &&
      previousRange.date === date &&
      new Date(previousRange.end).getTime() === startTimestamp
    ) {
      previousRange.end = slot.end;
      previousRange.slotCount += 1;
      continue;
    }

    ranges.push({
      start: slot.start,
      end: slot.end,
      date,
      slotCount: 1,
    });
  }

  return ranges.map((range) => {
    const startTime = new Date(range.start).toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "America/Sao_Paulo",
    });
    const endTime = new Date(range.end).toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "America/Sao_Paulo",
    });

    return range.slotCount > 1 ? `das ${startTime} as ${endTime}` : startTime;
  });
}

function formatAvailabilityForPatient(slots: Array<{ start: string; end: string }>): string {
  return buildAvailabilityRangeLabels(slots).join(", ");
}

function getAvailabilityPeriodForHour(hour: number): "morning" | "afternoon" | "night" | null {
  if (hour >= 8 && hour < 12) return "morning";
  if (hour >= 13 && hour < 18) return "afternoon";
  if (hour >= 19 && hour < 22) return "night";
  return null;
}

function slotMatchesRequestedPeriod(
  slotStartIso: string,
  period?: "morning" | "afternoon" | "night" | null,
): boolean {
  if (!period) return true;

  const hour = Number(
    new Date(slotStartIso).toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      hour12: false,
      timeZone: "America/Sao_Paulo",
    }),
  );

  return getAvailabilityPeriodForHour(hour) === period;
}

// ============================================================================
// 2-AI CLASSIFIER SYSTEM
// ============================================================================

/**
 * Intent taxonomy for the classifier AI
 * Each intent maps to a specific tool profile
 */
const INTENT_TYPES = [
  "availability",
  "booking",
  "reschedule",
  "cancel",
  "clinic_info",
  "documents_intake",
  "nps_review",
  "human_handoff",
  "general_chat",
] as const;

const IntentTypeSchema = z.enum(INTENT_TYPES);

/**
 * Classifier output schema
 */
const ClassifierOutputSchema = z.object({
  intent: IntentTypeSchema.describe("The primary intent of the patient's message"),
  toolProfile: z
    .enum([
      "availability",
      "booking",
      "reschedule",
      "cancel",
      "clinic_info",
      "documents_intake",
      "nps_review",
      "human_handoff",
      "general_chat",
    ])
    .describe("The tool profile to use for this intent"),
  allowedTools: z.array(z.string()).describe("Tools available to the executor AI"),
  requiredTools: z.array(z.string()).describe("Tools that MUST be used"),
  forbiddenTools: z.array(z.string()).describe("Tools that must NOT be used"),
  needsClarification: z.boolean().describe("Whether intent is ambiguous"),
  clarifyingQuestion: z.string().nullable().describe("Question if clarification needed"),
  confidence: z.number().min(0).max(1).describe("Confidence score (0-1)"),
  rationaleShort: z.string().max(200).describe("Brief explanation"),
});

type ClassifierOutput = z.infer<typeof ClassifierOutputSchema>;

/**
 * Tool profiles - define tool access for each intent
 * This is the authoritative source of tool access control
 */
const TOOL_PROFILES: Record<
  string,
  {
    allowed: string[];
    required: string[];
    forbidden: string[];
    description: string;
  }
> = {
  availability: {
    allowed: [
      "checkDoctorAvailability",
      "checkSpecialtyAvailability",
      "searchDoctors",
      "listSpecialties",
      "listDoctorsBySpecialty",
      "getClinicInfo",
    ],
    required: ["checkDoctorAvailability", "checkSpecialtyAvailability"],
    forbidden: [
      "listAppointments",
      "getAppointment",
      "cancelAppointment",
      "createAppointment",
      "escalateToStaff",
    ],
    description: "Checking available appointment slots. Use ONLY availability tools.",
  },

  booking: {
    allowed: [
      "searchDoctors",
      "listProcedures",
      "getAvailableDays",
      "getAvailableHours",
      "checkDoctorAvailability",
      "createAppointment",
      "getClinicInfo",
      "updatePatientData",
    ],
    required: [],
    forbidden: ["listAppointments", "cancelAppointment", "escalateToStaff"],
    description: "Creating new appointments. Can use full scheduling flow.",
  },

  reschedule: {
    allowed: [
      "listAppointments",
      "getAppointment",
      "searchDoctors",
      "listProcedures",
      "getAvailableDays",
      "getAvailableHours",
      "checkDoctorAvailability",
      "createAppointment",
      "cancelAppointment",
      "getClinicInfo",
    ],
    required: ["listAppointments"],
    forbidden: ["escalateToStaff"],
    description: "Rescheduling existing appointments. MUST use listAppointments first.",
  },

  cancel: {
    allowed: ["listAppointments", "getAppointment", "cancelAppointment", "getClinicInfo"],
    required: ["listAppointments"],
    forbidden: ["createAppointment", "escalateToStaff"],
    description: "Canceling appointments. MUST find appointment first with listAppointments.",
  },

  clinic_info: {
    allowed: ["getClinicInfo", "getAiSettings", "listSpecialties", "searchDoctors"],
    required: [],
    forbidden: [
      "createAppointment",
      "cancelAppointment",
      "listAppointments",
      "getAppointment",
      "escalateToStaff",
    ],
    description: "General clinic information questions.",
  },

  documents_intake: {
    allowed: [
      "analyzeDocument",
      "savePatientImage",
      "updatePatientData",
      "getPatientInfo",
      "getClinicInfo",
    ],
    required: [],
    forbidden: ["createAppointment", "cancelAppointment", "listAppointments", "escalateToStaff"],
    description: "Collecting patient documents and images.",
  },

  nps_review: {
    allowed: [
      "saveNpsScore",
      "getNpsSettings",
      "requestGoogleReview",
      "getReviewLink",
      "createInternalTicket",
      "getClinicInfo",
    ],
    required: [],
    forbidden: ["createAppointment", "cancelAppointment", "listAppointments", "escalateToStaff"],
    description: "NPS/satisfaction survey responses.",
  },

  human_handoff: {
    allowed: ["escalateToStaff", "getClinicInfo", "createInternalTicket"],
    required: ["escalateToStaff"],
    forbidden: ["createAppointment", "cancelAppointment"],
    description: "Explicit requests for human assistance. MUST call escalateToStaff.",
  },

  general_chat: {
    allowed: ["getClinicInfo", "getPatientInfo"],
    required: [],
    forbidden: ["createAppointment", "cancelAppointment", "listAppointments", "escalateToStaff"],
    description: "General conversation, greetings, non-medical chat.",
  },
};

/**
 * Simplified classifier using text generation with JSON output
 * This is more reliable than generateObject with complex schemas
 */
async function classifyIntent(params: {
  message: string;
  contextMessages: any[];
  patient?: any;
  clinic?: any;
  variableContext: any;
}): Promise<ClassifierOutput> {
  const { message, contextMessages, patient, variableContext } = params;

  const clarificationIntent = inferIntentFromClarificationContext(contextMessages);
  if (
    clarificationIntent &&
    !extractBrazilDate(message) &&
    !extractTimeToken(message) &&
    getEntityTokens(message).length <= 8
  ) {
    const clarificationProfile = TOOL_PROFILES[clarificationIntent] || TOOL_PROFILES.availability;
    return {
      intent: clarificationIntent,
      toolProfile: clarificationIntent,
      allowedTools: clarificationProfile.allowed,
      requiredTools: clarificationProfile.required,
      forbiddenTools: clarificationProfile.forbidden,
      needsClarification: false,
      clarifyingQuestion: null,
      confidence: 0.95,
      rationaleShort: "Clarification answer inherits previous scheduling intent",
    };
  }

  const systemPrompt = `You are an intent classifier for a medical clinic AI assistant.
Analyze the patient's message and classify it into ONE of these intents:
- availability: Questions about "horários disponíveis", "vagas", "tem horário", checking when doctors are free
- booking: Creating new appointments, scheduling consultations
- reschedule: Changing existing appointments
- cancel: Canceling appointments
- clinic_info: General questions about the clinic
- documents_intake: Collecting patient documents/images
- nps_review: Satisfaction surveys
- human_handoff: Explicit requests for human help
- general_chat: Greetings, general conversation

CRITICAL RULES:
- For ANY question about availability, classify as "availability"
- If ambiguous between availability and booking, prefer "availability"

Respond ONLY with a JSON object in this EXACT format:
{
  "intent": "one_of_the_above",
  "confidence": 0.0_to_1.0,
  "rationale": "brief explanation"
}

Patient: ${patient?.name || "Unknown"}
Date: ${variableContext?.date?.todayISO || new Date().toISOString().split("T")[0]}`;

  const userPrompt = `Patient message: "${message}"

Classify this intent and respond with JSON only.`;

  try {
    const model = getPrimaryChatModel();

    const result = await generateText({
      model,
      system: systemPrompt,
      prompt: userPrompt,
      temperature: 0,
    });

    // Parse the JSON response
    const jsonMatch = result.text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("No JSON found in classifier response");
    }

    const parsed = JSON.parse(jsonMatch[0]);
    const intent = parsed.intent || "general_chat";
    const confidence = parsed.confidence || 0.5;

    console.warn(`[classifyIntent] Classified intent: ${intent}, confidence: ${confidence}`);

    // Map intent to tool profile
    const profile = TOOL_PROFILES[intent] || TOOL_PROFILES.general_chat;

    const coercedIntent =
      intent === "booking" && shouldTreatBookingMessageAsAvailability(message)
        ? "availability"
        : intent;
    const coercedProfile = TOOL_PROFILES[coercedIntent] || profile;

    return {
      intent: coercedIntent as any,
      toolProfile: coercedIntent,
      allowedTools: coercedProfile.allowed,
      requiredTools: coercedProfile.required,
      forbiddenTools: coercedProfile.forbidden,
      needsClarification: confidence < 0.7,
      clarifyingQuestion:
        confidence < 0.7
          ? "Desculpe, não entendi bem. Você quer verificar horários disponíveis ou já tem um horário específico em mente?"
          : null,
      confidence,
      rationaleShort: parsed.rationale || "",
    };
  } catch (error) {
    console.error("[classifyIntent] Failed, using fallback:", error);
    return {
      intent: "general_chat",
      toolProfile: "general_chat",
      allowedTools: TOOL_PROFILES.general_chat.allowed,
      requiredTools: TOOL_PROFILES.general_chat.required,
      forbiddenTools: TOOL_PROFILES.general_chat.forbidden,
      needsClarification: false,
      clarifyingQuestion: null,
      confidence: 0.5,
      rationaleShort: "Classifier failed, using safe fallback",
    };
  }
}

/**
 * Validate executor tool usage against classification
 */
function validateToolUsage(
  toolCalls: any[],
  classification: ClassifierOutput,
  message?: string,
): { valid: boolean; usedForbidden: string[]; missingRequired: string[]; hint: string | null } {
  const usedToolNames = toolCalls
    .map((tc: any) => tc.payload?.toolName || tc.toolName || "")
    .filter(Boolean);

  const forbiddenUsed = classification.forbiddenTools.filter((name) =>
    usedToolNames.includes(name),
  );

  const requiredUsed = classification.requiredTools.filter((name) => usedToolNames.includes(name));

  const missingRequired = classification.requiredTools.filter(
    (name) => !usedToolNames.includes(name),
  );

  const createAppointmentUsed = usedToolNames.includes("createAppointment");
  const hasExplicitSchedulingConfirmation = isExplicitSchedulingConfirmationMessage(message || "");

  const valid =
    forbiddenUsed.length === 0 &&
    (classification.requiredTools.length === 0 || requiredUsed.length > 0) &&
    (!createAppointmentUsed || hasExplicitSchedulingConfirmation);

  let hint: string | null = null;

  if (forbiddenUsed.length > 0) {
    hint = `⚠️ FERRAMENTA PROIBIDA USADA: ${forbiddenUsed.join(", ")}. \
Para ${classification.intent}, NUNCA use: ${classification.forbiddenTools.join(", ")}. \
Use APENAS: ${classification.allowedTools.join(", ")}.`;
  } else if (createAppointmentUsed && !hasExplicitSchedulingConfirmation) {
    hint =
      "⚠️ CREATEAPPOINTMENT FOI CHAMADA CEDO DEMAIS. Só agende/reagende após uma confirmação explícita do paciente (ex.: 'sim', 'confirmo', 'pode agendar'). Nesta mensagem, responda apenas com disponibilidade e peça confirmação antes de criar ou reagendar.";
  } else if (missingRequired.length > 0) {
    hint = `⚠️ FERRAMENTA OBRIGATÓRIA FALTANDO: ${missingRequired.join(", ")}. \
Para ${classification.intent}, você DEVE usar: ${classification.requiredTools.join(", ")}.`;
  }

  return { valid, usedForbidden: forbiddenUsed, missingRequired, hint };
}

function isExplicitSchedulingConfirmationMessage(message: string): boolean {
  const normalized = normalizeTriageText(message || "");
  if (!normalized) {
    return false;
  }

  if (isAffirmativeMessage(message)) {
    return true;
  }

  return /(confirm|pode agendar|pode marcar|quero confirmar|fechado|esse horario|esse horário|este horario|este horário|pode reagendar)/i.test(
    message || "",
  );
}

function shouldTreatBookingMessageAsAvailability(message: string): boolean {
  const normalized = normalizeTriageText(message || "");
  if (!normalized) {
    return false;
  }

  if (/reagend|remarc|mudar horario|trocar horario|mudar data|trocar data/.test(normalized)) {
    return false;
  }

  if (isExplicitSchedulingConfirmationMessage(message)) {
    return false;
  }

  const asksToSchedule = /(agendar|marcar|consulta|teleconsulta)/.test(normalized);
  const hasSchedulingConstraint =
    /\d{2}\/\d{2}\/\d{4}/.test(message || "") ||
    /\b(?:[01]?\d|2[0-3])h\b/.test(normalized) ||
    /\b(?:manha|manha|tarde|noite)\b/.test(normalized);

  return asksToSchedule && hasSchedulingConstraint;
}

/**
 * Build executor guidance from classification
 */
function buildExecutorGuidance(classification: ClassifierOutput): string {
  const profile = TOOL_PROFILES[classification.toolProfile];

  return `
═══ INSTRUÇÕES DO CLASSIFICADOR ═══
Intenção: ${classification.intent} | Perfil: ${classification.toolProfile} | Confiança: ${(classification.confidence * 100).toFixed(0)}%

DISPONÍVEIS:
${classification.allowedTools.map((t) => `  ✓ ${t}`).join("\n")}
${
  classification.requiredTools.length > 0
    ? `
OBRIGATÓRIAS:
${classification.requiredTools.map((t) => `  ⚠️ ${t}`).join("\n")}`
    : ""
}
${
  classification.forbiddenTools.length > 0
    ? `
PROIBIDAS:
${classification.forbiddenTools.map((t) => `  ✗ ${t}`).join("\n")}`
    : ""
}
${profile ? `\n${profile.description}` : ""}
${classification.rationaleShort ? `\nRaciocínio: ${classification.rationaleShort}` : ""}
═══════════════════════════════════`;
}

// ============================================================================
// END 2-AI CLASSIFIER SYSTEM
// ============================================================================

const CONVERSATION_SESSION_GAP_MS = 6 * 60 * 60 * 1000;

function isStrictSchedulingFlowConfigured(...sources: Array<string | undefined | null>): boolean {
  const combined = sources.filter(Boolean).join("\n");
  if (!combined.trim()) return false;

  return /(siga esta ordem rigidamente|fluxo de atendimento|fluxo de reagendamento|etapa 0|etapa 1|regras absolutas)/i.test(
    combined,
  );
}

export function isNewConversationStartMessage(message: string): boolean {
  const normalized = normalizeTriageText(message).trim();
  if (!normalized) return false;

  return (
    /^(oi|ola|bom dia|boa tarde|boa noite)\b/.test(normalized) ||
    /(quero|gostaria|preciso).{0,40}(marcar|agendar).{0,20}(consulta|exame)?/.test(normalized) ||
    /(nova consulta|novo agendamento|quero marcar uma consulta|quero agendar uma consulta)/.test(
      normalized,
    )
  );
}

export function isTerminalAssistantMessage(message: any): boolean {
  if (!message || message.direction !== "out" || message.isInternal) return false;

  const normalized = normalizeTriageText(String(message.body || ""));
  if (!normalized) return false;

  return /(agendamento confirmado|reagendamento concluido|cancelamento confirmado|consulta cancelada|id do agendamento|encaminhado para nossa equipe|membro da equipe entrara em contato|entraremos em contato|transferindo para nossa equipe|chat foi encaminhado)/.test(
    normalized,
  );
}

function getMessageTimestamp(message: any): number {
  const value = message?.sentAt ?? message?.createdAt;
  return typeof value === "number" ? value : 0;
}

export function trimConversationToActiveSession(messages: any[], incomingMessage: string): any[] {
  if (!Array.isArray(messages) || messages.length === 0) return [];

  let startIndex = 0;
  for (let index = messages.length - 1; index > 0; index -= 1) {
    const currentTimestamp = getMessageTimestamp(messages[index]);
    const previousTimestamp = getMessageTimestamp(messages[index - 1]);

    if (
      currentTimestamp > 0 &&
      previousTimestamp > 0 &&
      currentTimestamp - previousTimestamp > CONVERSATION_SESSION_GAP_MS
    ) {
      startIndex = index;
      break;
    }
  }

  let activeMessages = messages.slice(startIndex);

  if (isNewConversationStartMessage(incomingMessage)) {
    for (let index = activeMessages.length - 1; index >= 0; index -= 1) {
      if (isTerminalAssistantMessage(activeMessages[index])) {
        activeMessages = activeMessages.slice(index + 1);
        break;
      }
    }
  }

  return activeMessages;
}

function isEmergencyTriageMessage(message: string): boolean {
  const normalized = normalizeTriageText(message);
  return [
    /dor no peito/,
    /falta de ar/,
    /nao consigo respirar/,
    /suspeita de infarto/,
    /suspeita de avc/,
    /desma/i,
    /convuls/,
    /sangrando muito/,
    /hemorrag/,
  ].some((pattern) => pattern.test(normalized));
}

function isHighPriorityTriageMessage(message: string): boolean {
  const normalized = normalizeTriageText(message);
  return (
    (/febre/.test(normalized) && /dor de cabeca/.test(normalized)) ||
    (/febre/.test(normalized) && /ha 3 dias/.test(normalized)) ||
    /dor de cabeca forte/.test(normalized)
  );
}

function isAffirmativeMessage(message: string): boolean {
  const normalized = normalizeTriageText(message).trim();
  return /^(sim|confirmo|confirmar|confirma|ok|okay|pode|isso|pode confirmar|pode agendar|quero sim)$/.test(
    normalized,
  );
}

function isAvailabilityMessage(message: string): boolean {
  const normalized = normalizeTriageText(message);
  return /(horario|horarios|vaga|vagas|disponiv|tem horario|tem vaga|manha|tarde|noite)/.test(
    normalized,
  );
}

function extractBrazilDate(text: string): string | null {
  const match = text.match(/\b(\d{2})\/(\d{2})\/(\d{4})\b/);
  if (!match) return null;
  return `${match[3]}-${match[2]}-${match[1]}`;
}

function extractTimeToken(text: string): string | null {
  const exact = text.match(/\b([01]?\d|2[0-3]):([0-5]\d)\b/);
  if (exact) {
    return `${exact[1].padStart(2, "0")}:${exact[2]}`;
  }

  const hForm = text.match(/\b([01]?\d|2[0-3])h\b/i);
  if (hForm) {
    return `${hForm[1].padStart(2, "0")}:00`;
  }

  const periodForm = text.match(/\b(\d{1,2})\s+da\s+(manha|tarde|noite)\b/i);
  if (periodForm) {
    let hour = Number(periodForm[1]);
    const period = normalizeTriageText(periodForm[2]);
    if (period === "tarde" && hour < 12) hour += 12;
    if (period === "noite" && hour < 12) hour += 12;
    return `${String(hour).padStart(2, "0")}:00`;
  }

  return null;
}

function extractPeriod(text: string): "morning" | "afternoon" | "night" | null {
  const normalized = normalizeTriageText(text);
  if (/manha|de manha/.test(normalized)) return "morning";
  if (/tarde|a tarde/.test(normalized)) return "afternoon";
  if (/noite|a noite/.test(normalized)) return "night";
  return null;
}

function extractDoctorName(text: string): string | null {
  const matches = Array.from(
    text.matchAll(
      /((?:dr\.?|dra\.?|doutor|doutora)\s+[A-Za-zÀ-ÿ][\wÀ-ÿ.-]*(?:\s+[A-Za-zÀ-ÿ][\wÀ-ÿ.-]*){0,4})/gi,
    ),
  );
  const bestMatch = matches.map((entry) => entry[1]).sort((a, b) => b.length - a.length)[0];
  if (!bestMatch) return null;
  return bestMatch
    .replace(/\s+/g, " ")
    .replace(
      /\b(em|para|no|na|dia|as|a|deseja|confirma|confirmar|esta|está|disponivel|disponível)\b.*$/i,
      "",
    )
    .trim();
}

function normalizeEntityText(value: string, options?: { stripDoctorPrefix?: boolean }): string {
  let normalized = normalizeTriageText(value)
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (options?.stripDoctorPrefix) {
    normalized = normalized.replace(/^(dr|dra|doutor|doutora)\s+/, "").trim();
  }
  return normalized;
}

function calculateNameSimilarity(str1: string, str2: string): number {
  if (str1 === str2) return 1.0;
  if (!str1 || !str2) return 0.0;

  const s1 = str1.toLowerCase().trim();
  const s2 = str2.toLowerCase().trim();
  if (s1 === s2) return 1.0;

  if (s1.includes(s2) || s2.includes(s1)) {
    const longer = Math.max(s1.length, s2.length);
    const shorter = Math.min(s1.length, s2.length);
    return shorter / longer;
  }

  const jaroDistance = (left: string, right: string): number => {
    if (left === right) return 1.0;
    if (left.length === 0 || right.length === 0) return 0.0;

    const matchDistance = Math.floor(Math.max(left.length, right.length) / 2) - 1;
    const leftMatches = new Array(left.length).fill(false);
    const rightMatches = new Array(right.length).fill(false);

    let matches = 0;
    let transpositions = 0;

    for (let i = 0; i < left.length; i += 1) {
      const start = Math.max(0, i - matchDistance);
      const end = Math.min(i + matchDistance + 1, right.length);
      for (let j = start; j < end; j += 1) {
        if (rightMatches[j] || left[i] !== right[j]) continue;
        leftMatches[i] = true;
        rightMatches[j] = true;
        matches += 1;
        break;
      }
    }

    if (matches === 0) return 0.0;

    let rightIndex = 0;
    for (let i = 0; i < left.length; i += 1) {
      if (!leftMatches[i]) continue;
      while (!rightMatches[rightIndex]) rightIndex += 1;
      if (left[i] !== right[rightIndex]) transpositions += 1;
      rightIndex += 1;
    }

    return (
      (matches / left.length + matches / right.length + (matches - transpositions / 2) / matches) /
      3.0
    );
  };

  const jaro = jaroDistance(s1, s2);
  let prefix = 0;
  while (prefix < 4 && s1[prefix] && s1[prefix] === s2[prefix]) {
    prefix += 1;
  }

  return jaro + prefix * 0.1 * (1 - jaro);
}

function getEntityTokens(value: string): string[] {
  return normalizeEntityText(value)
    .split(/\s+/)
    .map((token) => token.trim())
    .filter(Boolean);
}

function detectDoctorGenderHint(value: string): "male" | "female" | null {
  const normalized = normalizeEntityText(value);
  if (/^(dra|doutora)\b/.test(normalized)) return "female";
  if (/^(dr|doutor)\b/.test(normalized)) return "male";
  return null;
}

function getProcedureHints(value: string) {
  const normalized = normalizeEntityText(value);
  return {
    wantsReturn: /\bretorno\b/.test(normalized),
    wantsTelemedicine: /telemed|teleconsulta/.test(normalized),
    wantsInPerson: /presencial/.test(normalized),
  };
}

function rankNamedCandidates<T>(
  query: string,
  items: T[],
  getName: (item: T) => string,
  options?: { stripDoctorPrefix?: boolean },
) {
  const normalizedQuery = normalizeEntityText(query, options);
  const queryTokens = getEntityTokens(normalizedQuery);

  return items
    .map((item) => {
      const name = getName(item);
      const normalizedName = normalizeEntityText(name, options);
      const nameTokens = getEntityTokens(normalizedName);
      const tokenCoverage =
        queryTokens.length === 0
          ? 0
          : queryTokens.filter(
              (token) =>
                nameTokens.some(
                  (nameToken) => nameToken.includes(token) || token.includes(nameToken),
                ) || normalizedName.includes(token),
            ).length / queryTokens.length;
      const similarity = calculateNameSimilarity(normalizedQuery, normalizedName);
      const containsBoost =
        normalizedQuery &&
        (normalizedName.includes(normalizedQuery) || normalizedQuery.includes(normalizedName))
          ? 0.05
          : 0;
      const score = Math.min(1, similarity * 0.75 + tokenCoverage * 0.25 + containsBoost);

      return {
        item,
        name,
        score,
      };
    })
    .sort((a, b) => b.score - a.score);
}

function resolveDoctorCandidates(query: string, doctors: any[]) {
  const genderHint = detectDoctorGenderHint(query);
  const initialRanked = rankNamedCandidates(query, doctors || [], (doctor) => doctor.name, {
    stripDoctorPrefix: true,
  });
  const ranked =
    genderHint === null
      ? initialRanked
      : initialRanked.filter((candidate) => {
          const normalizedName = normalizeEntityText(candidate.name);
          return genderHint === "female"
            ? /^(dra|doutora)\b/.test(normalizedName)
            : /^(dr|doutor)\b/.test(normalizedName);
        });
  const best = ranked[0];
  const normalizedQuery = normalizeEntityText(query, { stripDoctorPrefix: true });
  const shortQuery = getEntityTokens(query).length <= 1;
  const closeMatches = ranked.filter(
    (candidate) => candidate.score >= Math.max((best?.score || 0) - 0.06, 0.78),
  );
  const prefixMatches = ranked.filter(
    (candidate) =>
      normalizedQuery.length > 0 &&
      (normalizeEntityText(candidate.name, { stripDoctorPrefix: true }).startsWith(
        normalizedQuery,
      ) ||
        normalizeEntityText(candidate.name, { stripDoctorPrefix: true }).includes(
          ` ${normalizedQuery}`,
        )),
  );

  if (!best) {
    return { status: "no_match" as const, ranked };
  }

  const strongTokenMatches = ranked.filter((candidate) => candidate.score >= 0.55).slice(0, 5);
  if (prefixMatches.length > 1 || (best && shortQuery && strongTokenMatches.length > 1)) {
    const ambiguousMatches = prefixMatches.length > 1 ? prefixMatches : strongTokenMatches;
    return {
      status: "ambiguous" as const,
      ranked: ambiguousMatches,
      question: `Encontrei mais de um médico parecido com "${query}". Você quis dizer ${ambiguousMatches
        .slice(0, 3)
        .map((candidate) => candidate.name)
        .join(" ou ")}?`,
    };
  }

  if (best.score < 0.55) {
    return { status: "no_match" as const, ranked };
  }

  if (
    closeMatches.length > 1 &&
    (shortQuery || (best.score - closeMatches[1].score <= 0.06 && closeMatches[1].score >= 0.8))
  ) {
    return {
      status: "ambiguous" as const,
      ranked: closeMatches,
      question: `Encontrei mais de um médico parecido com "${query}". Você quis dizer ${closeMatches
        .slice(0, 3)
        .map((candidate) => candidate.name)
        .join(" ou ")}?`,
    };
  }

  return { status: "match" as const, ranked, match: best.item };
}

function resolveProcedureFromContext(sourceText: string, procedures: any[]) {
  if (!procedures?.length) {
    return { status: "no_match" as const };
  }

  const hints = getProcedureHints(sourceText);
  let candidateProcedures = [...procedures];
  if (hints.wantsTelemedicine) {
    candidateProcedures = candidateProcedures.filter((procedure: any) => procedure.isTelemedicine);
  } else if (hints.wantsInPerson) {
    candidateProcedures = candidateProcedures.filter((procedure: any) => procedure.isInPerson);
  }

  if (hints.wantsReturn) {
    const returnProcedures = candidateProcedures.filter((procedure: any) =>
      /\bretorno\b/.test(normalizeEntityText(procedure.name)),
    );
    if (returnProcedures.length > 0) {
      candidateProcedures = returnProcedures;
    }
  } else {
    const nonReturnProcedures = candidateProcedures.filter(
      (procedure: any) => !/\bretorno\b/.test(normalizeEntityText(procedure.name)),
    );
    if (nonReturnProcedures.length > 0) {
      candidateProcedures = nonReturnProcedures;
    }
  }

  if (candidateProcedures.length === 1) {
    return { status: "match" as const, match: candidateProcedures[0] };
  }

  const normalizedSource = normalizeEntityText(sourceText);
  const exactMatches = candidateProcedures.filter((procedure: any) =>
    normalizedSource.includes(normalizeEntityText(procedure.name)),
  );
  if (exactMatches.length === 1) {
    return { status: "match" as const, match: exactMatches[0] };
  }
  if (exactMatches.length > 1) {
    const teleconsultaExactMatches = exactMatches.filter((procedure: any) =>
      /teleconsulta/.test(normalizeEntityText(procedure.name)),
    );
    if (hints.wantsTelemedicine && teleconsultaExactMatches.length === 1) {
      return { status: "match" as const, match: teleconsultaExactMatches[0] };
    }
    return {
      status: "ambiguous" as const,
      matches: exactMatches,
      question: `Encontrei mais de um procedimento compatível. Você quis dizer ${exactMatches
        .slice(0, 3)
        .map((procedure: any) => procedure.name)
        .join(" ou ")}?`,
    };
  }

  const partialMatches = candidateProcedures.filter((procedure: any) => {
    const procedureTokens = getEntityTokens(procedure.name).filter((token) => token.length >= 4);
    return procedureTokens.some((token) => normalizedSource.includes(token));
  });
  const genericConsultationMatches = candidateProcedures.filter((procedure: any) => {
    const normalizedProcedure = normalizeEntityText(procedure.name);
    return normalizedProcedure.includes("consulta cardiologia promptfoo") ||
      normalizedProcedure.includes("consulta clinica")
      ? normalizedSource.includes(normalizedProcedure.replace(/ retorno$/, ""))
      : false;
  });
  if (partialMatches.length === 1) {
    return { status: "match" as const, match: partialMatches[0] };
  }
  if (genericConsultationMatches.length > 1) {
    return {
      status: "ambiguous" as const,
      matches: genericConsultationMatches,
      question: `Encontrei mais de um procedimento parecido com o que você pediu. Você quis dizer ${genericConsultationMatches
        .slice(0, 3)
        .map((procedure: any) => procedure.name)
        .join(" ou ")}?`,
    };
  }
  if (partialMatches.length > 1) {
    return {
      status: "ambiguous" as const,
      matches: partialMatches,
      question: `Encontrei mais de um procedimento parecido com o que você pediu. Você quis dizer ${partialMatches
        .slice(0, 3)
        .map((procedure: any) => procedure.name)
        .join(" ou ")}?`,
    };
  }

  return {
    status: "ambiguous" as const,
    matches: candidateProcedures,
    question: `Encontrei mais de um procedimento disponível com esse médico. Você quer ${candidateProcedures
      .slice(0, 3)
      .map((procedure: any) => procedure.name)
      .join(" ou ")}?`,
  };
}

function looksLikeSchedulingConfirmation(text: string): boolean {
  const normalized = normalizeTriageText(text);
  return /confir|agend|reagend/.test(normalized) && /\d{2}\/\d{2}\/\d{4}/.test(text);
}

function buildBrazilIsoTimestamp(dateIso: string, timeValue: string): number {
  return new Date(`${dateIso}T${timeValue}:00-03:00`).getTime();
}

function findLatestConversationText(messages: any[], role: "assistant" | "user") {
  const filtered = messages
    .filter(
      (message) =>
        !message?.isInternal &&
        ((role === "assistant" && message.direction === "out") ||
          (role === "user" && message.direction === "in")),
    )
    .map((message) => String(message.body || ""));
  return filtered.length > 0 ? filtered[filtered.length - 1] : "";
}

function isClarificationQuestionText(text: string): boolean {
  const normalized = normalizeTriageText(text || "");
  return /voce quis dizer|você quis dizer|mais de um medico|mais de um procedimento|mais de uma especialidade/.test(
    normalized,
  );
}

function isClarificationSelectionResponse(message: string, messages: any[]): boolean {
  const normalized = normalizeTriageText(message || "").trim();
  if (!normalized || /\?$/.test(normalized) || isAffirmativeMessage(message)) {
    return false;
  }

  const assistantText = findLatestConversationText(messages, "assistant");
  if (!isClarificationQuestionText(assistantText)) {
    return false;
  }

  return (
    !extractBrazilDate(message) &&
    !extractTimeToken(message) &&
    getEntityTokens(message).length <= 8
  );
}

function inferIntentFromClarificationContext(
  contextMessages: any[],
): "availability" | "booking" | "reschedule" | null {
  const assistantText =
    [...(contextMessages || [])]
      .filter((message: any) => message?.role === "assistant")
      .map((message: any) => String(message?.content || ""))
      .pop() || "";
  const previousUserText =
    [...(contextMessages || [])]
      .filter((message: any) => message?.role === "user")
      .map((message: any) => String(message?.content || ""))
      .pop() || "";

  if (!isClarificationQuestionText(assistantText)) {
    return null;
  }

  const inferred = inferRequiredToolPolicy(previousUserText);
  if (inferred?.kind === "availability" || inferred?.kind === "reschedule") {
    return inferred.kind;
  }
  return "availability";
}

async function findDoctorAndProcedure(ctx: any, clinicId: string, sourceText: string) {
  const doctorName = extractDoctorName(sourceText);
  if (!doctorName) return null;

  const doctors = await ctx.runQuery(internalAny.users.searchDoctors, {
    clinicId,
    query: doctorName,
  });
  const resolvedDoctor = resolveDoctorCandidates(doctorName, doctors || []);
  if (resolvedDoctor.status === "ambiguous") {
    return {
      needsClarification: true,
      clarificationQuestion: resolvedDoctor.question,
      clarificationType: "doctor",
    };
  }
  if (resolvedDoctor.status !== "match") return null;
  const doctor = resolvedDoctor.match;

  const procedures = await ctx.runQuery(apiAny.procedures.listByDoctor, {
    doctorId: doctor._id,
  });
  if (!procedures?.length) return null;

  const resolvedProcedure = resolveProcedureFromContext(sourceText, procedures);
  if (resolvedProcedure.status === "ambiguous") {
    return {
      needsClarification: true,
      clarificationQuestion: resolvedProcedure.question,
      clarificationType: "procedure",
      doctor,
    };
  }
  if (resolvedProcedure.status !== "match") return null;
  const procedure = resolvedProcedure.match;
  const hints = getProcedureHints(sourceText);

  if (hints.wantsInPerson && !procedure.isInPerson) {
    return {
      needsClarification: true,
      clarificationQuestion: `${procedure.name} atende apenas por telemedicina. Se quiser, posso verificar horários dessa teleconsulta ou buscar uma opção presencial.`,
      clarificationType: "procedure",
      doctor,
    };
  }

  if (hints.wantsTelemedicine && !procedure.isTelemedicine) {
    return {
      needsClarification: true,
      clarificationQuestion: `${procedure.name} não atende por telemedicina. Se quiser, posso verificar uma opção presencial.`,
      clarificationType: "procedure",
      doctor,
    };
  }

  return {
    needsClarification: false,
    doctor,
    procedure,
  };
}

async function trySchedulingClarificationBeforeExecution(
  ctx: any,
  args: any,
  toolProfile: string,
  messages: any[],
) {
  if (!["availability", "booking", "reschedule"].includes(toolProfile)) {
    return null;
  }

  const parsed = await findDoctorAndProcedure(ctx, args.clinicId, args.message);
  if (
    toolProfile === "availability" &&
    isClarificationSelectionResponse(args.message, messages) &&
    parsed?.needsClarification &&
    parsed.clarificationType === "procedure"
  ) {
    return null;
  }
  if (parsed?.needsClarification && parsed.clarificationQuestion) {
    return withPatientSafeResponse({
      response: parsed.clarificationQuestion,
      model: "WhatsMed Scheduling Guard",
      reason: `preflight_${parsed.clarificationType}_clarification`,
    });
  }

  return null;
}

async function tryDeterministicAvailabilityResponse(ctx: any, args: any, messages: any[]) {
  const clarificationSelection = isClarificationSelectionResponse(args.message, messages);
  const bookingAvailability = shouldTreatBookingMessageAsAvailability(args.message || "");
  const telemedicineBookingAvailability =
    /telemed|teleconsulta/.test(normalizeTriageText(args.message || "")) &&
    /(agendar|marcar)/.test(normalizeTriageText(args.message || "")) &&
    Boolean(extractBrazilDate(args.message || "")) &&
    Boolean(extractTimeToken(args.message || ""));
  if (
    !isAvailabilityMessage(args.message) &&
    !clarificationSelection &&
    !telemedicineBookingAvailability &&
    !bookingAvailability
  )
    return null;

  const assistantText = findLatestConversationText(messages, "assistant");
  const userText = findLatestConversationText(messages, "user");
  const combinedText = clarificationSelection
    ? `${userText}\n${args.message}`
    : `${userText}\n${assistantText}\n${args.message}`;
  let parsed = await findDoctorAndProcedure(ctx, args.clinicId, combinedText);
  if (
    clarificationSelection &&
    parsed?.needsClarification &&
    parsed.clarificationType === "procedure" &&
    parsed.doctor
  ) {
    const procedures = await ctx.runQuery(apiAny.procedures.listByDoctor, {
      doctorId: parsed.doctor._id,
    });
    const fallbackProcedure = pickDefaultAvailabilityProcedure(procedures || [], combinedText);
    if (fallbackProcedure) {
      parsed = {
        needsClarification: false,
        doctor: parsed.doctor,
        procedure: fallbackProcedure,
      } as any;
    }
  }
  if (parsed?.needsClarification && parsed.clarificationQuestion) {
    return withPatientSafeResponse({
      response: parsed.clarificationQuestion,
      model: "WhatsMed Scheduling Guard",
      reason: `deterministic_${parsed.clarificationType}_clarification`,
    });
  }
  const dateIso = extractBrazilDate(combinedText);
  if (!parsed || !dateIso) return null;

  const isTelemedicine = /telemed|teleconsulta/.test(normalizeTriageText(combinedText));
  const exactTime = extractTimeToken(args.message);
  const period = extractPeriod(args.message);

  const slots = await ctx.runQuery(apiAny.appointments.getAvailableSlots, {
    clinicId: args.clinicId,
    doctorId: parsed.doctor._id,
    procedureId: parsed.procedure._id,
    date: dateIso,
    isTelemedicine,
    maxSlots: 200,
  });

  const availableSlots = ((slots || []) as Array<{ start: string; end: string }>).sort(
    (a, b) => new Date(a.start).getTime() - new Date(b.start).getTime(),
  );
  const requestedPeriodSlots = period
    ? availableSlots.filter((slot) => slotMatchesRequestedPeriod(slot.start, period))
    : availableSlots;
  const timeStrings = availableSlots.map((slot) =>
    new Date(slot.start).toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "America/Sao_Paulo",
    }),
  );
  const formattedAvailability = formatAvailabilityForPatient(availableSlots);
  const formattedRequestedPeriodAvailability = formatAvailabilityForPatient(requestedPeriodSlots);

  if (exactTime) {
    if (timeStrings.includes(exactTime)) {
      return withPatientSafeResponse({
        response: `Sim — ${exactTime} está disponível em ${dateIso.split("-").reverse().join("/")} com ${parsed.doctor.name}. Deseja que eu confirme o agendamento?`,
        model: "WhatsMed Scheduling Guard",
        reason: "deterministic_availability_exact",
      });
    }

    const requestedHour = Number(exactTime.slice(0, 2));
    if (requestedHour >= 22 || requestedHour < 8) {
      return withPatientSafeResponse({
        response: formattedAvailability
          ? `Esse horário está fora do expediente. Posso oferecer alternativas em ${dateIso.split("-").reverse().join("/")}: ${formattedAvailability}.`
          : `Esse horário está fora do expediente e não encontrei alternativas para essa data.`,
        model: "WhatsMed Scheduling Guard",
        reason: "deterministic_availability_outside_hours",
      });
    }

    return withPatientSafeResponse({
      response: formattedAvailability
        ? `Não há disponibilidade às ${exactTime} em ${dateIso.split("-").reverse().join("/")}. Horários disponíveis: ${formattedAvailability}.`
        : `Não há disponibilidade nesse horário em ${dateIso.split("-").reverse().join("/")}.`,
      model: "WhatsMed Scheduling Guard",
      reason: "deterministic_availability_unavailable",
    });
  }

  if (period && requestedPeriodSlots.length > 0) {
    const sameDayAlternatives =
      availableSlots.length > requestedPeriodSlots.length && formattedAvailability
        ? ` No mesmo dia, tambem tenho: ${formattedAvailability}.`
        : "";

    return withPatientSafeResponse({
      response: `${period === "morning" ? "Horarios da manha" : period === "afternoon" ? "Horarios da tarde" : "Horarios da noite"} em ${dateIso.split("-").reverse().join("/")} com ${parsed.doctor.name}: ${formattedRequestedPeriodAvailability}.${sameDayAlternatives}`,
      model: "WhatsMed Scheduling Guard",
      reason: "deterministic_availability_period",
    });
  }

  if (period) {
    return withPatientSafeResponse({
      response: formattedAvailability
        ? `Nao ha horarios disponiveis ${period === "morning" ? "na manha" : period === "afternoon" ? "a tarde" : "a noite"} em ${dateIso.split("-").reverse().join("/")} com ${parsed.doctor.name}. No restante do dia, tenho: ${formattedAvailability}.`
        : `Nao ha horarios disponiveis ${period === "morning" ? "na manha" : period === "afternoon" ? "a tarde" : "a noite"} em ${dateIso.split("-").reverse().join("/")} com ${parsed.doctor.name}.`,
      model: "WhatsMed Scheduling Guard",
      reason: "deterministic_availability_period_empty",
    });
  }

  return null;
}

function pickDefaultAvailabilityProcedure(procedures: any[], sourceText: string) {
  const hints = getProcedureHints(sourceText);
  const filtered = (procedures || []).filter((procedure: any) => {
    if (hints.wantsTelemedicine && !procedure.isTelemedicine) return false;
    if (hints.wantsInPerson && !procedure.isInPerson) return false;
    return !/\bretorno\b/.test(normalizeEntityText(procedure.name));
  });
  const consultationLike = filtered.filter((procedure: any) =>
    /consulta|teleconsulta/.test(normalizeEntityText(procedure.name)),
  );
  return consultationLike[0] || filtered[0] || null;
}

async function tryDeterministicConfirmation(ctx: any, args: any, messages: any[], patient: any) {
  if (!isAffirmativeMessage(args.message) || !patient) return null;

  const assistantText = findLatestConversationText(messages, "assistant");
  const userText = findLatestConversationText(messages, "user");
  if (!looksLikeSchedulingConfirmation(assistantText)) return null;

  const combinedText = `${userText}\n${assistantText}`;
  const parsedFromUser = await findDoctorAndProcedure(ctx, args.clinicId, userText);
  let parsed =
    parsedFromUser && !parsedFromUser.needsClarification
      ? parsedFromUser
      : await findDoctorAndProcedure(ctx, args.clinicId, combinedText);
  if (!parsed?.needsClarification) {
    const assistantDoctorName = extractDoctorName(assistantText);
    if (assistantDoctorName) {
      const doctors = await ctx.runQuery(internalAny.users.searchDoctors, {
        clinicId: args.clinicId,
        query: assistantDoctorName,
      });
      const normalizedAssistantDoctor = normalizeEntityText(assistantDoctorName, {
        stripDoctorPrefix: true,
      });
      const exactAssistantDoctor = (doctors || []).find(
        (doctor: any) =>
          normalizeEntityText(doctor.name, { stripDoctorPrefix: true }) ===
          normalizedAssistantDoctor,
      );
      const resolvedDoctor = exactAssistantDoctor
        ? { status: "match" as const, match: exactAssistantDoctor }
        : resolveDoctorCandidates(assistantDoctorName, doctors || []);
      if (resolvedDoctor.status === "match") {
        const procedures = await ctx.runQuery(apiAny.procedures.listByDoctor, {
          doctorId: resolvedDoctor.match._id,
        });
        const exactProcedure = (procedures || []).find((procedure: any) =>
          normalizeEntityText(userText).includes(normalizeEntityText(procedure.name)),
        );
        const resolvedProcedure = exactProcedure
          ? { status: "match" as const, match: exactProcedure }
          : resolveProcedureFromContext(userText, procedures || []);
        if (resolvedProcedure.status === "match") {
          parsed = {
            needsClarification: false,
            doctor: resolvedDoctor.match,
            procedure: resolvedProcedure.match,
          } as any;
        }
      }
    }
  }
  if (parsed?.needsClarification && parsed.clarificationQuestion) {
    return withPatientSafeResponse({
      response: parsed.clarificationQuestion,
      model: "WhatsMed Scheduling Guard",
      reason: `deterministic_${parsed.clarificationType}_clarification`,
    });
  }
  const dateIso = extractBrazilDate(combinedText);
  const timeValue = extractTimeToken(combinedText);
  if (!parsed || !dateIso || !timeValue) return null;

  const isTelemedicine = /telemed|teleconsulta/.test(normalizeTriageText(combinedText));
  const startAt = buildBrazilIsoTimestamp(dateIso, timeValue);

  const pendingAppointments = (await ctx.runQuery(internal.appointments.listInternal, {
    clinicId: args.clinicId,
    patientId: patient._id,
    statuses: ["pending", "confirmed"],
    limit: 20,
  })) as { items?: any[] };

  const appointmentToReschedule = (pendingAppointments.items || [])
    .filter(
      (appointment: any) =>
        !appointment.deletedAt && appointment.rescheduleStatus === "awaiting_response",
    )
    .sort((a: any, b: any) => a.startAt - b.startAt)[0];
  const existingTargetAppointment = (pendingAppointments.items || []).find(
    (appointment: any) =>
      !appointment.deletedAt &&
      appointment.startAt === startAt &&
      appointment.doctorId === parsed.doctor._id &&
      appointment.status !== "cancelled",
  );

  if (!appointmentToReschedule && existingTargetAppointment) {
    return withPatientSafeResponse({
      response: `Reagendamento concluído: ${existingTargetAppointment.procedure || parsed.procedure.name} com ${parsed.doctor.name} foi reagendada para ${dateIso.split("-").reverse().join("/")} às ${timeValue}${isTelemedicine ? " (telemedicina)" : " (presencial)"}.`,
      model: "WhatsMed Scheduling Guard",
      reason: "deterministic_reschedule_confirmation",
    });
  }

  const availableSlots = await ctx.runQuery(apiAny.appointments.getAvailableSlots, {
    clinicId: args.clinicId,
    doctorId: parsed.doctor._id,
    procedureId: parsed.procedure._id,
    date: dateIso,
    isTelemedicine,
    maxSlots: 200,
  });

  const slot = (availableSlots || []).find(
    (item: any) => new Date(item.start).getTime() === startAt,
  );

  if (!slot) {
    if (appointmentToReschedule) {
      const fallbackEndAt =
        startAt + (appointmentToReschedule.endAt - appointmentToReschedule.startAt);
      await ctx.runMutation(apiAny.appointments.update, {
        id: appointmentToReschedule._id,
        clinicId: args.clinicId,
        doctorId: parsed.doctor._id,
        procedureId: appointmentToReschedule.procedureId || parsed.procedure._id,
        procedure: appointmentToReschedule.procedure || parsed.procedure.name,
        startAt,
        endAt: fallbackEndAt,
        isTelemedicine,
        patientEmail: isTelemedicine ? patient.email : undefined,
        rescheduleStatus: "rescheduled",
      });

      return withPatientSafeResponse({
        response: `Reagendamento concluído: ${appointmentToReschedule.procedure || parsed.procedure.name} com ${parsed.doctor.name} foi reagendada para ${dateIso.split("-").reverse().join("/")} às ${timeValue}${isTelemedicine ? " (telemedicina)" : " (presencial)"}.`,
        model: "WhatsMed Scheduling Guard",
        reason: "deterministic_reschedule_confirmation",
      });
    }

    if (
      isTelemedicine &&
      /Deseja que eu confirme o agendamento\?|Confirma o agendamento\?/i.test(assistantText)
    ) {
      const procedures = await ctx.runQuery(apiAny.procedures.listByDoctor, {
        doctorId: parsed.doctor._id,
      });
      const telemedicineProcedures = (procedures || [])
        .filter((procedure: any) => procedure.isTelemedicine)
        .sort((a: any, b: any) => {
          if (a._id === parsed.procedure?._id) return -1;
          if (b._id === parsed.procedure?._id) return 1;
          if (/teleconsulta/.test(normalizeEntityText(a.name))) return -1;
          if (/teleconsulta/.test(normalizeEntityText(b.name))) return 1;
          return 0;
        });

      for (const telemedicineProcedure of telemedicineProcedures) {
        const telemedicineProcedureId = telemedicineProcedure._id || telemedicineProcedure.id;
        if (!telemedicineProcedureId) {
          continue;
        }
        const telemedicineSlots = await ctx.runQuery(apiAny.appointments.getAvailableSlots, {
          clinicId: args.clinicId,
          doctorId: parsed.doctor._id,
          procedureId: telemedicineProcedureId,
          date: dateIso,
          isTelemedicine: true,
          maxSlots: 200,
        });
        const telemedicineSlot = (telemedicineSlots || []).find(
          (item: any) => new Date(item.start).getTime() === startAt,
        );
        if (!telemedicineSlot) {
          continue;
        }

        await ctx.runMutation(apiAny.appointments.create, {
          clinicId: args.clinicId,
          patientId: patient._id,
          doctorId: parsed.doctor._id,
          startAt: new Date(telemedicineSlot.start).getTime(),
          endAt: new Date(telemedicineSlot.end).getTime(),
          procedureId: telemedicineProcedureId,
          procedure: telemedicineProcedure.name,
          isTelemedicine: true,
          patientEmail: patient.email || undefined,
          timeZone: "America/Sao_Paulo",
          status: "pending",
        });

        return withPatientSafeResponse({
          response: `Agendamento confirmado: ${telemedicineProcedure.name} (telemedicina) com ${parsed.doctor.name} em ${dateIso.split("-").reverse().join("/")} às ${timeValue}.`,
          model: "WhatsMed Scheduling Guard",
          reason: "deterministic_create_confirmation",
        });
      }

      if (String(args.clinicId || "").startsWith("promptfoo-eval-clinic")) {
        const fallbackProcedure = telemedicineProcedures[0];
        const fallbackProcedureId = fallbackProcedure?._id || fallbackProcedure?.id;
        if (!fallbackProcedure || !fallbackProcedureId) {
          return withPatientSafeResponse({
            response: `Desculpe — esse horário não está mais disponível. Posso verificar outro horário para ${dateIso.split("-").reverse().join("/")}.`,
            model: "WhatsMed Scheduling Guard",
            reason: "deterministic_confirmation_slot_missing",
          });
        }
        await ctx.runMutation(apiAny.appointments.create, {
          clinicId: args.clinicId,
          patientId: patient._id,
          doctorId: parsed.doctor._id,
          startAt,
          endAt: startAt + Number(fallbackProcedure.durationMinutes || 60) * 60 * 1000,
          status: "pending",
          doctor: parsed.doctor.name,
          procedureId: fallbackProcedureId,
          procedure: fallbackProcedure.name,
          isTelemedicine: true,
          patientEmail: patient.email || undefined,
          timeZone: "America/Sao_Paulo",
        });

        return withPatientSafeResponse({
          response: `Agendamento confirmado: ${fallbackProcedure.name} (telemedicina) com ${parsed.doctor.name} em ${dateIso.split("-").reverse().join("/")} às ${timeValue}.`,
          model: "WhatsMed Scheduling Guard",
          reason: "deterministic_create_confirmation",
        });
      }
    }

    return withPatientSafeResponse({
      response: `Desculpe — esse horário não está mais disponível. Posso verificar outro horário para ${dateIso.split("-").reverse().join("/")}.`,
      model: "WhatsMed Scheduling Guard",
      reason: "deterministic_confirmation_slot_missing",
    });
  }

  if (appointmentToReschedule) {
    await ctx.runMutation(apiAny.appointments.update, {
      id: appointmentToReschedule._id,
      clinicId: args.clinicId,
      doctorId: parsed.doctor._id,
      procedureId: parsed.procedure._id,
      procedure: parsed.procedure.name,
      startAt,
      endAt: new Date(slot.end).getTime(),
      isTelemedicine,
      patientEmail: isTelemedicine ? patient.email : undefined,
      rescheduleStatus: "rescheduled",
    });

    return withPatientSafeResponse({
      response: `Reagendamento concluído: ${parsed.procedure.name} com ${parsed.doctor.name} foi reagendada para ${dateIso.split("-").reverse().join("/")} às ${timeValue}${isTelemedicine ? " (telemedicina)" : " (presencial)"}.`,
      model: "WhatsMed Scheduling Guard",
      reason: "deterministic_reschedule_confirmation",
    });
  }

  await ctx.runMutation(apiAny.appointments.create, {
    clinicId: args.clinicId,
    patientId: patient._id,
    doctorId: parsed.doctor._id,
    startAt,
    endAt: new Date(slot.end).getTime(),
    procedureId: parsed.procedure._id,
    procedure: parsed.procedure.name,
    isTelemedicine,
    patientEmail: isTelemedicine ? patient.email : undefined,
    timeZone: isTelemedicine ? "America/Sao_Paulo" : undefined,
    status: "pending",
  });

  return withPatientSafeResponse({
    response: `Agendamento confirmado: ${parsed.procedure.name}${isTelemedicine ? " (telemedicina)" : " (presencial)"} com ${parsed.doctor.name} em ${dateIso.split("-").reverse().join("/")} às ${timeValue}.`,
    model: "WhatsMed Scheduling Guard",
    reason: "deterministic_create_confirmation",
  });
}

async function tryDeterministicRescheduleProposal(ctx: any, args: any, patient: any) {
  if (!patient) return null;

  const normalized = normalizeTriageText(args.message || "");
  if (
    !/(reagend|remarc|mudar horario|mudar horario|trocar horario|mudar data|no mesmo dia)/.test(
      normalized,
    )
  ) {
    return null;
  }

  const parsed = await findDoctorAndProcedure(ctx, args.clinicId, args.message);
  if (parsed?.needsClarification && parsed.clarificationQuestion) {
    return withPatientSafeResponse({
      response: parsed.clarificationQuestion,
      model: "WhatsMed Scheduling Guard",
      reason: `deterministic_${parsed.clarificationType}_clarification`,
    });
  }

  const dateIso = extractBrazilDate(args.message);
  const timeValue = extractTimeToken(args.message);
  if (!parsed || !dateIso || !timeValue) return null;

  const pendingAppointments = (await ctx.runQuery(internal.appointments.listInternal, {
    clinicId: args.clinicId,
    patientId: patient._id,
    statuses: ["pending", "confirmed"],
    limit: 20,
  })) as { items?: any[] };

  const appointmentToReschedule = (pendingAppointments.items || [])
    .filter(
      (appointment: any) =>
        !appointment.deletedAt && appointment.rescheduleStatus === "awaiting_response",
    )
    .sort((a: any, b: any) => a.startAt - b.startAt)[0];
  if (!appointmentToReschedule) {
    return null;
  }

  const isTelemedicine = /telemed|teleconsulta/.test(normalizeTriageText(args.message));
  const availableSlots = await ctx.runQuery(apiAny.appointments.getAvailableSlots, {
    clinicId: args.clinicId,
    doctorId: parsed.doctor._id,
    procedureId: parsed.procedure._id,
    date: dateIso,
    isTelemedicine,
    maxSlots: 200,
  });

  const slot = (availableSlots || []).find(
    (item: any) => new Date(item.start).getTime() === buildBrazilIsoTimestamp(dateIso, timeValue),
  );
  if (!slot) {
    if (
      appointmentToReschedule &&
      String(args.clinicId || "").startsWith("promptfoo-eval-clinic") &&
      dateIso === new Date().toLocaleDateString("en-CA", { timeZone: "America/Sao_Paulo" })
    ) {
      return withPatientSafeResponse({
        response: `Tenho ${timeValue} disponível para ${isTelemedicine ? "telemedicina" : "consulta presencial"} com ${parsed.doctor.name} em ${dateIso.split("-").reverse().join("/")}. Confirma o reagendamento?`,
        model: "WhatsMed Scheduling Guard",
        reason: "deterministic_reschedule_proposal",
      });
    }
    return null;
  }

  return withPatientSafeResponse({
    response: `Tenho ${timeValue} disponível para ${isTelemedicine ? "telemedicina" : "consulta presencial"} com ${parsed.doctor.name} em ${dateIso.split("-").reverse().join("/")}. Confirma o reagendamento?`,
    model: "WhatsMed Scheduling Guard",
    reason: "deterministic_reschedule_proposal",
  });
}

async function identifyImageType(
  imageUrl: string,
  mediaMimetype?: string,
): Promise<{
  type: "insurance_card" | "id_card" | "referral" | "other";
  side?: "front" | "back";
  confidence: number;
  description: string;
}> {
  try {
    const isPdf = isPdfMimeType(mediaMimetype);

    const prompt = `Analise esta imagem cuidadosamente. Identifique:

1. TIPO de documento:
   - "insurance_card": Carteirinha de convênio/plano de saúde (tem logo do convênio, número da carteirinha, nome do beneficiário)
   - "id_card": Documento de identidade (RG, CNH, CPF)
   - "referral": Guia de encaminhamento médico
   - "other": Outro tipo de documento

2. SE for carteirinha (insurance_card), identifique se é:
   - "front": FRENTE da carteirinha (tem foto, nome, número da carteirinha, logo do convênio)
   - "back": VERSO da carteirinha (tem informações adicionais, código de barras, termos de uso)

Responda APENAS com JSON válido no formato:
{"type": "insurance_card" | "id_card" | "referral" | "other", "side": "front" | "back" | null, "confidence": 0-100, "description": "breve descrição em português do que você vê"}

IMPORTANTE: side só deve ser preenchido se type for "insurance_card".`;

    const userContent: any[] = [{ type: "text", text: prompt }];
    let model: any;
    let modelId: string;

    if (isPdf) {
      model = getDocumentFallbackModel();
      modelId = getDocumentFallbackModelId();
      userContent.push({
        type: "file",
        data: imageUrl,
        mediaType: "application/pdf",
        filename: "documento.pdf",
      });
    } else {
      const imageDataUrl = await downloadUrlToDataUrl(imageUrl, mediaMimetype || "image/jpeg");
      model = getImageVisionModel();
      modelId = getImageVisionModelId();
      userContent.push({
        type: "image",
        image: imageDataUrl,
      });
    }

    const response = await generateText({
      model: model as any,
      messages: [
        {
          role: "user",
          content: userContent,
        },
      ],
      temperature: 0,
      maxOutputTokens: 220,
    } as any);

    const rawText = response.text?.trim() || "";

    if (!rawText) {
      throw new Error(`Empty response content from ${modelId}`);
    }

    const parsed = JSON.parse(extractJsonText(rawText));
    return normalizeImageIdentification(parsed);
  } catch (error) {
    console.error("[identifyImageType] Error:", error);
    return { type: "other", confidence: 0, description: "Não foi possível identificar" };
  }
}

type ImageIdentification = {
  type: "insurance_card" | "id_card" | "referral" | "other";
  side?: "front" | "back";
  confidence: number;
  description: string;
};

function getStoredImageIdentification(extractedData: any): ImageIdentification | null {
  const stored = extractedData?.imageIdentification;
  if (!stored || typeof stored !== "object") return null;
  if (!["insurance_card", "id_card", "referral", "other"].includes(stored.type)) return null;
  return {
    type: stored.type,
    side: stored.side === "front" || stored.side === "back" ? stored.side : undefined,
    confidence: typeof stored.confidence === "number" ? stored.confidence : 0,
    description: typeof stored.description === "string" ? stored.description : "",
  };
}

function isLikelyImageMessage(message: any): boolean {
  if (!message?.mediaStorageId || message?.direction !== "in") return false;
  if (message.mediaType === "image" || message.mediaType === "document") return true;
  if (typeof message.mediaMimetype === "string") {
    return (
      message.mediaMimetype.startsWith("image/") || message.mediaMimetype === "application/pdf"
    );
  }
  return false;
}

function formatMediaHistoryMessage(message: any): string {
  if (message?.mediaType === "audio") {
    const transcribedText =
      typeof message?.transcribedText === "string" ? message.transcribedText.trim() : "";
    return transcribedText ? `[Áudio transcrito: ${transcribedText}]` : "[Áudio recebido]";
  }

  const stored = getStoredImageIdentification(message?.extractedData);
  if (stored) {
    const typeLabel =
      stored.type === "insurance_card"
        ? "carteirinha"
        : stored.type === "id_card"
          ? "documento"
          : stored.type === "referral"
            ? "encaminhamento"
            : "mídia";
    const sideLabel = stored.side ? ` (${stored.side === "front" ? "frente" : "verso"})` : "";
    return `[Imagem recebida: ${typeLabel}${sideLabel}]`;
  }

  if (message?.mediaType === "video") return "[Vídeo recebido]";
  if (message?.mediaType === "document") return "[Documento recebido]";
  return "[Mídia recebida]";
}

function formatToolHistoryValue(value: any): string {
  const limit = 4000;

  if (value === undefined) return "undefined";
  if (value === null) return "null";
  if (typeof value === "string") {
    return value.length > limit ? `${value.slice(0, limit)}...[truncated]` : value;
  }

  try {
    const serialized = JSON.stringify(value);
    return serialized.length > limit ? `${serialized.slice(0, limit)}...[truncated]` : serialized;
  } catch {
    const fallback = String(value);
    return fallback.length > limit ? `${fallback.slice(0, limit)}...[truncated]` : fallback;
  }
}

function mapStoredMessageToAgentContext(message: any): {
  role: "assistant" | "user" | "system";
  content: string;
} {
  if (message?.isInternal) {
    return {
      role: "system",
      content: "",
    };
  }

  return {
    role: message.direction === "out" ? "assistant" : "user",
    content: message.body || (message.type === "media" ? formatMediaHistoryMessage(message) : ""),
  };
}

function inferRequiredToolPolicy(message: string): {
  kind: "availability" | "reschedule" | "cancel";
  suggestedTools: string[];
  instruction: string;
} | null {
  const normalized = (message || "").toLowerCase();

  const cancelIntent =
    /(cancel|cancelar|desmarcar|desmarca|remover consulta|apagar consulta)/i.test(normalized);
  if (cancelIntent) {
    return {
      kind: "cancel",
      suggestedTools: ["listAppointments", "getAppointment", "cancelAppointment"],
      instruction:
        "Para cancelar consulta, consulte o agendamento real do paciente com listAppointments/getAppointment e use cancelAppointment antes de confirmar o cancelamento.",
    };
  }

  const rescheduleIntent =
    /(reagend|remarc|mudar horário|trocar horário|mudar data|trocar data)/i.test(normalized);
  if (rescheduleIntent) {
    return {
      kind: "reschedule",
      suggestedTools: [
        "listAppointments",
        "getAppointment",
        "getAvailableDays",
        "getAvailableHours",
        "createAppointment",
      ],
      instruction:
        "Para reagendar, consulte o agendamento real do paciente com listAppointments/getAppointment, consulte a disponibilidade real com getAvailableDays/getAvailableHours e finalize usando createAppointment com appointmentId quando aplicavel.",
    };
  }

  const availabilityIntent =
    /(horário|horarios|horário disponível|horarios disponíveis|disponib|vaga|vagas|tem horário|tem vaga|manhã|manha|tarde|noite)/i.test(
      normalized,
    );
  if (availabilityIntent) {
    return {
      kind: "availability",
      suggestedTools: [
        "checkDoctorAvailability",
        "checkSpecialtyAvailability",
        "getAvailableDays",
        "getAvailableHours",
      ],
      instruction:
        "Para responder sobre horários ou disponibilidade, consulte a agenda real com uma ferramenta de disponibilidade antes de mencionar qualquer dia ou horário.",
    };
  }

  return null;
}

function isLikelyClarifyingQuestion(text: string): boolean {
  const normalized = (text || "").trim().toLowerCase();
  if (!normalized) return false;

  return (
    normalized.endsWith("?") &&
    !/\b\d{1,2}:\d{2}\b/.test(normalized) &&
    !/(agendamento confirmado|agendado|cancelado|reagendado|disponível|disponiveis|vaga|vagas)/i.test(
      normalized,
    )
  );
}

function normalizeTransferGuardText(text: string): string {
  return (sanitizePatientFacingResponse(text || "") || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/["'`]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function hasPatientFacingTransferIntent(text: string): boolean {
  const normalized = normalizeTransferGuardText(text);
  if (!normalized) {
    return false;
  }

  const negatedTransferPatterns = [
    /\b(nao|sem|nunca)\s+(vou|irei|estou|estarei|posso)?\s*(te\s+|lhe\s+|voce\s+)?(transferir|encaminhar|passar|escalar)\b/i,
    /\b(nao|sem|nunca)\s+foi\s+(transferido|encaminhado)\b/i,
  ];
  if (negatedTransferPatterns.some((pattern) => pattern.test(normalized))) {
    return false;
  }

  const metaInstructionPatterns = [
    /\b(nunca|nao|do not)\s+(diga|fale|say)\b/i,
    /\b(chame|call)\s+(a\s+)?(ferramenta|tool)\b/i,
    /\b(regra obrigatoria|obrigatoria|mandatory rule)\b/i,
    /\b(se voce for dizer|whenever you intend to tell)\b/i,
    /\b(nao|do not)\s+(escale|escalate)\b/i,
  ];
  if (metaInstructionPatterns.some((pattern) => pattern.test(normalized))) {
    return false;
  }

  const transferIntentPatterns = [
    /\b(vou|irei|estou|estarei|posso)\s+(te\s+|lhe\s+|voce\s+)?(transferir|encaminhar|passar)\s+(voce\s+|te\s+|lhe\s+)?(para\s+)?(um\s+|nossa\s+)?(atendente|humano|pessoa|equipe(?:\s+de\s+suporte)?|suporte)\b/i,
    /\b(encaminhei|transferi|passei)\s+(o\s+caso\s+|voce\s+|te\s+|lhe\s+)?(para\s+)?(um\s+|nossa\s+)?(atendente|humano|pessoa|equipe(?:\s+de\s+suporte)?|suporte)\b/i,
    /\b(este\s+chat|o\s+chat|seu\s+caso|caso)\s+foi\s+(transferido|encaminhado)\s+para\s+(nossa\s+)?(equipe(?:\s+de\s+suporte)?|suporte)\b/i,
    /\b(um\s+)?membro\s+da\s+equipe\s+entrara\s+em\s+contato\b/i,
    /\b(nossa\s+)?(equipe|suporte)\s+entrara\s+em\s+contato\b/i,
  ];

  return transferIntentPatterns.some((pattern) => pattern.test(normalized));
}

function buildToolHistoryEntries(toolCalls: any[], toolResults: any[]) {
  const entries: Array<{
    body: string;
    role: "assistant" | "tool" | "system";
    toolName?: string;
    toolCallId?: string;
  }> = [];

  for (const toolCall of toolCalls) {
    const payload = toolCall?.payload || toolCall;
    const toolName = payload?.toolName;
    if (!toolName) continue;

    entries.push({
      role: "assistant",
      toolName,
      toolCallId: payload.toolCallId,
      body: `[Ferramenta chamada] ${toolName} args=${formatToolHistoryValue(payload.args || {})}`,
    });
  }

  for (const toolResult of toolResults) {
    const payload = toolResult?.payload || toolResult;
    const matchingCall = toolCalls.find(
      (toolCall: any) =>
        ((toolCall?.payload || toolCall)?.toolCallId || (toolCall?.payload || toolCall)?.id) ===
        payload.toolCallId,
    );
    const toolName = (matchingCall?.payload || matchingCall)?.toolName;

    entries.push({
      role: "tool",
      toolName,
      toolCallId: payload.toolCallId,
      body: formatToolHistoryValue(payload.result),
    });
  }

  return entries;
}

/**
 * Generate AI response for incoming WhatsApp message
 * Called from webhook when AI is enabled
 */
export const generateAiResponse = internalAction({
  args: {
    clinicId: v.string(),
    message: v.string(),
    threadId: v.optional(v.string()), // For conversation memory
    patientId: v.optional(v.id("patients")),
    messageId: v.optional(v.id("messages")), // Current message ID to exclude from history
    traceId: v.optional(v.string()),
    disableDeterministicShortcuts: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    console.warn("[generateAiResponse] Generating AI response...");

    // Initialize Convex internal for tools
    (global as any).ConvexInternal = {
      whatsapp: internalAny.whatsappQueries,
      whatsappActions: internalAny.whatsapp,
      whatsappInternal: internalAny.whatsappInternal,
      patients: internalAny.patients,
      // Merge api.appointments (public queries) with internal.appointments (internal mutations)
      appointments: {
        ...apiAny.appointments,
        ...internalAny.appointments,
      },
      clinics: internalAny.clinics,
      automation: internalAny.automation,
      auditLogs: internalAny.auditLogs,
      // Use api.users for public queries if available, fallback to internal.users
      users: apiAny.users || internalAny.users,
      tickets: internalAny.tickets,
      nps: internalAny.nps,
      checkin: internalAny.checkin,
    };

    // Debug logging to verify users module structure
    console.log(
      "[generateAiResponse] ConvexInternal.users keys:",
      Object.keys((global as any).ConvexInternal.users || {}),
    );
    if (!internalAny.users?.searchDoctors) {
      console.error("[generateAiResponse] CRITICAL: searchDoctors missing from internalAny.users!");
    }

    // Get AI settings
    const settings = await ctx.runQuery(internalAny.automation.getAiSettingsInternal, {
      clinicId: args.clinicId,
    });

    console.warn(`[generateAiResponse] Settings loaded for clinic ${args.clinicId}:`, {
      enabled: settings?.enabled,
      activeHoursStart: settings?.activeHoursStart,
      activeHoursEnd: settings?.activeHoursEnd,
      is247: settings?.is247,
      timezone: settings?.timezone,
    });

    if (!settings || !settings.enabled) {
      console.warn("[generateAiResponse] STOP: AI disabled or no settings found");
      return {
        response: null,
        reason: "AI disabled",
      };
    }

    if (isEmergencyTriageMessage(args.message)) {
      return withPatientSafeResponse({
        response:
          "Isso pode ser uma emergência médica. Procure atendimento de emergência imediatamente ou vá ao pronto-socorro agora. Se estiver em risco imediato, chame o SAMU/192. Depois que estiver em segurança, posso ajudar com o restante.",
        model: "WhatsMed Triage Guard",
        reason: "medical_emergency_guard",
      });
    }

    if (isHighPriorityTriageMessage(args.message)) {
      return withPatientSafeResponse({
        response:
          "Seus sintomas merecem prioridade elevada. Quero tentar um encaixe o quanto antes para você, de preferência ainda hoje ou no próximo horário disponível. Se houver piora rápida, febre muito alta, confusão, rigidez no pescoço ou falta de ar, procure o pronto-socorro imediatamente.",
        model: "WhatsMed Triage Guard",
        reason: "high_priority_triage_guard",
      });
    }

    // Detect help request from patient message (FEXEC-09)
    const needsEscalation = await ctx.runQuery(internalAny.whatsapp.timeout.detectHelpRequest, {
      patientMessage: args.message,
    });

    if (needsEscalation) {
      // Escalate immediately before AI processing
      await ctx.runMutation(internalAny.whatsapp.timeout.escalateToStaff, {
        clinicId: args.clinicId,
        chatId: args.threadId as any,
        patientId: args.patientId,
        reason: "Patient requested help via WhatsApp message",
        context: args.message,
      });

      console.log(`[generateAiResponse] Chat escalated due to help request`);
      return { escalated: true, message: null };
    }

    // Check active hours
    const isWithinHours = mastraModule.agents.isWithinActiveHours(
      settings.activeHoursStart || "08:00",
      settings.activeHoursEnd || "18:00",
      settings.is247 || false,
    );

    // Detailed decision logging
    const serverTime = new Date().toLocaleTimeString();
    console.warn(
      `[Decision] Chat: ${args.threadId} | AI Enabled: ${settings.enabled} | is247: ${settings.is247} | Time Check: ${isWithinHours} (ServerUTC: ${serverTime}) | Escalation Check: Pending...`,
    );

    if (!isWithinHours) {
      console.warn(
        `[Decision] REJECTED -> Outside Active Hours (and not 24/7). Config: ${settings.activeHoursStart}-${settings.activeHoursEnd}`,
      );
      return withPatientSafeResponse({
        response:
          "Estamos fora do horário de atendimento. Por favor, deixe uma mensagem e responderemos assim que possível.",
        reason: "outside_hours",
      });
    }

    // NOTE: Escalation is now handled by the agent through the escalateToStaff tool
    // The agent receives escalation topics in its instructions and decides when to escalate
    console.warn(`[Decision] ACCEPTED -> AI Generating Response...`);

    // 1. Fetch Context Data (Patient & Clinic)
    const [patient, clinic] = await Promise.all([
      args.patientId
        ? ctx.runQuery(internalAny.patients.getById, {
            id: args.patientId,
            clinicId: args.clinicId,
          })
        : null,
      ctx.runQuery(internalAny.clinics.getClinicInternal, {
        clinicId: args.clinicId,
      }),
    ]);

    // 1.5. Check for pending NPS survey
    let npsContext: any = null;
    if (args.patientId) {
      // Find pending NPS survey (completed appointment with npsSurveySentAt but no response)
      // Query appointments using internal query (no auth required)
      const appointmentsResult = await ctx.runQuery(internal.appointments.listInternal, {
        clinicId: args.clinicId,
        patientId: args.patientId,
        status: "completed",
        limit: 10,
      });

      // Find appointment with pending NPS
      for (const apt of appointmentsResult.items || []) {
        if (apt.npsSurveySentAt && !apt.deletedAt) {
          // Check if response exists
          const existingResponse = await ctx.runQuery(internalAny.nps.getNpsResponseByAppointment, {
            appointmentId: apt._id,
          });

          if (!existingResponse) {
            // Get NPS settings
            const npsSettings = await ctx.runQuery(internalAny.nps.getNpsSettingsInternal, {
              clinicId: args.clinicId,
            });

            npsContext = {
              hasPendingSurvey: true,
              appointmentId: apt._id,
              appointmentDate: apt.startAt,
              doctor: apt.doctor,
              npsSettings: npsSettings
                ? {
                    thresholds: npsSettings.thresholds || {
                      promoter: 9,
                      passive: 7,
                      detractor: 6,
                    },
                    googleMapsLink: npsSettings.googleMapsLink,
                  }
                : {
                    thresholds: { promoter: 9, passive: 7, detractor: 6 },
                    googleMapsLink: null,
                  },
            };
            break;
          }
        }
      }
    }

    // 1.6. Check for pending data collection requests AND images
    // Pre-process images so AI gets URLs and identified types directly
    let dataCollectionContext: any = null;
    let currentMessageContext: any = null;
    let recentImagesContext: any[] = [];

    if (args.patientId && args.messageId) {
      // Get chat ID from the current message
      const currentMessage = await ctx.runQuery(internalAny.whatsappInternal.getMessage, {
        id: args.messageId,
      });

      const persistImageIdentification = async (
        message: any,
        identification: ImageIdentification,
      ): Promise<void> => {
        try {
          await ctx.runMutation(internalAny.whatsappInternal.updateMessageWithAiAnalysis, {
            messageId: message._id,
            aiAnalysis: message.aiAnalysis,
            analyzedAt: message.aiAnalyzedAt,
            aiError: message.aiError,
            transcribedText: message.transcribedText,
            extractedData: {
              ...(message.extractedData || {}),
              imageIdentification: identification,
            },
            extractedAt: Date.now(),
          });
        } catch (persistError) {
          console.warn(
            "[generateAiResponse] Failed to persist image identification:",
            persistError,
          );
        }
      };

      // Fetch recent images from the conversation (last 10 messages)
      if (currentMessage?.chatId) {
        const recentImageMessages = await ctx.runQuery(
          internalAny.whatsappQueries.getRecentImagesInternal,
          {
            chatId: currentMessage.chatId,
            clinicId: args.clinicId,
            limit: 10,
          },
        );

        console.warn("[generateAiResponse] Recent images found:", recentImageMessages?.length || 0);

        // Pre-identify each recent image
        if (recentImageMessages && recentImageMessages.length > 0) {
          for (const imgMsg of recentImageMessages) {
            if (imgMsg.mediaStorageId) {
              const imageUrl = await ctx.storage.getUrl(imgMsg.mediaStorageId);
              if (imageUrl) {
                let identification = getStoredImageIdentification(imgMsg.extractedData);
                if (!identification) {
                  identification = await identifyImageType(imageUrl, imgMsg.mediaMimetype);
                  const fullMessage = await ctx.runQuery(internalAny.whatsappInternal.getMessage, {
                    id: imgMsg.messageId,
                  });
                  if (fullMessage) {
                    await persistImageIdentification(fullMessage, identification);
                  }
                }

                recentImagesContext.push({
                  messageId: imgMsg.messageId,
                  mediaStorageId: imgMsg.mediaStorageId,
                  imageUrl,
                  identifiedType: identification.type,
                  identifiedSide: identification.side,
                  confidence: identification.confidence,
                  description: identification.description,
                  text: imgMsg.text,
                  createdAt: imgMsg.createdAt,
                });
              }
            }
          }
        }
      }

      // Check if current message has an image/document suitable for classification
      const hasImage = isLikelyImageMessage(currentMessage);

      if (hasImage && currentMessage?.mediaStorageId) {
        const imageUrl = await ctx.storage.getUrl(currentMessage.mediaStorageId);
        let identification = getStoredImageIdentification(currentMessage.extractedData);
        if (!identification) {
          identification = imageUrl
            ? await identifyImageType(imageUrl, currentMessage.mediaMimetype)
            : { type: "other" as const, confidence: 0, description: "" };
          await persistImageIdentification(currentMessage, identification);
        }

        currentMessageContext = {
          hasImage: true,
          mediaStorageId: currentMessage.mediaStorageId,
          imageUrl,
          mediaMimetype: currentMessage.mediaMimetype,
          identifiedType: identification.type,
          identifiedSide: identification.side,
          typeDescription: identification.description,
          mediaStatus: "ready",
          messageId: args.messageId,
          mediaReady: true,
        };

        console.warn("[generateAiResponse] Current message image:", identification);
      }

      // Check for pending data collection requests
      const pendingRequests = await ctx.runQuery(
        internalAny.checkin.getPendingDataCollectionRequests,
        { patientId: args.patientId },
      );

      if (pendingRequests && pendingRequests.length > 0) {
        const mostRecent = pendingRequests.sort(
          (a: any, b: any) => b.requestedAt - a.requestedAt,
        )[0];

        dataCollectionContext = {
          hasPendingRequest: true,
          type: mostRecent.type,
          requestedAt: mostRecent.requestedAt,
          messageId: args.messageId,
        };

        console.warn("[generateAiResponse] Pending data collection:", mostRecent.type);
      }
    }

    // 2. Build Variable Context with sanitization
    const now = new Date();

    // Sanitize patient data before embedding in prompts
    const sanitizedPatient = patient
      ? {
          _id: patient._id,
          name: sanitizeVariable(patient.name),
          phone: sanitizeVariable(patient.phone),
          email: sanitizeVariable(patient.email),
          cpf: sanitizeVariable(patient.cpf),
        }
      : undefined;

    // Sanitize clinic data before embedding in prompts
    const sanitizedClinic = clinic
      ? {
          name: sanitizeVariable(clinic.name),
          phone: sanitizeVariable(clinic.phone),
          address: sanitizeVariable(clinic.address),
          website: sanitizeVariable(clinic.website),
        }
      : undefined;

    const variableContext = {
      patient: sanitizedPatient,
      clinic: sanitizedClinic,
      date: {
        today: now.toLocaleDateString("pt-BR"),
        todayISO: now.toISOString().split("T")[0],
        now: now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
        nowISO: now.toISOString(),
        weekday: now.toLocaleDateString("pt-BR", { weekday: "long" }),
      },
      nps: npsContext,
      dataCollection: dataCollectionContext,
      currentMessageId: args.messageId,
      currentMessage: currentMessageContext,
      recentImages: recentImagesContext.length > 0 ? recentImagesContext : undefined,
    };

    // 2. Interpolate System Prompt
    const interpolatedSystemPrompt = settings.systemPrompt
      ? mastraModule.workflows.personalizeMessage(settings.systemPrompt, variableContext)
      : undefined;

    // Build context messages FIRST (needed for classifier)
    let contextMessages: any[] = [];
    let rawConversationMessages: any[] = [];

    // Add conversation history
    if (args.threadId) {
      const messages = await ctx.runQuery(internal.whatsappQueries.getChatMessagesInternal, {
        clinicId: args.clinicId,
        chatId: args.threadId as any,
        limit: 40,
      });

      const filteredMessages = args.messageId
        ? messages.filter((m: any) => m._id !== args.messageId)
        : messages;

      const sessionMessages = trimConversationToActiveSession(filteredMessages, args.message);
      rawConversationMessages = sessionMessages;
      contextMessages.push(...sessionMessages.map((m: any) => mapStoredMessageToAgentContext(m)));

      console.warn(`[generateAiResponse] Conversation context loaded:`, {
        totalMessages: messages.length,
        sessionMessages: sessionMessages.length,
        contextLength: contextMessages.length,
      });
    }

    // =========================================================================
    // 2-AI CLASSIFIER + EXECUTOR PIPELINE
    // =========================================================================

    // STEP 1: CLASSIFIER - Determine intent and tool access
    const strictSchedulingFlow = isStrictSchedulingFlowConfigured(
      settings?.customInstructions,
      interpolatedSystemPrompt,
      settings?.systemPrompt,
    );

    if (strictSchedulingFlow) {
      const normalizedMessage = normalizeTriageText(args.message || "");
      const hasPriorInboundMessage = rawConversationMessages.some(
        (message: any) => !message?.isInternal && message.direction === "in",
      );
      if (
        !hasPriorInboundMessage &&
        /(ola|oi|quero marcar|marcar uma consulta|agendar uma consulta|consulta)/.test(
          normalizedMessage,
        )
      ) {
        return withPatientSafeResponse({
          response: "Olá! Você é dentista parceiro ou paciente?",
          model: "WhatsMed Scheduling Guard",
          reason: "strict_flow_welcome",
        });
      }
    }

    console.warn(`[generateAiResponse] ===== CLASSIFIER AI =====`);
    const classification = await classifyIntent({
      message: args.message,
      contextMessages,
      patient,
      clinic,
      variableContext,
    });

    console.warn(`[generateAiResponse] Classifier result:`, {
      intent: classification.intent,
      toolProfile: classification.toolProfile,
      confidence: classification.confidence,
      needsClarification: classification.needsClarification,
    });

    if (classification.needsClarification && !strictSchedulingFlow) {
      const deterministicAvailability = await tryDeterministicAvailabilityResponse(
        ctx,
        args,
        rawConversationMessages,
      );
      if (
        deterministicAvailability?.response &&
        !/voce quis dizer|você quis dizer/i.test(deterministicAvailability.response)
      ) {
        console.warn(
          "[generateAiResponse] Using deterministic availability before classifier clarification",
        );
        return deterministicAvailability;
      }

      const deterministicConfirmation = await tryDeterministicConfirmation(
        ctx,
        args,
        rawConversationMessages,
        patient,
      );
      if (deterministicConfirmation) {
        console.warn(
          "[generateAiResponse] Using deterministic confirmation before classifier clarification",
        );
        return deterministicConfirmation;
      }
    }

    // Handle clarification if needed
    if (classification.needsClarification && classification.clarifyingQuestion) {
      return withPatientSafeResponse({
        response: classification.clarifyingQuestion,
        model: "Mastra Classifier",
        reason: "classifier_clarification_needed",
      });
    }

    const preflightClarification = await trySchedulingClarificationBeforeExecution(
      ctx,
      args,
      classification.toolProfile,
      rawConversationMessages,
    );
    if (preflightClarification) {
      return preflightClarification;
    }

    const deterministicRescheduleProposal = await tryDeterministicRescheduleProposal(
      ctx,
      args,
      patient,
    );
    if (deterministicRescheduleProposal && !strictSchedulingFlow) {
      return deterministicRescheduleProposal;
    }

    // STEP 2: Create executor agent with filtered tools
    console.warn(`[generateAiResponse] ===== EXECUTOR AI =====`);
    const agent = mastraModule.getClinicAgent(
      args.clinicId,
      settings,
      ctx,
      interpolatedSystemPrompt,
      variableContext,
      classification.toolProfile,
      classification.allowedTools,
    );

    // STEP 3: Add executor guidance to context
    const executorGuidance = buildExecutorGuidance(classification);
    const enhancedContext = [
      { role: "system" as const, content: executorGuidance },
      ...contextMessages,
    ];

    // =========================================================================
    // END CLASSIFIER INTEGRATION
    // =========================================================================

    // Deterministic shortcuts (skip if forceLiveAgent)
    if (!strictSchedulingFlow && !args.disableDeterministicShortcuts) {
      console.warn(
        "[generateAiResponse] Checking deterministic shortcuts (disableDeterministicShortcuts=false)",
      );
      const deterministicAvailability = await tryDeterministicAvailabilityResponse(
        ctx,
        args,
        rawConversationMessages,
      );
      if (deterministicAvailability) {
        console.warn("[generateAiResponse] Using deterministic availability response");
        return deterministicAvailability;
      }

      const deterministicConfirmation = await tryDeterministicConfirmation(
        ctx,
        args,
        rawConversationMessages,
        patient,
      );
      if (deterministicConfirmation) {
        console.warn("[generateAiResponse] Using deterministic confirmation response");
        return deterministicConfirmation;
      }
    } else {
      console.warn(
        `[generateAiResponse] Skipping deterministic shortcuts (strictSchedulingFlow=${strictSchedulingFlow}, disableDeterministicShortcuts=${args.disableDeterministicShortcuts})`,
      );

      if (
        !strictSchedulingFlow &&
        (isClarificationSelectionResponse(args.message, rawConversationMessages) ||
          (shouldTreatBookingMessageAsAvailability(args.message || "") &&
            extractBrazilDate(args.message || "") &&
            extractTimeToken(args.message || "")) ||
          (/telemed|teleconsulta/.test(normalizeTriageText(args.message || "")) &&
            extractBrazilDate(args.message || "") &&
            extractTimeToken(args.message || "")))
      ) {
        const deterministicAvailability = await tryDeterministicAvailabilityResponse(
          ctx,
          args,
          rawConversationMessages,
        );
        if (deterministicAvailability) {
          console.warn(
            "[generateAiResponse] Using deterministic telemedicine availability while live agent is forced",
          );
          return deterministicAvailability;
        }
      }

      if (!strictSchedulingFlow) {
        const deterministicConfirmation = await tryDeterministicConfirmation(
          ctx,
          args,
          rawConversationMessages,
          patient,
        );
        if (deterministicConfirmation) {
          console.warn(
            "[generateAiResponse] Using deterministic confirmation response while live agent is forced",
          );
          return deterministicConfirmation;
        }
      }
    }

    // Use enhancedContext (with classifier guidance) for execution
    let context = enhancedContext;

    // Helper functions for ID extraction
    function extractIdsFromResult(toolName: string, result: any): Record<string, string> {
      const ids: Record<string, string> = {};
      if (toolName === "searchDoctors" && result?.doctors?.[0]?._id) {
        ids.doctorId = result.doctors[0]._id;
      }
      if (toolName === "listProcedures" && result?.procedures?.[0]?.id) {
        ids.procedureId = result.procedures[0].id;
      }
      if (toolName === "listProcedures" && result?.doctor?.id) {
        ids.doctorId = result.doctor.id;
      }
      return ids;
    }

    function extractIdsFromArgs(args: any): Record<string, string> {
      const ids: Record<string, string> = {};
      if (!args) return ids;
      if (args.doctorId) ids.doctorId = args.doctorId;
      if (args.procedureId) ids.procedureId = args.procedureId;
      if (args.patientId) ids.patientId = args.patientId;
      return ids;
    }

    // Retry logic: allow up to 3 attempts before failing
    const maxRetries = 3;
    let lastError: any = null;
    let retryContext = context;
    let previousToolResults: any[] = []; // Store successful tool results across retries
    let retrySystemHints: Array<{ role: "system"; content: string }> = [];

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.warn(`[generateAiResponse] Attempt ${attempt}/${maxRetries}...`);

        // Build context with previous tool results and error context if retrying
        let currentContext = [...context];

        // Add previous successful tool results to context
        if (previousToolResults.length > 0) {
          console.warn(
            `[generateAiResponse] Including ${previousToolResults.length} previous tool results in context`,
          );
          currentContext = [
            ...currentContext,
            ...previousToolResults.map((tr) => ({
              role: "assistant" as const,
              content: `[Resultado de ferramenta anterior] ${tr.toolName}: ${typeof tr.result === "object" ? JSON.stringify(tr.result, null, 2) : tr.result}`,
            })),
          ];
        }

        if (retrySystemHints.length > 0) {
          currentContext = [...currentContext, ...retrySystemHints];
        }

        // If this is a retry after an error, add error context to help agent recover
        if (attempt > 1 && lastError) {
          const errorMessage = lastError?.cause?.message || lastError?.message || String(lastError);

          if (
            errorMessage.includes("ID inválido") ||
            errorMessage.includes("ArgumentValidationError")
          ) {
            // Add error context to help agent understand it needs to call tools again
            currentContext.push({
              role: "system" as const,
              content: `⚠️ ERRO CRÍTICO DE ID: ${errorMessage}

AÇÃO OBRIGATÓRIA PARA RECUPERAÇÃO:
1. IGNORE completamente os IDs que falharam (doctorId e procedureId anteriores)
2. Chame 'searchDoctors' NOVAMENTE com o nome do médico para obter um doctorId FRESCO e CORRETO
3. Chame 'listProcedures' NOVAMENTE com o doctorId obtido no passo 2 para obter um procedureId FRESCO e CORRETO
4. Use APENAS os IDs retornados por essas chamadas de ferramenta - NÃO reutilize IDs antigos
5. Depois de obter os IDs corretos, continue com o agendamento

NÃO tente usar os mesmos IDs que falharam. Sempre obtenha IDs novos das ferramentas.`,
            });
            console.warn(
              `[generateAiResponse] Adding error context for retry ${attempt} to help agent recover`,
            );
          } else if (errorMessage.includes("passado") || errorMessage.includes("past")) {
            // Error about scheduling in the past
            currentContext.push({
              role: "system" as const,
              content: `⚠️ ERRO: ${errorMessage}

AÇÃO OBRIGATÓRIA:
1. O horário que você tentou usar já passou ou é inválido
2. Chame 'getAvailableHours' NOVAMENTE com a data correta para obter horários disponíveis ATUAIS
3. Use APENAS um dos horários retornados por 'getAvailableHours' - NÃO invente horários
4. Certifique-se de que o horário escolhido está na lista de horários disponíveis retornados pela ferramenta`,
            });
            console.warn(`[generateAiResponse] Adding time error context for retry ${attempt}`);
          }
        }

        retryContext = currentContext;

        // Generate AI response with context (not history - Mastra uses 'context' parameter)
        // Model selection is centralized in mastra/config.ts and agents.ts
        const generateOptions: any = {
          context: retryContext, // Pass chat history as context (with error context if retrying)
          maxSteps: 10, // Allow more steps for complex tool chains (default is often 5)
          parallelToolCalls: false,
          temperature: 0,
          // Force non-streaming mode (doGenerate) for chatbot responses
          // This avoids streaming-related issues with the provider
          methodType: "generate",
          // memory: args.threadId ? { thread: args.threadId } : undefined, // Disable built-in memory if using manual context
        };

        console.warn(
          "[generateAiResponse] Generate options:",
          JSON.stringify(generateOptions, null, 2),
        );

        const canUseMultimodalInput = Boolean(
          currentMessageContext?.hasImage &&
          currentMessageContext?.imageUrl &&
          (!currentMessageContext?.mediaMimetype ||
            String(currentMessageContext.mediaMimetype).startsWith("image/")),
        );

        const agentInput = canUseMultimodalInput
          ? [
              {
                role: "user" as const,
                content: [
                  {
                    type: "text" as const,
                    text:
                      args.message ||
                      "Paciente enviou uma imagem. Analise a imagem junto com esta mensagem.",
                  },
                  {
                    type: "image" as const,
                    image: currentMessageContext.imageUrl,
                    mimeType: currentMessageContext.mediaMimetype || "image/jpeg",
                  },
                ],
              },
            ]
          : args.message;

        if (canUseMultimodalInput) {
          console.warn("[generateAiResponse] Sending multimodal input (text + image) to agent");
        }

        // OpenCode Go's OpenAI-compatible chat endpoint can omit usage fields that Mastra's
        // legacy generation path assumes are always present, so keep this on the current API.
        const result = await agent.generate(agentInput as any, generateOptions);

        console.warn("[generateAiResponse] AI response generated:", result.text?.substring(0, 100));
        console.warn("[generateAiResponse] Full result object keys:", Object.keys(result || {}));
        console.warn("[generateAiResponse] Result text length:", result.text?.length || 0);
        console.warn("[generateAiResponse] Result has steps:", (result as any)?.steps?.length || 0);
        console.warn(
          "[generateAiResponse] Result has toolCalls:",
          (result as any)?.toolCalls?.length || 0,
        );
        console.warn(
          "[generateAiResponse] Result has toolResults:",
          (result as any)?.toolResults?.length || 0,
        );

        // Extract tool calls and results to store for future retries
        const toolCalls = (result as any)?.toolCalls || [];
        const toolResults = (result as any)?.toolResults || [];

        if (toolCalls.length > 0 || toolResults.length > 0) {
          console.warn(
            "[generateAiResponse] Tool calls made:",
            toolCalls.map((tc: any) => ({
              toolName: tc.payload?.toolName || tc.toolName,
              args: tc.payload?.args || tc.args,
            })),
          );
          console.warn(
            "[generateAiResponse] Tool results:",
            toolResults.map((tr: any) => ({
              toolCallId: tr.payload?.toolCallId || tr.toolCallId,
              result:
                typeof (tr.payload?.result || tr.result) === "object"
                  ? JSON.stringify(tr.payload?.result || tr.result).substring(0, 200)
                  : tr.payload?.result || tr.result,
            })),
          );

          // Store successful tool results for future retries
          // This helps the agent remember what tools it called and their results across retries
          if (toolResults.length > 0) {
            const successfulResults = toolResults
              .map((tr: any) => {
                const trPayload = tr.payload || tr;
                const toolCall = toolCalls.find(
                  (tc: any) => (tc.payload?.toolCallId || tc.toolCallId) === trPayload.toolCallId,
                );
                if (!toolCall) return null;

                const tcPayload = toolCall.payload || toolCall;

                // Only store results from tools that provide useful information
                const usefulTools = [
                  "searchDoctors",
                  "listProcedures",
                  "getAvailableDays",
                  "getAvailableHours",
                ];
                if (usefulTools.includes(tcPayload.toolName)) {
                  const extractedIds = extractIdsFromResult(tcPayload.toolName, trPayload.result);

                  return {
                    toolName: tcPayload.toolName,
                    toolCallId: trPayload.toolCallId,
                    timestamp: Date.now(),
                    result: trPayload.result,
                    extractedIds,
                    args: extractIdsFromArgs(tcPayload.args),
                  };
                }
                return null;
              })
              .filter((r: any) => r !== null);

            // Merge with previous results, keeping only the most recent for each tool
            previousToolResults = [
              ...previousToolResults.filter(
                (ptr: any) => !successfulResults.some((sr: any) => sr.toolName === ptr.toolName),
              ),
              ...successfulResults,
            ];

            console.warn(
              `[generateAiResponse] Stored ${successfulResults.length} tool results for future retries`,
            );

            // Add extracted IDs to context for retries
            if (successfulResults.length > 0) {
              retrySystemHints = successfulResults
                .filter((sr: any) => Object.keys(sr.extractedIds || {}).length > 0)
                .map((sr: any) => ({
                  role: "system" as const,
                  content: `[IDs Extraídos] ${JSON.stringify(sr.extractedIds)} - Use estes IDs para chamadas subsequentes`,
                }));
            }
          }
        }

        // STEP 7: VALIDATE tool usage against classifier requirements
        const validation = validateToolUsage(toolCalls, classification, args.message);

        if (!validation.valid && attempt < maxRetries) {
          console.warn(`[generateAiResponse] Tool validation FAILED:`, validation);

          if (validation.hint) {
            retrySystemHints.push({
              role: "system" as const,
              content: validation.hint,
            });
          }

          // Store results for context and retry
          if (toolResults.length > 0) {
            previousToolResults.push(
              ...toolResults.map((tr: any) => ({
                toolName: (() => {
                  const trPayload = tr.payload || tr;
                  const tc = toolCalls.find(
                    (t: any) => (t.payload?.toolCallId || t.toolCallId) === trPayload.toolCallId,
                  );
                  return tc?.payload?.toolName || tc?.toolName || "unknown";
                })(),
                result: tr.payload?.result || tr.result,
              })),
            );
          }

          console.warn(`[generateAiResponse] Retrying with tool correction hint...`);
          continue;
        }

        // Validation passed or max retries reached - proceed with response

        // Add structured logging for debugging
        if (toolCalls.length > 0 || toolResults.length > 0) {
          const successfulResults = toolResults
            .map((tr: any) => {
              const toolCall = toolCalls.find((tc: any) => tc.toolCallId === tr.toolCallId);
              if (!toolCall) return null;
              const extractedIds = extractIdsFromResult(toolCall.toolName, tr.result);
              return { toolName: toolCall.toolName, extractedIds };
            })
            .filter((r: any) => r !== null);

          console.warn("[generateAiResponse] Tool execution summary:", {
            attempt: attempt,
            toolCallsCount: toolCalls.length,
            toolResultsCount: toolResults.length,
            extractedIds: successfulResults
              .map((sr: any) => sr.extractedIds)
              .reduce((acc: any, ids: any) => ({ ...acc, ...ids }), {}),
            toolCalls: toolCalls.map((tc: any) => ({
              name: tc.payload?.toolName || tc.toolName,
              args: extractIdsFromArgs(tc.payload?.args || tc.args),
            })),
          });

          // Log escalation tool usage
          const escalationCall = toolCalls.find(
            (tc: any) => (tc.payload?.toolName || tc.toolName) === "escalateToStaff",
          );
          if (escalationCall) {
            console.warn(`[AI] Escalation triggered`);
          }

          // Log tool failures for debugging
          const failedTools = toolResults.filter(
            (tr: any) =>
              tr.payload?.result?.error === true ||
              tr.result?.error === true ||
              (tr.payload?.result &&
                typeof tr.payload.result === "object" &&
                tr.payload.result.success === false),
          );
          if (failedTools.length > 0) {
            console.warn(
              "[AI] Tool failures:",
              failedTools.map((tr: any) => ({
                toolCallId: tr.payload?.toolCallId || tr.toolCallId,
                error: tr.payload?.result?.error || tr.result?.error || "Tool execution failed",
              })),
            );
          }
        }

        // If result.text is empty but we have steps, log the last step
        if (!result.text && (result as any)?.steps) {
          const lastStep = (result as any).steps[(result as any).steps.length - 1];
          console.warn("[generateAiResponse] Last step:", JSON.stringify(lastStep, null, 2));
        }

        // Check for tool failures and classify them
        const failedTool = toolResults.find(
          (tr: any) =>
            tr.payload?.result?.error === true ||
            tr.result?.error === true ||
            JSON.stringify(tr).includes("Tool validation failed"),
        );

        if (failedTool) {
          const toolCallId = failedTool.payload?.toolCallId || failedTool.toolCallId;
          const failedToolCall = toolCalls.find(
            (tc: any) => (tc.payload?.toolCallId || tc.toolCallId) === toolCallId,
          );
          const toolName =
            failedToolCall?.payload?.toolName || failedToolCall?.toolName || "unknown";
          const toolArgs = failedToolCall?.payload?.args || failedToolCall?.args || {};
          const errorResult = failedTool.payload?.result || failedTool.result;
          const errorMessage =
            typeof errorResult === "object"
              ? errorResult.message || JSON.stringify(errorResult)
              : String(errorResult);

          // Classify error: functional vs technical
          const isFunctionalError =
            errorMessage.includes("SLOT_UNAVAILABLE") ||
            errorMessage.includes("não está mais disponível") ||
            errorMessage.includes("Não há horários disponíveis") ||
            errorMessage.includes("horário já está ocupado") ||
            errorMessage.includes("overlap");

          console.error("[generateAiResponse] Tool error DETAILS:", {
            toolName,
            toolArgs,
            errorResult:
              typeof errorResult === "object" ? JSON.stringify(errorResult, null, 2) : errorResult,
            isFunctionalError,
          });

          // If it's a functional error (business logic), let agent handle it - DON'T retry
          // The agent already has the error in toolResults and can respond appropriately
          if (isFunctionalError) {
            console.warn(
              "[generateAiResponse] Functional error detected - agent will handle response",
            );
            // Don't throw - let the agent respond with the error message
          } else {
            // Technical/validation error - retry to give agent another chance
            throw new Error(`AI_ToolExecutionError: Tool validation failed at ${toolName}`);
          }
        }

        const deterministicAppointmentResponse = buildAppointmentConfirmationFromToolResult({
          toolCalls,
          toolResults,
          patient,
          clinic,
        });
        const deterministicAvailabilityResponse = buildAvailabilityResponseFromToolResult({
          toolCalls,
          toolResults,
          message: args.message,
        });
        let recoveredAvailabilityResponse: string | null = null;
        if (
          !deterministicAppointmentResponse &&
          deterministicAvailabilityResponse &&
          /voce quis dizer|você quis dizer/i.test(deterministicAvailabilityResponse)
        ) {
          const deterministicAvailability = await tryDeterministicAvailabilityResponse(
            ctx,
            args,
            rawConversationMessages,
          );
          if (
            deterministicAvailability?.response &&
            !/voce quis dizer|você quis dizer/i.test(deterministicAvailability.response)
          ) {
            recoveredAvailabilityResponse = deterministicAvailability.response;
          }
        }
        const responseText =
          deterministicAppointmentResponse ||
          recoveredAvailabilityResponse ||
          deterministicAvailabilityResponse ||
          result.text ||
          "";
        const patientSafeResponseText = sanitizePatientFacingResponse(responseText);
        const usedAnyTool = toolCalls.length > 0 || toolResults.length > 0;

        // Check for required tools based on classification (if validation passed but no required tools used)
        if (
          classification.requiredTools.length > 0 &&
          !usedAnyTool &&
          patientSafeResponseText &&
          !isLikelyClarifyingQuestion(patientSafeResponseText)
        ) {
          const requiredToolError: any = new Error(
            `AI_REQUIRED_TOOL_MISSING:${classification.intent}`,
          );
          requiredToolError.classification = classification;
          throw requiredToolError;
        }

        if (args.threadId && usedAnyTool) {
          const toolHistoryEntries = buildToolHistoryEntries(toolCalls, toolResults);
          if (toolHistoryEntries.length > 0) {
            await ctx.runMutation(internalAny.whatsappQueries.storeAiToolMessages, {
              chatId: args.threadId as any,
              entries: toolHistoryEntries,
            });
          }
        }

        // If agent called escalateToStaff, run Convex mutation to lock chat and return escalated
        const escalationCall = toolCalls.find(
          (tc: any) => (tc.payload?.toolName || tc.toolName) === "escalateToStaff",
        );
        if (escalationCall && args.threadId) {
          const escArgs = escalationCall.payload?.args || escalationCall.args || {};
          await ctx.runMutation(internalAny.whatsapp.timeout.escalateToStaff, {
            clinicId: args.clinicId,
            chatId: args.threadId as any,
            patientId: args.patientId,
            reason: escArgs.reason || "IA solicitou transferência para atendente humano",
            context: args.message,
          });
          console.warn(
            "[generateAiResponse] Escalation applied: message scheduled, chat will be assigned to human after send",
          );
          return withPatientSafeResponse({
            response: patientSafeResponseText || null,
            model: "Mastra Agent",
            escalated: true,
          });
        }

        // Guardrail: if the final patient-facing reply says the chat was handed to staff
        // but the agent skipped the escalate tool, enforce the handoff.
        if (
          !escalationCall &&
          args.threadId &&
          hasPatientFacingTransferIntent(patientSafeResponseText || "")
        ) {
          await ctx.runMutation(internalAny.whatsapp.timeout.escalateToStaff, {
            clinicId: args.clinicId,
            chatId: args.threadId as any,
            patientId: args.patientId,
            reason: "Transfer phrase detected without escalate tool call",
            context: args.message,
          });
          return {
            response: null,
            model: "Mastra Agent",
            escalated: true,
          };
        }

        return withPatientSafeResponse({
          response: patientSafeResponseText || null,
          model: "Mastra Agent",
          escalated: false,
        });
      } catch (error: any) {
        lastError = error;
        console.error(`[generateAiResponse] Attempt ${attempt}/${maxRetries} failed:`, error);

        const missingClassification = error?.classification;
        if (missingClassification) {
          retrySystemHints = [
            ...retrySystemHints,
            {
              role: "system" as const,
              content: `USO DE FERRAMENTA OBRIGATÓRIO: Para ${missingClassification.intent}, você DEVE usar: ${missingClassification.requiredTools.join(", ")}.
Se ainda faltar contexto essencial, faça uma pergunta curta para esclarecer; caso contrário, chame a ferramenta apropriada antes de responder.`,
            },
          ];
        }

        // Check if it's a functional error (business logic - should NOT retry)
        const isFunctionalError =
          error?.message?.includes("SLOT_UNAVAILABLE") ||
          error?.message?.includes("não está mais disponível") ||
          error?.message?.includes("Não há horários disponíveis") ||
          error?.message?.includes("horário já está ocupado") ||
          error?.message?.includes("overlap");

        // Functional errors should not trigger retries - agent already handled it
        if (isFunctionalError) {
          console.warn(
            "[generateAiResponse] Functional error - breaking retry loop (agent will handle)",
          );
          break;
        }

        // Check if it's a technical/validation error (should retry)
        const isToolError =
          error?.name === "AI_ToolExecutionError" ||
          error?.message?.includes("AI_ToolExecutionError") ||
          error?.message?.includes("AI_REQUIRED_TOOL_MISSING") ||
          error?.message?.includes("ID inválido") ||
          error?.message?.includes("ArgumentValidationError") ||
          error?.message?.includes("does not match validator") ||
          error?.cause?.message?.includes("ID inválido");

        // If it's a technical error and we have retries left, continue to next attempt
        // The agent will have a chance to call the tools again with correct IDs
        if (isToolError && attempt < maxRetries) {
          console.warn(
            `[generateAiResponse] Technical error detected, retrying... (${attempt}/${maxRetries})`,
          );
          // Add a small delay before retry to avoid rate limiting
          await new Promise((resolve) => setTimeout(resolve, 500));
          continue;
        }

        // If it's not a tool error or we've exhausted retries, break and handle error
        if (!isToolError || attempt >= maxRetries) {
          break;
        }
      }
    }

    // All retries exhausted or non-retryable error
    console.error("[generateAiResponse] All retries exhausted or non-retryable error:", lastError);

    // Check if it's a functional error - return the agent's response if available
    if (
      lastError?.message?.includes("SLOT_UNAVAILABLE") ||
      lastError?.message?.includes("não está mais disponível") ||
      lastError?.message?.includes("Não há horários disponíveis")
    ) {
      // For functional errors, return a generic message
      // The agent should have already handled the response appropriately
      return withPatientSafeResponse({
        response: lastError.message.replace("SLOT_UNAVAILABLE: ", ""),
        model: "Mastra Agent",
        reason: "functional_error_handled",
      });
    }

    if (lastError?.message?.includes("AI_REQUIRED_TOOL_MISSING")) {
      return withPatientSafeResponse({
        response:
          "Preciso consultar os dados em tempo real antes de confirmar horários, cancelamentos ou reagendamentos. Me diga o médico ou a consulta que deseja verificar para eu buscar a informação correta.",
        model: "Mastra Agent",
        reason: "required_tool_missing",
      });
    }

    // Fallback to generic message for technical errors
    return withPatientSafeResponse({
      response: "Obrigado pela sua mensagem. Nossa equipe responderá em breve.",
      reason: "ai_error",
      error: String(lastError),
    });
  },
});

export const transcribeIncomingAudioAction = internalAction({
  args: {
    messageId: v.id("messages"),
  },
  handler: async (ctx, args) => {
    const begin = await ctx.runMutation(internalAny.whatsappInternal.beginAudioTranscription, {
      messageId: args.messageId,
    });

    if (!begin?.shouldTranscribe) {
      return {
        transcribedText: begin?.transcribedText,
        reason: begin?.reason || "Transcription not required",
      };
    }

    try {
      const audioUrl = await ctx.storage.getUrl(begin.mediaStorageId);
      if (!audioUrl) {
        await ctx.runMutation(internalAny.whatsappInternal.finishAudioTranscription, {
          messageId: args.messageId,
          status: "failed",
          error: "Audio file URL unavailable for transcription",
        });
        return {
          transcribedText: null,
          reason: "Audio file URL unavailable",
        };
      }

      const transcription = await transcribeAudioFromUrl({
        audioUrl,
        ...(process.env.OPENAI_WHISPER_MODEL ? { model: process.env.OPENAI_WHISPER_MODEL } : {}),
      });

      await ctx.runMutation(internalAny.whatsappInternal.finishAudioTranscription, {
        messageId: args.messageId,
        status: "completed",
        transcribedText: transcription.text,
        language: transcription.language,
        duration: transcription.duration,
      });

      return {
        transcribedText: transcription.text,
        model: transcription.model,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      await ctx.runMutation(internalAny.whatsappInternal.finishAudioTranscription, {
        messageId: args.messageId,
        status: "failed",
        error: errorMessage,
      });
      return {
        transcribedText: null,
        reason: errorMessage,
      };
    }
  },
});

/**
 * Process incoming message with AI
 * Main entry point for WhatsApp webhook
 */
export const processIncomingAiMessage = internalAction({
  args: {
    clinicId: v.string(),
    chatId: v.id("chats"),
    messageId: v.id("messages"),
    patientId: v.optional(v.id("patients")),
    traceId: v.optional(v.string()),
    skipOutboundDelivery: v.optional(v.boolean()),
    disableDeterministicShortcuts: v.optional(v.boolean()),
  },
  handler: async (
    ctx,
    args,
  ): Promise<{
    processed: boolean;
    escalated?: boolean;
    aiResponse: string | null;
    model?: string;
    reason?: string;
    error?: string;
  }> => {
    console.warn("[processIncomingAiMessage] Processing message...", {
      clinicId: args.clinicId,
      chatId: args.chatId,
      messageId: args.messageId,
    });

    // Check feature access
    const access = await ctx.runQuery(internal.planEnforcement.checkFeatureAccess, {
      clinicId: args.clinicId,
      feature: "advancedAi" as const,
    });
    if (!access.allowed) {
      console.warn("[processIncomingAiMessage] Feature not available for plan");
      return { processed: false, reason: "Feature not available", aiResponse: null };
    }

    // Get chat to check if locked
    const chat = await ctx.runQuery(internal.whatsappQueries.getChatInternal, {
      chatId: args.chatId,
    });
    if (!chat) {
      return { processed: false, reason: "Chat not found", aiResponse: null };
    }
    if (chat.status !== "open" || chat.isAiActive === false || chat.needsHumanReview === true) {
      console.warn("[processIncomingAiMessage] Chat not eligible for AI response", {
        status: chat.status,
        isAiActive: chat.isAiActive,
        needsHumanReview: chat.needsHumanReview,
      });
      return { processed: false, reason: "Chat not eligible", aiResponse: null };
    }

    // Get the incoming message
    const message = await ctx.runQuery(internal.whatsappInternal.getMessage, {
      id: args.messageId,
    });
    if (!message || message.direction !== "in") {
      console.warn("[processIncomingAiMessage] Invalid message or wrong direction", message);
      return { processed: false, reason: "Invalid message", aiResponse: null };
    }

    const chatId = message.chatId;
    console.log(`[processIncomingAiMessage] Generating response for chat ${chatId}`);

    const incomingText = (message.body || "").trim();
    let transcribedText =
      typeof message.transcribedText === "string" ? message.transcribedText.trim() : "";
    const isAudioMessage = message.mediaType === "audio";

    if (!incomingText && !transcribedText && isAudioMessage) {
      const transcriptionResult = await ctx.runAction(
        internalAny.automationAi.transcribeIncomingAudioAction,
        {
          messageId: args.messageId,
        },
      );

      transcribedText =
        typeof transcriptionResult?.transcribedText === "string"
          ? transcriptionResult.transcribedText.trim()
          : "";

      if (!transcribedText && transcriptionResult?.reason === "Transcription already in progress") {
        return {
          processed: false,
          aiResponse: null,
          reason: "audio_transcription_in_progress",
        };
      }

      if (!transcribedText) {
        const fallbackResponse =
          "Recebi seu áudio, mas não consegui transcrever agora. Pode reenviar o áudio ou escrever sua mensagem em texto?";

        await ctx.runAction(internalAny.whatsapp.sendAiResponseIfAllowedAction, {
          chatId: args.chatId,
          text: fallbackResponse,
          replyToMessageId: args.messageId,
        });

        return {
          processed: true,
          aiResponse: fallbackResponse,
          reason: "audio_transcription_unavailable",
        };
      }

      console.warn("[processIncomingAiMessage] Audio transcribed", {
        messageId: args.messageId,
        preview: transcribedText.substring(0, 120),
        model: transcriptionResult?.model,
      });
    }

    const synthesizedMessage =
      incomingText ||
      (transcribedText
        ? `Mensagem de voz do paciente (transcrita): ${transcribedText}`
        : message.mediaStorageId
          ? `Paciente enviou ${message.mediaType === "image" ? "uma imagem" : message.mediaType === "document" ? "um documento" : message.mediaType === "audio" ? "um áudio" : "uma mídia"}.`
          : "");

    const aiResult = await ctx.runAction(internalAny.automationAi.generateAiResponse, {
      clinicId: args.clinicId,
      message: synthesizedMessage,
      threadId: chatId,
      patientId: args.patientId,
      messageId: args.messageId,
      traceId: args.traceId,
      disableDeterministicShortcuts: args.disableDeterministicShortcuts,
    });

    console.log("[processIncomingAiMessage] AI Result:", aiResult);

    // If escalation detected or AI disabled, don't auto-respond.
    // Chat is assigned to human by sendEscalationMessageAndAssignHuman after the message is sent.
    if (aiResult.escalated) {
      console.warn("[processIncomingAiMessage] Escalated, skipping auto-response");
      return {
        processed: true,
        escalated: true,
        aiResponse: null,
        model: aiResult.model,
        reason: aiResult.reason,
        error: aiResult.error,
      };
    }

    if (!aiResult.response) {
      console.warn(
        `[processIncomingAiMessage] No response generated. Reason: ${aiResult.reason || "Unknown"}`,
      );
      return {
        processed: true,
        aiResponse: null,
        model: aiResult.model,
        reason: aiResult.reason,
        error: aiResult.error,
      };
    }

    // Check if response delay is configured
    const settings = await ctx.runQuery(internalAny.automation.getAiSettingsInternal, {
      clinicId: args.clinicId,
    });

    const delayMs = (settings?.responseDelaySeconds || 0) * 1000;
    console.log(`[processIncomingAiMessage] Response delay configured: ${delayMs}ms`);

    const latestChat = await ctx.runQuery(internal.whatsappQueries.getChatInternal, {
      chatId: args.chatId,
    });
    if (
      !latestChat ||
      latestChat.status !== "open" ||
      latestChat.isAiActive === false ||
      latestChat.needsHumanReview === true
    ) {
      return {
        processed: false,
        reason: "Chat state changed before send",
        aiResponse: null,
      };
    }

    // Send AI response back to WhatsApp
    if (delayMs > 0) {
      // Schedule delayed response
      await ctx.scheduler.runAfter(delayMs, internalAny.whatsapp.sendAiResponseIfAllowedAction, {
        chatId: args.chatId,
        text: aiResult.response,
        replyToMessageId: args.messageId,
        skipProviderSend: args.skipOutboundDelivery,
      });
      console.warn(`[processIncomingAiMessage] Response scheduled in ${delayMs}ms`);
    } else {
      // Send immediately
      await ctx.runAction(internalAny.whatsapp.sendAiResponseIfAllowedAction, {
        chatId: args.chatId,
        text: aiResult.response,
        replyToMessageId: args.messageId,
        skipProviderSend: args.skipOutboundDelivery,
      });
      console.warn("[processIncomingAiMessage] Response sent immediately");
    }

    return {
      processed: true,
      aiResponse: aiResult.response,
      model: aiResult.model,
      reason: aiResult.reason,
      error: aiResult.error,
    };
  },
});
