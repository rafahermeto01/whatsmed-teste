import { v } from "convex/values";

import { internalQuery, query } from "./_generated/server";
import { checkFeatureAccess as checkFeatureAccessImpl } from "./lib/planEnforcement";

// Export as internal query so it can be called from actions
export const checkFeatureAccess = internalQuery({
  args: {
    clinicId: v.string(),
    feature: v.union(
      v.literal("appointments"),
      v.literal("advancedAi"),
      v.literal("integrations"),
      v.literal("nps"),
      v.literal("checkin"),
      v.literal("telemedicine"),
      v.literal("apiAccess"),
    ),
  },
  handler: async (ctx, args) => {
    return await checkFeatureAccessImpl(ctx, args.clinicId, args.feature);
  },
});

// Public query for frontend use
export const checkFeatureAccessPublic = query({
  args: {
    clinicId: v.string(),
    feature: v.union(
      v.literal("appointments"),
      v.literal("advancedAi"),
      v.literal("integrations"),
      v.literal("nps"),
      v.literal("checkin"),
      v.literal("telemedicine"),
      v.literal("apiAccess"),
    ),
  },
  handler: async (ctx, args) => {
    return await checkFeatureAccessImpl(ctx, args.clinicId, args.feature);
  },
});
