import { paginationOptsValidator } from "convex/server";
import { v } from "convex/values";

import { mutation, query } from "./_generated/server";

export const insert = mutation({
  args: {
    action: v.string(),
    clinicId: v.string(),
    userId: v.optional(v.string()),
    email: v.optional(v.string()),
    userAgent: v.optional(v.string()),
    metadata: v.optional(v.any()),
    createdAt: v.number(),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("auditLogs", args);
    return { ok: true };
  },
});

export const list = query({
  args: {
    clinicId: v.string(),
    paginationOpts: paginationOptsValidator,
  },
  handler: async (ctx, args) => {
    const logs = await ctx.db
      .query("auditLogs")
      .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", args.clinicId))
      .order("desc")
      .paginate(args.paginationOpts);

    // Enrich with user names if userId exists
    const enrichedPage = await Promise.all(
      logs.page.map(async (log) => {
        let userName = log.email || "Sistema";

        if (log.userId) {
          const user = await ctx.db
            .query("users")
            .filter((q) => q.eq(q.field("_id"), log.userId))
            .first();
          if (user) {
            userName = user.name;
          }
        }

        return {
          ...log,
          userName,
        };
      }),
    );

    return {
      ...logs,
      page: enrichedPage,
    };
  },
});
