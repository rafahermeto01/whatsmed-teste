"use node";

import { v } from "convex/values";
import nodemailer from "nodemailer";

import { internalAction } from "./_generated/server";

function getTransport() {
  const host = process.env.SMTP_HOST;
  const port = process.env.SMTP_PORT ? Number(process.env.SMTP_PORT) : 587;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS || process.env.SMTP_PASSWORD;
  if (!host || !user || !pass) {
    throw new Error("SMTP_HOST/SMTP_USER/SMTP_PASS or SMTP_PASSWORD are required to send email");
  }
  return nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: { user, pass },
  });
}

export const sendPasswordResetEmail = internalAction({
  args: {
    email: v.string(),
    resetUrl: v.string(),
  },
  handler: async (_ctx, { email, resetUrl }) => {
    const transport = getTransport();
    const from =
      process.env.SMTP_FROM || process.env.SMTP_FROM_EMAIL || "no-reply@mail.whatsmed.tech";

    const html = `
      <p>Recebemos uma solicitação para redefinir sua senha.</p>
      <p>Clique no link abaixo para continuar. O link expira em 30 minutos.</p>
      <p><a href="${resetUrl}">${resetUrl}</a></p>
      <p>Se você não solicitou, ignore este e-mail.</p>
    `;

    await transport.sendMail({
      from,
      to: email,
      subject: "Redefinir Senha - WhatsMed",
      html,
    });
  },
});

export const sendEmail = internalAction({
  args: {
    to: v.string(),
    subject: v.string(),
    html: v.string(),
  },
  handler: async (_ctx, { to, subject, html }) => {
    const transport = getTransport();
    const from =
      process.env.SMTP_FROM || process.env.SMTP_FROM_EMAIL || "no-reply@mail.whatsmed.tech";
    await transport.sendMail({ from, to, subject, html });
  },
});
