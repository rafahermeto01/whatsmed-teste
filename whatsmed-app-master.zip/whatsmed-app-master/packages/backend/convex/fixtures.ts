import { v } from "convex/values";

import { mutation } from "./_generated/server";
import { loadLocalFixtures } from "./lib/fixtures";

function getNextBrazilWeekdayAt(hour: number, minute: number) {
  const base = new Date();
  base.setUTCDate(base.getUTCDate() + 1);
  while (base.getUTCDay() === 0 || base.getUTCDay() === 6) {
    base.setUTCDate(base.getUTCDate() + 1);
  }

  return Date.UTC(
    base.getUTCFullYear(),
    base.getUTCMonth(),
    base.getUTCDate(),
    hour + 3,
    minute,
    0,
    0,
  );
}

function getBrazilIsoDate(timestamp: number) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(timestamp));
}

export const load = mutation({
  args: {
    clinicId: v.optional(v.string()),
  },
  handler: async (ctx, { clinicId }) => {
    return loadLocalFixtures(ctx, clinicId ?? "clinic-demo");
  },
});

export const seedTelemedicineRescheduleScenario = mutation({
  args: {
    clinicId: v.string(),
    suffix: v.string(),
  },
  handler: async (ctx, { clinicId, suffix }) => {
    const now = Date.now();
    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", clinicId))
      .first();

    if (clinic) {
      await ctx.db.patch(clinic._id, {
        name: clinic.name || "Minha Clínica",
        plan: "professional",
        planStatus: "active",
        updatedAt: now,
      });
    } else {
      await ctx.db.insert("clinics", {
        clinicId,
        name: "Minha Clínica",
        plan: "professional",
        planStatus: "active",
        createdAt: now,
        updatedAt: now,
      });
    }

    const doctorId = await ctx.db.insert("users", {
      authUserId: `doctor-e2e-${suffix}`,
      clinicId,
      name: `Doctor E2E ${suffix}`,
      email: `doctor.e2e.${suffix}@example.test`,
      role: "doctor",
      isActive: true,
      createdAt: now,
      deletedAt: undefined,
    });

    const patientId = await ctx.db.insert("patients", {
      clinicId,
      name: `Paciente E2E ${suffix}`,
      email: `patient.e2e.${suffix}@example.test`,
      phone: `5511999${suffix.slice(-6).padStart(6, "0")}`,
      status: "active",
      tags: [],
      createdAt: now,
      updatedAt: now,
      deletedAt: undefined,
    });

    const initialStartAt = getNextBrazilWeekdayAt(9, 0);
    const targetStartAt = getNextBrazilWeekdayAt(10, 0);

    const weekday = new Date(initialStartAt).toLocaleDateString("en-US", {
      timeZone: "America/Sao_Paulo",
      weekday: "short",
    });
    const dayOfWeekMap: Record<string, number> = {
      Sun: 0,
      Mon: 1,
      Tue: 2,
      Wed: 3,
      Thu: 4,
      Fri: 5,
      Sat: 6,
    };

    await ctx.db.patch(doctorId, {
      workingHours: [
        {
          dayOfWeek: dayOfWeekMap[weekday] ?? 1,
          slots: [
            {
              start: "09:00",
              end: "12:00",
              types: ["telemedicine", "in_person"],
            },
          ],
        },
      ],
    });

    const procedureId = await ctx.db.insert("procedures", {
      clinicId,
      doctorId,
      name: `Teleconsulta E2E ${suffix}`,
      durationMinutes: 60,
      isActive: true,
      isTelemedicine: true,
      isInPerson: true,
      createdAt: now,
    });

    const appointmentId = await ctx.db.insert("appointments", {
      clinicId,
      patientId,
      doctorId,
      startAt: initialStartAt,
      endAt: initialStartAt + 60 * 60 * 1000,
      status: "confirmed",
      doctor: `Doctor E2E ${suffix}`,
      procedure: `Teleconsulta E2E ${suffix}`,
      procedureId,
      createdAt: now,
      updatedAt: now,
      isTelemedicine: true,
      patientEmail: `patient.e2e.${suffix}@example.test`,
      timeZone: "America/Sao_Paulo",
      meetingLink: "https://meet.google.com/seed-test-link",
      meetingId: "seed-test-link",
      calendarEventId: `seeded-calendar-${suffix}`,
      conferenceData: {
        entryPoints: [
          {
            entryPointType: "video",
            uri: "https://meet.google.com/seed-test-link",
          },
        ],
      },
    });

    return {
      doctorId,
      patientId,
      appointmentId,
      procedureId,
      patientName: `Paciente E2E ${suffix}`,
      initialDate: getBrazilIsoDate(initialStartAt),
      initialDateDisplay:
        getBrazilIsoDate(initialStartAt).slice(8, 10) +
        "/" +
        getBrazilIsoDate(initialStartAt).slice(5, 7),
      initialTime: "09:00",
      targetDate: getBrazilIsoDate(targetStartAt),
      targetDateDisplay:
        getBrazilIsoDate(targetStartAt).slice(8, 10) +
        "/" +
        getBrazilIsoDate(targetStartAt).slice(5, 7),
      targetTime: "10:00",
    };
  },
});
