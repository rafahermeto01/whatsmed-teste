import type { DataModel, Doc } from "../_generated/dataModel";
import type { GenericCtx } from "@convex-dev/better-auth";

/**
 * Auth Context Types
 */
export type AuthContext = Omit<GenericCtx, "db"> & {
  runMutation: <T>(mutation: string, args: any) => Promise<T>;
  runQuery: <T>(query: string, args: any) => Promise<T>;
  runAction: <T>(action: string, args: any) => Promise<T>;
};

/**
 * Query Context Types
 */
export interface QueryContext {
  db: DataModel;
  auth: {
    getUserIdentity: () => Promise<{ subject: string; email: string; name: string } | null>;
  };
}

/**
 * Mutation Context Types
 */
export interface MutationContext extends QueryContext {}

/**
 * Internal Context Types
 */
export interface InternalContext {
  db: DataModel;
}

/**
 * Document Types
 */
export type Patient = Doc<"patients">;
export type Appointment = Doc<"appointments">;
export type User = Doc<"users">;
export type Clinic = Doc<"clinics">;
export type Message = Doc<"messages">;
export type Chat = Doc<"chats">;
export type Document = Doc<"uploads">;

/**
 * Role Types
 */
export type Role = "admin" | "staff" | "viewer" | "doctor" | "super_admin";

/**
 * Status Types
 */
export type AppointmentStatus = "pending" | "confirmed" | "cancelled" | "completed" | "arrived";
export type PatientStatus = "active" | "inactive";
export type SubscriptionStatus = "active" | "past_due" | "canceled" | "trialing";
export type PlanType = "free" | "starter" | "professional" | "enterprise";

/**
 * Auth Result Types
 */
export interface AuthResult {
  user: User;
  clinicId: string;
  identity: { subject: string; email: string; name: string };
}

/**
 * Pagination Types
 */
export interface PaginationOpts {
  numItems?: number;
  cursor?: string;
}

export interface PaginatedResult<T> {
  page: T[];
  continueCursor: string | null;
  isDone: boolean;
}

/**
 * Rate Limit Types
 */
export interface RateLimitCheck {
  allowed: boolean;
  limit: number;
  remaining: number;
  reset: number;
}

/**
 * Error Types
 */
export interface ErrorDetails {
  code?: string;
  message: string;
  details?: Record<string, unknown>;
  requestId?: string;
}

/**
 * API Response Types
 */
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: ErrorDetails;
}

/**
 * WhatsApp Types
 */
export interface WhatsAppMessage {
  from: string;
  to: string;
  body: string;
  timestamp: number;
  messageId?: string;
}

export interface WhatsAppWebhookEvent {
  event: string;
  data: {
    id?: string;
    key?: {
      remoteJid: string;
      fromMe: boolean;
      id: string;
    };
    message?: {
      conversation: string;
      fromMe: boolean;
      id: string;
      timestamp: number;
    };
  };
}

/**
 * NPS Types
 */
export interface NPSSubmission {
  score: number;
  comment?: string;
  patientId: string;
  clinicId: string;
  appointmentId?: string;
}

/**
 * Analytics Types
 */
export interface AnalyticsMetrics {
  totalPatients: number;
  totalAppointments: number;
  activeDoctors: number;
  completedAppointments: number;
  cancelledAppointments: number;
  averageNPS: number;
}

/**
 * Time Range Types
 */
export interface TimeRange {
  start: number;
  end: number;
}

/**
 * Filter Types
 */
export interface FilterOptions {
  startDate?: number;
  endDate?: number;
  status?: string[];
  search?: string;
}

/**
 * Validation Types
 */
export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

/**
 * Document Processing Types
 */
export interface DocumentProcessingResult {
  success: boolean;
  extractedData?: Record<string, unknown>;
  errors?: string[];
}

/**
 * Automation Types
 */
export interface AutomationTrigger {
  type: "appointment_created" | "appointment_completed" | "patient_created" | "message_received";
  conditions?: Record<string, unknown>;
}

export interface AutomationAction {
  type: "send_whatsapp" | "send_email" | "update_status" | "create_task";
  params: Record<string, unknown>;
}

export interface Automation {
  id: string;
  name: string;
  triggers: AutomationTrigger[];
  actions: AutomationAction[];
  isActive: boolean;
  clinicId: string;
}

/**
 * Google Calendar Types
 */
export interface CalendarEvent {
  id?: string;
  summary: string;
  description?: string;
  start: { dateTime: string; timeZone?: string };
  end: { dateTime: string; timeZone?: string };
  attendees?: Array<{ email: string; displayName?: string }>;
  conferenceData?: {
    createRequest: { requestId: string; conferenceSolutionKey: { type: "hangoutsMeet" } };
  };
}

/**
 * Billing Types
 */
export interface Subscription {
  id: string;
  clinicId: string;
  plan: PlanType;
  status: SubscriptionStatus;
  currentPeriodEnd: number;
  cancelAtPeriodEnd: boolean;
}

export interface Payment {
  id: string;
  appointmentId?: string;
  amount: number;
  status: "pending" | "completed" | "failed" | "refunded";
  paymentMethod: string;
  createdAt: number;
}

/**
 * Utility Types
 */
export type WithRequired<T, K extends keyof T> = T & { [P in K]-?: T[P] };
export type WithOptional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;
