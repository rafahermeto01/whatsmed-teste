import { rateLimited } from "./errors";
import { internal } from "../_generated/api";

export type RateLimitResult = {
  allowed: boolean;
  limit: number;
  remaining: number;
  reset: number;
};

type HttpCtx = {
  runMutation: (mutation: any, args: any) => Promise<any>;
};

const DEFAULT_WINDOW_MS = 60_000;

export async function checkRateLimit(
  ctx: HttpCtx,
  key: string,
  limit: number,
  windowMs = DEFAULT_WINDOW_MS,
  clinicId?: string,
): Promise<RateLimitResult> {
  return ctx.runMutation((internal as any).rateLimit.check, {
    key,
    limit,
    windowMs,
    clinicId,
  });
}

export function throwIfRateLimited(result: RateLimitResult, message = "Too Many Requests") {
  if (!result.allowed) {
    throw rateLimited(message, {
      details: { limit: result.limit, remaining: result.remaining, reset: result.reset },
    });
  }
}

export function rateLimitHeaders(result: RateLimitResult) {
  return {
    "X-RateLimit-Limit": result.limit.toString(),
    "X-RateLimit-Remaining": result.remaining.toString(),
    "X-RateLimit-Reset": Math.ceil(result.reset / 1000).toString(),
  };
}

export function buildRateLimitKey(request: Request, category = "general") {
  const forwardedFor = request.headers.get("x-forwarded-for");
  const realIp = request.headers.get("x-real-ip");
  const candidate = forwardedFor?.split(",")[0]?.trim() || realIp || "unknown";
  return `${category}:${candidate || "unknown"}`;
}
