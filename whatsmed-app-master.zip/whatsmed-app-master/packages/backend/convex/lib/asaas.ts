const getBaseUrl = () => {
  const env = process.env.ASAAS_ENVIRONMENT || "sandbox";
  return env === "production" ? "https://api.asaas.com/v3" : "https://api-sandbox.asaas.com/v3";
};

const getApiKey = () => {
  const key = process.env.ASAAS_API_KEY;
  if (!key) throw new Error("ASAAS_API_KEY is not configured");
  return key;
};

async function asaasRequest(path: string, options: RequestInit = {}) {
  const url = `${getBaseUrl()}${path}`;
  const headers = {
    "Content-Type": "application/json",
    access_token: getApiKey(),
    ...options.headers,
  };

  const response = await fetch(url, {
    ...options,
    headers,
  });

  const data = await response.json();

  if (!response.ok) {
    console.error("Asaas API Error:", JSON.stringify(data, null, 2));
    throw new Error(`Asaas API Error: ${data.errors?.[0]?.description || response.statusText}`);
  }

  return data;
}

export const asaas = {
  createCustomer: async (customerData: {
    name: string;
    cpfCnpj: string;
    email?: string;
    phone?: string;
    mobilePhone?: string;
    externalReference?: string;
  }) => {
    return asaasRequest("/customers", {
      method: "POST",
      body: JSON.stringify(customerData),
    });
  },

  getCustomer: async (id: string) => {
    return asaasRequest(`/customers/${id}`, {
      method: "GET",
    });
  },

  createSubscription: async (subscriptionData: {
    customer: string;
    billingType: "BOLETO" | "CREDIT_CARD" | "PIX";
    value: number;
    nextDueDate: string;
    cycle: "WEEKLY" | "BIWEEKLY" | "MONTHLY" | "QUARTERLY" | "SEMIANNUALLY" | "YEARLY";
    description?: string;
    creditCard?: {
      holderName: string;
      number: string;
      expiryMonth: string;
      expiryYear: string;
      ccv: string;
    };
    creditCardToken?: string;
    remoteIp?: string;
  }) => {
    return asaasRequest("/subscriptions", {
      method: "POST",
      body: JSON.stringify(subscriptionData),
    });
  },

  updateSubscription: async (
    id: string,
    subscriptionData: {
      billingType?: "BOLETO" | "CREDIT_CARD" | "PIX";
      value?: number;
      cycle?: "WEEKLY" | "BIWEEKLY" | "MONTHLY" | "QUARTERLY" | "SEMIANNUALLY" | "YEARLY";
      status?: "ACTIVE" | "INACTIVE";
    },
  ) => {
    return asaasRequest(`/subscriptions/${id}`, {
      method: "PUT",
      body: JSON.stringify(subscriptionData),
    });
  },

  updateSubscriptionCreditCard: async (
    id: string,
    cardData: {
      creditCard: {
        holderName: string;
        number: string;
        expiryMonth: string;
        expiryYear: string;
        ccv: string;
      };
      creditCardHolderInfo: {
        name: string;
        email: string;
        cpfCnpj: string;
        postalCode: string;
        addressNumber: string;
        phone: string;
      };
      creditCardToken?: string;
      remoteIp: string;
    },
  ) => {
    return asaasRequest(`/subscriptions/${id}/creditCard`, {
      method: "PUT",
      body: JSON.stringify(cardData),
    });
  },

  cancelSubscription: async (id: string) => {
    return asaasRequest(`/subscriptions/${id}`, {
      method: "DELETE",
    });
  },

  createPayment: async (paymentData: {
    customer: string;
    billingType: "BOLETO" | "CREDIT_CARD" | "PIX";
    value: number;
    dueDate: string;
    description?: string;
    externalReference?: string;
    creditCard?: {
      holderName: string;
      number: string;
      expiryMonth: string;
      expiryYear: string;
      ccv: string;
    };
    creditCardToken?: string;
    remoteIp?: string;
  }) => {
    return asaasRequest("/payments", {
      method: "POST",
      body: JSON.stringify(paymentData),
    });
  },

  getPixQrCode: async (paymentId: string) => {
    return asaasRequest(`/payments/${paymentId}/pixQrCode`, {
      method: "GET",
    });
  },

  tokenizeCard: async (cardData: {
    customer: string;
    creditCard: {
      holderName: string;
      number: string;
      expiryMonth: string;
      expiryYear: string;
      ccv: string;
    };
    creditCardHolderInfo: {
      name: string;
      email: string;
      cpfCnpj: string;
      postalCode: string;
      addressNumber: string;
      phone: string;
    };
  }) => {
    return asaasRequest("/creditCard/tokenizeCreditCard", {
      method: "POST",
      body: JSON.stringify(cardData),
    });
  },
};
