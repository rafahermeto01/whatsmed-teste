export interface EvolutionInstance {
  instance: {
    instanceName: string;
    instanceId: string;
    status: string;
  };
  hash: {
    apikey: string;
  };
}

export interface ConnectResponse {
  base64: string;
  code: string;
  count: number;
}

export interface ConnectionState {
  instance: {
    instanceName: string;
    state: "open" | "close" | "connecting";
  };
}

export interface SendMessageResponse {
  key: {
    remoteJid: string;
    fromMe: boolean;
    id: string;
  };
}

const EVOLUTION_WEBHOOK_EVENTS = [
  "APPLICATION_STARTUP",
  "QRCODE_UPDATED",
  "MESSAGES_UPSERT",
  "MESSAGES_UPDATE",
  "MESSAGES_DELETE",
  "SEND_MESSAGE",
  "CONNECTION_UPDATE",
  "CHATS_UPSERT",
  "CHATS_UPDATE",
] as const;

function buildWebhookConfig(url: string, enabled = true) {
  return {
    enabled,
    url,
    byEvents: false,
    base64: true,
    events: [...EVOLUTION_WEBHOOK_EVENTS],
  };
}

export class EvolutionClient {
  private baseUrl: string;
  private apiKey: string;

  constructor(config?: { baseUrl?: string; apiKey?: string }) {
    this.baseUrl = config?.baseUrl || process.env.EVOLUTION_API_URL || "";
    this.apiKey = config?.apiKey || process.env.EVOLUTION_API_KEY || "";
  }

  private async request<T>(endpoint: string, method: string, body?: any): Promise<T> {
    if (!this.baseUrl) {
      throw new Error("EVOLUTION_API_URL is not configured");
    }

    const url = `${this.baseUrl}${endpoint}`;
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      apikey: this.apiKey,
    };

    const response = await fetch(url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Evolution API error: ${response.status} ${response.statusText} - ${error}`);
    }

    return response.json();
  }

  async createInstance(
    instanceName: string,
    webhookUrl?: string,
    options?: { groupsIgnore?: boolean },
  ): Promise<EvolutionInstance> {
    return this.request<EvolutionInstance>("/instance/create", "POST", {
      instanceName,
      qrcode: true,
      integration: "WHATSAPP-BAILEYS",
      groupsIgnore: options?.groupsIgnore ?? true,
      webhook: webhookUrl ? buildWebhookConfig(webhookUrl, true) : undefined,
    });
  }

  async connectInstance(instanceName: string): Promise<ConnectResponse> {
    return this.request<ConnectResponse>(`/instance/connect/${instanceName}`, "GET");
  }

  async getConnectionStatus(instanceName: string): Promise<ConnectionState> {
    return this.request<ConnectionState>(`/instance/connectionState/${instanceName}`, "GET");
  }

  async fetchInstance(
    instanceName: string,
  ): Promise<{ instance: { instanceName: string; status: string } } | null> {
    try {
      return await this.request<{ instance: { instanceName: string; status: string } }>(
        `/instance/fetchInstances?instanceName=${instanceName}`,
        "GET",
      );
    } catch {
      return null;
    }
  }

  async instanceExists(instanceName: string): Promise<boolean> {
    try {
      await this.request(`/instance/connectionState/${instanceName}`, "GET");
      return true;
    } catch {
      return false;
    }
  }

  async logoutInstance(instanceName: string): Promise<any> {
    return this.request(`/instance/logout/${instanceName}`, "DELETE");
  }

  async deleteInstance(instanceName: string): Promise<any> {
    return this.request(`/instance/delete/${instanceName}`, "DELETE");
  }

  async sendText(instanceName: string, number: string, text: string): Promise<SendMessageResponse> {
    return this.request<SendMessageResponse>(`/message/sendText/${instanceName}`, "POST", {
      number,
      text,
    });
  }

  async sendMedia(
    instanceName: string,
    options: {
      number: string;
      mediaUrl: string;
      type: "image" | "video" | "document" | "audio";
      caption?: string;
      fileName?: string;
    },
  ): Promise<SendMessageResponse> {
    const payload: Record<string, any> = {
      number: options.number,
      media: options.mediaUrl,
      mediatype: options.type,
      mediaType: options.type,
    };

    if (options.caption) payload.caption = options.caption;
    if (options.fileName) payload.fileName = options.fileName;

    try {
      return await this.request<SendMessageResponse>(
        `/message/sendMedia/${instanceName}`,
        "POST",
        payload,
      );
    } catch {
      return await this.request<SendMessageResponse>(
        `/message/sendFile/${instanceName}`,
        "POST",
        payload,
      );
    }
  }

  async findChats(instanceName: string): Promise<any[]> {
    return this.request<any[]>(`/chat/findChats/${instanceName}`, "GET");
  }

  async findMessages(
    instanceName: string,
    remoteJid: string,
    page = 1,
    limit = 50,
  ): Promise<any[]> {
    return this.request<any[]>(`/chat/findMessages/${instanceName}`, "POST", {
      where: {
        key: {
          remoteJid,
        },
      },
      page,
      offset: limit,
    });
  }

  async findContacts(instanceName: string): Promise<any[]> {
    return this.request<any[]>(`/chat/findContacts/${instanceName}`, "POST", {});
  }

  async fetchProfile(
    instanceName: string,
    number: string,
  ): Promise<{ name?: string; status?: string; picture?: string }> {
    return this.request<{ name?: string; status?: string; picture?: string }>(
      `/chat/fetchProfile/${instanceName}`,
      "POST",
      { number },
    );
  }

  async fetchProfilePictureUrl(
    instanceName: string,
    number: string,
  ): Promise<{ profilePictureUrl?: string } | null> {
    try {
      return await this.request<{ profilePictureUrl?: string }>(
        `/chat/fetchProfilePictureUrl/${instanceName}`,
        "POST",
        { number },
      );
    } catch {
      // Some users may not have a profile picture or have privacy settings
      return null;
    }
  }

  async getBase64FromMediaMessage(
    instanceName: string,
    messageId: string,
    convertToMp4 = false,
  ): Promise<{ base64: string; mimetype: string }> {
    const response = await this.request<any>(
      `/chat/getBase64FromMediaMessage/${instanceName}`,
      "POST",
      {
        message: { key: { id: messageId } },
        convertToMp4,
      },
    );

    // Evolution API might return base64 directly or in a nested structure
    // Handle both cases
    if (typeof response === "string") {
      // If response is just a base64 string
      return {
        base64: response,
        mimetype: "application/octet-stream",
      };
    }

    if (response.base64) {
      return {
        base64: response.base64,
        mimetype: response.mimetype || response.mimeType || "application/octet-stream",
      };
    }

    // Try alternative response structures
    if (response.data?.base64) {
      return {
        base64: response.data.base64,
        mimetype: response.data.mimetype || response.data.mimeType || "application/octet-stream",
      };
    }

    throw new Error(
      `Unexpected response format from Evolution API: ${JSON.stringify(response).substring(0, 200)}`,
    );
  }

  async fetchContactByJid(
    instanceName: string,
    remoteJid: string,
  ): Promise<{ pushName?: string; profilePicUrl?: string } | null> {
    try {
      const contacts = await this.findContacts(instanceName);
      const contact = contacts.find((c: any) => c.id === remoteJid || c.remoteJid === remoteJid);
      if (contact) {
        return {
          pushName: contact.pushName || contact.name || contact.notify,
          profilePicUrl: contact.profilePicUrl,
        };
      }
      return null;
    } catch {
      return null;
    }
  }

  async setWebhook(instanceName: string, url: string, enabled = true): Promise<any> {
    return this.request(`/webhook/set/${instanceName}`, "POST", {
      webhook: buildWebhookConfig(url, enabled),
    });
  }
}
