const DEFAULT_LIMIT = 50;
const MAX_LIMIT = 1000;

export type PaginationParams = {
  limit?: number;
  cursor?: string;
};

export function parsePaginationParams(params: PaginationParams = {}) {
  const limit =
    typeof params.limit === "number" && params.limit > 0
      ? Math.min(params.limit, MAX_LIMIT)
      : DEFAULT_LIMIT;

  const cursor = params.cursor && params.cursor.length > 0 ? params.cursor : undefined;

  return { limit, cursor };
}

export function buildPaginatedResponse<T>(items: T[], cursor?: string | null, total?: number) {
  return {
    items,
    ...(cursor ? { cursor } : {}),
    ...(typeof total === "number" ? { total } : {}),
  };
}

export const paginationDefaults = {
  DEFAULT_LIMIT,
  MAX_LIMIT,
};
