import { api } from "../_generated/api";
import { forbidden, unauthorized } from "./errors";
import { requireClinicId } from "./multiTenant";

export type Role = "admin" | "staff" | "viewer" | "super_admin" | "doctor";

type CtxWithAuth = {
  auth: {
    getUserIdentity: () => Promise<any>;
  };
  db?: any; // Use any to accept Convex's typed db context
  runQuery?: (queryRef: any, args: any) => Promise<any>;
};

type AuthContext = {
  appUser: any;
  clinicId: string | null;
  role: Role;
  identity: any;
};

async function getAppUser(ctx: CtxWithAuth, identity: any) {
  if (!identity?.email) {
    return null;
  }

  if (ctx.db) {
    return await ctx.db
      .query("users")
      .withIndex("by_email", (q: any) => q.eq("email", identity.email))
      .first();
  }

  if (ctx.runQuery) {
    return await ctx.runQuery(api.users.getByEmail, { email: identity.email });
  }

  return null;
}

export async function getAuthContext(ctx: CtxWithAuth): Promise<AuthContext> {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) {
    throw unauthorized("Authentication required");
  }

  const appUser = await getAppUser(ctx, identity);
  if (appUser && (!appUser.isActive || appUser.deletedAt)) {
    throw unauthorized("Inactive user");
  }

  const role =
    appUser?.role ??
    (identity as any)?.role ??
    (identity as any)?.metadata?.role ??
    (identity as any)?.claims?.role ??
    null;

  if (!role) {
    throw forbidden("Insufficient role");
  }

  const clinicId =
    appUser?.clinicId ??
    (identity as any)?.clinicId ??
    (identity as any)?.claims?.clinicId ??
    (identity as any)?.metadata?.clinicId ??
    null;

  return {
    appUser,
    clinicId,
    role: role as Role,
    identity,
  };
}

export async function requireRole(ctx: CtxWithAuth, allowed: Role[]) {
  const { clinicId, identity, role } = await getAuthContext(ctx);

  if (!role || !allowed.includes(role as Role)) {
    throw forbidden("Insufficient role");
  }

  // Super admin can bypass clinic requirements
  if (role === "super_admin") {
    return { clinicId: null, role: role as Role, identity };
  }

  const ensuredClinicId = clinicId ?? (await requireClinicId(ctx)).clinicId;
  return { clinicId: ensuredClinicId, role: role as Role, identity };
}

export async function requireClinicAccess(ctx: CtxWithAuth, targetClinicId: string) {
  const auth = await getAuthContext(ctx);

  if (auth.role === "super_admin") {
    return auth;
  }

  if (!auth.clinicId || auth.clinicId !== targetClinicId) {
    throw forbidden("Access denied to this clinic");
  }

  return auth;
}

export async function requireClinicRole(ctx: CtxWithAuth, targetClinicId: string, allowed: Role[]) {
  const auth = await requireClinicAccess(ctx, targetClinicId);

  if (!allowed.includes(auth.role)) {
    throw forbidden("Insufficient role");
  }

  return {
    clinicId: auth.role === "super_admin" ? targetClinicId : auth.clinicId,
    role: auth.role,
    identity: auth.identity,
    appUser: auth.appUser,
  };
}

export function isAdmin(role: Role) {
  return role === "admin" || role === "super_admin";
}
