import type { Id } from "../_generated/dataModel";
import type { MutationCtx } from "../_generated/server";

type UpsertUserInput = {
  email: string;
  name: string;
  role: "admin" | "staff" | "viewer";
  phone?: string;
};

type UpsertPatientInput = {
  name: string;
  email?: string;
  phone?: string;
  status?: "active" | "inactive";
};

async function ensureUser(ctx: MutationCtx, clinicId: string, input: UpsertUserInput) {
  const existing = await ctx.db
    .query("users")
    .withIndex("by_clinic_email", (q) => q.eq("clinicId", clinicId).eq("email", input.email))
    .first();
  const now = Date.now();

  if (existing) return existing._id;

  return ctx.db.insert("users", {
    authUserId: crypto.randomUUID(),
    clinicId,
    email: input.email,
    name: input.name,
    role: input.role,
    phone: input.phone,
    isActive: true,
    lastLoginAt: undefined,
    createdAt: now,
    deletedAt: undefined,
  });
}

async function ensurePatient(ctx: MutationCtx, clinicId: string, input: UpsertPatientInput) {
  if (input.email) {
    const existingByEmail = await ctx.db
      .query("patients")
      .withIndex("by_clinic_email", (q) => q.eq("clinicId", clinicId).eq("email", input.email))
      .first();
    if (existingByEmail) return existingByEmail._id;
  }

  if (input.phone) {
    const existingByPhone = await ctx.db
      .query("patients")
      .withIndex("by_clinic_phone", (q) => q.eq("clinicId", clinicId).eq("phone", input.phone))
      .first();
    if (existingByPhone) return existingByPhone._id;
  }

  const now = Date.now();
  return ctx.db.insert("patients", {
    clinicId,
    name: input.name,
    email: input.email,
    phone: input.phone,
    status: input.status ?? "active",
    tags: [],
    notes: undefined,
    externalId: undefined,
    createdAt: now,
    updatedAt: now,
    deletedAt: undefined,
  });
}

export async function loadLocalFixtures(ctx: MutationCtx, clinicId = "clinic-demo") {
  const [adminId, staffId, viewerId] = await Promise.all([
    ensureUser(ctx, clinicId, {
      email: "admin@demo.test",
      name: "Demo Admin",
      role: "admin",
      phone: "+5511999999911",
    }),
    ensureUser(ctx, clinicId, {
      email: "staff@demo.test",
      name: "Demo Staff",
      role: "staff",
      phone: "+5511999999922",
    }),
    ensureUser(ctx, clinicId, {
      email: "viewer@demo.test",
      name: "Demo Viewer",
      role: "viewer",
      phone: "+5511999999933",
    }),
  ]);

  const patientA = await ensurePatient(ctx, clinicId, {
    name: "Alice Cardoso",
    email: "alice@demo.test",
    phone: "+5511990000001",
  });
  const patientB = await ensurePatient(ctx, clinicId, {
    name: "Bruno Silva",
    phone: "+5511990000002",
    status: "active",
  });

  const now = Date.now();

  const appointmentExisting = await ctx.db
    .query("appointments")
    .withIndex("by_clinic_patient_date", (q) =>
      q.eq("clinicId", clinicId).eq("patientId", patientA).gte("startAt", now),
    )
    .first();

  const appointmentId = appointmentExisting?._id
    ? appointmentExisting._id
    : await ctx.db.insert("appointments", {
        clinicId,
        patientId: patientA,
        startAt: now + 60 * 60 * 1000,
        endAt: now + 90 * 60 * 1000,
        status: "confirmed",
        doctor: "Dr. Demo",
        procedure: "Initial consultation",
        notes: "Bring previous exams.",
        reminderAt: now + 30 * 60 * 1000,
        createdAt: now,
        updatedAt: now,
        deletedAt: undefined,
      });

  let wallet = await ctx.db
    .query("wallets")
    .withIndex("by_clinic", (q) => q.eq("clinicId", clinicId))
    .first();
  if (!wallet) {
    const walletId = await ctx.db.insert("wallets", {
      clinicId,
      balance: 50000,
      currency: "BRL",
      autoRechargeEnabled: false,
      autoRechargeThreshold: undefined,
      autoRechargeAmount: undefined,
      providerCustomerId: undefined,
      createdAt: now,
      updatedAt: now,
    });
    wallet = await ctx.db.get(walletId);
  }

  const walletId = wallet!._id as Id<"wallets">;

  const transactionCount = await ctx.db
    .query("transactions")
    .withIndex("by_wallet_createdAt", (q) => q.eq("walletId", walletId))
    .take(1);
  if (transactionCount.length === 0) {
    await ctx.db.insert("transactions", {
      clinicId,
      walletId,
      type: "topup",
      amount: 50000,
      currency: "BRL",
      providerRef: "demo-topup",
      status: "succeeded",
      reason: "Initial credit",
      meta: { source: "fixtures" },
      createdAt: now,
      updatedAt: now,
    });
  }

  const defaultCard = await ctx.db
    .query("paymentMethods")
    .withIndex("by_wallet_createdAt", (q) => q.eq("walletId", walletId))
    .first();
  if (!defaultCard) {
    await ctx.db.insert("paymentMethods", {
      clinicId,
      walletId,
      brand: "visa",
      last4: "4242",
      expMonth: 12,
      expYear: new Date().getFullYear() + 2,
      holder: "Demo Admin",
      fingerprint: "demo-card-fingerprint",
      providerPaymentMethodId: "pm_demo",
      isDefault: true,
      createdAt: now,
      updatedAt: now,
    });
  }

  const chat = await ctx.db
    .query("chats")
    .withIndex("by_clinic_whatsappId", (q) =>
      q.eq("clinicId", clinicId).eq("whatsappChatId", "demo-chat"),
    )
    .first();

  const chatId: Id<"chats"> =
    chat?._id ??
    (await ctx.db.insert("chats", {
      clinicId,
      patientId: patientB,
      whatsappChatId: "demo-chat",
      title: "Demo Chat",
      unreadCount: 0,
      status: "open",
      lastMessageAt: now,
      avatarUrl: undefined,
      online: true,
      createdAt: now,
      updatedAt: now,
    }));

  const existingMessages = await ctx.db
    .query("messages")
    .withIndex("by_clinic_chat_sent", (q) => q.eq("clinicId", clinicId).eq("chatId", chatId))
    .take(1);
  if (existingMessages.length === 0) {
    await ctx.db.insert("messages", {
      clinicId,
      chatId,
      direction: "in",
      type: "text",
      body: "Ola! Preciso remarcar minha consulta.",
      mediaIds: undefined,
      sentAt: now,
      status: "delivered",
      authorUserId: undefined,
      createdAt: now,
      updatedAt: now,
    });
    await ctx.db.insert("messages", {
      clinicId,
      chatId,
      direction: "out",
      type: "text",
      body: "Claro! Vamos encontrar um horário para você.",
      mediaIds: undefined,
      sentAt: now + 1000,
      status: "sent",
      authorUserId: adminId.toString(),
      createdAt: now + 1000,
      updatedAt: now + 1000,
    });
  }

  const apiKey = await ctx.db
    .query("apiKeys")
    .withIndex("by_clinic_prefix", (q) => q.eq("clinicId", clinicId).eq("prefix", "demo_"))
    .first();
  if (!apiKey) {
    await ctx.db.insert("apiKeys", {
      clinicId,
      name: "Demo Key",
      prefix: "demo_",
      hashedSecret: "demo_hashed_secret",
      lastUsedAt: undefined,
      scopes: ["read", "write"],
      rotatedAt: undefined,
      revokedAt: undefined,
      createdAt: now,
      updatedAt: now,
    });
  }

  const upload = await ctx.db
    .query("uploads")
    .withIndex("by_clinic_checksum", (q) =>
      q.eq("clinicId", clinicId).eq("checksum", "demo-checksum"),
    )
    .first();
  if (!upload) {
    // For fixtures, create a minimal storage entry
    // const storageId = await ctx.storage.store(
    //   new Blob([Buffer.from("demo content")], { type: "application/pdf" }),
    //   "application/pdf"
    // );
    const storageId = "mock_storage_id" as any;

    await ctx.db.insert("uploads", {
      clinicId,
      url: "https://example.com/demo-file.pdf",
      filename: "demo-file.pdf",
      size: 1024,
      mimeType: "application/pdf",
      checksum: "demo-checksum",
      linkedResource: { type: "patient", id: patientA.toString() },
      providerKey: undefined,
      storageId,
      expiresAt: now + 48 * 60 * 60 * 1000, // 48 hours
      downloads: 0,
      createdAt: now,
      updatedAt: now,
    });
  }

  const webhook = await ctx.db
    .query("webhookEvents")
    .withIndex("by_clinic_status_createdAt", (q) =>
      q.eq("clinicId", clinicId).eq("status", "pending"),
    )
    .first();
  if (!webhook) {
    await ctx.db.insert("webhookEvents", {
      clinicId,
      eventType: "patient.created",
      payload: { id: patientA.toString() },
      status: "pending",
      endpointUrl: "https://webhook.site/demo",
      signature: undefined,
      attempts: 0,
      lastAttemptAt: undefined,
      nextAttemptAt: undefined,
      createdAt: now,
      updatedAt: now,
    });
  }

  return {
    clinicId,
    users: [adminId, staffId, viewerId],
    patients: [patientA, patientB],
    appointmentId,
    walletId,
    chatId,
  };
}
