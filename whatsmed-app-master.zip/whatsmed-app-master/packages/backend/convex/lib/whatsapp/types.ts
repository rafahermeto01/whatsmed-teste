export interface SendTextOptions {
  to: string;
  text: string;
}

export interface SendMediaOptions {
  to: string;
  url: string;
  caption?: string;
  type: "image" | "video" | "document" | "audio";
}

export interface WhatsAppProfile {
  name?: string;
  pictureUrl?: string;
  status?: string;
}

export interface IWhatsAppProvider {
  /**
   * Send a text message
   */
  sendText(options: SendTextOptions): Promise<{ messageId: string }>;

  /**
   * Send a media message (image, video, document, audio)
   */
  sendMedia(options: SendMediaOptions): Promise<{ messageId: string }>;

  /**
   * Get contact profile information
   */
  getProfile(phone: string): Promise<WhatsAppProfile | null>;

  /**
   * Check connection health/status
   */
  checkHealth(): Promise<{ status: "connected" | "disconnected" | "connecting" }>;
}
