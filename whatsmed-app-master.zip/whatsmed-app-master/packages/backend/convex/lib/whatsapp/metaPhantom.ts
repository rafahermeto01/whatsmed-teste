import { IWhatsAppProvider, SendMediaOptions, SendTextOptions, WhatsAppProfile } from "./types";

export class MetaPhantomProvider implements IWhatsAppProvider {
  private phoneNumberId: string;

  constructor(phoneNumberId: string) {
    this.phoneNumberId = phoneNumberId;
  }

  async sendText(options: SendTextOptions): Promise<{ messageId: string }> {
    console.log(`[MetaPhantom] Sending text to ${options.to}: ${options.text}`);
    // Simulate successful send
    return {
      messageId: `wamid.HBgN${Math.random().toString(36).substring(7)}`,
    };
  }

  async sendMedia(options: SendMediaOptions): Promise<{ messageId: string }> {
    console.log(`[MetaPhantom] Sending media (${options.type}) to ${options.to}: ${options.url}`);
    return {
      messageId: `wamid.HBgN${Math.random().toString(36).substring(7)}`,
    };
  }

  async getProfile(phone: string): Promise<WhatsAppProfile | null> {
    console.log(`[MetaPhantom] Getting profile for ${phone}`);
    return {
      name: "Phantom User",
      status: "Available (Phantom)",
    };
  }

  async checkHealth(): Promise<{ status: "connected" | "disconnected" | "connecting" }> {
    return { status: "connected" };
  }
}
