import { EvolutionClient } from "../evolution";
import { IWhatsAppProvider, SendMediaOptions, SendTextOptions, WhatsAppProfile } from "./types";

export class EvolutionProvider implements IWhatsAppProvider {
  private client: EvolutionClient;
  private instanceName: string;

  constructor(instanceName: string, apiKey?: string, baseUrl?: string) {
    this.client = new EvolutionClient({ apiKey, baseUrl });
    this.instanceName = instanceName;
  }

  async sendText(options: SendTextOptions): Promise<{ messageId: string }> {
    const response = await this.client.sendText(this.instanceName, options.to, options.text);
    return { messageId: response.key.id };
  }

  async sendMedia(options: SendMediaOptions): Promise<{ messageId: string }> {
    const fallbackName =
      options.type === "image"
        ? "image"
        : options.type === "video"
          ? "video"
          : options.type === "audio"
            ? "audio"
            : "document";

    const fileName = options.url.split("?")[0]?.split("/").pop() || fallbackName;

    const response = await this.client.sendMedia(this.instanceName, {
      number: options.to,
      mediaUrl: options.url,
      type: options.type,
      caption: options.caption,
      fileName,
    });

    return { messageId: response.key.id };
  }

  async getProfile(phone: string): Promise<WhatsAppProfile | null> {
    const profile = await this.client.fetchProfile(this.instanceName, phone);
    if (!profile) return null;

    return {
      name: profile.name,
      status: profile.status,
      pictureUrl: profile.picture,
    };
  }

  async checkHealth(): Promise<{ status: "connected" | "disconnected" | "connecting" }> {
    try {
      const state = await this.client.getConnectionStatus(this.instanceName);
      const status = state.instance.state;

      if (status === "open") return { status: "connected" };
      if (status === "connecting") return { status: "connecting" };
      return { status: "disconnected" };
    } catch {
      return { status: "disconnected" };
    }
  }
}
