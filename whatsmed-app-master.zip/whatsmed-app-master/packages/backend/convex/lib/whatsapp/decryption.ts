"use node";

import { createDecipheriv, createHmac } from "crypto";

// Info strings for HKDF based on media type
const MEDIA_HKDF_INFO = {
  image: "WhatsApp Image Keys",
  video: "WhatsApp Video Keys",
  audio: "WhatsApp Audio Keys",
  document: "WhatsApp Document Keys",
  sticker: "WhatsApp Image Keys", // Stickers use Image Keys
  ptv: "WhatsApp Video Keys",
};

/**
 * HKDF key derivation (HMAC-based Key Derivation Function)
 * implementation for WhatsApp media keys
 */
function hkdf(key: Buffer, info: string, length: number = 112): Buffer {
  const salt = Buffer.alloc(32); // WhatsApp uses 32 bytes of 0s as salt
  const prk = createHmac("sha256", salt).update(key).digest();

  const infoBuffer = Buffer.from(info);
  let t = Buffer.alloc(0);
  let okm = Buffer.alloc(0);
  let i = 0;

  while (okm.length < length) {
    i++;
    const hmac = createHmac("sha256", prk);
    if (i > 1) {
      hmac.update(t);
    }
    hmac.update(infoBuffer);
    hmac.update(Buffer.from([i]));
    t = hmac.digest();
    okm = Buffer.concat([okm, t]);
  }

  return okm.slice(0, length);
}

/**
 * Decrypts WhatsApp media buffer
 * @param encryptedMedia The raw encrypted buffer downloaded from mmg.whatsapp.net
 * @param mediaKey The base64 mediaKey from the message payload
 * @param mediaType The type of media (image, video, etc.)
 */
export function decryptMedia(
  encryptedMedia: Buffer,
  mediaKey: string,
  mediaType: "image" | "video" | "audio" | "document" | "sticker",
): Buffer {
  // 1. Decode media key
  const mediaKeyBuffer = Buffer.from(mediaKey, "base64");
  if (mediaKeyBuffer.length !== 32) {
    throw new Error(`Invalid mediaKey length: ${mediaKeyBuffer.length}`);
  }

  // 2. Derive keys using HKDF
  const info = MEDIA_HKDF_INFO[mediaType];
  if (!info) {
    throw new Error(`Unsupported media type for decryption: ${mediaType}`);
  }

  const derivedKeys = hkdf(mediaKeyBuffer, info);

  // 3. Extract keys
  // IV: bytes 0-16
  // Cipher Key: bytes 16-48
  // Mac Key: bytes 48-80
  const iv = derivedKeys.slice(0, 16);
  const cipherKey = derivedKeys.slice(16, 48);
  // const macKey = derivedKeys.slice(48, 80); // Used for validating HMAC, skipping for now

  // 4. Decrypt content (AES-CBC)
  // The file ends with 10 bytes of MAC which we should ignore for decryption (or use to validate)
  // Usually standard decryption handles the length, but WhatsApp appends MAC.
  // We strictly need to slice off the MAC if we are decrypting?
  // Actually, standard practice is: encrypted content + 10 bytes MAC.
  // Let's try decrypting the whole thing minus 10 bytes.

  const encryptedContent = encryptedMedia.slice(0, encryptedMedia.length - 10);

  const decipher = createDecipheriv("aes-256-cbc", cipherKey, iv);

  // Disable auto padding because file size might not be multiple of block size?
  // WhatsApp uses PKCS7 padding usually?
  // Baileys implementation doesn't disable padding.

  const decrypted = Buffer.concat([decipher.update(encryptedContent), decipher.final()]);

  return decrypted;
}
