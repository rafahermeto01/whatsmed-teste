import { EvolutionProvider } from "./evolutionProvider";
import { MetaPhantomProvider } from "./metaPhantom";
import { IWhatsAppProvider } from "./types";

export interface ProviderConfig {
  provider?: "evolution" | "meta";
  // Evolution config
  instanceName?: string;
  evolutionApiKey?: string;
  evolutionUrl?: string;
  // Meta config
  metaPhoneNumberId?: string;
  metaWabaId?: string;
  metaAccessToken?: string;
}

export class WhatsAppProviderFactory {
  static getProvider(config: ProviderConfig): IWhatsAppProvider {
    if (config.provider === "meta") {
      if (!config.metaPhoneNumberId) {
        throw new Error("Meta Phone Number ID is required for Meta provider");
      }
      return new MetaPhantomProvider(config.metaPhoneNumberId);
    }

    // Default to Evolution
    if (!config.instanceName) {
      throw new Error("Instance Name is required for Evolution provider");
    }
    return new EvolutionProvider(config.instanceName, config.evolutionApiKey, config.evolutionUrl);
  }
}
