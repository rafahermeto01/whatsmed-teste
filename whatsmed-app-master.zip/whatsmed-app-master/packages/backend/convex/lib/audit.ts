import { internal as internalApi } from "../_generated/api";
import { type ActionCtx } from "../_generated/server";

export type AuditAction =
  | "LOGIN"
  | "RESET_REQUEST"
  | "RESET_CONFIRM"
  | "USER_CREATE"
  | "USER_UPDATE_ROLE"
  | "USER_DELETE"
  | "PATIENT_CREATE"
  | "PATIENT_UPDATE"
  | "PATIENT_DELETE"
  | "PATIENT_IMPORT";

type AuditPayload = {
  action: AuditAction;
  clinicId?: string | null;
  userId?: string | null;
  email?: string | null;
  userAgent?: string | null;
  metadata?: Record<string, any>;
};

export async function writeAudit(ctx: ActionCtx, payload: AuditPayload) {
  const internal = internalApi as any;
  const doc = {
    action: payload.action,
    clinicId: payload.clinicId ?? "unknown",
    userId: payload.userId ?? undefined,
    email: payload.email ?? undefined,
    userAgent: payload.userAgent ?? undefined,
    metadata: payload.metadata ?? undefined,
    createdAt: Date.now(),
  };

  await ctx.runMutation(internal.auditLogs.insert, doc);
}
