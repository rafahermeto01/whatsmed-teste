const INTERNAL_FIELD_LABELS = [
  "_id",
  "doctorId",
  "procedureId",
  "patientId",
  "appointmentId",
  "storageId",
  "mediaStorageId",
  "messageId",
  "chatId",
  "ticketId",
];

const ENGLISH_TO_PATIENT_PORTUGUESE: Array<[RegExp, string]> = [
  [/\bappointment not found\b/gi, "Nao consegui localizar esse agendamento"],
  [/\bpatient not found\b/gi, "Nao consegui localizar esse cadastro"],
  [/\bdoctor not found\b/gi, "Nao consegui localizar esse medico"],
  [/\bno doctor found with name\b/gi, "Nao encontrei medico com o nome"],
  [/\bno doctors found\b/gi, "Nao encontrei medicos disponiveis"],
  [/\bprocedure not found\b/gi, "Nao consegui localizar esse procedimento"],
  [/\bno procedure found\b/gi, "Nao encontrei esse procedimento"],
  [/\bno procedures found\b/gi, "Nao encontrei procedimentos disponiveis"],
  [/\bno available slots?\b/gi, "Nao encontrei horarios disponiveis"],
  [/\bno slots available\b/gi, "Nao encontrei horarios disponiveis"],
  [/\buse one of these dates\b/gi, "Posso te mostrar as datas disponiveis"],
  [/\buse one of these time slots\b/gi, "Posso te mostrar os horarios disponiveis"],
  [/\bcurrent date is\b/gi, "A data de referencia e"],
  [/\bthe current date is\b/gi, "A data de referencia e"],
  [/\btransfer you to\b/gi, "encaminhar voce para"],
  [/\bhuman attendant\b/gi, "atendente humano"],
  [/\bhuman support\b/gi, "equipe humana"],
  [
    /\bplease check the spelling or try a different name\b/gi,
    "confira o nome e, se quiser, me diga outra opcao",
  ],
  [/\bplease check the spelling\b/gi, "confira o nome informado"],
  [/\bplease try again\b/gi, "tente novamente"],
  [/\bsuccessfully\b/gi, "com sucesso"],
  [/\bimportant:?\b/gi, "Importante:"],
  [/\bdate\(s\)\b/gi, "data(s)"],
  [/\btime slot\(s\)\b/gi, "horario(s)"],
  [/\bdoctor\b/gi, "medico"],
  [/\bprocedure\b/gi, "procedimento"],
  [/\bpatient\b/gi, "paciente"],
  [/\bappointment\b/gi, "agendamento"],
  [/\bavailable\b/gi, "disponivel"],
  [/\bunavailable\b/gi, "indisponivel"],
];

const META_RESPONSE_LINE_PATTERNS = [
  /^ai\s*answer\s*:/i,
  /^we\s+must\b/i,
  /^we\s+have\b/i,
  /^we\s+should\b/i,
  /^i\s+should\b/i,
  /^need\s+to\b/i,
  /^the\s+assistant\s+should\b/i,
  /^respond\s+in\b/i,
  /^keep\s+it\b/i,
  /^be\s+concise\b/i,
  /^let'?s\s+craft\b/i,
  /^good\.?\s+ensure\b/i,
  /^provide\s+confirmation\b/i,
  /^provide\s+availability\b/i,
  /^displaytext\b/i,
  /^ask\s+one\s+question\s+at\s+a\s+time\b/i,
  /^do\s+not\s+repeat\b/i,
  /^must\s+be\s+max\b/i,
  /^the\s+user\s+asked\b/i,
  /^assistant\s+previously\s+said\b/i,
  /^also\s+earlier\b/i,
  /^let'?s\s+produce\b/i,
  /^so\s+reply\s*:/i,
  /^ferramenta\s+chamada\b/i,
  /^resultado\s+persistido\s+da\s+ferramenta\b/i,
  /^resultado\s+da\s+ferramenta\b/i,
  /^args\s*=/i,
  /^updatedfields\b/i,
  /^success\s*:/i,
];

const TOOL_TRACE_BLOCK_PATTERNS = [
  /\[\s*ferramenta\s+chamada\s*\][\s\S]*?(?=(?:\n\n|$))/gi,
  /\[\s*resultado\s+persistido\s+da\s+ferramenta[^\]]*\][\s\S]*?(?=(?:\n\n|$))/gi,
  /\bferramenta\s+chamada\b[\s\S]*?(?=(?:obrigado|perfeito|certo|ok|entendi|qual|quando|por favor|pode|vamos|$))/gi,
  /\bresultado\s+persistido\s+da\s+ferramenta\b[\s\S]*?(?=(?:obrigado|perfeito|certo|ok|entendi|qual|quando|por favor|pode|vamos|$))/gi,
  /\bargs\s*=\s*[^\n]+/gi,
  /\bupdatedFields\s*:\s*[^\n]+/gi,
  /\bsuccess\s*:\s*;?/gi,
];

function stripInternalIdLines(text: string): string {
  let next = text;

  next = next.replace(/\bID do agendamento\s*:\s*[A-Za-z0-9_-]{6,}\.?/gi, "");
  next = next.replace(/\b(?:internal|convex)?\s*id\s*:\s*[A-Za-z0-9_-]{6,}\.?/gi, "");

  for (const label of INTERNAL_FIELD_LABELS) {
    const escaped = label.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&");
    next = next.replace(
      new RegExp(`(^|\\n)\\s*[-*]?\\s*${escaped}\\s*[:=]\\s*[A-Za-z0-9_-]{6,}\\s*(?=$|\\n)`, "gi"),
      "$1",
    );
    next = next.replace(new RegExp(`\\b${escaped}\\s*[:=]\\s*"?[A-Za-z0-9_-]{6,}"?`, "gi"), "");
  }

  next = next.replace(/\b[A-Za-z0-9]{24,}\b/g, "");
  return next;
}

function translateCommonEnglish(text: string): string {
  let next = text;
  for (const [pattern, replacement] of ENGLISH_TO_PATIENT_PORTUGUESE) {
    next = next.replace(pattern, replacement);
  }
  return next;
}

function normalizeSpacing(text: string): string {
  return text
    .replace(/[ \t]+/g, " ")
    .replace(/\s+([,.;!?])/g, "$1")
    .replace(/([,.;!?])(\S)/g, "$1 $2")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/(?:\n\s*){2,}/g, "\n\n")
    .replace(/\s{2,}/g, " ")
    .trim();
}

function stripToolTraceLeakage(text: string): string {
  let next = text;

  for (const pattern of TOOL_TRACE_BLOCK_PATTERNS) {
    next = next.replace(pattern, " ");
  }

  return next;
}

function stripMetaResponseLeadIn(text: string): string {
  let next = text.trim();

  for (let pass = 0; pass < 6; pass += 1) {
    const lines = next
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean);

    if (lines.length === 0) {
      return "";
    }

    const firstLine = lines[0];
    if (!META_RESPONSE_LINE_PATTERNS.some((pattern) => pattern.test(firstLine))) {
      break;
    }

    lines.shift();
    next = lines.join("\n").trim();
  }

  next = next.replace(
    /^(?:ai\s*answer\s*:|we\s+must\b|we\s+should\b|i\s+should\b|the\s+assistant\s+should\b|respond\s+in\b|provide\s+availability\b|ask\s+one\s+question\s+at\s+a\s+time\b|do\s+not\s+repeat\b)[^.!?\n]*[.!?]\s*/i,
    "",
  );

  next = next.replace(
    /^(?:the\s+assistant\s+previously\s+said|also\s+earlier|now\s+user\s+asked|so\s+reply\s*:)[^.!?\n]*[.!?]\s*/i,
    "",
  );

  return next.trim();
}

export function sanitizePatientFacingResponse(text: string | null | undefined): string | null {
  if (typeof text !== "string") return null;

  let next = text.trim();
  if (!next) return null;

  next = stripMetaResponseLeadIn(next);
  next = stripToolTraceLeakage(next);
  next = stripMetaResponseLeadIn(next);
  next = stripInternalIdLines(next);
  next = translateCommonEnglish(next);
  next = next
    .replace(/\b(?:tool|payload|validator|context|thread|storage)\b/gi, "")
    .replace(/\b(?:true|false|null|undefined)\b/gi, "")
    .replace(/[{}"]+|\[+|\]+/g, " ");
  next = normalizeSpacing(next);

  if (!next) {
    return "Obrigado pela sua mensagem. Vou te ajudar da melhor forma possivel.";
  }

  return next;
}
