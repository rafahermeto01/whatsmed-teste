/**
 * Removes all non-digit characters from a phone number string
 * @param phone - The phone number string
 * @returns Digits only string
 */
export function cleanPhone(phone: string): string {
  return phone.replace(/\D/g, "");
}

/**
 * Formats a phone number to E.164 standard (+CCXXXXXXXXXX)
 * Defaults to Brazil (+55) if no country code is detected
 * @param phone - The input phone number
 * @param defaultCountryCode - The country code to use if none is present (default: 55 for Brazil)
 * @returns E.164 formatted string or null if invalid
 */
export function formatToE164(phone: string, defaultCountryCode: string = "55"): string | null {
  if (!phone) return null;

  // If it starts with +, keep it as is (after cleaning non-digits except +)
  const isInternational = phone.trim().startsWith("+");
  let digits = cleanPhone(phone);

  if (!digits) return null;

  if (isInternational) {
    return `+${digits}`;
  }

  // Heuristic for Brazil
  // 10 digits: DDD + Landline (e.g., 11 3333 4444)
  // 11 digits: DDD + Mobile (e.g., 11 99999 4444)
  if (digits.length === 10 || digits.length === 11) {
    return `+${defaultCountryCode}${digits}`;
  }

  // If length implies it might already include country code (e.g. 12 or 13 digits starting with 55)
  // But without the + sign, it's ambiguous.
  // However, if we assume default Brazil, and we get 12/13 digits, it's likely DDI+DDD+Phone.
  if (digits.length > 11) {
    return `+${digits}`;
  }

  // Fallback: assume it needs country code
  return `+${defaultCountryCode}${digits}`;
}

/**
 * Validates if a string is a valid E.164 phone number
 * @param phone - The phone number string
 * @returns true if valid
 */
export function isValidE164(phone: string): boolean {
  // E.164: + followed by 10-15 digits
  return /^\+\d{10,15}$/.test(phone);
}

/**
 * Normalizes Brazilian phone numbers by removing the 9th digit (mobile)
 * if present, to allow for fuzzy matching.
 * Returns both versions (with and without 9) for robust searching.
 *
 * @param phone - The input phone number (digits only or E.164)
 * @returns Array of possible phone number variations (digits only)
 */
export function getBrazilianPhoneVariations(phone: string): string[] {
  const digits = cleanPhone(phone);

  // Check if it's a Brazilian number (starts with 55)
  if (!digits.startsWith("55")) {
    return [digits];
  }

  // Remove country code
  const localPart = digits.substring(2);

  // If length is 11 (2 digit DDD + 9 digits), it likely has the 9
  // Example: 11 98888 7777
  if (localPart.length === 11) {
    const ddd = localPart.substring(0, 2);
    const number = localPart.substring(2);

    // Check if it starts with 9 (mobile)
    if (number.startsWith("9")) {
      const without9 = `55${ddd}${number.substring(1)}`;
      return [digits, without9];
    }
  }

  // If length is 10 (2 digit DDD + 8 digits), it might be missing the 9
  if (localPart.length === 10) {
    const ddd = localPart.substring(0, 2);
    const number = localPart.substring(2);

    // Construct version with 9
    // (Note: Landlines also have 10 digits but don't get a 9.
    //  Mobile numbers usually start with 7, 8, or 9 in the 8-digit format.
    //  Strictly speaking, we might add noise if we add 9 to a landline,
    //  but for lookup purposes it's usually safe as landlines don't have WhatsApp)
    const with9 = `55${ddd}9${number}`;
    return [digits, with9];
  }

  return [digits];
}
