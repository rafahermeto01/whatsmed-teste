import { v } from "convex/values";

export type PlanType = "free" | "starter" | "professional" | "enterprise";
export type PlanFeature =
  | "appointments"
  | "advancedAi"
  | "integrations"
  | "nps"
  | "checkin"
  | "telemedicine"
  | "apiAccess";

export interface PlanConfig {
  price: number;
  maxUsers: number;
  maxConversations: number;
  features: PlanFeature[];
}

export const PLAN_CONFIG: Record<PlanType, PlanConfig> = {
  free: {
    price: 0,
    maxUsers: 1,
    maxConversations: 10,
    features: [],
  },
  starter: {
    price: 497,
    maxUsers: 1,
    maxConversations: 100,
    features: [],
  },
  professional: {
    price: 697,
    maxUsers: 3,
    maxConversations: 1000,
    features: ["appointments", "advancedAi", "integrations", "nps", "checkin", "telemedicine"],
  },
  enterprise: {
    price: 997, // Custom pricing, but default value
    maxUsers: Infinity,
    maxConversations: Infinity,
    features: [
      "appointments",
      "advancedAi",
      "integrations",
      "nps",
      "checkin",
      "telemedicine",
      "apiAccess",
    ],
  },
};

export function getPlanConfig(plan: PlanType | undefined): PlanConfig {
  if (!plan) return PLAN_CONFIG.free;
  return PLAN_CONFIG[plan] || PLAN_CONFIG.free;
}

export function getPlanFeatures(plan: PlanType | undefined): PlanFeature[] {
  return getPlanConfig(plan).features;
}

export function hasPlanFeature(plan: PlanType | undefined, feature: PlanFeature): boolean {
  return getPlanFeatures(plan).includes(feature);
}
