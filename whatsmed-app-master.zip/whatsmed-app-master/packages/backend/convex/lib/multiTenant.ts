import { forbidden, notFound, unauthorized } from "./errors";

type AuthIdentity = {
  [key: string]: unknown;
};

function validateClinicIdFormat(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const value = raw.trim();
  if (!value) return null;
  // Accept UUID-like or slug-like identifiers
  const uuidLike = /^[a-zA-Z0-9-]{8,}$/;
  return uuidLike.test(value) ? value : null;
}

function extractClinicId(identity: AuthIdentity | null): string | null {
  if (!identity) return null;
  return (
    (identity as any).clinicId ??
    (identity as any).claims?.clinicId ??
    (identity as any).token?.clinicId ??
    (identity as any).metadata?.clinicId ??
    null
  );
}

type RequireClinicIdCtx = {
  auth: { getUserIdentity: () => Promise<AuthIdentity | null> };
  db?: any;
};

export async function requireClinicId(ctx: RequireClinicIdCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) {
    throw unauthorized("Authentication required");
  }
  let clinicId = validateClinicIdFormat(extractClinicId(identity));
  if (!clinicId && ctx.db && (identity as any).email) {
    try {
      const user = await ctx.db
        .query("users")
        .withIndex("by_email", (q: any) => q.eq("email", (identity as any).email))
        .first();
      if (user?.clinicId) {
        clinicId = validateClinicIdFormat(user.clinicId) ?? null;
      }
    } catch (error) {
      console.error("Error fetching user for clinicId:", error);
    }
  }
  if (!clinicId) {
    throw forbidden("Clinic context required");
  }
  return { clinicId, identity };
}

export function validateClinicAccess(
  resourceClinicId: string | null | undefined,
  clinicId: string,
  options: { notFoundOnMismatch?: boolean } = {},
) {
  if (!resourceClinicId || resourceClinicId !== clinicId) {
    if (options.notFoundOnMismatch) {
      throw notFound("Resource not found");
    }
    throw forbidden("Cross-clinic access forbidden");
  }
}
