import { getPlanConfig, hasPlanFeature, PlanFeature } from "./plans";
import { QueryCtx, MutationCtx } from "../_generated/server";

export async function checkUserLimit(
  ctx: QueryCtx | MutationCtx,
  clinicId: string,
): Promise<{ allowed: boolean; current: number; max: number }> {
  const clinic = await ctx.db
    .query("clinics")
    .withIndex("by_clinicId", (q) => q.eq("clinicId", clinicId))
    .unique();

  if (!clinic) {
    throw new Error("Clinic not found");
  }

  const planConfig = getPlanConfig(clinic.plan);
  const current = await ctx.db
    .query("clinicMembers")
    .withIndex("by_clinic", (q) => q.eq("clinicId", clinicId))
    .collect();

  const currentCount = current.length;
  const maxUsers = planConfig.maxUsers === Infinity ? 999999 : planConfig.maxUsers;

  return {
    allowed: currentCount < maxUsers,
    current: currentCount,
    max: maxUsers,
  };
}

export async function checkConversationCredit(
  ctx: QueryCtx | MutationCtx,
  clinicId: string,
): Promise<{ hasCredit: boolean; source: "plan" | "purchased" | "none" }> {
  const clinic = await ctx.db
    .query("clinics")
    .withIndex("by_clinicId", (q) => q.eq("clinicId", clinicId))
    .unique();

  if (!clinic) {
    return { hasCredit: false, source: "none" };
  }

  const planConfig = getPlanConfig(clinic.plan);
  const used = clinic.conversationCreditsUsed || 0;
  const purchased = clinic.conversationCreditsPurchased || 0;
  const planLimit = planConfig.maxConversations === Infinity ? 999999 : planConfig.maxConversations;

  // Check plan credits first
  if (used < planLimit) {
    return { hasCredit: true, source: "plan" };
  }

  // Check purchased credits
  if (purchased > 0) {
    return { hasCredit: true, source: "purchased" };
  }

  return { hasCredit: false, source: "none" };
}

export async function checkFeatureAccess(
  ctx: QueryCtx | MutationCtx,
  clinicId: string,
  feature: PlanFeature,
): Promise<{ allowed: boolean; requiredPlan: string }> {
  const clinic = await ctx.db
    .query("clinics")
    .withIndex("by_clinicId", (q) => q.eq("clinicId", clinicId))
    .unique();

  if (!clinic) {
    return { allowed: false, requiredPlan: "Professional" };
  }

  const allowed = hasPlanFeature(clinic.plan, feature);

  // Determine required plan based on feature
  let requiredPlan = "Professional";
  if (feature === "apiAccess") {
    requiredPlan = "Enterprise";
  }

  return { allowed, requiredPlan };
}
