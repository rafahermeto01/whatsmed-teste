import { throwIfRateLimited } from "./rateLimit";

/**
 * Comprehensive rate limiting configuration for all mutations
 * Limits are defined per operation with time windows in milliseconds
 */
export const RATE_LIMITS = {
  // User operations
  createUser: { limit: 3, window: 3600000 }, // 3/hour
  updateUser: { limit: 10, window: 60000 }, // 10/minute
  deleteUser: { limit: 3, window: 3600000 }, // 3/hour

  // Patient operations
  createPatient: { limit: 10, window: 60000 }, // 10/minute
  updatePatient: { limit: 20, window: 60000 }, // 20/minute
  deletePatient: { limit: 3, window: 3600000 }, // 3/hour

  // Appointment operations
  createAppointment: { limit: 5, window: 60000 }, // 5/minute
  updateAppointment: { limit: 10, window: 60000 }, // 10/minute
  deleteAppointment: { limit: 3, window: 3600000 }, // 3/hour
  checkInPatient: { limit: 20, window: 60000 }, // 20/minute

  // WhatsApp operations
  sendWhatsAppMessage: { limit: 10, window: 60000 }, // 10/minute
  processWebhook: { limit: 100, window: 60000 }, // 100/minute

  // Document operations
  uploadDocument: { limit: 5, window: 60000 }, // 5/minute
  deleteDocument: { limit: 3, window: 3600000 }, // 3/hour

  // Billing/Payment operations
  processPayment: { limit: 3, window: 60000 }, // 3/minute
  createSubscription: { limit: 3, window: 3600000 }, // 3/hour
  updateSubscription: { limit: 5, window: 60000 }, // 5/minute

  // NPS operations
  submitNPS: { limit: 1, window: 60000 }, // 1/minute per patient

  // Automation operations
  createAutomation: { limit: 5, window: 60000 }, // 5/minute
  updateAutomation: { limit: 10, window: 60000 }, // 10/minute
  deleteAutomation: { limit: 3, window: 3600000 }, // 3/hour

  // Clinic operations
  createClinic: { limit: 3, window: 3600000 }, // 3/hour
  updateClinic: { limit: 10, window: 60000 }, // 10/minute

  // Generic/query operations
  fetchAnalytics: { limit: 60, window: 60000 }, // 60/minute

  // Email operations
  sendEmail: { limit: 10, window: 60000 }, // 10/minute
  sendPasswordReset: { limit: 3, window: 3600000 }, // 3/hour

  // Check-in operations
  startCheckIn: { limit: 20, window: 60000 }, // 20/minute
  completeCheckIn: { limit: 20, window: 60000 }, // 20/minute
} as const;

export type RateLimitKey = keyof typeof RATE_LIMITS;

/**
 * Error messages for rate limits (in Portuguese)
 */
export const RATE_LIMIT_MESSAGES: Record<RateLimitKey, string> = {
  createUser: "Muitas tentativas de criação de usuário. Tente novamente em uma hora.",
  updateUser: "Muitas tentativas de atualização. Aguarde um momento.",
  deleteUser: "Muitas tentativas de exclusão de usuário. Tente novamente em uma hora.",
  createPatient: "Muitas tentativas de criação de paciente. Aguarde um momento.",
  updatePatient: "Muitas tentativas de atualização. Aguarde um momento.",
  deletePatient: "Muitas tentativas de exclusão de paciente. Tente novamente em uma hora.",
  createAppointment: "Muitas tentativas de agendamento. Aguarde um momento.",
  updateAppointment: "Muitas tentativas de atualização. Aguarde um momento.",
  deleteAppointment: "Muitas tentativas de exclusão de agendamento. Tente novamente em uma hora.",
  checkInPatient: "Muitas tentativas de check-in. Aguarde um momento.",
  sendWhatsAppMessage: "Muitas mensagens enviadas. Aguarde um momento.",
  processWebhook: "Muitas requisições de webhook. Aguarde um momento.",
  uploadDocument: "Muitos uploads de documento. Aguarde um momento.",
  deleteDocument: "Muitas tentativas de exclusão de documento. Tente novamente em uma hora.",
  processPayment: "Muitas tentativas de pagamento. Aguarde um momento.",
  createSubscription: "Muitas tentativas de criação de assinatura. Tente novamente em uma hora.",
  updateSubscription: "Muitas tentativas de atualização. Aguarde um momento.",
  submitNPS: "Muitas tentativas de avaliação. Aguarde um momento.",
  createAutomation: "Muitas tentativas de criação de automação. Aguarde um momento.",
  updateAutomation: "Muitas tentativas de atualização. Aguarde um momento.",
  deleteAutomation: "Muitas tentativas de exclusão de automação. Tente novamente em uma hora.",
  createClinic: "Muitas tentativas de criação de clínica. Tente novamente em uma hora.",
  updateClinic: "Muitas tentativas de atualização. Aguarde um momento.",
  fetchAnalytics: "Muitas requisições de analytics. Aguarde um momento.",
  sendEmail: "Muitos e-mails enviados. Aguarde um momento.",
  sendPasswordReset: "Muitas solicitações de redefinição de senha. Tente novamente em uma hora.",
  startCheckIn: "Muitas tentativas de check-in. Aguarde um momento.",
  completeCheckIn: "Muitas tentativas de check-in. Aguarde um momento.",
};

/**
 * Applies rate limiting to a mutation
 * @param ctx - Convex context
 * @param key - Rate limit key
 * @param userId - Optional user ID for user-based rate limiting
 * @param clinicId - Optional clinic ID for clinic-based rate limiting
 * @param ip - Optional IP address for IP-based rate limiting
 */
export async function applyRateLimit(
  ctx: any,
  key: RateLimitKey,
  options?: {
    userId?: string;
    clinicId?: string;
    ip?: string;
  },
) {
  const config = RATE_LIMITS[key];
  const message = RATE_LIMIT_MESSAGES[key];

  // Build rate limit key with multiple levels for better granularity
  const keyParts: string[] = [key];

  // Priority: user > clinic > IP > global
  if (options?.userId) {
    keyParts.push(`user:${options.userId}`);
  } else if (options?.clinicId) {
    keyParts.push(`clinic:${options.clinicId}`);
  } else if (options?.ip) {
    keyParts.push(`ip:${options.ip}`);
  } else {
    keyParts.push("global");
  }

  const rateLimitKey = keyParts.join(":");

  // Import checkRateLimit dynamically to avoid circular dependencies
  const { checkRateLimit } = await import("./rateLimit");

  const result = await checkRateLimit(
    ctx,
    rateLimitKey,
    config.limit,
    config.window,
    options?.clinicId,
  );

  throwIfRateLimited(result, message);

  return result;
}

/**
 * Helper to extract user ID from auth context
 */
export async function extractUserId(ctx: any): Promise<string | null> {
  try {
    // Try to get auth user
    const authComponent = await import("../auth");
    const authUser = await authComponent.authComponent.getAuthUser(ctx);
    return authUser?.email || null;
  } catch {
    return null;
  }
}

/**
 * Helper to extract clinic ID from auth context
 */
export async function extractClinicId(ctx: any): Promise<string | null> {
  try {
    const userId = await extractUserId(ctx);
    if (!userId) return null;

    // Look up user to get clinicId
    const user = await ctx.db
      .query("users")
      .withIndex("by_email", (q: any) => q.eq("email", userId))
      .first();

    return user?.clinicId || null;
  } catch {
    return null;
  }
}

/**
 * Helper to extract IP from request (for HTTP actions)
 */
export function extractIp(request: Request): string | null {
  // Check various headers for IP
  const forwarded = request.headers.get("x-forwarded-for");
  const realIp = request.headers.get("x-real-ip");
  const cfConnectingIp = request.headers.get("cf-connecting-ip");

  return forwarded?.split(",")[0]?.trim() || realIp || cfConnectingIp || null;
}
