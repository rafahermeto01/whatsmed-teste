import { ApiError, errorCodes, internalError } from "./errors";
import {
  buildRateLimitKey,
  checkRateLimit,
  rateLimitHeaders,
  throwIfRateLimited,
  type RateLimitResult,
} from "./rateLimit";

type HttpHandler = (ctx: any, request: Request) => Promise<Response>;

const getAllowedOrigins = () => {
  const siteUrl = process.env.SITE_URL;
  if (!siteUrl) return ["*"];
  return siteUrl
    .split(",")
    .map((origin) => origin.trim())
    .filter(Boolean);
};

function mergeHeaders(base: Headers, extras: Record<string, string>) {
  const result = new Headers(base);
  Object.entries(extras).forEach(([key, value]) => {
    result.set(key, value);
  });
  return result;
}

type CorsResolution = { allowed: boolean; headers: Record<string, string> };

function resolveCorsHeaders(request: Request): CorsResolution {
  const allowedOrigins = getAllowedOrigins();
  const origin = request.headers.get("origin");
  const allowAll = allowedOrigins.includes("*");
  const matchedOrigin = allowAll ? "*" : origin && allowedOrigins.includes(origin) ? origin : null;

  if (!matchedOrigin) {
    return { allowed: false, headers: {} };
  }

  return {
    allowed: true,
    headers: {
      "Access-Control-Allow-Origin": matchedOrigin,
      "Access-Control-Allow-Methods": "GET,POST,PUT,PATCH,DELETE,OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, Idempotency-Key",
      "Access-Control-Allow-Credentials": "true",
    },
  };
}

export function corsHeadersForRequest(request: Request) {
  return resolveCorsHeaders(request);
}

export function jsonResponse(data: unknown, status = 200, headers: Record<string, string> = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      ...headers,
    },
  });
}

export function errorResponse(error: unknown, requestId?: string) {
  if (!(error instanceof ApiError)) {
    // Minimal logging for observability; avoid leaking details in the response
    console.error("[http] unhandled error", { requestId, error });
    const fallback = internalError("Internal Server Error", requestId ? { requestId } : undefined);
    return jsonResponse(fallback.body, fallback.status);
  }
  return jsonResponse(error.body, error.status);
}

export function withCors(handler: HttpHandler): HttpHandler {
  return async (ctx, request) => {
    const { allowed, headers } = resolveCorsHeaders(request);

    if (request.method === "OPTIONS") {
      if (!allowed) {
        return new Response(null, { status: 403 });
      }
      return new Response(null, { status: 204, headers });
    }

    const response = await handler(ctx, request);
    const mergedHeaders = allowed ? mergeHeaders(response.headers, headers) : response.headers;
    return new Response(response.body, {
      status: response.status,
      headers: mergedHeaders,
    });
  };
}

type RateLimitOptions = {
  limit?: number;
  windowMs?: number;
  category?: string;
  buildKey?: (request: Request) => string;
};

function attachRateLimitHeaders(response: Response, result: RateLimitResult) {
  return new Response(response.body, {
    status: response.status,
    headers: mergeHeaders(response.headers, rateLimitHeaders(result)),
  });
}

export function withRateLimit(handler: HttpHandler, options: RateLimitOptions = {}): HttpHandler {
  const { limit = 100, windowMs, buildKey, category = "general" } = options;

  return async (ctx, request) => {
    const key = buildKey ? buildKey(request) : buildRateLimitKey(request, category);
    const result = await checkRateLimit(ctx, key, limit, windowMs);
    throwIfRateLimited(result);

    const response = await handler(ctx, request);
    return attachRateLimitHeaders(response, result);
  };
}

export function getBearerToken(request: Request) {
  const header = request.headers.get("authorization") ?? request.headers.get("Authorization");
  if (!header) return null;
  const [scheme, token] = header.split(" ");
  if (scheme?.toLowerCase() !== "bearer" || !token) return null;
  return token;
}

export function withAuth(handler: HttpHandler): HttpHandler {
  return async (ctx, request) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ApiError(401, errorCodes.UNAUTHORIZED, "Unauthorized");
    }
    return handler({ ...ctx, identity }, request);
  };
}
