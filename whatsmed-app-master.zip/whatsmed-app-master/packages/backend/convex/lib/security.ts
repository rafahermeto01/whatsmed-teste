export function generateSecureToken(length = 32): string {
  let token = "";

  while (token.length < length) {
    token += globalThis.crypto.randomUUID().replace(/-/g, "");
  }

  return token.slice(0, length);
}
