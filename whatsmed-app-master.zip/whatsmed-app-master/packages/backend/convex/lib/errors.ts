export type ErrorBody = {
  code: string;
  message: string;
  details?: unknown;
  requestId?: string;
};

type ErrorOptions = {
  details?: unknown;
  requestId?: string;
};

export class ApiError extends Error {
  status: number;
  body: ErrorBody;

  constructor(status: number, code: string, message: string, options: ErrorOptions = {}) {
    super(message);
    this.status = status;
    this.body = {
      code,
      message,
      ...(options.details !== undefined ? { details: options.details } : {}),
      ...(options.requestId ? { requestId: options.requestId } : {}),
    };
  }
}

export const errorCodes = {
  VALIDATION_ERROR: "VALIDATION_ERROR",
  NOT_FOUND: "NOT_FOUND",
  FORBIDDEN: "FORBIDDEN",
  UNAUTHORIZED: "UNAUTHORIZED",
  CONFLICT: "CONFLICT",
  RATE_LIMITED: "RATE_LIMITED",
  INTERNAL_ERROR: "INTERNAL_ERROR",
} as const;

export function badRequest(message = "Invalid request", options?: ErrorOptions) {
  return new ApiError(422, errorCodes.VALIDATION_ERROR, message, options);
}

export function notFound(message = "Not found", options?: ErrorOptions) {
  return new ApiError(404, errorCodes.NOT_FOUND, message, options);
}

export function forbidden(message = "Forbidden", options?: ErrorOptions) {
  return new ApiError(403, errorCodes.FORBIDDEN, message, options);
}

export function unauthorized(message = "Unauthorized", options?: ErrorOptions) {
  return new ApiError(401, errorCodes.UNAUTHORIZED, message, options);
}

export function conflict(message = "Conflict", options?: ErrorOptions) {
  return new ApiError(409, errorCodes.CONFLICT, message, options);
}

export function rateLimited(message = "Too Many Requests", options?: ErrorOptions) {
  return new ApiError(429, errorCodes.RATE_LIMITED, message, options);
}

export function internalError(message = "Internal Server Error", options?: ErrorOptions) {
  return new ApiError(500, errorCodes.INTERNAL_ERROR, message, options);
}
