import { authComponent } from "../auth";
import { unauthorized, notFound, forbidden } from "./errors";

import type { QueryContext, MutationContext, AuthResult, Role } from "./types";

/**
 * Gets the authenticated user from context
 * @param ctx - Query or Mutation context
 * @returns AuthResult with user, clinicId, and identity
 * @throws unauthorized if user is not authenticated
 * @throws notFound if user is not found in users table
 * @throws unauthorized if user is inactive or deleted
 */
export async function getAuthenticatedUser(
  ctx: QueryContext | MutationContext,
): Promise<AuthResult> {
  const identity = await ctx.auth.getUserIdentity();

  if (!identity || !identity.email) {
    throw unauthorized("Autenticação necessária");
  }

  const user = await (ctx.db as any)
    .query("users")
    .withIndex("by_email", (q: any) => q.eq("email", identity.email))
    .first();

  if (!user) {
    throw notFound("Usuário não encontrado");
  }

  if (!user.isActive) {
    throw unauthorized("Conta de usuário está inativa");
  }

  if (user.deletedAt) {
    throw unauthorized("Conta de usuário foi excluída");
  }

  return {
    user,
    clinicId: user.clinicId,
    identity,
  };
}

/**
 * Gets the authenticated user with role validation
 * @param ctx - Query or Mutation context
 * @param allowedRoles - Array of allowed roles
 * @returns AuthResult with user, clinicId, identity, and role
 * @throws unauthorized if user is not authenticated
 * @throws forbidden if user does not have required role
 */
export async function getAuthenticatedUserWithRole(
  ctx: QueryContext | MutationContext,
  allowedRoles: Role[],
): Promise<AuthResult & { role: Role }> {
  const auth = await getAuthenticatedUser(ctx);

  if (!allowedRoles.includes(auth.user.role as Role)) {
    throw forbidden(`Permissões insuficientes. Requerido: ${allowedRoles.join(" ou ")}`);
  }

  return { ...auth, role: auth.user.role as Role };
}

/**
 * Checks if current user has a specific role
 * @param ctx - Query or Mutation context
 * @param role - Role to check
 * @returns true if user has the role, false otherwise
 */
export async function hasRole(ctx: QueryContext | MutationContext, role: Role): Promise<boolean> {
  try {
    const auth = await getAuthenticatedUserWithRole(ctx, [role]);
    return auth.role === role;
  } catch {
    return false;
  }
}

/**
 * Checks if current user is super admin
 * @param ctx - Query or Mutation context
 * @returns true if user is super admin, false otherwise
 */
export async function isSuperAdmin(ctx: QueryContext | MutationContext): Promise<boolean> {
  return hasRole(ctx, "super_admin");
}

/**
 * Checks if current user is admin or super admin
 * @param ctx - Query or Mutation context
 * @returns true if user is admin, false otherwise
 */
export async function isAdmin(ctx: QueryContext | MutationContext): Promise<boolean> {
  try {
    const auth = await getAuthenticatedUserWithRole(ctx, ["admin", "super_admin"]);
    return true;
  } catch {
    return false;
  }
}

/**
 * Gets the current user's clinic ID
 * @param ctx - Query or Mutation context
 * @returns Clinic ID
 * @throws unauthorized if user is not authenticated
 */
export async function getClinicId(ctx: QueryContext | MutationContext): Promise<string> {
  const auth = await getAuthenticatedUser(ctx);
  return auth.clinicId;
}

/**
 * Gets the current user's email
 * @param ctx - Query or Mutation context
 * @returns User email or null if not authenticated
 */
export async function getUserEmail(ctx: QueryContext | MutationContext): Promise<string | null> {
  try {
    const identity = await ctx.auth.getUserIdentity();
    return identity?.email || null;
  } catch {
    return null;
  }
}

/**
 * Checks if user belongs to a specific clinic
 * @param ctx - Query or Mutation context
 * @param clinicId - Clinic ID to check
 * @returns true if user belongs to the clinic, false otherwise
 */
export async function belongsToClinic(
  ctx: QueryContext | MutationContext,
  clinicId: string,
): Promise<boolean> {
  try {
    const userClinicId = await getClinicId(ctx);
    return userClinicId === clinicId;
  } catch {
    return false;
  }
}
