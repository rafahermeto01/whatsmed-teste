import type { QueryContext, MutationContext } from "./types";

/**
 * Cache entry with timestamp
 */
interface CacheEntry<T> {
  result: T;
  timestamp: number;
}

/**
 * Cache configuration
 */
const CACHE_TTL_MS = 60_000; // 1 minute default
const MAX_CACHE_SIZE = 1000; // Maximum cache entries

/**
 * In-memory cache store
 */
const cacheStore = new Map<string, CacheEntry<unknown>>();

/**
 * Cache statistics
 */
const stats = {
  hits: 0,
  misses: 0,
  evictions: 0,
};

/**
 * Gets a value from cache
 * @param key - Cache key
 * @param ttl - Time to live in milliseconds (default: CACHE_TTL_MS)
 * @returns Cached value or null if not found or expired
 */
export function getCache<T>(key: string, ttl: number = CACHE_TTL_MS): T | null {
  const entry = cacheStore.get(key);

  if (!entry) {
    stats.misses++;
    return null;
  }

  // Check if cache entry has expired
  if (Date.now() - entry.timestamp > ttl) {
    cacheStore.delete(key);
    stats.evictions++;
    stats.misses++;
    return null;
  }

  stats.hits++;
  return entry.result as T;
}

/**
 * Sets a value in cache
 * @param key - Cache key
 * @param value - Value to cache
 * @returns The cached value
 */
export function setCache<T>(key: string, value: T): T {
  // Evict oldest entries if cache is full
  if (cacheStore.size >= MAX_CACHE_SIZE) {
    const oldestKey = cacheStore.keys().next().value;
    if (oldestKey) {
      cacheStore.delete(oldestKey);
      stats.evictions++;
    }
  }

  cacheStore.set(key, {
    result: value,
    timestamp: Date.now(),
  });

  return value;
}

/**
 * Clears a specific cache entry
 * @param key - Cache key to clear
 */
export function clearCache(key: string): void {
  cacheStore.delete(key);
}

/**
 * Clears cache entries matching a pattern
 * @param pattern - Pattern to match (supports simple wildcards *)
 */
export function clearCachePattern(pattern: string): void {
  const regex = new RegExp(pattern.replace(/\*/g, ".*"));

  for (const key of cacheStore.keys()) {
    if (regex.test(key)) {
      cacheStore.delete(key);
      stats.evictions++;
    }
  }
}

/**
 * Clears all cache entries
 */
export function clearAllCache(): void {
  const size = cacheStore.size;
  cacheStore.clear();
  stats.evictions += size;
}

/**
 * Gets cache statistics
 * @returns Cache statistics object
 */
export function getCacheStats() {
  return {
    ...stats,
    size: cacheStore.size,
    hitRate: stats.hits + stats.misses > 0 ? stats.hits / (stats.hits + stats.misses) : 0,
  };
}

/**
 * Resets cache statistics
 */
export function resetCacheStats(): void {
  stats.hits = 0;
  stats.misses = 0;
  stats.evictions = 0;
}

/**
 * Wraps a query function with caching
 * @param ctx - Query context
 * @param key - Cache key
 * @param fn - Query function to execute if cache miss
 * @param ttl - Time to live in milliseconds (default: CACHE_TTL_MS)
 * @returns Cached or computed result
 */
export async function withCache<T>(
  ctx: QueryContext | MutationContext,
  key: string,
  fn: () => Promise<T>,
  ttl: number = CACHE_TTL_MS,
): Promise<T> {
  // Try to get from cache
  const cached = getCache<T>(key, ttl);
  if (cached !== null) {
    return cached;
  }

  // Execute function and cache result
  const result = await fn();
  return setCache(key, result);
}

/**
 * Cache key builders for common use cases
 */
export const CacheKeys = {
  user: (email: string) => `user:${email}`,
  clinic: (clinicId: string) => `clinic:${clinicId}`,
  patient: (patientId: string) => `patient:${patientId}`,
  appointment: (appointmentId: string) => `appointment:${appointmentId}`,
  doctors: (clinicId: string) => `doctors:${clinicId}`,
  patients: (clinicId: string, filters?: string) =>
    `patients:${clinicId}${filters ? `:${filters}` : ""}`,
  appointments: (clinicId: string, filters?: string) =>
    `appointments:${clinicId}${filters ? `:${filters}` : ""}`,
  analytics: (clinicId: string, dateRange: string) => `analytics:${clinicId}:${dateRange}`,
  aiSettings: (clinicId: string) => `aiSettings:${clinicId}`,
  integration: (clinicId: string, type: string) => `integration:${clinicId}:${type}`,
};

/**
 * Invalidates cache entries for a specific entity
 * @param entityType - Type of entity (user, clinic, patient, etc.)
 * @param entityId - ID of the entity
 */
export function invalidateEntity(entityType: string, entityId: string): void {
  const pattern = `${entityType}:${entityId}`;
  clearCachePattern(pattern);
}

/**
 * Invalidates cache entries for a clinic
 * @param clinicId - Clinic ID
 */
export function invalidateClinic(clinicId: string): void {
  clearCachePattern(`${clinicId}:*`);
  clearCachePattern(`*:${clinicId}:*`);
}

/**
 * Executes a function and invalidates related cache entries
 * @param ctx - Mutation context
 * @param invalidations - Array of cache keys/patterns to invalidate
 * @param fn - Function to execute
 * @returns Result of the function
 */
export async function withInvalidation<T>(
  ctx: MutationContext,
  invalidations: string[],
  fn: () => Promise<T>,
): Promise<T> {
  try {
    return await fn();
  } finally {
    for (const key of invalidations) {
      if (key.includes("*")) {
        clearCachePattern(key);
      } else {
        clearCache(key);
      }
    }
  }
}
