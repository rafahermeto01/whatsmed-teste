import { v } from "convex/values";

/**
 * Validates Brazilian CPF (Cadastro de Pessoas Físicas) using Luhn algorithm
 * @param cpf - CPF string (can include formatting or not)
 * @returns true if valid CPF, false otherwise
 */
export function isValidCPF(cpf: string): boolean {
  // Remove non-digits
  cpf = cpf.replace(/\D/g, "");

  // Check length
  if (cpf.length !== 11) return false;

  // Check for repeated digits (e.g., 111.111.111-11)
  if (/^(\d)\1{10}$/.test(cpf)) return false;

  // Validate first check digit
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += parseInt(cpf.charAt(i)) * (10 - i);
  }
  let remainder = (sum * 10) % 11;
  if (remainder === 10) remainder = 0;
  if (remainder !== parseInt(cpf.charAt(9))) return false;

  // Validate second check digit
  sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += parseInt(cpf.charAt(i)) * (11 - i);
  }
  remainder = (sum * 10) % 11;
  if (remainder === 10) remainder = 0;

  return remainder === parseInt(cpf.charAt(10));
}

/**
 * Formats CPF with standard Brazilian formatting
 * @param cpf - CPF string (digits only)
 * @returns Formatted CPF (e.g., 123.456.789-01)
 */
export function formatCPF(cpf: string): string {
  const digits = cpf.replace(/\D/g, "");
  if (digits.length !== 11) return cpf;
  return digits.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
}

export function normalizeCpfCnpj(value: string): string {
  return value.replace(/\D/g, "");
}

export function isValidCpfCnpj(value: string): boolean {
  const digits = normalizeCpfCnpj(value);

  if (digits.length === 11) return isValidCPF(digits);
  if (digits.length === 14) return isValidCNPJ(digits);

  return false;
}

/**
 * Validates Brazilian phone number
 * @param phone - Phone string (can include formatting or not)
 * @returns true if valid Brazilian phone number, false otherwise
 */
export function isValidBrazilianPhone(phone: string): boolean {
  const digits = phone.replace(/\D/g, "");

  // Brazil phone numbers are 10 or 11 digits (including DDD)
  // 10 digits: XX NNNN-NNNN (landline)
  // 11 digits: XX NNNNN-NNNN (mobile)
  if (digits.length !== 10 && digits.length !== 11) return false;

  // Check DDD (area code) - valid Brazilian DDDs are 11-99
  const ddd = parseInt(digits.substring(0, 2));
  if (ddd < 11 || ddd > 99) return false;

  return true;
}

/**
 * Formats Brazilian phone number
 * @param phone - Phone string (digits only)
 * @returns Formatted phone number
 */
export function formatBrazilianPhone(phone: string): string {
  const digits = phone.replace(/\D/g, "");

  if (digits.length === 10) {
    // Landline: XX NNNN-NNNN
    return digits.replace(/(\d{2})(\d{4})(\d{4})/, "($1) $2-$3");
  } else if (digits.length === 11) {
    // Mobile: XX NNNNN-NNNN
    return digits.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3");
  }

  return phone;
}

/**
 * Validates email address according to RFC 5322
 * @param email - Email address to validate
 * @returns true if valid email, false otherwise
 */
export function isValidEmail(email: string): boolean {
  const emailRegex =
    /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

  if (!emailRegex.test(email)) return false;

  // Additional checks
  const parts = email.split("@");
  if (parts.length !== 2) return false;
  const [localPart, domain] = parts;

  // Local part should not be empty or too long
  if (localPart.length === 0 || localPart.length > 64) return false;

  // Domain should not be empty or too long
  if (domain.length === 0 || domain.length > 253) return false;

  // Domain should have at least one dot
  if (!domain.includes(".")) return false;

  return true;
}

/**
 * Sanitizes string input to prevent XSS and injection attacks
 * @param input - String to sanitize
 * @param maxLength - Maximum allowed length (default: 1000)
 * @returns Sanitized string
 */
export function sanitizeString(input: string, maxLength: number = 1000): string {
  let sanitized = input.trim();

  // Truncate to max length
  sanitized = sanitized.substring(0, maxLength);

  // Remove control characters (except newline, tab, carriage return)
  sanitized = sanitized.replace(
    // eslint-disable-next-line no-control-regex
    /[\u{0000}-\u{0008}\u{000B}-\u{000C}\u{000E}-\u{001F}\u{200B}-\u{200D}\u{FEFF}]/gu,
    "",
  );

  // Remove bidirectional override characters
  sanitized = sanitized.replace(/[\u202A-\u202E\u2066-\u2069]/g, "");

  return sanitized;
}

/**
 * Sanitizes HTML content to prevent XSS attacks
 * @param html - HTML string to sanitize
 * @returns Sanitized HTML with dangerous tags/attributes removed
 */
export function sanitizeHTML(html: string): string {
  let sanitized = html;

  // Remove script tags and content
  sanitized = sanitized.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "");

  // Remove dangerous event handlers (onclick, onerror, etc.)
  sanitized = sanitized.replace(/\s*on\w+\s*=\s*["'][^"']*["']/gi, "");

  // Remove javascript: protocol in href
  sanitized = sanitized.replace(/href\s*=\s*["']\s*javascript:[^"']*["']/gi, 'href="#"');

  // Remove iframe tags
  sanitized = sanitized.replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, "");

  return sanitized;
}

/**
 * Validates date range (start before end)
 * @param startAt - Start timestamp in milliseconds
 * @param endAt - End timestamp in milliseconds
 * @returns true if valid date range, false otherwise
 */
export function isValidDateRange(startAt: number, endAt: number): boolean {
  return startAt < endAt;
}

/**
 * Checks if date is in the future
 * @param timestamp - Date timestamp in milliseconds
 * @returns true if date is in the future, false otherwise
 */
export function isFutureDate(timestamp: number): boolean {
  return timestamp > Date.now();
}

/**
 * Checks if date is in the past
 * @param timestamp - Date timestamp in milliseconds
 * @returns true if date is in the past, false otherwise
 */
export function isPastDate(timestamp: number): boolean {
  return timestamp < Date.now();
}

/**
 * Validates appointment time slot duration
 * @param startAt - Start timestamp in milliseconds
 * @param endAt - End timestamp in milliseconds
 * @param minMinutes - Minimum duration in minutes (default: 15)
 * @param maxMinutes - Maximum duration in minutes (default: 480 = 8 hours)
 * @returns true if valid duration, false otherwise
 */
export function isValidAppointmentDuration(
  startAt: number,
  endAt: number,
  minMinutes: number = 15,
  maxMinutes: number = 480,
): boolean {
  const durationMs = endAt - startAt;
  const durationMinutes = durationMs / (1000 * 60);

  return durationMinutes >= minMinutes && durationMinutes <= maxMinutes;
}

/**
 * Checks if two time ranges overlap
 * @param start1 - First range start
 * @param end1 - First range end
 * @param start2 - Second range start
 * @param end2 - Second range end
 * @returns true if ranges overlap, false otherwise
 */
export function doRangesOverlap(
  start1: number,
  end1: number,
  start2: number,
  end2: number,
): boolean {
  return start1 < end2 && start2 < end1;
}

/**
 * Validates Brazilian CNPJ (Cadastro Nacional da Pessoa Jurídica)
 * @param cnpj - CNPJ string (can include formatting or not)
 * @returns true if valid CNPJ, false otherwise
 */
export function isValidCNPJ(cnpj: string): boolean {
  // Remove non-digits
  cnpj = cnpj.replace(/\D/g, "");

  // Check length
  if (cnpj.length !== 14) return false;

  // Check for repeated digits
  if (/^(\d)\1{13}$/.test(cnpj)) return false;

  // Validate first check digit
  let sum = 0;
  let weight = 5;
  for (let i = 0; i < 12; i++) {
    sum += parseInt(cnpj.charAt(i)) * weight;
    weight = weight === 2 ? 9 : weight - 1;
  }
  let remainder = sum % 11;
  const digit1 = remainder < 2 ? 0 : 11 - remainder;
  if (digit1 !== parseInt(cnpj.charAt(12))) return false;

  // Validate second check digit
  sum = 0;
  weight = 6;
  for (let i = 0; i < 13; i++) {
    sum += parseInt(cnpj.charAt(i)) * weight;
    weight = weight === 2 ? 9 : weight - 1;
  }
  remainder = sum % 11;
  const digit2 = remainder < 2 ? 0 : 11 - remainder;

  return digit2 === parseInt(cnpj.charAt(13));
}

/**
 * Formats CNPJ with standard Brazilian formatting
 * @param cnpj - CNPJ string (digits only)
 * @returns Formatted CNPJ (e.g., 12.345.678/0001-90)
 */
export function formatCNPJ(cnpj: string): string {
  const digits = cnpj.replace(/\D/g, "");
  if (digits.length !== 14) return cnpj;
  return digits.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1.$2.$3/$4-$5");
}

/**
 * Validates Brazilian CEP (Código de Endereçamento Postal - postal code)
 * @param cep - CEP string (can include formatting or not)
 * @returns true if valid CEP, false otherwise
 */
export function isValidCEP(cep: string): boolean {
  const digits = cep.replace(/\D/g, "");
  return digits.length === 8;
}

/**
 * Formats CEP with standard Brazilian formatting
 * @param cep - CEP string (digits only)
 * @returns Formatted CEP (e.g., 12345-678)
 */
export function formatCEP(cep: string): string {
  const digits = cep.replace(/\D/g, "");
  if (digits.length !== 8) return cep;
  return digits.replace(/(\d{5})(\d{3})/, "$1-$2");
}

// Convex validators for API validation
export const validators = {
  cpf: v.string(),
  cnpj: v.string(),
  cep: v.string(),
  phone: v.string(),
  email: v.string(),
  name: v.string(),
  address: v.optional(v.string()),
  city: v.optional(v.string()),
  state: v.optional(v.string()),
  zip: v.optional(v.string()),
};

/**
 * Validates all required fields are present
 * @param data - Object with fields to validate
 * @param requiredFields - Array of required field names
 * @returns Object with isValid flag and missing fields array
 */
export function validateRequiredFields(
  data: Record<string, any>,
  requiredFields: string[],
): { isValid: boolean; missingFields: string[] } {
  const missingFields = requiredFields.filter((field) => !data[field]);
  return {
    isValid: missingFields.length === 0,
    missingFields,
  };
}

/**
 * Creates a validation error message
 * @param field - Field name that failed validation
 * @param reason - Reason for validation failure
 * @returns Formatted error message in Portuguese
 */
export function createValidationError(field: string, reason: string): string {
  const fieldNames: Record<string, string> = {
    cpf: "CPF",
    cnpj: "CNPJ",
    cep: "CEP",
    phone: "telefone",
    email: "e-mail",
    name: "nome",
    dateOfBirth: "data de nascimento",
  };

  const fieldName = fieldNames[field] || field;
  return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} inválido: ${reason}`;
}

const SPECIALTY_ALIASES: Record<string, string> = {
  cardiologista: "cardiologia",
  cardiologico: "cardiologia",
  cardiologa: "cardiologia",
  pediatra: "pediatria",
  pediatrico: "pediatria",
  pediatrica: "pediatria",
  dermatologista: "dermatologia",
  dermatologico: "dermatologia",
  dermatologica: "dermatologia",
  neurologista: "neurologia",
  neurologico: "neurologia",
  neurologica: "neurologia",
  ortopedista: "ortopedia",
  ortopedico: "ortopedia",
  ortopedica: "ortopedia",
  urologista: "urologia",
  urologico: "urologia",
  urologica: "urologia",
  ginecologista: "ginecologia",
  ginecologico: "ginecologia",
  ginecologica: "ginecologia",
  obstetra: "obstetricia",
  obstetrico: "obstetricia",
  obstetrica: "obstetricia",
  endocrinologista: "endocrinologia",
  endocrinologico: "endocrinologia",
  endocrinologica: "endocrinologia",
  gastroenterologista: "gastroenterologia",
  gastroenterologico: "gastroenterologia",
  gastroenterologica: "gastroenterologia",
  pneumologista: "pneumologia",
  pneumologico: "pneumologia",
  pneumologica: "pneumologia",
  psiquiatra: "psiquiatria",
  psiquiatrico: "psiquiatria",
  psiquiatrica: "psiquiatria",
  oftalmologista: "oftalmologia",
  oftalmologico: "oftalmologia",
  oftalmologica: "oftalmologia",
  otorrinolaringologista: "otorrinolaringologia",
  otorrinolaringologico: "otorrinolaringologia",
  otorrinolaringologica: "otorrinolaringologia",
  reumatologista: "reumatologia",
  reumatologico: "reumatologia",
  reumatologica: "reumatologia",
  oncologista: "oncologia",
  oncologico: "oncologia",
  oncologica: "oncologia",
  nefrologista: "nefrologia",
  nefrologico: "nefrologia",
  nefrologica: "nefrologia",
  hematologista: "hematologia",
  hematologico: "hematologia",
  hematologica: "hematologia",
  alergologista: "alergologia",
  alergologico: "alergologia",
  alergologica: "alergologia",
  infectologista: "infectologia",
  infectologico: "infectologia",
  infectologica: "infectologia",
  geriatra: "geriatria",
  geriatrico: "geriatria",
  geriatrica: "geriatria",
  angiologista: "angiologia",
  angiologico: "angiologia",
  angiologica: "angiologia",
  cirurgiao: "cirurgia",
  cirurgica: "cirurgia",
  cirurgico: "cirurgia",
  clinico: "clinica",
  clinica_geral: "clinica geral",
  clinico_geral: "clinica geral",
  medicina_do_trabalho: "medicina do trabalho",
  medicino: "medicina",
};

function normalizeSpecialty(specialty: string): string {
  return specialty
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .replace(/[^a-z0-9\s]/g, "");
}

export function normalizeSpecialtyForMatch(specialty: string): string {
  const normalized = normalizeSpecialty(specialty);
  return SPECIALTY_ALIASES[normalized] || normalized;
}

function levenshtein(a: string, b: string): number {
  const matrix: number[][] = [];
  for (let i = 0; i <= b.length; i++) matrix[i] = [i];
  for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          Math.min(matrix[i][j - 1] + 1, matrix[i - 1][j] + 1),
        );
      }
    }
  }
  return matrix[b.length][a.length];
}

const FUZZY_THRESHOLD = 2;
const FUZZY_THRESHOLD_LOOSE = 4;
const RELATIVE_DISTANCE_THRESHOLD = 0.3;

export function matchesSpecialty(doctorSpecialty: string, searchSpecialty: string): boolean {
  const normalizedDoctor = normalizeSpecialtyForMatch(doctorSpecialty);
  const normalizedSearch = normalizeSpecialtyForMatch(searchSpecialty);

  if (normalizedDoctor === normalizedSearch) {
    return true;
  }

  const distance = levenshtein(normalizedDoctor, normalizedSearch);
  const maxLen = Math.max(normalizedDoctor.length, normalizedSearch.length);
  const relativeDistance = distance / maxLen;

  return distance <= FUZZY_THRESHOLD || relativeDistance <= 0.2;
}

export type SpecialtyMatchResult = {
  score: number;
  reason: "exact" | "alias" | "contains" | "fuzzy" | "partial" | "none";
};

export function calculateSpecialtyScore(
  doctorSpecialty: string,
  searchSpecialty: string,
): SpecialtyMatchResult {
  const normalizedDoctor = normalizeSpecialty(doctorSpecialty);
  const normalizedSearch = normalizeSpecialty(searchSpecialty);
  const aliasedDoctor = SPECIALTY_ALIASES[normalizedDoctor] || normalizedDoctor;
  const aliasedSearch = SPECIALTY_ALIASES[normalizedSearch] || normalizedSearch;

  if (aliasedDoctor === aliasedSearch) {
    if (normalizedDoctor !== normalizedSearch) {
      return { score: 0.95, reason: "alias" };
    }
    return { score: 1.0, reason: "exact" };
  }

  if (normalizedDoctor === normalizedSearch) {
    return { score: 1.0, reason: "exact" };
  }

  if (aliasedDoctor.includes(aliasedSearch) || aliasedSearch.includes(aliasedDoctor)) {
    const lenDiff = Math.abs(aliasedDoctor.length - aliasedSearch.length);
    const maxLen = Math.max(aliasedDoctor.length, aliasedSearch.length);
    const containScore = Math.max(0.7, 1 - (lenDiff / maxLen) * 0.5);
    return { score: containScore, reason: "contains" };
  }

  if (normalizedDoctor.includes(normalizedSearch) || normalizedSearch.includes(normalizedDoctor)) {
    const lenDiff = Math.abs(normalizedDoctor.length - normalizedSearch.length);
    const maxLen = Math.max(normalizedDoctor.length, normalizedSearch.length);
    const containScore = Math.max(0.65, 1 - (lenDiff / maxLen) * 0.5);
    return { score: containScore, reason: "contains" };
  }

  const distance = levenshtein(aliasedDoctor, aliasedSearch);
  const maxLen = Math.max(aliasedDoctor.length, aliasedSearch.length);
  const relativeDistance = distance / maxLen;

  if (distance <= FUZZY_THRESHOLD_LOOSE || relativeDistance <= RELATIVE_DISTANCE_THRESHOLD) {
    const fuzzyScore = Math.max(0.5, 1 - relativeDistance);
    return { score: fuzzyScore, reason: "fuzzy" };
  }

  const distanceRaw = levenshtein(normalizedDoctor, normalizedSearch);
  const maxLenRaw = Math.max(normalizedDoctor.length, normalizedSearch.length);
  const relativeDistanceRaw = distanceRaw / maxLenRaw;

  if (distanceRaw <= FUZZY_THRESHOLD_LOOSE || relativeDistanceRaw <= RELATIVE_DISTANCE_THRESHOLD) {
    const fuzzyScore = Math.max(0.4, 1 - relativeDistanceRaw);
    return { score: fuzzyScore, reason: "partial" };
  }

  return { score: 0, reason: "none" };
}

export function findBestSpecialtyMatch(
  doctorSpecialties: string[] | undefined,
  searchSpecialty: string,
): SpecialtyMatchResult {
  if (!doctorSpecialties || doctorSpecialties.length === 0) {
    return { score: 0, reason: "none" };
  }

  let bestResult: SpecialtyMatchResult = { score: 0, reason: "none" };

  for (const specialty of doctorSpecialties) {
    const result = calculateSpecialtyScore(specialty, searchSpecialty);
    if (result.score > bestResult.score) {
      bestResult = result;
    }
  }

  return bestResult;
}

export function isGenericSpecialty(specialty: string): boolean {
  const normalized = normalizeSpecialty(specialty);
  const genericTerms = [
    "qualquer",
    "qualquer um",
    "qualquer uma",
    "sem preferencia",
    "sem preferencias",
    "tanto faz",
    "indiferente",
    "nao importa",
    "nao tenho preferencia",
    "nao tenho preferencias",
    "nao faço ideia",
    "qualquer especialidade",
    "qualquer medico",
    "qualquer doutor",
    "o primeiro disponivel",
    "primeiro disponivel",
    "o que tiver vaga",
    "o que tiver disponibilidade",
  ];
  return genericTerms.includes(normalized);
}
