import { v } from "convex/values";

import { api, internal } from "./_generated/api";
import {
  query,
  mutation,
  internalMutation,
  action,
  internalAction,
  internalQuery,
} from "./_generated/server";
import { EvolutionClient } from "./lib/evolution";

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const EXPIRY_HOURS = 48;
const EXPIRY_MS = EXPIRY_HOURS * 60 * 60 * 1000;
const ALLOWED_MIME_TYPES = new Set(["application/pdf", "image/jpeg", "image/png"]);

const evolution = new EvolutionClient();

export const generateUploadUrl = mutation({
  args: {
    // We can pass validation args here if we want to validate before generating URL,
    // but usually we just generate it.
  },
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

export const saveDocument = mutation({
  args: {
    clinicId: v.string(),
    filename: v.string(),
    storageId: v.id("_storage"),
    size: v.number(),
    mimeType: v.string(),
  },
  handler: async (ctx, args) => {
    const { clinicId, filename, storageId, size, mimeType } = args;

    // Validate file size (check against metadata or trusted client arg)
    // We trust client arg for now, but we could check ctx.storage.getMetadata(storageId)
    // if we wanted to be strictly secure.
    if (size > MAX_FILE_SIZE) {
      throw new Error(`Arquivo muito grande. Máximo: 10MB`);
    }

    // Validate MIME type
    if (!ALLOWED_MIME_TYPES.has(mimeType)) {
      throw new Error(`Formato inválido. Use PDF, JPG ou PNG`);
    }

    // Calculate expiration
    const now = Date.now();
    const expiresAt = now + EXPIRY_MS;

    // Get storage URL
    const url = (await ctx.storage.getUrl(storageId)) ?? "";

    // Create record in uploads table
    const documentId = await ctx.db.insert("uploads", {
      clinicId,
      url,
      filename,
      size,
      mimeType,
      storageId,
      expiresAt,
      downloads: 0,
      createdAt: now,
      updatedAt: now,
    });

    // Fetch and return the created document
    const document = await ctx.db.get(documentId);
    return document;
  },
});

export const deleteDocument = mutation({
  args: {
    documentId: v.id("uploads"),
  },
  handler: async (ctx, args) => {
    const { documentId } = args;

    // Fetch document to verify it exists
    const document = await ctx.db.get(documentId);
    if (!document) {
      throw new Error("Documento não encontrado");
    }

    // Delete from database
    await ctx.db.delete(documentId);

    // Note: Storage file will be cleaned up by cron job
    return { success: true };
  },
});

export const incrementDocumentDownloads = internalMutation({
  args: {
    documentId: v.id("uploads"),
  },
  handler: async (ctx, args) => {
    const { documentId } = args;

    const document = await ctx.db.get(documentId);
    if (!document) {
      throw new Error("Documento não encontrado");
    }

    // Increment downloads counter
    await ctx.db.patch(documentId, {
      downloads: document.downloads + 1,
      updatedAt: Date.now(),
    });

    return document.downloads + 1;
  },
});

export const listDocuments = query({
  args: {
    clinicId: v.string(),
    paginationOpts: v.optional(
      v.object({
        numItems: v.number(),
        cursor: v.union(v.null(), v.string()),
      }),
    ),
  },
  handler: async (ctx, args) => {
    const { clinicId, paginationOpts } = args;

    if (paginationOpts) {
      // Paginated query
      const results = await ctx.db
        .query("uploads")
        .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", clinicId))
        .paginate(paginationOpts);

      return results;
    } else {
      // Non-paginated query (default to first 20)
      const results = await ctx.db
        .query("uploads")
        .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", clinicId))
        .order("desc")
        .take(20);

      return results;
    }
  },
});

export const getDocument = query({
  args: {
    documentId: v.id("uploads"),
  },
  handler: async (ctx, args) => {
    const { documentId } = args;

    const document = await ctx.db.get(documentId);

    if (!document) {
      return null;
    }

    // Check if expired
    if (document.expiresAt < Date.now()) {
      return null;
    }

    return document;
  },
});

export const getSecureDocumentUrl = mutation({
  args: {
    documentId: v.id("uploads"),
  },
  handler: async (ctx, args) => {
    const { documentId } = args;

    const document = await ctx.db.get(documentId);

    if (!document) {
      return { url: null, error: "Documento não encontrado" };
    }

    // Check if expired
    if (document.expiresAt < Date.now()) {
      return { url: null, error: "Documento expirado" };
    }

    // Increment download counter
    await ctx.db.patch(documentId, {
      downloads: document.downloads + 1,
      updatedAt: Date.now(),
    });

    return { url: document.url, expiresAt: document.expiresAt };
  },
});

export const sendDocumentViaWhatsApp = action({
  args: {
    documentId: v.id("uploads"),
    patientId: v.id("patients"),
    customMessage: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<{ success: boolean; message: string }> => {
    const { documentId, patientId, customMessage } = args;

    // Fetch document
    const document = await ctx.runQuery(api.documents.getDocument, {
      documentId,
    });

    if (!document) {
      throw new Error("Documento não encontrado ou expirado");
    }

    // Fetch patient
    const patient = await ctx.runQuery(api.patients.getById, {
      id: patientId,
      clinicId: document.clinicId,
    });

    if (!patient) {
      throw new Error("Paciente não encontrado");
    }

    if (!patient.phone) {
      throw new Error("Paciente não possui telefone cadastrado");
    }

    // Get document URL
    const urlResult: any = await ctx.runMutation(api.documents.getSecureDocumentUrl, {
      documentId,
    });

    if (!urlResult.url) {
      throw new Error(urlResult.error || "Erro ao obter link do documento");
    }

    // Format expiry date
    const expiryDate = new Date(document.expiresAt).toLocaleString("pt-BR");

    // Build message
    const message =
      customMessage ||
      `Olá ${patient.name}, seu documento "${document.filename}" está disponível.\n` +
        `Acesso válido até ${expiryDate}: ${urlResult.url}\n` +
        `Este link expira em 48 horas por segurança.`;

    // Get WhatsApp instance for the clinic
    const instance = await ctx.runQuery(internal.integrations.getWhatsAppInstanceInternal, {
      clinicId: document.clinicId,
    });

    if (!instance || !instance.instanceName) {
      throw new Error("Nenhuma instância WhatsApp configurada para esta clínica");
    }

    // Send WhatsApp message directly using EvolutionClient
    await evolution.sendText(instance.instanceName, patient.phone, message);

    return { success: true, message };
  },
});

export const cleanupExpiredDocuments = internalAction({
  args: {},
  handler: async (ctx): Promise<{ cleanedCount: number; expiredDocs: number }> => {
    const now = Date.now();

    // Query for all expired documents
    // Since we need to scan all clinics, we'll use a different approach
    // We'll get all documents and filter (not ideal for production, but works for MVP)
    const allDocs: any[] = await ctx.runQuery(internal.documents.listAllDocuments, {});

    const expiredDocs = allDocs.filter((doc: any) => doc.expiresAt < now);

    let cleanedCount = 0;

    for (const doc of expiredDocs) {
      try {
        // Delete from database
        await ctx.runMutation(internal.documents.deleteDocumentInternal, {
          documentId: doc._id,
        });
        cleanedCount++;
      } catch (error) {
        console.error(`Failed to delete document ${doc._id}:`, error);
      }
    }

    return { cleanedCount, expiredDocs: expiredDocs.length };
  },
});

export const listAllDocuments = internalQuery({
  args: {},
  handler: async (ctx) => {
    const results = await ctx.db.query("uploads").order("desc").collect();

    return results;
  },
});

export const deleteDocumentInternal = internalMutation({
  args: {
    documentId: v.id("uploads"),
  },
  handler: async (ctx, args) => {
    await ctx.db.delete(args.documentId);
  },
});
