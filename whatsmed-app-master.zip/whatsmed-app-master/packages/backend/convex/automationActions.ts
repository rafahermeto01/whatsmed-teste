"use node";

import { v } from "convex/values";

import * as mastraModule from "../mastra";
import { internal, api } from "./_generated/api";
import { internalAction } from "./_generated/server";
import { cleanPhone } from "./lib/phoneUtils";

const internalAny = internal as any;
const apiAny = api as any;

// Helper to initialize Convex internal in Mastra module
function initMastraConvex() {
  (global as any).ConvexInternal = {
    whatsapp: internalAny.whatsappQueries,
    patients: internalAny.patients,
    appointments: {
      ...apiAny.appointments,
      ...internalAny.appointments,
    },
    appointmentsInternal: internalAny.appointmentsInternal,
    clinics: internalAny.clinics,
    auditLogs: internalAny.auditLogs,
    automation: internalAny.automationInternal,
  };
}

async function ensurePatientChat(
  ctx: any,
  {
    clinicId,
    patientId,
    patientName,
    phone,
  }: {
    clinicId: string;
    patientId: any;
    patientName?: string;
    phone?: string | null;
  },
) {
  if (!phone) {
    return null;
  }

  const existingChat = await ctx.runQuery(internalAny.whatsappQueries.findChatByPhone, {
    clinicId,
    phone,
  });

  if (existingChat) {
    return existingChat._id;
  }

  const normalizedPhone = cleanPhone(phone);
  if (!normalizedPhone) {
    return null;
  }

  const whatsappPhone = normalizedPhone.startsWith("55") ? normalizedPhone : `55${normalizedPhone}`;

  return await ctx.runMutation(internalAny.whatsappQueries.createChatInternal, {
    clinicId,
    patientId,
    whatsappChatId: `${whatsappPhone}@s.whatsapp.net`,
    title: patientName,
  });
}

function isAffirmativeReply(text: string) {
  const normalized = (text || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();
  return /^(sim|confirmo|confirmar|confirma|ok|okay|isso|pode|quero sim)$/.test(normalized);
}

function isNegativeReply(text: string) {
  const normalized = (text || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();
  return /^(nao|n|nao posso|cancelar|cancela|desmarcar|desmarca)$/.test(normalized);
}

function parseRescheduleOption(text: string) {
  const normalized = (text || "").trim();
  const match = normalized.match(/^([1-3])\b/);
  return match ? Number(match[1]) - 1 : null;
}

async function buildAppointmentMessageContext(ctx: any, clinicId: string, appointmentId: any) {
  console.warn("[buildAppointmentMessageContext] Building context for appointment:", {
    appointmentId,
    clinicId,
    timestamp: new Date().toISOString(),
  });

  const clinic = await ctx.runQuery(internalAny.nps.getClinicInternal, { clinicId });
  const appointment = await ctx.runQuery(internalAny.appointments.getByIdInternal, {
    id: appointmentId,
    clinicId,
  });

  if (!appointment) {
    console.error("[buildAppointmentMessageContext] Appointment not found:", appointmentId);
    return null;
  }

  console.warn("[buildAppointmentMessageContext] Appointment data:", {
    appointmentId,
    startAt: appointment.startAt,
    startAtISO: new Date(appointment.startAt).toISOString(),
    isTelemedicine: appointment.isTelemedicine,
    doctor: appointment.doctor,
    procedure: appointment.procedure,
    timeZone: appointment.timeZone || "America/Sao_Paulo",
  });

  const patient = await ctx.runQuery(internalAny.patients.getByIdInternal, {
    id: appointment.patientId,
  });

  if (!patient) {
    console.error("[buildAppointmentMessageContext] Patient not found:", appointment.patientId);
    return null;
  }

  const apptObj = new Date(appointment.startAt);
  const appointmentDate = apptObj.toLocaleDateString("pt-BR", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    timeZone: appointment.timeZone || "America/Sao_Paulo",
  });
  const appointmentTime = apptObj.toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: appointment.timeZone || "America/Sao_Paulo",
  });

  console.warn("[buildAppointmentMessageContext] Formatted datetime:", {
    appointmentId,
    appointmentDate,
    appointmentTime,
    originalTimestamp: appointment.startAt,
  });

  const now = new Date();
  const appointmentType = appointment.isTelemedicine ? "Teleconsulta" : "Consulta presencial";

  return {
    clinic,
    appointment,
    patient,
    context: {
      patientName: patient.name,
      appointmentDate,
      appointmentTime,
      clinicName: clinic?.name || clinicId,
      doctorName: appointment.doctor,
      procedureName: appointment.procedure || "consulta",
      patient: {
        name: patient.name,
        phone: patient.phone,
        email: patient.email,
        cpf: patient.cpf,
      },
      clinic: {
        name: clinic?.name || clinicId,
        phone: clinic?.phone,
        address: clinic?.address,
        website: clinic?.website,
      },
      appointment: {
        date: appointmentDate,
        time: appointmentTime,
        doctor: appointment.doctor,
        procedure: appointment.procedure || "consulta",
        type: appointmentType,
        isTelemedicine: appointment.isTelemedicine ?? false,
        meetingLink: appointment.meetingLink,
      },
      doctor: {
        name: appointment.doctor,
      },
      date: {
        today: now.toLocaleDateString("pt-BR"),
        now: now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
        weekday: now.toLocaleDateString("pt-BR", { weekday: "long" }),
      },
      reschedule: {
        options: "",
      },
      cancellation: {
        reason: "",
      },
    },
  };
}

async function getReminderConfigMessage(
  ctx: any,
  clinicId: string,
  type:
    | "appointmentConfirmation"
    | "sevenDay"
    | "twentyFourHour"
    | "oneHour"
    | "postConsultation"
    | "noShowRecovery"
    | "rescheduleOptions"
    | "rescheduleConfirmation"
    | "confirmationReply"
    | "cancellationConfirmation"
    | "googleReviewFollowUp"
    | "detractorAlert",
) {
  const config = await ctx.runQuery(
    internalAny.automationInternal.getReminderConfigByClinicAndType,
    {
      clinicId,
      type,
    },
  );

  if (!config?.enabled || !config.message?.trim()) {
    return null;
  }

  return config.message;
}

async function sendConfiguredChatMessage(
  ctx: any,
  args: {
    clinicId: string;
    chatId: any;
    type:
      | "postConsultation"
      | "noShowRecovery"
      | "rescheduleOptions"
      | "confirmationReply"
      | "cancellationConfirmation";
    context: Record<string, any>;
    appointmentId?: any;
    reminderType?: "postConsultation" | "noShowRecovery";
    automationKind?: "rescheduleOptions" | "confirmationReply" | "cancellationConfirmation";
  },
) {
  const template = await getReminderConfigMessage(ctx, args.clinicId, args.type);
  if (!template) {
    return { sent: false, reason: "config_disabled" };
  }

  const text = mastraModule.workflows.personalizeMessage(template, args.context);
  const tracking =
    args.appointmentId && (args.reminderType || args.automationKind)
      ? {
          clinicId: args.clinicId,
          appointmentId: args.appointmentId,
          reminderType: args.reminderType,
          automationKind: args.automationKind,
        }
      : undefined;

  const messageId = await ctx.runMutation(internalAny.whatsappQueries.sendMessageAction, {
    chatId: args.chatId,
    text,
    tracking,
  });

  return { sent: true, messageId, text };
}

function appendTelemedicineMeetingLink(text: string, context: any, reminderType: string) {
  if (reminderType !== "appointmentConfirmation") {
    return text;
  }

  if (!context?.appointment?.isTelemedicine || !context?.appointment?.meetingLink) {
    return text;
  }

  if (text.includes(context.appointment.meetingLink)) {
    return text;
  }

  return `${text}\n\nLink da teleconsulta: ${context.appointment.meetingLink}`;
}

async function sendAppointmentMessage(
  ctx: any,
  args: {
    clinicId: string;
    appointmentId: any;
    reminderType: "appointmentConfirmation" | "sevenDay" | "twentyFourHour" | "oneHour";
    automationKind: "confirmationRequest" | "appointmentReminder";
  },
) {
  const payload = await buildAppointmentMessageContext(ctx, args.clinicId, args.appointmentId);
  if (!payload) {
    return { sent: false, reason: "missing_context" };
  }

  const reminderConfigs = await ctx.runQuery(
    internalAny.automationInternal.getReminderConfigsByClinic,
    {
      clinicId: args.clinicId,
    },
  );
  const config = reminderConfigs?.find((entry: any) => entry.type === args.reminderType);
  if (!config?.enabled) {
    return { sent: false, reason: "config_disabled" };
  }

  const text = appendTelemedicineMeetingLink(
    mastraModule.workflows.personalizeMessage(config.message, payload.context),
    payload.context,
    args.reminderType,
  );
  const chatId = await ensurePatientChat(ctx, {
    clinicId: args.clinicId,
    patientId: payload.appointment.patientId,
    patientName: payload.patient.name,
    phone: payload.patient.phone,
  });

  if (!chatId) {
    await ctx.runMutation(internalAny.automationInternal.upsertAppointmentReminderState, {
      clinicId: args.clinicId,
      appointmentId: args.appointmentId,
      reminderType: args.reminderType,
      status: "failed",
      channels: ["whatsapp"],
      lastError: "WhatsApp chat not found",
    });
    return { sent: false, reason: "missing_chat" };
  }

  const messageId = await ctx.runMutation(internalAny.whatsappQueries.sendMessageAction, {
    chatId,
    text,
    tracking: {
      clinicId: args.clinicId,
      appointmentId: args.appointmentId,
      reminderType: args.reminderType,
      markLegacyReminderAt: args.reminderType !== "appointmentConfirmation",
      automationKind: args.automationKind,
    },
  });

  return {
    sent: true,
    messageId,
    chatId,
    appointment: payload.appointment,
    patient: payload.patient,
  };
}

async function findTrackedAppointmentMessage(
  ctx: any,
  clinicId: string,
  chatId: any,
  message: any,
) {
  if (message?.replyToId) {
    const repliedMessage = await ctx.runQuery(internalAny.whatsappInternal.getMessage, {
      id: message.replyToId,
    });
    if (repliedMessage?.appointmentId && repliedMessage?.automationKind) {
      return repliedMessage;
    }
  }

  const recentMessages = await ctx.runQuery(internalAny.whatsappQueries.getChatMessagesInternal, {
    clinicId,
    chatId,
    limit: 20,
  });

  return [...(recentMessages || [])]
    .reverse()
    .find(
      (entry: any) =>
        entry.direction === "out" &&
        entry.appointmentId &&
        entry.automationKind &&
        !entry.isInternal,
    );
}

/**
 * Send post-consultation reminder (NPS survey)
 * Triggered when appointment status changes to "completed"
 */
export const sendPostConsultationReminder = internalAction({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    console.warn("[sendPostConsultationReminder] Starting...");
    initMastraConvex();

    const { appointmentId, clinicId } = args;

    await ctx.runMutation(internalAny.automationInternal.ensureReminderConfigsForClinic, {
      clinicId,
    });

    // Get appointment details
    const appointment = await ctx.runQuery(internalAny.appointments.getByIdInternal, {
      id: appointmentId,
      clinicId,
    });

    if (!appointment) {
      throw new Error("Appointment not found");
    }

    // Get post-consultation reminder config
    const reminderConfigs = await ctx.runQuery(
      internalAny.automationInternal.getReminderConfigsByClinic,
      {
        clinicId,
      },
    );

    const postConsultConfig = reminderConfigs?.find((c: any) => c.type === "postConsultation");

    if (!postConsultConfig || !postConsultConfig.enabled) {
      console.warn("[sendPostConsultationReminder] Config disabled or not found");
      return;
    }

    const payload = await buildAppointmentMessageContext(ctx, clinicId, appointmentId);
    if (!payload) throw new Error("Appointment context not found");

    // Create reminder agent
    const _tools = mastraModule.createConvexTools(ctx, clinicId);
    const _agent = mastraModule.createReminderAgent({ clinicId }, _tools);

    // Send via WhatsApp
    if (payload.patient.phone) {
      const chat = await ctx.runQuery(internalAny.whatsappQueries.findChatByPhone, {
        clinicId,
        phone: payload.patient.phone,
      });

      if (chat) {
        await sendConfiguredChatMessage(ctx, {
          clinicId,
          chatId: chat._id,
          type: "postConsultation",
          context: payload.context,
          appointmentId,
          reminderType: "postConsultation",
        });

        console.warn(
          `[sendPostConsultationReminder] Sent NPS reminder to patient ${payload.patient.name}`,
        );
        return { sent: true, messageId: chat._id };
      }
    }

    return { sent: false, reason: "WhatsApp chat not found" };
  },
});

/**
 * Handle no-show recovery
 * Triggered when appointment is missed/cancelled
 */
export const handleNoShowRecovery = internalAction({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    console.warn("[handleNoShowRecovery] Starting...");
    initMastraConvex();

    const { appointmentId, clinicId } = args;

    await ctx.runMutation(internalAny.automationInternal.ensureReminderConfigsForClinic, {
      clinicId,
    });

    // Get appointment details
    const appointment = await ctx.runQuery(internalAny.appointments.getByIdInternal, {
      id: appointmentId,
      clinicId,
    });

    if (!appointment) {
      throw new Error("Appointment not found");
    }

    // Get no-show recovery config
    const reminderConfigs = await ctx.runQuery(
      internalAny.automationInternal.getReminderConfigsByClinic,
      {
        clinicId,
      },
    );

    const noShowConfig = reminderConfigs?.find((c: any) => c.type === "noShowRecovery");

    if (!noShowConfig || !noShowConfig.enabled) {
      console.warn("[handleNoShowRecovery] Config disabled or not found");
      return;
    }

    const payload = await buildAppointmentMessageContext(ctx, clinicId, appointmentId);
    if (!payload) throw new Error("Appointment context not found");

    // Create recovery agent
    const _tools = mastraModule.createConvexTools(ctx, clinicId);
    const _agent = mastraModule.createReminderAgent({ clinicId }, _tools);

    // Send via WhatsApp
    if (payload.patient.phone) {
      const chat = await ctx.runQuery(internalAny.whatsappQueries.findChatByPhone, {
        clinicId,
        phone: payload.patient.phone,
      });

      if (chat) {
        await sendConfiguredChatMessage(ctx, {
          clinicId,
          chatId: chat._id,
          type: "noShowRecovery",
          context: payload.context,
          appointmentId,
          reminderType: "noShowRecovery",
        });

        console.warn(
          `[handleNoShowRecovery] Sent no-show recovery to patient ${payload.patient.name}`,
        );
        return { sent: true, messageId: chat._id };
      }
    }

    return { sent: false, reason: "WhatsApp chat not found" };
  },
});

/**
 * Send appointment confirmation immediately after booking
 * Called when a new appointment is created
 */
export const sendAppointmentConfirmation = internalAction({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    console.warn("[sendAppointmentConfirmation] Starting...");
    initMastraConvex();

    const { appointmentId, clinicId } = args;

    await ctx.runMutation(internalAny.automationInternal.ensureReminderConfigsForClinic, {
      clinicId,
    });
    const appointment = await ctx.runQuery(internalAny.appointments.getByIdInternal, {
      id: appointmentId,
      clinicId,
    });

    if (!appointment) {
      console.error("[sendAppointmentConfirmation] Appointment not found:", appointmentId);
      await ctx.runMutation(internalAny.automationInternal.upsertAppointmentReminderState, {
        clinicId,
        appointmentId,
        reminderType: "appointmentConfirmation",
        status: "failed",
        channels: ["whatsapp"],
        lastError: "Appointment not found",
      });
      return { sent: false, error: "Appointment not found" };
    }

    if (appointment.status !== "pending") {
      return { sent: false, reason: "appointment_not_pending" };
    }

    const result = await sendAppointmentMessage(ctx, {
      clinicId,
      appointmentId,
      reminderType: "appointmentConfirmation",
      automationKind: "confirmationRequest",
    });

    if (result.sent) {
      console.warn(
        `[sendAppointmentConfirmation] Queued confirmation request for patient ${result.patient.name}`,
      );
    }

    return result;
  },
});

export const sendConfirmedAppointmentReminder = internalAction({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
    reminderType: v.union(v.literal("sevenDay"), v.literal("twentyFourHour"), v.literal("oneHour")),
  },
  handler: async (ctx, args) => {
    initMastraConvex();

    await ctx.runMutation(internalAny.automationInternal.ensureReminderConfigsForClinic, {
      clinicId: args.clinicId,
    });

    const appointment = await ctx.runQuery(internalAny.appointments.getByIdInternal, {
      id: args.appointmentId,
      clinicId: args.clinicId,
    });
    if (
      !appointment ||
      appointment.deletedAt ||
      ["cancelled", "arrived", "completed"].includes(appointment.status)
    ) {
      return { sent: false, reason: "appointment_not_remindable" };
    }

    return await sendAppointmentMessage(ctx, {
      clinicId: args.clinicId,
      appointmentId: args.appointmentId,
      reminderType: args.reminderType,
      automationKind: "appointmentReminder",
    });
  },
});

export const runScheduledAppointmentJob = internalAction({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
    jobKind: v.union(
      v.literal("appointmentConfirmation"),
      v.literal("sevenDay"),
      v.literal("twentyFourHour"),
      v.literal("oneHour"),
      v.literal("rescheduleTimeout"),
    ),
  },
  handler: async (ctx, args) => {
    initMastraConvex();

    let result;
    if (args.jobKind === "appointmentConfirmation") {
      result = await ctx.runAction(internalAny.automationActions.sendAppointmentConfirmation, {
        appointmentId: args.appointmentId,
        clinicId: args.clinicId,
      });
    } else if (args.jobKind === "rescheduleTimeout") {
      result = await ctx.runMutation(internalAny.appointments.cancelFromRescheduleTimeoutInternal, {
        appointmentId: args.appointmentId,
        clinicId: args.clinicId,
      });
      if (result?.cancelled && result?.chatId) {
        const payload = await buildAppointmentMessageContext(
          ctx,
          args.clinicId,
          args.appointmentId,
        );
        await sendConfiguredChatMessage(ctx, {
          clinicId: args.clinicId,
          chatId: result.chatId,
          type: "cancellationConfirmation",
          context: {
            ...(payload?.context || {}),
            cancellation: {
              reason: " por nao recebermos sua resposta a tempo",
            },
          },
          appointmentId: args.appointmentId,
          automationKind: "cancellationConfirmation",
        });
      }
    } else {
      result = await ctx.runAction(internalAny.automationActions.sendConfirmedAppointmentReminder, {
        appointmentId: args.appointmentId,
        clinicId: args.clinicId,
        reminderType: args.jobKind,
      });
    }

    await ctx.runMutation(internalAny.automationInternal.markScheduledJobExecuted, {
      appointmentId: args.appointmentId,
      jobKind: args.jobKind,
    });

    return result;
  },
});

export const handleAppointmentReply = internalAction({
  args: {
    clinicId: v.string(),
    chatId: v.id("chats"),
    messageId: v.id("messages"),
    patientId: v.optional(v.id("patients")),
  },
  handler: async (ctx, args) => {
    initMastraConvex();

    const inboundMessage = await ctx.runQuery(internalAny.whatsappInternal.getMessage, {
      id: args.messageId,
    });
    if (!inboundMessage || inboundMessage.direction !== "in") {
      return { handled: false, reason: "invalid_message" };
    }

    const sourceMessage = await findTrackedAppointmentMessage(
      ctx,
      args.clinicId,
      args.chatId,
      inboundMessage,
    );
    if (!sourceMessage?.appointmentId || !sourceMessage?.automationKind) {
      return { handled: false, reason: "no_appointment_context" };
    }

    const inboundText = String(inboundMessage.body || "");

    if (sourceMessage.automationKind === "confirmationRequest") {
      if (isAffirmativeReply(inboundText)) {
        const result = await ctx.runMutation(
          internalAny.appointments.confirmByPatientReplyInternal,
          {
            appointmentId: sourceMessage.appointmentId,
            clinicId: args.clinicId,
            responseMessageId: args.messageId,
          },
        );

        if (result?.chatId) {
          const payload = await buildAppointmentMessageContext(
            ctx,
            args.clinicId,
            sourceMessage.appointmentId,
          );
          await sendConfiguredChatMessage(ctx, {
            clinicId: args.clinicId,
            chatId: result.chatId,
            type: "confirmationReply",
            context: payload?.context || {},
            appointmentId: sourceMessage.appointmentId,
            automationKind: "confirmationReply",
          });
        }

        return { handled: true, outcome: "confirmed" };
      }

      if (isNegativeReply(inboundText)) {
        const result = await ctx.runAction(
          internalAny.automationActions.beginRescheduleFlowFromDeclinedConfirmation,
          {
            appointmentId: sourceMessage.appointmentId,
            clinicId: args.clinicId,
            responseMessageId: args.messageId,
          },
        );
        return { handled: true, outcome: result.outcome };
      }

      return { handled: false, reason: "confirmation_reply_not_understood" };
    }

    if (sourceMessage.automationKind === "rescheduleOptions") {
      const optionIndex = parseRescheduleOption(inboundText);
      if (optionIndex !== null) {
        await ctx.runMutation(internalAny.appointments.applyRescheduleOptionInternal, {
          appointmentId: sourceMessage.appointmentId,
          clinicId: args.clinicId,
          optionIndex,
          responseMessageId: args.messageId,
        });
        return { handled: true, outcome: "rescheduled" };
      }

      if (isNegativeReply(inboundText)) {
        const result = await ctx.runMutation(
          internalAny.appointments.cancelAfterRescheduleDeclineInternal,
          {
            appointmentId: sourceMessage.appointmentId,
            clinicId: args.clinicId,
            responseMessageId: args.messageId,
          },
        );

        if (result?.chatId) {
          const payload = await buildAppointmentMessageContext(
            ctx,
            args.clinicId,
            sourceMessage.appointmentId,
          );
          await sendConfiguredChatMessage(ctx, {
            clinicId: args.clinicId,
            chatId: result.chatId,
            type: "cancellationConfirmation",
            context: {
              ...(payload?.context || {}),
              cancellation: { reason: "" },
            },
            appointmentId: sourceMessage.appointmentId,
            automationKind: "cancellationConfirmation",
          });
        }

        return { handled: true, outcome: "cancelled" };
      }

      return { handled: false, reason: "reschedule_reply_not_understood" };
    }

    return { handled: false, reason: "unsupported_automation_kind" };
  },
});

export const beginRescheduleFlowFromDeclinedConfirmation = internalAction({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
    responseMessageId: v.optional(v.id("messages")),
  },
  handler: async (ctx, args) => {
    initMastraConvex();

    const appointment = await ctx.runQuery(internalAny.appointments.getByIdInternal, {
      id: args.appointmentId,
      clinicId: args.clinicId,
    });
    if (!appointment) {
      return { outcome: "missing_appointment" };
    }

    if (!appointment.doctorId || !appointment.procedureId) {
      const cancelled = await ctx.runMutation(
        internalAny.appointments.cancelAfterRescheduleDeclineInternal,
        {
          appointmentId: args.appointmentId,
          clinicId: args.clinicId,
          responseMessageId: args.responseMessageId,
        },
      );

      if (cancelled?.chatId) {
        const payload = await buildAppointmentMessageContext(
          ctx,
          args.clinicId,
          args.appointmentId,
        );
        await sendConfiguredChatMessage(ctx, {
          clinicId: args.clinicId,
          chatId: cancelled.chatId,
          type: "cancellationConfirmation",
          context: {
            ...(payload?.context || {}),
            cancellation: {
              reason: " porque nao consegui sugerir novos horarios agora",
            },
          },
          appointmentId: args.appointmentId,
          automationKind: "cancellationConfirmation",
        });
      }

      return { outcome: cancelled?.cancelled ? "cancelled" : "failed" };
    }

    const payload = await buildAppointmentMessageContext(ctx, args.clinicId, args.appointmentId);
    if (!payload) {
      return { outcome: "failed" };
    }

    const slotResults = await ctx.runQuery(apiAny.appointments.getAvailableSlots, {
      clinicId: args.clinicId,
      doctorId: appointment.doctorId,
      procedureId: appointment.procedureId,
      startTime: new Date(appointment.startAt + 15 * 60 * 1000).toISOString(),
      endTime: new Date(appointment.startAt + 14 * 24 * 60 * 60 * 1000).toISOString(),
      isTelemedicine: appointment.isTelemedicine,
      maxSlots: 3,
    });

    const offeredSlots = (slotResults || []).slice(0, 3).map((slot: any) => ({
      startAt: new Date(slot.start).getTime(),
      endAt: new Date(slot.end).getTime(),
    }));

    if (offeredSlots.length === 0) {
      const cancelled = await ctx.runMutation(
        internalAny.appointments.cancelAfterRescheduleDeclineInternal,
        {
          appointmentId: args.appointmentId,
          clinicId: args.clinicId,
          responseMessageId: args.responseMessageId,
        },
      );

      if (cancelled?.chatId) {
        await sendConfiguredChatMessage(ctx, {
          clinicId: args.clinicId,
          chatId: cancelled.chatId,
          type: "cancellationConfirmation",
          context: {
            ...payload.context,
            cancellation: {
              reason: " porque nao encontrei horarios alternativos agora",
            },
          },
          appointmentId: args.appointmentId,
          automationKind: "cancellationConfirmation",
        });
      }

      return { outcome: "cancelled" };
    }

    const prepared = await ctx.runMutation(
      internalAny.appointments.prepareRescheduleOptionsInternal,
      {
        appointmentId: args.appointmentId,
        clinicId: args.clinicId,
        offeredSlots,
        responseMessageId: args.responseMessageId,
      },
    );

    if (!prepared?.chatId) {
      return { outcome: "failed" };
    }

    const formattedSlots = offeredSlots
      .map((slot: { startAt: number; endAt: number }, index: number) => {
        const start = new Date(slot.startAt);
        const dateStr = start.toLocaleDateString("pt-BR", {
          day: "2-digit",
          month: "2-digit",
          timeZone: appointment.timeZone || "America/Sao_Paulo",
        });
        const timeStr = start.toLocaleTimeString("pt-BR", {
          hour: "2-digit",
          minute: "2-digit",
          timeZone: appointment.timeZone || "America/Sao_Paulo",
        });
        return `${index + 1}. ${dateStr} as ${timeStr}`;
      })
      .join("\n");

    await sendConfiguredChatMessage(ctx, {
      clinicId: args.clinicId,
      chatId: prepared.chatId,
      type: "rescheduleOptions",
      context: {
        ...payload.context,
        reschedule: {
          options: formattedSlots,
        },
      },
      appointmentId: args.appointmentId,
      automationKind: "rescheduleOptions",
    });

    return { outcome: "reschedule_offered" };
  },
});

// ============================================
// CAMPAIGN EXECUTION ACTIONS
// ============================================

/**
 * Schedule and execute campaigns based on trigger conditions
 * Runs every 30 minutes to check for campaign triggers
 */
export const scheduleCampaignExecution = internalAction({
  args: {
    clinicId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    console.warn("[scheduleCampaignExecution] Starting...");
    initMastraConvex();

    // Get clinics to process
    let clinicIds: string[] = [];
    if (args.clinicId) {
      clinicIds = [args.clinicId];
    } else {
      // Get all clinics with active campaigns
      clinicIds = await ctx.runQuery(
        internalAny.automationCampaigns.getAllActiveCampaignClinics,
        {},
      );
      console.warn(
        `[scheduleCampaignExecution] Found ${clinicIds.length} clinics with active campaigns`,
      );
    }

    const now = Date.now();

    for (const clinicId of clinicIds) {
      try {
        // Get clinic details
        const clinic = await ctx.runQuery(internalAny.clinics.getClinicInternal, { clinicId });
        const clinicName = clinic?.name || clinicId;

        // Get all active campaigns for this clinic
        const campaigns = await ctx.runQuery(internalAny.automation.listCampaigns, {
          clinicId,
          status: "active",
        });

        if (!campaigns || campaigns.length === 0) {
          continue;
        }

        for (const campaign of campaigns) {
          console.warn(`[scheduleCampaignExecution] Checking campaign: ${campaign.name}`);

          // Check trigger conditions
          let appointmentsToProcess: any[] = [];

          switch (campaign.triggerType) {
            case "time_after_appointment": {
              // Find appointments completed X hours ago
              const cutoff = now - (campaign.triggerDelayHours || 0) * 60 * 60 * 1000;
              appointmentsToProcess = await ctx.runQuery(internalAny.appointments.list, {
                clinicId,
                status: "completed",
                startAt: cutoff - 60 * 60 * 1000, // 1 hour window
                endAt: cutoff,
              });
              break;
            }

            case "time_after_procedure": {
              // Similar to time_after_appointment but filter by procedure
              // TODO: Add procedure filter
              appointmentsToProcess = [];
              break;
            }

            case "birthday": {
              const today = new Date();
              const todayMonth = today.getUTCMonth() + 1;
              const todayDay = today.getUTCDate();
              const birthdayPatients = await ctx.runQuery(internalAny.patients.listByBirthday, {
                clinicId,
                month: todayMonth,
                day: todayDay,
              });

              // Map to pseudo-appointments for processing
              appointmentsToProcess = birthdayPatients.map((p: any) => ({
                _id: undefined,
                patientId: p._id,
                startAt: now,
                doctor: clinicName,
              }));
              break;
            }

            case "no_show":
              // Find missed appointments (cancelled without prior notice)
              appointmentsToProcess = await ctx.runQuery(internalAny.appointments.list, {
                clinicId,
                status: "cancelled",
                startAt: now - 24 * 60 * 60 * 1000, // Last 24 hours
                endAt: now,
              });
              break;

            case "custom":
              // Only manual trigger, skip
              continue;
          }

          if (appointmentsToProcess.length === 0) {
            continue;
          }

          // Process each matching appointment
          for (const appointment of appointmentsToProcess) {
            // Check if already sent (idempotency)
            const alreadySent = await ctx.runQuery(
              internalAny.automationCampaigns.getCampaignSentLog,
              {
                campaignId: campaign._id,
                appointmentId: appointment._id,
                patientId: appointment.patientId,
              },
            );

            if (alreadySent) {
              continue;
            }

            console.warn(
              `[scheduleCampaignExecution] Executing campaign ${campaign.name} for patient ${appointment.patientId}`,
            );

            // Get patient
            const patient = await ctx.runQuery(internalAny.patients.getById, {
              id: appointment.patientId,
            });

            if (!patient) {
              continue;
            }

            // Prepare context
            const apptObj = new Date(appointment.startAt);
            const appointmentDate = apptObj.toLocaleDateString("pt-BR");
            const appointmentTime = apptObj.toLocaleTimeString("pt-BR", {
              hour: "2-digit",
              minute: "2-digit",
            });
            const nowObj = new Date();

            const context = {
              patientName: patient.name,
              patientPhone: patient.phone,
              appointmentDate,
              appointmentTime,
              clinicName: clinicName,
              doctorName: appointment.doctor,
              patient: {
                name: patient.name,
                phone: patient.phone,
                email: patient.email,
                cpf: patient.cpf,
              },
              clinic: {
                name: clinic?.name || clinicName,
                phone: clinic?.phone,
                address: clinic?.address,
                website: clinic?.website,
              },
              appointment: {
                date: appointmentDate,
                time: appointmentTime,
                doctor: appointment.doctor,
              },
              date: {
                today: nowObj.toLocaleDateString("pt-BR"),
                now: nowObj.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
                weekday: nowObj.toLocaleDateString("pt-BR", { weekday: "long" }),
              },
            };

            // Execute campaign steps with proper scheduling
            let cumulativeDelayMs = 0;

            for (const step of campaign.steps) {
              // First step (order 1) is sent immediately, subsequent steps respect delays
              const stepDelayMs = step.order === 1 ? 0 : (step.delayHours || 0) * 60 * 60 * 1000;
              cumulativeDelayMs += stepDelayMs;

              // Prepare step execution data
              const stepData = {
                campaignId: campaign._id,
                campaignName: campaign.name,
                clinicId,
                clinicName: clinicName,
                appointmentId: appointment._id,
                patientId: appointment.patientId,
                patientPhone: patient.phone,
                patientEmail: patient.email,
                stepOrder: step.order,
                channel: step.channel,
                message: step.message,
                context: JSON.stringify(context),
              };

              if (cumulativeDelayMs === 0) {
                // Send first step immediately
                console.warn(`[scheduleCampaignExecution] Sending step ${step.order} immediately`);
                await ctx.runAction(internal.automationActions.executeCampaignStep, stepData);
              } else {
                // Schedule subsequent steps with delay
                console.warn(
                  `[scheduleCampaignExecution] Scheduling step ${step.order} for ${cumulativeDelayMs}ms (${step.delayHours}h) later`,
                );
                await ctx.scheduler.runAfter(
                  cumulativeDelayMs,
                  internal.automationActions.executeCampaignStep,
                  stepData,
                );
              }
            }

            // Increment trigger count
            await ctx.runMutation(internal.automationCampaigns.incrementTriggerCount, {
              campaignId: campaign._id,
            });
          }
        }
      } catch (error) {
        console.error(`[scheduleCampaignExecution] Error processing clinic ${clinicId}:`, error);
      }
    }

    console.warn("[scheduleCampaignExecution] Completed");
    return { processed: clinicIds.length };
  },
});

/**
 * Execute a single campaign step (used for scheduled/delayed steps)
 * This action is called by the scheduler for delayed campaign steps
 */
export const executeCampaignStep = internalAction({
  args: {
    campaignId: v.id("campaigns"),
    campaignName: v.string(),
    clinicId: v.string(),
    clinicName: v.string(),
    appointmentId: v.optional(v.id("appointments")),
    patientId: v.id("patients"),
    patientPhone: v.optional(v.string()),
    patientEmail: v.optional(v.string()),
    stepOrder: v.number(),
    channel: v.string(),
    message: v.string(),
    context: v.string(), // JSON stringified context
  },
  handler: async (ctx, args) => {
    console.warn(
      `[executeCampaignStep] Executing step ${args.stepOrder} of campaign ${args.campaignName}`,
    );
    initMastraConvex();

    try {
      // Parse context
      const context = JSON.parse(args.context);

      // Personalize message
      const personalizedMessage = mastraModule.workflows.personalizeMessage(args.message, context);

      // Send via configured channel
      if (args.channel === "whatsapp" && args.patientPhone) {
        const chat = await ctx.runQuery(internalAny.whatsappQueries.findChatByPhone, {
          clinicId: args.clinicId,
          phone: args.patientPhone,
        });

        if (chat) {
          await ctx.runMutation(internalAny.whatsappQueries.sendMessageAction, {
            chatId: chat._id,
            text: personalizedMessage,
          });

          // Log campaign execution
          await ctx.runMutation(internalAny.automationCampaigns.logCampaignExecution, {
            campaignId: args.campaignId,
            clinicId: args.clinicId,
            appointmentId: args.appointmentId,
            patientId: args.patientId,
            stepOrder: args.stepOrder,
            channel: args.channel,
            sentAt: Date.now(),
          });

          console.warn(`[executeCampaignStep] Sent step ${args.stepOrder} via WhatsApp`);
          return { success: true, channel: "whatsapp" };
        } else {
          console.warn(
            `[executeCampaignStep] No WhatsApp chat found for phone ${args.patientPhone}`,
          );
          return { success: false, reason: "no_chat" };
        }
      }

      if (args.channel === "email" && args.patientEmail) {
        await ctx.runAction(internalAny.emailActions.sendEmail, {
          to: args.patientEmail,
          subject: `Mensagem de ${args.clinicName}`,
          html: personalizedMessage.replace(/\n/g, "<br>"),
        });

        // Log campaign execution
        await ctx.runMutation(internalAny.automationCampaigns.logCampaignExecution, {
          campaignId: args.campaignId,
          clinicId: args.clinicId,
          appointmentId: args.appointmentId,
          patientId: args.patientId,
          stepOrder: args.stepOrder,
          channel: args.channel,
          sentAt: Date.now(),
        });

        console.warn(`[executeCampaignStep] Sent step ${args.stepOrder} via Email`);
        return { success: true, channel: "email" };
      }

      console.warn(`[executeCampaignStep] No valid channel/contact for step ${args.stepOrder}`);
      return { success: false, reason: "no_contact" };
    } catch (error) {
      console.error(`[executeCampaignStep] Error executing step ${args.stepOrder}:`, error);
      return { success: false, reason: "error", error: String(error) };
    }
  },
});

/**
 * Check for birthday campaigns (daily cron at 9 AM)
 */
export const checkBirthdayCampaigns = internalAction({
  args: {},
  handler: async (_ctx) => {
    // Birthday campaigns are now handled by scheduleCampaignExecution
    return { checked: true };
  },
});
