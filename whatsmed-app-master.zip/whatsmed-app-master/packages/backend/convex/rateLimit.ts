import { v } from "convex/values";

import { mutation } from "./_generated/server";

const DEFAULT_WINDOW_MS = 60_000;
const CLEANUP_HORIZON_MS = 24 * 60 * 60 * 1000; // 24h

export const check = mutation({
  args: {
    key: v.string(),
    limit: v.number(),
    windowMs: v.optional(v.number()),
    clinicId: v.optional(v.string()),
  },
  handler: async (ctx, { key, limit, windowMs, clinicId }) => {
    const window = windowMs ?? DEFAULT_WINDOW_MS;
    const now = Date.now();
    const windowStart = now - window;
    const scopedClinicId = clinicId ?? "global";

    // Record this request
    await ctx.db.insert("rateLimits", {
      key,
      clinicId: scopedClinicId,
      count: 1,
      windowStart: now,
      createdAt: now,
    });

    // Count recent requests for this key within the window
    const recent = await ctx.db
      .query("rateLimits")
      .withIndex("by_clinic_key", (q) => q.eq("clinicId", scopedClinicId).eq("key", key))
      .filter((q) => q.gte(q.field("windowStart"), windowStart))
      .take(limit + 1); // small cap for efficiency

    const used = recent.length;
    const remaining = Math.max(limit - used, 0);
    const reset = now + window;

    return {
      allowed: used <= limit,
      limit,
      remaining,
      reset,
    };
  },
});

export const cleanup = mutation({
  args: {
    horizonMs: v.optional(v.number()),
  },
  handler: async (ctx, { horizonMs }) => {
    const cutoff = Date.now() - (horizonMs ?? CLEANUP_HORIZON_MS);
    const stale = await ctx.db
      .query("rateLimits")
      .filter((q) => q.lt(q.field("windowStart"), cutoff))
      .take(500);

    await Promise.all(stale.map((row) => ctx.db.delete(row._id)));

    return { deleted: stale.length };
  },
});
