import { v } from "convex/values";

import { query, mutation, internalQuery, internalMutation } from "./_generated/server";
import { conflict, notFound } from "./lib/errors";
import { formatToE164, isValidE164 } from "./lib/phoneUtils";
import { isValidEmail, sanitizeString } from "./lib/validators";

function normalizeSearchText(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

function extractDigits(value: string): string {
  return value.replace(/\D/g, "");
}

export const list = query({
  args: {
    clinicId: v.string(),
    status: v.optional(v.union(v.literal("active"), v.literal("inactive"))),
    search: v.optional(v.string()),
    limit: v.optional(v.number()),
    cursor: v.optional(v.string()),
    sortBy: v.optional(v.union(v.literal("createdAt"), v.literal("status"))),
    order: v.optional(v.union(v.literal("asc"), v.literal("desc"))),
    dateStart: v.optional(v.number()),
    dateEnd: v.optional(v.number()),
    hasEmail: v.optional(v.boolean()),
    hasPhone: v.optional(v.boolean()),
    externalId: v.optional(v.string()),
    orFilters: v.optional(v.boolean()),
  },
  handler: async (
    ctx,
    {
      clinicId,
      status,
      search,
      limit = 50,
      cursor,
      sortBy = "createdAt",
      order = "desc",
      dateStart,
      dateEnd,
      hasEmail,
      hasPhone,
      externalId,
      orFilters = false,
    },
  ) => {
    const normalizedSearch = search ? normalizeSearchText(search) : "";
    const searchDigits = search ? extractDigits(search) : "";
    const needsComplexFilter =
      !!search ||
      hasEmail !== undefined ||
      hasPhone !== undefined ||
      !!externalId ||
      dateStart !== undefined ||
      dateEnd !== undefined;

    const matchesSearch = (doc: any): boolean => {
      if (!search) return true;
      const name = normalizeSearchText(doc.name ?? "");
      const email = normalizeSearchText(doc.email ?? "");
      const external = normalizeSearchText(doc.externalId ?? "");
      const phoneDigits = extractDigits(doc.phone ?? "");
      const cpfDigits = extractDigits(doc.cpf ?? "");

      return (
        name.includes(normalizedSearch) ||
        email.includes(normalizedSearch) ||
        external.includes(normalizedSearch) ||
        (searchDigits.length > 0 &&
          (phoneDigits.includes(searchDigits) || cpfDigits.includes(searchDigits)))
      );
    };

    const matchesFilters = (doc: any): boolean => {
      if (doc.deletedAt) return false;
      const checks: boolean[] = [];
      if (search) checks.push(matchesSearch(doc));
      if (hasEmail !== undefined) checks.push(hasEmail ? !!doc.email : !doc.email);
      if (hasPhone !== undefined) checks.push(hasPhone ? !!doc.phone : !doc.phone);
      if (externalId) checks.push((doc.externalId ?? "") === externalId);
      if (dateStart !== undefined) {
        const ref = doc.dateOfBirth ?? doc.createdAt;
        checks.push(ref !== undefined && ref >= dateStart);
      }
      if (dateEnd !== undefined) {
        const ref = doc.dateOfBirth ?? doc.createdAt;
        checks.push(ref !== undefined && ref <= dateEnd);
      }
      if (checks.length === 0) return true;
      return orFilters ? checks.some(Boolean) : checks.every(Boolean);
    };

    // Use search index for name search when no other complex filters
    if (
      search &&
      !status &&
      sortBy === "createdAt" &&
      !hasEmail &&
      !hasPhone &&
      !externalId &&
      !dateStart &&
      !dateEnd
    ) {
      const results = await ctx.db
        .query("patients")
        .withSearchIndex("search_name", (q) => q.search("name", search).eq("clinicId", clinicId))
        .take(limit * 3);

      const filtered = results.filter((doc) => !doc.deletedAt && matchesSearch(doc));
      const ordered =
        order === "desc"
          ? filtered.sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0))
          : filtered.sort((a, b) => (a.createdAt ?? 0) - (b.createdAt ?? 0));

      return {
        items: ordered.slice(0, limit),
        cursor: null,
        isDone: true,
        total: Math.min(ordered.length, limit),
      };
    }

    // Standard index-based query with post-filtering
    const createBaseQuery = () => {
      if (status && sortBy !== "status") {
        return ctx.db
          .query("patients")
          .withIndex("by_clinic_status_createdAt", (q) =>
            q.eq("clinicId", clinicId).eq("status", status),
          );
      }

      if (sortBy === "status" || status) {
        return ctx.db
          .query("patients")
          .withIndex("by_clinic_status_createdAt", (q) =>
            q.eq("clinicId", clinicId).eq("status", status ?? "active"),
          );
      }

      return ctx.db
        .query("patients")
        .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", clinicId));
    };

    if (!needsComplexFilter) {
      const results = await createBaseQuery()
        .order(order)
        .paginate({ cursor: cursor ?? null, numItems: limit });
      return {
        items: results.page.filter((doc) => !doc.deletedAt),
        cursor: results.continueCursor ?? null,
        isDone: results.isDone,
        total: results.page.length,
      };
    }

    // Complex filtering: collect the indexed result set once, then filter and
    // paginate in memory. Convex allows only a single paginated query per
    // function, so we avoid chaining multiple paginate calls here.
    const startIdx = cursor ? parseInt(cursor, 10) : 0;
    const allResults = await createBaseQuery().order(order).collect();
    const filtered = allResults.filter(matchesFilters);

    const page = filtered.slice(startIdx, startIdx + limit!);
    const nextCursor = startIdx + limit! < filtered.length ? String(startIdx + limit!) : null;

    return {
      items: page,
      cursor: nextCursor,
      isDone: nextCursor === null,
      total: page.length,
    };
  },
});

export const getById = query({
  args: {
    id: v.id("patients"),
    clinicId: v.string(),
  },
  handler: async (ctx, { id, clinicId }) => {
    const patient = await ctx.db.get(id);
    if (!patient || patient.clinicId !== clinicId || patient.deletedAt) {
      return null;
    }
    return patient;
  },
});

export const create = mutation({
  args: {
    clinicId: v.string(),
    name: v.string(),
    phone: v.optional(v.string()),
    email: v.optional(v.string()),
    cpf: v.optional(v.string()),
    dateOfBirth: v.optional(v.string()),
    gender: v.optional(v.union(v.literal("male"), v.literal("female"), v.literal("other"))),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    state: v.optional(v.string()),
    zip: v.optional(v.string()),
    country: v.optional(v.string()),
    externalId: v.optional(v.string()),
    notes: v.optional(v.string()),
    tags: v.optional(v.array(v.string())),
    status: v.optional(v.union(v.literal("active"), v.literal("inactive"))),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    if (args.email && !isValidEmail(args.email)) {
      throw conflict("E-mail inválido");
    }

    let formattedPhone: string | undefined;
    if (args.phone) {
      const e164 = formatToE164(args.phone);
      if (!e164 || !isValidE164(e164)) {
        throw conflict("Telefone inválido");
      }
      formattedPhone = e164;
    }

    const sanitizedName = sanitizeString(args.name, 200);

    if (formattedPhone) {
      const existing = await ctx.db
        .query("patients")
        .withIndex("by_clinic_phone", (q) =>
          q.eq("clinicId", args.clinicId).eq("phone", formattedPhone!),
        )
        .first();

      if (existing && !existing.deletedAt) {
        throw conflict("Paciente com este telefone já existe");
      }
    }

    if (args.email) {
      const existing = await ctx.db
        .query("patients")
        .withIndex("by_clinic_email", (q) =>
          q.eq("clinicId", args.clinicId).eq("email", args.email!),
        )
        .first();

      if (existing && !existing.deletedAt) {
        throw conflict("Paciente com este e-mail já existe");
      }
    }

    const patientId = await ctx.db.insert("patients", {
      clinicId: args.clinicId,
      name: sanitizedName,
      phone: formattedPhone,
      email: args.email,
      cpf: args.cpf,
      externalId: args.externalId,
      status: args.status ?? "active",
      dateOfBirth: args.dateOfBirth ? new Date(args.dateOfBirth).getTime() : undefined,
      gender: args.gender,
      address: args.address,
      city: args.city,
      state: args.state,
      zip: args.zip,
      country: args.country,
      notes: args.notes,
      tags: args.tags,
      createdAt: now,
    });

    return await ctx.db.get(patientId);
  },
});

export const update = mutation({
  args: {
    id: v.id("patients"),
    clinicId: v.string(),
    name: v.optional(v.string()),
    phone: v.optional(v.string()),
    email: v.optional(v.string()),
    cpf: v.optional(v.string()),
    dateOfBirth: v.optional(v.string()),
    gender: v.optional(v.union(v.literal("male"), v.literal("female"), v.literal("other"))),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    state: v.optional(v.string()),
    zip: v.optional(v.string()),
    country: v.optional(v.string()),
    externalId: v.optional(v.string()),
    notes: v.optional(v.string()),
    tags: v.optional(v.array(v.string())),
    status: v.optional(v.union(v.literal("active"), v.literal("inactive"))),
  },
  handler: async (ctx, args) => {
    const { id, clinicId, ...updates } = args;
    const patient = await ctx.db.get(id);

    if (!patient || patient.clinicId !== clinicId || patient.deletedAt) {
      throw notFound("Patient not found");
    }

    const updatesToApply = { ...updates };

    if (updates.phone) {
      const e164 = formatToE164(updates.phone);
      if (!e164 || !isValidE164(e164)) {
        throw conflict("Invalid phone number");
      }
      updatesToApply.phone = e164;

      if (updatesToApply.phone !== patient.phone) {
        const existing = await ctx.db
          .query("patients")
          .withIndex("by_clinic_phone", (q) =>
            q.eq("clinicId", clinicId).eq("phone", updatesToApply.phone!),
          )
          .first();
        if (existing && existing._id !== id && !existing.deletedAt) {
          throw conflict("Phone number already in use");
        }
      }
    }

    const patch: any = { ...updatesToApply, updatedAt: Date.now() };
    if (updates.dateOfBirth) {
      patch.dateOfBirth = new Date(updates.dateOfBirth).getTime();
    }
    if (updates.name) {
      patch.name = sanitizeString(updates.name, 200);
    }

    await ctx.db.patch(id, patch);
    return await ctx.db.get(id);
  },
});

export const softDelete = mutation({
  args: {
    id: v.id("patients"),
    clinicId: v.string(),
  },
  handler: async (ctx, { id, clinicId }) => {
    const patient = await ctx.db.get(id);
    if (!patient || patient.clinicId !== clinicId) {
      throw notFound("Patient not found");
    }

    await ctx.db.patch(id, { deletedAt: Date.now(), status: "inactive" });
  },
});

export const importBatch = mutation({
  args: {
    clinicId: v.string(),
    patients: v.array(
      v.object({
        name: v.string(),
        phone: v.optional(v.string()),
        email: v.optional(v.string()),
        cpf: v.optional(v.string()),
        dateOfBirth: v.optional(v.string()),
        gender: v.optional(v.union(v.literal("male"), v.literal("female"), v.literal("other"))),
        address: v.optional(v.string()),
        city: v.optional(v.string()),
        state: v.optional(v.string()),
        zip: v.optional(v.string()),
        country: v.optional(v.string()),
        externalId: v.optional(v.string()),
        notes: v.optional(v.string()),
        tags: v.optional(v.string()),
        status: v.optional(v.union(v.literal("active"), v.literal("inactive"))),
      }),
    ),
  },
  handler: async (ctx, { clinicId, patients }) => {
    const results = {
      success: 0,
      failed: 0,
      errors: [] as string[],
    };

    for (const p of patients) {
      try {
        let formattedPhone = p.phone;
        if (p.phone) {
          const e164 = formatToE164(p.phone);
          if (e164 && isValidE164(e164)) {
            formattedPhone = e164;
          }
        }

        if (formattedPhone) {
          const existing = await ctx.db
            .query("patients")
            .withIndex("by_clinic_phone", (q) =>
              q.eq("clinicId", clinicId).eq("phone", formattedPhone!),
            )
            .first();
          if (existing && !existing.deletedAt) {
            results.failed++;
            results.errors.push(`Duplicate phone: ${formattedPhone}`);
            continue;
          }
        }

        const parsedTags = p.tags
          ? p.tags
              .split(/[;,]/)
              .map((t) => t.trim())
              .filter(Boolean)
          : undefined;
        const normalizedStatus = p.status ?? "active";
        const normalizedGender =
          p.gender?.toLowerCase() === "masculino" || p.gender === "male"
            ? "male"
            : p.gender?.toLowerCase() === "feminino" || p.gender === "female"
              ? "female"
              : p.gender === "other"
                ? "other"
                : undefined;

        await ctx.db.insert("patients", {
          clinicId,
          name: sanitizeString(p.name, 200),
          phone: formattedPhone,
          email: p.email,
          cpf: p.cpf,
          externalId: p.externalId,
          status: normalizedStatus,
          dateOfBirth: p.dateOfBirth ? new Date(p.dateOfBirth).getTime() : undefined,
          gender: normalizedGender,
          address: p.address,
          city: p.city,
          state: p.state,
          zip: p.zip,
          country: p.country,
          notes: p.notes,
          tags: parsedTags,
          createdAt: Date.now(),
        });
        results.success++;
      } catch (err: any) {
        results.failed++;
        results.errors.push(`Error importing ${p.name}: ${err.message}`);
      }
    }

    return results;
  },
});

export const listByBirthday = internalQuery({
  args: {
    clinicId: v.string(),
    month: v.number(),
    day: v.number(),
  },
  handler: async (ctx, { clinicId, month, day }) => {
    // This is a scan. Ideally we should have an index.
    const patients = await ctx.db
      .query("patients")
      .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", clinicId))
      .filter((q) => q.eq(q.field("status"), "active"))
      .collect();

    return patients.filter((p) => {
      if (!p.dateOfBirth) return false;
      const dob = new Date(p.dateOfBirth);
      // getUTCMonth() is 0-indexed (0-11), so we add 1
      return dob.getUTCMonth() + 1 === month && dob.getUTCDate() === day;
    });
  },
});

export const getByIdInternal = internalQuery({
  args: {
    id: v.id("patients"),
  },
  handler: async (ctx, { id }) => {
    const patient = await ctx.db.get(id);
    if (!patient || patient.deletedAt) {
      return null;
    }
    return patient;
  },
});

export const getByPhoneInternal = internalQuery({
  args: {
    clinicId: v.string(),
    phone: v.string(),
  },
  handler: async (ctx, { clinicId, phone }) => {
    // Format phone to E.164 if possible
    let searchPhone = phone;
    const e164 = formatToE164(phone);
    if (e164 && isValidE164(e164)) {
      searchPhone = e164;
    }

    const patient = await ctx.db
      .query("patients")
      .withIndex("by_clinic_phone", (q) => q.eq("clinicId", clinicId).eq("phone", searchPhone))
      .first();

    if (!patient || patient.deletedAt) {
      return null;
    }

    return patient;
  },
});

/**
 * Save an image (insurance card, ID card, or referral) to a patient record
 * Internal mutation used by AI agent tools
 * For insurance_card, supports front/back via 'side' argument
 */
export const savePatientImage = internalMutation({
  args: {
    patientId: v.id("patients"),
    imageType: v.union(v.literal("insurance_card"), v.literal("id_card"), v.literal("referral")),
    storageId: v.id("_storage"),
    side: v.optional(v.union(v.literal("front"), v.literal("back"))),
  },
  handler: async (ctx, args) => {
    const patient = await ctx.db.get(args.patientId);
    if (!patient || patient.deletedAt) {
      throw new Error("Patient not found");
    }

    // Get storage URL
    const url = await ctx.storage.getUrl(args.storageId);
    if (!url) {
      throw new Error("Failed to get storage URL");
    }

    const now = Date.now();
    const patch: any = { updatedAt: now };

    if (args.imageType === "insurance_card") {
      // Determine which side to save
      // If side is specified, use it; otherwise, save to front if empty, else back
      let targetSide = args.side;
      if (!targetSide) {
        // Auto-detect: front first, then back
        targetSide = patient.insuranceCardFrontStorageId ? "back" : "front";
      }

      if (targetSide === "front") {
        patch.insuranceCardFrontStorageId = args.storageId;
        patch.insuranceCardFrontUrl = url;
        patch.insuranceCardFrontUploadedAt = now;
      } else {
        patch.insuranceCardBackStorageId = args.storageId;
        patch.insuranceCardBackUrl = url;
        patch.insuranceCardBackUploadedAt = now;
      }

      // Also update legacy fields for backward compatibility
      patch.insuranceCardStorageId = args.storageId;
      patch.insuranceCardUrl = url;
      patch.insuranceCardUploadedAt = now;
    } else if (args.imageType === "id_card") {
      patch.idCardStorageId = args.storageId;
      patch.idCardUrl = url;
      patch.idCardUploadedAt = now;
    } else if (args.imageType === "referral") {
      patch.referralStorageId = args.storageId;
      patch.referralUrl = url;
      patch.referralUploadedAt = now;
    }

    await ctx.db.patch(args.patientId, patch);

    return {
      success: true,
      url,
      imageType: args.imageType,
      side:
        args.imageType === "insurance_card"
          ? patch.insuranceCardFrontStorageId
            ? "front"
            : "back"
          : undefined,
    };
  },
});

/**
 * Update patient data - Internal mutation for AI agent
 * Allows the AI agent to update patient information
 * AUTO-SAVE: Called immediately when patient provides data
 */
export const updatePatientDataInternal = internalMutation({
  args: {
    patientId: v.id("patients"),
    updates: v.object({
      name: v.optional(v.string()),
      email: v.optional(v.string()),
      phone: v.optional(v.string()),
      cpf: v.optional(v.string()),
      dateOfBirth: v.optional(v.number()),
      gender: v.optional(v.union(v.literal("male"), v.literal("female"), v.literal("other"))),
      address: v.optional(v.string()),
      city: v.optional(v.string()),
      state: v.optional(v.string()),
      zip: v.optional(v.string()),
      country: v.optional(v.string()),
      notes: v.optional(v.string()),
      tags: v.optional(v.array(v.string())),
      paymentType: v.optional(v.union(v.literal("insurance"), v.literal("private"))),
      insurance: v.optional(v.string()),
    }),
  },
  handler: async (ctx, args) => {
    const patient = await ctx.db.get(args.patientId);
    if (!patient || patient.deletedAt) {
      throw new Error("Patient not found");
    }

    const patch: any = { updatedAt: Date.now() };

    if (args.updates.name !== undefined) {
      patch.name = sanitizeString(args.updates.name, 200);
    }
    if (args.updates.email !== undefined) {
      if (args.updates.email && !isValidEmail(args.updates.email)) {
        throw new Error("Invalid email format");
      }
      patch.email = args.updates.email || undefined;
    }
    if (args.updates.phone !== undefined) {
      if (args.updates.phone) {
        const e164 = formatToE164(args.updates.phone);
        if (!e164 || !isValidE164(e164)) {
          throw new Error("Invalid phone number");
        }
        patch.phone = e164;
      } else {
        patch.phone = undefined;
      }
    }
    if (args.updates.cpf !== undefined) patch.cpf = args.updates.cpf || undefined;
    if (args.updates.dateOfBirth !== undefined) {
      patch.dateOfBirth = args.updates.dateOfBirth;
    }
    if (args.updates.gender !== undefined) patch.gender = args.updates.gender;
    if (args.updates.address !== undefined) patch.address = args.updates.address || undefined;
    if (args.updates.city !== undefined) patch.city = args.updates.city || undefined;
    if (args.updates.state !== undefined) patch.state = args.updates.state || undefined;
    if (args.updates.zip !== undefined) patch.zip = args.updates.zip || undefined;
    if (args.updates.country !== undefined) patch.country = args.updates.country || undefined;
    if (args.updates.notes !== undefined) patch.notes = args.updates.notes || undefined;
    if (args.updates.tags !== undefined) patch.tags = args.updates.tags;
    if (args.updates.paymentType !== undefined) patch.paymentType = args.updates.paymentType;
    if (args.updates.insurance !== undefined) patch.insurance = args.updates.insurance || undefined;

    await ctx.db.patch(args.patientId, patch);
    return { success: true, updatedFields: Object.keys(patch).filter((k) => k !== "updatedAt") };
  },
});
