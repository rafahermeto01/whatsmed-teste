import { v } from "convex/values";

import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "./auth";

export const list = query({
  args: {
    clinicId: v.string(),
    type: v.optional(v.union(v.literal("anamnesis"), v.literal("post_op"), v.literal("return"))),
  },
  handler: async (ctx, args) => {
    // Verify auth
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Unauthorized");

    let q = ctx.db.query("forms").withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId));

    if (args.type) {
      q = ctx.db
        .query("forms")
        .withIndex("by_clinic_type", (q) =>
          q
            .eq("clinicId", args.clinicId)
            .eq("type", args.type as "anamnesis" | "post_op" | "return"),
        );
    }

    const forms = await q.collect();
    return forms.filter((f) => f.isActive);
  },
});

export const get = query({
  args: {
    id: v.id("forms"),
  },
  handler: async (ctx, args) => {
    // Verify auth
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Unauthorized");

    return await ctx.db.get(args.id);
  },
});

export const create = mutation({
  args: {
    clinicId: v.string(),
    title: v.string(),
    description: v.optional(v.string()),
    type: v.union(v.literal("anamnesis"), v.literal("post_op"), v.literal("return")),
    questions: v.array(
      v.object({
        id: v.string(),
        type: v.union(
          v.literal("text"),
          v.literal("textarea"),
          v.literal("number"),
          v.literal("select"),
          v.literal("checkbox"),
          v.literal("date"),
        ),
        label: v.string(),
        options: v.optional(v.array(v.string())),
        required: v.boolean(),
      }),
    ),
  },
  handler: async (ctx, args) => {
    // Verify auth
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Unauthorized");

    const formId = await ctx.db.insert("forms", {
      clinicId: args.clinicId,
      title: args.title,
      description: args.description,
      type: args.type,
      questions: args.questions,
      isActive: true,
      createdAt: Date.now(),
    });

    return formId;
  },
});

export const update = mutation({
  args: {
    id: v.id("forms"),
    title: v.optional(v.string()),
    description: v.optional(v.string()),
    questions: v.optional(
      v.array(
        v.object({
          id: v.string(),
          type: v.union(
            v.literal("text"),
            v.literal("textarea"),
            v.literal("number"),
            v.literal("select"),
            v.literal("checkbox"),
            v.literal("date"),
          ),
          label: v.string(),
          options: v.optional(v.array(v.string())),
          required: v.boolean(),
        }),
      ),
    ),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    // Verify auth
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Unauthorized");

    const { id, ...updates } = args;

    await ctx.db.patch(id, {
      ...updates,
      updatedAt: Date.now(),
    });
  },
});

export const deleteForm = mutation({
  args: {
    id: v.id("forms"),
  },
  handler: async (ctx, args) => {
    // Verify auth
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Unauthorized");

    // Soft delete by setting isActive to false
    await ctx.db.patch(args.id, {
      isActive: false,
      updatedAt: Date.now(),
    });
  },
});
