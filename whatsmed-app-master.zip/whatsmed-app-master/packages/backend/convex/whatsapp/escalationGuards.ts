const HUMAN_HANDOFF_PATTERNS = [
  /\b(falar|conversar)\s+com\s+(um\s+)?(humano|atendente|pessoa|alguem|suporte|equipe)\b/i,
  /\b(quero|preciso|gostaria|posso|pode)\s+(falar|conversar)\s+com\s+(um\s+)?(humano|atendente|pessoa|alguem|suporte|equipe)\b/i,
  /\b(me\s+)?(transfere|transferir|encaminha|encaminhar|passa|passar|conecta|conectar)\s+(para\s+)?(um\s+)?(humano|atendente|pessoa|alguem|suporte|equipe)\b/i,
  /\b(atendimento|suporte)\s+humano\b/i,
  /\b(talk|speak|chat)\s+(to|with)\s+(a\s+)?(human|person|agent|representative|staff|someone)\b/i,
  /\b(i\s+want|i\s+need|can\s+i|could\s+i)\s+(to\s+)?(talk|speak|chat)\s+(to|with)\s+(a\s+)?(human|person|agent|representative|staff|someone)\b/i,
  /\b(transfer|connect|escalate)\s+me\s+(to|with)\s+(a\s+)?(human|person|agent|representative|staff)\b/i,
  /\b(human|live)\s+(agent|support|attendant|representative)\b/i,
];

const EMERGENCY_PATTERNS = [
  /\b(emergencia|emergency)\b/i,
  /\b(socorro|ambulancia|samu)\b/i,
  /\b(nao\s+consigo\s+respirar|falta\s+de\s+ar|dor\s+no\s+peito|desmaiei|convulsao|hemorragia|sangrando\s+muito|tentando\s+me\s+machucar)\b/i,
  /\b(cant\s+breathe|shortness\s+of\s+breath|chest\s+pain|passed\s+out|seizure|bleeding\s+heavily|suicidal|trying\s+to\s+hurt\s+myself)\b/i,
];

function normalizeEscalationText(message: string) {
  return message
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/['’]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function shouldEscalateToHumanSupport(message: string) {
  const normalizedMessage = normalizeEscalationText(message);

  if (!normalizedMessage) {
    return false;
  }

  return [...HUMAN_HANDOFF_PATTERNS, ...EMERGENCY_PATTERNS].some((pattern) =>
    pattern.test(normalizedMessage),
  );
}
