import { v } from "convex/values";

import { shouldEscalateToHumanSupport } from "./escalationGuards.js";
import { internal } from "../_generated/api";
import { internalMutation, internalQuery } from "../_generated/server";

const internalAny = internal as any;

/**
 * Detect help request from patient message
 * Escalation mechanism for patients who need human support (FEXEC-09)
 */
export const detectHelpRequest = internalQuery({
  args: {
    patientMessage: v.string(),
  },
  handler: async (ctx, args) => {
    const hasHelpKeyword = shouldEscalateToHumanSupport(args.patientMessage);

    console.log(
      `[detectHelpRequest] Message checked: "${args.patientMessage.substring(0, 50)}...", detected: ${hasHelpKeyword}`,
    );

    return hasHelpKeyword;
  },
});

/**
 * Escalate chat to human staff
 * Creates escalation message and updates chat status (FEXEC-09)
 */
export const escalateToStaff = internalMutation({
  args: {
    clinicId: v.string(),
    chatId: v.id("chats"),
    patientId: v.optional(v.id("patients")),
    reason: v.string(),
    context: v.string(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    const chat = await ctx.db.get(args.chatId);
    if (!chat) {
      throw new Error("Chat not found for escalation");
    }

    // Idempotency guard: if already escalated recently, do not create duplicate escalation messages
    if (
      chat.needsHumanReview === true &&
      chat.lastEscalatedAt &&
      now - chat.lastEscalatedAt < 5 * 60 * 1000
    ) {
      return chat.escalationMessageId ?? null;
    }

    console.log(`[Escalation] Chat ${args.chatId} escalated to human staff: ${args.reason}`);

    // Create escalation message (direction: "out")
    const escalationMessage =
      "📢 Este chat foi encaminhado para nossa equipe de suporte.\n\n" +
      `Motivo: ${args.reason}\n\n` +
      "Um membro da equipe entrará em contato em breve.";

    const messageId = await ctx.db.insert("messages", {
      chatId: args.chatId,
      clinicId: args.clinicId,
      direction: "out",
      body: escalationMessage,
      type: "text",
      status: "sending",
      sentAt: now,
      createdAt: now,
      patientId: args.patientId ?? undefined,
    } as any);

    // Mark escalation immediately so AI is gated even before outbound send finishes
    await ctx.db.patch(args.chatId, {
      isAiActive: false,
      needsHumanReview: true,
      lastEscalatedAt: now,
      escalationMessageId: messageId,
      escalationReason: args.reason,
      updatedAt: now,
    });

    // Schedule action to send message first, then assign chat to human (no lock)
    await ctx.scheduler.runAfter(0, internalAny.whatsapp.sendEscalationMessageAndAssignHuman, {
      chatId: args.chatId,
      messageId,
      clinicId: args.clinicId,
    });

    console.log(`[Escalation] Created escalation message ${messageId} for chat ${args.chatId}`);

    return messageId;
  },
});

/**
 * Timeout check constants
 * 24 hours = 86400000 ms
 * 18 hours = 64800000 ms (75% of timeout)
 */
const TIMEOUT_MS = 24 * 60 * 60 * 1000; // 24 hours
const NUDGE_MS = 18 * 60 * 60 * 1000; // 18 hours (75% of timeout)

/**
 * Check conversation timeouts and send nudges or mark as abandoned
 * Called by cron job on hourly schedule
 */
export const checkConversationTimeouts = internalMutation({
  args: {},
  handler: async (ctx) => {
    console.log("[Timeout] Starting timeout check...");

    const now = Date.now();

    // Query only chats that are old enough for nudge/abandon checks.
    // We fan out by clinic to leverage index prefix (clinicId, lastActivityAt)
    // and avoid scanning the whole chats table on every run.
    const threshold = now - NUDGE_MS;
    const clinics = await ctx.db.query("clinics").collect();

    const inactiveChats: any[] = [];
    for (const clinic of clinics) {
      const clinicChats = await ctx.db
        .query("chats")
        .withIndex("by_clinic_lastActivity", (q) =>
          q.eq("clinicId", clinic.clinicId).lt("lastActivityAt", threshold),
        )
        .collect();
      inactiveChats.push(...clinicChats);
    }

    let abandonedCount = 0;
    let nudgeCount = 0;

    for (const chat of inactiveChats) {
      // Only check open chats
      if (chat.status !== "open") continue;

      const lastActivityAt = chat.lastActivityAt;
      if (!lastActivityAt) continue; // Skip if never had activity

      const inactiveDuration = now - lastActivityAt;

      // Check if chat should be abandoned
      if (inactiveDuration >= TIMEOUT_MS) {
        await ctx.db.patch(chat._id, {
          status: "abandoned",
          abandonedAt: now,
          updatedAt: now,
        });
        console.log(
          `[Timeout] Chat ${chat._id} marked as abandoned (inactive for ${Math.floor(inactiveDuration / 1000 / 60)} minutes)`,
        );
        abandonedCount++;
      }
      // Check if chat needs nudge (hasn't been nudged yet and is at 75% threshold)
      else if (!chat.timeoutSentAt && inactiveDuration >= NUDGE_MS) {
        // Send nudge message
        const messageId = await ctx.runMutation(internalAny.whatsapp.timeout.sendNudgeMessage, {
          chatId: chat._id,
        });

        if (messageId) {
          // Mark nudge as sent
          await ctx.db.patch(chat._id, {
            timeoutSentAt: now,
            updatedAt: now,
          });
          console.log(
            `[Timeout] Nudge sent for chat ${chat._id} (inactive for ${Math.floor(inactiveDuration / 1000 / 60)} minutes)`,
          );
          nudgeCount++;
        }
      }
    }

    console.log(`[Timeout] Check complete: ${abandonedCount} abandoned, ${nudgeCount} nudges sent`);
  },
});

/**
 * Send nudge message to patient
 * Default message: "Ainda está aí? Posso continuar ajudando com o que estávamos conversando? Se preferir, posso encaminhar para alguém da nossa equipe."
 */
export const sendNudgeMessage = internalMutation({
  args: {
    chatId: v.id("chats"),
  },
  handler: async (ctx, args) => {
    const chat = await ctx.db.get(args.chatId);
    if (!chat) {
      console.error(`[Timeout] Chat ${args.chatId} not found for nudge`);
      return null;
    }

    const nudgeMessage =
      "Ainda está aí? Posso continuar ajudando com o que estávamos conversando? Se preferir, posso encaminhar para alguém da nossa equipe.";

    // Store nudge message in messages table (direction: "out")
    const messageId = await ctx.db.insert("messages", {
      clinicId: chat.clinicId,
      chatId: args.chatId,
      direction: "out",
      type: "text",
      body: nudgeMessage,
      status: "sending",
      sentAt: Date.now(),
      createdAt: Date.now(),
    });

    // Schedule sending via WhatsApp provider
    await ctx.scheduler.runAfter(0, internalAny.whatsapp.sendTextAction, {
      chatId: args.chatId,
      text: nudgeMessage,
      messageId: messageId,
    });

    console.log(`[Timeout] Nudge message ${messageId} created for chat ${args.chatId}`);

    return messageId;
  },
});
