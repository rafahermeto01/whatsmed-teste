import { v } from "convex/values";

import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "./auth";
import { generateSecureToken } from "./lib/security";

// Admin/Doctor: Assign a form to a patient
export const assignToPatient = mutation({
  args: {
    clinicId: v.string(),
    patientId: v.id("patients"),
    appointmentId: v.optional(v.id("appointments")),
    formId: v.id("forms"),
  },
  handler: async (ctx, args) => {
    // Verify auth
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Unauthorized");

    // Check if form exists
    const form = await ctx.db.get(args.formId);
    if (!form || !form.isActive) throw new Error("Form not found or inactive");

    // Generate a secure token for public access
    const token = generateSecureToken();

    const patientFormId = await ctx.db.insert("patientForms", {
      clinicId: args.clinicId,
      patientId: args.patientId,
      appointmentId: args.appointmentId,
      formId: args.formId,
      status: "pending",
      token,
      createdAt: Date.now(),
    });

    return patientFormId;
  },
});

// Admin/Doctor: Get all forms for a patient
export const getByPatient = query({
  args: {
    clinicId: v.string(),
    patientId: v.id("patients"),
  },
  handler: async (ctx, args) => {
    // Verify auth
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Unauthorized");

    const forms = await ctx.db
      .query("patientForms")
      .withIndex("by_patient_status", (q) => q.eq("patientId", args.patientId))
      .collect();

    // Enrich with form details
    const enriched = await Promise.all(
      forms.map(async (pf) => {
        const form = await ctx.db.get(pf.formId);
        return {
          ...pf,
          formTitle: form?.title,
          formType: form?.type,
        };
      }),
    );

    return enriched;
  },
});

// Public: Get form details by token (for patient portal)
export const getByToken = query({
  args: {
    token: v.string(),
  },
  handler: async (ctx, args) => {
    const patientForm = await ctx.db
      .query("patientForms")
      .withIndex("by_token", (q) => q.eq("token", args.token))
      .first();

    if (!patientForm) throw new Error("Invalid token");

    const form = await ctx.db.get(patientForm.formId);
    if (!form) throw new Error("Form definition not found");

    return {
      patientForm,
      form,
    };
  },
});

// Public: Submit a form
export const submit = mutation({
  args: {
    token: v.string(),
    submissionData: v.any(),
  },
  handler: async (ctx, args) => {
    const patientForm = await ctx.db
      .query("patientForms")
      .withIndex("by_token", (q) => q.eq("token", args.token))
      .first();

    if (!patientForm) throw new Error("Invalid token");
    if (patientForm.status === "completed") throw new Error("Form already submitted");

    await ctx.db.patch(patientForm._id, {
      submissionData: args.submissionData,
      status: "completed",
      submittedAt: Date.now(),
      updatedAt: Date.now(),
    });

    return { success: true };
  },
});

// Public: Get pending forms for a patient (via check-in session)
// This is used in the Check-in flow where we have a check-in token,
// and we want to find other forms linked to the same patient/appointment.
export const getPendingForCheckin = query({
  args: {
    patientId: v.id("patients"),
    appointmentId: v.id("appointments"),
  },
  handler: async (ctx, args) => {
    const forms = await ctx.db
      .query("patientForms")
      .withIndex("by_patient_status", (q) =>
        q.eq("patientId", args.patientId).eq("status", "pending"),
      )
      .filter((q) => q.eq(q.field("appointmentId"), args.appointmentId))
      .collect();

    // Enrich with form details
    const enriched = await Promise.all(
      forms.map(async (pf) => {
        const form = await ctx.db.get(pf.formId);
        return {
          ...pf,
          formTitle: form?.title,
          formDescription: form?.description,
          formType: form?.type,
          formQuestions: form?.questions,
        };
      }),
    );

    return enriched;
  },
});
