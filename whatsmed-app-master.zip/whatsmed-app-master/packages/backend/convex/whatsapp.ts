"use node";

import { v } from "convex/values";

import { internal } from "./_generated/api";
import { internalAction } from "./_generated/server";
import { sanitizePatientFacingResponse } from "./lib/patientResponse";
import { WhatsAppProviderFactory } from "./lib/whatsapp/factory";

const internalAny = internal as any;

async function persistSuccessfulSend(
  ctx: any,
  args: {
    messageId: any;
    tracking?: {
      clinicId: string;
      appointmentId: any;
      markLegacyReminderAt?: boolean;
      automationKind?:
        | "confirmationRequest"
        | "appointmentReminder"
        | "rescheduleOptions"
        | "rescheduleConfirmation"
        | "confirmationReply"
        | "cancellationConfirmation";
      reminderType?:
        | "appointmentConfirmation"
        | "sevenDay"
        | "twentyFourHour"
        | "oneHour"
        | "postConsultation"
        | "noShowRecovery";
    };
  },
) {
  await ctx.runMutation(internalAny.whatsappQueries.updateMessageStatusInternal, {
    messageId: args.messageId,
    status: "sent",
  });

  if (!args.tracking) {
    return;
  }

  if (args.tracking.reminderType) {
    await ctx.runMutation(internalAny.automationInternal.upsertAppointmentReminderState, {
      clinicId: args.tracking.clinicId,
      appointmentId: args.tracking.appointmentId,
      reminderType: args.tracking.reminderType,
      status: "sent",
      responseStatus:
        args.tracking.automationKind === "confirmationRequest" ? "awaiting" : undefined,
      channels: ["whatsapp"],
      sentAt: Date.now(),
    });
  }

  if (args.tracking.markLegacyReminderAt) {
    await ctx.runMutation(internalAny.appointmentsInternal.markReminderSent, {
      id: args.tracking.appointmentId,
      reminderAt: Date.now(),
    });
  }
}

export const persistDeliverySuccessAction = internalAction({
  args: {
    messageId: v.id("messages"),
    tracking: v.optional(
      v.object({
        clinicId: v.string(),
        appointmentId: v.id("appointments"),
        markLegacyReminderAt: v.optional(v.boolean()),
        automationKind: v.optional(
          v.union(
            v.literal("confirmationRequest"),
            v.literal("appointmentReminder"),
            v.literal("rescheduleOptions"),
            v.literal("rescheduleConfirmation"),
            v.literal("confirmationReply"),
            v.literal("cancellationConfirmation"),
          ),
        ),
        reminderType: v.optional(
          v.union(
            v.literal("appointmentConfirmation"),
            v.literal("sevenDay"),
            v.literal("twentyFourHour"),
            v.literal("oneHour"),
            v.literal("postConsultation"),
            v.literal("noShowRecovery"),
          ),
        ),
      }),
    ),
  },
  handler: async (ctx, args) => {
    await persistSuccessfulSend(ctx, args);
  },
});

/**
 * The REAL action that sends to the configured Provider
 */
export const sendTextAction = internalAction({
  args: {
    chatId: v.id("chats"),
    text: v.string(),
    messageId: v.id("messages"),
    attempt: v.optional(v.number()),
    tracking: v.optional(
      v.object({
        clinicId: v.string(),
        appointmentId: v.id("appointments"),
        markLegacyReminderAt: v.optional(v.boolean()),
        automationKind: v.optional(
          v.union(
            v.literal("confirmationRequest"),
            v.literal("appointmentReminder"),
            v.literal("rescheduleOptions"),
            v.literal("rescheduleConfirmation"),
            v.literal("confirmationReply"),
            v.literal("cancellationConfirmation"),
          ),
        ),
        reminderType: v.optional(
          v.union(
            v.literal("appointmentConfirmation"),
            v.literal("sevenDay"),
            v.literal("twentyFourHour"),
            v.literal("oneHour"),
            v.literal("postConsultation"),
            v.literal("noShowRecovery"),
          ),
        ),
      }),
    ),
  },
  handler: async (ctx, args) => {
    const attempt = args.attempt ?? 1;
    let delivered = false;

    try {
      // 1. Get chat to get whatsappChatId
      const chat = await ctx.runQuery(internalAny.whatsappQueries.getChatInternal, {
        chatId: args.chatId,
      });
      if (!chat) throw new Error("Chat not found");

      // 2. Get instance name and config
      const integration = await ctx.runQuery(internalAny.integrations.getWhatsAppInstanceInternal, {
        clinicId: chat.clinicId,
      });
      if (!integration || integration.status !== "connected") {
        throw new Error("WhatsApp instance not connected");
      }

      // 3. Instantiate Provider
      const provider = WhatsAppProviderFactory.getProvider({
        provider: integration.provider,
        instanceName: integration.instanceName,
        evolutionApiKey: integration.apikey,
        metaPhoneNumberId: integration.metaPhoneNumberId,
        metaWabaId: integration.metaWabaId,
        metaAccessToken: integration.metaAccessToken,
      });

      // Extract number from whatsappChatId (remove suffix if needed)
      const number = chat.whatsappChatId.split("@")[0];

      // 4. Send
      await provider.sendText({ to: number, text: args.text });
      delivered = true;

      try {
        await persistSuccessfulSend(ctx, {
          messageId: args.messageId,
          tracking: args.tracking,
        });
      } catch (stateError) {
        console.error("[sendTextAction] Failed to persist delivery status:", stateError);
        await ctx.scheduler.runAfter(0, internalAny.whatsapp.persistDeliverySuccessAction, {
          messageId: args.messageId,
          tracking: args.tracking,
        });
      }
    } catch (error) {
      if (delivered) {
        console.error(
          "[sendTextAction] Delivery succeeded but persistence fallback failed:",
          error,
        );
        return;
      }

      await ctx.runMutation(internalAny.whatsappQueries.updateMessageStatusInternal, {
        messageId: args.messageId,
        status: "failed",
      });

      if (args.tracking?.reminderType) {
        await ctx.runMutation(internalAny.automationInternal.upsertAppointmentReminderState, {
          clinicId: args.tracking.clinicId,
          appointmentId: args.tracking.appointmentId,
          reminderType: args.tracking.reminderType,
          status: "failed",
          channels: ["whatsapp"],
          lastError: error instanceof Error ? error.message : String(error),
        });

        if (attempt < 3) {
          const retryDelayMs = Math.min(5 * 60 * 1000 * attempt, 30 * 60 * 1000);
          await ctx.scheduler.runAfter(retryDelayMs, internalAny.whatsapp.sendTextAction, {
            chatId: args.chatId,
            text: args.text,
            messageId: args.messageId,
            attempt: attempt + 1,
            tracking: args.tracking,
          });
        }
      }

      throw error;
    }
  },
});

/**
 * Send escalation message to WhatsApp, then assign chat to human (isAiActive: false, needsHumanReview: true).
 * Message is sent first; chat state is updated only after send completes. Does not lock the chat.
 */
export const sendEscalationMessageAndAssignHuman = internalAction({
  args: {
    chatId: v.id("chats"),
    messageId: v.id("messages"),
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const message = await ctx.runQuery(internalAny.whatsappInternal.getMessage, {
      id: args.messageId,
    });
    if (!message?.body) throw new Error("Escalation message not found");

    const chat = await ctx.runQuery(internalAny.whatsappQueries.getChatInternal, {
      chatId: args.chatId,
    });
    if (!chat) throw new Error("Chat not found");

    const integration = await ctx.runQuery(internalAny.integrations.getWhatsAppInstanceInternal, {
      clinicId: args.clinicId,
    });
    if (!integration) throw new Error("WhatsApp instance not connected");

    const provider = WhatsAppProviderFactory.getProvider({
      provider: integration.provider,
      instanceName: integration.instanceName,
      evolutionApiKey: integration.apikey,
      metaPhoneNumberId: integration.metaPhoneNumberId,
      metaWabaId: integration.metaWabaId,
      metaAccessToken: integration.metaAccessToken,
    });

    const number = chat.whatsappChatId.split("@")[0];

    try {
      await provider.sendText({ to: number, text: message.body });
      await ctx.runMutation(internalAny.whatsappQueries.updateMessageStatusInternal, {
        messageId: args.messageId,
        status: "sent",
      });
    } catch (err) {
      console.error("[sendEscalationMessageAndAssignHuman] Send failed:", err);
      await ctx.runMutation(internalAny.whatsappQueries.updateMessageStatusInternal, {
        messageId: args.messageId,
        status: "failed",
      });
    }

    // Assign chat to human even if send failed so the toggle reflects escalation
    await ctx.runMutation(internalAny.whatsappQueries.assignChatToHuman, {
      chatId: args.chatId,
    });
  },
});

/**
 * Action to send AI response
 * Stores message in DB (without disabling AI) and sends via Provider
 */
export const sendAiResponseAction = internalAction({
  args: {
    chatId: v.id("chats"),
    text: v.string(),
    replyToMessageId: v.optional(v.id("messages")),
    messageId: v.optional(v.id("messages")),
    skipProviderSend: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const safeText = sanitizePatientFacingResponse(args.text) || args.text;
    console.log("[sendAiResponseAction] Sending AI response:", safeText.substring(0, 50));

    const currentChat = await ctx.runQuery(internalAny.whatsappQueries.getChatInternal, {
      chatId: args.chatId,
    });
    if (
      !currentChat ||
      currentChat.status !== "open" ||
      currentChat.isAiActive === false ||
      currentChat.needsHumanReview === true
    ) {
      console.warn("[sendAiResponseAction] Skipping send due to chat state", {
        status: currentChat?.status,
        isAiActive: currentChat?.isAiActive,
        needsHumanReview: currentChat?.needsHumanReview,
      });
      return;
    }

    // 1. Store message in DB (first attempt) or reuse existing message (retries)
    const messageId =
      args.messageId ||
      (await ctx.runMutation(internalAny.whatsappQueries.storeAiMessage, {
        chatId: args.chatId,
        text: safeText,
        replyToMessageId: args.replyToMessageId,
      }));

    if (args.skipProviderSend) {
      await ctx.runMutation(internalAny.whatsappQueries.updateMessageStatusInternal, {
        messageId,
        status: "sent",
      });
      return;
    }

    try {
      // 2. Get chat to get whatsappChatId
      const chat = await ctx.runQuery(internalAny.whatsappQueries.getChatInternal, {
        chatId: args.chatId,
      });
      if (!chat) throw new Error("Chat not found");

      // 3. Get instance name and config
      const integration = await ctx.runQuery(internalAny.integrations.getWhatsAppInstanceInternal, {
        clinicId: chat.clinicId,
      });
      if (!integration) {
        throw new Error("WhatsApp instance not connected");
      }

      // 4. Instantiate Provider
      const provider = WhatsAppProviderFactory.getProvider({
        provider: integration.provider,
        instanceName: integration.instanceName,
        evolutionApiKey: integration.apikey,
        metaPhoneNumberId: integration.metaPhoneNumberId,
        metaWabaId: integration.metaWabaId,
        metaAccessToken: integration.metaAccessToken,
      });

      // Extract number from whatsappChatId (remove suffix if needed)
      const number = chat.whatsappChatId.split("@")[0];

      // 5. Send
      // Note: We're not using reply context in the actual send yet because the Provider interface might need updates
      // But we stored the context in DB
      await provider.sendText({ to: number, text: safeText });

      // 6. Update message status
      await ctx.runMutation(internalAny.whatsappQueries.updateMessageStatusInternal, {
        messageId: messageId,
        status: "sent",
      });

      console.log("[sendAiResponseAction] AI response sent successfully");
    } catch (error) {
      console.error("[sendAiResponseAction] Failed to send AI response:", error);

      // Update status to failed
      await ctx.runMutation(internalAny.whatsappQueries.updateMessageStatusInternal, {
        messageId: messageId,
        status: "failed",
      });

      const wrapped = error instanceof Error ? error : new Error(String(error));
      (wrapped as any).messageId = messageId;
      throw wrapped;
    }
  },
});

/**
 * Safe wrapper for delayed/scheduled AI sends.
 * Re-checks chat state right before sending and then delegates to sendAiResponseAction.
 */
export const sendAiResponseIfAllowedAction = internalAction({
  args: {
    chatId: v.id("chats"),
    text: v.string(),
    replyToMessageId: v.optional(v.id("messages")),
    attempt: v.optional(v.number()),
    messageId: v.optional(v.id("messages")),
    skipProviderSend: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const attempt = args.attempt ?? 1;
    const chat = await ctx.runQuery(internalAny.whatsappQueries.getChatInternal, {
      chatId: args.chatId,
    });

    if (!chat || chat.status !== "open" || chat.isAiActive === false || chat.needsHumanReview) {
      return;
    }

    try {
      await ctx.runAction(internalAny.whatsapp.sendAiResponseAction, {
        chatId: args.chatId,
        text: args.text,
        replyToMessageId: args.replyToMessageId,
        messageId: args.messageId,
        skipProviderSend: args.skipProviderSend,
      });
    } catch (error) {
      const messageId = (error as any)?.messageId || args.messageId;
      if (attempt < 3) {
        const delayMs = Math.min(1000 * 2 ** attempt, 10000);
        await ctx.scheduler.runAfter(delayMs, internalAny.whatsapp.sendAiResponseIfAllowedAction, {
          chatId: args.chatId,
          text: args.text,
          replyToMessageId: args.replyToMessageId,
          attempt: attempt + 1,
          messageId,
          skipProviderSend: args.skipProviderSend,
        });
        return;
      }
      throw error;
    }
  },
});
