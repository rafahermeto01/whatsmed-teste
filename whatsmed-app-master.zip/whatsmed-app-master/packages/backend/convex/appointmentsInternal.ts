import { v } from "convex/values";

import { internalMutation } from "./_generated/server";

/**
 * Mark appointment as having received a reminder
 * Internal mutation for idempotency
 */
export const markReminderSent = internalMutation({
  args: {
    id: v.id("appointments"),
    reminderAt: v.number(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.id, {
      reminderAt: args.reminderAt,
    });
  },
});

/**
 * Mark appointment with NPS reminder sent
 * Internal mutation for post-consultation reminders
 */
export const markNpsSent = internalMutation({
  args: {
    id: v.id("appointments"),
    npsSentAt: v.number(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.id, {
      npsSentAt: args.npsSentAt,
    });
  },
});
