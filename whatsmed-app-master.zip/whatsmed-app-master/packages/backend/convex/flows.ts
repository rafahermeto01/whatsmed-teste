import { v } from "convex/values";

import { mutation, query } from "./_generated/server";
import { unauthorized, forbidden, notFound } from "./lib/errors";

import type { MutationCtx } from "./_generated/server";

// Re-export version management functions
export * from "./flows/versions";

// Re-export audit logging functions
export * from "./flows/audit";

// Re-export variable sanitization utilities
export * from "./flows/sanitization";

// Internal imports
import { logFlowOperation } from "./flows/audit";

import type { FlowAuditOperation } from "./flows/audit";

/**
 * Flows Module
 *
 * This module provides Convex functions for flow management, including:
 * - Flow CRUD operations (create, read, update, delete, list)
 * - Flow version management (create immutable versions, track active version)
 * - Flow execution tracking (start, resume, complete, cancel flows)
 *
 * Flow Data Model:
 * - flows: Parent flow records with metadata and active version reference
 * - flowVersions: Immutable flow definitions with nodes, connections, and variables
 * - flowExecutions: Runtime execution instances pinned to specific versions
 *
 * Multi-Tenant Isolation:
 * All operations are scoped by clinicId to ensure tenant data isolation.
 *
 * Access Control:
 * Role-based permissions (admin, staff, doctor, viewer) are enforced
 * in both API layer (middleware) and database layer (Convex rules).
 */

// Types exported for frontend use
export type Flow = {
  _id: string;
  clinicId: string;
  name: string;
  description?: string;
  status: "draft" | "active" | "archived";
  activeVersionId?: string;
  createdBy: string;
  createdAt: number;
  updatedAt?: number;
};

export type FlowVersion = {
  _id: string;
  clinicId: string;
  flowId: string;
  versionNumber: number;
  nodes: Array<{
    id: string;
    type: string;
    data: unknown;
    position: { x: number; y: number };
  }>;
  connections: Array<{
    id: string;
    source: string;
    target: string;
    sourceHandle?: string;
    targetHandle?: string;
  }>;
  variables: Array<{
    name: string;
    type: "string" | "number" | "boolean";
    defaultValue?: unknown;
    description?: string;
  }>;
  createdBy: string;
  createdAt: number;
};

export type FlowExecution = {
  _id: string;
  clinicId: string;
  flowId: string;
  flowVersionId: string;
  chatId?: string;
  patientId?: string;
  currentNodeId?: string;
  nodeContext?: {
    variables: Record<string, unknown>;
    history: Array<{
      nodeId: string;
      timestamp: number;
      result?: unknown;
    }>;
  };
  status: "in_progress" | "completed" | "cancelled" | "error";
  startedAt: number;
  completedAt?: number;
  errorMessage?: string;
};

// Flow CRUD operations - Plan 01-02
export const createFlow = mutation({
  args: {
    name: v.string(),
    description: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw unauthorized("Unauthorized");
    }

    const userId = identity.subject;

    // Get user to get clinicId and role
    const user = await ctx.db
      .query("users")
      .filter((q) => q.eq(q.field("authUserId"), userId))
      .first();

    if (!user || !user.clinicId) {
      throw unauthorized("User not found or has no clinic");
    }

    if (!["admin", "staff", "super_admin"].includes(user.role)) {
      throw forbidden("Insufficient permissions");
    }

    const flowId = await ctx.db.insert("flows", {
      clinicId: user.clinicId,
      name: args.name,
      description: args.description,
      status: "draft",
      createdBy: user.name,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });

    // Log the operation
    await logFlowOperation(
      ctx,
      "flow.create" as FlowAuditOperation,
      user.clinicId,
      flowId,
      userId,
      user.email,
      {
        flowName: args.name,
        description: args.description,
      },
    );

    return flowId;
  },
});

export const listFlows = query({
  args: {
    status: v.optional(v.union(v.literal("draft"), v.literal("active"), v.literal("archived"))),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      return [];
    }

    const userId = identity.subject;

    // Get user to get clinicId
    const user = await ctx.db
      .query("users")
      .filter((q) => q.eq(q.field("authUserId"), userId))
      .first();

    if (!user || !user.clinicId) {
      return [];
    }

    // Build query with optional status filter
    let query = ctx.db
      .query("flows")
      .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", user.clinicId));

    if (args.status) {
      query = query.filter((q) => q.eq(q.field("status"), args.status));
    }

    const flows = await query.collect();

    return flows.map((flow) => ({
      id: flow._id,
      name: flow.name,
      description: flow.description,
      status: flow.status,
      createdAt: flow.createdAt,
      updatedAt: flow.updatedAt,
      createdBy: flow.createdBy,
      activeVersionId: flow.activeVersionId,
      versionCount: flow.activeVersionId ? 1 : 0, // Will be computed properly in next plan
    }));
  },
});

export const getById = query({
  args: {
    id: v.id("flows"),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw unauthorized("Unauthorized");
    }

    const userId = identity.subject;

    const flow = await ctx.db.get(args.id);
    if (!flow) {
      throw notFound("Flow not found");
    }

    // Verify user belongs to flow's clinic
    const user = await ctx.db
      .query("users")
      .withIndex("by_clinic", (q) => q.eq("clinicId", flow.clinicId))
      .filter((q) => q.eq(q.field("authUserId"), userId))
      .first();

    if (!user || !user.isActive || user.deletedAt) {
      throw unauthorized("Unauthorized");
    }

    return flow;
  },
});

export const updateFlow = mutation({
  args: {
    id: v.id("flows"),
    name: v.optional(v.string()),
    description: v.optional(v.string()),
    status: v.optional(v.union(v.literal("draft"), v.literal("active"), v.literal("archived"))),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw unauthorized("Unauthorized");
    }

    const userId = identity.subject;

    const flow = await ctx.db.get(args.id);
    if (!flow) {
      throw notFound("Flow not found");
    }

    // Get user to check role
    const user = await ctx.db
      .query("users")
      .withIndex("by_clinic", (q) => q.eq("clinicId", flow.clinicId))
      .filter((q) => q.eq(q.field("authUserId"), userId))
      .first();

    if (!user || !user.isActive || user.deletedAt) {
      throw unauthorized("Unauthorized");
    }

    // Check role for status changes (admin only)
    if (args.status) {
      if (!["admin", "super_admin"].includes(user.role)) {
        throw forbidden("Only admins can change flow status");
      }
    } else {
      // For non-status changes, admin/staff can edit
      if (!["admin", "staff", "super_admin"].includes(user.role)) {
        throw forbidden("Insufficient permissions");
      }
    }

    // Update flow
    const updates: any = { updatedAt: Date.now() };
    if (args.name !== undefined) updates.name = args.name;
    if (args.description !== undefined) updates.description = args.description;
    if (args.status !== undefined) updates.status = args.status;

    await ctx.db.patch(args.id, updates);

    // Log operation
    const changedFields: string[] = [];
    if (args.name !== undefined) changedFields.push("name");
    if (args.description !== undefined) changedFields.push("description");
    if (args.status !== undefined) changedFields.push("status");

    await logFlowOperation(
      ctx,
      "flow.update" as FlowAuditOperation,
      flow.clinicId,
      args.id.toString(),
      userId,
      undefined,
      { changedFields, updates },
    );

    return { success: true };
  },
});

export const deleteFlow = mutation({
  args: {
    id: v.id("flows"),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw unauthorized("Unauthorized");
    }

    const userId = identity.subject;

    const flow = await ctx.db.get(args.id);
    if (!flow) {
      throw notFound("Flow not found");
    }

    // Get user to check role
    const user = await ctx.db
      .query("users")
      .withIndex("by_clinic", (q) => q.eq("clinicId", flow.clinicId))
      .filter((q) => q.eq(q.field("authUserId"), userId))
      .first();

    if (!user || !user.isActive || user.deletedAt) {
      throw unauthorized("Unauthorized");
    }

    if (!["admin", "staff", "super_admin"].includes(user.role)) {
      throw forbidden("Insufficient permissions");
    }

    // Log operation (before deletion so we have data)
    await logFlowOperation(
      ctx,
      "flow.delete" as FlowAuditOperation,
      flow.clinicId,
      args.id.toString(),
      userId,
      undefined,
      { flowName: flow.name, flowStatus: flow.status },
    );

    // Delete flow
    await ctx.db.delete(args.id);

    return { success: true };
  },
});

// Re-export formatters for convenient access
export {
  formatFlowForLLM,
  createFlowInstructions,
  formatFlowForSystemPrompt,
} from "./flows/formatters";

// Re-export clinic flow functions
export { getClinicAiFlow, createClinicAiFlow, saveClinicAiFlow } from "./flows/clinicFlow";

// Re-export tool mappings
export { getToolMappingsFromFlow } from "./flows/toolIntegration";

/**
 * Simple test query to verify Convex registration
 */
export const testQuery = query({
  args: {},
  handler: async (ctx) => {
    return { test: true, timestamp: Date.now() };
  },
});

/**
 * Get formatted flow instructions for AI consumption
 *
 * This query combines flow loading and formatting into a single call,
 * providing a clean API for WhatsApp handler to get flow instructions.
 *
 * @param clinicId - Clinic Id - Clinic identifier for multi-tenant isolation
 * @returns Object with flowId, flowName, and formatted instructions, or null if no active flow
 *
 * Usage: Called by WhatsApp handler to get flow instructions in one call (AIINT-01)
 */
export const getFormattedFlowForAI = query({
  args: {
    clinicId: v.string(),
  },
  handler: async (
    ctx,
    args,
  ): Promise<{ flowId: string; flowName: string; instructions: string } | null> => {
    // First, try to get the default flow from clinicSettings
    const clinics = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q: any) => q.eq("clinicId", args.clinicId))
      .collect();

    let activeFlow: any = null;

    if (clinics.length > 0) {
      const clinic = clinics[0];
      const clinicSettings = await ctx.db
        .query("clinicSettings")
        .withIndex("by_clinic", (q: any) => q.eq("clinicId", clinic._id))
        .first();

      if (clinicSettings?.defaultFlowId) {
        const defaultFlow = await ctx.db.get(clinicSettings.defaultFlowId);
        if (defaultFlow && defaultFlow.clinicId === args.clinicId && defaultFlow.activeVersionId) {
          activeFlow = defaultFlow;
        }
      }
    }

    // Fallback: Query flows by clinicId and status="active"
    if (!activeFlow) {
      const flows = await ctx.db
        .query("flows")
        .withIndex("by_clinic_status", (q: any) =>
          q.eq("clinicId", args.clinicId).eq("status", "active"),
        )
        .collect();

      for (const flow of flows) {
        if (flow.activeVersionId) {
          activeFlow = flow;
          break;
        }
      }
    }

    if (!activeFlow || !activeFlow.activeVersionId) {
      return null;
    }

    // Load the active flow version
    const flowVersion = await ctx.db.get(activeFlow.activeVersionId);

    if (!flowVersion) {
      return null;
    }

    // Import and use formatter
    const { formatFlowForLLM } = await import("./flows/formatters");

    // Format instructions for AI
    const instructions = formatFlowForLLM(flowVersion as any);

    return {
      flowId: activeFlow._id,
      flowName: activeFlow.name,
      instructions,
    };
  },
});

// TODO: Implement version management in plan 01-03
// export const createFlowVersion = mutation(...)
// export const activateFlowVersion = mutation(...)

// TODO: Implement execution functions in plan 01-07 (or later phase)
// export const startFlowExecution = mutation(...)
// export const updateFlowExecution = mutation(...)
// export const completeFlowExecution = mutation(...)
// export const cancelFlowExecution = mutation(...)
