import { v } from "convex/values";

import { internal } from "./_generated/api";
import {
  internalAction,
  internalMutation,
  mutation,
  action,
  query,
  internalQuery,
} from "./_generated/server";
import { badRequest, unauthorized } from "./lib/errors";
import { EvolutionClient } from "./lib/evolution";
import { checkFeatureAccess } from "./lib/planEnforcement";
import { generateSecureToken } from "./lib/security";

const internalAny = internal as any;

const evolution = new EvolutionClient();

const APPROVE_UPDATE_ALLOWED_ROLES = new Set(["admin", "staff", "super_admin"]);
const PATIENT_PROFILE_ALLOWED_FIELDS = [
  "name",
  "email",
  "phone",
  "cpf",
  "dateOfBirth",
  "gender",
  "address",
  "city",
  "state",
  "zip",
  "country",
  "paymentType",
  "insurance",
  "notes",
] as const;

// ==================== CHECK-IN SESSION MANAGEMENT ====================

// Create a check-in session (e.g., from WhatsApp link generation)
export const createCheckinSession = mutation({
  args: {
    clinicId: v.string(),
    appointmentId: v.id("appointments"),
    patientId: v.id("patients"),
  },
  handler: async (ctx, args) => {
    const { clinicId, appointmentId, patientId } = args;
    const now = Date.now();

    // Check if there's already an active session
    // Index is ["patientId", "appointmentId"]
    const existing = await ctx.db
      .query("checkinSessions")
      .withIndex("by_patient_appointment", (q: any) =>
        q.eq("patientId", patientId).eq("appointmentId", appointmentId),
      )
      .first();

    if (existing && existing.status === "in_progress" && existing.expiresAt > now) {
      return existing;
    }

    // Generate secure random token
    const token = generateSecureToken();
    const expiresAt = now + 24 * 60 * 60 * 1000; // 24 hours expiry

    const id = await ctx.db.insert("checkinSessions", {
      clinicId,
      appointmentId,
      patientId,
      token,
      status: "in_progress",
      expiresAt,
      createdAt: now,
      updatedAt: now,
    });

    return await ctx.db.get(id);
  },
});

// Validate check-in token (for web flow)
export const validateCheckinToken = mutation({
  args: {
    token: v.string(),
  },
  handler: async (ctx, args) => {
    const { token } = args;
    const now = Date.now();

    const session = await ctx.db
      .query("checkinSessions")
      .withIndex("by_token", (q: any) => q.eq("token", token))
      .first();

    if (!session) {
      throw new Error("Sessão inválida");
    }

    if (session.expiresAt < now) {
      throw new Error("Sessão expirada");
    }

    // Return session details with patient and appointment info
    const patient = await ctx.db.get(session.patientId);
    const appointment = await ctx.db.get(session.appointmentId);

    return {
      session,
      patient,
      appointment,
    };
  },
});

export const getCheckinSession = query({
  args: {
    token: v.string(),
  },
  handler: async (ctx, args) => {
    const session = await ctx.db
      .query("checkinSessions")
      .withIndex("by_token", (q: any) => q.eq("token", args.token))
      .first();

    if (!session) return null;

    if (session.expiresAt < Date.now()) {
      return { session, error: "expired" };
    }

    const patient = await ctx.db.get(session.patientId);
    const appointment = await ctx.db.get(session.appointmentId);

    // Try to find clinic details
    // We don't have a direct query for clinic by string ID in common helpers, so manual query
    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q: any) => q.eq("clinicId", session.clinicId))
      .first();

    return { session, patient, appointment, clinic };
  },
});

export const getPatientCheckinStatus = query({
  args: {
    patientId: v.id("patients"),
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    // Find active session
    const session = await ctx.db
      .query("checkinSessions")
      .withIndex("by_clinic_status", (q: any) =>
        q.eq("clinicId", args.clinicId).eq("status", "in_progress"),
      )
      .filter((q: any) => q.eq(q.field("patientId"), args.patientId))
      .first();

    if (session && session.expiresAt > Date.now()) {
      return { hasActiveCheckin: true, session };
    }
    return { hasActiveCheckin: false };
  },
});

// ==================== ANAMNESIS & DATA UPDATES ====================

export const submitAnamnesisData = mutation({
  args: {
    clinicId: v.string(),
    patientId: v.id("patients"),
    checkinSessionId: v.optional(v.id("checkinSessions")),
    data: v.any(), // Flexible schema for anamnesis form data
  },
  handler: async (ctx, args) => {
    const { clinicId, patientId, checkinSessionId, data } = args;

    // Create patient data update request
    // Mapping to schema: field="anamnesis", value=data, source="checkin"
    const updateId = await ctx.db.insert("patientDataUpdates", {
      clinicId,
      patientId,
      checkinSessionId,
      field: "anamnesis",
      value: data,
      source: "checkin",
      createdAt: Date.now(),
    });

    return updateId;
  },
});

export const getPendingPatientUpdates = query({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    // Query by clinic and filter for pending (approved === undefined)
    const updates = await ctx.db
      .query("patientDataUpdates")
      .withIndex("by_clinic_approved", (q: any) => q.eq("clinicId", args.clinicId))
      .filter((q) => q.eq(q.field("approved"), undefined))
      .collect();

    // Enrich with patient name
    const enriched = await Promise.all(
      updates.map(async (u) => {
        const patient = await ctx.db.get(u.patientId);
        return { ...u, patientName: patient?.name || "Unknown" };
      }),
    );

    return enriched;
  },
});

export const approvePatientDataUpdate = mutation({
  args: {
    updateId: v.id("patientDataUpdates"),
    approved: v.boolean(),
  },
  handler: async (ctx, args) => {
    const { updateId, approved } = args;

    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw unauthorized();

    const update = await ctx.db.get(updateId);
    if (!update) throw new Error("Update not found");

    const member = await ctx.db
      .query("clinicMembers")
      .withIndex("by_user_clinic", (q) =>
        q.eq("userId", identity.subject).eq("clinicId", update.clinicId),
      )
      .first();

    if (!member || !APPROVE_UPDATE_ALLOWED_ROLES.has(member.role)) {
      throw unauthorized("Only clinic staff can approve patient updates");
    }

    const approverUser = await ctx.db
      .query("users")
      .withIndex("by_authUserId", (q) => q.eq("authUserId", identity.subject))
      .first();

    if (approved) {
      if (update.field === "profile") {
        const patient = await ctx.db.get(update.patientId);
        if (!patient || patient.clinicId !== update.clinicId) {
          throw badRequest("Patient update does not belong to this clinic");
        }

        const profileUpdateValue =
          update.value && typeof update.value === "object" && !Array.isArray(update.value)
            ? (update.value as Record<string, unknown>)
            : {};

        const safeProfilePatch: Record<string, unknown> = {};
        for (const field of PATIENT_PROFILE_ALLOWED_FIELDS) {
          if (field in profileUpdateValue) {
            safeProfilePatch[field] = profileUpdateValue[field];
          }
        }

        if (Object.keys(safeProfilePatch).length > 0) {
          await ctx.db.patch(update.patientId, {
            ...safeProfilePatch,
            updatedAt: Date.now(),
          });
        }
      }
    }

    await ctx.db.patch(updateId, {
      approved: approved,
      approvedAt: Date.now(),
      approvedBy: approverUser?._id,
    });

    return { success: true };
  },
});

// ==================== CONSENTS ====================

export const saveConsent = mutation({
  args: {
    clinicId: v.string(),
    patientId: v.id("patients"),
    appointmentId: v.optional(v.id("appointments")),
    checkinSessionId: v.optional(v.id("checkinSessions")),
    type: v.string(),
    version: v.string(),
    signature: v.string(),
    acceptedAt: v.number(),
  },
  handler: async (ctx, args) => {
    // Map frontend types to schema types
    let consentType: "data_processing" | "treatment" | "terms_of_service" = "terms_of_service";
    if (args.type === "lgpd") consentType = "data_processing";
    else if (args.type === "procedures") consentType = "treatment";
    else if (args.type === "telehealth") consentType = "terms_of_service";

    const id = await ctx.db.insert("consents", {
      clinicId: args.clinicId,
      patientId: args.patientId,
      appointmentId: args.appointmentId,
      checkinSessionId: args.checkinSessionId,
      consentType,
      signedAt: args.acceptedAt,
      ipAddress: "127.0.0.1", // Placeholder, requires client info
      userAgent: "Unknown", // Placeholder
      signatureData: args.signature,
      createdAt: Date.now(),
    });
    return id;
  },
});

export const getPatientConsents = query({
  args: {
    patientId: v.id("patients"),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("consents")
      .withIndex("by_patient", (q: any) => q.eq("patientId", args.patientId))
      .collect();
  },
});

export const getAppointmentConsents = query({
  args: {
    appointmentId: v.id("appointments"),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("consents")
      .withIndex("by_appointment", (q: any) => q.eq("appointmentId", args.appointmentId))
      .collect();
  },
});

// ==================== DATA COLLECTION PROMPTS ====================

/**
 * Create a data collection request tracking record
 */
export const createDataCollectionRequest = internalMutation({
  args: {
    clinicId: v.string(),
    patientId: v.id("patients"),
    type: v.union(v.literal("id_card"), v.literal("insurance_card"), v.literal("referral")),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    // Invalidate any existing pending requests of the same type
    const existing = await ctx.db
      .query("dataCollectionRequests")
      .withIndex("by_patient_type", (q) => q.eq("patientId", args.patientId).eq("type", args.type))
      .filter((q) => q.eq(q.field("status"), "pending"))
      .collect();

    for (const req of existing) {
      await ctx.db.patch(req._id, {
        status: "expired",
      });
    }

    // Determine required count (insurance_card needs 2: front and back)
    const requiredCount = args.type === "insurance_card" ? 2 : 1;

    // Create new request
    const requestId = await ctx.db.insert("dataCollectionRequests", {
      clinicId: args.clinicId,
      patientId: args.patientId,
      type: args.type,
      status: "pending",
      requestedAt: now,
      requiredCount,
      receivedCount: 0,
      receivedMessageIds: [],
      createdAt: now,
    });

    return requestId;
  },
});

/**
 * Mark a data collection request as received
 */
export const markDataCollectionReceived = internalMutation({
  args: {
    patientId: v.id("patients"),
    type: v.union(v.literal("id_card"), v.literal("insurance_card"), v.literal("referral")),
    messageId: v.id("messages"),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    // Find pending request
    const request = await ctx.db
      .query("dataCollectionRequests")
      .withIndex("by_patient_type", (q) => q.eq("patientId", args.patientId).eq("type", args.type))
      .filter((q) => q.eq(q.field("status"), "pending"))
      .first();

    if (!request) {
      return {
        success: false,
        error: "No pending request found",
        isComplete: false,
      };
    }

    // Check if this message was already counted (idempotency)
    const receivedMessageIds = request.receivedMessageIds || [];
    if (receivedMessageIds.some((id) => id === args.messageId)) {
      return {
        success: true,
        alreadyCounted: true,
        receivedCount: request.receivedCount || 0,
        requiredCount: request.requiredCount || 1,
        isComplete: (request.receivedCount || 0) >= (request.requiredCount || 1),
      };
    }

    // Increment received count
    const newReceivedCount = (request.receivedCount || 0) + 1;
    const requiredCount = request.requiredCount || 1;
    const isComplete = newReceivedCount >= requiredCount;

    // Update request
    await ctx.db.patch(request._id, {
      receivedCount: newReceivedCount,
      receivedMessageIds: [...receivedMessageIds, args.messageId],
      // Only mark as received and set receivedAt when complete
      status: isComplete ? "received" : "pending",
      receivedAt: isComplete ? now : undefined,
      messageId: isComplete ? args.messageId : request.messageId,
    });

    return {
      success: true,
      receivedCount: newReceivedCount,
      requiredCount,
      isComplete,
      type: args.type,
    };
  },
});

/**
 * Get pending data collection requests for a patient
 */
export const getPendingDataCollectionRequests = internalQuery({
  args: {
    patientId: v.id("patients"),
  },
  handler: async (ctx, args) => {
    const requests = await ctx.db
      .query("dataCollectionRequests")
      .withIndex("by_patient_type", (q) => q.eq("patientId", args.patientId))
      .filter((q) => q.eq(q.field("status"), "pending"))
      .collect();

    return requests;
  },
});

export const triggerDataCollection = action({
  args: {
    patientId: v.id("patients"),
    clinicId: v.string(),
    type: v.union(
      v.literal("id_card"),
      v.literal("insurance_card"),
      v.literal("anamnesis"),
      v.literal("referral"),
    ),
  },
  handler: async (ctx, args) => {
    const { patientId, clinicId, type } = args;

    // Get patient phone
    const patient = await ctx.runQuery(internal.checkin.getPatientDetails, { patientId });
    if (!patient?.phone) return;

    // Get WhatsApp instance
    const integration = await ctx.runQuery(internal.checkin.getWhatsappIntegration, { clinicId });
    if (!integration?.instanceName) return;

    let message = "";
    if (type === "id_card") {
      message = `Olá ${patient.name}, para agilizar seu atendimento, por favor envie uma foto do seu documento de identidade (RG ou CNH).`;
    } else if (type === "insurance_card") {
      message = `Olá ${patient.name}, por favor envie uma foto da carteirinha do seu convênio.`;
    } else if (type === "referral") {
      message = `Olá ${patient.name}, por favor envie uma foto do encaminhamento médico.`;
    }

    if (message) {
      await evolution.sendText(integration.instanceName, patient.phone, message);

      // Create tracking record (only for image types, not anamnesis)
      if (type !== "anamnesis") {
        await ctx.runMutation(internal.checkin.createDataCollectionRequest, {
          clinicId,
          patientId,
          type: type as "id_card" | "insurance_card" | "referral",
        });
      }
    }
  },
});

// Public mutation to scan and validate QR code, completing check-in process
export const scanAndValidateQR = mutation({
  args: {
    qrToken: v.string(), // Token from QR code scanned at clinic totem
    urlToken: v.string(), // Token from URL that started the check-in session
  },
  handler: async (ctx, args) => {
    const { qrToken, urlToken } = args;
    const now = Date.now();

    // Step 1: Validate QR code token (public token from totem)
    const totemQR = await ctx.db
      .query("totemQRs")
      .withIndex("by_qrCode", (q) => q.eq("qrCode", qrToken))
      .first();

    if (!totemQR) {
      throw new Error("QR Code inválido ou expirado");
    }

    // Check if QR is expired
    if (totemQR.expiresAt < now) {
      throw new Error("QR Code inválido ou expirado");
    }

    // Check if QR is still active and not already scanned
    if (!totemQR.isActive || totemQR.scannedAt) {
      throw new Error("Este QR Code já foi utilizado");
    }

    // Step 2: Validate URL token (patient's personal session token from WhatsApp)
    const checkinSession = await ctx.db
      .query("checkinSessions")
      .withIndex("by_token", (q) => q.eq("token", urlToken))
      .first();

    if (!checkinSession) {
      throw new Error("Sessão de check-in não encontrada");
    }

    // Step 3: Security: Verify session is in correct state
    if (checkinSession.status !== "in_progress") {
      if (checkinSession.status === "completed") {
        throw new Error("Check-in já realizado anteriormente");
      }
      throw new Error("Estado da sessão inválido para check-in");
    }

    // Step 4: Security: Verify session has not expired
    if (checkinSession.expiresAt < now) {
      throw new Error("Sessão de check-in expirada. Por favor, solicite um novo link.");
    }

    // Step 5: Get appointment to validate status
    const appointment = await ctx.db.get(checkinSession.appointmentId);
    if (!appointment) {
      throw new Error("Agendamento não encontrado");
    }

    // Validate appointment status allows check-in
    if (appointment.status !== "pending" && appointment.status !== "confirmed") {
      throw new Error("O status do agendamento não permite check-in");
    }

    // Step 6: Security: Verify QR belongs to same clinic as session
    // This prevents cross-clinic QR scanning
    if (totemQR.clinicId !== checkinSession.clinicId) {
      throw new Error("QR Code inválido para esta clínica");
    }

    // Step 7: Invalidate QR code atomically (mark as scanned)
    await ctx.db.patch(totemQR._id, {
      isActive: false,
      scannedAt: now,
      scannedBy: checkinSession.patientId, // Track which patient used this QR
    });

    // Step 8: Complete check-in session
    await ctx.db.patch(checkinSession._id, {
      status: "completed",
      checkedInAt: now,
      updatedAt: now,
    });

    // Step 9: Update appointment status to "arrived"
    await ctx.db.patch(appointment._id, {
      status: "arrived",
      updatedAt: now,
    });

    // Step 9.5: Add to waitlist queue for reception tracking
    await ctx.runMutation(internal.waitlists.upsertWaitlistForCheckin, {
      clinicId: checkinSession.clinicId,
      appointmentId: checkinSession.appointmentId,
      patientId: checkinSession.patientId,
      doctorId: appointment.doctorId,
    });

    // Step 10: Schedule WhatsApp confirmation (non-blocking)
    const patient = await ctx.db.get(checkinSession.patientId);
    if (patient && patient.phone) {
      await ctx.scheduler.runAfter(0, internal.checkin.sendCheckinConfirmation, {
        patientId: checkinSession.patientId,
        clinicId: checkinSession.clinicId,
        appointmentId: checkinSession.appointmentId,
        patientPhone: patient.phone,
      });
    }

    // Return success with session and appointment details
    return {
      sessionId: checkinSession._id,
      appointmentId: appointment._id,
      checkedInAt: now,
    };
  },
});

// Internal mutation to complete check-in session and update appointment
export const internalCompleteCheckin = internalMutation({
  args: {
    checkinSessionId: v.id("checkinSessions"),
    patientId: v.id("patients"),
  },
  handler: async (ctx, args) => {
    const { checkinSessionId, patientId: _patientId } = args;
    const now = Date.now();

    // Get check-in session
    const checkinSession = await ctx.db.get(checkinSessionId);
    if (!checkinSession) {
      throw new Error("Sessão de check-in não encontrada");
    }

    // Update session to completed
    await ctx.db.patch(checkinSessionId, {
      status: "completed",
      checkedInAt: now,
      updatedAt: now,
    });

    // Update linked appointment
    const appointment = await ctx.db.get(checkinSession.appointmentId);
    if (appointment) {
      await ctx.db.patch(appointment._id, {
        status: "arrived",
        updatedAt: now,
      });

      // Add to waitlist queue for reception tracking
      await ctx.runMutation(internal.waitlists.upsertWaitlistForCheckin, {
        clinicId: checkinSession.clinicId,
        appointmentId: checkinSession.appointmentId,
        patientId: checkinSession.patientId,
        doctorId: appointment.doctorId,
      });
    }

    return { success: true };
  },
});

// Action to send WhatsApp confirmation to patient
export const sendCheckinConfirmation = internalAction({
  args: {
    patientId: v.id("patients"),
    clinicId: v.string(),
    appointmentId: v.id("appointments"),
    patientPhone: v.string(),
  },
  handler: async (ctx, args) => {
    const { patientId, clinicId, appointmentId, patientPhone } = args;

    try {
      // Fetch patient details
      const patient = await ctx.runQuery(internal.checkin.getPatientDetails, {
        patientId,
      });
      if (!patient) {
        console.error("[sendCheckinConfirmation] Patient not found:", patientId);
        return { success: false, error: "Patient not found" };
      }

      // Fetch clinic details
      const clinic = await ctx.runQuery(internal.checkin.getClinicDetails, {
        clinicId,
      });
      if (!clinic) {
        console.error("[sendCheckinConfirmation] Clinic not found:", clinicId);
        return { success: false, error: "Clinic not found" };
      }

      // Fetch appointment details
      const appointment = await ctx.runQuery(internal.checkin.getAppointmentDetails, {
        appointmentId,
      });
      if (!appointment) {
        console.error("[sendCheckinConfirmation] Appointment not found:", appointmentId);
        return { success: false, error: "Appointment not found" };
      }

      // Format appointment time in Portuguese
      const appointmentDate = new Date(appointment.startAt);
      const timeZone = appointment.timeZone || "America/Sao_Paulo";
      const formattedTime = appointmentDate.toLocaleTimeString("pt-BR", {
        hour: "2-digit",
        minute: "2-digit",
        timeZone,
      });

      // Format WhatsApp message
      const message = `Olá ${patient.name}! ✅\n\nVocê fez check-in com sucesso na clínica ${clinic.name} para sua consulta às ${formattedTime}.\n\nPor favor, aguarde na recepção. Obrigado! 🏥`;

      // Get WhatsApp integration instance for this clinic
      const whatsappIntegration = await ctx.runQuery(internal.checkin.getWhatsappIntegration, {
        clinicId,
      });

      if (!whatsappIntegration || !whatsappIntegration.instanceName) {
        console.error(
          "[sendCheckinConfirmation] WhatsApp integration not configured for clinic:",
          clinicId,
        );
        return { success: false, error: "WhatsApp not configured" };
      }

      // Send message via Evolution API
      await evolution.sendText(whatsappIntegration.instanceName, patientPhone, message);

      console.warn("[sendCheckinConfirmation] WhatsApp sent successfully to:", patientPhone);
      return { success: true };
    } catch (error) {
      console.error("[sendCheckinConfirmation] Error sending WhatsApp:", error);
      // Return error but don't throw - check-in should succeed even if WhatsApp fails
      return { success: false, error: String(error) };
    }
  },
});

// Internal queries to fetch details for WhatsApp message
export const getPatientDetails = internalQuery({
  args: {
    patientId: v.id("patients"),
  },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.patientId);
  },
});

export const getClinicDetails = internalQuery({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .first();
    return clinic;
  },
});

export const getAppointmentDetails = internalQuery({
  args: {
    appointmentId: v.id("appointments"),
  },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.appointmentId);
  },
});

export const getWhatsappIntegration = internalQuery({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const integration = await ctx.db
      .query("whatsappInstances")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .first();
    return integration;
  },
});

// ==================== SEND CHECK-IN LINK ====================

/**
 * Internal query to get the next upcoming appointment for a patient
 */
export const getNextUpcomingAppointment = internalQuery({
  args: {
    clinicId: v.string(),
    patientId: v.id("patients"),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    // Query appointments for this patient that are in the future
    const appointment = await ctx.db
      .query("appointments")
      .withIndex("by_clinic_patient_date", (q) =>
        q.eq("clinicId", args.clinicId).eq("patientId", args.patientId).gte("startAt", now),
      )
      .filter((q) => q.or(q.eq(q.field("status"), "pending"), q.eq(q.field("status"), "confirmed")))
      .order("asc")
      .first();

    return appointment;
  },
});

export const getPatientHasUpcomingAppointment = query({
  args: {
    clinicId: v.string(),
    patientId: v.id("patients"),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    const appointment = await ctx.db
      .query("appointments")
      .withIndex("by_clinic_patient_date", (q) =>
        q.eq("clinicId", args.clinicId).eq("patientId", args.patientId).gte("startAt", now),
      )
      .filter((q) => q.or(q.eq(q.field("status"), "pending"), q.eq(q.field("status"), "confirmed")))
      .first();

    return !!appointment;
  },
});

/**
 * Action to send check-in link to patient via WhatsApp
 * Creates a checkin session and sends the link
 */
export const sendCheckinLink = action({
  args: {
    patientId: v.id("patients"),
    clinicId: v.string(),
    appointmentId: v.optional(v.id("appointments")),
  },
  handler: async (
    ctx,
    args,
  ): Promise<{
    success: boolean;
    appointmentId: string;
    sessionId: string;
    checkinUrl: string;
  }> => {
    const { patientId, clinicId, appointmentId } = args;

    // Get patient details
    const patient = await ctx.runQuery(internal.checkin.getPatientDetails, { patientId });
    if (!patient) {
      throw new Error("Paciente não encontrado");
    }
    if (!patient.phone) {
      throw new Error("Paciente sem telefone cadastrado");
    }

    // Get appointment (provided or next upcoming)
    let appointment;
    if (appointmentId) {
      appointment = await ctx.runQuery(internal.checkin.getAppointmentDetails, { appointmentId });
    } else {
      appointment = await ctx.runQuery(internal.checkin.getNextUpcomingAppointment, {
        clinicId,
        patientId,
      });
    }

    if (!appointment) {
      throw new Error(
        "Este paciente não tem nenhuma consulta agendada. Primeiro agende uma consulta para poder enviar o link de check-in.",
      );
    }

    // Get clinic details
    const clinic = await ctx.runQuery(internal.checkin.getClinicDetails, { clinicId });
    if (!clinic) {
      throw new Error("Clínica não encontrada");
    }

    // Get WhatsApp integration
    const whatsappIntegration = await ctx.runQuery(internal.checkin.getWhatsappIntegration, {
      clinicId,
    });
    if (!whatsappIntegration || !whatsappIntegration.instanceName) {
      throw new Error("WhatsApp não configurado para esta clínica");
    }

    // Create check-in session
    const session = await ctx.runMutation(internalAny.checkin.internalCreateCheckinSession, {
      clinicId,
      appointmentId: appointment._id,
      patientId,
    });

    // Build check-in URL
    // Use environment variable or fallback to production URL
    const baseUrl = process.env.FRONTEND_URL || "https://app.whatsmed.tech";
    const checkinUrl = `${baseUrl}/checkin?token=${session.token}`;

    // Format appointment time
    const appointmentDate = new Date(appointment.startAt);
    const timeZone = appointment.timeZone || "America/Sao_Paulo";
    const formattedDate = appointmentDate.toLocaleDateString("pt-BR", {
      weekday: "long",
      day: "2-digit",
      month: "long",
      timeZone,
    });
    const formattedTime = appointmentDate.toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone,
    });

    // Send WhatsApp message
    const message = `Olá ${patient.name}! 👋\n\nVocê tem uma consulta agendada na *${clinic.name}* para *${formattedDate}* às *${formattedTime}*.\n\nPara agilizar seu atendimento, faça o check-in online antes de chegar:\n\n🔗 ${checkinUrl}\n\nEste link é pessoal e expira em 24 horas.\n\nAté logo! 🏥`;

    await evolution.sendText(whatsappIntegration.instanceName, patient.phone, message);

    return {
      success: true,
      appointmentId: appointment._id as string,
      sessionId: session._id as string,
      checkinUrl,
    };
  },
});

/**
 * Internal mutation to create check-in session (used by action)
 */
export const internalCreateCheckinSession = internalMutation({
  args: {
    clinicId: v.string(),
    appointmentId: v.id("appointments"),
    patientId: v.id("patients"),
  },
  handler: async (ctx, args) => {
    const { clinicId, appointmentId, patientId } = args;
    const now = Date.now();

    // Check if there's already an active session
    // Index is ["patientId", "appointmentId"]
    const existing = await ctx.db
      .query("checkinSessions")
      .withIndex("by_patient_appointment", (q) =>
        q.eq("patientId", patientId).eq("appointmentId", appointmentId),
      )
      .first();

    if (existing && existing.status === "in_progress" && existing.expiresAt > now) {
      return existing;
    }

    // Generate secure random token
    const token = generateSecureToken();
    const expiresAt = now + 24 * 60 * 60 * 1000; // 24 hours expiry

    const id = await ctx.db.insert("checkinSessions", {
      clinicId,
      appointmentId,
      patientId,
      token,
      status: "in_progress",
      expiresAt,
      createdAt: now,
      updatedAt: now,
    });

    return await ctx.db.get(id);
  },
});

// Public mutation to generate new totem QR code
export const generateTotemQR = mutation({
  args: {
    clinicId: v.string(),
    userId: v.id("users"),
    expiresInMinutes: v.optional(v.number()), // Optional: QR expires after X minutes (default 15)
  },
  handler: async (ctx, args) => {
    const { clinicId, userId, expiresInMinutes = 15 } = args;
    const now = Date.now();
    const expiresAt = now + expiresInMinutes * 60 * 1000;

    // Step 1: Invalidate previous active QR codes for this clinic
    const activeQRs = await ctx.db
      .query("totemQRs")
      .withIndex("by_clinic_active", (q) => q.eq("clinicId", clinicId).eq("isActive", true))
      .collect();

    for (const qr of activeQRs) {
      await ctx.db.patch(qr._id, {
        isActive: false,
        updatedAt: now,
      });
    }

    // Step 2: Generate cryptographically random QR token
    // Format: totem_clinicId_timestamp_randomString
    const randomString = generateSecureToken(12);
    const qrCode = `totem_${clinicId}_${now}_${randomString}`;

    // Step 3: Create new totem QR record
    const qrId = await ctx.db.insert("totemQRs", {
      clinicId,
      qrCode,
      expiresAt,
      createdBy: userId,
      isActive: true,
      createdAt: now,
    });

    // Return QR code with expiry info
    return {
      qrId,
      qrCode,
      expiresAt,
      expiresInMinutes,
      expiresAtFormatted: new Date(expiresAt).toLocaleString("pt-BR"),
    };
  },
});

// Internal mutation to invalidate previous QR codes
export const invalidatePreviousQR = internalMutation({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const { clinicId } = args;
    const now = Date.now();

    // Find all active QR codes for this clinic
    const activeQRs = await ctx.db
      .query("totemQRs")
      .withIndex("by_clinic_active", (q) => q.eq("clinicId", clinicId).eq("isActive", true))
      .collect();

    // Invalidate all active QR codes
    for (const qr of activeQRs) {
      await ctx.db.patch(qr._id, {
        isActive: false,
        updatedAt: now,
      });
    }

    return { invalidatedCount: activeQRs.length };
  },
});

// Public query to get active totem QR code for display
export const getActiveTotemQR = query({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const { clinicId } = args;
    const now = Date.now();

    // Find active QR code for this clinic
    const activeQR = await ctx.db
      .query("totemQRs")
      .withIndex("by_clinic_active", (q) => q.eq("clinicId", clinicId).eq("isActive", true))
      .first();

    if (!activeQR) {
      return null;
    }

    // Check if QR is expired
    if (activeQR.expiresAt < now) {
      return null;
    }

    // Calculate remaining time in seconds
    const remainingSeconds = Math.max(0, Math.floor((activeQR.expiresAt - now) / 1000));

    return {
      qrCode: activeQR.qrCode,
      expiresAt: activeQR.expiresAt,
      expiresAtFormatted: new Date(activeQR.expiresAt).toLocaleString("pt-BR"),
      remainingSeconds,
      remainingFormatted: formatRemainingTime(remainingSeconds),
      createdAt: activeQR.createdAt,
    };
  },
});

// Helper function to format remaining time in Portuguese
function formatRemainingTime(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const secs = seconds % 60;

  if (minutes > 0) {
    return `${minutes} minuto${minutes > 1 ? "s" : ""} e ${secs} segundo${secs !== 1 ? "s" : ""}`;
  }
  return `${secs} segundo${secs !== 1 ? "s" : ""}`;
}

// Internal query to get totem QR by code (for validation)
export const getTotemQR = internalQuery({
  args: {
    qrCode: v.string(),
  },
  handler: async (ctx, args) => {
    const qr = await ctx.db
      .query("totemQRs")
      .withIndex("by_qrCode", (q) => q.eq("qrCode", args.qrCode))
      .first();
    return qr;
  },
});
