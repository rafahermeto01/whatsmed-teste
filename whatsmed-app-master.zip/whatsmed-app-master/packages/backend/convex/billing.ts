import { v } from "convex/values";

import { internal } from "./_generated/api";
import type { Doc, Id } from "./_generated/dataModel";
import { action, internalMutation, mutation, query } from "./_generated/server";
import { asaas } from "./lib/asaas";
import { badRequest, notFound } from "./lib/errors";
import { requireClinicAccess, requireClinicRole } from "./lib/rbac";
import { isValidCpfCnpj, normalizeCpfCnpj } from "./lib/validators";

async function requireBillingReadAccess(ctx: any, clinicId: string) {
  return await requireClinicAccess(ctx, clinicId);
}

async function requireBillingAccess(ctx: any, clinicId: string) {
  return await requireClinicRole(ctx, clinicId, ["admin", "super_admin"]);
}

// Queries

export const getWallet = query({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    await requireBillingReadAccess(ctx, args.clinicId);
    const wallet = await ctx.db
      .query("wallets")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .unique();
    return wallet;
  },
});

export const listTransactions = query({
  args: {
    clinicId: v.string(),
    limit: v.optional(v.number()),
    cursor: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireBillingReadAccess(ctx, args.clinicId);
    const limit = args.limit ?? 20;
    const transactions = await ctx.db
      .query("transactions")
      .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", args.clinicId))
      .order("desc")
      .paginate({ cursor: args.cursor ?? null, numItems: limit });

    return transactions;
  },
});

export const listPaymentMethods = query({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    await requireBillingReadAccess(ctx, args.clinicId);
    return await ctx.db
      .query("paymentMethods")
      .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", args.clinicId))
      .collect();
  },
});

export const getSubscription = query({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    await requireBillingReadAccess(ctx, args.clinicId);
    return await ctx.db
      .query("subscriptions")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .unique();
  },
});

// Regular mutations (no external API calls)

export const removePaymentMethod = mutation({
  args: {
    clinicId: v.string(),
    paymentMethodId: v.id("paymentMethods"),
  },
  handler: async (ctx, args) => {
    await requireBillingAccess(ctx, args.clinicId);
    const method = await ctx.db.get(args.paymentMethodId);
    if (!method || method.clinicId !== args.clinicId) throw notFound("Payment method not found");

    await ctx.db.delete(args.paymentMethodId);

    if (method.isDefault) {
      const other = await ctx.db
        .query("paymentMethods")
        .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", args.clinicId))
        .first();
      if (other) {
        await ctx.db.patch(other._id, { isDefault: true });
      }
    }
  },
});

export const setDefaultPaymentMethod = mutation({
  args: {
    clinicId: v.string(),
    paymentMethodId: v.id("paymentMethods"),
  },
  handler: async (ctx, args) => {
    await requireBillingAccess(ctx, args.clinicId);
    const methods = await ctx.db
      .query("paymentMethods")
      .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", args.clinicId))
      .collect();

    for (const m of methods) {
      if (m._id === args.paymentMethodId) {
        await ctx.db.patch(m._id, { isDefault: true });
      } else if (m.isDefault) {
        await ctx.db.patch(m._id, { isDefault: false });
      }
    }
  },
});

export const updateAutoRechargeSettings = mutation({
  args: {
    clinicId: v.string(),
    enabled: v.boolean(),
    threshold: v.optional(v.number()),
    amount: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await requireBillingAccess(ctx, args.clinicId);
    const wallet = await ctx.db
      .query("wallets")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .unique();

    if (!wallet) throw notFound("Wallet not found");

    await ctx.db.patch(wallet._id, {
      autoRechargeEnabled: args.enabled,
      autoRechargeThreshold: args.threshold,
      autoRechargeAmount: args.amount,
      updatedAt: Date.now(),
    });
  },
});

// Actions (can make external API calls)

export const initializeWallet = action({
  args: {
    clinicId: v.string(),
    name: v.string(),
    cpfCnpj: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<Doc<"wallets"> | null> => {
    await requireBillingAccess(ctx, args.clinicId);
    // Check if wallet exists
    const existing = (await ctx.runQuery(internal.billing_internal.getWalletInternal, {
      clinicId: args.clinicId,
    })) as Doc<"wallets"> | null;

    if (existing) return existing;

    const cpfCnpj = normalizeCpfCnpj(args.cpfCnpj);
    if (!isValidCpfCnpj(cpfCnpj)) {
      throw badRequest("CPF/CNPJ inválido.");
    }

    // Create Asaas Customer
    const customer = await asaas.createCustomer({
      name: args.name,
      cpfCnpj,
      email: args.email,
      phone: args.phone,
      externalReference: args.clinicId,
    });

    // Create wallet
    const wallet = (await ctx.runMutation(internal.billing_internal.createWalletInternal, {
      clinicId: args.clinicId,
      asaasCustomerId: customer.id,
    })) as Doc<"wallets"> | null;

    return wallet;
  },
});

type InitWalletResult = {
  wallet: Doc<"wallets"> | null;
  created: boolean;
  needsSetup?: boolean;
  asaasLinked?: boolean;
  errorMessage?: string;
};

export const initializeWalletFromClinic = action({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args): Promise<InitWalletResult> => {
    await requireBillingAccess(ctx, args.clinicId);
    // Check if wallet already exists
    const existingWallet = (await ctx.runQuery(internal.billing_internal.getWalletInternal, {
      clinicId: args.clinicId,
    })) as Doc<"wallets"> | null;

    // If wallet exists and already has Asaas customer, return it
    if (existingWallet?.asaasCustomerId) {
      return { wallet: existingWallet, created: false };
    }

    // Get clinic data
    const clinic = (await ctx.runQuery(internal.billing_internal.getClinicInternal, {
      clinicId: args.clinicId,
    })) as Doc<"clinics"> | null;

    if (!clinic || !clinic.cpfCnpj) {
      return {
        wallet: existingWallet || null,
        created: false,
        needsSetup: true,
        errorMessage: "Configure o CPF/CNPJ da clínica para habilitar o faturamento.",
      };
    }

    const cpfCnpj = normalizeCpfCnpj(clinic.cpfCnpj);
    if (!isValidCpfCnpj(cpfCnpj)) {
      return {
        wallet: existingWallet || null,
        created: false,
        needsSetup: true,
        errorMessage: "O CPF/CNPJ da clínica é inválido. Corrija-o nas configurações.",
      };
    }

    // Create Asaas Customer
    const customer = await asaas.createCustomer({
      name: clinic.name,
      cpfCnpj,
      email: clinic.email,
      phone: clinic.phone,
      externalReference: args.clinicId,
    });

    if (existingWallet) {
      // Update existing wallet with Asaas customer ID
      const wallet = (await ctx.runMutation(internal.billing_internal.updateWalletAsaasId, {
        walletId: existingWallet._id,
        asaasCustomerId: customer.id,
      })) as Doc<"wallets"> | null;
      return { wallet, created: false, asaasLinked: true };
    }

    // Create new wallet with Asaas customer
    const wallet = (await ctx.runMutation(internal.billing_internal.createWalletInternal, {
      clinicId: args.clinicId,
      asaasCustomerId: customer.id,
    })) as Doc<"wallets"> | null;

    return { wallet, created: true };
  },
});

export const addPaymentMethod = action({
  args: {
    clinicId: v.string(),
    creditCard: v.object({
      holderName: v.string(),
      number: v.string(),
      expiryMonth: v.string(),
      expiryYear: v.string(),
      ccv: v.string(),
    }),
    creditCardHolderInfo: v.object({
      name: v.string(),
      email: v.string(),
      cpfCnpj: v.string(),
      postalCode: v.string(),
      addressNumber: v.string(),
      phone: v.string(),
    }),
  },
  handler: async (ctx, args): Promise<{ ok: boolean }> => {
    await requireBillingAccess(ctx, args.clinicId);
    const wallet = (await ctx.runQuery(internal.billing_internal.getWalletInternal, {
      clinicId: args.clinicId,
    })) as Doc<"wallets"> | null;

    if (!wallet || !wallet.asaasCustomerId) throw notFound("Wallet or Asaas customer not found");

    // Tokenize card
    const tokenized = await asaas.tokenizeCard({
      customer: wallet.asaasCustomerId,
      creditCard: args.creditCard,
      creditCardHolderInfo: args.creditCardHolderInfo,
    });

    // Check if default (need to query payment methods)
    const existingMethods = (await ctx.runQuery(
      internal.billing_internal.listPaymentMethodsInternal,
      {
        clinicId: args.clinicId,
      },
    )) as Doc<"paymentMethods">[];

    const isFirst = existingMethods.length === 0;

    await ctx.runMutation(internal.billing_internal.insertPaymentMethod, {
      clinicId: args.clinicId,
      walletId: wallet._id,
      brand: tokenized.creditCardBrand,
      last4: tokenized.creditCardNumber,
      expMonth: Number(args.creditCard.expiryMonth),
      expYear: Number(args.creditCard.expiryYear),
      holder: args.creditCard.holderName,
      fingerprint: tokenized.creditCardToken,
      providerPaymentMethodId: tokenized.creditCardToken,
      asaasCardToken: tokenized.creditCardToken,
      isDefault: isFirst,
    });

    return { ok: true };
  },
});

type TopUpResult = {
  paymentId: string;
  status: string;
  invoiceUrl?: string;
  // 3DS: If status is AWAITING_RISK_ANALYSIS or PENDING, user must complete authentication
  requires3DS?: boolean;
  authorizationUrl?: string;
  pixQrCode?: {
    encodedImage: string;
    payload: string;
    expirationDate: string;
  };
};

export const createTopUp = action({
  args: {
    clinicId: v.string(),
    amount: v.number(),
    billingType: v.union(v.literal("CREDIT_CARD"), v.literal("PIX")),
    cardId: v.optional(v.id("paymentMethods")),
  },
  handler: async (ctx, args): Promise<TopUpResult> => {
    await requireBillingAccess(ctx, args.clinicId);
    const wallet = (await ctx.runQuery(internal.billing_internal.getWalletInternal, {
      clinicId: args.clinicId,
    })) as Doc<"wallets"> | null;

    if (!wallet || !wallet.asaasCustomerId) throw notFound("Wallet or Asaas customer not found");

    let creditCardToken: string | undefined;

    if (args.billingType === "CREDIT_CARD") {
      if (!args.cardId) throw badRequest("Card ID required for credit card payment");
      const card = (await ctx.runQuery(internal.billing_internal.getPaymentMethodInternal, {
        id: args.cardId,
        clinicId: args.clinicId,
      })) as Doc<"paymentMethods"> | null;
      if (!card) throw notFound("Card not found");
      creditCardToken = card.asaasCardToken;
    }

    const payment = await asaas.createPayment({
      customer: wallet.asaasCustomerId,
      billingType: args.billingType,
      value: args.amount,
      dueDate: new Date().toISOString().split("T")[0],
      description: "Wallet Top-up",
      externalReference: wallet._id,
      creditCardToken: creditCardToken,
    });

    // Record transaction
    await ctx.runMutation(internal.billing_internal.insertTransaction, {
      clinicId: args.clinicId,
      walletId: wallet._id,
      type: "topup",
      amount: args.amount,
      asaasPaymentId: payment.id,
      status: "pending",
    });

    // If PIX, get QR Code
    let pixQrCode: TopUpResult["pixQrCode"];
    if (args.billingType === "PIX") {
      const qrData = await asaas.getPixQrCode(payment.id);
      pixQrCode = {
        encodedImage: qrData.encodedImage,
        payload: qrData.payload,
        expirationDate: qrData.expirationDate,
      };
    }

    // Check if 3DS is required (credit card payments may require additional authentication)
    const requires3DS =
      args.billingType === "CREDIT_CARD" &&
      (payment.status === "AWAITING_RISK_ANALYSIS" || payment.status === "PENDING");

    // The authorization URL is typically in invoiceUrl or transactionReceiptUrl
    const authorizationUrl = requires3DS
      ? payment.transactionReceiptUrl || payment.invoiceUrl
      : undefined;

    return {
      paymentId: payment.id,
      status: payment.status,
      invoiceUrl: payment.invoiceUrl,
      requires3DS,
      authorizationUrl,
      pixQrCode,
    };
  },
});

export const purchaseConversationCredits = action({
  args: {
    clinicId: v.string(),
    quantity: v.number(),
    billingType: v.union(v.literal("CREDIT_CARD"), v.literal("PIX")),
    cardId: v.optional(v.id("paymentMethods")),
  },
  handler: async (ctx, args): Promise<TopUpResult> => {
    await requireBillingAccess(ctx, args.clinicId);
    const wallet = (await ctx.runQuery(internal.billing_internal.getWalletInternal, {
      clinicId: args.clinicId,
    })) as Doc<"wallets"> | null;

    if (!wallet || !wallet.asaasCustomerId) throw notFound("Wallet or Asaas customer not found");

    // Price per credit (R$2 per credit)
    const PRICE_PER_CREDIT = 2;
    const totalAmount = args.quantity * PRICE_PER_CREDIT;

    let creditCardToken: string | undefined;

    if (args.billingType === "CREDIT_CARD") {
      if (!args.cardId) throw badRequest("Card ID required for credit card payment");
      const card = (await ctx.runQuery(internal.billing_internal.getPaymentMethodInternal, {
        id: args.cardId,
        clinicId: args.clinicId,
      })) as Doc<"paymentMethods"> | null;
      if (!card) throw notFound("Card not found");
      creditCardToken = card.asaasCardToken;
    }

    const payment = await asaas.createPayment({
      customer: wallet.asaasCustomerId,
      billingType: args.billingType,
      value: totalAmount,
      dueDate: new Date().toISOString().split("T")[0],
      description: `Compra de ${args.quantity} créditos de conversa`,
      externalReference: wallet._id,
      creditCardToken: creditCardToken,
    });

    // Record transaction with credit purchase metadata
    await ctx.runMutation(internal.billing_internal.insertTransaction, {
      clinicId: args.clinicId,
      walletId: wallet._id,
      type: "topup",
      amount: totalAmount,
      asaasPaymentId: payment.id,
      status: "pending",
      reason: "credit_purchase",
      meta: { creditQuantity: args.quantity },
    });

    // If PIX, get QR Code
    let pixQrCode: TopUpResult["pixQrCode"];
    if (args.billingType === "PIX") {
      const qrData = await asaas.getPixQrCode(payment.id);
      pixQrCode = {
        encodedImage: qrData.encodedImage,
        payload: qrData.payload,
        expirationDate: qrData.expirationDate,
      };
    }

    // Check if 3DS is required
    const requires3DS =
      args.billingType === "CREDIT_CARD" &&
      (payment.status === "AWAITING_RISK_ANALYSIS" || payment.status === "PENDING");

    const authorizationUrl = requires3DS
      ? payment.transactionReceiptUrl || payment.invoiceUrl
      : undefined;

    return {
      paymentId: payment.id,
      status: payment.status,
      invoiceUrl: payment.invoiceUrl,
      requires3DS,
      authorizationUrl,
      pixQrCode,
    };
  },
});

// Plan prices configuration
const PLAN_PRICES: Record<string, number> = {
  free: 0,
  starter: 497,
  professional: 697,
  enterprise: 997,
};

const PLAN_NAMES: Record<string, string> = {
  free: "Gratuito",
  starter: "Inicial",
  professional: "Profissional",
  enterprise: "Empresarial",
};

type SubscribeToPlanResult = {
  success: boolean;
  subscriptionId?: string;
  requires3DS?: boolean;
  authorizationUrl?: string;
};

export const subscribeToPlan = action({
  args: {
    clinicId: v.string(),
    plan: v.union(v.literal("starter"), v.literal("professional"), v.literal("enterprise")),
  },
  handler: async (ctx, args): Promise<SubscribeToPlanResult> => {
    await requireBillingAccess(ctx, args.clinicId);
    const wallet = (await ctx.runQuery(internal.billing_internal.getWalletInternal, {
      clinicId: args.clinicId,
    })) as Doc<"wallets"> | null;

    if (!wallet || !wallet.asaasCustomerId) throw notFound("Wallet or Asaas customer not found");

    // Get default payment method
    const card = (await ctx.runQuery(internal.billing_internal.getDefaultPaymentMethod, {
      clinicId: args.clinicId,
    })) as Doc<"paymentMethods"> | null;

    if (!card || !card.asaasCardToken)
      throw badRequest("Nenhum cartão cadastrado. Adicione um cartão primeiro.");

    // Check if there's an existing subscription
    const existingSub = (await ctx.runQuery(internal.billing_internal.getSubscriptionByClinic, {
      clinicId: args.clinicId,
    })) as Doc<"subscriptions"> | null;

    if (existingSub && existingSub.status === "ACTIVE") {
      throw badRequest("Você já possui uma assinatura ativa. Cancele a atual para mudar de plano.");
    }

    const value = PLAN_PRICES[args.plan];
    const today = new Date().toISOString().split("T")[0];

    const subscription = await asaas.createSubscription({
      customer: wallet.asaasCustomerId,
      billingType: "CREDIT_CARD",
      value,
      nextDueDate: today,
      cycle: "MONTHLY",
      description: `Plano ${PLAN_NAMES[args.plan]}`,
      creditCardToken: card.asaasCardToken,
    });

    // Insert subscription record
    await ctx.runMutation(internal.billing_internal.insertSubscription, {
      clinicId: args.clinicId,
      asaasSubscriptionId: subscription.id,
      asaasCustomerId: wallet.asaasCustomerId,
      status: subscription.status,
      billingType: "CREDIT_CARD",
      value,
      nextDueDate: subscription.nextDueDate,
      cycle: "MONTHLY",
      description: args.plan,
      creditCard: {
        brand: card.brand,
        last4: card.last4,
      },
    });

    // Update clinic plan
    await ctx.runMutation(internal.billing_internal.updateClinicPlan, {
      clinicId: args.clinicId,
      plan: args.plan,
      planStatus: subscription.status === "ACTIVE" ? "active" : "trialing",
      asaasSubscriptionId: subscription.id,
      planValue: value,
      planNextDueDate: subscription.nextDueDate,
      planCycle: "MONTHLY",
    });

    // Reset billing cycle and conversation credits
    await ctx.runMutation(internal.conversationCredits.resetBillingCycle, {
      clinicId: args.clinicId,
    });

    // Check if 3DS is required for the first payment
    // Subscriptions may also require 3DS on the initial charge
    const requires3DS =
      subscription.status === "AWAITING_RISK_ANALYSIS" || subscription.status === "PENDING";
    const authorizationUrl = requires3DS
      ? subscription.transactionReceiptUrl || subscription.paymentLink
      : undefined;

    return {
      success: true,
      subscriptionId: subscription.id,
      requires3DS,
      authorizationUrl,
    };
  },
});

export const createSubscription = action({
  args: {
    clinicId: v.string(),
    plan: v.string(),
    billingType: v.literal("CREDIT_CARD"),
    cardId: v.id("paymentMethods"),
    value: v.number(),
    cycle: v.union(
      v.literal("WEEKLY"),
      v.literal("BIWEEKLY"),
      v.literal("MONTHLY"),
      v.literal("QUARTERLY"),
      v.literal("SEMIANNUALLY"),
      v.literal("YEARLY"),
    ),
  },
  handler: async (ctx, args): Promise<Id<"subscriptions">> => {
    await requireBillingAccess(ctx, args.clinicId);
    const wallet = (await ctx.runQuery(internal.billing_internal.getWalletInternal, {
      clinicId: args.clinicId,
    })) as Doc<"wallets"> | null;

    if (!wallet || !wallet.asaasCustomerId) throw notFound("Wallet or Asaas customer not found");

    const card = (await ctx.runQuery(internal.billing_internal.getPaymentMethodInternal, {
      id: args.cardId,
      clinicId: args.clinicId,
    })) as Doc<"paymentMethods"> | null;
    if (!card) throw notFound("Card not found");

    const today = new Date().toISOString().split("T")[0];

    const subscription = await asaas.createSubscription({
      customer: wallet.asaasCustomerId,
      billingType: args.billingType,
      value: args.value,
      nextDueDate: today,
      cycle: args.cycle,
      description: `Subscription ${args.plan}`,
      creditCardToken: card.asaasCardToken,
    });

    const subId = (await ctx.runMutation(internal.billing_internal.insertSubscription, {
      clinicId: args.clinicId,
      asaasSubscriptionId: subscription.id,
      asaasCustomerId: wallet.asaasCustomerId,
      status: subscription.status,
      billingType: args.billingType,
      value: args.value,
      nextDueDate: subscription.nextDueDate,
      cycle: args.cycle,
      description: args.plan,
      creditCard: {
        brand: card.brand,
        last4: card.last4,
      },
    })) as Id<"subscriptions">;

    // Update clinic plan
    const planType = args.plan as "starter" | "professional" | "enterprise";
    if (["starter", "professional", "enterprise"].includes(args.plan)) {
      await ctx.runMutation(internal.billing_internal.updateClinicPlan, {
        clinicId: args.clinicId,
        plan: planType,
        planStatus: subscription.status === "ACTIVE" ? "active" : "trialing",
        asaasSubscriptionId: subscription.id,
        planValue: args.value,
        planNextDueDate: subscription.nextDueDate,
        planCycle: args.cycle,
      });
    }

    return subId;
  },
});

export const cancelSubscription = action({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args): Promise<void> => {
    await requireBillingAccess(ctx, args.clinicId);
    // Get subscription from clinic
    const sub = (await ctx.runQuery(internal.billing_internal.getSubscriptionByClinic, {
      clinicId: args.clinicId,
    })) as Doc<"subscriptions"> | null;

    if (!sub) throw notFound("Subscription not found");

    await asaas.cancelSubscription(sub.asaasSubscriptionId);

    // Update subscription status
    await ctx.runMutation(internal.billing_internal.updateSubscriptionStatus, {
      subscriptionId: sub._id,
      status: "INACTIVE",
    });

    // Update clinic plan to free
    await ctx.runMutation(internal.billing_internal.updateClinicPlan, {
      clinicId: args.clinicId,
      plan: "free",
      planStatus: "canceled",
      asaasSubscriptionId: undefined,
      planValue: 0,
      planNextDueDate: undefined,
      planCycle: undefined,
    });
  },
});

// Internal Mutations for Webhooks

export const processPaymentConfirmed = internalMutation({
  args: {
    paymentId: v.string(),
    value: v.number(),
    billingType: v.string(),
  },
  handler: async (ctx, args) => {
    const tx = await ctx.db
      .query("transactions")
      .withIndex("by_asaas_payment_id", (q) => q.eq("asaasPaymentId", args.paymentId))
      .unique();

    if (tx && tx.status !== "succeeded") {
      await ctx.db.patch(tx._id, {
        status: "succeeded",
        updatedAt: Date.now(),
      });

      // Check if this is a credit purchase
      if (
        tx.reason === "credit_purchase" &&
        tx.meta &&
        typeof tx.meta === "object" &&
        "creditQuantity" in tx.meta
      ) {
        const creditQuantity = tx.meta.creditQuantity as number;
        // Add credits to clinic instead of wallet balance
        await ctx.runMutation(internal.conversationCredits.addPurchasedCredits, {
          clinicId: tx.clinicId,
          amount: creditQuantity,
        });
      } else {
        // Regular top-up: add to wallet balance
        const wallet = await ctx.db.get(tx.walletId);
        if (wallet) {
          await ctx.db.patch(wallet._id, {
            balance: wallet.balance + args.value,
            updatedAt: Date.now(),
          });
        }
      }
      return { handled: true as const };
    } else if (!tx) {
      return { handled: false as const, reason: "unknown_payment" as const };
    }

    return { handled: false as const, reason: "already_processed" as const };
  },
});

export const processPaymentRefunded = internalMutation({
  args: {
    paymentId: v.string(),
    value: v.number(),
  },
  handler: async (ctx, args) => {
    const tx = await ctx.db
      .query("transactions")
      .withIndex("by_asaas_payment_id", (q) => q.eq("asaasPaymentId", args.paymentId))
      .unique();

    if (tx && tx.status === "succeeded") {
      await ctx.db.patch(tx._id, {
        status: "failed",
        reason: "Refunded",
        updatedAt: Date.now(),
      });

      const wallet = await ctx.db.get(tx.walletId);
      if (wallet) {
        await ctx.db.patch(wallet._id, {
          balance: wallet.balance - args.value,
          updatedAt: Date.now(),
        });
      }
      return { handled: true as const };
    }

    return {
      handled: false as const,
      reason: tx ? ("ignored_status" as const) : ("unknown_payment" as const),
    };
  },
});

export const processPaymentFailed = internalMutation({
  args: {
    paymentId: v.string(),
    status: v.string(),
  },
  handler: async (ctx, args) => {
    const tx = await ctx.db
      .query("transactions")
      .withIndex("by_asaas_payment_id", (q) => q.eq("asaasPaymentId", args.paymentId))
      .unique();

    if (tx && tx.status !== "succeeded" && tx.status !== "failed") {
      await ctx.db.patch(tx._id, {
        status: "failed",
        reason: args.status,
        updatedAt: Date.now(),
      });
      return { handled: true as const };
    }

    return {
      handled: false as const,
      reason: tx ? ("ignored_status" as const) : ("unknown_payment" as const),
    };
  },
});

export const processSubscriptionEvent = internalMutation({
  args: {
    subscriptionId: v.string(),
    status: v.string(),
    nextDueDate: v.optional(v.string()),
    value: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const sub = await ctx.db
      .query("subscriptions")
      .withIndex("by_asaas_id", (q) => q.eq("asaasSubscriptionId", args.subscriptionId))
      .unique();

    if (sub) {
      // Update subscription record
      const updates: Record<string, unknown> = {
        status: args.status,
        updatedAt: Date.now(),
      };
      if (args.nextDueDate) updates.nextDueDate = args.nextDueDate;
      if (args.value) updates.value = args.value;

      await ctx.db.patch(sub._id, updates);

      // Update clinic plan status
      const clinic = await ctx.db
        .query("clinics")
        .withIndex("by_clinicId", (q) => q.eq("clinicId", sub.clinicId))
        .unique();

      if (clinic) {
        // Map Asaas status to our plan status
        let planStatus: "active" | "past_due" | "canceled" | "trialing" = "active";
        if (args.status === "INACTIVE" || args.status === "EXPIRED") {
          planStatus = "canceled";
        } else if (args.status === "OVERDUE") {
          planStatus = "past_due";
        }

        const clinicUpdates: Record<string, unknown> = {
          planStatus,
          updatedAt: Date.now(),
        };
        if (args.nextDueDate) clinicUpdates.planNextDueDate = args.nextDueDate;
        if (args.value) clinicUpdates.planValue = args.value;

        await ctx.db.patch(clinic._id, clinicUpdates);

        // Reset billing cycle when subscription renews (status changes to ACTIVE with new nextDueDate)
        if (args.status === "ACTIVE" && args.nextDueDate && planStatus === "active") {
          await ctx.runMutation(internal.conversationCredits.resetBillingCycle, {
            clinicId: sub.clinicId,
          });
        }
      }
    }
  },
});
