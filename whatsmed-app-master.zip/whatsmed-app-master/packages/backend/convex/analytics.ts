import { v } from "convex/values";

import { mutation, query } from "./_generated/server";

export interface FunnelMetrics {
  sent: number;
  engaged: number;
  confirmed: number;
  arrived: number;
}

export interface WaitlistStats {
  count: number;
  waiting: number;
  notified: number;
  assigned: number;
}

export const getDashboardMetrics = query({
  args: {
    clinicId: v.string(),
    periodStart: v.number(),
    periodEnd: v.number(),
  },
  handler: async (ctx, args) => {
    const { clinicId, periodStart, periodEnd } = args;

    // 1. Appointments for rates (period-scoped)
    const appointments = await ctx.db
      .query("appointments")
      .withIndex("by_clinic_date", (q) =>
        q.eq("clinicId", clinicId).gte("startAt", periodStart).lte("startAt", periodEnd),
      )
      .collect();

    const totalAppointments = appointments.length;
    const confirmedAppointments = appointments.filter(
      (a) => a.status === "confirmed" || a.status === "arrived" || a.status === "completed",
    ).length;
    const cancelledAppointments = appointments.filter((a) => a.status === "cancelled").length;

    const confirmationRate =
      totalAppointments > 0 ? (confirmedAppointments / totalAppointments) * 100 : 0;
    const cancellationRate =
      totalAppointments > 0 ? (cancelledAppointments / totalAppointments) * 100 : 0;

    // 2. Manual Interventions: Active chats escalated for human intervention (real-time count)
    // These are open chats where AI could not resolve and staff needs to respond
    const openChats = await ctx.db
      .query("chats")
      .withIndex("by_clinic_status_updated", (q) => q.eq("clinicId", clinicId).eq("status", "open"))
      .collect();

    const manualInterventions = openChats.filter((chat) => chat.needsHumanReview === true).length;

    // 3. Waitlist
    const waitlist = await ctx.db
      .query("waitlists")
      .withIndex("by_clinic_status", (q) => q.eq("clinicId", clinicId).eq("status", "waiting"))
      .collect();

    return {
      confirmationRate,
      cancellationRate,
      manualInterventions,
      waitlistCount: waitlist.length,
    };
  },
});

export const getFunnelMetrics = query({
  args: {
    clinicId: v.string(),
    periodStart: v.number(),
    periodEnd: v.number(),
  },
  handler: async (ctx, args) => {
    const { clinicId, periodStart, periodEnd } = args;

    // Query appointments by clinic and date range
    const appointments = await ctx.db
      .query("appointments")
      .withIndex("by_clinic_date", (q) =>
        q.eq("clinicId", clinicId).gte("startAt", periodStart).lte("startAt", periodEnd),
      )
      .collect();

    // Funnel stages based on appointment lifecycle:
    // 1. Sent/Agendados: All non-cancelled appointments
    // 2. Engaged (IA): Chats with patient interaction in period
    // 3. Confirmed: Explicitly confirmed appointments
    // 4. Arrived: Patient showed up (arrived OR completed means they came)

    const sent = appointments.filter((apt) => apt.status !== "cancelled").length;

    // Get engaged patients (chats with activity in the period)
    const chats = await ctx.db
      .query("chats")
      .withIndex("by_clinic_lastMessageAt", (q) =>
        q
          .eq("clinicId", clinicId)
          .gte("lastMessageAt", periodStart)
          .lte("lastMessageAt", periodEnd),
      )
      .collect();

    const engaged = chats.filter((chat) => chat.lastMessage && chat.lastMessage !== "").length;

    const confirmed = appointments.filter((apt) => apt.status === "confirmed").length;

    const arrived = appointments.filter(
      (apt) => apt.status === "arrived" || apt.status === "completed",
    ).length;

    return {
      sent,
      engaged,
      confirmed,
      arrived,
    } as FunnelMetrics;
  },
});

export const recordFunnelStep = mutation({
  args: {
    clinicId: v.string(),
    step: v.union(
      v.literal("sent"),
      v.literal("engaged"),
      v.literal("confirmed"),
      v.literal("arrived"),
    ),
    value: v.number(),
    periodStart: v.number(),
    periodEnd: v.number(),
  },
  handler: async (ctx, args) => {
    const { clinicId, step, value, periodStart, periodEnd } = args;

    await ctx.db.insert("analyticsData", {
      clinicId,
      metricType: "funnel_step",
      value,
      periodStart,
      periodEnd,
      metadata: {
        step,
      },
      createdAt: Date.now(),
    });
  },
});

export const aggregateDailyFunnelMetrics = mutation({
  args: {
    clinicId: v.string(),
    date: v.number(),
  },
  handler: async (ctx, args) => {
    const { clinicId, date } = args;

    // Calculate period start/end for the day
    const periodStart = date;
    const periodEnd = date + 24 * 60 * 60 * 1000 - 1; // End of day

    // Get funnel metrics for the day
    const appointments = await ctx.db
      .query("appointments")
      .withIndex("by_clinic_date", (q) =>
        q.eq("clinicId", clinicId).gte("startAt", periodStart).lte("startAt", periodEnd),
      )
      .collect();

    const chats = await ctx.db
      .query("chats")
      .withIndex("by_clinic_lastMessageAt", (q) =>
        q
          .eq("clinicId", clinicId)
          .gte("lastMessageAt", periodStart)
          .lte("lastMessageAt", periodEnd),
      )
      .collect();

    const sent = appointments.filter((apt) => apt.status !== "cancelled").length;

    const engaged = chats.filter((chat) => chat.lastMessage && chat.lastMessage !== "").length;

    const confirmed = appointments.filter((apt) => apt.status === "confirmed").length;

    const arrived = appointments.filter(
      (apt) => apt.status === "arrived" || apt.status === "completed",
    ).length;

    // Record all funnel steps as separate analyticsData entries
    const now = Date.now();
    const steps = [
      { step: "sent", value: sent },
      { step: "engaged", value: engaged },
      { step: "confirmed", value: confirmed },
      { step: "arrived", value: arrived },
    ] as const;

    for (const { step, value } of steps) {
      await ctx.db.insert("analyticsData", {
        clinicId,
        metricType: "funnel_step",
        value,
        periodStart,
        periodEnd,
        metadata: {
          step,
        },
        createdAt: now,
      });
    }

    return { success: true, recorded: steps };
  },
});

export const getWaitlistCount = query({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const { clinicId } = args;

    // Get all waitlist entries for clinic
    const waitlistEntries = await ctx.db
      .query("waitlists")
      .withIndex("by_clinic_status", (q) => q.eq("clinicId", clinicId).eq("status", "waiting"))
      .collect();

    return waitlistEntries.length;
  },
});

export const getWaitlistEntries = query({
  args: {
    clinicId: v.string(),
    status: v.optional(v.union(v.literal("waiting"), v.literal("notified"), v.literal("assigned"))),
  },
  handler: async (ctx, args) => {
    const { clinicId, status } = args;

    let waitlistEntries;
    if (status) {
      // Filter by specific status
      waitlistEntries = await ctx.db
        .query("waitlists")
        .withIndex("by_clinic_status", (q) => q.eq("clinicId", clinicId).eq("status", status))
        .collect();
    } else {
      // Get all waitlist entries
      waitlistEntries = await ctx.db
        .query("waitlists")
        .withIndex("by_clinic_requestedAt", (q) => q.eq("clinicId", clinicId))
        .collect();
    }

    // Join with patients data
    const entriesWithPatients = await Promise.all(
      waitlistEntries.map(async (entry) => {
        const patient = await ctx.db.get(entry.patientId);
        return {
          ...entry,
          patient,
        };
      }),
    );

    return entriesWithPatients;
  },
});
