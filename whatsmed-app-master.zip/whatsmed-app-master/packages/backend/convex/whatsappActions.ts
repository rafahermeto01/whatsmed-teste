"use node";

import { v } from "convex/values";

import { internalAction } from "./_generated/server";
import { decryptMedia } from "./lib/whatsapp/decryption";

const DOWNLOAD_TIMEOUT_MS = 20_000;
const MAX_MEDIA_SIZE_BYTES = 25 * 1024 * 1024; // 25MB

async function readResponseBufferWithLimit(response: Response, maxBytes: number): Promise<Buffer> {
  if (!response.body) {
    const arrayBuffer = await response.arrayBuffer();
    if (arrayBuffer.byteLength > maxBytes) {
      throw new Error(`Media exceeds maximum allowed size (${maxBytes} bytes)`);
    }
    return Buffer.from(arrayBuffer);
  }

  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let totalBytes = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    if (!value) continue;

    totalBytes += value.byteLength;
    if (totalBytes > maxBytes) {
      await reader.cancel();
      throw new Error(`Media exceeds maximum allowed size (${maxBytes} bytes)`);
    }

    chunks.push(value);
  }

  return Buffer.from(Buffer.concat(chunks));
}

export const downloadAndDecryptMedia = internalAction({
  args: {
    url: v.string(),
    mediaKey: v.optional(v.any()), // Accepts string or Buffer-like object
    mediaType: v.string(), // "image", "video", etc.
    mimetype: v.string(),
  },
  handler: async (ctx, args) => {
    console.log(`[media-action] Processing media from ${args.url}`);

    // Normalize mediaKey to base64 string if it's an object/buffer
    let mediaKeyStr = args.mediaKey;
    if (typeof args.mediaKey === "object" && args.mediaKey !== null) {
      // Handle {0: 216, 1: 79...} object style buffer
      const values = Object.values(args.mediaKey) as number[];
      mediaKeyStr = Buffer.from(values).toString("base64");
      console.log(
        `[media-action] Converted object mediaKey to base64: ${mediaKeyStr.substring(0, 10)}...`,
      );
    }

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), DOWNLOAD_TIMEOUT_MS);
      let response: Response;

      try {
        response = await fetch(args.url, {
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeout);
      }

      if (!response.ok) {
        throw new Error(`Failed to fetch media: ${response.status}`);
      }

      const contentLengthHeader = response.headers.get("content-length");
      if (contentLengthHeader) {
        const contentLength = Number(contentLengthHeader);
        if (!Number.isNaN(contentLength) && contentLength > MAX_MEDIA_SIZE_BYTES) {
          throw new Error(
            `Media too large: ${contentLength} bytes (max ${MAX_MEDIA_SIZE_BYTES} bytes)`,
          );
        }
      }

      const buffer = await readResponseBufferWithLimit(response, MAX_MEDIA_SIZE_BYTES);

      let finalBuffer: any = buffer;

      // Decrypt if it's an encrypted WhatsApp URL and we have the key
      if ((args.url.includes("whatsapp.net") || args.url.includes(".enc")) && mediaKeyStr) {
        console.log(`[media-action] Decrypting media...`);
        try {
          finalBuffer = decryptMedia(buffer as any, mediaKeyStr, args.mediaType as any);
          console.log(`[media-action] Decryption successful. New size: ${finalBuffer.byteLength}`);
        } catch (e) {
          console.error(`[media-action] Decryption failed: ${e}`);
          // If decryption fails, we might still want to try storing it (though it's likely garbage)
          // or throw error. Let's throw to let the caller know.
          throw new Error(`Decryption failed: ${e}`);
        }
      }

      // Upload to Convex Storage
      // Convert Buffer back to Blob for storage.store
      const blob = new Blob([finalBuffer], { type: args.mimetype });
      const storageId = await ctx.storage.store(blob);

      console.log(`[media-action] Stored media: ${storageId}`);
      return storageId;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error(`[media-action] Error: ${errorMessage}`);
      return null;
    }
  },
});
