import { v } from "convex/values";

import { internal } from "./_generated/api";
import { internalAction, internalMutation, internalQuery } from "./_generated/server";

const internalAny = internal as any;

const DEFAULT_CLINIC_ID = "promptfoo-eval-clinic";
const DEFAULT_INSTANCE_NAME = "promptfoo-eval-instance";
const PRIMARY_DOCTOR_EMAIL = "promptfoo.doctor@example.test";
const PRIMARY_DOCTOR_AUTH_USER_ID = "promptfoo-doctor-auth";
const PRIMARY_DOCTOR_NAME = "Dr Promptfoo Avaliacao";
const PRIMARY_PROCEDURE_NAME = "Consulta Promptfoo";
const PRIMARY_PROCEDURE_DESCRIPTION = "Procedimento de teste automatizado para promptfoo";
const BRAZIL_TIME_ZONE = "America/Sao_Paulo";

type WorkingSlot = {
  start: string;
  end: string;
  types: string[];
};

type WorkingDay = {
  dayOfWeek: number;
  slots: WorkingSlot[];
};

const DEFAULT_WORKING_HOURS: WorkingDay[] = [1, 2, 3, 4, 5].map((dayOfWeek) => ({
  dayOfWeek,
  slots: [
    { start: "08:00", end: "12:00", types: ["in_person", "telemedicine"] },
    { start: "13:00", end: "18:00", types: ["in_person", "telemedicine"] },
    { start: "19:00", end: "22:00", types: ["in_person", "telemedicine"] },
  ],
}));

DEFAULT_WORKING_HOURS.push({
  dayOfWeek: 6,
  slots: [{ start: "09:00", end: "12:00", types: ["in_person", "telemedicine"] }],
});

const MORNING_ONLY_HOURS: WorkingDay[] = [1, 2, 3, 4, 5].map((dayOfWeek) => ({
  dayOfWeek,
  slots: [{ start: "08:00", end: "12:00", types: ["in_person", "telemedicine"] }],
}));

const AFTERNOON_ONLY_HOURS: WorkingDay[] = [1, 2, 3, 4, 5].map((dayOfWeek) => ({
  dayOfWeek,
  slots: [{ start: "13:00", end: "18:00", types: ["in_person", "telemedicine"] }],
}));

const NIGHT_ONLY_HOURS: WorkingDay[] = [1, 2, 3, 4, 5].map((dayOfWeek) => ({
  dayOfWeek,
  slots: [{ start: "19:00", end: "22:00", types: ["in_person", "telemedicine"] }],
}));

const DOCTOR_FIXTURES = [
  {
    key: "primary",
    email: PRIMARY_DOCTOR_EMAIL,
    authUserId: PRIMARY_DOCTOR_AUTH_USER_ID,
    name: PRIMARY_DOCTOR_NAME,
    specialties: ["Clínico geral", "Telemedicina"],
    workingHours: DEFAULT_WORKING_HOURS,
  },
  {
    key: "ambiguousSameFirstName",
    email: "promptfoo.avaliacao.clinica@example.test",
    authUserId: "promptfoo-doctor-auth-ambiguous-1",
    name: "Dra Promptfoo Avaliacao Clinica",
    specialties: ["Clínica Médica"],
    workingHours: MORNING_ONLY_HOURS,
  },
  {
    key: "specialist",
    email: "promptfoo.cardiologia@example.test",
    authUserId: "promptfoo-doctor-auth-cardiologia",
    name: "Dr Promptfoo Cardiologia",
    specialties: ["Cardiologia"],
    workingHours: AFTERNOON_ONLY_HOURS,
  },
  {
    key: "nightClinician",
    email: "promptfoo.clinica.medica@example.test",
    authUserId: "promptfoo-doctor-auth-clinica-medica",
    name: "Dra Promptfoo Clinica Medica",
    specialties: ["Clínica Médica"],
    workingHours: NIGHT_ONLY_HOURS,
  },
] as const;

const PROCEDURE_FIXTURES = [
  {
    key: "primaryConsultation",
    doctorKey: "primary",
    name: PRIMARY_PROCEDURE_NAME,
    description: PRIMARY_PROCEDURE_DESCRIPTION,
    durationMinutes: 60,
    isTelemedicine: true,
    isInPerson: true,
  },
  {
    key: "returnConsultation",
    doctorKey: "primary",
    name: "Retorno Promptfoo",
    description: "Retorno de teste automatizado para promptfoo",
    durationMinutes: 30,
    isTelemedicine: true,
    isInPerson: true,
  },
  {
    key: "cardiologyConsultation",
    doctorKey: "specialist",
    name: "Consulta Cardiologia Promptfoo",
    description: "Consulta de cardiologia para cenarios de ambiguidade",
    durationMinutes: 60,
    isTelemedicine: true,
    isInPerson: true,
  },
  {
    key: "cardiologyFollowUp",
    doctorKey: "specialist",
    name: "Consulta Cardiologia Promptfoo Retorno",
    description: "Retorno de cardiologia para cenarios de ambiguidade",
    durationMinutes: 30,
    isTelemedicine: true,
    isInPerson: true,
  },
  {
    key: "clinicConsultation",
    doctorKey: "ambiguousSameFirstName",
    name: "Consulta Clinica Promptfoo",
    description: "Consulta clínica para cenários de ambiguidade de médico",
    durationMinutes: 45,
    isTelemedicine: true,
    isInPerson: true,
  },
  {
    key: "telemedicineOnlyConsultation",
    doctorKey: "primary",
    name: "Teleconsulta Promptfoo",
    description: "Procedimento exclusivo de telemedicina para testes",
    durationMinutes: 45,
    isTelemedicine: true,
    isInPerson: false,
  },
  {
    key: "inPersonOnlyExam",
    doctorKey: "ambiguousSameFirstName",
    name: "Exame Presencial Promptfoo",
    description: "Procedimento exclusivo presencial para testes",
    durationMinutes: 45,
    isTelemedicine: false,
    isInPerson: true,
  },
  {
    key: "nightClinicConsultation",
    doctorKey: "nightClinician",
    name: "Consulta Clinica Medica Promptfoo",
    description: "Consulta clínica médica no turno da noite",
    durationMinutes: 60,
    isTelemedicine: true,
    isInPerson: true,
  },
] as const;

const DEFAULT_CLINIC_ADDRESS = "Rua Professor Otto Cirne, 20 - Funcionarios, Belo Horizonte/MG";

async function ensureClinic(ctx: any, clinicId: string, address?: string) {
  const existing = await ctx.db
    .query("clinics")
    .withIndex("by_clinicId", (q: any) => q.eq("clinicId", clinicId))
    .unique();

  const now = Date.now();
  const patch = {
    clinicId,
    name: "Promptfoo Eval Clinic",
    plan: "professional" as const,
    planStatus: "active" as const,
    phone: "+5511999990000",
    email: "promptfoo-clinic@example.test",
    address: address || DEFAULT_CLINIC_ADDRESS,
    updatedAt: now,
  };

  if (existing) {
    await ctx.db.patch(existing._id, patch);
    return await ctx.db.get(existing._id);
  }

  const id = await ctx.db.insert("clinics", {
    ...patch,
    createdAt: now,
  });
  return await ctx.db.get(id);
}

async function ensureAiSettings(
  ctx: any,
  clinicId: string,
  customInstructionsOverride?: string,
  enabledToolsOverride?: string[],
) {
  const rows = await ctx.db
    .query("aiSettings")
    .withIndex("by_clinic", (q: any) => q.eq("clinicId", clinicId))
    .collect();

  const now = Date.now();
  const latest = [...rows].sort(
    (a, b) => (b.updatedAt ?? b.createdAt ?? 0) - (a.updatedAt ?? a.createdAt ?? 0),
  )[0];

  const settings = {
    clinicId,
    enabled: true,
    tone: "empathetic" as const,
    escalationEnabled: true,
    escalationKeywords: [] as string[],
    activeHoursStart: "00:00",
    activeHoursEnd: "23:59",
    is247: true,
    voiceNotesEnabled: true,
    responseDelaySeconds: 0,
    enabledTools: enabledToolsOverride || ["scheduling", "documents", "patientData", "nps"],
    escalationTopics: {
      legal: true,
      medicalEmergency: true,
      complaints: true,
      customKeywords: [],
    },
    customInstructions:
      customInstructionsOverride ||
      "Ambiente de teste promptfoo. Ao responder sobre horários, use apenas os horários retornados pelas ferramentas. Mantenha respostas objetivas.",
    createdAt: latest?.createdAt ?? now,
    updatedAt: now,
  };

  if (latest) {
    await ctx.db.patch(latest._id, settings);
    return await ctx.db.get(latest._id);
  }

  const id = await ctx.db.insert("aiSettings", settings);
  return await ctx.db.get(id);
}

async function ensureReminderConfig(ctx: any, clinicId: string) {
  const existing = await ctx.db
    .query("reminderConfigs")
    .withIndex("by_clinic_type", (q: any) =>
      q.eq("clinicId", clinicId).eq("type", "appointmentConfirmation"),
    )
    .first();

  const now = Date.now();
  const doc = {
    clinicId,
    type: "appointmentConfirmation" as const,
    enabled: true,
    message:
      "Olá {{patient.name}}! ✅\n\nSua consulta foi agendada com sucesso!\n\n📅 Data: {{appointment.date}}\n⏰ Horário: {{appointment.time}}\n👨‍⚕️ Médico: {{appointment.doctor}}\n📋 Procedimento: {{appointment.procedure}}\n\nAguardamos você! 😊",
    channels: ["whatsapp"] as const,
    useOfficialApi: false,
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
  };

  if (existing) {
    await ctx.db.patch(existing._id, doc);
    return await ctx.db.get(existing._id);
  }

  const id = await ctx.db.insert("reminderConfigs", doc);
  return await ctx.db.get(id);
}

async function ensureWhatsappInstance(ctx: any, clinicId: string) {
  const existing = await ctx.db
    .query("whatsappInstances")
    .withIndex("by_clinic", (q: any) => q.eq("clinicId", clinicId))
    .first();

  const now = Date.now();
  const patch = {
    clinicId,
    instanceName: DEFAULT_INSTANCE_NAME,
    apikey: "promptfoo-dummy-key",
    status: "connected" as const,
    webhookConfigured: false,
    provider: "evolution" as const,
    updatedAt: now,
  };

  if (existing) {
    await ctx.db.patch(existing._id, patch);
    return await ctx.db.get(existing._id);
  }

  const id = await ctx.db.insert("whatsappInstances", {
    ...patch,
    createdAt: now,
  });
  return await ctx.db.get(id);
}

async function ensureDoctors(ctx: any, clinicId: string) {
  const doctors = [];
  for (const fixture of DOCTOR_FIXTURES) {
    const existing = await ctx.db
      .query("users")
      .withIndex("by_clinic_email", (q: any) =>
        q.eq("clinicId", clinicId).eq("email", fixture.email),
      )
      .first();

    const now = Date.now();
    const doctorDoc = {
      authUserId: fixture.authUserId,
      clinicId,
      email: fixture.email,
      name: fixture.name,
      role: "doctor" as const,
      isActive: true,
      specialties: [...fixture.specialties],
      workingHours: fixture.workingHours,
    };

    if (existing) {
      await ctx.db.patch(existing._id, doctorDoc);
      doctors.push({ key: fixture.key, doc: await ctx.db.get(existing._id) });
      continue;
    }

    const id = await ctx.db.insert("users", {
      ...doctorDoc,
      createdAt: now,
    });
    doctors.push({ key: fixture.key, doc: await ctx.db.get(id) });
  }

  return doctors;
}

async function ensureGoogleCalendarToken(ctx: any, clinicId: string, doctorId: string) {
  const existing = await ctx.db
    .query("googleOAuthTokens")
    .withIndex("by_clinic_user", (q: any) => q.eq("clinicId", clinicId).eq("userId", doctorId))
    .first();

  const now = Date.now();
  const tokenDoc = {
    clinicId,
    userId: doctorId,
    accessToken: "promptfoo-mock-access-token",
    refreshToken: "promptfoo-mock-refresh-token",
    expiresAt: now + 3600000, // 1 hour from now
    scope: "https://www.googleapis.com/auth/calendar",
    tokenType: "Bearer",
    primaryCalendarId: "primary",
    blockedCalendarIds: [],
    lastSyncAt: now,
    createdAt: now,
    updatedAt: now,
  };

  if (existing) {
    await ctx.db.patch(existing._id, tokenDoc);
    return await ctx.db.get(existing._id);
  }

  const id = await ctx.db.insert("googleOAuthTokens", tokenDoc);
  return await ctx.db.get(id);
}

async function ensureProcedures(ctx: any, clinicId: string, doctorsByKey: Map<string, any>) {
  const procedures = [];
  for (const fixture of PROCEDURE_FIXTURES) {
    const doctor = doctorsByKey.get(fixture.doctorKey);
    if (!doctor) {
      throw new Error(`Missing doctor fixture for procedure ${fixture.key}`);
    }

    const existing = await ctx.db
      .query("procedures")
      .withIndex("by_clinic_doctor", (q: any) =>
        q.eq("clinicId", clinicId).eq("doctorId", doctor._id),
      )
      .filter((q: any) => q.eq(q.field("name"), fixture.name))
      .first();

    const now = Date.now();
    const procedureDoc = {
      clinicId,
      doctorId: doctor._id,
      name: fixture.name,
      description: fixture.description,
      durationMinutes: fixture.durationMinutes,
      isActive: true,
      isTelemedicine: fixture.isTelemedicine,
      isInPerson: fixture.isInPerson,
      updatedAt: now,
    };

    if (existing) {
      await ctx.db.patch(existing._id, procedureDoc);
      procedures.push({
        key: fixture.key,
        doctorKey: fixture.doctorKey,
        doc: await ctx.db.get(existing._id),
      });
      continue;
    }

    const id = await ctx.db.insert("procedures", {
      ...procedureDoc,
      createdAt: now,
    });
    procedures.push({ key: fixture.key, doctorKey: fixture.doctorKey, doc: await ctx.db.get(id) });
  }

  return procedures;
}

async function ensurePatient(
  ctx: any,
  clinicId: string,
  phone: string,
  name: string,
  email?: string,
) {
  const normalizedPhone = phone.replace(/\D/g, "");
  const existing = await ctx.db
    .query("patients")
    .withIndex("by_clinic_phone", (q: any) =>
      q.eq("clinicId", clinicId).eq("phone", normalizedPhone),
    )
    .first();

  const now = Date.now();
  const patientDoc = {
    clinicId,
    name,
    phone: normalizedPhone,
    email,
    status: "active" as const,
    updatedAt: now,
  };

  if (existing) {
    await ctx.db.patch(existing._id, patientDoc);
    return await ctx.db.get(existing._id);
  }

  const id = await ctx.db.insert("patients", {
    ...patientDoc,
    createdAt: now,
  });
  return await ctx.db.get(id);
}

async function ensureChat(
  ctx: any,
  clinicId: string,
  patientId: string,
  phone: string,
  title: string,
) {
  const normalizedPhone = phone.replace(/\D/g, "");
  const whatsappChatId = `${normalizedPhone}@s.whatsapp.net`;
  const existing = await ctx.db
    .query("chats")
    .withIndex("by_clinic_whatsappId", (q: any) =>
      q.eq("clinicId", clinicId).eq("whatsappChatId", whatsappChatId),
    )
    .first();

  const now = Date.now();
  const chatDoc = {
    clinicId,
    patientId,
    whatsappChatId,
    title,
    status: "open" as const,
    isAiActive: true,
    needsHumanReview: false,
    unreadCount: 0,
    updatedAt: now,
  };

  if (existing) {
    await ctx.db.patch(existing._id, chatDoc);
    return await ctx.db.get(existing._id);
  }

  const id = await ctx.db.insert("chats", {
    ...chatDoc,
    createdAt: now,
  });
  return await ctx.db.get(id);
}

async function clearChatMessages(ctx: any, clinicId: string, chatId: string) {
  const messages = await ctx.db
    .query("messages")
    .withIndex("by_clinic_chat_sent", (q: any) => q.eq("clinicId", clinicId).eq("chatId", chatId))
    .collect();

  for (const message of messages) {
    await ctx.db.delete(message._id);
  }

  await ctx.db.patch(chatId, {
    lastMessage: undefined,
    lastMessageAt: undefined,
    lastActivityAt: undefined,
    unreadCount: 0,
    updatedAt: Date.now(),
  });
}

async function clearPatientAppointments(ctx: any, clinicId: string, patientId: string) {
  const appointments = await ctx.db
    .query("appointments")
    .withIndex("by_clinic_patient_date", (q: any) =>
      q.eq("clinicId", clinicId).eq("patientId", patientId),
    )
    .collect();

  const now = Date.now();
  for (const appointment of appointments) {
    if (!appointment.deletedAt) {
      await ctx.db.patch(appointment._id, {
        deletedAt: now,
        updatedAt: now,
      });
    }
  }
}

async function clearClinicAppointments(ctx: any, clinicId: string) {
  const appointments = await ctx.db
    .query("appointments")
    .withIndex("by_clinic_date", (q: any) => q.eq("clinicId", clinicId))
    .collect();

  const now = Date.now();
  for (const appointment of appointments) {
    if (!appointment.deletedAt) {
      await ctx.db.patch(appointment._id, {
        deletedAt: now,
        status: "cancelled",
        updatedAt: now,
      });
    }
  }

  const reminders = await ctx.db
    .query("appointmentReminders")
    .withIndex("by_clinic_type_sentAt", (q: any) => q.eq("clinicId", clinicId))
    .collect();

  for (const reminder of reminders) {
    await ctx.db.delete(reminder._id);
  }
}

async function createExistingAppointment(
  ctx: any,
  clinicId: string,
  patient: any,
  doctor: any,
  procedure: any,
  startAt: number,
  status: "pending" | "confirmed" | "completed" | "arrived",
  rescheduleStatus: "none" | "awaiting_response" | "rescheduled",
  isTelemedicine: boolean,
) {
  const endAt = startAt + procedure.durationMinutes * 60 * 1000;
  const now = Date.now();

  const appointmentId = await ctx.db.insert("appointments", {
    clinicId,
    patientId: patient._id,
    doctorId: doctor._id,
    doctor: doctor.name,
    procedureId: procedure._id,
    procedure: procedure.name,
    startAt,
    endAt,
    status,
    createdAt: now,
    updatedAt: now,
    rescheduleStatus,
    isTelemedicine,
    patientEmail: isTelemedicine ? patient.email : undefined,
    doctorEmail: isTelemedicine ? doctor.email : undefined,
    timeZone: isTelemedicine ? BRAZIL_TIME_ZONE : undefined,
  });

  return await ctx.db.get(appointmentId);
}

async function seedConfirmedBookingHistory(
  ctx: any,
  clinicId: string,
  chatId: string,
  appointment: any,
  doctor: any,
  procedure: any,
) {
  if (!appointment) return;

  const baseTimestamp = Date.now() - 5000;
  const appointmentDate = new Date(appointment.startAt).toLocaleDateString("pt-BR", {
    timeZone: BRAZIL_TIME_ZONE,
  });
  const appointmentTime = new Date(appointment.startAt).toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: BRAZIL_TIME_ZONE,
  });

  await ctx.db.insert("messages", {
    clinicId,
    chatId,
    direction: "in",
    type: "text",
    body: "Sim",
    status: "delivered",
    sentAt: baseTimestamp,
    createdAt: baseTimestamp,
    provider: "evolution",
  } as any);

  await ctx.db.insert("messages", {
    clinicId,
    chatId,
    direction: "out",
    type: "text",
    body: `Agendamento confirmado! Consulta presencial com ${doctor.name} em ${appointmentDate} às ${appointmentTime}. ID do agendamento: ${appointment._id}. Procedimento: ${procedure.name}.`,
    status: "sent",
    sentAt: baseTimestamp + 1000,
    createdAt: baseTimestamp + 1000,
  } as any);

  await ctx.db.patch(chatId, {
    lastMessage: `Agendamento confirmado! Consulta presencial com ${doctor.name} em ${appointmentDate} às ${appointmentTime}. ID do agendamento: ${appointment._id}. Procedimento: ${procedure.name}.`,
    lastMessageAt: baseTimestamp + 1000,
    lastActivityAt: baseTimestamp + 1000,
    updatedAt: Date.now(),
  });
}

function makeTurnMessageId(patientPhone: string, text: string) {
  const normalizedPhone = patientPhone.replace(/\D/g, "");
  const compactText = text
    .normalize("NFD")
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 24);
  return `pf-${normalizedPhone}-${compactText}-${Date.now()}`;
}

function decodeBase64ToBlob(base64Data: string, mimeType: string) {
  const binary = atob(base64Data);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return new Blob([bytes], { type: mimeType });
}

function formatMediaPlaceholder(mediaType: "audio" | "image" | "document", fileName: string) {
  if (mediaType === "audio") return `[Audio: ${fileName}]`;
  if (mediaType === "image") return `[Imagem: ${fileName}]`;
  return `[Documento: ${fileName}]`;
}

export const ensureFixtures = internalMutation({
  args: {
    clinicId: v.optional(v.string()),
    clinicAddress: v.optional(v.string()),
    patientPhone: v.string(),
    patientName: v.string(),
    patientEmail: v.optional(v.string()),
    customInstructions: v.optional(v.string()),
    enabledTools: v.optional(v.array(v.string())),
    targetDoctorKey: v.optional(v.string()),
    targetProcedureKey: v.optional(v.string()),
    resetConversation: v.optional(v.boolean()),
    createInitialAppointment: v.optional(v.boolean()),
    seedConfirmedHistory: v.optional(v.boolean()),
    initialAppointmentStartAt: v.optional(v.number()),
    initialAppointmentStatus: v.optional(
      v.union(
        v.literal("pending"),
        v.literal("confirmed"),
        v.literal("completed"),
        v.literal("arrived"),
      ),
    ),
    initialRescheduleStatus: v.optional(
      v.union(v.literal("none"), v.literal("awaiting_response"), v.literal("rescheduled")),
    ),
    initialAppointmentIsTelemedicine: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const clinicId = args.clinicId || DEFAULT_CLINIC_ID;
    await ensureClinic(ctx, clinicId, args.clinicAddress);
    await ensureAiSettings(ctx, clinicId, args.customInstructions, args.enabledTools);
    await ensureReminderConfig(ctx, clinicId);
    await ensureWhatsappInstance(ctx, clinicId);

    const doctorEntries = await ensureDoctors(ctx, clinicId);
    const doctorsByKey = new Map<string, any>(doctorEntries.map((entry) => [entry.key, entry.doc]));
    for (const doctorEntry of doctorEntries) {
      await ensureGoogleCalendarToken(ctx, clinicId, doctorEntry.doc!._id);
    }
    const procedureEntries = await ensureProcedures(ctx, clinicId, doctorsByKey);
    const proceduresByKey = new Map<string, any>(
      procedureEntries.map((entry) => [entry.key, entry.doc]),
    );
    const doctor = doctorsByKey.get(args.targetDoctorKey || "primary");
    const procedure = proceduresByKey.get(args.targetProcedureKey || "primaryConsultation");
    if (!doctor) {
      throw new Error(`Unknown targetDoctorKey: ${args.targetDoctorKey}`);
    }
    if (!procedure) {
      throw new Error(`Unknown targetProcedureKey: ${args.targetProcedureKey}`);
    }
    const patient = await ensurePatient(
      ctx,
      clinicId,
      args.patientPhone,
      args.patientName,
      args.patientEmail,
    );
    const chat = await ensureChat(ctx, clinicId, patient!._id, args.patientPhone, args.patientName);

    await clearClinicAppointments(ctx, clinicId);

    if (args.resetConversation !== false) {
      await clearChatMessages(ctx, clinicId, chat!._id);
    }

    let appointment = null;
    if (args.createInitialAppointment) {
      await clearPatientAppointments(ctx, clinicId, patient!._id);
      if (!args.initialAppointmentStartAt) {
        throw new Error("initialAppointmentStartAt is required when createInitialAppointment=true");
      }
      appointment = await createExistingAppointment(
        ctx,
        clinicId,
        patient,
        doctor,
        procedure,
        args.initialAppointmentStartAt,
        args.initialAppointmentStatus || "confirmed",
        args.initialRescheduleStatus || "none",
        args.initialAppointmentIsTelemedicine || false,
      );

      if (args.seedConfirmedHistory) {
        await seedConfirmedBookingHistory(ctx, clinicId, chat!._id, appointment, doctor, procedure);
      }
    }

    return {
      clinicId,
      doctorId: doctor!._id,
      doctorName: doctor!.name,
      procedureId: procedure!._id,
      procedureName: procedure!.name,
      doctors: doctorEntries.map((entry) => ({
        key: entry.key,
        id: entry.doc!._id,
        name: entry.doc!.name,
        specialties: entry.doc!.specialties || [],
      })),
      procedures: procedureEntries.map((entry) => ({
        key: entry.key,
        id: entry.doc!._id,
        doctorKey: entry.doctorKey,
        doctorId: entry.doc!.doctorId,
        name: entry.doc!.name,
      })),
      patientId: patient!._id,
      patientPhone: patient!.phone,
      patientEmail: patient!.email,
      chatId: chat!._id,
      appointmentId: appointment?._id ?? null,
      instanceName: DEFAULT_INSTANCE_NAME,
      timeZone: BRAZIL_TIME_ZONE,
    };
  },
});

export const appendIncomingMessage = internalMutation({
  args: {
    clinicId: v.optional(v.string()),
    patientPhone: v.string(),
    patientName: v.string(),
    patientEmail: v.optional(v.string()),
    text: v.string(),
  },
  handler: async (ctx, args) => {
    const clinicId = args.clinicId || DEFAULT_CLINIC_ID;
    const patient = await ensurePatient(
      ctx,
      clinicId,
      args.patientPhone,
      args.patientName,
      args.patientEmail,
    );
    const chat = await ensureChat(ctx, clinicId, patient!._id, args.patientPhone, args.patientName);
    const now = Date.now();
    const messageId = await ctx.db.insert("messages", {
      clinicId,
      chatId: chat!._id,
      patientId: patient!._id,
      direction: "in",
      type: "text",
      body: args.text,
      status: "delivered",
      sentAt: now,
      createdAt: now,
      whatsappMessageId: makeTurnMessageId(args.patientPhone, args.text),
      provider: "evolution",
    } as any);

    await ctx.db.patch(chat!._id, {
      patientId: patient!._id,
      title: args.patientName,
      lastMessage: args.text,
      lastMessageAt: now,
      lastActivityAt: now,
      unreadCount: (chat!.unreadCount || 0) + 1,
      status: "open",
      isAiActive: true,
      needsHumanReview: false,
      updatedAt: now,
    });

    return {
      clinicId,
      chatId: chat!._id,
      patientId: patient!._id,
      messageId,
    };
  },
});

export const appendIncomingMediaMessageWithStorageId = internalMutation({
  args: {
    clinicId: v.optional(v.string()),
    patientPhone: v.string(),
    patientName: v.string(),
    patientEmail: v.optional(v.string()),
    mediaType: v.union(v.literal("audio"), v.literal("image"), v.literal("document")),
    mimeType: v.string(),
    fileName: v.string(),
    storageId: v.id("_storage"),
    caption: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const clinicId = args.clinicId || DEFAULT_CLINIC_ID;
    const patient = await ensurePatient(
      ctx,
      clinicId,
      args.patientPhone,
      args.patientName,
      args.patientEmail,
    );
    const chat = await ensureChat(ctx, clinicId, patient!._id, args.patientPhone, args.patientName);
    const now = Date.now();
    const lastMessage =
      args.caption?.trim() || formatMediaPlaceholder(args.mediaType, args.fileName);
    const messageId = await ctx.db.insert("messages", {
      clinicId,
      chatId: chat!._id,
      patientId: patient!._id,
      direction: "in",
      type: "media",
      body: args.caption?.trim() || "",
      status: "delivered",
      sentAt: now,
      createdAt: now,
      whatsappMessageId: makeTurnMessageId(args.patientPhone, `${args.mediaType}-${args.fileName}`),
      provider: "evolution",
      mediaStorageId: args.storageId,
      mediaType: args.mediaType,
      mediaMimetype: args.mimeType,
      mediaFileName: args.fileName,
      mediaStatus: "ready",
      transcriptionStatus: args.mediaType === "audio" ? "pending" : undefined,
    } as any);

    await ctx.db.patch(chat!._id, {
      patientId: patient!._id,
      title: args.patientName,
      lastMessage,
      lastMessageAt: now,
      lastActivityAt: now,
      unreadCount: (chat!.unreadCount || 0) + 1,
      status: "open",
      isAiActive: true,
      needsHumanReview: false,
      updatedAt: now,
    });

    return {
      clinicId,
      chatId: chat!._id,
      patientId: patient!._id,
      messageId,
      mediaStorageId: args.storageId,
    };
  },
});

export const appendIncomingMediaMessage = internalAction({
  args: {
    clinicId: v.optional(v.string()),
    patientPhone: v.string(),
    patientName: v.string(),
    patientEmail: v.optional(v.string()),
    mediaType: v.union(v.literal("audio"), v.literal("image"), v.literal("document")),
    mimeType: v.string(),
    fileName: v.string(),
    base64Data: v.string(),
    caption: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const storageId = await ctx.storage.store(decodeBase64ToBlob(args.base64Data, args.mimeType));
    return await ctx.runMutation(
      internalAny.promptfooHarness.appendIncomingMediaMessageWithStorageId,
      {
        clinicId: args.clinicId,
        patientPhone: args.patientPhone,
        patientName: args.patientName,
        patientEmail: args.patientEmail,
        mediaType: args.mediaType,
        mimeType: args.mimeType,
        fileName: args.fileName,
        storageId,
        caption: args.caption,
      },
    );
  },
});

export const simulateIncomingTurn = internalAction({
  args: {
    clinicId: v.optional(v.string()),
    patientPhone: v.string(),
    patientName: v.string(),
    patientEmail: v.optional(v.string()),
    text: v.optional(v.string()),
    mediaType: v.optional(v.union(v.literal("audio"), v.literal("image"), v.literal("document"))),
    mimeType: v.optional(v.string()),
    fileName: v.optional(v.string()),
    base64Data: v.optional(v.string()),
    fixtureName: v.optional(v.string()),
    caption: v.optional(v.string()),
    forceLiveAgent: v.optional(v.boolean()),
    skipOutboundDelivery: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const hasMedia = !!args.mediaType;
    if (hasMedia && !args.fixtureName && (!args.mimeType || !args.fileName || !args.base64Data)) {
      throw new Error("fixtureName or mimeType/fileName/base64Data are required for media turns");
    }
    if (!hasMedia && !args.text?.trim()) {
      throw new Error("text is required for text turns");
    }

    let incoming;
    if (hasMedia) {
      if (args.fixtureName) {
        const storedFixture = await ctx.runAction(internalAny.promptfooFixtures.storeFixture, {
          fixtureName: args.fixtureName,
        });
        incoming = await ctx.runMutation(
          internalAny.promptfooHarness.appendIncomingMediaMessageWithStorageId,
          {
            clinicId: args.clinicId || DEFAULT_CLINIC_ID,
            patientPhone: args.patientPhone,
            patientName: args.patientName,
            patientEmail: args.patientEmail,
            mediaType: storedFixture.mediaType,
            mimeType: storedFixture.mimeType,
            fileName: storedFixture.fileName,
            storageId: storedFixture.storageId,
            caption: args.caption,
          },
        );
      } else {
        incoming = await ctx.runAction(internalAny.promptfooHarness.appendIncomingMediaMessage, {
          clinicId: args.clinicId || DEFAULT_CLINIC_ID,
          patientPhone: args.patientPhone,
          patientName: args.patientName,
          patientEmail: args.patientEmail,
          mediaType: args.mediaType,
          mimeType: args.mimeType,
          fileName: args.fileName,
          base64Data: args.base64Data,
          caption: args.caption,
        });
      }
    } else {
      incoming = await ctx.runMutation(internalAny.promptfooHarness.appendIncomingMessage, {
        clinicId: args.clinicId || DEFAULT_CLINIC_ID,
        patientPhone: args.patientPhone,
        patientName: args.patientName,
        patientEmail: args.patientEmail,
        text: args.text,
      });
    }

    const result = await ctx.runAction(internalAny.automationAi.processIncomingAiMessage, {
      clinicId: incoming.clinicId,
      chatId: incoming.chatId,
      messageId: incoming.messageId,
      patientId: incoming.patientId,
      disableDeterministicShortcuts: args.forceLiveAgent,
      skipOutboundDelivery: args.skipOutboundDelivery !== false,
    });

    const state = await ctx.runQuery(internalAny.promptfooHarness.getScenarioState, {
      clinicId: incoming.clinicId,
      patientPhone: args.patientPhone,
    });
    const latestOutgoing = [...(state.outgoingMessages || [])].pop();

    return {
      ...incoming,
      response: result?.aiResponse || latestOutgoing?.body || null,
      model: result?.model || null,
      reason: result?.reason || null,
      error: result?.error || null,
      escalated: result?.escalated || false,
      processed: result?.processed || false,
    };
  },
});

export const simulatePatientMessage = internalAction({
  args: {
    clinicId: v.optional(v.string()),
    patientPhone: v.string(),
    patientName: v.string(),
    patientEmail: v.optional(v.string()),
    text: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.runAction(internalAny.promptfooHarness.simulateIncomingTurn, {
      clinicId: args.clinicId,
      patientPhone: args.patientPhone,
      patientName: args.patientName,
      patientEmail: args.patientEmail,
      text: args.text,
      skipOutboundDelivery: true,
    });
  },
});

export const getScenarioState = internalQuery({
  args: {
    clinicId: v.optional(v.string()),
    patientPhone: v.string(),
  },
  handler: async (ctx, args) => {
    const clinicId = args.clinicId || DEFAULT_CLINIC_ID;
    const phone = args.patientPhone.replace(/\D/g, "");
    const patient = await ctx.db
      .query("patients")
      .withIndex("by_clinic_phone", (q: any) => q.eq("clinicId", clinicId).eq("phone", phone))
      .first();

    const chat = await ctx.db
      .query("chats")
      .withIndex("by_clinic_whatsappId", (q: any) =>
        q.eq("clinicId", clinicId).eq("whatsappChatId", `${phone}@s.whatsapp.net`),
      )
      .first();

    const messages = chat
      ? await ctx.db
          .query("messages")
          .withIndex("by_clinic_chat_sent", (q: any) =>
            q.eq("clinicId", clinicId).eq("chatId", chat._id),
          )
          .order("desc")
          .take(30)
      : [];

    const appointments = patient
      ? await ctx.db
          .query("appointments")
          .withIndex("by_clinic_patient_date", (q: any) =>
            q.eq("clinicId", clinicId).eq("patientId", patient._id),
          )
          .collect()
      : [];

    const activeAppointments = appointments
      .filter((appointment) => !appointment.deletedAt && appointment.status !== "cancelled")
      .sort((a, b) => a.startAt - b.startAt);

    const appointmentIds = activeAppointments.map((appointment) => appointment._id);
    const reminderLogs = [];
    for (const appointmentId of appointmentIds) {
      const entries = await ctx.db
        .query("appointmentReminders")
        .withIndex("by_appointment_type", (q: any) => q.eq("appointmentId", appointmentId))
        .collect();
      reminderLogs.push(...entries);
    }

    return {
      patient: patient
        ? {
            id: patient._id,
            name: patient.name,
            phone: patient.phone,
            email: patient.email,
            documents: {
              insuranceCardFront: !!patient.insuranceCardFrontStorageId,
              insuranceCardBack: !!patient.insuranceCardBackStorageId,
              insuranceCardAny: !!patient.insuranceCardStorageId,
              idCard: !!patient.idCardStorageId,
              referral: !!patient.referralStorageId,
            },
          }
        : null,
      chat: chat
        ? {
            id: chat._id,
            title: chat.title,
            status: chat.status,
            isAiActive: chat.isAiActive !== false,
            needsHumanReview: chat.needsHumanReview === true,
          }
        : null,
      appointments: activeAppointments.map((appointment) => ({
        id: appointment._id,
        startAt: appointment.startAt,
        endAt: appointment.endAt,
        status: appointment.status,
        rescheduleStatus: appointment.rescheduleStatus || "none",
        doctorId: appointment.doctorId,
        doctor: appointment.doctor,
        procedureId: appointment.procedureId,
        procedure: appointment.procedure,
        isTelemedicine: appointment.isTelemedicine || false,
        meetingLink: appointment.meetingLink || null,
        meetingError: appointment.meetingError || null,
        patientEmail: appointment.patientEmail || null,
        doctorEmail: appointment.doctorEmail || null,
      })),
      outgoingMessages: messages
        .filter((message) => message.direction === "out" && !message.isInternal)
        .reverse()
        .map((message) => ({
          id: message._id,
          body: message.body,
          status: message.status,
          sentAt: message.sentAt,
          replyToId: message.replyToId || null,
        })),
      internalToolMessages: messages
        .filter((message) => message.isInternal)
        .reverse()
        .map((message) => ({
          id: message._id,
          body: message.body,
          role: message.internalRole || null,
          toolName: message.toolName || null,
          toolCallId: message.toolCallId || null,
          sentAt: message.sentAt,
        })),
      incomingMessages: messages
        .filter((message) => message.direction === "in")
        .reverse()
        .map((message) => ({
          id: message._id,
          body: message.body,
          sentAt: message.sentAt,
          mediaType: message.mediaType || null,
          mediaMimetype: message.mediaMimetype || null,
          mediaFileName: message.mediaFileName || null,
          mediaStatus: message.mediaStatus || null,
          transcribedText: message.transcribedText || null,
          transcriptionStatus: message.transcriptionStatus || null,
          extractedData: message.extractedData || null,
        })),
      reminderLogs: reminderLogs.map((entry) => ({
        appointmentId: entry.appointmentId,
        reminderType: entry.reminderType,
        status: entry.status,
        channels: entry.channels,
        sentAt: entry.sentAt || null,
        lastError: entry.lastError || null,
      })),
    };
  },
});
