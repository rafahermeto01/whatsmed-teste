import { v } from "convex/values";

import { api, internal } from "./_generated/api";
import { mutation, query, action, internalQuery } from "./_generated/server";
import { buildDefaultReminderConfigs } from "./automationDefaults";
import { badRequest } from "./lib/errors";
import { requireClinicAccess, requireClinicRole, requireRole } from "./lib/rbac";
import { isValidCpfCnpj, normalizeCpfCnpj } from "./lib/validators";
import { generateSecureToken } from "./lib/security";

const clinicPlanValidator = v.union(
  v.literal("free"),
  v.literal("starter"),
  v.literal("professional"),
  v.literal("enterprise"),
);

async function seedDefaultReminderConfigs(ctx: any, clinicId: string, now: number) {
  const reminderConfigs = buildDefaultReminderConfigs(clinicId, now);

  for (const config of reminderConfigs) {
    await ctx.db.insert("reminderConfigs", config);
  }
}

export const getClinic = query({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    await requireClinicAccess(ctx, args.clinicId);
    return await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .unique();
  },
});

export const getClinicInternal = internalQuery({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .unique();
  },
});

export const internalListAll = internalQuery({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("clinics").collect();
  },
});

export const listAll = query({
  args: {},
  handler: async (ctx) => {
    await requireRole(ctx, ["super_admin"]);
    const clinics = await ctx.db.query("clinics").collect();
    return clinics;
  },
});

export const upsertClinic = mutation({
  args: {
    clinicId: v.string(),
    name: v.string(),
    plan: v.optional(clinicPlanValidator),
    cpfCnpj: v.optional(v.string()),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    address: v.optional(v.string()),
    website: v.optional(v.string()),
    logoUrl: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireClinicRole(ctx, args.clinicId, ["admin", "super_admin"]);

    const cpfCnpj = args.cpfCnpj ? normalizeCpfCnpj(args.cpfCnpj) : undefined;
    if (cpfCnpj && !isValidCpfCnpj(cpfCnpj)) {
      throw badRequest("CPF/CNPJ inválido.");
    }

    const existing = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .unique();

    if (existing) {
      // Only update if there are actual changes to avoid infinite loops
      const hasChanges =
        existing.name !== args.name ||
        existing.cpfCnpj !== cpfCnpj ||
        existing.email !== args.email ||
        existing.phone !== args.phone ||
        existing.address !== args.address ||
        existing.website !== args.website ||
        existing.logoUrl !== args.logoUrl;

      if (hasChanges) {
        await ctx.db.patch(existing._id, {
          name: args.name,
          cpfCnpj,
          email: args.email,
          phone: args.phone,
          address: args.address,
          website: args.website,
          logoUrl: args.logoUrl,
          updatedAt: Date.now(),
        });
      }
      return existing._id;
    } else {
      const clinicDocId = await ctx.db.insert("clinics", {
        clinicId: args.clinicId,
        name: args.name,
        plan: args.plan ?? "free",
        planStatus: "active",
        cpfCnpj,
        email: args.email,
        phone: args.phone,
        address: args.address,
        website: args.website,
        logoUrl: args.logoUrl,
        createdAt: Date.now(),
      });

      await seedDefaultReminderConfigs(ctx, args.clinicId, Date.now());

      return clinicDocId;
    }
  },
});

export const createClinic = action({
  args: {
    clinicId: v.string(),
    name: v.string(),
    plan: v.optional(clinicPlanValidator),
  },
  handler: async (ctx, args): Promise<any> => {
    // Get user identity to check role
    const identity = await ctx.auth.getUserIdentity();
    if (!identity || !identity.email) {
      throw new Error("Unauthorized");
    }

    // Check role from users table
    const user = await ctx.runQuery(api.users.getByEmail, { email: identity.email });
    if (!user || user.role !== "super_admin") {
      throw new Error("Super admin only");
    }

    // Create clinic using mutation
    await ctx.runMutation(api.clinics.upsertClinic, {
      clinicId: args.clinicId,
      name: args.name,
      plan: args.plan,
    });

    // Return the created clinic
    return await ctx.runQuery(internal.clinics.getClinicInternal, {
      clinicId: args.clinicId,
    });
  },
});

export const setClinicPlan = mutation({
  args: {
    clinicId: v.string(),
    plan: clinicPlanValidator,
  },
  handler: async (ctx, args) => {
    await requireRole(ctx, ["super_admin"]);

    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .unique();

    if (!clinic) {
      throw new Error("Clinic not found");
    }

    await ctx.db.patch(clinic._id, {
      plan: args.plan,
      planStatus: "active",
      asaasSubscriptionId: undefined,
      planValue: undefined,
      planNextDueDate: undefined,
      planCycle: undefined,
      updatedAt: Date.now(),
    });

    return await ctx.db.get(clinic._id);
  },
});

export const updateClinicBillingInfo = mutation({
  args: {
    clinicId: v.string(),
    cpfCnpj: v.string(),
  },
  handler: async (ctx, args) => {
    await requireClinicRole(ctx, args.clinicId, ["admin", "super_admin"]);

    const cpfCnpj = normalizeCpfCnpj(args.cpfCnpj);
    if (!isValidCpfCnpj(cpfCnpj)) {
      throw badRequest("CPF/CNPJ inválido.");
    }

    const existing = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .unique();

    if (existing) {
      // Only update if cpfCnpj is not already set
      if (!existing.cpfCnpj) {
        await ctx.db.patch(existing._id, {
          cpfCnpj,
          updatedAt: Date.now(),
        });
      }
      return existing._id;
    } else {
      // Create minimal clinic record
      return await ctx.db.insert("clinics", {
        clinicId: args.clinicId,
        name: "Clínica",
        cpfCnpj,
        createdAt: Date.now(),
      });
    }
  },
});

export const createOwnClinic = mutation({
  args: {
    name: v.string(),
    cpfCnpj: v.string(),
    phone: v.optional(v.string()),
    address: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new Error("Unauthorized");
    }

    // Generate a random clinic ID
    const clinicId = generateSecureToken(16);
    const cpfCnpj = normalizeCpfCnpj(args.cpfCnpj);
    if (!isValidCpfCnpj(cpfCnpj)) {
      throw badRequest("CPF/CNPJ inválido.");
    }

    const now = Date.now();

    // 1. Create Clinic
    await ctx.db.insert("clinics", {
      clinicId,
      name: args.name,
      cpfCnpj,
      phone: args.phone,
      address: args.address,
      createdAt: now,
      plan: "free",
      planStatus: "active",
    });

    await seedDefaultReminderConfigs(ctx, clinicId, now);

    // 2. Add User as Admin in clinicMembers
    await ctx.db.insert("clinicMembers", {
      clinicId,
      userId: identity.subject,
      role: "admin",
      createdAt: now,
    });

    // 3. Update userClinics table
    const userClinics = await ctx.db
      .query("userClinics")
      .withIndex("by_user", (q) => q.eq("userId", identity.subject))
      .unique();

    if (userClinics) {
      await ctx.db.patch(userClinics._id, {
        clinics: [...userClinics.clinics, { clinicId, role: "admin" }],
        updatedAt: now,
      });
    } else {
      await ctx.db.insert("userClinics", {
        userId: identity.subject,
        clinics: [{ clinicId, role: "admin" }],
        createdAt: now,
      });
    }

    // 4. Switch User Context
    const user = await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", identity.email!))
      .unique();

    if (user) {
      await ctx.db.patch(user._id, {
        clinicId,
        role: "admin",
      });
    }

    return clinicId;
  },
});
