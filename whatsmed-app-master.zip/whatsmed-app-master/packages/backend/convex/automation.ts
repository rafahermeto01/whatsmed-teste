import { v } from "convex/values";

import { internal } from "./_generated/api";
import { internalMutation, internalQuery, query, mutation } from "./_generated/server";
import { buildDefaultReminderConfigs } from "./automationDefaults";
import { authComponent } from "./auth";
import { cleanPhone } from "./lib/phoneUtils";
import { clearAgentCache } from "../mastra/agentCache";

const internalAny = internal as any;

const DEFAULT_ESCALATION_TOPICS = {
  legal: true,
  medicalEmergency: true,
  complaints: true,
  customKeywords: [],
};

const DEFAULT_ENABLED_TOOLS = ["scheduling", "nps", "documents", "patientData"];

// Helper to get authenticated user and clinicId
async function getAuth(ctx: any): Promise<{ user: any; clinicId: string }> {
  const authUser = await authComponent.getAuthUser(ctx);
  if (!authUser) {
    throw new Error("Não autenticado");
  }

  // Try to find app user to get reliable clinicId
  const appUser = await ctx.db
    .query("users")
    .withIndex("by_email", (q: any) => q.eq("email", authUser.email))
    .first();

  const clinicId = appUser?.clinicId || (authUser as any).clinicId;

  // Return appUser if found (contains role), otherwise fallback to authUser
  return { user: appUser || authUser, clinicId: clinicId as string };
}

function pickLatestAiSettings(records: any[]) {
  if (!records || records.length === 0) return null;
  return [...records].sort(
    (a, b) => (b.updatedAt ?? b.createdAt ?? 0) - (a.updatedAt ?? a.createdAt ?? 0),
  )[0];
}

async function getAiSettingsRows(ctx: any, clinicId: string) {
  return await ctx.db
    .query("aiSettings")
    .withIndex("by_clinic", (q: any) => q.eq("clinicId", clinicId))
    .collect();
}

function buildDefaultAiSettings(
  clinicId: string,
  now: number,
  overrides: Record<string, any> = {},
): any {
  return {
    clinicId,
    enabled: true,
    tone: "empathetic" as const,
    activeHoursStart: "08:00",
    activeHoursEnd: "18:00",
    is247: false,
    voiceNotesEnabled: true,
    responseDelaySeconds: 0,
    escalationTopics: { ...DEFAULT_ESCALATION_TOPICS },
    enabledTools: [...DEFAULT_ENABLED_TOOLS],
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

async function getCanonicalAiSettingsRow(ctx: any, clinicId: string) {
  const existingRows = await getAiSettingsRows(ctx, clinicId);
  const existing = pickLatestAiSettings(existingRows);

  if (existingRows.length > 1 && existing) {
    const duplicates = existingRows.filter((row: any) => row._id !== existing._id);
    for (const duplicate of duplicates) {
      await ctx.db.delete(duplicate._id);
    }
    console.warn(
      `[automation] Removed ${duplicates.length} duplicate aiSettings rows for clinic ${clinicId}`,
    );
  }

  return existing;
}

async function syncActivePromptToAiSettings(
  ctx: any,
  clinicId: string,
  activePromptId: any,
  customInstructions: string | undefined,
) {
  const now = Date.now();
  const existing = await getCanonicalAiSettingsRow(ctx, clinicId);

  if (existing) {
    await ctx.db.patch(existing._id, {
      activePromptId,
      customInstructions,
      updatedAt: now,
    });
    return existing._id;
  }

  return await ctx.db.insert(
    "aiSettings",
    buildDefaultAiSettings(clinicId, now, {
      activePromptId,
      customInstructions,
    }),
  );
}

function clearClinicAgentCache(clinicId: string) {
  try {
    clearAgentCache(clinicId);
    console.log(`[automation] Agent cache cleared for clinic ${clinicId}.`);
  } catch (e) {
    console.error("[automation] Failed to clear agent cache:", e);
  }
}

async function getAuthorizedAiClinic(ctx: any, requestedClinicId: string) {
  const { clinicId: authClinicId, user } = await getAuth(ctx);

  if (!["admin", "super_admin"].includes(user?.role)) {
    throw new Error("Insufficient permissions");
  }

  const targetClinicId = user?.role === "super_admin" ? requestedClinicId : authClinicId;

  if (user?.role !== "super_admin" && requestedClinicId !== authClinicId) {
    throw new Error("Access denied to this clinic");
  }

  return { user, targetClinicId, authClinicId };
}

function validatePromptName(name: string) {
  const trimmed = name.trim();
  if (!trimmed) {
    throw new Error("Prompt name is required");
  }
  if (trimmed.length > 80) {
    throw new Error("Prompt name must be at most 80 characters");
  }
  return trimmed;
}

function validatePromptContent(content: string) {
  if (content.length > 20000) {
    throw new Error("Prompt content must be at most 20000 characters");
  }
  return content;
}

async function getPromptForClinic(ctx: any, promptId: any, clinicId: string) {
  const prompt = await ctx.db.get(promptId);
  if (!prompt || prompt.clinicId !== clinicId) {
    throw new Error("Prompt not found");
  }
  return prompt;
}

function toWhatsAppChatId(phone: string): string | null {
  const digits = cleanPhone(phone || "");
  if (!digits) return null;

  const normalized = digits.length < 12 ? `55${digits}` : digits;
  return `${normalized}@s.whatsapp.net`;
}

// ============================================
// AI SETTINGS MODULE
// ============================================

/**
 * Get AI settings for a clinic
 */
export const getAiSettings = query({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    // Verify user has access to this clinic
    if (args.clinicId !== clinicId) {
      throw new Error("Access denied");
    }

    const settings = pickLatestAiSettings(await getAiSettingsRows(ctx, args.clinicId));

    if (!settings) {
      return settings;
    }

    return {
      ...settings,
      voiceNotesEnabled: true,
    };
  },
});

/**
 * Internal: Get AI settings for a clinic (no auth check)
 * Used by automation agents
 */
export const getAiSettingsInternal = internalQuery({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const settings = pickLatestAiSettings(await getAiSettingsRows(ctx, args.clinicId));

    if (!settings) {
      return settings;
    }

    return {
      ...settings,
      voiceNotesEnabled: true,
    };
  },
});

export const listAiSystemPrompts = query({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    if (args.clinicId !== clinicId) {
      throw new Error("Access denied");
    }

    const [prompts, settings] = await Promise.all([
      ctx.db
        .query("aiSystemPrompts")
        .withIndex("by_clinic", (q: any) => q.eq("clinicId", args.clinicId))
        .collect(),
      getAiSettingsRows(ctx, args.clinicId).then((rows) => pickLatestAiSettings(rows)),
    ]);

    return [...prompts]
      .sort((a, b) => (b.updatedAt ?? b.createdAt ?? 0) - (a.updatedAt ?? a.createdAt ?? 0))
      .map((prompt) => ({
        ...prompt,
        isActive: settings?.activePromptId === prompt._id,
      }));
  },
});

export const createAiSystemPrompt = mutation({
  args: {
    clinicId: v.string(),
    name: v.string(),
    content: v.string(),
    makeActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const { targetClinicId } = await getAuthorizedAiClinic(ctx, args.clinicId);
    const now = Date.now();
    const name = validatePromptName(args.name);
    const content = validatePromptContent(args.content);
    const existingSettings = await getCanonicalAiSettingsRow(ctx, targetClinicId);

    const promptId = await ctx.db.insert("aiSystemPrompts", {
      clinicId: targetClinicId,
      name,
      content,
      createdAt: now,
      updatedAt: now,
    });

    const shouldActivate = args.makeActive ?? !existingSettings?.activePromptId;

    if (shouldActivate) {
      await syncActivePromptToAiSettings(ctx, targetClinicId, promptId, content);
      clearClinicAgentCache(targetClinicId);
    }

    return await ctx.db.get(promptId);
  },
});

export const updateAiSystemPrompt = mutation({
  args: {
    clinicId: v.string(),
    promptId: v.id("aiSystemPrompts"),
    name: v.optional(v.string()),
    content: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { targetClinicId } = await getAuthorizedAiClinic(ctx, args.clinicId);
    const prompt = await getPromptForClinic(ctx, args.promptId, targetClinicId);
    const updates: Record<string, any> = {
      updatedAt: Date.now(),
    };

    if (args.name !== undefined) {
      updates.name = validatePromptName(args.name);
    }

    if (args.content !== undefined) {
      updates.content = validatePromptContent(args.content);
    }

    await ctx.db.patch(prompt._id, updates);
    const nextContent = updates.content ?? prompt.content;
    const updatedPrompt = await ctx.db.get(prompt._id);
    const settings = await getCanonicalAiSettingsRow(ctx, targetClinicId);

    if (settings?.activePromptId === prompt._id) {
      await syncActivePromptToAiSettings(ctx, targetClinicId, prompt._id, nextContent);
      clearClinicAgentCache(targetClinicId);
    }

    return updatedPrompt;
  },
});

export const setActiveAiSystemPrompt = mutation({
  args: {
    clinicId: v.string(),
    promptId: v.id("aiSystemPrompts"),
  },
  handler: async (ctx, args) => {
    const { targetClinicId } = await getAuthorizedAiClinic(ctx, args.clinicId);
    const prompt = await getPromptForClinic(ctx, args.promptId, targetClinicId);

    await syncActivePromptToAiSettings(ctx, targetClinicId, prompt._id, prompt.content);
    clearClinicAgentCache(targetClinicId);

    return prompt;
  },
});

export const deleteAiSystemPrompt = mutation({
  args: {
    clinicId: v.string(),
    promptId: v.id("aiSystemPrompts"),
  },
  handler: async (ctx, args) => {
    const { targetClinicId } = await getAuthorizedAiClinic(ctx, args.clinicId);
    const prompt = await getPromptForClinic(ctx, args.promptId, targetClinicId);
    const settings = await getCanonicalAiSettingsRow(ctx, targetClinicId);
    const wasActive = settings?.activePromptId === prompt._id;

    await ctx.db.delete(prompt._id);

    if (wasActive) {
      await syncActivePromptToAiSettings(ctx, targetClinicId, undefined, undefined);
      clearClinicAgentCache(targetClinicId);
    }

    return { success: true, deletedPromptId: prompt._id, wasActive };
  },
});

/**
 * Update AI settings for a clinic
 * Creates new settings if they don't exist (upsert pattern)
 */
export const updateAiSettings = mutation({
  args: {
    clinicId: v.string(),
    enabled: v.optional(v.boolean()),
    systemPrompt: v.optional(v.string()), // Deprecated
    tone: v.optional(
      v.union(
        v.literal("empathetic"),
        v.literal("formal"),
        v.literal("casual"),
        v.literal("direct"),
      ),
    ),
    temperature: v.optional(v.number()), // Deprecated
    escalationEnabled: v.optional(v.boolean()), // Deprecated
    escalationKeywords: v.optional(v.array(v.string())), // Deprecated
    activeHoursStart: v.optional(v.string()),
    activeHoursEnd: v.optional(v.string()),
    is247: v.optional(v.boolean()),
    voiceNotesEnabled: v.optional(v.boolean()),
    responseDelaySeconds: v.optional(v.number()),
    // New fields
    escalationTopics: v.optional(
      v.object({
        legal: v.boolean(),
        medicalEmergency: v.boolean(),
        complaints: v.boolean(),
        customKeywords: v.array(v.string()),
      }),
    ),
    enabledTools: v.optional(v.array(v.string())),
    // Custom instructions (from /automation tab)
    customInstructions: v.optional(v.string()),
    activePromptId: v.optional(v.id("aiSystemPrompts")),
  },
  handler: async (ctx, args) => {
    console.log("[updateAiSettings] 1. Started with args:", JSON.stringify(args, null, 2));

    const { user, targetClinicId, authClinicId } = await getAuthorizedAiClinic(ctx, args.clinicId);
    console.log("[updateAiSettings] 2. Auth successful:", {
      userEmail: user?.email,
      userRole: user?.role,
      authClinicId,
    });
    console.log("[updateAiSettings] 3. Target Clinic ID:", targetClinicId);

    // Validate tone if provided
    if (args.tone) {
      const validTones = ["empathetic", "formal", "casual", "direct"];
      if (!validTones.includes(args.tone)) {
        console.error("[updateAiSettings] Invalid tone:", args.tone);
        throw new Error(`Invalid tone: ${args.tone}`);
      }
    }

    // Validate time formats if provided
    const timeRegex = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/;
    if (args.activeHoursStart && !timeRegex.test(args.activeHoursStart)) {
      console.error("[updateAiSettings] Invalid start time:", args.activeHoursStart);
      throw new Error("Invalid activeHoursStart format. Use HH:MM");
    }
    if (args.activeHoursEnd && !timeRegex.test(args.activeHoursEnd)) {
      console.error("[updateAiSettings] Invalid end time:", args.activeHoursEnd);
      throw new Error("Invalid activeHoursEnd format. Use HH:MM");
    }

    // Validate custom keywords if provided
    if (args.escalationTopics?.customKeywords && args.escalationTopics.customKeywords.length > 20) {
      console.error(
        "[updateAiSettings] Too many custom keywords:",
        args.escalationTopics.customKeywords.length,
      );
      throw new Error("Maximum 20 custom escalation keywords allowed");
    }

    // Validate enabledTools if provided
    const validTools = ["scheduling", "nps", "documents", "patientData"];
    if (args.enabledTools) {
      const invalidTools = args.enabledTools.filter((t) => !validTools.includes(t));
      if (invalidTools.length > 0) {
        console.error("[updateAiSettings] Invalid tools:", invalidTools);
        throw new Error(`Invalid tools: ${invalidTools.join(", ")}`);
      }
    }

    console.log("[updateAiSettings] 4. Validation passed. Querying existing settings...");

    // Check if settings exist
    const existing = await getCanonicalAiSettingsRow(ctx, targetClinicId);

    console.log("[updateAiSettings] 5. Existing settings found:", !!existing);

    if (existing) {
      console.log("[updateAiSettings] 6. Updating existing settings:", existing._id);
      // Build updates object with only provided fields
      const updates: any = {
        updatedAt: Date.now(),
      };
      if (args.enabled !== undefined) updates.enabled = args.enabled;
      if (args.tone !== undefined) updates.tone = args.tone;
      if (args.activeHoursStart !== undefined) updates.activeHoursStart = args.activeHoursStart;
      if (args.activeHoursEnd !== undefined) updates.activeHoursEnd = args.activeHoursEnd;
      if (args.is247 !== undefined) updates.is247 = args.is247;
      updates.voiceNotesEnabled = true;
      if (args.responseDelaySeconds !== undefined)
        updates.responseDelaySeconds = args.responseDelaySeconds;
      if (args.escalationTopics !== undefined) updates.escalationTopics = args.escalationTopics;
      if (args.enabledTools !== undefined) updates.enabledTools = args.enabledTools;
      if (args.customInstructions !== undefined)
        updates.customInstructions = args.customInstructions;
      if (args.activePromptId !== undefined) updates.activePromptId = args.activePromptId;

      // Update existing settings
      const updatedSettings = await ctx.db.patch(existing._id, {
        ...updates,
        clinicId: targetClinicId, // Ensure clinicId is set correctly
      });
      console.log("[updateAiSettings] 7. Settings updated.");

      // Clear Mastra agent cache so new agent gets created with updated settings
      clearClinicAgentCache(targetClinicId);

      return updatedSettings;
    } else {
      console.log("[updateAiSettings] 6. Creating new settings record.");
      const now = Date.now();
      const newSettings = await ctx.db.insert(
        "aiSettings",
        buildDefaultAiSettings(targetClinicId, now, {
          enabled: args.enabled ?? true,
          tone: args.tone ?? "empathetic",
          activeHoursStart: args.activeHoursStart ?? "08:00",
          activeHoursEnd: args.activeHoursEnd ?? "18:00",
          is247: args.is247 ?? false,
          voiceNotesEnabled: true,
          responseDelaySeconds: args.responseDelaySeconds ?? 0,
          escalationTopics: args.escalationTopics ?? DEFAULT_ESCALATION_TOPICS,
          enabledTools: args.enabledTools ?? DEFAULT_ENABLED_TOOLS,
          customInstructions: args.customInstructions,
          activePromptId: args.activePromptId,
        }),
      );
      console.log("[updateAiSettings] 7. New settings created:", newSettings);

      return newSettings;
    }
  },
});

/**
 * Toggle AI enabled status
 */
export const toggleAiEnabled = mutation({
  args: {
    clinicId: v.string(),
    enabled: v.boolean(),
  },
  handler: async (ctx, args) => {
    const { targetClinicId } = await getAuthorizedAiClinic(ctx, args.clinicId);

    const existing = await getCanonicalAiSettingsRow(ctx, targetClinicId);

    if (!existing) {
      throw new Error("AI settings not found");
    }

    const updated = await ctx.db.patch(existing._id, {
      enabled: args.enabled,
      updatedAt: Date.now(),
    });

    clearClinicAgentCache(targetClinicId);

    return updated;
  },
});

/**
 * Update fallback channels (escalation keywords)
 */
export const updateFallbackChannels = mutation({
  args: {
    clinicId: v.string(),
    escalationKeywords: v.array(v.string()),
    escalationEnabled: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const { targetClinicId } = await getAuthorizedAiClinic(ctx, args.clinicId);

    // Validate keyword list
    if (args.escalationKeywords.length > 20) {
      throw new Error("Maximum 20 escalation keywords allowed");
    }

    const existing = await getCanonicalAiSettingsRow(ctx, targetClinicId);

    if (!existing) {
      throw new Error("AI settings not found");
    }

    const updated = await ctx.db.patch(existing._id, {
      escalationKeywords: args.escalationKeywords,
      escalationEnabled: args.escalationEnabled ?? existing.escalationEnabled,
      updatedAt: Date.now(),
    });

    clearClinicAgentCache(targetClinicId);

    return updated;
  },
});

// ============================================
// REMINDER CONFIGS MODULE
// ============================================

/**
 * Get all reminder configs for a clinic
 */
export const getReminderConfigs = query({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    if (args.clinicId !== clinicId) {
      throw new Error("Access denied");
    }

    const configs = await ctx.db
      .query("reminderConfigs")
      .withIndex("by_clinic_type", (q: any) => q.eq("clinicId", clinicId))
      .collect();

    const defaultConfigs = buildDefaultReminderConfigs(clinicId, 0);

    if (configs.length === 0) {
      return defaultConfigs;
    }

    const configsByType = new Map(configs.map((config) => [config.type, config]));

    return defaultConfigs.map(
      (defaultConfig) => configsByType.get(defaultConfig.type) ?? defaultConfig,
    );
  },
});

/**
 * Update a reminder config
 */
export const updateReminderConfig = mutation({
  args: {
    clinicId: v.string(),
    type: v.union(
      v.literal("appointmentConfirmation"),
      v.literal("sevenDay"),
      v.literal("twentyFourHour"),
      v.literal("oneHour"),
      v.literal("postConsultation"),
      v.literal("noShowRecovery"),
      v.literal("rescheduleOptions"),
      v.literal("rescheduleConfirmation"),
      v.literal("confirmationReply"),
      v.literal("cancellationConfirmation"),
      v.literal("googleReviewFollowUp"),
      v.literal("detractorAlert"),
    ),
    enabled: v.optional(v.boolean()),
    message: v.optional(v.string()),
    channels: v.optional(
      v.array(
        v.union(v.literal("whatsapp"), v.literal("sms"), v.literal("email"), v.literal("call")),
      ),
    ),
    useOfficialApi: v.optional(v.boolean()),
    delayMinutes: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const { targetClinicId } = await getAuthorizedAiClinic(ctx, args.clinicId);

    // Validate channels if provided
    const validChannels = ["whatsapp", "sms", "email", "call"];
    if (args.channels) {
      const invalidChannels = args.channels.filter((ch) => !validChannels.includes(ch));
      if (invalidChannels.length > 0) {
        throw new Error(`Invalid channels: ${invalidChannels.join(", ")}`);
      }
    }

    // Check if config exists (unique index on clinicId + type)
    const existing = await ctx.db
      .query("reminderConfigs")
      .withIndex("by_clinic_type", (q: any) =>
        q.eq("clinicId", targetClinicId).eq("type", args.type),
      )
      .unique();

    if (existing) {
      // Update existing config
      const updated = await ctx.db.patch(existing._id, {
        ...args,
        updatedAt: Date.now(),
      });

      return updated;
    } else {
      // Create new config
      const newConfig = await ctx.db.insert("reminderConfigs", {
        clinicId: targetClinicId,
        type: args.type,
        enabled: args.enabled ?? true,
        message: args.message ?? "",
        channels: args.channels ?? ["whatsapp"],
        useOfficialApi: args.useOfficialApi ?? false,
        delayMinutes: args.delayMinutes,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });

      return newConfig;
    }
  },
});

/**
 * Toggle a reminder config enabled status
 */
export const toggleReminder = mutation({
  args: {
    clinicId: v.string(),
    type: v.union(
      v.literal("appointmentConfirmation"),
      v.literal("sevenDay"),
      v.literal("twentyFourHour"),
      v.literal("oneHour"),
      v.literal("postConsultation"),
      v.literal("noShowRecovery"),
      v.literal("rescheduleOptions"),
      v.literal("rescheduleConfirmation"),
      v.literal("confirmationReply"),
      v.literal("cancellationConfirmation"),
      v.literal("googleReviewFollowUp"),
      v.literal("detractorAlert"),
    ),
    enabled: v.boolean(),
  },
  handler: async (ctx, args) => {
    const { targetClinicId } = await getAuthorizedAiClinic(ctx, args.clinicId);

    const existing = await ctx.db
      .query("reminderConfigs")
      .withIndex("by_clinic_type", (q: any) =>
        q.eq("clinicId", targetClinicId).eq("type", args.type),
      )
      .unique();

    if (!existing) {
      throw new Error("Reminder config not found");
    }

    const updated = await ctx.db.patch(existing._id, {
      enabled: args.enabled,
      updatedAt: Date.now(),
    });

    return updated;
  },
});

// ============================================
// CAMPAIGN BUILDER MODULE
// ============================================

/**
 * List all campaigns for a clinic
 */
export const listCampaigns = query({
  args: {
    clinicId: v.string(),
    status: v.optional(v.union(v.literal("active"), v.literal("paused"), v.literal("draft"))),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    if (args.clinicId !== clinicId) {
      throw new Error("Access denied");
    }

    let q;
    if (args.status) {
      q = ctx.db
        .query("campaigns")
        .withIndex("by_clinic_status", (q: any) =>
          q.eq("clinicId", clinicId).eq("status", args.status),
        );
    } else {
      q = ctx.db
        .query("campaigns")
        .withIndex("by_clinic_createdAt", (q: any) => q.eq("clinicId", clinicId));
    }

    const campaigns = await q.collect();
    return campaigns;
  },
});

/**
 * Get a single campaign by ID
 */
export const getCampaign = query({
  args: {
    clinicId: v.string(),
    campaignId: v.id("campaigns"),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    if (args.clinicId !== clinicId) {
      throw new Error("Access denied");
    }

    const campaign = await ctx.db.get(args.campaignId);

    if (!campaign || campaign.clinicId !== clinicId) {
      throw new Error("Campaign not found or access denied");
    }

    return campaign;
  },
});

/**
 * Create a new campaign
 */
export const createCampaign = mutation({
  args: {
    clinicId: v.string(),
    name: v.string(),
    triggerType: v.union(
      v.literal("time_after_appointment"),
      v.literal("time_after_procedure"),
      v.literal("birthday"),
      v.literal("no_show"),
      v.literal("custom"),
    ),
    triggerDelayHours: v.optional(v.number()),
    steps: v.array(
      v.object({
        order: v.number(),
        delayHours: v.number(),
        channel: v.union(
          v.literal("whatsapp"),
          v.literal("sms"),
          v.literal("email"),
          v.literal("call"),
        ),
        message: v.string(),
      }),
    ),
  },
  handler: async (ctx, args) => {
    const { targetClinicId } = await getAuthorizedAiClinic(ctx, args.clinicId);

    // Validate steps
    if (!args.steps || args.steps.length === 0) {
      throw new Error("At least one step is required");
    }

    // Validate step order is sequential
    const orders = args.steps.map((s) => s.order).sort((a, b) => a - b);
    if (JSON.stringify(orders) !== JSON.stringify(args.steps.map((s) => s.order))) {
      throw new Error("Step orders must be sequential");
    }

    // Validate channels
    const validChannels = ["whatsapp", "sms", "email", "call"];
    const invalidChannels = args.steps.some((s) => !validChannels.includes(s.channel));
    if (invalidChannels) {
      throw new Error("Invalid channel in steps");
    }

    const campaign = await ctx.db.insert("campaigns", {
      clinicId: targetClinicId,
      name: args.name,
      triggerType: args.triggerType,
      triggerDelayHours: args.triggerDelayHours,
      steps: args.steps,
      status: "draft",
      triggerCount: 0,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });

    return campaign;
  },
});

/**
 * Update a campaign
 */
export const updateCampaign = mutation({
  args: {
    clinicId: v.string(),
    campaignId: v.id("campaigns"),
    name: v.optional(v.string()),
    triggerType: v.optional(
      v.union(
        v.literal("time_after_appointment"),
        v.literal("time_after_procedure"),
        v.literal("birthday"),
        v.literal("no_show"),
        v.literal("custom"),
      ),
    ),
    triggerDelayHours: v.optional(v.number()),
    steps: v.optional(
      v.array(
        v.object({
          order: v.number(),
          delayHours: v.number(),
          channel: v.union(
            v.literal("whatsapp"),
            v.literal("sms"),
            v.literal("email"),
            v.literal("call"),
          ),
          message: v.string(),
        }),
      ),
    ),
    status: v.optional(v.union(v.literal("active"), v.literal("paused"), v.literal("draft"))),
  },
  handler: async (ctx, args) => {
    const { targetClinicId } = await getAuthorizedAiClinic(ctx, args.clinicId);

    const campaign = await ctx.db.get(args.campaignId);

    if (!campaign || campaign.clinicId !== targetClinicId) {
      throw new Error("Campaign not found or access denied");
    }

    // Validate steps if provided
    if (args.steps) {
      if (args.steps.length === 0) {
        throw new Error("At least one step is required");
      }

      const validChannels = ["whatsapp", "sms", "email", "call"];
      const invalidChannels = args.steps.some((s) => !validChannels.includes(s.channel));
      if (invalidChannels) {
        throw new Error("Invalid channel in steps");
      }
    }

    const updated = await ctx.db.patch(args.campaignId, {
      ...args,
      updatedAt: Date.now(),
    });

    return updated;
  },
});

/**
 * Delete a campaign
 */
export const deleteCampaign = mutation({
  args: {
    clinicId: v.string(),
    campaignId: v.id("campaigns"),
  },
  handler: async (ctx, args) => {
    const { targetClinicId } = await getAuthorizedAiClinic(ctx, args.clinicId);

    const campaign = await ctx.db.get(args.campaignId);

    if (!campaign || campaign.clinicId !== targetClinicId) {
      throw new Error("Campaign not found or access denied");
    }

    // Check if campaign has executions (triggerCount > 0)
    if (campaign.triggerCount > 0) {
      throw new Error("Cannot delete campaign with executions");
    }

    await ctx.db.delete(args.campaignId);

    return { success: true };
  },
});

/**
 * Toggle campaign status between active and paused
 */
export const toggleCampaignStatus = mutation({
  args: {
    clinicId: v.string(),
    campaignId: v.id("campaigns"),
  },
  handler: async (ctx, args) => {
    const { targetClinicId } = await getAuthorizedAiClinic(ctx, args.clinicId);

    const campaign = await ctx.db.get(args.campaignId);

    if (!campaign || campaign.clinicId !== targetClinicId) {
      throw new Error("Campaign not found or access denied");
    }

    const newStatus = campaign.status === "active" ? "paused" : "active";

    const updated = await ctx.db.patch(args.campaignId, {
      status: newStatus,
      updatedAt: Date.now(),
    });

    return updated;
  },
});

// ============================================
// BROADCAST / MANUAL CAMPAIGN MODULE
// ============================================

/**
 * List campaigns that can be manually triggered for patients
 */
export const listCampaignsForBroadcast = query({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    if (args.clinicId !== clinicId) {
      throw new Error("Access denied");
    }

    const campaigns = await ctx.db
      .query("campaigns")
      .withIndex("by_clinic_status", (q: any) => q.eq("clinicId", clinicId).eq("status", "active"))
      .collect();

    return campaigns;
  },
});

/**
 * Trigger a campaign for specific patients (manual broadcast)
 * This is an action because it needs to call the WhatsApp API
 */
export const triggerCampaignForPatients = internalMutation({
  args: {
    clinicId: v.string(),
    campaignId: v.id("campaigns"),
    patientIds: v.array(v.id("patients")),
  },
  handler: async (ctx, args) => {
    const campaign = await ctx.db.get(args.campaignId);

    if (!campaign || campaign.clinicId !== args.clinicId) {
      throw new Error("Campaign not found or access denied");
    }

    if (!campaign.steps || campaign.steps.length === 0) {
      throw new Error("Campaign has no steps");
    }

    const results = {
      sent: 0,
      failed: 0,
      noPhone: 0,
      noChat: 0,
      errors: [] as string[],
    };

    const now = Date.now();
    const firstStep = campaign.steps[0];

    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q: any) => q.eq("clinicId", args.clinicId))
      .first();

    for (const patientId of args.patientIds) {
      try {
        const patient = await ctx.db.get(patientId);

        if (!patient) {
          results.failed++;
          results.errors.push(`Patient ${patientId} not found`);
          continue;
        }

        if (!patient.phone) {
          results.noPhone++;
          continue;
        }

        const whatsappChatId = toWhatsAppChatId(patient.phone);
        if (!whatsappChatId) {
          results.noPhone++;
          continue;
        }

        const chat = await ctx.db
          .query("chats")
          .withIndex("by_clinic_whatsappId", (q: any) =>
            q.eq("clinicId", args.clinicId).eq("whatsappChatId", whatsappChatId),
          )
          .first();

        if (!chat) {
          results.noChat++;
          continue;
        }

        const context = {
          patient: {
            name: patient.name,
            phone: patient.phone,
            email: patient.email,
          },
          clinic: {
            name: clinic?.name || "",
            phone: clinic?.phone,
            address: clinic?.address,
          },
          date: {
            today: new Date().toLocaleDateString("pt-BR"),
            now: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
          },
        };

        const personalizeMessage = (template: string, ctx: Record<string, any>): string => {
          if (!template) return "";
          const resolvePath = (obj: any, path: string): string => {
            return path.split(".").reduce((acc, part) => {
              return acc && acc[part] !== undefined ? acc[part] : undefined;
            }, obj);
          };
          return template.replace(/{{([\w.]+)}}/g, (match, path) => {
            const value = resolvePath(ctx, path);
            if (value !== undefined && value !== null) {
              return String(value);
            }
            return match;
          });
        };

        const personalizedMessage = personalizeMessage(firstStep.message, context);

        const messageId = await ctx.db.insert("messages", {
          clinicId: args.clinicId,
          chatId: chat._id,
          direction: "out",
          type: "text",
          body: personalizedMessage,
          sentAt: now,
          status: "sending",
          patientId: patient._id,
          createdAt: now,
        });

        await ctx.scheduler.runAfter(0, internalAny.whatsapp.sendTextAction, {
          chatId: chat._id,
          text: personalizedMessage,
          messageId,
        });

        await ctx.db.insert("campaignExecutions", {
          campaignId: campaign._id,
          clinicId: args.clinicId,
          patientId: patient._id,
          stepOrder: firstStep.order,
          channel: firstStep.channel,
          sentAt: now,
          status: "sent",
        });

        await ctx.db.patch(campaign._id, {
          triggerCount: campaign.triggerCount + 1,
          updatedAt: now,
        });

        results.sent++;
      } catch (error) {
        results.failed++;
        results.errors.push(`Patient ${patientId}: ${String(error)}`);
      }
    }

    return results;
  },
});

/**
 * Send a quick broadcast message to selected patients
 */
export const sendBroadcastToPatients = internalMutation({
  args: {
    clinicId: v.string(),
    patientIds: v.array(v.id("patients")),
    message: v.string(),
  },
  handler: async (ctx, args) => {
    const results = {
      sent: 0,
      failed: 0,
      noPhone: 0,
      noChat: 0,
      errors: [] as string[],
    };

    const now = Date.now();

    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q: any) => q.eq("clinicId", args.clinicId))
      .first();

    for (const patientId of args.patientIds) {
      try {
        const patient = await ctx.db.get(patientId);

        if (!patient) {
          results.failed++;
          results.errors.push(`Patient ${patientId} not found`);
          continue;
        }

        if (!patient.phone) {
          results.noPhone++;
          continue;
        }

        const whatsappChatId = toWhatsAppChatId(patient.phone);
        if (!whatsappChatId) {
          results.noPhone++;
          continue;
        }

        const chat = await ctx.db
          .query("chats")
          .withIndex("by_clinic_whatsappId", (q: any) =>
            q.eq("clinicId", args.clinicId).eq("whatsappChatId", whatsappChatId),
          )
          .first();

        if (!chat) {
          results.noChat++;
          continue;
        }

        const context = {
          patient: {
            name: patient.name,
            phone: patient.phone,
            email: patient.email,
          },
          clinic: {
            name: clinic?.name || "",
            phone: clinic?.phone,
            address: clinic?.address,
          },
          date: {
            today: new Date().toLocaleDateString("pt-BR"),
            now: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
          },
        };

        const personalizeMessage = (template: string, ctx: Record<string, any>): string => {
          if (!template) return "";
          const resolvePath = (obj: any, path: string): string => {
            return path.split(".").reduce((acc, part) => {
              return acc && acc[part] !== undefined ? acc[part] : undefined;
            }, obj);
          };
          return template.replace(/{{([\w.]+)}}/g, (match, path) => {
            const value = resolvePath(ctx, path);
            if (value !== undefined && value !== null) {
              return String(value);
            }
            return match;
          });
        };

        const personalizedMessage = personalizeMessage(args.message, context);

        const messageId = await ctx.db.insert("messages", {
          clinicId: args.clinicId,
          chatId: chat._id,
          direction: "out",
          type: "text",
          body: personalizedMessage,
          sentAt: now,
          status: "sending",
          patientId: patient._id,
          createdAt: now,
        });

        await ctx.scheduler.runAfter(0, internalAny.whatsapp.sendTextAction, {
          chatId: chat._id,
          text: personalizedMessage,
          messageId,
        });

        results.sent++;
      } catch (error) {
        results.failed++;
        results.errors.push(`Patient ${patientId}: ${String(error)}`);
      }
    }

    return results;
  },
});

/**
 * Public wrapper for sendBroadcastToPatients
 */
export const sendBroadcast = mutation({
  args: {
    clinicId: v.string(),
    patientIds: v.array(v.id("patients")),
    message: v.string(),
  },
  handler: async (ctx, args) => {
    const { clinicId: authClinicId, user } = await getAuth(ctx);

    if (!["admin", "staff", "super_admin"].includes(user?.role)) {
      throw new Error("Insufficient permissions");
    }

    const targetClinicId = user?.role === "super_admin" ? args.clinicId : authClinicId;

    if (user?.role !== "super_admin" && args.clinicId !== authClinicId) {
      throw new Error("Access denied to this clinic");
    }

    if (!args.patientIds || args.patientIds.length === 0) {
      throw new Error("No patients selected");
    }

    if (!args.message || args.message.trim().length === 0) {
      throw new Error("Message is required");
    }

    return await ctx.runMutation(internalAny.automation.sendBroadcastToPatients, {
      clinicId: targetClinicId,
      patientIds: args.patientIds,
      message: args.message.trim(),
    });
  },
});

/**
 * Public wrapper for triggerCampaignForPatients
 */
export const triggerCampaign = mutation({
  args: {
    clinicId: v.string(),
    campaignId: v.id("campaigns"),
    patientIds: v.array(v.id("patients")),
  },
  handler: async (ctx, args) => {
    const { clinicId: authClinicId, user } = await getAuth(ctx);

    if (!["admin", "staff", "super_admin"].includes(user?.role)) {
      throw new Error("Insufficient permissions");
    }

    const targetClinicId = user?.role === "super_admin" ? args.clinicId : authClinicId;

    if (user?.role !== "super_admin" && args.clinicId !== authClinicId) {
      throw new Error("Access denied to this clinic");
    }

    if (!args.patientIds || args.patientIds.length === 0) {
      throw new Error("No patients selected");
    }

    return await ctx.runMutation(internalAny.automation.triggerCampaignForPatients, {
      clinicId: targetClinicId,
      campaignId: args.campaignId,
      patientIds: args.patientIds,
    });
  },
});
