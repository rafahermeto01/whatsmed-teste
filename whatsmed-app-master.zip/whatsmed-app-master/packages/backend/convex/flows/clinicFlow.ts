import { v } from "convex/values";

import { query, internalMutation, mutation } from "../_generated/server";
import { requireClinicRole } from "../lib/rbac";

/**
 * Get clinic's AI Guide Flow
 * Enforces clinic isolation - users can only access their own clinic's flow
 */
export const getClinicAiFlow = query({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      return null;
    }

    const userId = identity.subject;

    // Verify user belongs to this clinic
    const user = await ctx.db
      .query("users")
      .withIndex("by_authUserId", (q) => q.eq("authUserId", userId))
      .first();

    if (!user || user.clinicId !== args.clinicId) {
      return null;
    }

    // Query flow by clinicId and name (single flow per clinic)
    const flow = await ctx.db
      .query("flows")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .filter((q) => q.eq(q.field("name"), "AI Guide Flow"))
      .first();

    if (!flow) {
      return null;
    }

    // Get active version
    const version = flow.activeVersionId ? await ctx.db.get(flow.activeVersionId) : null;

    return {
      flow,
      version,
    };
  },
});

/**
 * Test query to verify functions are registering
 */
export const testClinicFlow = query({
  args: {},
  handler: async (ctx) => {
    return { test: true };
  },
});

/**
 * Create AI Guide Flow for clinic (lazy migration)
 * Creates flow with default Start node
 */
export const createClinicAiFlow = mutation({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const { identity } = await requireClinicRole(ctx, args.clinicId, ["admin", "super_admin"]);

    const userId = identity.subject;

    // Create AI Guide Flow
    const flowId = await ctx.db.insert("flows", {
      clinicId: args.clinicId,
      name: "AI Guide Flow",
      description: "Flow de guia para inteligência artificial da clínica",
      status: "active",
      activeVersionId: undefined,
      createdBy: userId,
      createdAt: Date.now(),
    });

    // Create version with default Start node
    const versionId = await ctx.db.insert("flowVersions", {
      clinicId: args.clinicId,
      flowId,
      versionNumber: 1,
      nodes: [
        {
          id: "start",
          type: "start",
          data: {
            title: "Guia da IA",
            instructions:
              "Seja útil, empático e profissional. Ajude os pacientes com agendamentos, informações e suporte.",
            tone: "empathetic",
            escalationRules:
              "Escalar quando: emergência médica, problemas jurídicos, ou pedido explícito",
            goals: "Priorizar agendamentos, responder dúvidas, escalar quando necessário",
          },
          position: { x: 100, y: 50 },
        },
      ],
      connections: [],
      variables: [],
      createdBy: userId,
      createdAt: Date.now(),
    });

    // Set as active version
    await ctx.db.patch(flowId, {
      activeVersionId: versionId,
    });

    return { flowId, versionId };
  },
});

/**
 * Save clinic AI flow
 * Updates nodes and connections for active version
 */
export const saveClinicAiFlow = mutation({
  args: {
    clinicId: v.string(),
    flowId: v.id("flows"),
    nodes: v.array(v.any()),
    edges: v.array(v.any()),
  },
  handler: async (ctx, args) => {
    const { identity } = await requireClinicRole(ctx, args.clinicId, ["admin", "super_admin"]);

    const userId = identity.subject;

    // Verify flow belongs to clinic
    const flow = await ctx.db.get(args.flowId);
    if (!flow || flow.clinicId !== args.clinicId) {
      throw new Error("Flow not found or access denied");
    }

    // Get current active version
    if (!flow.activeVersionId) {
      throw new Error("No active version");
    }

    const currentVersion = await ctx.db.get(flow.activeVersionId);
    const newVersionNumber = (currentVersion?.versionNumber || 0) + 1;

    const versionId = await ctx.db.insert("flowVersions", {
      clinicId: args.clinicId,
      flowId: args.flowId,
      versionNumber: newVersionNumber,
      nodes: args.nodes.map((node: any) => ({
        id: node.id,
        type: node.type,
        data: node.data,
        position: {
          x: node.position?.x ?? 0,
          y: node.position?.y ?? 0,
        },
      })),
      connections: args.edges.map((edge: any) => {
        const connection: any = {
          id: edge.id,
          source: edge.source,
          target: edge.target,
        };
        if (edge.sourceHandle != null) {
          connection.sourceHandle = edge.sourceHandle;
        }
        if (edge.targetHandle != null) {
          connection.targetHandle = edge.targetHandle;
        }
        return connection;
      }),
      variables: currentVersion?.variables || [],
      createdBy: userId,
      createdAt: Date.now(),
    });

    // Update flow to point to new version
    await ctx.db.patch(args.flowId, {
      activeVersionId: versionId,
      updatedAt: Date.now(),
    });

    return { flowId: args.flowId, versionId, versionNumber: newVersionNumber };
  },
});
