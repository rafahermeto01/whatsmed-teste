import { unauthorized, forbidden, notFound } from "../lib/errors";

/**
 * Flow Authorization Helpers
 *
 * These helpers provide role-based access control for flow operations.
 * They ensure multi-tenant isolation by verifying user belongs to specified clinic.
 *
 * Note: These helpers use generic types that work with Convex's DataModel.
 * The actual implementations in flows.ts use direct database lookups to avoid type issues.
 */

/**
 * Check if a user has access to a clinic
 *
 * @param ctx - Query or Mutation context (with db and auth)
 * @param clinicId - Clinic ID to verify access to
 * @param userId - User's authUserId
 * @returns true if user belongs to clinic, false otherwise
 */
export async function hasFlowAccess(
  ctx: any, // Generic ctx with db and auth
  clinicId: string,
  userId: string,
): Promise<boolean> {
  const user = await ctx.db
    .query("users")
    .withIndex("by_clinic", (q: any) => q.eq("clinicId", clinicId))
    .filter((q: any) => q.eq(q.field("authUserId"), userId))
    .first();

  if (!user) {
    return false;
  }

  // Check if user is active and not deleted
  if (!user.isActive || user.deletedAt) {
    return false;
  }

  return true;
}

/**
 * Check if a user has a specific role in a clinic
 *
 * @param ctx - Query or Mutation context (with db and auth)
 * @param clinicId - Clinic ID to check role in
 * @param userId - User's authUserId
 * @param requiredRoles - Array of allowed roles
 * @returns true if user has one of the required roles, false otherwise
 */
export async function checkFlowRole(
  ctx: any, // Generic ctx with db and auth
  clinicId: string,
  userId: string,
  requiredRoles: string[],
): Promise<boolean> {
  const user = await ctx.db
    .query("users")
    .withIndex("by_clinic", (q: any) => q.eq("clinicId", clinicId))
    .filter((q: any) => q.eq(q.field("authUserId"), userId))
    .first();

  if (!user) {
    return false;
  }

  // Check if user is active and not deleted
  if (!user.isActive || user.deletedAt) {
    return false;
  }

  // Check if user's role is in the required roles array
  return requiredRoles.includes(user.role);
}

/**
 * Get a user's active clinic ID
 *
 * @param ctx - Query or Mutation context (with db and auth)
 * @param userId - User's authUserId
 * @returns Clinic ID if user has one, null otherwise
 */
export async function getUserClinicId(
  ctx: any, // Generic ctx with db and auth
  userId: string,
): Promise<string | null> {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) {
    return null;
  }

  const user = await ctx.db
    .query("users")
    .filter((q: any) => q.eq(q.field("authUserId"), userId))
    .first();

  if (!user) {
    return null;
  }

  return user.clinicId ?? null;
}
