/**
 * Variable Sanitization Utilities
 *
 * This module provides utilities for sanitizing variable values to prevent injection attacks
 * when patient data is substituted into flow message templates.
 *
 * Threats Blocked:
 * - XSS (cross-site scripting): script tags, javascript:, onerror=
 * - Template injection: double braces, dollar braces, percent braces, hash braces
 * - SQL injection: single quotes, double quotes, semicolons, dashes, comments
 * - HTML entities: angle brackets, ampersand, quotes
 * - Newline injection: newlines and carriage returns
 *
 * Usage:
 * - Call sanitizeVariable() to escape individual values
 * - Call substituteVariables() to replace {{variable}} placeholders in templates
 *
 * This is critical for healthcare data security (SEC-06) - patient data must be
 * escaped before it's embedded in any message text or template.
 */

/**
 * Sanitize a variable value to prevent injection attacks
 *
 * Escapes:
 * - HTML entities (angle brackets, ampersand, quotes)
 * - Template injection patterns (double braces, dollar braces, percent braces, hash braces)
 * - SQL injection patterns (single quotes, double quotes, semicolons, dashes, comments)
 * - XSS vectors (javascript:, onerror=, onfocus=, onload=, onclick=)
 * - Newlines and control characters
 *
 * @param value - The variable value to sanitize (string, number, boolean)
 * @returns Sanitized string value
 */
export function sanitizeVariable(value: string | number | boolean | null | undefined): string {
  if (value === null || value === undefined) {
    return "";
  }

  const strValue = String(value);

  // Escape XSS vectors first (remove dangerous patterns)
  let sanitized = strValue
    .replace(/javascript:/gi, "")
    .replace(/onerror=/gi, "")
    .replace(/onfocus=/gi, "")
    .replace(/onload=/gi, "")
    .replace(/onclick=/gi, "")
    .replace(/on\w+=/gi, ""); // Remove other on*= patterns

  // Escape HTML entities
  sanitized = sanitized
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#x27;");

  // Escape template injection patterns
  sanitized = sanitized
    .replace(/\{\{/g, "&#123;&#123;") // Double curly braces
    .replace(/\}\}/g, "&#125;&#125;")
    .replace(/\$\{/g, "&#36;&#123;") // Dollar curly
    .replace(/%\{/g, "&#37;&#123;") // Percent curly
    .replace(/#\{/g, "&#35;&#123;"); // Hash curly

  // Remove control characters (except whitespace)
  // eslint-disable-next-line no-control-regex
  sanitized = sanitized.replace(/[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F]/g, "");

  // Limit length to prevent DOS
  const MAX_LENGTH = 1000;
  if (sanitized.length > MAX_LENGTH) {
    sanitized = sanitized.substring(0, MAX_LENGTH);
  }

  return sanitized;
}

/**
 * Substitute variables into a template string with sanitization
 *
 * Template syntax: {{variableName}}
 * Example: "Hello {{patientName}}, your appointment is on {{appointmentDate}}"
 *
 * @param template - The template string with {{variable}} placeholders
 * @param variables - Object mapping variable names to values
 * @returns Template with variables substituted and sanitized
 */
export function substituteVariables(
  template: string,
  variables: Record<string, string | number | boolean | null | undefined>,
): string {
  let result = template;

  // Find all {{variableName}} patterns
  const variablePattern = /\{\{(\w+)\}\}/g;
  const matches = template.matchAll(variablePattern);

  for (const match of matches) {
    const fullMatch = match[0]; // "{{variableName}}"
    const variableName = match[1]; // "variableName"

    // Get variable value, default to empty string if not found
    const value = variables[variableName];

    // Sanitize value
    const sanitizedValue = sanitizeVariable(value);

    // Replace placeholder with sanitized value
    result = result.replace(fullMatch, sanitizedValue);
  }

  return result;
}
