"use node";

/**
 * Tool-Flow Integration Utilities
 *
 * These utilities help format tool context for flow integration.
 * They are optional helpers that provide enhanced tool descriptions
 * based on flow type and suggest relevant tools for specific flow nodes.
 *
 * Note: The core tool system already works with flows - these are
 * optimization helpers for specific flow types.
 */

import type { Doc } from "../_generated/dataModel";

/**
 * Flow intent types based on flow structure analysis
 */
export type FlowIntent = "scheduling" | "intake" | "followup" | "general" | "support";

/**
 * Tool category definitions with their relevance to different flow types
 */
const TOOL_CATEGORIES: Record<
  string,
  {
    tools: string[];
    relevance: Record<FlowIntent, number>; // 0-10 relevance score
    description: string;
  }
> = {
  scheduling: {
    tools: [
      "searchDoctors",
      "checkDoctorAvailability",
      "createAppointment",
      "listProcedures",
      "getAvailableDays",
      "getAvailableHours",
      "listSpecialties",
      "listDoctorsBySpecialty",
      "checkSpecialtyAvailability",
      "getAppointment",
      "listAppointments",
    ],
    relevance: {
      scheduling: 10,
      intake: 3,
      followup: 7,
      general: 5,
      support: 4,
    },
    description: "Ferramentas de agendamento e gerenciamento de consultas",
  },
  patientData: {
    tools: ["getPatientInfo", "updatePatientData", "getPatientByPhone", "savePatientImage"],
    relevance: {
      scheduling: 6,
      intake: 10,
      followup: 8,
      general: 5,
      support: 7,
    },
    description: "Ferramentas de gerenciamento de dados do paciente",
  },
  documents: {
    tools: ["analyzeDocument", "transcribeAudio"],
    relevance: {
      scheduling: 4,
      intake: 9,
      followup: 6,
      general: 7,
      support: 5,
    },
    description: "Ferramentas de análise de documentos e mídia",
  },
  communication: {
    tools: ["sendWhatsApp", "escalateToStaff", "scheduleReminder"],
    relevance: {
      scheduling: 7,
      intake: 6,
      followup: 8,
      general: 8,
      support: 10,
    },
    description: "Ferramentas de comunicação e escalonamento",
  },
  nps: {
    tools: [
      "saveNpsScore",
      "getNpsSettings",
      "requestGoogleReview",
      "getReviewLink",
      "createInternalTicket",
    ],
    relevance: {
      scheduling: 2,
      intake: 1,
      followup: 10,
      general: 3,
      support: 6,
    },
    description: "Ferramentas de pesquisa NPS e feedback",
  },
  core: {
    tools: ["getClinicInfo", "getAiSettings"],
    relevance: {
      scheduling: 5,
      intake: 5,
      followup: 5,
      general: 6,
      support: 5,
    },
    description: "Ferramentas core de informações da clínica",
  },
};

/**
 * Format tools for flow context by highlighting relevant tools
 * based on the current flow type
 *
 * @param enabledTools - Array of enabled tool categories
 * @param currentFlow - The current flow being executed
 * @returns Enhanced tool descriptions for the specific flow context
 */
export function formatToolsForFlowContext(
  enabledTools: string[],
  currentFlow?: { name: string; nodes?: any[] } | null,
): {
  highlightedTools: string[];
  flowIntent: FlowIntent;
  contextualDescription: string;
} {
  // Extract flow intent from flow structure
  const flowIntent = extractFlowIntent(currentFlow?.nodes || []);

  // Collect all enabled tools
  const allEnabledTools = new Set<string>();

  // Always include core tools
  TOOL_CATEGORIES.core.tools.forEach((tool) => allEnabledTools.add(tool));

  // Add tools from enabled categories
  enabledTools.forEach((category) => {
    const categoryData = TOOL_CATEGORIES[category];
    if (categoryData) {
      categoryData.tools.forEach((tool) => allEnabledTools.add(tool));
    }
  });

  // Sort tools by relevance to current flow intent
  const toolsWithRelevance = Array.from(allEnabledTools).map((toolName) => {
    let maxRelevance = 0;

    // Find the highest relevance score across all categories
    Object.values(TOOL_CATEGORIES).forEach((category) => {
      if (category.tools.includes(toolName)) {
        const relevance = category.relevance[flowIntent];
        if (relevance > maxRelevance) {
          maxRelevance = relevance;
        }
      }
    });

    return { name: toolName, relevance: maxRelevance };
  });

  // Sort by relevance (highest first)
  toolsWithRelevance.sort((a, b) => b.relevance - a.relevance);

  // Get highlighted tools (relevance >= 7)
  const highlightedTools = toolsWithRelevance.filter((t) => t.relevance >= 7).map((t) => t.name);

  // Generate contextual description
  const contextualDescription = generateContextualDescription(flowIntent, highlightedTools);

  return {
    highlightedTools,
    flowIntent,
    contextualDescription,
  };
}

/**
 * Analyze flow nodes to determine primary purpose/intent
 *
 * @param flowNodes - Array of flow nodes to analyze
 * @returns Flow intent classification
 */
export function extractFlowIntent(flowNodes: any[]): FlowIntent {
  if (!flowNodes || flowNodes.length === 0) {
    return "general";
  }

  // Count node types and content indicators
  let schedulingIndicators = 0;
  let intakeIndicators = 0;
  let followupIndicators = 0;
  let supportIndicators = 0;

  // Keywords that indicate flow type
  const schedulingKeywords = [
    "agendar",
    "consulta",
    "médico",
    "horário",
    "disponibilidade",
    "marcar",
    "agendamento",
    "appointment",
    "schedule",
    "doctor",
  ];

  const intakeKeywords = [
    "cadastro",
    "dados",
    "informações",
    "documento",
    "carteirinha",
    "registro",
    "formulário",
    "intake",
    "register",
    "document",
  ];

  const followupKeywords = [
    "acompanhamento",
    "retorno",
    "pós-consulta",
    "nps",
    "feedback",
    "avaliação",
    "followup",
    "review",
    "survey",
    "pós-operatório",
  ];

  const supportKeywords = [
    "ajuda",
    "suporte",
    "dúvida",
    "problema",
    "reclamação",
    "help",
    "support",
    "issue",
    "complaint",
    "emergency",
  ];

  flowNodes.forEach((node) => {
    const content = JSON.stringify(node).toLowerCase();

    // Check for scheduling indicators
    schedulingKeywords.forEach((keyword) => {
      if (content.includes(keyword)) schedulingIndicators++;
    });

    // Check for intake indicators
    intakeKeywords.forEach((keyword) => {
      if (content.includes(keyword)) intakeIndicators++;
    });

    // Check for followup indicators
    followupKeywords.forEach((keyword) => {
      if (content.includes(keyword)) followupIndicators++;
    });

    // Check for support indicators
    supportKeywords.forEach((keyword) => {
      if (content.includes(keyword)) supportIndicators++;
    });

    // Node type specific scoring
    if (node.type === "input") {
      // Input nodes often indicate data collection (intake)
      intakeIndicators += 2;
    }

    if (node.type === "condition") {
      // Condition nodes about appointments indicate scheduling
      if (content.includes("agend") || content.includes("consult")) {
        schedulingIndicators += 3;
      }
    }
  });

  // Determine primary intent based on highest score
  const scores = [
    { intent: "scheduling" as FlowIntent, score: schedulingIndicators },
    { intent: "intake" as FlowIntent, score: intakeIndicators },
    { intent: "followup" as FlowIntent, score: followupIndicators },
    { intent: "support" as FlowIntent, score: supportIndicators },
  ];

  scores.sort((a, b) => b.score - a.score);

  // If highest score is 0, return general
  if (scores[0].score === 0) {
    return "general";
  }

  return scores[0].intent;
}

/**
 * Create tool guidance based on flow name and nodes
 * Analyzes flow structure to suggest relevant tools
 *
 * @param flowName - Name of the flow
 * @param flowNodes - Array of flow nodes
 * @returns String with suggested tool usage for the flow
 */
export function createToolGuidance(flowName: string, flowNodes: any[]): string {
  const intent = extractFlowIntent(flowNodes);
  const suggestions: string[] = [];

  // Analyze nodes for specific tool suggestions
  flowNodes.forEach((node, index) => {
    const nodeContent = JSON.stringify(node).toLowerCase();

    // Message nodes about appointments
    if (node.type === "message") {
      if (nodeContent.includes("médico") || nodeContent.includes("doctor")) {
        suggestions.push(
          `Node ${index + 1}: Quando mencionar médicos, use 'searchDoctors' se o paciente especificar um nome`,
        );
      }

      if (nodeContent.includes("disponibilidade") || nodeContent.includes("availability")) {
        suggestions.push(
          `Node ${index + 1}: Se perguntar sobre disponibilidade, use 'checkDoctorAvailability' ou 'getAvailableDays'`,
        );
      }

      if (nodeContent.includes("confirmar") || nodeContent.includes("confirma")) {
        suggestions.push(
          `Node ${index + 1}: Antes de confirmar agendamento, use 'createAppointment' apenas após confirmação explícita`,
        );
      }
    }

    // Input nodes asking for documents
    if (node.type === "input") {
      if (
        nodeContent.includes("documento") ||
        nodeContent.includes("carteirinha") ||
        nodeContent.includes("imagem") ||
        nodeContent.includes("document")
      ) {
        suggestions.push(
          `Node ${index + 1}: Se solicitar documentos, use 'analyzeDocument' quando o paciente enviar`,
        );
      }

      if (nodeContent.includes("dados") || nodeContent.includes("informações")) {
        suggestions.push(
          `Node ${index + 1}: Use 'getPatientInfo' no início e 'updatePatientData' se houver alterações`,
        );
      }
    }

    // Condition nodes about escalation
    if (node.type === "condition") {
      if (
        nodeContent.includes("ajuda") ||
        nodeContent.includes("humano") ||
        nodeContent.includes("reclamação")
      ) {
        suggestions.push(
          `Node ${index + 1}: Se detectar necessidade de ajuda humana, use 'escalateToStaff' imediatamente`,
        );
      }
    }

    // Wait nodes (often in follow-up flows)
    if (node.type === "wait") {
      suggestions.push(
        `Node ${index + 1}: Durante esperas, pode usar 'listAppointments' para verificar status se relevante`,
      );
    }
  });

  // Build guidance string
  const guidanceLines = [
    `Fluxo: ${flowName}`,
    `Tipo Detectado: ${intent}`,
    "",
    "Sugestões de Ferramentas:",
    ...suggestions,
    "",
    "Ferramentas Relevantes para este Tipo de Fluxo:",
    ...getToolsForIntent(intent),
  ];

  return guidanceLines.join("\n");
}

/**
 * Generate contextual description for flow intent
 */
function generateContextualDescription(intent: FlowIntent, highlightedTools: string[]): string {
  const intentDescriptions: Record<FlowIntent, string> = {
    scheduling:
      "Este fluxo foca em agendamento de consultas. As ferramentas de agendamento estão priorizadas.",
    intake:
      "Este fluxo foca em coleta de dados e cadastro do paciente. Ferramentas de dados e documentos estão priorizadas.",
    followup:
      "Este fluxo foca em acompanhamento pós-consulta. Ferramentas de histórico e NPS estão priorizadas.",
    general: "Este é um fluxo geral. Todas as ferramentas estão disponíveis conforme necessidade.",
    support:
      "Este fluxo foca em suporte ao paciente. Ferramentas de escalonamento estão priorizadas.",
  };

  const baseDescription = intentDescriptions[intent];
  const toolsList =
    highlightedTools.length > 0 ? ` Ferramentas principais: ${highlightedTools.join(", ")}.` : "";

  return baseDescription + toolsList;
}

/**
 * Get recommended tools for a specific flow intent
 */
function getToolsForIntent(intent: FlowIntent): string[] {
  const toolMap: Record<FlowIntent, string[]> = {
    scheduling: [
      "• searchDoctors - Para encontrar médicos",
      "• checkDoctorAvailability - Para verificar disponibilidade",
      "• createAppointment - Para criar agendamentos (após confirmação)",
      "• listProcedures - Para listar procedimentos disponíveis",
      "• getAvailableDays/Hours - Para mostrar horários",
    ],
    intake: [
      "• getPatientInfo - Para verificar dados do paciente",
      "• updatePatientData - Para atualizar informações",
      "• analyzeDocument - Para processar documentos enviados",
      "• savePatientImage - Para salvar imagens (carteirinha, etc.)",
    ],
    followup: [
      "• listAppointments - Para mostrar histórico de consultas",
      "• getAppointment - Para detalhes de consulta específica",
      "• saveNpsScore - Para registrar avaliações NPS",
      "• scheduleReminder - Para gerenciar lembretes",
    ],
    general: ["• Todas as ferramentas disponíveis conforme necessidade do paciente"],
    support: [
      "• escalateToStaff - Para transferir para atendimento humano",
      "• getPatientInfo - Para verificar histórico do paciente",
      "• listAppointments - Para contexto de atendimentos",
      "• sendWhatsApp - Para enviar atualizações",
    ],
  };

  return toolMap[intent];
}

/**
 * Get tool relevance score for a specific tool and flow intent
 * Useful for dynamic UI highlighting or logging
 *
 * @param toolName - Name of the tool
 * @param intent - Flow intent type
 * @returns Relevance score (0-10)
 */
export function getToolRelevanceScore(toolName: string, intent: FlowIntent): number {
  let maxRelevance = 0;

  Object.values(TOOL_CATEGORIES).forEach((category) => {
    if (category.tools.includes(toolName)) {
      const relevance = category.relevance[intent];
      if (relevance > maxRelevance) {
        maxRelevance = relevance;
      }
    }
  });

  return maxRelevance;
}

/**
 * Check if a tool is appropriate for a specific flow context
 *
 * @param toolName - Name of the tool to check
 * @param flowIntent - Current flow intent
 * @param minimumRelevance - Minimum relevance score to be considered appropriate (default: 3)
 * @returns Boolean indicating if tool is appropriate
 */
export function isToolAppropriateForFlow(
  toolName: string,
  flowIntent: FlowIntent,
  minimumRelevance: number = 3,
): boolean {
  const score = getToolRelevanceScore(toolName, flowIntent);
  return score >= minimumRelevance;
}

/**
 * Extract tool mappings from flow nodes for OpenAI function calling
 * Analyzes flow structure to build tool definitions dynamically
 *
 * @param nodes - Array of flow nodes from flow version
 * @returns Object mapping tool names to their configurations for OpenAI
 */
export function getToolMappingsFromFlow(nodes: any[]): Record<string, any> {
  const mappings: Record<string, any> = {};

  nodes.forEach((node) => {
    switch (node.type) {
      case "scheduleAppointment":
        mappings.scheduleAppointment = {
          nodeId: node.id,
          description: node.data.description || "Agendar consulta para paciente",
          parameters: {
            patientId: {
              type: "string",
              description: "ID do paciente",
            },
            date: {
              type: "string",
              description: "Data da consulta (YYYY-MM-DD)",
            },
            time: {
              type: "string",
              description: "Horário da consulta (HH:mm)",
            },
            doctorId: {
              type: "string",
              description: "ID do médico",
            },
          },
        };
        break;

      case "patientLookup":
        mappings.patientLookup = {
          nodeId: node.id,
          description: node.data.description || "Buscar informações de paciente",
          parameters: {
            identifier: {
              type: "string",
              description: "Identificador do paciente (telefone, CPF, etc.)",
            },
          },
        };
        break;

      case "escalateToHuman":
        mappings.escalateToHuman = {
          nodeId: node.id,
          description: node.data.description || "Escalar conversa para humano",
          parameters: {
            reason: {
              type: "string",
              description: "Motivo da escalação",
            },
            urgency: {
              type: "string",
              enum: ["low", "medium", "high"],
              description: "Urgência",
            },
          },
        };
        break;

      case "analyzeIntent":
        // Intent node doesn't map to a tool directly
        // It's used for flow control/routing
        break;

      case "sendMessage":
        mappings.sendWhatsApp = {
          nodeId: node.id,
          description: node.data.description || "Enviar mensagem WhatsApp",
          parameters: {
            chatId: {
              type: "string",
              description: "ID do chat WhatsApp",
            },
            text: {
              type: "string",
              description: "Texto da mensagem",
            },
          },
        };
        break;
    }
  });

  return mappings;
}
