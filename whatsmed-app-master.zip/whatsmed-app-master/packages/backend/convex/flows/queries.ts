import { v } from "convex/values";

import { internalQuery } from "../_generated/server";

/**
 * Get flow by ID (internal version for HTTP routes)
 *
 * This internalQuery retrieves a flow by its ID without authentication.
 * It's designed for use by HTTP routes where authentication is handled at the HTTP layer.
 *
 * @param id - Flow identifier
 * @returns Flow object or null if not found
 *
 * Usage: Called by HTTP GET /api/flows/:flowId
 */
export const getFlow = internalQuery({
  args: {
    id: v.id("flows"),
  },
  handler: async (ctx, args) => {
    const flow = await ctx.db.get(args.id);
    return flow || null;
  },
});

/**
 * Get active flow version for execution
 *
 * This internalQuery retrieves the currently active flow version for a given flow.
 * It's designed for use by the AI automation system without authentication checks
 * (as it's called from internal contexts where auth is already verified).
 *
 * @param clinicId - Clinic identifier for multi-tenant isolation
 * @param flowId - Flow identifier (id from flows table)
 * @returns Flow version object with full node/connection data, or null if not found
 *
 * Usage: Called by execution.ts loadFlowForConversation or directly by AI automation
 */
export const getActiveFlowVersion = internalQuery({
  args: {
    clinicId: v.string(),
    flowId: v.id("flows"),
  },
  handler: async (ctx, args) => {
    // Get the flow from flows table by clinicId and flowId
    const flow = await ctx.db
      .query("flows")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .filter((q) => q.eq(q.field("_id"), args.flowId))
      .first();

    // Return null if flow not found
    if (!flow) {
      return null;
    }

    // Return null if no active version
    if (!flow.activeVersionId) {
      return null;
    }

    // Get the active flow version with full data
    const flowVersion = await ctx.db.get(flow.activeVersionId);

    return flowVersion || null;
  },
});

/**
 * Get flow by active version ID
 *
 * This internalQuery retrieves a flow version by its ID.
 * It's designed for use when you already have the flowVersionId and need the full data.
 *
 * @param flowVersionId - Flow version identifier (id from flowVersions table)
 * @returns Flow version object with full node/connection data, or null if not found
 *
 * Usage: Called when reusing existing flowVersionId in conversation context
 */
export const getFlowByActiveVersion = internalQuery({
  args: {
    flowVersionId: v.id("flowVersions"),
  },
  handler: async (ctx, args) => {
    // Get the flow version directly by ID
    const flowVersion = await ctx.db.get(args.flowVersionId);

    return flowVersion || null;
  },
});

/**
 * Get flow metadata by active version ID
 *
 * This internalQuery retrieves flow metadata (name, description) along with version data.
 * It's useful for including flow context in conversation history without full node data.
 *
 * @param flowVersionId - Flow version identifier (id from flowVersions table)
 * @returns Object with flow metadata and version info, or null if not found
 *
 * Usage: Called when preparing conversation context summaries
 */
export const getFlowMetadataByVersion = internalQuery({
  args: {
    flowVersionId: v.id("flowVersions"),
  },
  handler: async (ctx, args) => {
    // Get the flow version
    const flowVersion = await ctx.db.get(args.flowVersionId);

    if (!flowVersion) {
      return null;
    }

    // Get the parent flow to retrieve metadata
    const flow = await ctx.db.get(flowVersion.flowId);

    if (!flow) {
      return null;
    }

    // Return combined metadata
    return {
      flowId: flow._id,
      flowName: flow.name,
      flowDescription: flow.description,
      flowStatus: flow.status,
      versionId: flowVersion._id,
      versionNumber: flowVersion.versionNumber,
      nodeCount: flowVersion.nodes.length,
      connectionCount: flowVersion.connections.length,
      hasVariables: flowVersion.variables && flowVersion.variables.length > 0,
    };
  },
});

/**
 * Get active flow by clinic ID
 *
 * This internalQuery retrieves the currently active flow for a clinic.
 * It first checks for a default flow in clinicSettings, then falls back to
 * any active flow in the clinic.
 *
 * @param clinicId - Clinic identifier for multi-tenant isolation
 * @returns Flow object with active version info, or null if no active flow exists
 *
 * Usage: Called by WhatsApp message handler to auto-trigger flows (AIINT-03)
 */
export const getActiveFlowByClinic = internalQuery({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    // First, try to get the default flow from clinicSettings
    // Note: We need to query by clinic.clinicId (string), not by Id<"clinics">
    // So we need to convert or find the clinics table entry first
    const clinics = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .collect();

    if (clinics.length > 0) {
      const clinic = clinics[0];
      const clinicSettings = await ctx.db
        .query("clinicSettings")
        .withIndex("by_clinic", (q) => q.eq("clinicId", clinic._id))
        .first();

      if (clinicSettings?.defaultFlowId) {
        // Get the default flow
        const defaultFlow = await ctx.db.get(clinicSettings.defaultFlowId);
        if (defaultFlow && defaultFlow.clinicId === args.clinicId && defaultFlow.activeVersionId) {
          return defaultFlow;
        }
      }
    }

    // Fallback: Query flows by clinicId and status="active"
    const flows = await ctx.db
      .query("flows")
      .withIndex("by_clinic_status", (q) => q.eq("clinicId", args.clinicId).eq("status", "active"))
      .collect();

    // Find the first flow with an active version set
    for (const flow of flows) {
      if (flow.activeVersionId) {
        return flow;
      }
    }

    // No active flow found
    return null;
  },
});
