import { describe, it, expect } from "vitest";

import { sanitizeVariable, substituteVariables } from "./sanitization";

describe("sanitizeVariable", () => {
  it("should escape HTML entities", () => {
    expect(sanitizeVariable("<script>")).toBe("&lt;script&gt;");
    expect(sanitizeVariable('"')).toBe("&quot;");
    expect(sanitizeVariable("&")).toBe("&amp;");
  });

  it("should escape template injection patterns", () => {
    expect(sanitizeVariable("{{test}}")).toContain("&#123;&#123;");
    expect(sanitizeVariable("${test}")).toContain("&#36;&#123;");
  });

  it("should handle null and undefined", () => {
    expect(sanitizeVariable(null)).toBe("");
    expect(sanitizeVariable(undefined)).toBe("");
  });

  it("should preserve safe text", () => {
    expect(sanitizeVariable("Hello, John Doe")).toBe("Hello, John Doe");
  });

  it("should limit length", () => {
    const long = "a".repeat(2000);
    expect(sanitizeVariable(long)).toHaveLength(1000);
  });
});

describe("substituteVariables", () => {
  it("should substitute variables with sanitization", () => {
    const template = "Hello {{name}}, your appointment is on {{date}}";
    const variables = { name: "John", date: "2024-01-15" };

    expect(substituteVariables(template, variables)).toBe(
      "Hello John, your appointment is on 2024-01-15",
    );
  });

  it("should sanitize XSS in variables", () => {
    const template = "Hello {{name}}";
    const variables = { name: "<script>alert('xss')</script>" };

    expect(substituteVariables(template, variables)).not.toContain("<script>");
  });

  it("should handle missing variables", () => {
    const template = "Hello {{name}} {{unknown}}";
    const variables = { name: "John" };

    expect(substituteVariables(template, variables)).toBe("Hello John ");
  });

  it("should handle multiple occurrences of same variable", () => {
    const template = "{{name}} {{name}} {{name}}";
    const variables = { name: "John" };

    expect(substituteVariables(template, variables)).toBe("John John John");
  });
});
