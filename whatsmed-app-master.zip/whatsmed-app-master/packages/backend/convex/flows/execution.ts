import { v } from "convex/values";

import formatFlowForLlm from "./contextFormatter";
import { internal } from "../_generated/api";
import { internalMutation } from "../_generated/server";

/**
 * Load active flow version from Convex for conversation execution
 *
 * This function retrieves the currently active flow version for a given flow.
 * It's designed for use by the AI automation system to prepare flow context.
 *
 * @param clinicId - Clinic identifier for multi-tenant isolation
 * @param flowId - Flow identifier (id from flows table)
 * @returns Flow version object or null if not found
 *
 * Usage: Called by prepareFlowContext or directly by AI automation
 */
export const loadFlowForConversation = internalMutation({
  args: {
    clinicId: v.string(),
    flowId: v.id("flows"),
  },
  handler: async (ctx, args) => {
    // Get the flow from flows table by clinicId and flowId
    const flow = await ctx.db
      .query("flows")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .filter((q) => q.eq(q.field("_id"), args.flowId))
      .first();

    if (!flow || !flow.activeVersionId) {
      return null;
    }

    // Get the active flow version
    const flowVersion = await ctx.db.get(flow.activeVersionId);

    if (!flowVersion) {
      return null;
    }

    return flowVersion;
  },
});

/**
 * Prepare flow context for LLM consumption
 *
 * This function formats the flow structure into a Markdown+JSON document
 * that can be injected into the Mastra agent's context as guidance.
 *
 * @param flowVersion - Flow version object from Convex flowVersions table
 * @param patientId - Patient identifier (for conversation context)
 * @param chatId - Chat identifier (for conversation context)
 * @returns Context object with formatted flow data
 *
 * Usage: Called by AI automation to prepare flow guidance for LLM
 */
export const prepareFlowContext = internalMutation({
  args: {
    flowVersionId: v.id("flowVersions"),
    patientId: v.optional(v.id("patients")),
    chatId: v.optional(v.id("chats")),
  },
  handler: async (ctx, args) => {
    // Get the flow version
    const flowVersion = await ctx.db.get(args.flowVersionId);

    if (!flowVersion) {
      throw new Error("Flow version not found");
    }

    // Format flow for LLM consumption
    const flowContext = formatFlowForLlm(flowVersion);

    // Return context object for agent injection
    return {
      flowContext: flowContext as string, // Formatted Markdown string
      flowVersionId: flowVersion._id,
      flowVersionNumber: flowVersion.versionNumber,
      variables: flowVersion.variables,
    };
  },
});

/**
 * Combined function: Load flow and prepare context in one call
 *
 * This convenience function combines loading and formatting for simpler usage
 * in AI automation workflows.
 *
 * @param clinicId - Clinic identifier for multi-tenant isolation
 * @param flowId - Flow identifier (id from flows table)
 * @param patientId - Patient identifier (for conversation context)
 * @param chatId - Chat identifier (for conversation context)
 * @returns Context object with formatted flow data or null if flow not found
 *
 * Usage: Called by AI automation to load and format flow in one step
 */
export const loadAndPrepareFlowContext = internalMutation({
  args: {
    clinicId: v.string(),
    flowId: v.id("flows"),
    patientId: v.optional(v.id("patients")),
    chatId: v.optional(v.id("chats")),
  },
  handler: async (ctx, args) => {
    // Get the flow from flows table by clinicId and flowId
    const flow = await ctx.db
      .query("flows")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .filter((q) => q.eq(q.field("_id"), args.flowId))
      .first();

    if (!flow || !flow.activeVersionId) {
      return null;
    }

    // Get the active flow version
    const flowVersion = await ctx.db.get(flow.activeVersionId);

    if (!flowVersion) {
      return null;
    }

    // Format flow for LLM consumption
    const flowContext = formatFlowForLlm(flowVersion);

    // Return context object for agent injection
    return {
      flowContext: flowContext as string, // Formatted Markdown string
      flowVersionId: flowVersion._id,
      flowVersionNumber: flowVersion.versionNumber,
      variables: flowVersion.variables,
      flowId: flow._id,
    };
  },
});
