import { v } from "convex/values";

import { sanitizeVariable } from "./sanitization";

/**
 * Flow version data structure from Convex
 */
interface FlowVersionData {
  _id: string;
  versionNumber: number;
  nodes: Array<{
    id: string;
    type: string;
    data: any;
    position: { x: number; y: number };
  }>;
  connections: Array<{
    id: string;
    source: string;
    target: string;
    sourceHandle?: string;
    targetHandle?: string;
  }>;
  variables?: Array<{
    name: string;
    type: "string" | "number" | "boolean";
    defaultValue?: any;
    description?: string;
  }>;
}

/**
 * Format flow structure for LLM consumption
 *
 * Converts React Flow JSON structure to Markdown+LLM-friendly format
 * that can be injected into Mastra agent context as guidance document.
 *
 * @param flowVersion - Flow version object from Convex flowVersions table
 * @returns Markdown+JSON structure formatted for LLM parsing
 *
 * Pattern from RESEARCH.md section "React Flow to LLM Conversion"
 */
export function formatFlowForLlm(flowVersion: FlowVersionData): string {
  const { nodes, connections, variables, versionNumber } = flowVersion;

  // Build node descriptions by type (semantic descriptions for LLM)
  const nodeDescriptions = nodes
    .filter((n) => n.type !== "start" && n.type !== "end")
    .map((node) => {
      const data = node.data as any;

      switch (node.type) {
        case "message":
          return `## Node: ${sanitizeVariable(data.title || "Message")}
Tipo: ENVIAR MENSAGEM
Conteúdo: "${sanitizeVariable(data.text || "")}"
ID: ${node.id}

Instrução: Use este texto quando apropriado na conversa. Adapte de forma natural.
`;
        case "condition":
          return `## Node: ${sanitizeVariable(data.title || "Condition")}
Tipo: VERIFICAR CONDICÃO
Condição: "${sanitizeVariable(data.condition || "")}"
ID: ${node.id}

Instrução: Verifique se a condição é verdadeira e siga o caminho correspondente (sim/não).
`;
        case "input":
          return `## Node: ${sanitizeVariable(data.title || "Input")}
Tipo: COLETAR DADO DO PACIENTE
Pergunta: "${sanitizeVariable(data.prompt || "")}"
Campo: "${sanitizeVariable(data.field || "value")}"
Tipo: ${data.inputType || "text"}
ID: ${node.id}

Instrução: Pergunte ao paciente de forma natural. Armazene a resposta no campo especificado.
`;
        case "wait":
          return `## Node: ${sanitizeVariable(data.title || "Wait")}
Tipo: AGUARDAR
Duração: ${data.duration || "24"} ${data.durationUnit || "hours"}
ID: ${node.id}

Instrução: Aguarde o período especificado antes de continuar com o fluxo.
`;
        default:
          return `## Node: ${sanitizeVariable(data.title || node.type)}
Tipo: ${node.type}
Dados: ${JSON.stringify(data, null, 2)}
ID: ${node.id}

Instrução: Execute a ação descrita neste nó.
`;
      }
    })
    .join("\n---\n");

  // Build connection paths showing node relationships
  const connectionPaths = connections
    .map((conn) => {
      const sourceNode = nodes.find((n) => n.id === conn.source);
      const targetNode = nodes.find((n) => n.id === conn.target);

      const sourceTitle = sanitizeVariable((sourceNode?.data as any)?.title || conn.source);
      const targetTitle = sanitizeVariable((targetNode?.data as any)?.title || conn.target);

      let handleLabel = "";
      if (conn.sourceHandle) {
        const handleText =
          conn.sourceHandle === "yes"
            ? "sim"
            : conn.sourceHandle === "no"
              ? "não"
              : conn.sourceHandle;
        handleLabel = ` [${handleText}]`;
      }

      return `${sourceTitle}${handleLabel} → ${targetTitle}`;
    })
    .join("\n");

  // Variables reference list with type and description
  const variablesList =
    variables
      ?.map(
        (v) => `- \`{{${v.name}}}\` (${v.type}): ${v.description || `padrão="${v.defaultValue}"`}`,
      )
      .join("\n") || "(Nenhuma variável definida)";

  // Find flow purpose from first message node or use default
  const firstMessageNode = nodes.find((n) => n.type === "message");
  const flowPurpose = sanitizeVariable(
    (firstMessageNode?.data as any)?.title || "Fluxo de paciente",
  );
  const startNode = connections[0]?.source || "start";

  // Build flow overview with autonomy instruction
  const flowOverview = `## Visão Geral
Este fluxo serve como guia de referência para a IA durante a conversa com o paciente.

**Propósito**: ${flowPurpose}

**Importante**: A IA tem autonomia completa para desviar da estrutura quando necessário.
Os nós são ferramentas para ajudar a IA se organizar, não etapas obrigatórias.`;

  // Build AI instructions section (guidance, not strict rules)
  const aiInstructions = `## Instruções para a IA

### Autonomia e Naturalidade
1. Você tem **completa liberdade** para seguir ou desviar deste fluxo
2. Mantenha conversa natural e empática, não robótica
3. Use os nós como pontos de referência para saber o que fazer, não como script rígido

### Respostas a Perguntas
1. Se o paciente fizer uma pergunta fora do fluxo, responda naturalmente
2. Volte ao fluxo apenas quando apropriado para a conversa
3. Priorize a experiência do paciente sobre a estrutura do fluxo

### Uso de Variáveis
- Substitua \`{{variavel}}\` pelos valores coletados do paciente
- As variáveis são preenchidas dinamicamente durante a conversa
- Use variáveis para personalizar mensagens e manter contexto

### Escalada de Conversa
Se detectar frustração ou pedido de ajuda:
- Use a ferramenta \`escalateToStaff\` para encaminhar para equipe humana
- Palavras como "frustrado", "chateado", "não consigo", "não funciona" indicam necessidade de escalada

### Retorno após Inatividade
Quando o paciente retornar à conversa após inatividade:
- Analise o histórico de mensagens para inferir a posição atual
- Faça uma breve verificação de contexto antes de continuar
- Seja empático sobre a pausa na conversa`;

  // Final Markdown+JSON structure for LLM parsing
  return `
# FLOW DE PACIENTE - GUIA PARA IA

${flowOverview}

## Variáveis Disponíveis
${variablesList}

## Estrutura do Fluxo

### Nós do Fluxo
${nodeDescriptions}

### Conexões (Caminhos)
${connectionPaths}

## Dados do Fluxo (JSON)
\`\`\`json
{
  "versionNumber": ${versionNumber},
  "flowPurpose": "${flowPurpose}",
  "startNode": "${startNode}",
  "nodeCount": ${nodes.length},
  "connectionCount": ${connections.length},
  "nodes": ${JSON.stringify(
    nodes.map((n) => ({
      id: n.id,
      type: n.type,
      title: sanitizeVariable((n.data as any)?.title),
    })),
    null,
    2,
  )},
  "connections": ${JSON.stringify(
    connections.map((c) => ({
      id: c.id,
      source: c.source,
      target: c.target,
      sourceHandle: c.sourceHandle,
    })),
    null,
    2,
  )}
}
\`\`\`

${aiInstructions}
`;
}

// Export for Convex functions
export default formatFlowForLlm;
