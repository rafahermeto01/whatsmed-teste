import { v } from "convex/values";

import { internalMutation, internalQuery } from "../_generated/server";

const multipliers = {
  seconds: 1000,
  minutes: 60 * 1000,
  hours: 60 * 60 * 1000,
  days: 24 * 60 * 60 * 1000,
} as const;

export const startWaitInternal = internalMutation({
  args: {
    clinicId: v.string(),
    flowId: v.id("flows"),
    chatId: v.id("chats"),
    nodeId: v.string(),
    duration: v.number(),
    unit: v.union(
      v.literal("seconds"),
      v.literal("minutes"),
      v.literal("hours"),
      v.literal("days"),
    ),
    timeoutAction: v.union(v.literal("resume"), v.literal("escalate")),
    resumeCondition: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const startedAt = Date.now();
    const expiresAt = startedAt + args.duration * multipliers[args.unit];

    const waitId = await ctx.db.insert("flowWaitStates", {
      clinicId: args.clinicId,
      flowId: args.flowId,
      chatId: args.chatId,
      nodeId: args.nodeId,
      duration: args.duration,
      unit: args.unit,
      timeoutAction: args.timeoutAction,
      resumeCondition: args.resumeCondition,
      status: "waiting",
      startedAt,
      expiresAt,
    });

    return {
      waitId,
      startedAt,
      expiresAt,
    };
  },
});

export const checkWaitStatusInternal = internalMutation({
  args: {
    chatId: v.id("chats"),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    const activeWaits = await ctx.db
      .query("flowWaitStates")
      .withIndex("by_chat_status", (q) => q.eq("chatId", args.chatId).eq("status", "waiting"))
      .collect();

    if (activeWaits.length === 0) {
      return null;
    }

    const wait = activeWaits[0];

    if (now >= wait.expiresAt) {
      await ctx.db.patch(wait._id, {
        status: "expired",
        processedAt: now,
      });
      return {
        waitId: wait._id,
        status: "expired" as const,
        expiresAt: wait.expiresAt,
        timeoutAction: wait.timeoutAction,
      };
    }

    return {
      waitId: wait._id,
      status: "waiting" as const,
      expiresAt: wait.expiresAt,
      timeoutAction: wait.timeoutAction,
    };
  },
});

export const cancelWaitInternal = internalMutation({
  args: {
    chatId: v.id("chats"),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    const activeWaits = await ctx.db
      .query("flowWaitStates")
      .withIndex("by_chat_status", (q) => q.eq("chatId", args.chatId).eq("status", "waiting"))
      .collect();

    if (activeWaits.length === 0) {
      return false;
    }

    for (const wait of activeWaits) {
      await ctx.db.patch(wait._id, {
        status: "resumed",
        processedAt: now,
      });
    }

    return true;
  },
});

export const processWaitTimeoutInternal = internalMutation({
  args: {
    waitId: v.id("flowWaitStates"),
  },
  handler: async (ctx, args) => {
    const wait = await ctx.db.get(args.waitId);

    if (!wait || wait.status !== "waiting") {
      return;
    }

    const now = Date.now();

    await ctx.db.patch(args.waitId, {
      status: "expired",
      processedAt: now,
    });

    return {
      waitId: args.waitId,
      chatId: wait.chatId,
      timeoutAction: wait.timeoutAction,
    };
  },
});

export const cleanupExpiredWaitsInternal = internalMutation({
  args: {
    olderThanMs: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const olderThanMs = args.olderThanMs ?? 24 * 60 * 60 * 1000; // 24 hours default
    const now = Date.now();
    const cutoffTime = now - olderThanMs;

    const expiredWaits = await ctx.db
      .query("flowWaitStates")
      .withIndex("by_expiresAt", (q) => q.lt("expiresAt", cutoffTime))
      .collect();

    let deletedCount = 0;

    for (const wait of expiredWaits) {
      await ctx.db.delete(wait._id);
      deletedCount++;
    }

    return { deletedCount };
  },
});
