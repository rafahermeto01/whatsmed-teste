import { v } from "convex/values";

import { internal } from "../_generated/api";
import { mutation, query, MutationCtx, QueryCtx } from "../_generated/server";

/**
 * Audit Logging Module for Flow Operations
 *
 * This module provides utilities for logging all flow CRUD operations to support
 * healthcare compliance requirements.
 *
 * **Audit Requirements:**
 * - All flow CRUD operations must be logged (create, read, update, delete)
 * - Log entries include: timestamp, userId, clinicId, operation, flowId
 * - Audit logs are append-only (no updates or deletes allowed)
 * - Audit logs are queryable by clinic, operation, and date range
 * - Retention period: 1 year
 *
 * **Operations Logged:**
 * - flow.create: New flow created
 * - flow.update: Existing flow modified
 * - flow.delete: Flow deleted
 * - flow.read: Flow accessed (for read auditing if needed)
 * - flowVersion.create: New flow version created
 * - flowVersion.activate: Flow version activated
 * - flowExecution.create: Flow execution started
 * - flowExecution.update: Flow execution state changed
 * - flowExecution.complete: Flow execution finished
 *
 * **Append-Only Design:**
 * Audit logs are immutable once created. No update or delete functions
 * are provided for audit entries to ensure complete audit trail.
 */

/**
 * Flow audit operation types
 */
export type FlowAuditOperation =
  | "flow.create"
  | "flow.update"
  | "flow.delete"
  | "flow.read"
  | "flow.activate"
  | "flow.deactivate"
  | "flowVersion.create"
  | "flowVersion.activate"
  | "flowExecution.create"
  | "flowExecution.update"
  | "flowExecution.complete";

/**
 * Internal helper: Log flow operation to audit logs
 * This is a helper function (not a mutation) that can be called directly from other mutations
 */
async function logFlowOperationInternal(
  ctx: MutationCtx,
  operation: string,
  clinicId: string,
  flowId: string,
  userId: string,
  userEmail?: string,
  metadata?: Record<string, any>,
) {
  await ctx.db.insert("auditLogs", {
    action: operation,
    clinicId: clinicId,
    userId: userId,
    email: userEmail,
    metadata: {
      flowId: flowId,
      ...metadata,
    },
    createdAt: Date.now(),
  });
}

/**
 * Public helper: Log flow operation
 * Use this in other mutations to record audit entries
 */
export async function logFlowOperation(
  ctx: MutationCtx,
  operation: FlowAuditOperation,
  clinicId: string,
  flowId: string,
  userId: string,
  userEmail?: string,
  metadata?: Record<string, any>,
) {
  await logFlowOperationInternal(ctx, operation, clinicId, flowId, userId, userEmail, metadata);
}

/**
 * Query flow audit logs for compliance reporting
 * Filters by clinic, operation, and date range
 * Returns only flow-related audit entries
 */
export const queryAuditLogs = query({
  args: {
    clinicId: v.string(),
    operation: v.optional(v.string()),
    startDate: v.optional(v.number()), // timestamp
    endDate: v.optional(v.number()), // timestamp
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new Error("Unauthorized");
    }

    const userId = identity.subject;

    // Verify user belongs to the clinic
    const user = await ctx.db
      .query("users")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .filter((q) => q.eq(q.field("authUserId"), userId))
      .first();

    if (!user || !user.isActive || user.deletedAt) {
      throw new Error("Unauthorized");
    }

    // Build base query
    let query = ctx.db
      .query("auditLogs")
      .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", args.clinicId));

    // Filter by operation if specified
    if (args.operation) {
      query = query.filter((q) => q.eq(q.field("action"), args.operation));
    }

    // Filter by date range if specified
    if (args.startDate !== undefined) {
      query = query.filter((q) => q.gte(q.field("createdAt"), args.startDate as any));
    }
    if (args.endDate !== undefined) {
      query = query.filter((q) => q.lte(q.field("createdAt"), args.endDate as any));
    }

    // Apply limit (default 100, max 1000)
    const limit = Math.min(args.limit || 100, 1000);
    const logs = await query.take(limit);

    // Extract flow-related logs (action starts with "flow." or "flowVersion." or "flowExecution.")
    return logs
      .filter(
        (log) =>
          log.action.startsWith("flow.") ||
          log.action.startsWith("flowVersion.") ||
          log.action.startsWith("flowExecution."),
      )
      .map((log) => ({
        id: log._id,
        action: log.action,
        userId: log.userId,
        email: log.email,
        flowId: log.metadata?.flowId,
        metadata: log.metadata,
        createdAt: log.createdAt,
      }));
  },
});
