import { v } from "convex/values";

import { logFlowOperation } from "./audit";
import { checkFlowRole, hasFlowAccess } from "./auth";
import { mutation, internalMutation } from "../_generated/server";
import { unauthorized, forbidden, notFound } from "../lib/errors";

/**
 * Update flow (internal version for HTTP routes)
 *
 * This internalMutation updates a flow's metadata without authentication.
 * It's designed for use by HTTP routes where authentication is handled at the HTTP layer.
 *
 * @param id - Flow identifier
 * @param name - Optional new name
 * @param description - Optional new description
 * @param status - Optional new status
 * @returns Updated flow object
 *
 * Usage: Called by HTTP PATCH /api/flows/:flowId
 */
export const updateFlow = internalMutation({
  args: {
    id: v.id("flows"),
    name: v.optional(v.string()),
    description: v.optional(v.string()),
    status: v.optional(v.union(v.literal("draft"), v.literal("active"), v.literal("archived"))),
  },
  handler: async (ctx, args) => {
    const flow = await ctx.db.get(args.id);
    if (!flow) {
      throw notFound("Flow not found");
    }

    // Update flow
    const updates: any = { updatedAt: Date.now() };
    if (args.name !== undefined) updates.name = args.name;
    if (args.description !== undefined) updates.description = args.description;
    if (args.status !== undefined) updates.status = args.status;

    await ctx.db.patch(args.id, updates);

    const updatedFlow = await ctx.db.get(args.id);
    return updatedFlow;
  },
});

/**
 * Delete flow (internal version for HTTP routes)
 *
 * This internalMutation deletes a flow without authentication.
 * It's designed for use by HTTP routes where authentication is handled at the HTTP layer.
 *
 * @param id - Flow identifier
 * @returns Success object
 *
 * Usage: Called by HTTP DELETE /api/flows/:flowId
 */
export const deleteFlow = internalMutation({
  args: {
    id: v.id("flows"),
  },
  handler: async (ctx, args) => {
    const flow = await ctx.db.get(args.id);
    if (!flow) {
      throw notFound("Flow not found");
    }

    // Delete flow
    await ctx.db.delete(args.id);

    return { success: true };
  },
});

/**
 * Activate a flow for a clinic
 *
 * This mutation makes a flow available for conversations by setting its status to "active".
 * It also deactivates all other flows in the clinic (sets them to "draft").
 *
 * Requirements:
 * - User must be authenticated
 * - User must have admin role in the clinic
 *
 * @param flowId - Flow identifier (id from flows table)
 * @param clinicId - Clinic identifier for multi-tenant isolation
 * @param versionId - Optional version identifier to set as active (defaults to latest)
 * @returns Updated flow object with active version info
 *
 * Usage: Called by flow builder UI to activate a published flow
 */
export const activateFlow = mutation({
  args: {
    flowId: v.id("flows"),
    clinicId: v.string(),
    versionId: v.optional(v.id("flowVersions")),
  },
  handler: async (ctx, args) => {
    // Get authenticated user
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw unauthorized("Authentication required");
    }

    const authUserId = identity.subject;

    // Verify user has admin role in the clinic
    const hasAdminRole = await checkFlowRole(ctx, args.clinicId, authUserId, ["admin"]);
    if (!hasAdminRole) {
      throw forbidden("Admin role required to activate flows");
    }

    // Get the flow to verify it exists and belongs to the clinic
    const flow = await ctx.db.get(args.flowId);
    if (!flow) {
      throw notFound("Flow not found");
    }

    if (flow.clinicId !== args.clinicId) {
      throw forbidden("Flow does not belong to this clinic");
    }

    // Determine which version to activate
    let activeVersionId = args.versionId;
    if (!activeVersionId) {
      // Find the latest version for this flow
      const versions = await ctx.db
        .query("flowVersions")
        .withIndex("by_flow", (q) => q.eq("flowId", args.flowId))
        .order("desc")
        .collect();

      if (versions.length === 0) {
        throw notFound("No versions found for this flow");
      }

      // Use the latest version (highest version number)
      activeVersionId = versions[0]._id;
    }

    // Verify the version exists and belongs to this flow
    const version = await ctx.db.get(activeVersionId);
    if (!version) {
      throw notFound("Version not found");
    }

    if (version.flowId !== args.flowId) {
      throw forbidden("Version does not belong to this flow");
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_authUserId", (q) => q.eq("authUserId", authUserId))
      .first();

    // Deactivate all other flows in the clinic (set status to "draft")
    const allClinicFlows = await ctx.db
      .query("flows")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .collect();

    for (const clinicFlow of allClinicFlows) {
      if (clinicFlow._id !== args.flowId && clinicFlow.status === "active") {
        await ctx.db.patch(clinicFlow._id, {
          status: "draft",
          activeVersionId: undefined,
        });
      }
    }

    // Log audit before activating
    await logFlowOperation(
      ctx,
      "flow.activate" as const,
      flow.clinicId,
      args.flowId,
      authUserId,
      user?.email,
      { versionId: activeVersionId, previousStatus: flow.status },
    );

    // Activate this flow
    const updatedFlow = await ctx.db.patch(args.flowId, {
      status: "active",
      activeVersionId,
    });

    return updatedFlow;
  },
});

/**
 * Deactivate a flow for a clinic
 *
 * This mutation makes a flow unavailable for conversations by setting its status to "archived".
 * It also clears the activeVersionId.
 *
 * Requirements:
 * - User must be authenticated
 * - User must have admin role in the clinic
 *
 * @param flowId - Flow identifier (id from flows table)
 * @param clinicId - Clinic identifier for multi-tenant isolation
 * @returns Updated flow object
 *
 * Usage: Called by flow builder UI to deactivate a flow
 */
export const deactivateFlow = mutation({
  args: {
    flowId: v.id("flows"),
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    // Get authenticated user
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw unauthorized("Authentication required");
    }

    const authUserId = identity.subject;

    // Verify user has admin role in the clinic
    const hasAdminRole = await checkFlowRole(ctx, args.clinicId, authUserId, ["admin"]);
    if (!hasAdminRole) {
      throw forbidden("Admin role required to deactivate flows");
    }

    // Get the flow to verify it exists and belongs to the clinic
    const flow = await ctx.db.get(args.flowId);
    if (!flow) {
      throw notFound("Flow not found");
    }

    if (flow.clinicId !== args.clinicId) {
      throw forbidden("Flow does not belong to this clinic");
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_authUserId", (q) => q.eq("authUserId", authUserId))
      .first();

    // Log audit before deactivating
    await logFlowOperation(
      ctx,
      "flow.deactivate" as const,
      flow.clinicId,
      args.flowId,
      authUserId,
      user?.email,
      { previousStatus: flow.status },
    );

    // Archive this flow
    const updatedFlow = await ctx.db.patch(args.flowId, {
      status: "archived",
      activeVersionId: undefined,
    });

    return updatedFlow;
  },
});
