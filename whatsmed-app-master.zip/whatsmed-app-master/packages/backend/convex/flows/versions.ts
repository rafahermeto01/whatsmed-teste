import { v } from "convex/values";

import { logFlowOperation } from "./audit";
import { checkFlowRole, hasFlowAccess } from "./auth";
import { mutation, query } from "../_generated/server";
import { unauthorized, forbidden, notFound } from "../lib/errors";

/**
 * Flow Version Management Module
 *
 * This module handles immutable flow version management with these key principles:
 *
 * IMMUTABLE VERSIONS:
 * - Once created, versions cannot be modified (no updatedAt field)
 * - Edits create new versions, preserving complete audit trail
 * - Version numbers are sequential integers (1, 2, 3...)
 *
 * ACTIVE VERSION TRACKING:
 * - Each flow has an activeVersionId pointing to the current version
 * - First version is auto-activated when created
 * - Admins and staff can activate any existing version via activateVersion
 *
 * STICKY VERSIONING:
 * - Flow executions are pinned to flowVersionId (not flow.activeVersionId)
 * - Active executions continue with their starting version even if a new version is activated
 * - Only new executions use the latest active version (VERS-02, VERS-03, VERS-04)
 *
 * MULTI-TENANT ISOLATION:
 * - All version operations are scoped to clinicId
 * - Users can only access versions from flows in their clinics
 */

/**
 * Create a new immutable flow version
 *
 * Creates a new version for a flow with the provided nodes, connections,
 * and variables. Versions are immutable - once created they cannot be modified.
 * Version numbers are sequential integers starting from 1.
 *
 * If this is the first version for the flow (versionNumber === 1), it is
 * automatically set as the active version for the flow.
 *
 * @requires admin or staff role in the flow's clinic
 */
export const createFlowVersion = mutation({
  args: {
    flowId: v.id("flows"),
    nodes: v.array(
      v.object({
        id: v.string(),
        type: v.string(),
        data: v.any(),
        position: v.object({ x: v.number(), y: v.number() }),
      }),
    ),
    connections: v.array(
      v.object({
        id: v.string(),
        source: v.string(),
        target: v.string(),
        sourceHandle: v.optional(v.string()),
        targetHandle: v.optional(v.string()),
      }),
    ),
    variables: v.optional(
      v.array(
        v.object({
          name: v.string(),
          type: v.union(v.literal("string"), v.literal("number"), v.literal("boolean")),
          defaultValue: v.optional(v.any()),
          description: v.optional(v.string()),
        }),
      ),
    ),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw unauthorized("Unauthorized");

    const userId = identity.subject;
    const flow = await ctx.db.get(args.flowId);
    if (!flow) throw notFound("Flow not found");

    // Verify user has access to this flow's clinic
    const hasAccess = await hasFlowAccess(ctx, flow.clinicId, userId);
    if (!hasAccess) throw unauthorized("Unauthorized");

    const hasEditRole = await checkFlowRole(ctx, flow.clinicId, userId, [
      "admin",
      "staff",
      "super_admin",
    ]);
    if (!hasEditRole) throw forbidden("Insufficient permissions");

    // Calculate next version number
    const existingVersions = await ctx.db
      .query("flowVersions")
      .withIndex("by_flow", (q) => q.eq("flowId", args.flowId))
      .collect();

    const nextVersionNumber = existingVersions.length + 1;

    // Create immutable version
    const versionId = await ctx.db.insert("flowVersions", {
      clinicId: flow.clinicId,
      flowId: args.flowId,
      versionNumber: nextVersionNumber,
      nodes: args.nodes,
      connections: args.connections,
      variables: args.variables || [],
      createdBy: userId,
      createdAt: Date.now(),
    });

    // If this is first version, set as active
    if (nextVersionNumber === 1) {
      await ctx.db.patch(args.flowId, {
        activeVersionId: versionId,
        updatedAt: Date.now(),
      });
    }

    return versionId;
  },
});

/**
 * List all versions for a flow
 *
 * Returns version history for a specific flow, sorted newest first.
 * Each version includes an isActive flag indicating whether it's the
 * currently active version for the flow (VERS-01).
 *
 * @requires access to the flow's clinic
 */
export const listFlowVersions = query({
  args: {
    flowId: v.id("flows"),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];

    const userId = identity.subject;
    const flow = await ctx.db.get(args.flowId);
    if (!flow) throw notFound("Flow not found");

    // Verify user has access to this flow's clinic
    const hasAccess = await hasFlowAccess(ctx, flow.clinicId, userId);
    if (!hasAccess) throw unauthorized("Unauthorized");

    // Get all versions for this flow
    const versions = await ctx.db
      .query("flowVersions")
      .withIndex("by_flow", (q) => q.eq("flowId", args.flowId))
      .collect();

    // Sort by version number (descending for history view)
    versions.sort((a, b) => b.versionNumber - a.versionNumber);

    // Mark which version is active
    return versions.map((version) => ({
      id: version._id,
      versionNumber: version.versionNumber,
      nodes: version.nodes,
      connections: version.connections,
      variables: version.variables,
      createdAt: version.createdAt,
      createdBy: version.createdBy,
      isActive: version._id === flow.activeVersionId,
    }));
  },
});

/**
 * Get the active version for a flow
 *
 * Returns the currently active version for a flow, which is used
 * by the execution engine to get the current structure for new
 * conversations (VERS-03).
 *
 * @requires access to the flow's clinic
 */
export const getActiveVersion = query({
  args: {
    flowId: v.id("flows"),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw unauthorized("Unauthorized");

    const userId = identity.subject;
    const flow = await ctx.db.get(args.flowId);
    if (!flow) throw notFound("Flow not found");

    // Verify user has access to this flow's clinic
    const hasAccess = await hasFlowAccess(ctx, flow.clinicId, userId);
    if (!hasAccess) throw unauthorized("Unauthorized");

    // If no active version, return null
    if (!flow.activeVersionId) return null;

    // Get active version
    const version = await ctx.db.get(flow.activeVersionId);
    if (!version) return null;

    return {
      id: version._id,
      versionNumber: version.versionNumber,
      nodes: version.nodes,
      connections: version.connections,
      variables: version.variables,
      createdAt: version.createdAt,
      createdBy: version.createdBy,
    };
  },
});

/**
 * Activate a specific version for a flow
 *
 * Sets the activeVersionId on the flow object, making the specified
 * version the one used for new flow executions. Existing executions
 * continue with their pinned versions (VERS-02, VERS-04).
 *
 * This allows admin/staff to switch which version new conversations use
 * while preserving in-progress conversations on their original versions.
 *
 * @requires admin or staff role in the flow's clinic
 */
export const activateVersion = mutation({
  args: {
    flowId: v.id("flows"),
    versionId: v.id("flowVersions"),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw unauthorized("Unauthorized");

    const userId = identity.subject;
    const flow = await ctx.db.get(args.flowId);
    if (!flow) throw notFound("Flow not found");

    // Verify user has access to this flow's clinic
    const hasAccess = await hasFlowAccess(ctx, flow.clinicId, userId);
    if (!hasAccess) throw unauthorized("Unauthorized");

    const hasEditRole = await checkFlowRole(ctx, flow.clinicId, userId, [
      "admin",
      "staff",
      "super_admin",
    ]);
    if (!hasEditRole) throw forbidden("Insufficient permissions");

    const user = await ctx.db
      .query("users")
      .withIndex("by_authUserId", (q) => q.eq("authUserId", userId))
      .first();

    // Verify version belongs to this flow
    const version = await ctx.db.get(args.versionId);
    if (!version || version.flowId !== args.flowId) {
      throw notFound("Version not found for this flow");
    }

    await logFlowOperation(
      ctx,
      "flowVersion.activate",
      flow.clinicId,
      args.flowId,
      userId,
      user?.email,
      { versionNumber: version.versionNumber, previousVersionId: flow.activeVersionId },
    );

    // Update flow's active version
    await ctx.db.patch(args.flowId, {
      activeVersionId: args.versionId,
      updatedAt: Date.now(),
    });

    return { success: true };
  },
});
