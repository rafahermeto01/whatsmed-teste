/**
 * Flow Formatters Module
 *
 * This module provides utilities to convert flow structures into natural language
 * instructions suitable for AI consumption. Flows are formatted as guidance
 * documents rather than strict execution scripts, allowing AI autonomy while
 * providing conversational structure.
 *
 * @module flows/formatters
 */

import { sanitizeVariable } from "./sanitization";

/**
 * Flow node data structure
 */
interface FlowNode {
  id: string;
  type: string;
  data: Record<string, unknown>;
  position: { x: number; y: number };
}

/**
 * Flow edge/connection data structure
 */
interface FlowEdge {
  id: string;
  source: string;
  target: string;
  sourceHandle?: string;
  targetHandle?: string;
}

/**
 * Flow variable definition
 */
interface FlowVariable {
  name: string;
  type: "string" | "number" | "boolean";
  defaultValue?: unknown;
  description?: string;
}

/**
 * Flow version data structure from Convex
 */
export interface FlowVersionData {
  _id: string;
  versionNumber: number;
  nodes: FlowNode[];
  connections: FlowEdge[];
  variables?: FlowVariable[];
}

/**
 * Format a flow version into natural language instructions for AI consumption
 *
 * Converts React Flow structure (nodes, edges, variables) into a clear,
 * conversational guidance document that helps AI agents follow clinic-defined
 * conversation flows while maintaining flexibility.
 *
 * @param flowVersion - Flow version object from Convex flowVersions table
 * @returns Formatted natural language instructions as a string
 *
 * @example
 * ```typescript
 * const instructions = formatFlowForLLM(flowVersion);
 * // Returns: "Follow this conversation flow as guidance:\n\n1. Welcome message..."
 * ```
 */
export function formatFlowForLLM(flowVersion: FlowVersionData): string {
  const { nodes, connections, variables, versionNumber } = flowVersion;

  // Build node instructions
  const nodeInstructions = nodes
    .filter((n) => n.type !== "start" && n.type !== "end")
    .map((node, index) => {
      const instruction = formatNodeInstructions(node, index + 1);
      return instruction;
    })
    .join("\n\n");

  // Build flow connections showing branching logic
  const flowPaths = buildFlowPaths(nodes, connections);

  // Build variable reference section
  const variablesSection = buildVariablesSection(variables);

  // Construct the complete flow instructions
  return createFlowInstructions({
    nodeInstructions,
    flowPaths,
    variablesSection,
    versionNumber,
    nodeCount: nodes.length,
    connectionCount: connections.length,
  });
}

/**
 * Format instructions for a single node based on its type
 *
 * @param node - Flow node with type and data
 * @param stepNumber - Step number in the flow sequence
 * @returns Formatted natural language instruction for the node
 */
export function formatNodeInstructions(node: FlowNode, stepNumber: number): string {
  const data = node.data as Record<string, unknown>;
  const title = (data?.title as string) || node.type;

  switch (node.type) {
    case "message": {
      const messageText = sanitizeVariable((data?.text as string) || "");
      return `${stepNumber}. **${title}** (Message Node)\n   - Purpose: Send a message to the patient\n   - Content: "${messageText}"\n   - Approach: Deliver this message naturally in conversation. You may adapt the tone while keeping the core information.`;
    }

    case "input": {
      const prompt = sanitizeVariable((data?.prompt as string) || "");
      const field = (data?.field as string) || "value";
      const inputType = (data?.inputType as string) || "text";
      return `${stepNumber}. **${title}** (Input Node)\n   - Purpose: Collect ${field} from patient\n   - Ask: "${prompt}"\n   - Input type: ${inputType}\n   - Approach: Ask naturally and wait for response. Store the value in variable {{${field}}}.`;
    }

    case "condition": {
      const condition = sanitizeVariable((data?.condition as string) || "");
      return `${stepNumber}. **${title}** (Condition Node)\n   - Purpose: Decision point based on patient response\n   - Check: ${condition}\n   - Approach: Evaluate naturally based on conversation context.`;
    }

    case "wait": {
      const duration = (data?.duration as number) || 24;
      const unit = (data?.unit as string) || "hours";
      const timeoutAction = (data?.timeoutAction as string) || "resume";
      const resumeCondition = (data?.resumeCondition as string) || "";
      const timeoutActionText =
        timeoutAction === "escalate" ? "escalate to human staff" : "continue flow";

      let instructions = `${stepNumber}. **${title}** (Wait Node)\n   - Purpose: Pause flow execution\n   - Duration: ${duration} ${unit}`;

      if (resumeCondition) {
        instructions += `\n   - Resume condition: Can resume early if "${resumeCondition}" is met`;
      }

      instructions += `\n   - Timeout action: ${timeoutActionText}`;
      instructions += `\n   - Approach: Inform patient about the wait if appropriate. If timeout expires, ${timeoutActionText}.`;

      return instructions;
    }

    default:
      return `${stepNumber}. **${title}** (${node.type} Node)\n   - Data: ${JSON.stringify(data)}\n   - Approach: Handle according to node type.`;
  }
}

/**
 * Build a description of flow paths showing branching logic
 *
 * @param nodes - Array of flow nodes
 * @param connections - Array of flow edges
 * @returns Formatted description of flow paths
 */
function buildFlowPaths(nodes: FlowNode[], connections: FlowEdge[]): string {
  if (connections.length === 0) {
    return "Linear flow: Follow nodes in sequence.";
  }

  const pathDescriptions = connections.map((conn) => {
    const sourceNode = nodes.find((n) => n.id === conn.source);
    const targetNode = nodes.find((n) => n.id === conn.target);

    const sourceTitle =
      ((sourceNode?.data as Record<string, unknown>)?.title as string) || conn.source;
    const targetTitle =
      ((targetNode?.data as Record<string, unknown>)?.title as string) || conn.target;

    // Handle condition branching labels
    if (conn.sourceHandle) {
      const conditionLabel =
        conn.sourceHandle === "yes"
          ? "If yes/confirmed"
          : conn.sourceHandle === "no"
            ? "If no/denied"
            : `If ${conn.sourceHandle}`;
      return `- ${conditionLabel}: Go to "${targetTitle}"`;
    }

    return `- From "${sourceTitle}" → Go to "${targetTitle}"`;
  });

  return pathDescriptions.join("\n");
}

/**
 * Build the variables reference section
 *
 * @param variables - Array of flow variable definitions
 * @returns Formatted variables section
 */
function buildVariablesSection(variables?: FlowVariable[]): string {
  if (!variables || variables.length === 0) {
    return "No variables defined for this flow.";
  }

  const variableLines = variables.map((v) => {
    const defaultValue = v.defaultValue !== undefined ? ` (default: ${v.defaultValue})` : "";
    const description = v.description ? ` - ${v.description}` : "";
    return `- \`{{${v.name}}}\` (${v.type})${defaultValue}${description}`;
  });

  return variableLines.join("\n");
}

/**
 * Options for creating flow instructions
 */
interface FlowInstructionsOptions {
  nodeInstructions: string;
  flowPaths: string;
  variablesSection: string;
  versionNumber: number;
  nodeCount: number;
  connectionCount: number;
}

/**
 * Create the complete flow instructions document
 *
 * Combines all flow elements into a comprehensive guidance document
 * for AI consumption.
 *
 * @param options - Flow instruction components
 * @returns Complete formatted instructions string
 */
export function createFlowInstructions(options: FlowInstructionsOptions): string {
  const {
    nodeInstructions,
    flowPaths,
    variablesSection,
    versionNumber,
    nodeCount,
    connectionCount,
  } = options;

  return `FLOW GUIDANCE: Follow this conversation structure as guidance for your interaction with the patient.

⚠️ IMPORTANT: This is guidance, not a strict script. You have autonomy to:
- Deviate when patient needs require it
- Answer questions outside the flow naturally
- Skip or combine steps as appropriate
- Prioritize patient experience over rigid structure

---

**Flow Structure (Version ${versionNumber})**
${nodeCount} nodes, ${connectionCount} connections

${nodeInstructions}

---

**Flow Paths & Branching Logic:**
${flowPaths}

---

**Available Variables:**
Use these variables to personalize messages:
${variablesSection}

---

**Guidance Notes:**
- Tool calls are hidden from patients - they see natural responses
- If a tool fails, handle gracefully with natural explanations
- When patient escalates to human, flow context pauses
- Resume flow guidance when conversation returns to AI
- Keep conversation natural and empathetic throughout
`;
}

/**
 * Format flow instructions for system prompt injection
 *
 * Creates a concise version suitable for direct injection into
 * the AI agent's system prompt while maintaining key guidance.
 *
 * @param flowVersion - Flow version data
 * @returns Condensed flow instructions for system prompt
 */
export function formatFlowForSystemPrompt(flowVersion: FlowVersionData): string {
  const { nodes, connections, variables } = flowVersion;

  // Build condensed node list
  const nodeList = nodes
    .filter((n) => n.type !== "start" && n.type !== "end")
    .map((node, index) => {
      const data = node.data as Record<string, unknown>;
      const title = (data?.title as string) || node.type;

      switch (node.type) {
        case "message":
          return `${index + 1}. Message: "${sanitizeVariable((data?.text as string) || "")}"`;
        case "input":
          return `${index + 1}. Input: Ask "${sanitizeVariable((data?.prompt as string) || "")}" (store in {{${(data?.field as string) || "value"}}})`;
        case "condition":
          return `${index + 1}. Condition: ${sanitizeVariable((data?.condition as string) || "")}`;
        case "wait":
          return `${index + 1}. Wait: ${(data?.duration as number) || "24"} ${(data?.unit as string) || "hours"} (timeout: ${(data?.timeoutAction as string) || "resume"})`;
        default:
          return `${index + 1}. ${title}`;
      }
    })
    .join("\n");

  // Build connection summary
  const connectionSummary = connections
    .map((conn) => {
      const sourceNode = nodes.find((n) => n.id === conn.source);
      const targetNode = nodes.find((n) => n.id === conn.target);
      const sourceTitle =
        ((sourceNode?.data as Record<string, unknown>)?.title as string) || conn.source;
      const targetTitle =
        ((targetNode?.data as Record<string, unknown>)?.title as string) || conn.target;

      if (conn.sourceHandle) {
        return `${sourceTitle} [${conn.sourceHandle}] → ${targetTitle}`;
      }
      return `${sourceTitle} → ${targetTitle}`;
    })
    .join("\n");

  // Build variable summary
  const variableSummary = variables?.length
    ? variables.map((v) => `{{${v.name}}} (${v.type})`).join(", ")
    : "None";

  return `FLOW GUIDANCE:
Follow this structure as guidance (not strict rules):

Steps:
${nodeList}

Paths:
${connectionSummary}

Variables: ${variableSummary}

Note: Deviate naturally when patient needs require it. Tool calls hidden from patients.`;
}

// Re-export the context formatter's formatFlowForLlm for backward compatibility
export { formatFlowForLlm } from "./contextFormatter";

// Default export for convenience
export default formatFlowForLLM;
