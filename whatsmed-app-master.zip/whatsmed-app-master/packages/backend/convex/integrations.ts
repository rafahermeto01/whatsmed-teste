import { v } from "convex/values";

import { internal } from "./_generated/api";
import { Doc } from "./_generated/dataModel";
import { action, internalQuery, mutation, query, internalMutation } from "./_generated/server";
import { authComponent } from "./auth";

// Helper to get authenticated user and clinicId
async function getAuth(ctx: any): Promise<{ user: any; clinicId: string }> {
  const user = await authComponent.getAuthUser(ctx);
  if (!user) {
    throw new Error("Unauthorized");
  }

  // Try to find app user to get reliable clinicId
  let appUser: Doc<"users"> | null | undefined;
  if (ctx.db) {
    appUser = await ctx.db
      .query("users")
      .withIndex("by_email", (q: any) => q.eq("email", user.email))
      .first();
  } else {
    appUser = await ctx.runQuery(internal.integrations.getUserByEmailInternal, {
      email: user.email,
    });
  }

  const clinicId = appUser?.clinicId || (user as any).clinicId;

  return { user, clinicId: clinicId as string };
}

type EvolutionBootstrapClient = {
  createInstance: (
    instanceName: string,
    webhookUrl?: string,
  ) => Promise<{
    hash: {
      apikey: string;
    };
  }>;
};

type EvolutionWebhookClient = {
  setWebhook: (instanceName: string, url: string, enabled?: boolean) => Promise<unknown>;
};

type EvolutionStatusClient = {
  getConnectionStatus: (instanceName: string) => Promise<{
    instance?: {
      state?: string;
    };
  }>;
};

const EVOLUTION_WEBHOOK_PATH = "/api/webhooks/evolution";
const EVOLUTION_WEBHOOK_OVERRIDE_ENV = "EVOLUTION_WEBHOOK_URL";

function getEvolutionWebhookUrl() {
  const explicitWebhookUrl = process.env[EVOLUTION_WEBHOOK_OVERRIDE_ENV]?.trim();
  if (explicitWebhookUrl) {
    return explicitWebhookUrl;
  }

  const convexSiteUrl = process.env.CONVEX_SITE_URL?.trim();
  if (convexSiteUrl) {
    return new URL(
      EVOLUTION_WEBHOOK_PATH,
      convexSiteUrl.endsWith("/") ? convexSiteUrl : `${convexSiteUrl}/`,
    ).toString();
  }

  const convexCloudUrl = process.env.CONVEX_CLOUD_URL?.trim();
  if (convexCloudUrl) {
    return new URL(
      `/http${EVOLUTION_WEBHOOK_PATH}`,
      convexCloudUrl.endsWith("/") ? convexCloudUrl : `${convexCloudUrl}/`,
    ).toString();
  }

  const fallbackSiteUrl = [process.env.SITE_URL, process.env.VITE_SITE_URL]
    .flatMap((value) => (value ?? "").split(","))
    .map((value) => value.trim())
    .find(Boolean);

  if (!fallbackSiteUrl) {
    throw new Error(
      "CONVEX_SITE_URL or EVOLUTION_WEBHOOK_URL must be configured to register the Evolution webhook",
    );
  }

  return new URL(
    EVOLUTION_WEBHOOK_PATH,
    fallbackSiteUrl.endsWith("/") ? fallbackSiteUrl : `${fallbackSiteUrl}/`,
  ).toString();
}

async function ensureEvolutionWebhookConfigured(params: {
  ctx: any;
  clinicId: string;
  instanceName: string;
  client: EvolutionWebhookClient;
  webhookUrl: string;
}) {
  const { ctx, clinicId, instanceName, client, webhookUrl } = params;

  await client.setWebhook(instanceName, webhookUrl, true);
  await ctx.runMutation(internal.integrations.updateWebhookConfiguredInternal, {
    clinicId,
    webhookConfigured: true,
  });
}

async function syncEvolutionStatus(params: {
  ctx: any;
  clinicId: string;
  instanceName: string;
  client: EvolutionStatusClient;
}) {
  const { ctx, clinicId, instanceName, client } = params;

  try {
    const state = await client.getConnectionStatus(instanceName);
    const status = state?.instance?.state || "disconnected";
    const normalizedStatus = status.toLowerCase();

    await ctx.runMutation(internal.integrations.updateStatusInternal, {
      clinicId,
      status:
        normalizedStatus === "open"
          ? "connected"
          : normalizedStatus === "connecting"
            ? "connecting"
            : "disconnected",
    });
  } catch (error) {
    console.error("Failed to fetch instance status:", error);
    await ctx.runMutation(internal.integrations.updateStatusInternal, {
      clinicId,
      status: "disconnected",
    });
  }
}

function isEvolutionInstanceAlreadyInUseError(error: unknown) {
  if (!(error instanceof Error)) {
    return false;
  }

  return error.message.includes("403 Forbidden") && error.message.includes("is already in use");
}

export async function ensureEvolutionInstanceRecord(params: {
  ctx: any;
  clinicId: string;
  instance: Doc<"whatsappInstances"> | null;
  client: EvolutionBootstrapClient;
  webhookUrl?: string;
}) {
  const { ctx, clinicId, instance, client, webhookUrl } = params;
  const instanceName = `clinic_${clinicId}`;
  const canReuseExisting =
    !!instance && instance.provider === "evolution" && !!instance.instanceName;

  if (canReuseExisting) {
    return instance;
  }

  try {
    const created = await client.createInstance(instanceName, webhookUrl);

    await ctx.runMutation(internal.integrations.saveInstanceInternal, {
      clinicId,
      instanceName,
      apikey: created.hash.apikey,
      status: "disconnected",
    });

    return {
      ...instance,
      clinicId,
      instanceName,
      apikey: created.hash.apikey,
      status: "disconnected" as const,
      provider: "evolution" as const,
    };
  } catch (error) {
    if (!isEvolutionInstanceAlreadyInUseError(error)) {
      throw error;
    }

    await ctx.runMutation(internal.integrations.saveInstanceInternal, {
      clinicId,
      instanceName,
      apikey: instance?.provider === "evolution" ? instance.apikey : undefined,
      status: "disconnected",
    });

    return {
      ...instance,
      clinicId,
      instanceName,
      apikey: instance?.provider === "evolution" ? instance.apikey : undefined,
      status: "disconnected" as const,
      provider: "evolution" as const,
    };
  }
}

export const getUserByEmailInternal = internalQuery({
  args: { email: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", args.email))
      .first();
  },
});

export const updateInstanceStatus = internalMutation({
  args: {
    instanceId: v.id("whatsappInstances"),
    status: v.string(),
    qrcode: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const patch: any = {
      status: args.status as any,
      updatedAt: Date.now(),
    };
    if (args.qrcode !== undefined) {
      patch.qrcode = args.qrcode;
    }
    await ctx.db.patch(args.instanceId, patch);
  },
});

// Ensure user exists in app users table
export const ensureUser = mutation({
  args: {},
  handler: async (ctx) => {
    const { user, clinicId } = await getAuth(ctx);
    if (!clinicId) return; // Should already be handled by getAuth
  },
});

export const findInstanceByName = internalQuery({
  args: { instanceName: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("whatsappInstances")
      .withIndex("by_instanceName", (q) => q.eq("instanceName", args.instanceName))
      .first();
  },
});

export const getWhatsAppInstance = query({
  args: {},
  handler: async (ctx) => {
    const { clinicId } = await getAuth(ctx);
    const instance = await ctx.db
      .query("whatsappInstances")
      .withIndex("by_clinic", (q) => q.eq("clinicId", clinicId))
      .first();

    if (!instance) {
      return null;
    }

    const { apikey: _apikey, metaAccessToken: _metaAccessToken, ...safeInstance } = instance;

    return {
      ...safeInstance,
      hasApiKey: Boolean(instance.apikey),
      hasMetaAccessToken: Boolean(instance.metaAccessToken),
    };
  },
});

export const getWhatsAppInstanceInternal = internalQuery({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("whatsappInstances")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .first();
  },
});

export const createInstance = action({
  args: {},
  handler: async (
    ctx,
  ): Promise<{
    instanceName: string;
    status: "disconnected" | "connecting" | "connected";
    reused: boolean;
  }> => {
    const { clinicId } = await getAuth(ctx);

    const instance: Doc<"whatsappInstances"> | null = await ctx.runQuery(
      internal.integrations.getWhatsAppInstanceInternal,
      {
        clinicId,
      },
    );

    const evolution = await import("./lib/evolution");
    const client = new evolution.EvolutionClient();
    const webhookUrl = getEvolutionWebhookUrl();

    const ensuredInstance = await ensureEvolutionInstanceRecord({
      ctx,
      clinicId,
      instance,
      client,
      webhookUrl,
    });

    await ensureEvolutionWebhookConfigured({
      ctx,
      clinicId,
      instanceName: ensuredInstance.instanceName,
      client,
      webhookUrl,
    });

    return {
      instanceName: ensuredInstance.instanceName,
      status: ensuredInstance.status,
      reused: Boolean(instance?.provider === "evolution" || ensuredInstance.apikey === undefined),
    };
  },
});

export const connectInstance = action({
  args: {},
  handler: async (ctx) => {
    const { clinicId } = await getAuth(ctx);

    let instance = await ctx.runQuery(internal.integrations.getWhatsAppInstanceInternal, {
      clinicId,
    });

    const evolution = await import("./lib/evolution");
    const client = new evolution.EvolutionClient();
    const webhookUrl = getEvolutionWebhookUrl();

    instance = await ensureEvolutionInstanceRecord({
      ctx,
      clinicId,
      instance,
      client,
      webhookUrl,
    });

    await ensureEvolutionWebhookConfigured({
      ctx,
      clinicId,
      instanceName: instance.instanceName,
      client,
      webhookUrl,
    });

    const result = await client.connectInstance(instance.instanceName);

    if (result.base64) {
      await ctx.runMutation(internal.integrations.updateQrCodeInternal, {
        clinicId,
        qrcode: result.base64,
        status: "connecting",
      });
    }

    return result;
  },
});

export const deleteInstance = action({
  args: {},
  handler: async (ctx) => {
    const { clinicId } = await getAuth(ctx);

    const instance = await ctx.runQuery(internal.integrations.getWhatsAppInstanceInternal, {
      clinicId,
    });

    if (instance) {
      const evolution = await import("./lib/evolution");
      const client = new evolution.EvolutionClient();
      await client.logoutInstance(instance.instanceName);
      await client.deleteInstance(instance.instanceName);
    }

    await ctx.runMutation(internal.integrations.deleteInstanceInternal, { clinicId });
  },
});

export const fetchInstanceStatus = action({
  args: {},
  handler: async (ctx) => {
    const { clinicId } = await getAuth(ctx);

    const instance = await ctx.runQuery(internal.integrations.getWhatsAppInstanceInternal, {
      clinicId,
    });

    if (!instance) return;
    if (instance.provider === "meta") return;

    const evolution = await import("./lib/evolution");
    const client = new evolution.EvolutionClient();

    try {
      await ensureEvolutionWebhookConfigured({
        ctx,
        clinicId,
        instanceName: instance.instanceName,
        client,
        webhookUrl: getEvolutionWebhookUrl(),
      });
    } catch (error) {
      console.error("Failed to ensure Evolution webhook:", error);
      await ctx.runMutation(internal.integrations.updateWebhookConfiguredInternal, {
        clinicId,
        webhookConfigured: false,
      });
    }

    await syncEvolutionStatus({
      ctx,
      clinicId,
      instanceName: instance.instanceName,
      client,
    });
  },
});

/**
 * Switch WhatsApp Provider (Evolution <-> Meta)
 */
export const switchWhatsAppProvider = mutation({
  args: {
    provider: v.union(v.literal("evolution"), v.literal("meta")),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);
    const instance = await ctx.db
      .query("whatsappInstances")
      .withIndex("by_clinic", (q) => q.eq("clinicId", clinicId))
      .first();

    if (!instance) {
      throw new Error("No WhatsApp instance found");
    }

    await ctx.db.patch(instance._id, {
      provider: args.provider,
    });
  },
});

/**
 * Update Meta Configuration
 */
export const updateMetaConfig = mutation({
  args: {
    phoneNumberId: v.string(),
    wabaId: v.string(),
    accessToken: v.string(),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);
    let instance = await ctx.db
      .query("whatsappInstances")
      .withIndex("by_clinic", (q) => q.eq("clinicId", clinicId))
      .first();

    if (!instance) {
      // Create placeholder instance if not exists
      await ctx.db.insert("whatsappInstances", {
        clinicId,
        instanceName: `meta_${clinicId}`, // Placeholder
        status: "disconnected",
        webhookConfigured: false,
        createdAt: Date.now(),
        provider: "meta",
        metaPhoneNumberId: args.phoneNumberId,
        metaWabaId: args.wabaId,
        metaAccessToken: args.accessToken,
      });
    } else {
      await ctx.db.patch(instance._id, {
        metaPhoneNumberId: args.phoneNumberId,
        metaWabaId: args.wabaId,
        metaAccessToken: args.accessToken,
        // If switching to Meta, ensure provider is set
        // But let the user explicitly switch using switchWhatsAppProvider
      });
    }
  },
});

// Internal mutations
export const saveInstanceInternal = internalMutation({
  args: {
    clinicId: v.string(),
    instanceName: v.string(),
    apikey: v.optional(v.string()),
    status: v.union(v.literal("disconnected"), v.literal("connecting"), v.literal("connected")),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("whatsappInstances")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .first();

    if (existing) {
      await ctx.db.patch(existing._id, {
        instanceName: args.instanceName,
        status: args.status,
        qrcode: undefined,
        provider: "evolution",
        metaPhoneNumberId: undefined,
        metaWabaId: undefined,
        metaAccessToken: undefined,
        updatedAt: Date.now(),
        ...(args.apikey !== undefined ? { apikey: args.apikey } : {}),
      });
    } else {
      await ctx.db.insert("whatsappInstances", {
        clinicId: args.clinicId,
        instanceName: args.instanceName,
        status: args.status,
        webhookConfigured: false,
        createdAt: Date.now(),
        provider: "evolution", // Default
        ...(args.apikey !== undefined ? { apikey: args.apikey } : {}),
      });
    }
  },
});

export const updateQrCodeInternal = internalMutation({
  args: {
    clinicId: v.string(),
    qrcode: v.string(),
    status: v.string(),
  },
  handler: async (ctx, args) => {
    const instance = await ctx.db
      .query("whatsappInstances")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .first();

    if (instance) {
      await ctx.db.patch(instance._id, {
        qrcode: args.qrcode,
        status: args.status as any,
        updatedAt: Date.now(),
      });
    }
  },
});

export const updateStatusInternal = internalMutation({
  args: {
    clinicId: v.string(),
    status: v.string(),
  },
  handler: async (ctx, args) => {
    const instance = await ctx.db
      .query("whatsappInstances")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .first();

    if (instance) {
      await ctx.db.patch(instance._id, {
        status: args.status as any,
        updatedAt: Date.now(),
      });
    }
  },
});

export const updateWebhookConfiguredInternal = internalMutation({
  args: {
    clinicId: v.string(),
    webhookConfigured: v.boolean(),
  },
  handler: async (ctx, args) => {
    const instance = await ctx.db
      .query("whatsappInstances")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .first();

    if (instance) {
      await ctx.db.patch(instance._id, {
        webhookConfigured: args.webhookConfigured,
        updatedAt: Date.now(),
      });
    }
  },
});

export const deleteInstanceInternal = internalMutation({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    const instance = await ctx.db
      .query("whatsappInstances")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .first();

    if (instance) {
      await ctx.db.delete(instance._id);
    }
  },
});
