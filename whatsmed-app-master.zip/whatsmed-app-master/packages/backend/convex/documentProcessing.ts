"use node";

import { v } from "convex/values";

import * as mastraModule from "../mastra";
import { internal, api } from "./_generated/api";
import { internalAction } from "./_generated/server";

const internalAny = internal as any;
const apiAny = api as any;

function formatDocumentHistoryMessage(message: any): string {
  if (message?.body) return message.body;
  if (message?.mediaType === "image") return "[Imagem recebida]";
  if (message?.mediaType === "audio") return "[Audio recebido]";
  if (message?.mediaType === "document") return "[Documento recebido]";
  if (message?.mediaType === "video") return "[Video recebido]";
  return "[Midia recebida]";
}

function mapStoredMessageToAgentMessage(message: any): {
  role: "assistant" | "user";
  content: string;
} {
  return {
    role: message.direction === "out" ? "assistant" : "user",
    content: formatDocumentHistoryMessage(message),
  };
}

// ============================================
// DOCUMENT PROCESSING WITH OPENAI
// ============================================

/**
 * Process incoming document message with AI
 * Handles files from WhatsApp (images, documents, audio)
 */
export const processDocumentWithAi = internalAction({
  args: {
    clinicId: v.string(),
    chatId: v.id("chats"),
    messageId: v.id("messages"),
    patientId: v.optional(v.id("patients")),
  },
  handler: async (
    ctx,
    args,
  ): Promise<{
    processed: boolean;
    aiResponse: string | null;
    model?: string;
    reason?: string;
    error?: string;
  }> => {
    console.log("[processDocumentWithAi] Processing document message...");

    // Initialize Mastra tools
    (global as any).ConvexInternal = {
      whatsapp: internalAny.whatsapp,
      patients: internalAny.patients,
      // Merge api.appointments (public queries) with internal.appointments (internal mutations)
      appointments: {
        ...apiAny.appointments,
        ...internalAny.appointments,
      },
      clinics: internalAny.clinics,
      auditLogs: internalAny.auditLogs,
      automation: internalAny.automation,
    };

    // Get the incoming message
    const message = await ctx.runQuery(internal.whatsappInternal.getMessage, {
      id: args.messageId,
    });
    if (!message || message.direction !== "in") {
      return { processed: false, reason: "Invalid message", aiResponse: null };
    }

    // Get AI settings for this clinic
    const settings = await ctx.runQuery(internalAny.automation.getAiSettings, {
      clinicId: args.clinicId,
    });

    if (!settings || !settings.enabled) {
      console.log("[processDocumentWithAi] AI disabled");
      return { processed: true, aiResponse: null, reason: "ai_disabled" };
    }

    // Get or create clinic agent
    const _tools = mastraModule.createConvexTools(ctx, args.clinicId);
    const agent = mastraModule.getClinicAgent(args.clinicId, settings, ctx);

    // Prepare input for AI
    const prompt = message.body || "Por favor, analise este arquivo.";
    const _context = {
      patientName: args.patientId ? "Paciente" : undefined, // Will be filled by getPatientInfo tool
      documentType: message.mediaType,
      fileId: message.mediaStorageId,
      clinicId: args.clinicId,
    };

    try {
      // Mastra memory storage is not configured in this Convex action runtime, so use the
      // persisted chat transcript from Convex as the canonical conversation memory source.
      const previousMessages = await ctx.runQuery(
        internalAny.whatsappQueries.getChatMessagesInternal,
        {
          clinicId: args.clinicId,
          chatId: args.chatId,
          limit: 20,
        },
      );

      const agentMessages = previousMessages
        .filter((storedMessage: any) => storedMessage._id !== args.messageId)
        .map((storedMessage: any) => mapStoredMessageToAgentMessage(storedMessage));

      agentMessages.push({
        role: "user",
        content: prompt,
      });

      const result = await agent.generate(agentMessages, {
        maxSteps: 6,
        modelSettings: {
          temperature: 0,
        },
      });

      console.log("[processDocumentWithAi] AI analysis complete:", result.text?.substring(0, 200));

      // Store AI response in message or as separate record
      await ctx.runMutation(internalAny.whatsappInternal.updateMessageWithAiAnalysis, {
        messageId: args.messageId,
        aiAnalysis: result.text,
        analyzedAt: Date.now(),
      });

      return {
        processed: true,
        aiResponse: result.text,
        model: "OpenAI GPT-4o (Vision)",
      };
    } catch (error) {
      console.error("[processDocumentWithAi] AI analysis error:", error);

      // Fallback response
      const fallbackMessage = "Recebemos seu arquivo. Nossa equipe analisará em breve.";

      await ctx.runMutation(internalAny.whatsappInternal.updateMessageWithAiAnalysis, {
        messageId: args.messageId,
        aiAnalysis: fallbackMessage,
        analyzedAt: Date.now(),
        error: String(error),
      });

      return {
        processed: true,
        aiResponse: fallbackMessage,
        model: "fallback",
        error: String(error),
      };
    }
  },
});
