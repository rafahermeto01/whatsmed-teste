import { v } from "convex/values";

import { internal } from "./_generated/api";
import {
  action,
  internalAction,
  internalMutation,
  mutation,
  query,
  internalQuery,
} from "./_generated/server";
import { authComponent } from "./auth";
import { notFound } from "./lib/errors";

const internalAny = internal as any;

// Helper to get authenticated user and clinicId
async function getAuth(ctx: any) {
  const user = await authComponent.getAuthUser(ctx);
  if (!user) {
    throw new Error("Unauthorized");
  }

  // Try to find app user to get reliable clinicId
  const appUser = await ctx.db
    .query("users")
    .withIndex("by_email", (q: any) => q.eq("email", user.email))
    .first();

  const clinicId = appUser?.clinicId || (user as any).clinicId;

  return { user, clinicId: clinicId as string, userId: appUser?._id };
}

// ============== MUTATIONS ==============

export const addToWaitlist = mutation({
  args: {
    clinicId: v.string(),
    patientId: v.id("patients"),
    doctorId: v.id("users"),
    priority: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { clinicId, patientId, doctorId, priority, notes } = args;

    // Validate patient belongs to clinic
    const patient = await ctx.db.get(patientId);
    if (!patient || patient.clinicId !== clinicId) {
      throw notFound("Paciente não encontrado nesta clínica");
    }

    // Validate doctor belongs to clinic and is a doctor
    const doctor = await ctx.db.get(doctorId);
    if (!doctor || doctor.clinicId !== clinicId || doctor.role !== "doctor" || doctor.deletedAt) {
      throw notFound("Médico inválido");
    }

    // Create waitlist entry
    const waitlistId = await ctx.db.insert("waitlists", {
      clinicId,
      patientId,
      doctorId,
      requestedAt: Date.now(),
      priority,
      status: "waiting",
      notes,
      createdAt: Date.now(),
    });

    // Create audit log
    await ctx.runMutation(internalAny.auditLogs.insert, {
      action: "waitlist_add",
      clinicId,
      userId: (await getAuth(ctx)).userId,
      metadata: {
        waitlistId,
        patientId,
        doctorId,
        priority,
      },
      createdAt: Date.now(),
    });

    return await ctx.db.get(waitlistId);
  },
});

export const notifyPatient = mutation({
  args: {
    waitlistId: v.id("waitlists"),
  },
  handler: async (ctx, { waitlistId }) => {
    const { userId, clinicId } = await getAuth(ctx);

    const waitlist = await ctx.db.get(waitlistId);
    if (!waitlist || waitlist.clinicId !== clinicId) {
      throw notFound("Entrada de lista de espera não encontrada");
    }

    // Verify status is "waiting" before notifying
    if (waitlist.status !== "waiting") {
      throw new Error("Este paciente já foi notificado ou atribuído");
    }

    // Update status to notified
    await ctx.db.patch(waitlistId, {
      status: "notified",
      notifiedAt: Date.now(),
      updatedAt: Date.now(),
    });

    // Create audit log
    await ctx.runMutation(internalAny.auditLogs.insert, {
      action: "waitlist_notify",
      clinicId,
      userId,
      metadata: {
        waitlistId,
        patientId: waitlist.patientId,
      },
      createdAt: Date.now(),
    });

    return await ctx.db.get(waitlistId);
  },
});

export const assignAppointment = mutation({
  args: {
    waitlistId: v.id("waitlists"),
    appointmentId: v.id("appointments"),
  },
  handler: async (ctx, { waitlistId, appointmentId }) => {
    const { userId, clinicId } = await getAuth(ctx);

    // Verify waitlist entry
    const waitlist = await ctx.db.get(waitlistId);
    if (!waitlist || waitlist.clinicId !== clinicId) {
      throw notFound("Entrada de lista de espera não encontrada");
    }

    // Verify waitlist status is "notified"
    if (waitlist.status !== "notified") {
      throw new Error("O paciente deve ser notificado antes da atribuição");
    }

    // Verify appointment exists and belongs to clinic
    const appointment = await ctx.db.get(appointmentId);
    if (!appointment || appointment.clinicId !== clinicId) {
      throw notFound("Consulta não encontrada");
    }

    // Verify appointment doesn't have a different patient
    if (appointment.patientId && appointment.patientId !== waitlist.patientId) {
      throw new Error("Esta consulta já está atribuída a outro paciente");
    }

    // Link appointment to patient if not already linked
    if (!appointment.patientId) {
      await ctx.db.patch(appointmentId, {
        patientId: waitlist.patientId,
        updatedAt: Date.now(),
      });
    }

    // Update waitlist entry
    await ctx.db.patch(waitlistId, {
      appointmentId,
      status: "assigned",
      updatedAt: Date.now(),
    });

    // Create audit log
    await ctx.runMutation(internalAny.auditLogs.insert, {
      action: "waitlist_assign",
      clinicId,
      userId,
      metadata: {
        waitlistId,
        appointmentId,
        patientId: waitlist.patientId,
      },
      createdAt: Date.now(),
    });

    return {
      waitlist: await ctx.db.get(waitlistId),
      appointment: await ctx.db.get(appointmentId),
    };
  },
});

// ============== QUERIES ==============

export const listWaitlist = query({
  args: {
    clinicId: v.string(),
    status: v.optional(v.union(v.literal("waiting"), v.literal("notified"), v.literal("assigned"))),
    paginationOpts: v.object({
      numItems: v.number(),
      cursor: v.optional(v.string()),
    }),
  },
  handler: async (ctx, { clinicId, status, paginationOpts }) => {
    let queryBuilder;

    // Choose appropriate index based on filter
    if (status) {
      // Use by_clinic_status for filtering by status
      queryBuilder = ctx.db
        .query("waitlists")
        .withIndex("by_clinic_status", (q) => q.eq("clinicId", clinicId).eq("status", status));
    } else {
      // Use by_clinic_requestedAt for ordering by request time
      queryBuilder = ctx.db
        .query("waitlists")
        .withIndex("by_clinic_requestedAt", (q) => q.eq("clinicId", clinicId));
    }

    // Apply pagination
    const results = await queryBuilder.paginate({
      cursor: paginationOpts.cursor ?? null,
      numItems: paginationOpts.numItems,
    });

    // Fetch patient details and appointments for each waitlist entry
    const waitlistEntries = await Promise.all(
      results.page.map(async (entry) => {
        const patient = await ctx.db.get(entry.patientId);
        const appointment = entry.appointmentId ? await ctx.db.get(entry.appointmentId) : null;

        return {
          _id: entry._id,
          patientId: entry.patientId,
          patientName: patient?.name ?? "Desconhecido",
          phone: patient?.phone ?? "",
          avatarUrl: patient?.avatarUrl,
          priority: entry.priority,
          since: new Date(entry.requestedAt).toLocaleTimeString("pt-BR", {
            hour: "2-digit",
            minute: "2-digit",
          }),
          requestedAt: entry.requestedAt,
          status: entry.status,
          notifiedAt: entry.notifiedAt,
          doctorId: entry.doctorId,
          appointmentId: entry.appointmentId,
          appointment: appointment
            ? {
                _id: appointment._id,
                startAt: appointment.startAt,
                endAt: appointment.endAt,
                status: appointment.status,
              }
            : null,
          notes: entry.notes,
          tags:
            entry.priority === "high"
              ? ["Urgente"]
              : entry.priority === "medium"
                ? ["Prioridade"]
                : [],
        };
      }),
    );

    return {
      items: waitlistEntries,
      continueCursor: results.continueCursor,
      isDone: results.isDone,
    };
  },
});

export const getWaitlistCount = query({
  args: {
    clinicId: v.string(),
    status: v.optional(v.union(v.literal("waiting"), v.literal("notified"), v.literal("assigned"))),
  },
  handler: async (ctx, { clinicId, status }) => {
    if (status) {
      // Count entries with specific status
      const entries = await ctx.db
        .query("waitlists")
        .withIndex("by_clinic_status", (q) => q.eq("clinicId", clinicId).eq("status", status))
        .collect();
      return entries.length;
    } else {
      // Return counts grouped by status
      const allEntries = await ctx.db
        .query("waitlists")
        .withIndex("by_clinic_requestedAt", (q) => q.eq("clinicId", clinicId))
        .collect();

      return {
        waiting: allEntries.filter((e) => e.status === "waiting").length,
        notified: allEntries.filter((e) => e.status === "notified").length,
        assigned: allEntries.filter((e) => e.status === "assigned").length,
        total: allEntries.length,
      };
    }
  },
});

// ============== ACTIONS ==============

export const sendWaitlistNotification = action({
  args: {
    waitlistId: v.id("waitlists"),
    message: v.optional(v.string()),
  },
  handler: async (ctx, { waitlistId, message }) => {
    try {
      // Fetch waitlist entry
      const waitlist = await ctx.runQuery(internalAny.waitlists.getWaitlistById, {
        waitlistId,
      });

      if (!waitlist) {
        throw new Error("Entrada de lista de espera não encontrada");
      }

      // Fetch patient details
      const patient = await ctx.runQuery(internalAny.patients.getById, {
        id: waitlist.patientId,
      });

      if (!patient) {
        throw new Error("Paciente não encontrado");
      }

      // Use default message if none provided
      const notificationMessage =
        message ||
        `Olá ${patient.name}! Você é o próximo na fila. Por favor, aguarde na sala de espera.`;

      // Check if patient has a phone number
      if (!patient.phone) {
        throw new Error("Paciente não possui telefone cadastrado");
      }

      // 3. Find existing chat or create new one
      const existingChats = await ctx.runQuery(internalAny.whatsappQueries.listChats, {
        search: patient.phone,
      });
      const patientPhoneFormatted = patient.phone.startsWith("+")
        ? patient.phone.substring(1)
        : patient.phone;

      // Try to find existing chat by phone
      const existingChat = existingChats.find((chat: any) =>
        chat.whatsappChatId.includes(patientPhoneFormatted),
      );

      let chatId;

      if (!existingChat) {
        // Create new chat entry
        chatId = await ctx.runMutation(internalAny.whatsapp.createChatInternal, {
          clinicId: waitlist.clinicId,
          patientId: patient._id,
          whatsappChatId: `55${patientPhoneFormatted}@s.whatsapp.net`,
          title: patient.name,
        });
      } else {
        chatId = existingChat._id;
      }

      // Send message using the sendMessage mutation
      await ctx.runMutation(internalAny.whatsapp.sendMessage, {
        chatId,
        text: notificationMessage,
      });

      return { success: true };
    } catch (error: any) {
      console.error("Failed to send waitlist notification:", error);
      // Log error but don't fail the action
      return { success: false, error: error.message };
    }
  },
});

// ============== INTERNAL QUERIES ==============

export const getWaitlistById = internalQuery({
  args: {
    waitlistId: v.id("waitlists"),
  },
  handler: async (ctx, { waitlistId }) => {
    return await ctx.db.get(waitlistId);
  },
});

// ============== INTERNAL MUTATIONS ==============

export const upsertWaitlistForCheckin = internalMutation({
  args: {
    clinicId: v.string(),
    appointmentId: v.id("appointments"),
    patientId: v.id("patients"),
    doctorId: v.optional(v.id("users")),
  },
  handler: async (ctx, args) => {
    const { clinicId, appointmentId, patientId, doctorId } = args;
    const now = Date.now();

    const existing = await ctx.db
      .query("waitlists")
      .withIndex("by_clinic_appointment", (q) =>
        q.eq("clinicId", clinicId).eq("appointmentId", appointmentId),
      )
      .first();

    if (existing) {
      return existing;
    }

    const waitlistId = await ctx.db.insert("waitlists", {
      clinicId,
      patientId,
      appointmentId,
      doctorId,
      requestedAt: now,
      priority: "medium",
      status: "waiting",
      createdAt: now,
    });

    return await ctx.db.get(waitlistId);
  },
});
