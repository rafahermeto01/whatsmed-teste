import { v } from "convex/values";

import { internalMutation, internalQuery, mutation, query } from "./_generated/server";
import { authComponent } from "./auth";

// Helper to get authenticated user and clinicId
async function getAuth(ctx: any) {
  const authUser = await authComponent.getAuthUser(ctx);
  if (!authUser) {
    throw new Error("Unauthorized");
  }

  const user = await ctx.db
    .query("users")
    .withIndex("by_email", (q: any) => q.eq("email", authUser.email))
    .first();

  if (!user || !user.clinicId) {
    throw new Error("User is not associated with a clinic");
  }

  return { user, clinicId: user.clinicId as string };
}

// Store OAuth state temporarily
export const storeOAuthState = internalMutation({
  args: {
    state: v.string(),
    clinicId: v.string(),
    userId: v.id("users"),
    expiresAt: v.number(),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("oauthStates")
      .withIndex("by_state", (q) => q.eq("state", args.state))
      .first();

    if (existing) {
      await ctx.db.delete(existing._id);
    }

    await ctx.db.insert("oauthStates", {
      state: args.state,
      clinicId: args.clinicId,
      userId: args.userId,
      expiresAt: args.expiresAt,
      createdAt: Date.now(),
    });

    return { stored: true };
  },
});

export const consumeOAuthState = internalMutation({
  args: {
    state: v.string(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    const record = await ctx.db
      .query("oauthStates")
      .withIndex("by_state", (q) => q.eq("state", args.state))
      .first();

    if (!record || record.consumedAt || record.expiresAt < now) {
      throw new Error("Invalid or expired state");
    }

    await ctx.db.patch(record._id, {
      consumedAt: now,
    });

    return {
      clinicId: record.clinicId,
      userId: record.userId,
    };
  },
});

// Store OAuth tokens
export const storeTokens = internalMutation({
  args: {
    clinicId: v.string(),
    userId: v.id("users"),
    accessToken: v.string(),
    refreshToken: v.optional(v.string()),
    expiresAt: v.optional(v.number()),
    scope: v.optional(v.string()),
    tokenType: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { clinicId, userId, accessToken, refreshToken, expiresAt, scope, tokenType } = args;

    // Check if tokens already exist for this clinic/user
    const existing = await ctx.db
      .query("googleOAuthTokens")
      .withIndex("by_clinic_user", (q) => q.eq("clinicId", clinicId).eq("userId", userId))
      .first();

    const now = Date.now();
    const tokenData: any = {
      clinicId,
      userId,
      accessToken,
      refreshToken,
      expiresAt,
      scope,
      tokenType,
      updatedAt: now,
    };

    if (existing) {
      console.log("[Mutation] Updating existing tokens for user", userId);
      await ctx.db.patch(existing._id, tokenData);
      return existing._id;
    } else {
      console.log("[Mutation] Inserting new tokens for user", userId);
      return await ctx.db.insert("googleOAuthTokens", {
        ...tokenData,
        createdAt: now,
      });
    }
  },
});

// Get stored tokens for a clinic (Public status check)
export const getTokens = query({
  args: {},
  handler: async (ctx) => {
    const { user, clinicId } = await getAuth(ctx);

    const tokens = await ctx.db
      .query("googleOAuthTokens")
      .withIndex("by_clinic_user", (q) => q.eq("clinicId", clinicId).eq("userId", user._id))
      .first();

    if (!tokens) {
      return null;
    }

    // Return connection status (don't expose tokens to client)
    return {
      connected: true,
      expiresAt: tokens.expiresAt,
      scope: tokens.scope,
      lastSyncAt: tokens.lastSyncAt,
    };
  },
});

export const getDoctorConnectionStatus = query({
  args: {
    doctorId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    const doctor = await ctx.db.get(args.doctorId);
    if (!doctor || doctor.clinicId !== clinicId || doctor.role !== "doctor" || doctor.deletedAt) {
      throw new Error("Doctor not found");
    }

    const tokens = await ctx.db
      .query("googleOAuthTokens")
      .withIndex("by_clinic_user", (q) => q.eq("clinicId", clinicId).eq("userId", args.doctorId))
      .first();

    return {
      connected: !!tokens,
      expiresAt: tokens?.expiresAt,
      lastSyncAt: tokens?.lastSyncAt,
    };
  },
});

// Get settings for frontend
export const getSettings = query({
  args: {},
  handler: async (ctx) => {
    const { user, clinicId } = await getAuth(ctx);

    const tokens = await ctx.db
      .query("googleOAuthTokens")
      .withIndex("by_clinic_user", (q) => q.eq("clinicId", clinicId).eq("userId", user._id))
      .first();

    if (!tokens) {
      return null;
    }

    return {
      primaryCalendarId: tokens.primaryCalendarId,
      blockedCalendarIds: tokens.blockedCalendarIds || [],
    };
  },
});

// Save settings
export const saveSettings = mutation({
  args: {
    primaryCalendarId: v.optional(v.string()),
    blockedCalendarIds: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const { user, clinicId } = await getAuth(ctx);

    const tokens = await ctx.db
      .query("googleOAuthTokens")
      .withIndex("by_clinic_user", (q) => q.eq("clinicId", clinicId).eq("userId", user._id))
      .first();

    if (!tokens) {
      throw new Error("Not connected to Google Calendar");
    }

    await ctx.db.patch(tokens._id, {
      primaryCalendarId: args.primaryCalendarId,
      blockedCalendarIds: args.blockedCalendarIds,
      updatedAt: Date.now(),
    });

    return { success: true };
  },
});

// Internal: Get tokens including blocked list
export const getTokensInternal = internalQuery({
  args: {
    clinicId: v.string(),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("googleOAuthTokens")
      .withIndex("by_clinic_user", (q) => q.eq("clinicId", args.clinicId).eq("userId", args.userId))
      .first();
  },
});

// Get access token for API calls (internal)
export const getAccessToken = internalQuery({
  args: {
    clinicId: v.string(),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const tokens = await ctx.db
      .query("googleOAuthTokens")
      .withIndex("by_clinic_user", (q) => q.eq("clinicId", args.clinicId).eq("userId", args.userId))
      .first();

    if (!tokens) {
      return null;
    }

    // Check if token is expired
    if (tokens.expiresAt && tokens.expiresAt < Date.now()) {
      // Token expired, need to refresh
      return { expired: true, refreshToken: tokens.refreshToken };
    }

    return { accessToken: tokens.accessToken, tokenType: tokens.tokenType || "Bearer" };
  },
});

// Internal: Update external events from sync
export const updateExternalEvents = internalMutation({
  args: {
    clinicId: v.string(),
    userId: v.id("users"),
    calendarId: v.string(),
    events: v.array(
      v.object({
        externalId: v.string(),
        title: v.string(),
        startTime: v.number(),
        endTime: v.number(),
        isAllDay: v.boolean(),
        transparent: v.boolean(),
      }),
    ),
  },
  handler: async (ctx, args) => {
    const { clinicId, userId, calendarId, events } = args;

    // 1. Get existing events for this calendar/user to find what needs updating/deleting
    // Note: For efficiency in a real production system, you'd use a more targeted sync
    // For now, we'll wipe and replace for this calendar in the time range, or use upsert

    // Efficient upsert strategy:
    for (const event of events) {
      const existing = await ctx.db
        .query("externalEvents")
        .withIndex("by_user_externalId", (q) =>
          q.eq("userId", userId).eq("externalId", event.externalId),
        )
        .first();

      if (existing) {
        await ctx.db.patch(existing._id, {
          title: event.title,
          startTime: event.startTime,
          endTime: event.endTime,
          isAllDay: event.isAllDay,
          transparent: event.transparent,
          updatedAt: Date.now(),
        });
      } else {
        await ctx.db.insert("externalEvents", {
          clinicId,
          userId,
          calendarId,
          externalId: event.externalId,
          title: event.title,
          startTime: event.startTime,
          endTime: event.endTime,
          isAllDay: event.isAllDay,
          transparent: event.transparent,
          createdAt: Date.now(),
        });
      }
    }
  },
});

// Internal: Update sync status
export const updateSyncStatus = internalMutation({
  args: {
    clinicId: v.string(),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const tokens = await ctx.db
      .query("googleOAuthTokens")
      .withIndex("by_clinic_user", (q) => q.eq("clinicId", args.clinicId).eq("userId", args.userId))
      .first();

    if (tokens) {
      await ctx.db.patch(tokens._id, {
        lastSyncAt: Date.now(),
      });
    }
  },
});

// Internal: Get all users with connected calendars for background sync
export const getAllConnectedUsers = internalQuery({
  args: {},
  handler: async (ctx) => {
    // In a real app, you might want to paginate this or filter by lastSyncAt
    const tokens = await ctx.db.query("googleOAuthTokens").collect();

    // Filter only those who have blocked calendars configured
    return tokens
      .filter((t) => t.blockedCalendarIds && t.blockedCalendarIds.length > 0)
      .map((t) => ({
        userId: t.userId,
        clinicId: t.clinicId,
      }));
  },
});

// Disconnect Google Calendar
export const disconnect = mutation({
  args: {},
  handler: async (ctx) => {
    const { user, clinicId } = await getAuth(ctx);

    const tokens = await ctx.db
      .query("googleOAuthTokens")
      .withIndex("by_clinic_user", (q) => q.eq("clinicId", clinicId).eq("userId", user._id))
      .first();

    if (tokens) {
      await ctx.db.delete(tokens._id);

      // Also cleanup external events
      const events = await ctx.db
        .query("externalEvents")
        .withIndex("by_user_time", (q) => q.eq("userId", user._id))
        .collect();

      for (const event of events) {
        await ctx.db.delete(event._id);
      }
    }

    return { success: true };
  },
});
