import { v } from "convex/values";

/**
 * Helper functions for automation
 * Message templating, context building, etc.
 */

/**
 * Personalize message with template variables
 * Replaces {{variable}} placeholders with actual values
 *
 * @param template - Message template with {{variable}} placeholders
 * @param context - Object with variable values
 * @returns Personalized message
 */
export function personalizeMessage(
  template: string,
  context: {
    patientName?: string;
    appointmentDate?: string;
    appointmentTime?: string;
    clinicName?: string;
    doctorName?: string;
  },
): string {
  let message = template;

  // Replace template variables (case-insensitive)
  const replacements: Record<string, string> = {};

  if (context.patientName) {
    replacements["{{patient_name}}"] = context.patientName;
  }

  if (context.appointmentDate) {
    replacements["{{appointment_date}}"] = context.appointmentDate;
  }

  if (context.appointmentTime) {
    replacements["{{appointment_time}}"] = context.appointmentTime;
  }

  if (context.clinicName) {
    replacements["{{clinic_name}}"] = context.clinicName;
  }

  if (context.doctorName) {
    replacements["{{doctor_name}}"] = context.doctorName;
  }

  // Apply all replacements
  for (const [placeholder, value] of Object.entries(replacements)) {
    const regex = new RegExp(placeholder.replace(/[{}]/g, ""), "gi");
    message = message.replace(regex, value);
  }

  return message;
}

/**
 * Format date for Portuguese locale
 * @param date - Date object or timestamp
 * @returns Formatted date string (e.g., "2 de Janeiro de 2024")
 */
export function formatDate(date: Date | number): string {
  const d = typeof date === "number" ? new Date(date) : date;
  return d.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
}

/**
 * Format time for Portuguese locale
 * @param date - Date object or timestamp
 * @returns Formatted time string (e.g., "14:30")
 */
export function formatTime(date: Date | number): string {
  const d = typeof date === "number" ? new Date(date) : date;
  return d.toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

/**
 * Format date and time together
 * @param date - Date object or timestamp
 * @returns Formatted date and time (e.g., "2 de Janeiro de 2024 às 14:30")
 */
export function formatDateTime(date: Date | number): string {
  return `${formatDate(date)} às ${formatTime(date)}`;
}

/**
 * Calculate delay in milliseconds from hours
 * @param hours - Hours to convert
 * @returns Milliseconds
 */
export function hoursToMs(hours: number): number {
  return hours * 60 * 60 * 1000;
}

/**
 * Convert delay in minutes to milliseconds
 * @param minutes - Minutes to convert
 * @returns Milliseconds
 */
export function minutesToMs(minutes: number): number {
  return minutes * 60 * 1000;
}

/**
 * Check if message contains escalation keywords
 * @param message - Message text to check
 * @param keywords - Array of keywords to match
 * @returns true if any keyword found
 */
export function detectEscalation(message: string, keywords: string[]): boolean {
  if (!keywords || keywords.length === 0) {
    return false;
  }

  const lowerMessage = message.toLowerCase();
  return keywords.some((keyword) => {
    const lowerKeyword = keyword.toLowerCase();
    // Match whole word or phrase (case-insensitive)
    return lowerMessage.includes(lowerKeyword);
  });
}

/**
 * Validate tone value
 * @param tone - Tone to validate
 * @returns true if valid
 */
export function isValidTone(tone: string): boolean {
  const validTones = ["empathetic", "formal", "casual", "direct"];
  return validTones.includes(tone);
}

/**
 * Validate channel value
 * @param channel - Channel to validate
 * @returns true if valid
 */
export function isValidChannel(channel: string): boolean {
  const validChannels = ["whatsapp", "sms", "email", "call"];
  return validChannels.includes(channel);
}

/**
 * Validate reminder type
 * @param type - Reminder type to validate
 * @returns true if valid
 */
export function isValidReminderType(type: string): boolean {
  const validTypes = [
    "appointmentConfirmation",
    "sevenDay",
    "twentyFourHour",
    "oneHour",
    "postConsultation",
    "noShowRecovery",
    "rescheduleOptions",
    "rescheduleConfirmation",
    "confirmationReply",
    "cancellationConfirmation",
    "googleReviewFollowUp",
    "detractorAlert",
  ];
  return validTypes.includes(type);
}

/**
 * Validate campaign trigger type
 * @param type - Trigger type to validate
 * @returns true if valid
 */
export function isValidCampaignTriggerType(type: string): boolean {
  const validTypes = [
    "time_after_appointment",
    "time_after_procedure",
    "birthday",
    "no_show",
    "custom",
  ];
  return validTypes.includes(type);
}

/**
 * Validate time format (HH:MM)
 * @param time - Time string to validate
 * @returns true if valid
 */
export function isValidTimeFormat(time: string): boolean {
  const timeRegex = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/;
  return timeRegex.test(time);
}

/**
 * Build context object for message personalization
 * @param data - Data from database
 * @returns Context object for templates
 */
export function buildTemplateContext(data: {
  patient?: any;
  appointment?: any;
  clinic?: any;
  doctor?: any;
}): {
  patientName?: string;
  appointmentDate?: string;
  appointmentTime?: string;
  clinicName?: string;
  doctorName?: string;
} {
  const context: any = {};

  if (data.patient) {
    context.patientName = data.patient.name;
  }

  if (data.appointment) {
    context.appointmentDate = formatDate(data.appointment.startAt);
    context.appointmentTime = formatTime(data.appointment.startAt);
  }

  if (data.clinic) {
    context.clinicName = data.clinic.name;
  }

  if (data.doctor || data.appointment?.doctor) {
    context.doctorName = data.doctor || data.appointment.doctor;
  }

  return context;
}

/**
 * Truncate message to maximum length
 * @param message - Message to truncate
 * @param maxLength - Maximum length
 * @returns Truncated message with ellipsis if needed
 */
export function truncateMessage(message: string, maxLength: number): string {
  if (message.length <= maxLength) {
    return message;
  }
  return message.substring(0, maxLength - 3) + "...";
}

/**
 * Sanitize message for WhatsApp (remove invalid characters)
 * @param message - Message to sanitize
 * @returns Sanitized message
 */
export function sanitizeWhatsAppMessage(message: string): string {
  // Remove WhatsApp-specific formatting issues
  return (
    message
      .replace(/\u{202E}/gu, "") // Remove combining characters
      .replace(/\u{200B}+\u{200C}/gu, "") // Remove zero-width joiners
      // eslint-disable-next-line no-control-regex
      .replace(/[\u{0000}-\u{001F}\u{007F}-\u{009F}]/gu, "") // Remove control characters
      .trim()
  );
}

/**
 * Generate unique thread ID for conversation
 * @param clinicId - Clinic ID
 * @param patientId - Patient ID
 * @returns Thread ID
 */
export function generateThreadId(clinicId: string, patientId: string): string {
  return `${clinicId}-${patientId}-${Date.now()}`;
}

/**
 * Check if within business hours
 * @param date - Date to check
 * @param startStr - Start time HH:MM
 * @param endStr - End time HH:MM
 * @returns true if within hours
 */
export function isWithinBusinessHours(date: Date, startStr: string, endStr: string): boolean {
  const [startHour, startMin] = startStr.split(":").map(Number);
  const [endHour, endMin] = endStr.split(":").map(Number);

  const currentMinutes = date.getHours() * 60 + date.getMinutes();
  const startMinutes = startHour * 60 + startMin;
  const endMinutes = endHour * 60 + endMin;

  // Handle overnight schedule (e.g., 22:00 - 06:00)
  if (endMinutes < startMinutes) {
    return currentMinutes >= startMinutes || currentMinutes < endMinutes;
  }

  return currentMinutes >= startMinutes && currentMinutes < endMinutes;
}

/**
 * Add emojis to message (tasteful usage)
 * @param message - Message to enhance
 * @param count - Number of emojis to add (default: 1)
 * @returns Message with emojis
 */
export function addEmojis(
  message: string,
  type: "greeting" | "reminder" | "confirmation" | "alert" = "reminder",
): string {
  const emojis: Record<string, string[]> = {
    greeting: ["👋", "😊", "👋🏻"],
    reminder: ["⏰", "📅", "🔔", "💭"],
    confirmation: ["✅", "👍", "✨"],
    alert: ["⚠️", "🔔", "📢"],
  };

  const typeEmojis = emojis[type] || [];
  const selectedEmoji = typeEmojis[Math.floor(Math.random() * typeEmojis.length)];

  return message + (selectedEmoji ? ` ${selectedEmoji}` : "");
}
