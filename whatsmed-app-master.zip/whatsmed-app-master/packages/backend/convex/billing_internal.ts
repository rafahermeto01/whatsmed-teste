import { v } from "convex/values";

import { internalMutation, internalQuery } from "./_generated/server";

// Internal queries for actions

export const getWalletInternal = internalQuery({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("wallets")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .unique();
  },
});

export const getClinicInternal = internalQuery({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .unique();
  },
});

export const getPaymentMethodInternal = internalQuery({
  args: { id: v.id("paymentMethods"), clinicId: v.string() },
  handler: async (ctx, args) => {
    const card = await ctx.db.get(args.id);
    if (!card || card.clinicId !== args.clinicId) return null;
    return card;
  },
});

export const getSubscriptionInternal = internalQuery({
  args: { id: v.id("subscriptions"), clinicId: v.string() },
  handler: async (ctx, args) => {
    const sub = await ctx.db.get(args.id);
    if (!sub || sub.clinicId !== args.clinicId) return null;
    return sub;
  },
});

export const listPaymentMethodsInternal = internalQuery({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("paymentMethods")
      .withIndex("by_clinic_createdAt", (q) => q.eq("clinicId", args.clinicId))
      .collect();
  },
});

// Internal mutations for database operations

export const createWalletInternal = internalMutation({
  args: {
    clinicId: v.string(),
    asaasCustomerId: v.string(),
  },
  handler: async (ctx, args) => {
    const walletId = await ctx.db.insert("wallets", {
      clinicId: args.clinicId,
      balance: 0,
      currency: "BRL",
      autoRechargeEnabled: false,
      asaasCustomerId: args.asaasCustomerId,
      createdAt: Date.now(),
    });
    return await ctx.db.get(walletId);
  },
});

export const updateWalletAsaasId = internalMutation({
  args: {
    walletId: v.id("wallets"),
    asaasCustomerId: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.walletId, {
      asaasCustomerId: args.asaasCustomerId,
      updatedAt: Date.now(),
    });
    return await ctx.db.get(args.walletId);
  },
});

export const insertPaymentMethod = internalMutation({
  args: {
    clinicId: v.string(),
    walletId: v.id("wallets"),
    brand: v.string(),
    last4: v.string(),
    expMonth: v.number(),
    expYear: v.number(),
    holder: v.string(),
    fingerprint: v.string(),
    providerPaymentMethodId: v.string(),
    asaasCardToken: v.string(),
    isDefault: v.boolean(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("paymentMethods", {
      clinicId: args.clinicId,
      walletId: args.walletId,
      brand: args.brand,
      last4: args.last4,
      expMonth: args.expMonth,
      expYear: args.expYear,
      holder: args.holder,
      fingerprint: args.fingerprint,
      providerPaymentMethodId: args.providerPaymentMethodId,
      asaasCardToken: args.asaasCardToken,
      isDefault: args.isDefault,
      createdAt: Date.now(),
    });
  },
});

export const insertTransaction = internalMutation({
  args: {
    clinicId: v.string(),
    walletId: v.id("wallets"),
    type: v.union(v.literal("topup"), v.literal("debit"), v.literal("refund")),
    amount: v.number(),
    asaasPaymentId: v.string(),
    status: v.union(v.literal("pending"), v.literal("succeeded"), v.literal("failed")),
    reason: v.optional(v.string()),
    meta: v.optional(v.any()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("transactions", {
      clinicId: args.clinicId,
      walletId: args.walletId,
      type: args.type,
      amount: args.amount,
      currency: "BRL",
      providerRef: args.asaasPaymentId,
      asaasPaymentId: args.asaasPaymentId,
      status: args.status,
      reason: args.reason,
      meta: args.meta,
      createdAt: Date.now(),
    });
  },
});

export const insertSubscription = internalMutation({
  args: {
    clinicId: v.string(),
    asaasSubscriptionId: v.string(),
    asaasCustomerId: v.string(),
    status: v.string(),
    billingType: v.string(),
    value: v.number(),
    nextDueDate: v.string(),
    cycle: v.string(),
    description: v.string(),
    creditCard: v.object({
      brand: v.string(),
      last4: v.string(),
    }),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("subscriptions", {
      clinicId: args.clinicId,
      asaasSubscriptionId: args.asaasSubscriptionId,
      asaasCustomerId: args.asaasCustomerId,
      status: args.status,
      billingType: args.billingType,
      value: args.value,
      nextDueDate: args.nextDueDate,
      cycle: args.cycle,
      description: args.description,
      creditCard: args.creditCard,
      createdAt: Date.now(),
    });
  },
});

export const updateSubscriptionStatus = internalMutation({
  args: {
    subscriptionId: v.id("subscriptions"),
    status: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.subscriptionId, {
      status: args.status,
      updatedAt: Date.now(),
    });
  },
});

export const updateClinicPlan = internalMutation({
  args: {
    clinicId: v.string(),
    plan: v.union(
      v.literal("free"),
      v.literal("starter"),
      v.literal("professional"),
      v.literal("enterprise"),
    ),
    planStatus: v.union(
      v.literal("active"),
      v.literal("past_due"),
      v.literal("canceled"),
      v.literal("trialing"),
    ),
    asaasSubscriptionId: v.optional(v.string()),
    planValue: v.optional(v.number()),
    planNextDueDate: v.optional(v.string()),
    planCycle: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .unique();

    if (clinic) {
      await ctx.db.patch(clinic._id, {
        plan: args.plan,
        planStatus: args.planStatus,
        asaasSubscriptionId: args.asaasSubscriptionId,
        planValue: args.planValue,
        planNextDueDate: args.planNextDueDate,
        planCycle: args.planCycle,
        updatedAt: Date.now(),
      });
    }
  },
});

export const getDefaultPaymentMethod = internalQuery({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("paymentMethods")
      .withIndex("by_clinic_default", (q) => q.eq("clinicId", args.clinicId).eq("isDefault", true))
      .first();
  },
});

export const getSubscriptionByClinic = internalQuery({
  args: { clinicId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("subscriptions")
      .withIndex("by_clinic", (q) => q.eq("clinicId", args.clinicId))
      .first();
  },
});

export const updateSubscription = internalMutation({
  args: {
    subscriptionId: v.id("subscriptions"),
    status: v.optional(v.string()),
    nextDueDate: v.optional(v.string()),
    value: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const updates: Record<string, unknown> = { updatedAt: Date.now() };
    if (args.status !== undefined) updates.status = args.status;
    if (args.nextDueDate !== undefined) updates.nextDueDate = args.nextDueDate;
    if (args.value !== undefined) updates.value = args.value;

    await ctx.db.patch(args.subscriptionId, updates);
    return await ctx.db.get(args.subscriptionId);
  },
});

export const deleteSubscription = internalMutation({
  args: { subscriptionId: v.id("subscriptions") },
  handler: async (ctx, args) => {
    await ctx.db.delete(args.subscriptionId);
  },
});
