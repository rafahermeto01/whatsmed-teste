import { createClient, type GenericCtx, type AuthFunctions } from "@convex-dev/better-auth";
import { convex } from "@convex-dev/better-auth/plugins";
import { zxcvbn, zxcvbnOptions } from "@zxcvbn-ts/core";
import * as zxcvbnEn from "@zxcvbn-ts/language-en";
import * as zxcvbnPtBr from "@zxcvbn-ts/language-pt-br";
import { betterAuth } from "better-auth";
import { v } from "convex/values";

// Initialize zxcvbn with English and Portuguese language packages
zxcvbnOptions.setOptions({
  dictionary: {
    ...zxcvbnEn.dictionary,
    ...zxcvbnPtBr.dictionary,
  },
  translations: zxcvbnPtBr.translations,
});

import { components, internal } from "./_generated/api";
import { type DataModel } from "./_generated/dataModel";
import { query } from "./_generated/server";

// Default clinic ID for auto-provisioning new users
const DEFAULT_CLINIC_ID = process.env.DEFAULT_CLINIC_ID || "clinic-demo";

// Auth functions required for triggers
// @ts-expect-error - Type instantiation is excessively deep due to Convex's internal types
const authFunctions = (internal as any).auth;

// @ts-expect-error - Type inference issue with createClient due to circular dependency
export const authComponent = createClient<DataModel>(components.betterAuth, {
  authFunctions,
  triggers: {
    user: {
      // When a user signs up via better-auth, create them in our users table
      onCreate: async (ctx, authUser) => {
        console.warn(`[Auth Trigger] Creating app user for ${authUser.email}`);

        // Check if user already exists in app's users table
        const existing = await ctx.db
          .query("users")
          .withIndex("by_email", (q) => q.eq("email", authUser.email))
          .first();

        if (existing) {
          console.warn(`[Auth Trigger] User ${authUser.email} already exists in users table`);
          return;
        }

        const now = Date.now();
        await ctx.db.insert("users", {
          authUserId: authUser._id,
          clinicId: DEFAULT_CLINIC_ID,
          email: authUser.email,
          name: authUser.name || authUser.email.split("@")[0],
          role: "viewer", // Default role is viewer for security
          phone: undefined,
          isActive: true,
          lastLoginAt: now,
          createdAt: now,
          deletedAt: undefined,
        });

        console.warn(
          `[Auth Trigger] Created app user for ${authUser.email} in clinic ${DEFAULT_CLINIC_ID}`,
        );
      },
    },
  },
});

// Export trigger functions for Convex to wire up
export const { onCreate, onUpdate, onDelete } = authComponent.triggersApi();

const REFRESH_TTL_SECONDS = 60 * 60 * 24 * 30; // 30d
const SITE_URL_FALLBACK = "http://localhost:3001";

function normalizeSiteUrl(input: string) {
  const trimmed = input.trim();
  const [firstOrigin] = trimmed
    .split(",")
    .map((value) => value.trim())
    .filter(Boolean);

  if (!firstOrigin) {
    return SITE_URL_FALLBACK;
  }

  const parsed = new URL(firstOrigin);
  const isLocalhost =
    parsed.hostname === "localhost" ||
    parsed.hostname === "127.0.0.1" ||
    parsed.hostname === "[::1]";

  if (!isLocalhost && parsed.protocol === "http:") {
    parsed.protocol = "https:";
  }

  return parsed.origin;
}

function getTrustedSiteOrigins() {
  const configuredSiteUrls = process.env.SITE_URL?.trim() || process.env.VITE_SITE_URL?.trim();

  if (!configuredSiteUrls) {
    return [SITE_URL_FALLBACK];
  }

  return configuredSiteUrls
    .split(",")
    .map((value) => value.trim())
    .filter(Boolean)
    .map(normalizeSiteUrl);
}

export function getSiteUrl() {
  const configuredSiteUrl = process.env.SITE_URL?.trim() || process.env.VITE_SITE_URL?.trim();

  if (!configuredSiteUrl) {
    console.warn(
      `SITE_URL is not set; falling back to ${SITE_URL_FALLBACK}. Set SITE_URL in Convex env for correct auth URLs.`,
    );
    return SITE_URL_FALLBACK;
  }

  return normalizeSiteUrl(configuredSiteUrl);
}

function createAuth(
  ctx: GenericCtx<DataModel>,
  { optionsOnly }: { optionsOnly?: boolean } = { optionsOnly: false },
) {
  const siteUrl = getSiteUrl();
  const trustedSiteOrigins = getTrustedSiteOrigins();
  return betterAuth({
    logger: {
      disabled: optionsOnly,
    },
    baseURL: siteUrl,
    trustedOrigins: [
      ...trustedSiteOrigins,
      "http://localhost:3001",
      "http://localhost:5173",
      "https://app.whatsmed.tech",
    ],
    database: authComponent.adapter(ctx),
    emailAndPassword: {
      enabled: true,
      requireEmailVerification: false,
      sendResetPassword: async ({ user, url, token: _token }, _request) => {
        // Use separate action to send email to avoid bundling Node.js modules in auth.ts
        if ("runAction" in ctx) {
          await (ctx as any).runAction(internal.emailActions.sendPasswordResetEmail, {
            email: user.email,
            resetUrl: url,
          });
        } else {
          console.error("Cannot send reset email: context does not support runAction");
        }
      },
    },
    session: {
      expiresIn: REFRESH_TTL_SECONDS,
    },
    user: {
      additionalFields: {
        clinicId: { type: "string", required: false, input: false },
        role: { type: "string", required: false, input: false },
        phone: { type: "string", required: false, input: false },
        isActive: { type: "boolean", required: false, input: false },
        lastLoginAt: { type: "number", required: false, input: false },
      },
    },
    plugins: [convex()],
  });
}

export { createAuth };

export const getCurrentUser = query({
  args: {},
  returns: v.any(),
  handler: async function (ctx) {
    try {
      return await authComponent.getAuthUser(ctx);
    } catch {
      // Return null if user is not authenticated instead of throwing
      return null;
    }
  },
});

export const getCurrentUserWithClinic = query({
  args: {},
  returns: v.union(
    v.null(),
    v.object({ clinicId: v.string(), email: v.string(), name: v.string() }),
  ),
  handler: async function (ctx) {
    try {
      const authUser = await authComponent.getAuthUser(ctx);
      if (!authUser) {
        return null;
      }

      // Get full user record from users table
      const user = await ctx.db
        .query("users")
        .withIndex("by_email", (q) => q.eq("email", authUser.email))
        .first();

      // Fallback to authUser clinicId if app user missing
      // This ensures we always return a valid clinicId if the user is authenticated
      const clinicId = user?.clinicId || (authUser as any).clinicId;

      if (!clinicId) {
        return null;
      }

      return {
        clinicId,
        email: authUser.email,
        name: user?.name || authUser.name || authUser.email.split("@")[0],
      };
    } catch {
      // Return null if user is not authenticated instead of throwing
      return null;
    }
  },
});

export interface PasswordStrength {
  score: number;
  warning: string | null;
  suggestions: string[];
  isValid: boolean;
}

/**
 * Validates password strength using zxcvbn
 * @param password - Password to validate
 * @returns PasswordStrength object with score (0-4), warnings, and suggestions
 */
export function validatePasswordPolicy(password: string): PasswordStrength {
  if (!password) {
    return {
      score: 0,
      warning: "Senha é obrigatória",
      suggestions: ["Por favor, insira uma senha"],
      isValid: false,
    };
  }

  // Minimum length check (8 characters)
  if (password.length < 8) {
    return {
      score: 0,
      warning: "Senha muito curta",
      suggestions: ["Use pelo menos 8 caracteres"],
      isValid: false,
    };
  }

  // Use zxcvbn for strength analysis
  const result = zxcvbn(password);

  // Minimum score requirement: 2 (out of 4)
  // Score 0: Weak, 1: Weak, 2: Fair, 3: Strong, 4: Very Strong
  const isValid = result.score >= 2;

  return {
    score: result.score,
    warning: result.feedback.warning || null,
    suggestions: result.feedback.suggestions || [],
    isValid,
  };
}

/**
 * Returns password strength label in Portuguese
 * @param score - Password score (0-4)
 * @returns Label string
 */
export function getPasswordStrengthLabel(score: number): string {
  const labels = ["Muito Fraca", "Fraca", "Razoável", "Forte", "Muito Forte"];
  // Clamp score to valid range (0-4)
  const clampedScore = Math.max(0, Math.min(score, 4));
  return labels[clampedScore];
}

/**
 * Checks if password meets minimum requirements for signup
 * @param password - Password to check
 * @returns true if meets minimum requirements, false otherwise
 */
export function isPasswordAcceptable(password: string): boolean {
  const result = validatePasswordPolicy(password);
  return result.isValid;
}

export async function getAuthUserId(ctx: any) {
  const user = await authComponent.getAuthUser(ctx);
  return user?._id ?? null;
}
