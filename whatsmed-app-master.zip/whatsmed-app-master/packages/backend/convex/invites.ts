import { v } from "convex/values";

import { mutation } from "./_generated/server";
import { notFound, unauthorized } from "./lib/errors";

const DEFAULT_CLINIC_ID = process.env.DEFAULT_CLINIC_ID || "clinic-demo";

export const getByToken = mutation({
  args: { token: v.string() },
  handler: async (ctx, { token }) => {
    const invite = await ctx.db
      .query("invites")
      .withIndex("by_token", (q) => q.eq("token", token))
      .first();

    if (!invite) {
      throw notFound("Convite inválido ou já utilizado");
    }
    if (invite.expiresAt < Date.now()) {
      throw notFound("Convite expirado");
    }
    if (invite.status !== "pending") {
      throw notFound("Convite inválido ou já utilizado");
    }

    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", invite.clinicId))
      .first();

    return {
      email: invite.email,
      clinicName: clinic?.name || "Clínica",
      role: invite.role,
    };
  },
});

export const accept = mutation({
  args: {
    token: v.string(),
  },
  handler: async (ctx, { token }) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw unauthorized();

    const authUserId = identity.subject;

    const invite = await ctx.db
      .query("invites")
      .withIndex("by_token", (q) => q.eq("token", token))
      .first();

    if (!invite || invite.status !== "pending" || invite.expiresAt < Date.now()) {
      throw notFound("Invalid or expired invite");
    }

    if (identity.email && identity.email !== invite.email) {
      throw unauthorized("Invite email does not match authenticated user");
    }

    // Update Invite Status
    await ctx.db.patch(invite._id, {
      status: "accepted",
      acceptedAt: Date.now(),
    });

    // 1. Add to userClinics
    const userClinics = await ctx.db
      .query("userClinics")
      .withIndex("by_user", (q) => q.eq("userId", authUserId))
      .first();

    const newClinicEntry = {
      clinicId: invite.clinicId,
      role: invite.role,
    };

    if (userClinics) {
      // Avoid duplicates
      const exists = userClinics.clinics.some((c) => c.clinicId === invite.clinicId);
      if (!exists) {
        await ctx.db.patch(userClinics._id, {
          clinics: [...userClinics.clinics, newClinicEntry],
          updatedAt: Date.now(),
        });
      }
    } else {
      await ctx.db.insert("userClinics", {
        userId: authUserId,
        clinics: [newClinicEntry],
        createdAt: Date.now(),
      });
    }

    // 2. Add to clinicMembers (Normalized for performance)
    const existingMember = await ctx.db
      .query("clinicMembers")
      .withIndex("by_user_clinic", (q) =>
        q.eq("userId", authUserId).eq("clinicId", invite.clinicId),
      )
      .first();

    if (!existingMember) {
      await ctx.db.insert("clinicMembers", {
        userId: authUserId,
        clinicId: invite.clinicId,
        role: invite.role,
        createdAt: Date.now(),
      });
    }

    // 3. Update users table: set clinicId to invite's clinic (if currently demo clinic) and sync role
    const userProfile = await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", invite.email))
      .first();

    if (userProfile) {
      const isDemoClinic = userProfile.clinicId === DEFAULT_CLINIC_ID;
      const isSameClinic = userProfile.clinicId === invite.clinicId;

      if (isDemoClinic) {
        // User was created with demo clinic, update to the invite's clinic and role
        await ctx.db.patch(userProfile._id, {
          clinicId: invite.clinicId,
          role: invite.role as "admin" | "staff" | "viewer" | "doctor" | "super_admin",
        });
      } else if (isSameClinic) {
        // User already in this clinic, just update role to match invite
        await ctx.db.patch(userProfile._id, {
          role: invite.role as "admin" | "staff" | "viewer" | "doctor" | "super_admin",
        });
      }
      // If user is in a different clinic, don't change their active clinic context
    }

    return { clinicId: invite.clinicId };
  },
});
