import { v } from "convex/values";

import { internal } from "./_generated/api";
import { internalQuery, internalMutation } from "./_generated/server";
import { buildDefaultReminderConfigs } from "./automationDefaults";

const internalAny = internal as any;

const reminderTypeValidator = v.union(
  v.literal("appointmentConfirmation"),
  v.literal("sevenDay"),
  v.literal("twentyFourHour"),
  v.literal("oneHour"),
  v.literal("postConsultation"),
  v.literal("noShowRecovery"),
);

const reminderConfigTypeValidator = v.union(
  v.literal("appointmentConfirmation"),
  v.literal("sevenDay"),
  v.literal("twentyFourHour"),
  v.literal("oneHour"),
  v.literal("postConsultation"),
  v.literal("noShowRecovery"),
  v.literal("rescheduleOptions"),
  v.literal("rescheduleConfirmation"),
  v.literal("confirmationReply"),
  v.literal("cancellationConfirmation"),
  v.literal("googleReviewFollowUp"),
  v.literal("detractorAlert"),
);

const scheduledJobKindValidator = v.union(
  v.literal("appointmentConfirmation"),
  v.literal("sevenDay"),
  v.literal("twentyFourHour"),
  v.literal("oneHour"),
  v.literal("rescheduleTimeout"),
);

// ============================================
// INTERNAL QUERIES (for actions)
// ============================================

/**
 * Get reminder configs for a clinic (internal)
 */
export const getReminderConfigsByClinic = internalQuery({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const configs = await ctx.db
      .query("reminderConfigs")
      .withIndex("by_clinic_type", (q: any) => q.eq("clinicId", args.clinicId))
      .collect();

    return configs;
  },
});

export const getReminderConfigByClinicAndType = internalQuery({
  args: {
    clinicId: v.string(),
    type: reminderConfigTypeValidator,
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("reminderConfigs")
      .withIndex("by_clinic_type", (q: any) =>
        q.eq("clinicId", args.clinicId).eq("type", args.type),
      )
      .unique();
  },
});

export const ensureReminderConfigsForClinic = internalMutation({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const existingConfigs = await ctx.db
      .query("reminderConfigs")
      .withIndex("by_clinic_type", (q: any) => q.eq("clinicId", args.clinicId))
      .collect();

    const existingTypes = new Set(existingConfigs.map((config) => config.type));
    const now = Date.now();
    const defaultConfigs = buildDefaultReminderConfigs(args.clinicId, now);
    let inserted = 0;

    for (const config of defaultConfigs) {
      if (existingTypes.has(config.type)) {
        continue;
      }

      await ctx.db.insert("reminderConfigs", config);
      inserted += 1;
    }

    return { inserted };
  },
});

// ============================================
// INTERNAL MUTATIONS
// ============================================

/**
 * Mark appointment reminder as sent
 */
export const markReminderSent = internalMutation({
  args: {
    id: v.id("appointments"),
    reminderAt: v.number(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.id, {
      reminderAt: args.reminderAt,
    });
  },
});

export const getAppointmentReminderState = internalQuery({
  args: {
    appointmentId: v.id("appointments"),
    reminderType: reminderTypeValidator,
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("appointmentReminders")
      .withIndex("by_appointment_type", (q) =>
        q.eq("appointmentId", args.appointmentId).eq("reminderType", args.reminderType),
      )
      .first();
  },
});

export const upsertAppointmentReminderState = internalMutation({
  args: {
    clinicId: v.string(),
    appointmentId: v.id("appointments"),
    reminderType: reminderTypeValidator,
    status: v.union(v.literal("sent"), v.literal("failed")),
    responseStatus: v.optional(
      v.union(
        v.literal("awaiting"),
        v.literal("confirmed"),
        v.literal("declined"),
        v.literal("reschedule_requested"),
        v.literal("cancelled"),
      ),
    ),
    responseMessageId: v.optional(v.id("messages")),
    respondedAt: v.optional(v.number()),
    channels: v.array(
      v.union(v.literal("whatsapp"), v.literal("sms"), v.literal("email"), v.literal("call")),
    ),
    sentAt: v.optional(v.number()),
    lastError: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    const existing = await ctx.db
      .query("appointmentReminders")
      .withIndex("by_appointment_type", (q) =>
        q.eq("appointmentId", args.appointmentId).eq("reminderType", args.reminderType),
      )
      .first();

    if (existing) {
      await ctx.db.patch(existing._id, {
        status: args.status,
        responseStatus: args.responseStatus,
        responseMessageId: args.responseMessageId,
        respondedAt: args.respondedAt,
        channels: args.channels,
        sentAt: args.sentAt,
        lastError: args.lastError,
        updatedAt: now,
      });
      return existing._id;
    }

    return await ctx.db.insert("appointmentReminders", {
      clinicId: args.clinicId,
      appointmentId: args.appointmentId,
      reminderType: args.reminderType,
      status: args.status,
      responseStatus: args.responseStatus,
      responseMessageId: args.responseMessageId,
      respondedAt: args.respondedAt,
      channels: args.channels,
      sentAt: args.sentAt,
      lastError: args.lastError,
      createdAt: now,
      updatedAt: now,
    });
  },
});

export const resetScheduledReminderStates = internalMutation({
  args: {
    appointmentId: v.id("appointments"),
  },
  handler: async (ctx, args) => {
    const reminderTypes = ["sevenDay", "twentyFourHour", "oneHour"] as const;

    for (const reminderType of reminderTypes) {
      const existing = await ctx.db
        .query("appointmentReminders")
        .withIndex("by_appointment_type", (q) =>
          q.eq("appointmentId", args.appointmentId).eq("reminderType", reminderType),
        )
        .first();

      if (existing) {
        await ctx.db.delete(existing._id);
      }
    }
  },
});

export const listAppointmentScheduledJobs = internalQuery({
  args: {
    appointmentId: v.id("appointments"),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("appointmentScheduledJobs")
      .withIndex("by_appointment", (q) => q.eq("appointmentId", args.appointmentId))
      .collect();
  },
});

export const clearAppointmentScheduledJobs = internalMutation({
  args: {
    appointmentId: v.id("appointments"),
  },
  handler: async (ctx, args) => {
    const jobs = await ctx.db
      .query("appointmentScheduledJobs")
      .withIndex("by_appointment", (q) => q.eq("appointmentId", args.appointmentId))
      .collect();

    for (const job of jobs) {
      if (job.status === "scheduled") {
        await ctx.scheduler.cancel(job.scheduledFunctionId);
      }

      await ctx.db.patch(job._id, {
        status: job.status === "executed" ? "executed" : "cancelled",
        updatedAt: Date.now(),
      });
    }

    return { cancelled: jobs.length };
  },
});

export const markScheduledJobExecuted = internalMutation({
  args: {
    appointmentId: v.id("appointments"),
    jobKind: scheduledJobKindValidator,
  },
  handler: async (ctx, args) => {
    const jobs = await ctx.db
      .query("appointmentScheduledJobs")
      .withIndex("by_appointment_jobKind", (q) =>
        q.eq("appointmentId", args.appointmentId).eq("jobKind", args.jobKind),
      )
      .collect();

    const now = Date.now();
    for (const job of jobs) {
      if (job.status === "scheduled") {
        await ctx.db.patch(job._id, {
          status: "executed",
          updatedAt: now,
        });
      }
    }
  },
});

export const syncAppointmentScheduledJobs = internalMutation({
  args: {
    appointmentId: v.id("appointments"),
  },
  handler: async (ctx, args) => {
    const appointment = await ctx.db.get(args.appointmentId);
    if (!appointment) {
      return { scheduled: 0, reason: "missing_appointment" };
    }

    console.warn("[syncAppointmentScheduledJobs] Syncing jobs for appointment:", {
      appointmentId: args.appointmentId,
      startAt: appointment.startAt,
      startAtLocal: new Date(appointment.startAt).toLocaleString("pt-BR", {
        timeZone: "America/Sao_Paulo",
      }),
      status: appointment.status,
      isTelemedicine: appointment.isTelemedicine,
      rescheduleStatus: appointment.rescheduleStatus,
    });

    await ctx.runMutation(internalAny.automationInternal.ensureReminderConfigsForClinic, {
      clinicId: appointment.clinicId,
    });

    await ctx.runMutation(internalAny.automationInternal.clearAppointmentScheduledJobs, {
      appointmentId: args.appointmentId,
    });

    const now = Date.now();
    if (
      appointment.deletedAt ||
      appointment.status === "cancelled" ||
      appointment.status === "arrived" ||
      appointment.status === "completed"
    ) {
      return { scheduled: 0, reason: "inactive_appointment" };
    }

    const reminderConfigs = await ctx.db
      .query("reminderConfigs")
      .withIndex("by_clinic_type", (q) => q.eq("clinicId", appointment.clinicId))
      .collect();
    const configByType = new Map(reminderConfigs.map((config) => [config.type, config]));

    const jobsToSchedule: Array<{
      jobKind:
        | "appointmentConfirmation"
        | "sevenDay"
        | "twentyFourHour"
        | "oneHour"
        | "rescheduleTimeout";
      scheduledFor: number;
    }> = [];

    if (appointment.status === "pending" && appointment.rescheduleStatus !== "awaiting_response") {
      const confirmationConfig = configByType.get("appointmentConfirmation");
      if (confirmationConfig?.enabled) {
        jobsToSchedule.push({
          jobKind: "appointmentConfirmation",
          scheduledFor: appointment.isTelemedicine ? now + 30 * 1000 : now,
        });
        console.warn("[syncAppointmentScheduledJobs] Scheduling confirmation job:", {
          appointmentId: args.appointmentId,
          delay: appointment.isTelemedicine ? "30s" : "immediate",
          scheduledFor: new Date(appointment.isTelemedicine ? now + 30 * 1000 : now).toISOString(),
        });
      }
    }

    if (appointment.status === "pending" || appointment.status === "confirmed") {
      const reminderOffsets = {
        sevenDay: 7 * 24 * 60 * 60 * 1000,
        twentyFourHour: 24 * 60 * 60 * 1000,
        oneHour: 60 * 60 * 1000,
      } as const;

      for (const [jobKind, offsetMs] of Object.entries(reminderOffsets) as Array<
        ["sevenDay" | "twentyFourHour" | "oneHour", number]
      >) {
        const config = configByType.get(jobKind);
        if (!config?.enabled) {
          continue;
        }

        const scheduledFor = appointment.startAt - offsetMs;
        if (scheduledFor <= now) {
          continue;
        }

        jobsToSchedule.push({ jobKind, scheduledFor });
      }
    }

    if (appointment.rescheduleStatus === "awaiting_response") {
      jobsToSchedule.push({
        jobKind: "rescheduleTimeout",
        scheduledFor: now + 12 * 60 * 60 * 1000,
      });
    }

    for (const job of jobsToSchedule) {
      const delay = Math.max(0, job.scheduledFor - now);
      console.warn("[syncAppointmentScheduledJobs] Scheduling job:", {
        appointmentId: appointment._id,
        jobKind: job.jobKind,
        delay,
        scheduledFor: new Date(job.scheduledFor).toISOString(),
        scheduledForLocal: new Date(job.scheduledFor).toLocaleString("pt-BR", {
          timeZone: "America/Sao_Paulo",
        }),
      });

      const scheduledFunctionId = await ctx.scheduler.runAfter(
        delay,
        internalAny.automationActions.runScheduledAppointmentJob,
        {
          appointmentId: appointment._id,
          clinicId: appointment.clinicId,
          jobKind: job.jobKind,
        },
      );

      await ctx.db.insert("appointmentScheduledJobs", {
        clinicId: appointment.clinicId,
        appointmentId: appointment._id,
        jobKind: job.jobKind,
        scheduledFor: job.scheduledFor,
        scheduledFunctionId,
        status: "scheduled",
        createdAt: now,
        updatedAt: now,
      });
    }

    console.warn("[syncAppointmentScheduledJobs] Jobs scheduled:", {
      appointmentId: appointment._id,
      totalJobs: jobsToSchedule.length,
      jobs: jobsToSchedule.map((j) => j.jobKind),
    });

    return { scheduled: jobsToSchedule.length };
  },
});

/**
 * Log campaign execution (would need campaignExecutions table)
 * For now, we'll log to console
 */
export const logCampaignStep = internalMutation({
  args: {
    campaignId: v.id("campaigns"),
    appointmentId: v.id("appointments"),
    stepOrder: v.number(),
    channel: v.string(),
    sentAt: v.number(),
  },
  handler: async (ctx, args) => {
    console.warn(`[CampaignExecution] Step ${args.stepOrder} sent for campaign ${args.campaignId}`);
    // In production, insert into campaignExecutions table
    return { logged: true };
  },
});
