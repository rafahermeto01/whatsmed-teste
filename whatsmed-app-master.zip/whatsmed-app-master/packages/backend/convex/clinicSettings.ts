import { v } from "convex/values";

import { mutation, internalQuery, query } from "./_generated/server";
import { checkFlowRole } from "./flows/auth";
import { unauthorized, forbidden, notFound } from "./lib/errors";
import { requireClinicAccess } from "./lib/rbac";

/**
 * Set the default active flow for a clinic
 *
 * This mutation sets the default flow that will be used for all conversations
 * when no specific flow is specified. Only admin users can perform this action.
 *
 * Requirements:
 * - User must be authenticated
 * - User must have admin role in the clinic
 * - Flow must exist and belong to the clinic
 *
 * @param clinicId - Clinic identifier (id from clinics table)
 * @param flowId - Flow identifier (id from flows table) to set as default
 * @returns Updated clinicSettings object
 *
 * Usage: Called by clinic settings UI to set the default flow
 */
export const setDefaultFlow = mutation({
  args: {
    clinicId: v.string(),
    flowId: v.id("flows"),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw unauthorized("Authentication required");
    }

    const authUserId = identity.subject;

    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .first();

    if (!clinic) {
      throw notFound("Clinic not found");
    }

    const hasAdminRole = await checkFlowRole(ctx, clinic.clinicId, authUserId, [
      "admin",
      "super_admin",
    ]);
    if (!hasAdminRole) {
      throw forbidden("Admin role required to set default flow");
    }

    const flow = await ctx.db.get(args.flowId);
    if (!flow) {
      throw notFound("Flow not found");
    }

    if (flow.clinicId !== clinic.clinicId) {
      throw forbidden("Flow does not belong to this clinic");
    }

    const existingSettings = await ctx.db
      .query("clinicSettings")
      .withIndex("by_clinic", (q) => q.eq("clinicId", clinic._id))
      .first();

    let updatedSettings;

    if (existingSettings) {
      await ctx.db.patch(existingSettings._id, {
        defaultFlowId: args.flowId,
      });
      updatedSettings = await ctx.db.get(existingSettings._id);
    } else {
      const settingsId = await ctx.db.insert("clinicSettings", {
        clinicId: clinic._id,
        defaultFlowId: args.flowId,
      });
      updatedSettings = await ctx.db.get(settingsId);
    }

    return updatedSettings;
  },
});

export const updateWhatsAppSettings = mutation({
  args: {
    clinicId: v.string(),
    prependAttendantNameOnManualMessages: v.boolean(),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw unauthorized("Authentication required");
    }

    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .first();

    if (!clinic) {
      throw notFound("Clinic not found");
    }

    const hasAdminRole = await checkFlowRole(ctx, clinic.clinicId, identity.subject, [
      "admin",
      "super_admin",
    ]);
    if (!hasAdminRole) {
      throw forbidden("Admin role required to update WhatsApp settings");
    }

    const existingSettings = await ctx.db
      .query("clinicSettings")
      .withIndex("by_clinic", (q) => q.eq("clinicId", clinic._id))
      .first();

    if (existingSettings) {
      await ctx.db.patch(existingSettings._id, {
        prependAttendantNameOnManualMessages: args.prependAttendantNameOnManualMessages,
      });
      return await ctx.db.get(existingSettings._id);
    }

    const settingsId = await ctx.db.insert("clinicSettings", {
      clinicId: clinic._id,
      prependAttendantNameOnManualMessages: args.prependAttendantNameOnManualMessages,
    });

    return await ctx.db.get(settingsId);
  },
});

/**
 * Get the default active flow for a clinic
 *
 * This internalQuery retrieves the default flow ID for a clinic.
 * It's designed for internal use by the flow execution system.
 *
 * @param clinicId - Clinic identifier (id from clinics table)
 * @returns clinicSettings object with defaultFlowId, or null if not set
 *
 * Usage: Called by flow execution system to find the default flow
 */
export const getDefaultFlow = internalQuery({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .first();

    if (!clinic) {
      return null;
    }

    const settings = await ctx.db
      .query("clinicSettings")
      .withIndex("by_clinic", (q) => q.eq("clinicId", clinic._id))
      .first();

    if (!settings || !settings.defaultFlowId) {
      return null;
    }

    return settings.defaultFlowId;
  },
});

/**
 * Get the full clinic settings for a clinic
 *
 * This query retrieves the complete clinicSettings object for a clinic.
 * It's designed for external use by the web app to get all settings.
 *
 * @param clinicId - Clinic identifier (id from clinics table)
 * @returns clinicSettings object, or null if not found
 *
 * Usage: Called by clinic settings UI to display current configuration
 */
export const getSettings = query({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    await requireClinicAccess(ctx, args.clinicId);

    const clinic = await ctx.db
      .query("clinics")
      .withIndex("by_clinicId", (q) => q.eq("clinicId", args.clinicId))
      .first();

    if (!clinic) {
      return null;
    }

    const settings = await ctx.db
      .query("clinicSettings")
      .withIndex("by_clinic", (q) => q.eq("clinicId", clinic._id))
      .first();

    return settings;
  },
});
