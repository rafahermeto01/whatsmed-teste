import { v } from "convex/values";

import { api, internal } from "./_generated/api";
import {
  internalAction,
  internalMutation,
  internalQuery,
  query,
  mutation,
  action,
} from "./_generated/server";
import { authComponent } from "./auth";
import { notFound, badRequest } from "./lib/errors";
import { checkFeatureAccess } from "./lib/planEnforcement";
import { checkRateLimit, throwIfRateLimited } from "./lib/rateLimit";
import { generateSecureToken } from "./lib/security";
import {
  isValidDateRange,
  isValidAppointmentDuration,
  doRangesOverlap,
  sanitizeString,
  matchesSpecialty,
} from "./lib/validators";
import { buildDefaultReminderConfigs } from "./automationDefaults";

const internalAny = internal as any;
const apiAny = api as any;

// Timezone-aware date helpers for Brazil (America/Sao_Paulo)
// Since working hours are stored as "HH:MM" in local time (Brazil time),
// we need to extract local date components from UTC timestamps and create
// slot boundaries correctly. The key insight: JavaScript Date methods work
// in the runtime's timezone, so we need to manually handle the Brazil timezone offset.

/**
 * Brazil timezone offset (America/Sao_Paulo): UTC-3
 * Note: DST is no longer observed in Brazil as of 2019, so offset is constant UTC-3
 */
const BRAZIL_UTC_OFFSET_MS = -3 * 60 * 60 * 1000; // UTC-3 = -10800000 ms
const DAY_IN_MS = 24 * 60 * 60 * 1000;
const MAX_APPOINTMENT_DURATION_MS = 8 * 60 * 60 * 1000;

async function getConfiguredReminderMessage(ctx: any, clinicId: string, type: any) {
  const configured = await ctx.db
    .query("reminderConfigs")
    .withIndex("by_clinic_type", (q: any) => q.eq("clinicId", clinicId).eq("type", type))
    .unique();

  if (configured) {
    return configured.enabled ? configured.message : null;
  }

  const defaultConfig = buildDefaultReminderConfigs(clinicId, 0).find(
    (config) => config.type === type,
  );
  return defaultConfig?.enabled ? defaultConfig.message : null;
}
const AVAILABILITY_SLOT_STEP_MS = 15 * 60 * 1000;
const MAX_USER_FACING_AVAILABILITY_SLOTS = 25;
const MAX_AVAILABILITY_QUERY_SLOTS = 200;

type AvailabilityPeriod = "morning" | "afternoon" | "night";

function createBrazilUtcTimestamp(
  year: number,
  month: number,
  day: number,
  hour: number,
  minute: number,
): number {
  return Date.UTC(year, month, day, hour + 3, minute, 0, 0);
}

function getBrazilDayStartTimestamp(timestamp: number): number {
  const localTime = getBrazilLocalTime(timestamp);
  return createBrazilUtcTimestamp(localTime.year, localTime.month, localTime.day, 0, 0);
}

function alignToSlotGrid(timestamp: number, slotStart: number, duration: number): number {
  if (timestamp <= slotStart) {
    return slotStart;
  }

  const offset = timestamp - slotStart;
  const remainder = offset % duration;
  return remainder === 0 ? timestamp : timestamp + (duration - remainder);
}

function getAvailabilityPeriodForHour(hour: number): AvailabilityPeriod | null {
  if (hour >= 8 && hour < 12) return "morning";
  if (hour >= 13 && hour < 19) return "afternoon";
  if (hour >= 19 && hour < 22) return "night";
  return null;
}

function slotMatchesRequestedPeriod(slotStartIso: string, period?: AvailabilityPeriod): boolean {
  if (!period) return true;

  const localTime = getBrazilLocalTime(new Date(slotStartIso).getTime());
  return getAvailabilityPeriodForHour(localTime.hour) === period;
}

function normalizeRequestedAvailabilityLimit(maxSlots?: number): number {
  if (!Number.isFinite(maxSlots) || !maxSlots) {
    return MAX_USER_FACING_AVAILABILITY_SLOTS;
  }

  return Math.max(1, Math.min(Math.floor(maxSlots), MAX_AVAILABILITY_QUERY_SLOTS));
}

function getAvailabilityBucketKey(slotStartIso: string): string {
  const localTime = getBrazilLocalTime(new Date(slotStartIso).getTime());
  const month = String(localTime.month + 1).padStart(2, "0");
  const day = String(localTime.day).padStart(2, "0");
  const period = getAvailabilityPeriodForHour(localTime.hour) ?? "other";

  return `${localTime.year}-${month}-${day}|${period}`;
}

function limitAvailabilitySlots<T extends { start: string; end: string }>(
  slots: T[],
  maxSlots?: number,
  period?: AvailabilityPeriod,
): T[] {
  const limit = normalizeRequestedAvailabilityLimit(maxSlots);
  const filtered = slots.filter((slot) => slotMatchesRequestedPeriod(slot.start, period));

  if (filtered.length <= limit) {
    return filtered;
  }

  if (period) {
    return filtered.slice(0, limit);
  }

  const buckets = new Map<string, T[]>();
  const bucketOrder: string[] = [];

  for (const slot of filtered) {
    const bucketKey = getAvailabilityBucketKey(slot.start);
    if (!buckets.has(bucketKey)) {
      buckets.set(bucketKey, []);
      bucketOrder.push(bucketKey);
    }
    buckets.get(bucketKey)!.push(slot);
  }

  const selected: T[] = [];

  while (selected.length < limit) {
    let addedInPass = false;

    for (const bucketKey of bucketOrder) {
      const bucket = buckets.get(bucketKey);
      if (!bucket || bucket.length === 0) {
        continue;
      }

      const slot = bucket.shift();
      if (!slot) {
        continue;
      }

      selected.push(slot);
      addedInPass = true;

      if (selected.length >= limit) {
        break;
      }
    }

    if (!addedInPass) {
      break;
    }
  }

  return selected.sort((a, b) => new Date(a.start).getTime() - new Date(b.start).getTime());
}

export function formatGoogleCalendarDateTime(timestamp: number, timeZone: string): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  }).formatToParts(new Date(timestamp));

  const values = Object.fromEntries(
    parts.filter((part) => part.type !== "literal").map((part) => [part.type, part.value]),
  ) as Record<string, string>;

  return `${values.year}-${values.month}-${values.day}T${values.hour}:${values.minute}:${values.second}`;
}

/**
 * Converts UTC timestamp to Brazil local time components.
 * Brazil is UTC-3, so local time = UTC time - 3 hours.
 * @param timestamp - UTC timestamp (milliseconds)
 * @returns Local time components in Brazil timezone
 */
function getBrazilLocalTime(timestamp: number): {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  dayOfWeek: number;
} {
  const date = new Date(timestamp);
  const utcHour = date.getUTCHours();
  const utcMinute = date.getUTCMinutes();
  let utcDay = date.getUTCDate();
  let utcMonth = date.getUTCMonth();
  let utcYear = date.getUTCFullYear();

  // Convert UTC hour to local hour by subtracting 3
  let localHour = utcHour - 3;
  let localDay = utcDay;
  let localMonth = utcMonth;
  let localYear = utcYear;

  // Handle day boundary crossing
  if (localHour < 0) {
    localHour += 24;
    localDay -= 1;
    if (localDay < 1) {
      localMonth -= 1;
      if (localMonth < 0) {
        localMonth = 11;
        localYear -= 1;
      }
      const prevMonthLastDay = new Date(Date.UTC(localYear, localMonth + 1, 0));
      localDay = prevMonthLastDay.getUTCDate();
    }
  }

  const localDate = new Date(Date.UTC(localYear, localMonth, localDay));

  return {
    year: localYear,
    month: localMonth,
    day: localDay,
    hour: localHour,
    minute: utcMinute,
    dayOfWeek: localDate.getUTCDay(),
  };
}

/**
 * Creates a UTC timestamp for a slot boundary in Brazil local time.
 * Brazil is UTC-3, so to convert local time to UTC: add 3 hours.
 * @param timestamp - Base UTC timestamp (milliseconds) - used to determine which day
 * @param hour - Hour in Brazil local time (0-23)
 * @param minute - Minute in Brazil local time (0-59)
 * @returns UTC timestamp (milliseconds) representing the local time on the same day
 */
function createSlotBoundaryInBrazilTime(timestamp: number, hour: number, minute: number): number {
  const localTime = getBrazilLocalTime(timestamp);
  return createBrazilUtcTimestamp(localTime.year, localTime.month, localTime.day, hour, minute);
}

function isGoogleMeetLink(meetingLink: string | undefined | null) {
  return !!meetingLink && /^https:\/\/meet\.google\.com\//i.test(meetingLink);
}

const TELEMEDICINE_GOOGLE_CALENDAR_REQUIRED_MESSAGE =
  "Conecte o Google Calendar do médico em Integrações para usar teleconsulta.";

function getFallbackTelemedicineLink(meetingLink: string | undefined | null) {
  return isGoogleMeetLink(meetingLink) ? meetingLink : undefined;
}

function buildEvalTelemedicineLink(
  clinicId: string | undefined | null,
  appointmentId: string | undefined | null,
) {
  if (!clinicId || !clinicId.startsWith("promptfoo-eval-clinic")) {
    return undefined;
  }

  const slug = String(appointmentId || "promptfooeval")
    .replace(/[^a-z0-9]/gi, "")
    .toLowerCase()
    .padEnd(10, "x");
  return `https://meet.google.com/${slug.slice(0, 3)}-${slug.slice(3, 7)}-${slug.slice(7, 10)}`;
}

async function assertTelemedicineGoogleCalendarConnected(
  ctx: any,
  clinicId: string,
  doctorId: any,
) {
  const tokens = await ctx.db
    .query("googleOAuthTokens")
    .withIndex("by_clinic_user", (q: any) => q.eq("clinicId", clinicId).eq("userId", doctorId))
    .first();

  if (!tokens) {
    throw new Error(TELEMEDICINE_GOOGLE_CALENDAR_REQUIRED_MESSAGE);
  }
}

function buildTelemedicineSummary(patientName?: string) {
  return `Teleconsulta - ${patientName || "Paciente"}`;
}

async function sendTelemedicineLinkEmail(
  ctx: any,
  args: {
    to: string | undefined;
    startAt: number;
    timeZone: string;
    meetingLink: string | undefined;
    variant?: "created" | "rescheduled";
  },
) {
  if (!args.to || !args.meetingLink) {
    return;
  }

  const startLabel = new Date(args.startAt).toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: args.timeZone,
  });

  const subject =
    args.variant === "rescheduled"
      ? "Novo link da teleconsulta reagendada - WhatsMed"
      : "Link da teleconsulta - WhatsMed";

  const intro =
    args.variant === "rescheduled"
      ? "Sua teleconsulta foi reagendada."
      : "Sua teleconsulta foi confirmada.";

  await ctx.runAction(internalAny.emailActions.sendEmail, {
    to: args.to,
    subject,
    html: `<p>${intro}</p><p><strong>Data e horário:</strong> ${startLabel}</p><p><strong>Link de acesso:</strong> <a href="${args.meetingLink}">${args.meetingLink}</a></p>`,
  });
}

function extractMeetingLink(eventData: any) {
  return (
    eventData?.conferenceData?.entryPoints?.find(
      (entryPoint: any) => entryPoint.entryPointType === "video",
    )?.uri || eventData?.hangoutLink
  );
}

async function getGoogleCalendarAuthForUser(ctx: any, clinicId: string, userId: any) {
  const tokenData = await ctx.runQuery(internalAny.googleCalendar.getAccessToken, {
    clinicId,
    userId,
  });

  const tokens = await ctx.runQuery(internalAny.googleCalendar.getTokensInternal, {
    clinicId,
    userId,
  });

  const primaryCalendarId = tokens?.primaryCalendarId || "primary";

  let accessToken = tokenData?.accessToken;
  let tokenType = tokenData?.tokenType || "Bearer";

  if (!accessToken) {
    if (tokenData?.expired && tokenData.refreshToken) {
      const refreshed = await ctx.runAction(internalAny.googleCalendarActions.refreshAccessToken, {
        clinicId,
        userId,
        refreshToken: tokenData.refreshToken,
      });

      accessToken = refreshed.accessToken;
      tokenType = refreshed.tokenType || "Bearer";
    } else {
      throw new Error(
        "Google Calendar not connected. Please connect your Google account in Integrations.",
      );
    }
  }

  return {
    accessToken,
    tokenType,
    primaryCalendarId,
  };
}

async function getGoogleCalendarConnection(ctx: any, appointment: any) {
  if (!appointment?.doctorId) {
    throw new Error("Appointment must have a doctor assigned");
  }

  const doctor = await ctx.runQuery(apiAny.users.getById, {
    id: appointment.doctorId,
  });

  if (!doctor?.email) {
    throw new Error("Appointment doctor must have an email");
  }

  const { accessToken, tokenType, primaryCalendarId } = await getGoogleCalendarAuthForUser(
    ctx,
    appointment.clinicId,
    appointment.doctorId,
  );

  return {
    doctor,
    accessToken,
    tokenType,
    primaryCalendarId,
  };
}

async function deleteGoogleCalendarEvent(
  ctx: any,
  args: {
    clinicId: string;
    userId: any;
    calendarEventId: string;
    sendUpdates?: "all" | "externalOnly" | "none";
  },
) {
  const { clinicId, userId, calendarEventId, sendUpdates = "all" } = args;
  const { accessToken, tokenType, primaryCalendarId } = await getGoogleCalendarAuthForUser(
    ctx,
    clinicId,
    userId,
  );

  const deleteResponse = await fetch(
    `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(primaryCalendarId)}/events/${encodeURIComponent(calendarEventId)}?sendUpdates=${sendUpdates}`,
    {
      method: "DELETE",
      headers: {
        Authorization: `${tokenType} ${accessToken}`,
      },
    },
  );

  if (!deleteResponse.ok && deleteResponse.status !== 404) {
    const errorText = await deleteResponse.text();
    throw new Error(`Google Calendar API delete error: ${deleteResponse.status} ${errorText}`);
  }
}

// Helper to get current authenticated user for doctor filtering
async function getCurrentUser(ctx: any) {
  let authUser;
  try {
    authUser = await authComponent.getAuthUser(ctx);
  } catch {
    return null;
  }

  if (!authUser) {
    return null;
  }

  const user = await ctx.db
    .query("users")
    .withIndex("by_email", (q: any) => q.eq("email", authUser.email))
    .first();

  return user;
}

export const list = query({
  args: {
    clinicId: v.string(),
    status: v.optional(
      v.union(
        v.literal("pending"),
        v.literal("confirmed"),
        v.literal("cancelled"),
        v.literal("completed"),
        v.literal("arrived"),
      ),
    ),
    patientId: v.optional(v.id("patients")),
    startAt: v.optional(v.number()),
    endAt: v.optional(v.number()),
    limit: v.optional(v.number()),
    cursor: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { clinicId, status, patientId, startAt, endAt, limit = 50, cursor } = args;

    // Get current user for doctor filtering
    const currentUser = await getCurrentUser(ctx);
    const isDoctor = currentUser?.role === "doctor";
    const currentUserId = currentUser?._id;

    // Base query using indexes
    let q;
    let usedDoctorIndex = false;
    if (status) {
      q = ctx.db
        .query("appointments")
        .withIndex("by_clinic_status_date", (q) => q.eq("clinicId", clinicId).eq("status", status));
    } else if (patientId) {
      q = ctx.db
        .query("appointments")
        .withIndex("by_clinic_patient_date", (q) =>
          q.eq("clinicId", clinicId).eq("patientId", patientId),
        );
    } else if (isDoctor && currentUserId) {
      // Use doctor-specific index
      q = ctx.db
        .query("appointments")
        .withIndex("by_clinic_doctor_date", (q) =>
          q.eq("clinicId", clinicId).eq("doctorId", currentUserId),
        );
      usedDoctorIndex = true;
    } else {
      q = ctx.db
        .query("appointments")
        .withIndex("by_clinic_date", (q) => q.eq("clinicId", clinicId));
    }

    // Filter logic
    const results = await q
      .filter((q) => {
        const conditions = [q.eq(q.field("deletedAt"), undefined)];

        // Doctor filtering: if user is doctor and we didn't use doctor index, add filter
        if (isDoctor && currentUserId && !usedDoctorIndex) {
          conditions.push(q.eq(q.field("doctorId"), currentUserId));
        }

        if (startAt) {
          conditions.push(q.gte(q.field("startAt"), startAt));
        }
        if (endAt) {
          conditions.push(q.lte(q.field("startAt"), endAt));
        }

        return q.and(...conditions);
      })
      .paginate({ cursor: cursor ?? null, numItems: limit });

    // Fetch patient details for each appointment
    const appointmentsWithPatient = await Promise.all(
      results.page.map(async (apt) => {
        const patient = await ctx.db.get(apt.patientId);
        return {
          ...apt,
          patientName: patient?.name ?? "Unknown",
        };
      }),
    );

    return {
      items: appointmentsWithPatient,
      cursor: results.continueCursor,
      total: results.page.length,
    };
  },
});

/**
 * Internal query version of list - doesn't require authentication
 * Used by internal actions/system functions
 */
export const listInternal = internalQuery({
  args: {
    clinicId: v.string(),
    statuses: v.optional(
      v.array(
        v.union(
          v.literal("pending"),
          v.literal("confirmed"),
          v.literal("cancelled"),
          v.literal("completed"),
          v.literal("arrived"),
        ),
      ),
    ),
    status: v.optional(
      v.union(
        v.literal("pending"),
        v.literal("confirmed"),
        v.literal("cancelled"),
        v.literal("completed"),
        v.literal("arrived"),
      ),
    ),
    patientId: v.optional(v.id("patients")),
    startAt: v.optional(v.number()),
    endAt: v.optional(v.number()),
    limit: v.optional(v.number()),
    cursor: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { clinicId, statuses, status, patientId, startAt, endAt, limit = 50, cursor } = args;

    // Use statuses array if provided, otherwise fall back to single status
    const statusList = statuses || (status ? [status] : undefined);

    // Base query using indexes
    let q;
    if (statusList && statusList.length === 1) {
      q = ctx.db
        .query("appointments")
        .withIndex("by_clinic_status_date", (q) =>
          q.eq("clinicId", clinicId).eq("status", statusList[0]),
        );
    } else if (patientId) {
      q = ctx.db
        .query("appointments")
        .withIndex("by_clinic_patient_date", (q) =>
          q.eq("clinicId", clinicId).eq("patientId", patientId),
        );
    } else {
      q = ctx.db
        .query("appointments")
        .withIndex("by_clinic_date", (q) => q.eq("clinicId", clinicId));
    }

    // Filter logic
    const results = await q
      .filter((q) => {
        const conditions = [q.eq(q.field("deletedAt"), undefined)];

        // Filter by status list if multiple statuses provided
        if (statusList && statusList.length > 1) {
          const statusConditions = statusList.map((s) => q.eq(q.field("status"), s));
          conditions.push(q.or(...statusConditions));
        }

        if (startAt) {
          conditions.push(q.gte(q.field("startAt"), startAt));
        }
        if (endAt) {
          conditions.push(q.lte(q.field("startAt"), endAt));
        }

        return q.and(...conditions);
      })
      .paginate({ cursor: cursor ?? null, numItems: limit });

    // Fetch patient details for each appointment
    const appointmentsWithPatient = await Promise.all(
      results.page.map(async (apt) => {
        const patient = await ctx.db.get(apt.patientId);
        return {
          ...apt,
          patientName: patient?.name ?? "Unknown",
        };
      }),
    );

    return {
      items: appointmentsWithPatient,
      cursor: results.continueCursor,
      isDone: results.isDone,
      total: appointmentsWithPatient.length,
    };
  },
});

export const getById = query({
  args: {
    id: v.id("appointments"),
    clinicId: v.string(),
  },
  handler: async (ctx, { id, clinicId }) => {
    const appointment = await ctx.db.get(id);
    if (!appointment || appointment.clinicId !== clinicId || appointment.deletedAt) {
      return null;
    }

    // Doctor filtering: if user is doctor, only allow access to their own appointments
    const currentUser = await getCurrentUser(ctx);
    if (currentUser?.role === "doctor" && appointment.doctorId !== currentUser._id) {
      return null;
    }

    const patient = await ctx.db.get(appointment.patientId);
    return {
      ...appointment,
      patientName: patient?.name ?? "Unknown",
    };
  },
});

export const getByIdInternal = internalQuery({
  args: {
    id: v.id("appointments"),
    clinicId: v.string(),
  },
  handler: async (ctx, { id, clinicId }) => {
    const appointment = await ctx.db.get(id);
    if (!appointment || appointment.clinicId !== clinicId || appointment.deletedAt) {
      return null;
    }

    const patient = await ctx.db.get(appointment.patientId);
    return {
      ...appointment,
      patientName: patient?.name ?? "Unknown",
    };
  },
});

export const create = mutation({
  args: {
    clinicId: v.string(),
    patientId: v.id("patients"),
    doctorId: v.id("users"),
    startAt: v.number(),
    endAt: v.number(),
    status: v.optional(
      v.union(
        v.literal("pending"),
        v.literal("confirmed"),
        v.literal("cancelled"),
        v.literal("completed"),
        v.literal("arrived"),
      ),
    ),
    doctor: v.optional(v.string()),
    procedure: v.optional(v.string()),
    procedureId: v.optional(v.id("procedures")),
    notes: v.optional(v.string()),
    reminderAt: v.optional(v.number()),
    patientEmail: v.optional(v.string()),
    timeZone: v.optional(v.string()),
    requiredFormIds: v.optional(v.array(v.id("forms"))),
    isTelemedicine: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    // Check feature access
    const access = await checkFeatureAccess(ctx, args.clinicId, "appointments");
    if (!access.allowed) {
      throw badRequest(`Recurso disponível a partir do plano ${access.requiredPlan}.`);
    }

    // Rate limit: 5 appointments per minute per clinic
    const rateLimit = await checkRateLimit(
      ctx,
      `create_appointment:${args.clinicId}`,
      5,
      60000,
      args.clinicId,
    );
    throwIfRateLimited(rateLimit);

    const {
      clinicId,
      patientId,
      startAt,
      endAt,
      patientEmail,
      timeZone,
      doctorId,
      procedure,
      procedureId,
      notes,
      reminderAt,
      isTelemedicine,
    } = args;

    // Validate date range
    if (!isValidDateRange(startAt, endAt)) {
      throw notFound("Horário de início deve ser anterior ao horário de término");
    }

    // Validate appointment duration (15 min to 8 hours)
    if (!isValidAppointmentDuration(startAt, endAt, 15, 480)) {
      throw notFound("Duração do agendamento deve ser entre 15 minutos e 8 horas");
    }

    // Validate patient belongs to clinic
    const patient = await ctx.db.get(patientId);
    if (!patient || patient.clinicId !== clinicId) {
      throw notFound("Paciente não encontrado nesta clínica");
    }

    // Get patient email (from record or override)
    const finalPatientEmail = patientEmail || patient.email;

    // Validate doctor is always required
    if (!doctorId) {
      throw notFound("Médico é obrigatório");
    }

    const doctorRecord = await ctx.db.get(doctorId);
    if (
      !doctorRecord ||
      doctorRecord.clinicId !== clinicId ||
      doctorRecord.role !== "doctor" ||
      doctorRecord.deletedAt
    ) {
      throw notFound("Médico selecionado inválido");
    }

    const doctor = doctorRecord;
    const doctorEmail = doctor.email;
    if (!doctorEmail) {
      throw notFound("E-mail do médico é obrigatório");
    }

    // Check for overlapping appointments for this doctor
    const existingAppointments = await ctx.db
      .query("appointments")
      .withIndex("by_clinic_doctor_date", (q) =>
        q.eq("clinicId", clinicId).eq("doctorId", doctorId),
      )
      .collect();

    const hasOverlap = existingAppointments.some(
      (app) =>
        app.doctorId === doctorId &&
        !app.deletedAt &&
        app.status !== "cancelled" &&
        doRangesOverlap(startAt, endAt, app.startAt, app.endAt),
    );

    if (hasOverlap) {
      throw notFound("Já existe um agendamento neste horário para este médico");
    }

    // Sanitize text fields
    const sanitizedNotes = notes ? sanitizeString(notes, 2000) : undefined;
    const sanitizedProcedure = procedure ? sanitizeString(procedure, 200) : undefined;

    // Use explicit isTelemedicine value from args, fallback to false
    const isTelemedicineValue = isTelemedicine ?? false;

    if (isTelemedicineValue) {
      await assertTelemedicineGoogleCalendarConnected(ctx, clinicId, doctorId);
    }

    // Validate against working hours
    if (doctor.workingHours && doctor.workingHours.length > 0) {
      // Get Brazil local time components from UTC timestamps
      const localTime = getBrazilLocalTime(startAt);
      const dayOfWeek = localTime.dayOfWeek;

      const config = doctor.workingHours.find((w) => w.dayOfWeek === dayOfWeek);

      // If no config for this day, doctor is not working
      if (!config) {
        throw notFound("Médico não atende neste dia da semana");
      }

      const typeToCheck = isTelemedicineValue ? "telemedicine" : "in_person";

      const isValidSlot = config.slots.some((s) => {
        if (!s.types.includes(typeToCheck)) return false;

        const [sH, sM] = s.start.split(":").map(Number);
        const [eH, eM] = s.end.split(":").map(Number);

        // Create slot boundaries in Brazil timezone (returns UTC timestamps)
        const slotStart = createSlotBoundaryInBrazilTime(startAt, sH, sM);
        const slotEnd = createSlotBoundaryInBrazilTime(startAt, eH, eM);

        // Check if appointment falls COMPLETELY within this slot
        return startAt >= slotStart && endAt <= slotEnd;
      });

      if (!isValidSlot) {
        throw notFound("Horário fora do expediente ou tipo de atendimento não disponível");
      }
    }

    // Create appointment
    const appointmentData = {
      clinicId,
      patientId,
      startAt,
      endAt,
      status: args.status ?? "pending",
      doctorId: doctorId,
      doctor: doctor?.name,
      procedure: sanitizedProcedure,
      procedureId: procedureId,
      notes: sanitizedNotes,
      reminderAt: reminderAt,
      createdAt: Date.now(),
      isTelemedicine: isTelemedicineValue,
      patientEmail: isTelemedicineValue ? finalPatientEmail : undefined,
      doctorEmail: isTelemedicineValue ? doctorEmail : undefined,
      timeZone: isTelemedicineValue ? timeZone || "America/Sao_Paulo" : undefined,
    };

    const id = await ctx.db.insert("appointments", appointmentData);

    // Assign required forms to patient
    if (args.requiredFormIds && args.requiredFormIds.length > 0) {
      for (const formId of args.requiredFormIds) {
        const token = generateSecureToken();
        await ctx.db.insert("patientForms", {
          clinicId,
          patientId,
          appointmentId: id,
          formId,
          status: "pending",
          token,
          createdAt: Date.now(),
        });
      }
    }

    // Schedule Google Meet creation for telemedicine appointments
    if (isTelemedicineValue && doctor && doctorEmail) {
      const summary = `Teleconsulta - ${patient.name}`;
      await ctx.scheduler.runAfter(0, internal.appointments.createGoogleMeetEvent, {
        appointmentId: id,
        summary,
        startAt,
        endAt,
        timeZone: timeZone || "America/Sao_Paulo",
        patientEmail: finalPatientEmail,
        doctorEmail: doctorEmail,
      });
    }

    await ctx.runMutation(internalAny.automationInternal.syncAppointmentScheduledJobs, {
      appointmentId: id,
    });

    return await ctx.db.get(id);
  },
});

export const update = mutation({
  args: {
    id: v.id("appointments"),
    clinicId: v.string(),
    startAt: v.optional(v.number()),
    endAt: v.optional(v.number()),
    status: v.optional(
      v.union(
        v.literal("pending"),
        v.literal("confirmed"),
        v.literal("cancelled"),
        v.literal("completed"),
        v.literal("arrived"),
      ),
    ),
    doctor: v.optional(v.string()),
    doctorId: v.optional(v.id("users")),
    procedure: v.optional(v.string()),
    procedureId: v.optional(v.id("procedures")),
    notes: v.optional(v.string()),
    reminderAt: v.optional(v.number()),
    patientEmail: v.optional(v.string()),
    timeZone: v.optional(v.string()),
    requiredFormIds: v.optional(v.array(v.id("forms"))),
    isTelemedicine: v.optional(v.boolean()),
    rescheduleStatus: v.optional(
      v.union(v.literal("none"), v.literal("awaiting_response"), v.literal("rescheduled")),
    ),
  },
  handler: async (ctx, args) => {
    const { id, clinicId, ...updates } = args;
    const appointment = await ctx.db.get(id);

    if (!appointment || appointment.clinicId !== clinicId || appointment.deletedAt) {
      throw notFound("Appointment not found");
    }

    const newStartAt = updates.startAt ?? appointment.startAt;
    const newEndAt = updates.endAt ?? appointment.endAt;
    const doctorId = updates.doctorId ?? appointment.doctorId;
    const procedureId = updates.procedureId ?? appointment.procedureId;
    const isTelemedicineValue = updates.isTelemedicine ?? appointment.isTelemedicine ?? false;

    if (!doctorId) {
      throw notFound("Médico não encontrado");
    }

    const doctor = await ctx.db.get(doctorId);
    if (!doctor || doctor.clinicId !== clinicId || doctor.role !== "doctor" || doctor.deletedAt) {
      throw notFound("Invalid doctor selected");
    }

    if (isTelemedicineValue) {
      await assertTelemedicineGoogleCalendarConnected(ctx, clinicId, doctorId);
    }

    if (isTelemedicineValue && !doctor.email) {
      throw notFound("E-mail do médico é obrigatório");
    }

    if (procedureId) {
      const procedureRecord = await ctx.db.get(procedureId);
      if (!procedureRecord || procedureRecord.clinicId !== clinicId || !procedureRecord.isActive) {
        throw notFound("Procedimento não encontrado nesta clínica");
      }

      if (procedureRecord.doctorId !== doctorId) {
        throw notFound("Procedimento não pertence ao médico selecionado");
      }

      if (isTelemedicineValue && !procedureRecord.isTelemedicine) {
        throw notFound("Este procedimento não suporta telemedicina");
      }

      if (!isTelemedicineValue && !procedureRecord.isInPerson) {
        throw notFound("Este procedimento não suporta atendimento presencial");
      }
    }

    if (updates.startAt !== undefined || updates.endAt !== undefined) {
      if (!isValidDateRange(newStartAt, newEndAt)) {
        throw notFound("Horário de início deve ser anterior ao horário de término");
      }

      if (!isValidAppointmentDuration(newStartAt, newEndAt, 15, 480)) {
        throw notFound("Duração do agendamento deve ser entre 15 minutos e 8 horas");
      }

      const existingAppointments = await ctx.db
        .query("appointments")
        .withIndex("by_clinic_doctor_date", (q) =>
          q.eq("clinicId", clinicId).eq("doctorId", doctorId),
        )
        .collect();

      const hasOverlap = existingAppointments.some(
        (app) =>
          app._id !== id &&
          !app.deletedAt &&
          app.status !== "cancelled" &&
          doRangesOverlap(newStartAt, newEndAt, app.startAt, app.endAt),
      );

      if (hasOverlap) {
        throw notFound("Já existe um agendamento neste horário para este médico");
      }

      if (doctor.workingHours && doctor.workingHours.length > 0) {
        const localTime = getBrazilLocalTime(newStartAt);
        const dayOfWeek = localTime.dayOfWeek;

        const config = doctor.workingHours.find((w) => w.dayOfWeek === dayOfWeek);

        if (!config) {
          throw notFound("Médico não atende neste dia da semana");
        }

        const typeToCheck = isTelemedicineValue ? "telemedicine" : "in_person";

        const isValidSlot = config.slots.some((s) => {
          if (!s.types.includes(typeToCheck)) return false;

          const [sH, sM] = s.start.split(":").map(Number);
          const [eH, eM] = s.end.split(":").map(Number);

          const slotStart = createSlotBoundaryInBrazilTime(newStartAt, sH, sM);
          const slotEnd = createSlotBoundaryInBrazilTime(newStartAt, eH, eM);

          return newStartAt >= slotStart && newEndAt <= slotEnd;
        });

        if (!isValidSlot) {
          throw notFound("Horário fora do expediente ou tipo de atendimento não disponível");
        }
      }
    }

    const patchData = Object.fromEntries(
      Object.entries(updates).filter(([, value]) => value !== undefined),
    ) as Record<string, unknown>;

    if (updates.doctorId !== undefined) {
      patchData.doctor = doctor.name;
    } else if (updates.doctor !== undefined) {
      patchData.doctor = updates.doctor;
    }

    if (updates.procedure !== undefined) {
      patchData.procedure =
        updates.procedure === "" ? updates.procedure : sanitizeString(updates.procedure, 200);
    }

    if (updates.notes !== undefined) {
      patchData.notes = updates.notes === "" ? updates.notes : sanitizeString(updates.notes, 2000);
    }

    if (isTelemedicineValue) {
      const patient = await ctx.db.get(appointment.patientId);
      patchData.patientEmail =
        updates.patientEmail ?? appointment.patientEmail ?? patient?.email ?? undefined;
      patchData.doctorEmail = doctor.email;
      patchData.timeZone = updates.timeZone ?? appointment.timeZone ?? "America/Sao_Paulo";
    } else if (updates.isTelemedicine !== undefined || appointment.isTelemedicine) {
      patchData.patientEmail = undefined;
      patchData.doctorEmail = undefined;
      patchData.timeZone = undefined;
    }

    patchData.updatedAt = Date.now();

    await ctx.db.patch(id, patchData);

    const didReschedule =
      (updates.startAt !== undefined || updates.endAt !== undefined) &&
      (updates.rescheduleStatus === "rescheduled" ||
        appointment.rescheduleStatus === "awaiting_response");

    const shouldSyncTelemedicineMeeting =
      (!!appointment.calendarEventId || appointment.isTelemedicine || isTelemedicineValue) &&
      (updates.startAt !== undefined ||
        updates.endAt !== undefined ||
        updates.status !== undefined ||
        updates.isTelemedicine !== undefined ||
        updates.doctorId !== undefined ||
        updates.patientEmail !== undefined ||
        updates.timeZone !== undefined);

    if (shouldSyncTelemedicineMeeting) {
      await ctx.scheduler.runAfter(0, internal.appointments.syncTelemedicineMeeting, {
        appointmentId: id,
        previousDoctorId: appointment.doctorId,
        previousCalendarEventId: appointment.calendarEventId,
        previousWasTelemedicine: appointment.isTelemedicine ?? false,
        notifyPatientEmail:
          !!isTelemedicineValue &&
          ((updates.startAt !== undefined && updates.startAt !== appointment.startAt) ||
            (updates.endAt !== undefined && updates.endAt !== appointment.endAt)) &&
          didReschedule,
      });
    }

    if (didReschedule) {
      await ctx.runMutation(internalAny.automationInternal.resetScheduledReminderStates, {
        appointmentId: id,
      });

      await ctx.scheduler.runAfter(
        0,
        internal.appointments.sendRescheduleConfirmationInternal as any,
        {
          appointmentId: id,
          clinicId,
          newStartAt,
          isTelemedicine: isTelemedicineValue,
        },
      );
    }

    await ctx.runMutation(internalAny.automationInternal.syncAppointmentScheduledJobs, {
      appointmentId: id,
    });

    // Check if status changed TO "completed" and NPS should be sent
    if (updates.status === "completed" && appointment.status !== "completed") {
      // Check if appointment already has an NPS response
      const existingResponse = await ctx.runQuery(internal.nps.getNpsResponseByAppointment, {
        appointmentId: id,
      });

      if (existingResponse) {
        console.warn(
          `[updateAppointment] Appointment ${id} already has NPS response, skipping survey scheduling`,
        );
      } else {
        // Check if NPS is enabled for this clinic
        const npsSettings = await ctx.runQuery(internal.nps.getNpsSettingsInternal, {
          clinicId,
        });

        if (npsSettings?.enabled && npsSettings.sendOnCompletion) {
          // Calculate delay in milliseconds
          const delayMs = (npsSettings.delayMinutes || 120) * 60 * 1000;

          // Schedule NPS survey with delay
          await ctx.scheduler.runAfter(delayMs, internal.nps.sendNpsSurveyAction, {
            appointmentId: id,
            clinicId,
            patientId: appointment.patientId,
            delayMinutes: npsSettings.delayMinutes,
          });
        }
      }
    }

    return await ctx.db.get(id);
  },
});

export const softDelete = mutation({
  args: {
    id: v.id("appointments"),
    clinicId: v.string(),
  },
  handler: async (ctx, { id, clinicId }) => {
    const appointment = await ctx.db.get(id);
    if (!appointment || appointment.clinicId !== clinicId) {
      throw notFound("Appointment not found");
    }

    await ctx.db.patch(id, {
      deletedAt: Date.now(),
      status: "cancelled", // Also cancel it
    });

    await ctx.runMutation(internalAny.automationInternal.syncAppointmentScheduledJobs, {
      appointmentId: id,
    });

    if (appointment.calendarEventId || appointment.isTelemedicine) {
      await ctx.scheduler.runAfter(0, internal.appointments.syncTelemedicineMeeting, {
        appointmentId: id,
        previousDoctorId: appointment.doctorId,
        previousCalendarEventId: appointment.calendarEventId,
        previousWasTelemedicine: appointment.isTelemedicine ?? false,
      });
    }
  },
});

export const listUpcomingForScheduledJobBackfill = internalQuery({
  args: {
    clinicId: v.optional(v.string()),
    startAt: v.number(),
    endAt: v.number(),
  },
  handler: async (ctx, args) => {
    const appointments = await ctx.db.query("appointments").collect();

    return appointments
      .filter((appointment) => {
        if (appointment.deletedAt) {
          return false;
        }

        if (args.clinicId && appointment.clinicId !== args.clinicId) {
          return false;
        }

        if (appointment.startAt < args.startAt || appointment.startAt > args.endAt) {
          return false;
        }

        return ["pending", "confirmed"].includes(appointment.status);
      })
      .map((appointment) => ({
        _id: appointment._id,
        clinicId: appointment.clinicId,
        status: appointment.status,
        startAt: appointment.startAt,
        rescheduleStatus: appointment.rescheduleStatus,
      }));
  },
});

export const backfillUpcomingScheduledJobs = action({
  args: {
    clinicId: v.optional(v.string()),
    hoursAhead: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    const endAt = now + Math.max(1, args.hoursAhead ?? 7 * 24) * 60 * 60 * 1000;

    const appointments = await ctx.runQuery(
      internalAny.appointments.listUpcomingForScheduledJobBackfill,
      {
        clinicId: args.clinicId,
        startAt: now,
        endAt,
      },
    );

    const results = [];
    for (const appointment of appointments) {
      const existingJobs = await ctx.runQuery(
        internalAny.automationInternal.listAppointmentScheduledJobs,
        {
          appointmentId: appointment._id,
        },
      );

      if (existingJobs.some((job: any) => job.status === "scheduled")) {
        results.push({
          appointmentId: appointment._id,
          skipped: true,
          reason: "already_scheduled",
        });
        continue;
      }

      const syncResult = await ctx.runMutation(
        internalAny.automationInternal.syncAppointmentScheduledJobs,
        {
          appointmentId: appointment._id,
        },
      );

      results.push({
        appointmentId: appointment._id,
        clinicId: appointment.clinicId,
        status: appointment.status,
        scheduled: syncResult?.scheduled || 0,
      });
    }

    return {
      scanned: appointments.length,
      scheduled: results.filter((result) => !result.skipped && result.scheduled > 0).length,
      results,
    };
  },
});

async function getOrCreateAppointmentChatId(ctx: any, appointment: any, patient: any) {
  if (!patient?.phone) {
    return null;
  }

  const existingChat = await ctx.runQuery(internalAny.whatsappQueries.findChatByPhone, {
    clinicId: appointment.clinicId,
    phone: patient.phone,
  });

  if (existingChat) {
    return existingChat._id;
  }

  const cleanPhone = String(patient.phone).replace(/\D/g, "");
  if (!cleanPhone) {
    return null;
  }

  const whatsappPhone = cleanPhone.startsWith("55") ? cleanPhone : `55${cleanPhone}`;
  return await ctx.runMutation(internalAny.whatsappQueries.createChatInternal, {
    clinicId: appointment.clinicId,
    patientId: appointment.patientId,
    whatsappChatId: `${whatsappPhone}@s.whatsapp.net`,
    title: patient.name,
  });
}

export const confirmByPatientReplyInternal = internalMutation({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
    responseMessageId: v.id("messages"),
  },
  handler: async (ctx, args) => {
    const appointment = await ctx.db.get(args.appointmentId);
    if (
      !appointment ||
      appointment.clinicId !== args.clinicId ||
      appointment.deletedAt ||
      appointment.status === "cancelled"
    ) {
      return { confirmed: false };
    }

    await ctx.db.patch(args.appointmentId, {
      status: "confirmed",
      rescheduleStatus: "none",
      rescheduleOfferedSlots: undefined,
      updatedAt: Date.now(),
    });

    const currentReminder = await ctx.db
      .query("appointmentReminders")
      .withIndex("by_appointment_type", (q) =>
        q.eq("appointmentId", args.appointmentId).eq("reminderType", "appointmentConfirmation"),
      )
      .first();

    await ctx.runMutation(internalAny.automationInternal.upsertAppointmentReminderState, {
      clinicId: args.clinicId,
      appointmentId: args.appointmentId,
      reminderType: "appointmentConfirmation",
      status: currentReminder?.status || "sent",
      responseStatus: "confirmed",
      responseMessageId: args.responseMessageId,
      respondedAt: Date.now(),
      channels: currentReminder?.channels || ["whatsapp"],
      sentAt: currentReminder?.sentAt,
      lastError: currentReminder?.lastError,
    });

    await ctx.runMutation(internalAny.automationInternal.syncAppointmentScheduledJobs, {
      appointmentId: args.appointmentId,
    });

    const patient = await ctx.db.get(appointment.patientId);
    const chatId = await getOrCreateAppointmentChatId(ctx, appointment, patient);

    return { confirmed: true, chatId };
  },
});

export const prepareRescheduleOptionsInternal = internalMutation({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
    offeredSlots: v.array(
      v.object({
        startAt: v.number(),
        endAt: v.number(),
      }),
    ),
    responseMessageId: v.optional(v.id("messages")),
  },
  handler: async (ctx, args) => {
    const appointment = await ctx.db.get(args.appointmentId);
    if (!appointment || appointment.clinicId !== args.clinicId || appointment.deletedAt) {
      return { prepared: false };
    }

    await ctx.db.patch(args.appointmentId, {
      status: "pending",
      rescheduleStatus: "awaiting_response",
      rescheduleOfferedSlots: args.offeredSlots,
      updatedAt: Date.now(),
    });

    const currentReminder = await ctx.db
      .query("appointmentReminders")
      .withIndex("by_appointment_type", (q) =>
        q.eq("appointmentId", args.appointmentId).eq("reminderType", "appointmentConfirmation"),
      )
      .first();

    await ctx.runMutation(internalAny.automationInternal.upsertAppointmentReminderState, {
      clinicId: args.clinicId,
      appointmentId: args.appointmentId,
      reminderType: "appointmentConfirmation",
      status: currentReminder?.status || "sent",
      responseStatus: "reschedule_requested",
      responseMessageId: args.responseMessageId,
      respondedAt: Date.now(),
      channels: currentReminder?.channels || ["whatsapp"],
      sentAt: currentReminder?.sentAt,
      lastError: currentReminder?.lastError,
    });

    await ctx.runMutation(internalAny.automationInternal.syncAppointmentScheduledJobs, {
      appointmentId: args.appointmentId,
    });

    const patient = await ctx.db.get(appointment.patientId);
    const chatId = await getOrCreateAppointmentChatId(ctx, appointment, patient);
    return { prepared: true, chatId };
  },
});

export const cancelAfterRescheduleDeclineInternal = internalMutation({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
    responseMessageId: v.optional(v.id("messages")),
  },
  handler: async (ctx, args) => {
    const appointment = await ctx.db.get(args.appointmentId);
    if (!appointment || appointment.clinicId !== args.clinicId || appointment.deletedAt) {
      return { cancelled: false };
    }

    await ctx.db.patch(args.appointmentId, {
      status: "cancelled",
      rescheduleStatus: "none",
      rescheduleOfferedSlots: undefined,
      updatedAt: Date.now(),
    });

    const currentReminder = await ctx.db
      .query("appointmentReminders")
      .withIndex("by_appointment_type", (q) =>
        q.eq("appointmentId", args.appointmentId).eq("reminderType", "appointmentConfirmation"),
      )
      .first();

    await ctx.runMutation(internalAny.automationInternal.upsertAppointmentReminderState, {
      clinicId: args.clinicId,
      appointmentId: args.appointmentId,
      reminderType: "appointmentConfirmation",
      status: currentReminder?.status || "sent",
      responseStatus: "cancelled",
      responseMessageId: args.responseMessageId,
      respondedAt: Date.now(),
      channels: currentReminder?.channels || ["whatsapp"],
      sentAt: currentReminder?.sentAt,
      lastError: currentReminder?.lastError,
    });

    await ctx.runMutation(internalAny.automationInternal.syncAppointmentScheduledJobs, {
      appointmentId: args.appointmentId,
    });

    const patient = await ctx.db.get(appointment.patientId);
    const chatId = await getOrCreateAppointmentChatId(ctx, appointment, patient);

    return { cancelled: true, chatId };
  },
});

export const cancelFromRescheduleTimeoutInternal = internalMutation({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const appointment = await ctx.db.get(args.appointmentId);
    if (
      !appointment ||
      appointment.clinicId !== args.clinicId ||
      appointment.deletedAt ||
      appointment.rescheduleStatus !== "awaiting_response"
    ) {
      return { cancelled: false };
    }

    await ctx.db.patch(args.appointmentId, {
      status: "cancelled",
      rescheduleStatus: "none",
      rescheduleOfferedSlots: undefined,
      updatedAt: Date.now(),
    });

    await ctx.runMutation(internalAny.automationInternal.syncAppointmentScheduledJobs, {
      appointmentId: args.appointmentId,
    });

    const patient = await ctx.db.get(appointment.patientId);
    const chatId = await getOrCreateAppointmentChatId(ctx, appointment, patient);

    return { cancelled: true, chatId };
  },
});

export const applyRescheduleOptionInternal = internalMutation({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
    optionIndex: v.number(),
    responseMessageId: v.id("messages"),
  },
  handler: async (ctx, args) => {
    const appointment = await ctx.db.get(args.appointmentId);
    if (!appointment || appointment.clinicId !== args.clinicId || appointment.deletedAt) {
      throw notFound("Consulta nao encontrada");
    }

    const offeredSlots = appointment.rescheduleOfferedSlots || [];
    const selectedSlot = offeredSlots[args.optionIndex];
    if (!selectedSlot) {
      throw notFound("Opcao de reagendamento invalida");
    }

    await ctx.runMutation(apiAny.appointments.update, {
      id: args.appointmentId,
      clinicId: args.clinicId,
      startAt: selectedSlot.startAt,
      endAt: selectedSlot.endAt,
      status: "confirmed",
      rescheduleStatus: "rescheduled",
    });

    const currentReminder = await ctx.db
      .query("appointmentReminders")
      .withIndex("by_appointment_type", (q) =>
        q.eq("appointmentId", args.appointmentId).eq("reminderType", "appointmentConfirmation"),
      )
      .first();

    await ctx.runMutation(internalAny.automationInternal.upsertAppointmentReminderState, {
      clinicId: args.clinicId,
      appointmentId: args.appointmentId,
      reminderType: "appointmentConfirmation",
      status: currentReminder?.status || "sent",
      responseStatus: "confirmed",
      responseMessageId: args.responseMessageId,
      respondedAt: Date.now(),
      channels: currentReminder?.channels || ["whatsapp"],
      sentAt: currentReminder?.sentAt,
      lastError: currentReminder?.lastError,
    });

    await ctx.db.patch(args.appointmentId, {
      rescheduleOfferedSlots: undefined,
      updatedAt: Date.now(),
    });

    return { rescheduled: true };
  },
});

// Internal query to get appointment for meeting creation
export const getAppointmentForMeeting = internalQuery({
  args: {
    appointmentId: v.id("appointments"),
  },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.appointmentId);
  },
});

// Internal mutation to update appointment with meeting data
export const updateMeetingData = internalMutation({
  args: {
    appointmentId: v.id("appointments"),
    meetingLink: v.optional(v.union(v.string(), v.null())),
    calendarEventId: v.optional(v.union(v.string(), v.null())),
    conferenceData: v.optional(v.union(v.any(), v.null())),
    meetingError: v.optional(v.union(v.string(), v.null())),
  },
  handler: async (ctx, args) => {
    const { appointmentId, meetingLink, calendarEventId, conferenceData, meetingError } = args;

    const update: any = {
      updatedAt: Date.now(),
    };

    if (meetingLink !== undefined) {
      update.meetingLink = meetingLink ?? undefined;

      if (meetingLink) {
        const match = meetingLink.match(/\/[a-z]{3}-[a-z]{4}-[a-z]{3}$/i);
        update.meetingId = match ? match[0].substring(1) : undefined;
        update.meetingCreatedAt = Date.now();
      } else {
        update.meetingId = undefined;
        update.meetingCreatedAt = undefined;
      }
    }

    if (calendarEventId !== undefined) {
      update.calendarEventId = calendarEventId ?? undefined;
    }

    if (conferenceData !== undefined) {
      update.conferenceData = conferenceData ?? undefined;
    }

    if (meetingError !== undefined) {
      update.meetingError = meetingError ?? undefined;
    } else if (
      meetingLink !== undefined ||
      calendarEventId !== undefined ||
      conferenceData !== undefined
    ) {
      update.meetingError = undefined;
    }

    await ctx.db.patch(appointmentId, update);
  },
});

export const syncTelemedicineMeeting = internalAction({
  args: {
    appointmentId: v.id("appointments"),
    previousDoctorId: v.optional(v.id("users")),
    previousCalendarEventId: v.optional(v.string()),
    previousWasTelemedicine: v.optional(v.boolean()),
    notifyPatientEmail: v.optional(v.boolean()),
  },
  handler: async (
    ctx,
    {
      appointmentId,
      previousDoctorId,
      previousCalendarEventId,
      previousWasTelemedicine,
      notifyPatientEmail,
    },
  ) => {
    const appointment = await ctx.runQuery(internalAny.appointments.getAppointmentForMeeting, {
      appointmentId,
    });

    if (!appointment) {
      throw new Error("Appointment not found");
    }

    const shouldDeletePreviousEvent =
      !!previousCalendarEventId &&
      !!previousDoctorId &&
      !!previousWasTelemedicine &&
      (previousDoctorId !== appointment.doctorId ||
        !appointment.isTelemedicine ||
        appointment.status === "cancelled" ||
        !!appointment.deletedAt);

    let previousDeleteError: string | undefined;

    if (shouldDeletePreviousEvent) {
      try {
        await deleteGoogleCalendarEvent(ctx, {
          clinicId: appointment.clinicId,
          userId: previousDoctorId,
          calendarEventId: previousCalendarEventId,
          sendUpdates: "all",
        });
      } catch (deleteError) {
        console.error("Failed to delete previous Google Calendar event:", deleteError);
        previousDeleteError =
          deleteError instanceof Error ? deleteError.message : String(deleteError);
      }
    }

    if (
      !appointment.isTelemedicine ||
      appointment.status === "cancelled" ||
      appointment.deletedAt
    ) {
      await ctx.runMutation(internalAny.appointments.updateMeetingData, {
        appointmentId,
        meetingLink: null,
        calendarEventId: previousDeleteError
          ? (previousCalendarEventId ?? appointment.calendarEventId ?? null)
          : null,
        conferenceData: previousDeleteError ? (appointment.conferenceData ?? null) : null,
        meetingError: previousDeleteError ?? null,
      });
      return {
        synced: false,
        reason: previousDeleteError ? "cleanup_failed" : "not_telemedicine",
        error: previousDeleteError,
      };
    }

    const patient = await ctx.runQuery(internalAny.patients.getByIdInternal, {
      id: appointment.patientId,
    });

    const patientEmail = appointment.patientEmail || patient?.email;
    const timeZone = appointment.timeZone || "America/Sao_Paulo";

    try {
      const { doctor, accessToken, tokenType, primaryCalendarId } =
        await getGoogleCalendarConnection(ctx, appointment);

      const baseUrl = `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(primaryCalendarId)}/events`;
      const attendees: Array<{ email: string }> = [{ email: doctor.email }];
      if (patientEmail) {
        attendees.push({ email: patientEmail });
      }

      const payload = {
        summary: buildTelemedicineSummary(patient?.name),
        start: {
          dateTime: formatGoogleCalendarDateTime(appointment.startAt, timeZone),
          timeZone,
        },
        end: {
          dateTime: formatGoogleCalendarDateTime(appointment.endAt, timeZone),
          timeZone,
        },
        attendees,
      } as Record<string, unknown>;

      let eventData: any;
      const currentCalendarEventId =
        previousDoctorId && previousDoctorId !== appointment.doctorId
          ? undefined
          : appointment.calendarEventId;

      if (currentCalendarEventId) {
        const existingResponse = await fetch(
          `${baseUrl}/${encodeURIComponent(currentCalendarEventId)}?conferenceDataVersion=1`,
          {
            headers: {
              Authorization: `${tokenType} ${accessToken}`,
            },
          },
        );

        if (existingResponse.ok) {
          const existingEvent = await existingResponse.json();
          if (existingEvent?.conferenceData || appointment.conferenceData) {
            payload.conferenceData = existingEvent?.conferenceData || appointment.conferenceData;
          }

          const patchResponse = await fetch(
            `${baseUrl}/${encodeURIComponent(currentCalendarEventId)}?conferenceDataVersion=1&sendUpdates=all`,
            {
              method: "PATCH",
              headers: {
                "Content-Type": "application/json",
                Authorization: `${tokenType} ${accessToken}`,
              },
              body: JSON.stringify(payload),
            },
          );

          if (!patchResponse.ok) {
            const errorText = await patchResponse.text();
            throw new Error(`Google Calendar API error: ${patchResponse.status} ${errorText}`);
          }

          eventData = await patchResponse.json();
        } else if (existingResponse.status !== 404) {
          const errorText = await existingResponse.text();
          throw new Error(`Google Calendar API error: ${existingResponse.status} ${errorText}`);
        }
      }

      if (!eventData) {
        const createResponse = await fetch(`${baseUrl}?conferenceDataVersion=1`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `${tokenType} ${accessToken}`,
          },
          body: JSON.stringify({
            ...payload,
            conferenceData: {
              createRequest: {
                requestId: `appt-${appointmentId}-${appointment.startAt}`,
                conferenceSolutionKey: {
                  type: "hangoutsMeet",
                },
              },
            },
          }),
        });

        if (!createResponse.ok) {
          const errorText = await createResponse.text();
          throw new Error(`Google Calendar API error: ${createResponse.status} ${errorText}`);
        }

        eventData = await createResponse.json();
      }

      await ctx.runMutation(internalAny.appointments.updateMeetingData, {
        appointmentId,
        meetingLink: extractMeetingLink(eventData),
        calendarEventId: eventData.id,
        conferenceData: eventData.conferenceData,
      });

      const syncedMeetingLink = extractMeetingLink(eventData);
      if (notifyPatientEmail && patientEmail && syncedMeetingLink) {
        try {
          await sendTelemedicineLinkEmail(ctx, {
            to: patientEmail,
            startAt: appointment.startAt,
            timeZone,
            meetingLink: syncedMeetingLink,
            variant: "rescheduled",
          });
        } catch (emailError) {
          console.error("Failed to send telemedicine reschedule email:", emailError);
        }
      }

      return {
        synced: true,
        calendarEventId: eventData.id,
        meetingLink: syncedMeetingLink,
      };
    } catch (error: any) {
      console.error("Failed to sync Google Meet event:", error);

      const fallbackMeetingLink =
        getFallbackTelemedicineLink(appointment?.meetingLink) ||
        buildEvalTelemedicineLink(appointment?.clinicId, String(appointmentId));
      await ctx.runMutation(internalAny.appointments.updateMeetingData, {
        appointmentId,
        meetingLink: fallbackMeetingLink ?? null,
        calendarEventId: null,
        conferenceData: null,
        meetingError: error.message || "Failed to sync Google Meet event",
      });

      if (notifyPatientEmail && patientEmail && fallbackMeetingLink) {
        try {
          await sendTelemedicineLinkEmail(ctx, {
            to: patientEmail,
            startAt: appointment.startAt,
            timeZone,
            meetingLink: fallbackMeetingLink,
            variant: "rescheduled",
          });
        } catch (emailError) {
          console.error("Failed to send telemedicine reschedule fallback email:", emailError);
        }
      }

      return {
        synced: false,
        meetingLink: fallbackMeetingLink,
        error: error.message || "Failed to sync Google Meet event",
      };
    }
  },
});

// Internal action to create Google Meet event via Google Calendar API
export const createGoogleMeetEvent = internalAction({
  args: {
    appointmentId: v.id("appointments"),
    summary: v.string(),
    startAt: v.number(),
    endAt: v.number(),
    timeZone: v.string(),
    patientEmail: v.optional(v.string()),
    doctorEmail: v.string(),
  },
  handler: async (ctx, args) => {
    const { appointmentId, summary, startAt, endAt, timeZone, patientEmail, doctorEmail } = args;
    let appointmentTimeZone = timeZone || "America/Sao_Paulo";
    let appointmentPatientEmail = patientEmail;
    let appointment: any;

    try {
      // Get access token from stored OAuth tokens
      // First, get the appointment to find clinicId and doctorId
      appointment = await ctx.runQuery(internalAny.appointments.getAppointmentForMeeting, {
        appointmentId,
      });

      if (!appointment) {
        throw new Error("Appointment not found");
      }

      appointmentTimeZone = appointment.timeZone || timeZone || "America/Sao_Paulo";
      appointmentPatientEmail = appointment.patientEmail || patientEmail;

      if (
        !appointment.isTelemedicine ||
        appointment.status === "cancelled" ||
        appointment.deletedAt
      ) {
        return await ctx.runAction(internalAny.appointments.syncTelemedicineMeeting, {
          appointmentId,
        });
      }

      if (
        appointment.startAt !== startAt ||
        appointment.endAt !== endAt ||
        (appointment.doctorEmail || doctorEmail) !== doctorEmail ||
        appointmentTimeZone !== (timeZone || "America/Sao_Paulo") ||
        (appointmentPatientEmail || undefined) !== (patientEmail || undefined)
      ) {
        return await ctx.runAction(internalAny.appointments.syncTelemedicineMeeting, {
          appointmentId,
        });
      }

      // Google Calendar expects the local wall-clock time to match the provided timeZone.
      const startDateTime = formatGoogleCalendarDateTime(appointment.startAt, appointmentTimeZone);
      const endDateTime = formatGoogleCalendarDateTime(appointment.endAt, appointmentTimeZone);

      // Build attendees array
      const attendees: Array<{ email: string }> = [{ email: doctorEmail }];
      if (appointmentPatientEmail) {
        attendees.push({ email: appointmentPatientEmail });
      }

      // Prepare request body for Google Calendar API
      const requestBody = {
        summary,
        start: {
          dateTime: startDateTime,
          timeZone: appointmentTimeZone,
        },
        end: {
          dateTime: endDateTime,
          timeZone: appointmentTimeZone,
        },
        attendees,
        conferenceData: {
          createRequest: {
            requestId: `appt-${appointmentId}-${appointment.startAt}`,
            conferenceSolutionKey: {
              type: "hangoutsMeet",
            },
          },
        },
      };

      // Get stored tokens for the clinic/user (using doctor's tokens)
      if (!appointment.doctorId) {
        throw new Error("Appointment must have a doctor assigned");
      }

      const tokenData = await ctx.runQuery(internalAny.googleCalendar.getAccessToken, {
        clinicId: appointment.clinicId,
        userId: appointment.doctorId,
      });

      // Also get settings to find primary calendar
      const tokens = await ctx.runQuery(internalAny.googleCalendar.getTokensInternal, {
        clinicId: appointment.clinicId,
        userId: appointment.doctorId,
      });
      const primaryCalendarId = tokens?.primaryCalendarId || "primary";

      if (!tokenData || !tokenData.accessToken) {
        // Try to refresh if expired
        if (tokenData?.expired && tokenData.refreshToken) {
          const refreshed = await ctx.runAction(
            internalAny.googleCalendarActions.refreshAccessToken,
            {
              clinicId: appointment.clinicId,
              userId: appointment.doctorId,
              refreshToken: tokenData.refreshToken,
            },
          );
          tokenData.accessToken = refreshed.accessToken;
          tokenData.tokenType = refreshed.tokenType;
        } else {
          throw new Error(
            "Google Calendar not connected. Please connect your Google account in Integrations.",
          );
        }
      }

      const accessToken = tokenData.accessToken;
      const tokenType = tokenData.tokenType || "Bearer";

      // Create calendar event with Google Meet
      const url = `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(primaryCalendarId)}/events?conferenceDataVersion=1`;

      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `${tokenType} ${accessToken}`,
        },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Google Calendar API error: ${response.status} ${errorText}`);
      }

      const eventData = await response.json();

      // Extract meeting link from conference data
      const meetingLink = extractMeetingLink(eventData);

      // Update appointment with meeting data
      await ctx.runMutation(internalAny.appointments.updateMeetingData, {
        appointmentId,
        meetingLink,
        calendarEventId: eventData.id,
        conferenceData: eventData.conferenceData,
      });

      if (appointmentPatientEmail && meetingLink) {
        try {
          await sendTelemedicineLinkEmail(ctx, {
            to: appointmentPatientEmail,
            startAt: appointment.startAt,
            timeZone: appointmentTimeZone,
            meetingLink,
            variant: "created",
          });
        } catch (emailError) {
          console.error("Failed to send telemedicine email:", emailError);
        }
      }
    } catch (error: any) {
      console.error("Failed to create Google Meet event:", error);

      const fallbackMeetingLink =
        getFallbackTelemedicineLink(appointment?.meetingLink) ||
        buildEvalTelemedicineLink(appointment?.clinicId, String(appointmentId));

      await ctx.runMutation(internalAny.appointments.updateMeetingData, {
        appointmentId,
        meetingLink: fallbackMeetingLink ?? null,
        calendarEventId: null,
        conferenceData: null,
        meetingError: error.message || "Failed to create Google Meet event",
      });

      if (appointmentPatientEmail && fallbackMeetingLink) {
        try {
          await sendTelemedicineLinkEmail(ctx, {
            to: appointmentPatientEmail,
            startAt,
            timeZone: appointmentTimeZone,
            meetingLink: fallbackMeetingLink,
            variant: "created",
          });
        } catch (emailError) {
          console.error("Failed to send telemedicine fallback email:", emailError);
        }
      }
    }
  },
});

// Check-in mutation
export const checkInPatient = mutation({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
  },
  handler: async (ctx, { appointmentId, clinicId }) => {
    const currentUser = await getCurrentUser(ctx);
    const userId = currentUser
      ? currentUser.authUserId || (currentUser._id ? String(currentUser._id) : undefined)
      : undefined;

    const appointment = await ctx.db.get(appointmentId);
    if (!appointment || appointment.clinicId !== clinicId || appointment.deletedAt) {
      throw notFound("Consulta não encontrada");
    }

    // Validate status is in allowed states (idempotency)
    const allowedStatuses = ["pending", "confirmed", "arrived"];
    if (!allowedStatuses.includes(appointment.status)) {
      throw new Error(`Consulta em status inválido para check-in: ${appointment.status}`);
    }

    // If already arrived, return success (idempotency)
    if (appointment.status === "arrived") {
      return await ctx.db.get(appointmentId);
    }

    // Update appointment status
    await ctx.db.patch(appointmentId, {
      status: "arrived",
      actualArrivalTime: Date.now(),
      updatedAt: Date.now(),
    });

    // Add to waitlist queue for reception tracking
    await ctx.runMutation(internal.waitlists.upsertWaitlistForCheckin, {
      clinicId,
      appointmentId,
      patientId: appointment.patientId,
      doctorId: appointment.doctorId,
    });

    // Create audit log
    await ctx.runMutation(internalAny.auditLogs.insert, {
      action: "checkin_complete",
      clinicId,
      userId,
      metadata: {
        appointmentId,
        patientId: appointment.patientId,
        actualArrivalTime: Date.now(),
      },
      createdAt: Date.now(),
    });

    // Schedule NPS survey if enabled
    await ctx.scheduler.runAfter(0, internal.appointments.scheduleNpsSurvey, {
      patientId: appointment.patientId,
      appointmentId,
      clinicId,
    });

    return await ctx.db.get(appointmentId);
  },
});

// Internal helper to schedule NPS survey
export const scheduleNpsSurvey = internalAction({
  args: {
    patientId: v.id("patients"),
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
  },
  handler: async (ctx, { patientId, appointmentId: _appointmentId, clinicId }) => {
    try {
      // Check NPS settings for clinic
      const npsSettings = await ctx.runQuery(internalAny.nps.getNpsSettingsInternal, {
        clinicId,
      });

      if (!npsSettings || !npsSettings.enabled || !npsSettings.sendOnCompletion) {
        console.warn("NPS not enabled for clinic, skipping survey");
        return;
      }

      // Check if patient has opted out (optional future enhancement)
      // const patient = await ctx.runQuery(internalAny.patients.getById, { id: patientId });
      // if (patient?.npsOptOut) return;

      // Schedule NPS survey after delay
      const delayMs = (npsSettings.delayMinutes || 120) * 60 * 1000;

      await ctx.scheduler.runAfter(delayMs, internalAny.nps.sendNpsSurveyAction, {
        patientId,
        appointmentId: _appointmentId,
        clinicId,
        delayMinutes: npsSettings.delayMinutes,
      });

      console.warn(
        `NPS survey scheduled for patient ${patientId} in ${npsSettings.delayMinutes} minutes`,
      );
    } catch (error: any) {
      console.error("Failed to schedule NPS survey:", error);
      // Don't fail the check-in if NPS scheduling fails
    }
  },
});

// Query to get available slots for rescheduling
export const getAvailableSlots = query({
  args: {
    clinicId: v.string(),
    doctorId: v.id("users"),
    procedureId: v.id("procedures"),
    date: v.optional(v.string()), // ISO date string (YYYY-MM-DD)
    startTime: v.optional(v.string()), // ISO datetime string
    endTime: v.optional(v.string()), // ISO datetime string
    isTelemedicine: v.optional(v.boolean()), // Filter by appointment type when provided
    period: v.optional(v.union(v.literal("morning"), v.literal("afternoon"), v.literal("night"))),
    maxSlots: v.optional(v.number()),
  },
  handler: async (
    ctx,
    { clinicId, doctorId, procedureId, date, startTime, endTime, isTelemedicine, period, maxSlots },
  ) => {
    // Validate procedure exists and is active
    const procedure = await ctx.db.get(procedureId);
    if (!procedure || procedure.deletedAt) {
      throw notFound("Procedure not found");
    }
    if (procedure.clinicId !== clinicId) {
      throw notFound("Procedure not found");
    }
    if (procedure.doctorId !== doctorId) {
      throw notFound("Procedure not found");
    }
    if (!procedure.isActive) {
      throw notFound("Procedure is not active");
    }

    // Derive appointment types from procedure flags
    // If isTelemedicine is provided, filter to only that type
    // Otherwise, include all types the procedure supports
    const supportedTypes: string[] = [];
    if (isTelemedicine !== undefined) {
      // Patient has chosen a specific type - filter to only that type
      if (isTelemedicine) {
        if (procedure.isTelemedicine) {
          supportedTypes.push("telemedicine");
        }
      } else {
        if (procedure.isInPerson) {
          supportedTypes.push("in_person");
        }
      }
    } else {
      // No preference - include all types the procedure supports
      if (procedure.isTelemedicine) {
        supportedTypes.push("telemedicine");
      }
      if (procedure.isInPerson) {
        supportedTypes.push("in_person");
      }
    }

    // Validate that the chosen type is supported by the procedure
    if (isTelemedicine !== undefined && supportedTypes.length === 0) {
      throw notFound(
        isTelemedicine
          ? "Este procedimento não suporta telemedicina"
          : "Este procedimento não suporta atendimento presencial",
      );
    }

    // Use procedure's duration
    const requiredDurationMs = procedure.durationMinutes * 60 * 1000; // Convert to ms
    const slotStepMs = AVAILABILITY_SLOT_STEP_MS;
    const normalizedMaxSlots = normalizeRequestedAvailabilityLimit(maxSlots);
    const rawSlotCollectionLimit = period
      ? Math.max(normalizedMaxSlots * 12, MAX_AVAILABILITY_QUERY_SLOTS)
      : normalizedMaxSlots * 4;

    // Determine mode: date takes precedence over startTime/endTime
    let mode: "days" | "day" | "range";
    let startTimestamp: number;
    let endTimestamp: number;

    if (date) {
      // Mode 2: Day slots
      mode = "day";
      // Parse date string (YYYY-MM-DD) directly without using Date constructor
      // to avoid timezone interpretation issues
      const dateMatch = date.match(/^(\d{4})-(\d{2})-(\d{2})$/);
      if (!dateMatch) {
        throw notFound("Invalid date format. Expected YYYY-MM-DD");
      }
      const [, yearStr, monthStr, dayStr] = dateMatch;
      const year = parseInt(yearStr, 10);
      const month = parseInt(monthStr, 10) - 1; // Convert to 0-indexed
      const day = parseInt(dayStr, 10);

      // Create start of day (00:00) and end of day (23:59:59.999) in Brazil time
      startTimestamp = createBrazilUtcTimestamp(year, month, day, 0, 0);
      const nextDayTimestamp = startTimestamp + DAY_IN_MS;
      endTimestamp = nextDayTimestamp - 1; // End of day
    } else if (startTime && endTime) {
      // Mode 3: Time range
      mode = "range";
      startTimestamp = new Date(startTime).getTime();
      endTimestamp = new Date(endTime).getTime();
      if (isNaN(startTimestamp) || isNaN(endTimestamp)) {
        throw notFound("Invalid time range format");
      }
      if (startTimestamp >= endTimestamp) {
        return []; // Invalid range
      }
    } else {
      // Mode 1: Available days (next 7 days)
      mode = "days";
      const now = Date.now();
      startTimestamp = now;
      endTimestamp = now + 7 * DAY_IN_MS; // 7 days from now
    }

    // Fetch doctor to get workingHours
    const doctor = await ctx.db.get(doctorId);
    const workingHours = doctor?.workingHours;

    // Get existing appointments (only for day/range modes)
    let existingAppointments: any[] = [];
    if (mode !== "days") {
      const overlapWindowStart = Math.max(0, startTimestamp - MAX_APPOINTMENT_DURATION_MS);

      const appointmentsInWindow = await ctx.db
        .query("appointments")
        .withIndex("by_clinic_doctor_date", (q) =>
          q
            .eq("clinicId", clinicId)
            .eq("doctorId", doctorId)
            .gte("startAt", overlapWindowStart)
            .lt("startAt", endTimestamp),
        )
        .filter((q) => q.eq(q.field("deletedAt"), undefined))
        .collect();

      existingAppointments = appointmentsInWindow.filter(
        (appointment) => appointment.status !== "cancelled" && appointment.endAt > startTimestamp,
      );
    }

    // Get external events (only for day/range modes)
    let externalEvents: any[] = [];
    if (mode !== "days") {
      externalEvents = await ctx.db
        .query("externalEvents")
        .withIndex("by_user_time", (q) => q.eq("userId", doctorId).gte("startTime", startTimestamp))
        .filter((q) => q.lt(q.field("startTime"), endTimestamp))
        .collect();
    }

    // Combine all busy intervals (only for day/range modes)
    const busyIntervals =
      mode === "days"
        ? []
        : [
            ...existingAppointments.map((a) => ({ start: a.startAt, end: a.endAt })),
            ...externalEvents
              .filter((e) => !e.transparent)
              .map((e) => ({ start: e.startTime, end: e.endTime })),
          ];

    // Helper function to check if a slot supports the procedure types
    const slotSupportsTypes = (slotTypes: string[] | undefined): boolean => {
      if (!slotTypes || slotTypes.length === 0) {
        // Empty array means slot supports all types (backward compatibility)
        return true;
      }
      // Check if slot types overlap with procedure supported types
      // When isTelemedicine is provided, supportedTypes only contains the chosen type
      return supportedTypes.some((type) => slotTypes.includes(type));
    };

    // Helper function to check if a day has availability
    const dayHasAvailability = (dayStart: number): boolean => {
      const localTime = getBrazilLocalTime(dayStart);
      const dayOfWeek = localTime.dayOfWeek;

      let dayWorkSlots: { start: number; end: number }[] = [];

      if (workingHours && workingHours.length > 0) {
        const config = workingHours.find((w) => w.dayOfWeek === dayOfWeek);
        if (config) {
          for (const s of config.slots) {
            // Filter by procedure supported types
            if (!slotSupportsTypes(s.types)) continue;

            const [startH, startM] = s.start.split(":").map(Number);
            const [endH, endM] = s.end.split(":").map(Number);

            const slotStart = createSlotBoundaryInBrazilTime(dayStart, startH, startM);
            const slotEnd = createSlotBoundaryInBrazilTime(dayStart, endH, endM);

            dayWorkSlots.push({ start: slotStart, end: slotEnd });
          }
        }
      } else if (!workingHours) {
        // Fallback to default 9-18 on weekdays
        if (dayOfWeek !== 0 && dayOfWeek !== 6) {
          const start = createSlotBoundaryInBrazilTime(dayStart, 9, 0);
          const end = createSlotBoundaryInBrazilTime(dayStart, 18, 0);
          dayWorkSlots.push({ start, end });
        }
      }

      if (dayWorkSlots.length === 0) {
        return false;
      }

      // For days mode, we just check if there are work slots (optimization)
      if (mode === "days") {
        return true;
      }

      // For day/range modes, check actual availability
      const now = Date.now();
      for (const workSlot of dayWorkSlots) {
        const businessStart = alignToSlotGrid(
          Math.max(workSlot.start, now),
          workSlot.start,
          slotStepMs,
        );
        const businessEnd = workSlot.end;

        if (businessStart >= businessEnd) continue;

        // Find intervals that overlap with this work slot
        const relevantBusyIntervals = busyIntervals.filter((interval) => {
          return interval.start < businessEnd && interval.end > businessStart;
        });

        relevantBusyIntervals.sort((a, b) => a.start - b.start);

        let slotStart = businessStart;
        let foundSlot = false;

        for (const interval of relevantBusyIntervals) {
          if (slotStart + requiredDurationMs <= interval.start) {
            foundSlot = true;
            break;
          }
          slotStart = alignToSlotGrid(
            Math.max(slotStart, interval.end),
            workSlot.start,
            slotStepMs,
          );
        }

        if (!foundSlot && slotStart + requiredDurationMs <= businessEnd) {
          foundSlot = true;
        }

        if (foundSlot) {
          return true;
        }
      }

      return false;
    };

    // Mode 1: Return available days
    if (mode === "days") {
      const availableDates: string[] = [];
      const now = Date.now();

      for (
        let dayStart = getBrazilDayStartTimestamp(now);
        dayStart < endTimestamp;
        dayStart += DAY_IN_MS
      ) {
        if (dayHasAvailability(dayStart)) {
          const localTime = getBrazilLocalTime(dayStart);
          const monthStr = String(localTime.month + 1).padStart(2, "0");
          const dayStr = String(localTime.day).padStart(2, "0");
          const dateStr = `${localTime.year}-${monthStr}-${dayStr}`;
          availableDates.push(dateStr);
        }
      }

      return { dates: availableDates };
    }

    // Mode 2 & 3: Return available slots
    const availableSlots: Array<{ start: string; end: string }> = [];
    const now = Date.now();

    // Iterate day by day
    for (
      let dayStart = getBrazilDayStartTimestamp(startTimestamp);
      dayStart < endTimestamp && availableSlots.length < rawSlotCollectionLimit;
      dayStart += DAY_IN_MS
    ) {
      const localTime = getBrazilLocalTime(dayStart);
      const dayOfWeek = localTime.dayOfWeek;

      let dayWorkSlots: { start: number; end: number }[] = [];

      if (workingHours && workingHours.length > 0) {
        const config = workingHours.find((w) => w.dayOfWeek === dayOfWeek);
        if (config) {
          for (const s of config.slots) {
            // Filter by procedure supported types
            if (!slotSupportsTypes(s.types)) continue;

            const [startH, startM] = s.start.split(":").map(Number);
            const [endH, endM] = s.end.split(":").map(Number);

            const slotStart = createSlotBoundaryInBrazilTime(dayStart, startH, startM);
            const slotEnd = createSlotBoundaryInBrazilTime(dayStart, endH, endM);

            dayWorkSlots.push({ start: slotStart, end: slotEnd });
          }
        }
      } else if (!workingHours) {
        // Fallback to default 9-18 on weekdays
        if (dayOfWeek !== 0 && dayOfWeek !== 6) {
          const start = createSlotBoundaryInBrazilTime(dayStart, 9, 0);
          const end = createSlotBoundaryInBrazilTime(dayStart, 18, 0);
          dayWorkSlots.push({ start, end });
        }
      }

      // Process each working slot for the day
      for (const workSlot of dayWorkSlots) {
        if (availableSlots.length >= rawSlotCollectionLimit) break;

        const businessStart = alignToSlotGrid(
          Math.max(workSlot.start, now, startTimestamp),
          workSlot.start,
          slotStepMs,
        );
        const businessEnd = Math.min(workSlot.end, endTimestamp);

        if (businessStart >= businessEnd) continue;

        // Find intervals that overlap with this work slot
        const relevantBusyIntervals = busyIntervals.filter((interval) => {
          return interval.start < businessEnd && interval.end > businessStart;
        });

        relevantBusyIntervals.sort((a, b) => a.start - b.start);

        // Generate slots within this work block
        let slotStart = businessStart;

        for (const interval of relevantBusyIntervals) {
          if (availableSlots.length >= rawSlotCollectionLimit) break;

          // If there's a gap before this interval, add slots
          if (slotStart + requiredDurationMs <= interval.start) {
            let currentSlotStart = slotStart;
            while (
              currentSlotStart + requiredDurationMs <= interval.start &&
              availableSlots.length < rawSlotCollectionLimit
            ) {
              if (currentSlotStart >= now) {
                availableSlots.push({
                  start: new Date(currentSlotStart).toISOString(),
                  end: new Date(currentSlotStart + requiredDurationMs).toISOString(),
                });
              }
              currentSlotStart += slotStepMs;
            }
          }
          slotStart = alignToSlotGrid(
            Math.max(slotStart, interval.end),
            workSlot.start,
            slotStepMs,
          );
        }

        // Add slots after the last interval until work slot end
        while (
          slotStart + requiredDurationMs <= businessEnd &&
          availableSlots.length < rawSlotCollectionLimit
        ) {
          if (slotStart >= now) {
            availableSlots.push({
              start: new Date(slotStart).toISOString(),
              end: new Date(slotStart + requiredDurationMs).toISOString(),
            });
          }
          slotStart += slotStepMs;
        }
      }
    }

    // Sort and return
    return limitAvailabilitySlots(
      availableSlots
        .filter((slot) => new Date(slot.start).getTime() >= now)
        .sort((a, b) => new Date(a.start).getTime() - new Date(b.start).getTime()),
      normalizedMaxSlots,
      period,
    );
  },
});

// Mutation to set reschedule status
export const setRescheduleStatus = mutation({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
  },
  handler: async (ctx, { appointmentId, clinicId }) => {
    const currentUser = await getCurrentUser(ctx);
    const userId = currentUser
      ? currentUser.authUserId || (currentUser._id ? String(currentUser._id) : undefined)
      : undefined;

    const appointment = await ctx.db.get(appointmentId);
    if (!appointment || appointment.clinicId !== clinicId || appointment.deletedAt) {
      throw notFound("Consulta não encontrada");
    }

    await ctx.db.patch(appointmentId, {
      rescheduleStatus: "awaiting_response",
      updatedAt: Date.now(),
    });

    // Create audit log
    await ctx.runMutation(internalAny.auditLogs.insert, {
      action: "reschedule_awaiting_response",
      clinicId,
      userId,
      metadata: {
        appointmentId,
        patientId: appointment.patientId,
      },
      createdAt: Date.now(),
    });

    return await ctx.db.get(appointmentId);
  },
});

// Action to send reschedule options via WhatsApp
export const sendRescheduleOptions = action({
  args: {
    patientId: v.id("patients"),
    appointmentId: v.id("appointments"),
    availableSlots: v.array(
      v.object({
        start: v.string(),
        end: v.string(),
      }),
    ),
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const { patientId, appointmentId, availableSlots, clinicId } = args;

    try {
      // Fetch patient details
      const patient = await ctx.runQuery(apiAny.patients.getById, { id: patientId, clinicId });
      if (!patient) {
        throw new Error("Paciente não encontrado");
      }

      // Fetch appointment details
      const appointment = await ctx.runQuery(internalAny.appointments.getByIdInternal, {
        id: appointmentId,
        clinicId,
      });
      if (!appointment) {
        throw new Error("Consulta não encontrada");
      }

      // Format message
      const formattedSlots = availableSlots
        .slice(0, 3) // Top 3 slots
        .map((slot, index) => {
          const start = new Date(slot.start);
          const dateStr = start.toLocaleDateString("pt-BR", {
            day: "2-digit",
            month: "2-digit",
          });
          const timeStr = start.toLocaleTimeString("pt-BR", {
            hour: "2-digit",
            minute: "2-digit",
          });
          return `${index + 1}. ${dateStr} às ${timeStr}`;
        })
        .join("\n");

      // Check if patient has phone
      if (!patient.phone) {
        throw new Error("Paciente não possui telefone cadastrado");
      }

      const clinic = await ctx.runQuery(internalAny.nps.getClinicInternal, { clinicId });
      const template = await getConfiguredReminderMessage(ctx, clinicId, "rescheduleOptions");
      if (!template) {
        return { success: false, error: "Template de reagendamento desativado" };
      }

      const { personalizeMessage } = await import("../mastra/workflows");
      const message = personalizeMessage(template, {
        patient: {
          name: patient.name,
          phone: patient.phone,
          email: patient.email,
          cpf: patient.cpf,
        },
        clinic: {
          name: clinic?.name || clinicId,
          phone: clinic?.phone || "",
          address: clinic?.address || "",
          website: clinic?.website || "",
        },
        appointment: {
          date: appointment.startAt
            ? new Date(appointment.startAt).toLocaleDateString("pt-BR")
            : "",
          time: appointment.startAt
            ? new Date(appointment.startAt).toLocaleTimeString("pt-BR", {
                hour: "2-digit",
                minute: "2-digit",
              })
            : "",
          doctor: appointment.doctor || "",
          procedure: appointment.procedure || "consulta",
        },
        doctor: {
          name: appointment.doctor || "",
        },
        reschedule: {
          options: formattedSlots,
        },
      });

      // 3. Find existing chat or create new one
      const existingChat = await ctx.runQuery(internalAny.whatsappQueries.findChatByPhone, {
        clinicId,
        phone: patient.phone,
      });

      let chatId;
      if (!existingChat) {
        const patientPhoneFormatted = patient.phone.startsWith("+")
          ? patient.phone.substring(1)
          : patient.phone;

        chatId = await ctx.runMutation(internalAny.whatsappQueries.createChatInternal, {
          clinicId,
          patientId,
          whatsappChatId: `55${patientPhoneFormatted}@s.whatsapp.net`,
          title: patient.name,
        });
      } else {
        chatId = existingChat._id;
      }

      // Set reschedule status
      await ctx.runMutation(apiAny.appointments.setRescheduleStatus, {
        appointmentId,
        clinicId,
      });

      // Send message
      await ctx.runMutation(internalAny.whatsappQueries.sendMessageAction, {
        chatId,
        text: message,
        tracking: {
          clinicId,
          appointmentId,
          automationKind: "rescheduleOptions",
        },
      });

      return { success: true };
    } catch (error: any) {
      console.error("Failed to send reschedule options:", error);
      // Log error but don't fail action
      return { success: false, error: error.message };
    }
  },
});

/**
 * Send a WhatsApp message confirming the rescheduled appointment
 */
async function sendRescheduleConfirmationImpl(ctx: any, args: any) {
  const { appointmentId, clinicId, newStartAt, isTelemedicine } = args;

  try {
    const appointment = await ctx.runQuery(internalAny.appointments.getByIdInternal, {
      id: appointmentId,
      clinicId,
    });
    if (!appointment) {
      throw new Error("Consulta não encontrada");
    }

    const patient = await ctx.runQuery(apiAny.patients.getById, {
      id: appointment.patientId,
      clinicId,
    });
    if (!patient) {
      throw new Error("Paciente não encontrado");
    }

    if (!patient.phone) {
      console.warn(`[sendRescheduleConfirmation] Patient ${patient.name} has no phone`);
      return { success: false, error: "Paciente não possui telefone cadastrado" };
    }

    const clinic = await ctx.runQuery(internalAny.nps.getClinicInternal, { clinicId });

    const newDate = new Date(newStartAt);
    const dateStr = newDate.toLocaleDateString("pt-BR", {
      weekday: "long",
      day: "2-digit",
      month: "long",
      timeZone: appointment.timeZone || "America/Sao_Paulo",
    });
    const timeStr = newDate.toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: appointment.timeZone || "America/Sao_Paulo",
    });

    const patientName = patient.name?.split(" ")[0] || "paciente";
    const appointmentType = isTelemedicine ? "Teleconsulta" : "Consulta presencial";
    const procedureName = appointment.procedure || "consulta";
    const now = new Date();
    const template = await getConfiguredReminderMessage(ctx, clinicId, "rescheduleConfirmation");
    if (!template) {
      return { success: false, error: "Template de reagendamento desativado" };
    }

    const { personalizeMessage } = await import("../mastra/workflows");
    const message = personalizeMessage(template, {
      patient: {
        name: patient.name,
        phone: patient.phone,
        email: patient.email,
        cpf: patient.cpf,
      },
      clinic: {
        name: clinic?.name || clinicId,
        phone: clinic?.phone || "",
        address: clinic?.address || "",
        website: clinic?.website || "",
      },
      appointment: {
        date: dateStr,
        time: timeStr,
        doctor: appointment.doctor || "",
        procedure: procedureName,
        type: appointmentType,
        isTelemedicine: !!isTelemedicine,
      },
      doctor: {
        name: appointment.doctor || "",
      },
      date: {
        today: now.toLocaleDateString("pt-BR"),
        now: now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
        weekday: now.toLocaleDateString("pt-BR", { weekday: "long" }),
      },
    });

    const phone = patient.phone.replace(/\D/g, "");
    const formattedPhone = phone.startsWith("55") ? phone : `55${phone}`;
    const whatsappChatId = `${formattedPhone}@s.whatsapp.net`;

    const chat = await ctx.runQuery(internalAny.whatsappQueries.findChatByPhone, {
      clinicId,
      phone,
    });

    const chatId = chat
      ? chat._id
      : await ctx.runMutation(internalAny.whatsappQueries.createChatInternal, {
          clinicId,
          patientId: appointment.patientId,
          whatsappChatId,
          title: patient.name,
        });

    await ctx.runMutation(internalAny.whatsappQueries.sendMessageAction, {
      chatId,
      text: message,
      tracking: {
        clinicId,
        appointmentId,
        automationKind: "rescheduleConfirmation",
      },
    });

    console.log(`[sendRescheduleConfirmation] Sent confirmation to ${patientName}`);
    return { success: true };
  } catch (error: any) {
    console.error("[sendRescheduleConfirmation] Failed:", error);
    return { success: false, error: error.message };
  }
}

export const sendRescheduleConfirmationInternal = internalAction({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
    newStartAt: v.number(),
    isTelemedicine: v.optional(v.boolean()),
  },
  handler: sendRescheduleConfirmationImpl,
});

export const sendRescheduleConfirmation = action({
  args: {
    appointmentId: v.id("appointments"),
    clinicId: v.string(),
    newStartAt: v.number(),
    isTelemedicine: v.optional(v.boolean()),
  },
  handler: sendRescheduleConfirmationImpl,
});

export const getSpecialtyAvailability = query({
  args: {
    clinicId: v.string(),
    specialty: v.string(),
    startDate: v.string(),
    endDate: v.optional(v.string()),
    slotDuration: v.optional(v.number()),
    period: v.optional(v.union(v.literal("morning"), v.literal("afternoon"), v.literal("night"))),
    maxSlots: v.optional(v.number()),
  },
  handler: async (
    ctx,
    { clinicId, specialty, startDate, endDate, slotDuration, period, maxSlots },
  ) => {
    const slotStepMs = slotDuration || AVAILABILITY_SLOT_STEP_MS;
    const requiredDurationMs = slotStepMs;
    const normalizedMaxSlots = normalizeRequestedAvailabilityLimit(maxSlots);

    const endTimestamp = endDate
      ? new Date(endDate).getTime()
      : new Date(startDate).getTime() + 7 * DAY_IN_MS;

    const startTimestamp = new Date(startDate).getTime();

    const allDoctors = await ctx.db
      .query("users")
      .withIndex("by_clinic_role", (q) => q.eq("clinicId", clinicId).eq("role", "doctor"))
      .filter((q) => q.eq(q.field("deletedAt"), undefined))
      .collect();

    const doctors = allDoctors.filter(
      (doc) => doc.specialties && doc.specialties.some((s) => matchesSpecialty(s, specialty)),
    );

    if (doctors.length === 0) {
      return [];
    }

    const allSlots: Array<{ start: string; end: string; doctorId: string; doctorName: string }> =
      [];

    // 2. Calculate slots for each doctor
    for (const doctor of doctors) {
      const workingHours = doctor.workingHours;
      if (!workingHours || workingHours.length === 0) continue;

      // Get doctor's busy intervals
      const existingAppointments = await ctx.db
        .query("appointments")
        .withIndex("by_clinic_doctor_date", (q) =>
          q
            .eq("clinicId", clinicId)
            .eq("doctorId", doctor._id)
            .gte("startAt", Math.max(0, startTimestamp - MAX_APPOINTMENT_DURATION_MS))
            .lt("startAt", endTimestamp),
        )
        .filter((q) => q.eq(q.field("deletedAt"), undefined))
        .collect();

      const relevantAppointments = existingAppointments.filter(
        (appointment) => appointment.status !== "cancelled" && appointment.endAt > startTimestamp,
      );

      const externalEvents = await ctx.db
        .query("externalEvents")
        .withIndex("by_user_time", (q) =>
          q.eq("userId", doctor._id).gte("startTime", startTimestamp),
        )
        .filter((q) => q.lt(q.field("startTime"), endTimestamp))
        .collect();

      const busyIntervals = [
        ...relevantAppointments.map((a) => ({ start: a.startAt, end: a.endAt })),
        ...externalEvents
          .filter((e) => !e.transparent)
          .map((e) => ({ start: e.startTime, end: e.endTime })),
      ];

      // Iterate days
      for (
        let dayStart = getBrazilDayStartTimestamp(startTimestamp);
        dayStart < endTimestamp;
        dayStart += DAY_IN_MS
      ) {
        const localTime = getBrazilLocalTime(dayStart);
        const dayOfWeek = localTime.dayOfWeek;

        const config = workingHours.find((w) => w.dayOfWeek === dayOfWeek);
        if (!config) continue;

        for (const s of config.slots) {
          const [startH, startM] = s.start.split(":").map(Number);
          const [endH, endM] = s.end.split(":").map(Number);

          const slotStart = createSlotBoundaryInBrazilTime(dayStart, startH, startM);
          const slotEnd = createSlotBoundaryInBrazilTime(dayStart, endH, endM);

          let currentStart = alignToSlotGrid(
            Math.max(slotStart, startTimestamp, Date.now()),
            slotStart,
            slotStepMs,
          );
          const currentEnd = Math.min(slotEnd, endTimestamp);

          if (currentStart >= currentEnd) {
            continue;
          }

          // Find overlapping busy intervals
          const relevantBusy = busyIntervals
            .filter((i) => i.start < currentEnd && i.end > currentStart)
            .sort((a, b) => a.start - b.start);

          let searchStart = currentStart;

          for (const interval of relevantBusy) {
            if (searchStart + requiredDurationMs <= interval.start) {
              let tempStart = searchStart;
              while (tempStart + requiredDurationMs <= interval.start) {
                allSlots.push({
                  start: new Date(tempStart).toISOString(),
                  end: new Date(tempStart + requiredDurationMs).toISOString(),
                  doctorId: doctor._id,
                  doctorName: doctor.name,
                });
                tempStart += slotStepMs;
              }
            }
            searchStart = alignToSlotGrid(
              Math.max(searchStart, interval.end),
              slotStart,
              slotStepMs,
            );
          }

          while (searchStart + requiredDurationMs <= currentEnd) {
            allSlots.push({
              start: new Date(searchStart).toISOString(),
              end: new Date(searchStart + requiredDurationMs).toISOString(),
              doctorId: doctor._id,
              doctorName: doctor.name,
            });
            searchStart += slotStepMs;
          }
        }
      }
    }

    // Sort combined slots
    return limitAvailabilitySlots(
      allSlots
        .filter((slot) => new Date(slot.start).getTime() >= Date.now())
        .sort((a, b) => new Date(a.start).getTime() - new Date(b.start).getTime()),
      normalizedMaxSlots,
      period,
    );
  },
});

export const getDoctorAvailability = query({
  args: {
    clinicId: v.string(),
    doctorId: v.id("users"),
    startDate: v.string(), // ISO date string
    endDate: v.optional(v.string()), // ISO date string
    procedureId: v.optional(v.id("procedures")),
    slotDuration: v.optional(v.number()), // Default 15 minutes
    period: v.optional(v.union(v.literal("morning"), v.literal("afternoon"), v.literal("night"))),
    maxSlots: v.optional(v.number()),
  },
  handler: async (
    ctx,
    { clinicId, doctorId, startDate, endDate, procedureId, slotDuration, period, maxSlots },
  ) => {
    const slotStepMs = slotDuration || AVAILABILITY_SLOT_STEP_MS;
    let requiredDurationMs = slotStepMs;
    const normalizedMaxSlots = normalizeRequestedAvailabilityLimit(maxSlots);

    if (procedureId) {
      const procedure = await ctx.db.get(procedureId);
      if (
        !procedure ||
        procedure.clinicId !== clinicId ||
        procedure.doctorId !== doctorId ||
        procedure.deletedAt ||
        !procedure.isActive
      ) {
        return [];
      }
      requiredDurationMs = procedure.durationMinutes * 60 * 1000;
    }

    // Set default end date to 7 days from start
    const endTimestamp = endDate
      ? new Date(endDate).getTime()
      : new Date(startDate).getTime() + 7 * DAY_IN_MS;

    const startTimestamp = new Date(startDate).getTime();

    // 1. Get doctor
    const doctor = await ctx.db.get(doctorId);
    if (!doctor || doctor.clinicId !== clinicId || doctor.role !== "doctor") {
      return [];
    }

    const workingHours = doctor.workingHours;
    if (!workingHours || workingHours.length === 0) return [];

    const slots: Array<{ start: string; end: string; doctorId: string; doctorName: string }> = [];

    // Get doctor's busy intervals
    const appointmentsInWindow = await ctx.db
      .query("appointments")
      .withIndex("by_clinic_doctor_date", (q) =>
        q
          .eq("clinicId", clinicId)
          .eq("doctorId", doctor._id)
          .gte("startAt", Math.max(0, startTimestamp - MAX_APPOINTMENT_DURATION_MS))
          .lt("startAt", endTimestamp),
      )
      .filter((q) => q.eq(q.field("deletedAt"), undefined))
      .collect();

    const existingAppointments = appointmentsInWindow.filter(
      (appointment) => appointment.status !== "cancelled" && appointment.endAt > startTimestamp,
    );

    const externalEvents = await ctx.db
      .query("externalEvents")
      .withIndex("by_user_time", (q) => q.eq("userId", doctor._id).gte("startTime", startTimestamp))
      .filter((q) => q.lt(q.field("startTime"), endTimestamp))
      .collect();

    const busyIntervals = [
      ...existingAppointments.map((a) => ({ start: a.startAt, end: a.endAt })),
      ...externalEvents
        .filter((e) => !e.transparent)
        .map((e) => ({ start: e.startTime, end: e.endTime })),
    ];

    // Iterate days
    for (
      let dayStart = getBrazilDayStartTimestamp(startTimestamp);
      dayStart < endTimestamp;
      dayStart += DAY_IN_MS
    ) {
      const localTime = getBrazilLocalTime(dayStart);
      const dayOfWeek = localTime.dayOfWeek;

      const config = workingHours.find((w) => w.dayOfWeek === dayOfWeek);
      if (!config) continue;

      for (const s of config.slots) {
        const [startH, startM] = s.start.split(":").map(Number);
        const [endH, endM] = s.end.split(":").map(Number);

        const slotStart = createSlotBoundaryInBrazilTime(dayStart, startH, startM);
        const slotEnd = createSlotBoundaryInBrazilTime(dayStart, endH, endM);

        let currentStart = alignToSlotGrid(
          Math.max(slotStart, startTimestamp, Date.now()),
          slotStart,
          slotStepMs,
        );
        const currentEnd = Math.min(slotEnd, endTimestamp);

        if (currentStart >= currentEnd) {
          continue;
        }

        // Find overlapping busy intervals
        const relevantBusy = busyIntervals
          .filter((i) => i.start < currentEnd && i.end > currentStart)
          .sort((a, b) => a.start - b.start);

        let searchStart = currentStart;

        for (const interval of relevantBusy) {
          if (searchStart + requiredDurationMs <= interval.start) {
            let tempStart = searchStart;
            while (tempStart + requiredDurationMs <= interval.start) {
              slots.push({
                start: new Date(tempStart).toISOString(),
                end: new Date(tempStart + requiredDurationMs).toISOString(),
                doctorId: doctor._id,
                doctorName: doctor.name,
              });
              tempStart += slotStepMs;
            }
          }
          searchStart = alignToSlotGrid(Math.max(searchStart, interval.end), slotStart, slotStepMs);
        }

        while (searchStart + requiredDurationMs <= currentEnd) {
          slots.push({
            start: new Date(searchStart).toISOString(),
            end: new Date(searchStart + requiredDurationMs).toISOString(),
            doctorId: doctor._id,
            doctorName: doctor.name,
          });
          searchStart += slotStepMs;
        }
      }
    }

    return limitAvailabilitySlots(
      slots
        .filter((slot) => new Date(slot.start).getTime() >= Date.now())
        .sort((a, b) => new Date(a.start).getTime() - new Date(b.start).getTime()),
      normalizedMaxSlots,
      period,
    );
  },
});
