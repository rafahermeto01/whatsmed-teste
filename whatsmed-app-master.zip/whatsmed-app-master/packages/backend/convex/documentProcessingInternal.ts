import { v } from "convex/values";

import { internalQuery } from "./_generated/server";

/**
 * Internal queries for document processing
 */

/**
 * Get documents for a patient
 * Returns all documents/files sent by patient
 */
export const getPatientDocuments = internalQuery({
  args: {
    clinicId: v.string(),
    chatId: v.id("chats"),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const messages = await ctx.db
      .query("messages")
      .withIndex("by_clinic_chat_sent", (q: any) =>
        q.eq("clinicId", args.clinicId).eq("chatId", args.chatId),
      )
      .filter((q: any) => q.eq("direction", "in"))
      .filter((q: any) => q.neq("mediaStorageId", undefined))
      .take(args.limit || 100);

    // Get patient info for each message's patient
    const enrichedDocs = [];
    for (const msg of messages) {
      if (!msg.patientId) continue;

      const patient = await ctx.db.get(msg.patientId);
      if (patient) {
        enrichedDocs.push({
          messageId: msg._id,
          sentAt: msg.sentAt,
          mediaType: msg.mediaType,
          aiAnalysis: msg.aiAnalysis,
          aiAnalyzedAt: msg.aiAnalyzedAt,
          patientName: patient.name,
          patientPhone: patient.phone,
        });
      }
    }

    return enrichedDocs;
  },
});

/**
 * Get message AI analysis (internal query)
 * Retrieves the AI analysis stored on a message
 */
export const getMessageAiAnalysis = internalQuery({
  args: {
    messageId: v.id("messages"),
  },
  handler: async (ctx, args) => {
    const message = await ctx.db.get(args.messageId);

    return {
      aiAnalysis: message?.aiAnalysis,
      aiAnalyzedAt: message?.aiAnalyzedAt,
      aiError: message?.aiError,
      hasAnalysis: !!message?.aiAnalysis,
    };
  },
});
