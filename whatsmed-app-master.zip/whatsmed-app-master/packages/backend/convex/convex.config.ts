import betterAuth from "@convex-dev/better-auth/convex.config";
import { defineApp } from "convex/server";

// Create app configuration
// External dependencies are configured in convex.json
const app = defineApp();

app.use(betterAuth);

export default app;
