import { cronJobs } from "convex/server";

import { internal } from "./_generated/api";

const internalAny = internal as any;
const crons = cronJobs();

// Existing cron jobs
crons.cron("cleanupRateLimits", "0 * * * *", internalAny.rateLimit.cleanup);

// Automation cron jobs
crons.cron(
  "checkCampaigns",
  "*/30 * * * *",
  internalAny.automationActions.scheduleCampaignExecution,
); // Every 30 minutes
crons.cron("checkBirthdays", "0 9 * * *", internalAny.automationActions.checkBirthdayCampaigns); // Daily at 9 AM
// WhatsApp timeout monitoring
crons.cron("timeoutCron", "0 * * * *", internalAny.whatsapp.timeout.checkConversationTimeouts); // Every hour
// NPS cron jobs
crons.cron("cleanupOldNpsSurveys", "0 2 * * *", internalAny.nps.cleanupOldSurveys); // Daily at 2 AM
// Documents cron jobs
crons.cron("cleanupExpiredDocuments", "0 3 * * *", internalAny.documents.cleanupExpiredDocuments); // Daily at 3 AM

// Google Calendar Sync
crons.interval(
  "syncGoogleCalendars",
  { minutes: 10 },
  internal.googleCalendarActions.syncAllCalendars,
);

// Billing cycle reset (daily at 4 AM)
crons.cron(
  "checkAndResetBillingCycles",
  "0 4 * * *",
  internal.conversationCredits.checkAndResetCycles,
);

export default crons;
