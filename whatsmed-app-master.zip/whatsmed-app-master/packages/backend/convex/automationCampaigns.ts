import { v } from "convex/values";

import { internalQuery, internalMutation } from "./_generated/server";

/**
 * Get campaign sent log (for idempotency check)
 */
export const getCampaignSentLog = internalQuery({
  args: {
    campaignId: v.id("campaigns"),
    appointmentId: v.optional(v.id("appointments")),
    patientId: v.optional(v.id("patients")),
  },
  handler: async (ctx, args) => {
    if (args.appointmentId) {
      return await ctx.db
        .query("campaignExecutions")
        .withIndex("by_campaign_appointment", (q: any) =>
          q.eq("campaignId", args.campaignId).eq("appointmentId", args.appointmentId),
        )
        .first();
    }

    if (args.patientId) {
      // For birthday campaigns, we check if sent in the last year
      const logs = await ctx.db
        .query("campaignExecutions")
        .withIndex("by_campaign_patient", (q: any) =>
          q.eq("campaignId", args.campaignId).eq("patientId", args.patientId),
        )
        .order("desc")
        .first();

      if (!logs) return null;

      // If sent within last 365 days, consider sent (to avoid re-sending same year)
      const now = Date.now();
      if (now - logs.sentAt < 365 * 24 * 60 * 60 * 1000) {
        return logs;
      }
      return null;
    }

    return null;
  },
});

/**
 * List active campaigns for a clinic
 */
export const listActiveCampaigns = internalQuery({
  args: {
    clinicId: v.string(),
  },
  handler: async (ctx, args) => {
    const campaigns = await ctx.db
      .query("campaigns")
      .withIndex("by_clinic_status", (q: any) =>
        q.eq("clinicId", args.clinicId).eq("status", "active"),
      )
      .collect();
    return campaigns;
  },
});

/**
 * Get all clinics that have active campaigns
 */
export const getAllActiveCampaignClinics = internalQuery({
  args: {},
  handler: async (ctx) => {
    const campaigns = await ctx.db
      .query("campaigns")
      .filter((q: any) => q.eq(q.field("status"), "active"))
      .collect();

    // Extract unique clinicIds
    const clinicIds = [...new Set(campaigns.map((c) => c.clinicId))];
    return clinicIds;
  },
});

/**
 * Log campaign execution
 */
export const logCampaignExecution = internalMutation({
  args: {
    campaignId: v.id("campaigns"),
    clinicId: v.string(),
    appointmentId: v.optional(v.id("appointments")),
    patientId: v.id("patients"),
    stepOrder: v.number(),
    channel: v.string(),
    sentAt: v.number(),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("campaignExecutions", {
      campaignId: args.campaignId,
      clinicId: args.clinicId,
      patientId: args.patientId,
      appointmentId: args.appointmentId,
      stepOrder: args.stepOrder,
      channel: args.channel,
      sentAt: args.sentAt,
      status: "sent",
    });
    return { logged: true };
  },
});

/**
 * Increment campaign trigger count
 */
export const incrementTriggerCount = internalMutation({
  args: {
    campaignId: v.id("campaigns"),
  },
  handler: async (ctx, args) => {
    const campaign = await ctx.db.get(args.campaignId);

    if (!campaign) {
      throw new Error("Campaign not found");
    }

    const updated = await ctx.db.patch(args.campaignId, {
      triggerCount: campaign.triggerCount + 1,
    });

    return updated;
  },
});
