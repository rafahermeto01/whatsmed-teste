import { execSync } from "child_process";

const args = JSON.stringify({
  clinicId: "promptfoo-eval-clinic-sf-01",
  message: "Ola",
}).replace(/"/g, '\\"');

console.log("Running with args:", args);

try {
  // Push code first with convex dev --once
  console.log("Pushing code...");
  execSync(`bunx convex dev --once --typecheck disable`, {
    cwd: process.cwd(),
    encoding: "utf-8",
    timeout: 120000,
  });
  console.log("Code pushed. Running test...");

  const result = execSync(`bunx convex run internal.automationAi.generateAiResponse "${args}"`, {
    cwd: process.cwd(),
    encoding: "utf-8",
    timeout: 180000,
  });
  console.log(result);
} catch (e) {
  console.error("Error:", e.message);
  console.error("stdout:", e.stdout);
  console.error("stderr:", e.stderr);
}
