import { spawnSync } from "node:child_process";

function run(command, args) {
  const result = spawnSync(command, args, {
    cwd: process.cwd(),
    stdio: "inherit",
    shell: process.platform === "win32",
    env: process.env,
  });

  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}

const bunx = "bunx";
const npx = "npx";
const skipPush = process.argv.includes("--no-push");

if (!skipPush) {
  run(bunx, ["convex", "dev", "--once", "--typecheck", "disable"]);
}
run(npx, ["promptfoo@0.121.3", "eval", "-c", "promptfoo/live-evals.cjs"]);
