import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "node",
    globals: true,
    coverage: {
      provider: "v8",
      reporter: ["text", "json", "html"],
      exclude: [
        "node_modules/",
        "**/_generated/**",
        "**/*.test.ts",
        "tests/",
        "convex.config.ts",
        "tsconfig.json",
      ],
      thresholds: {
        lines: 70,
        functions: 70,
        branches: 60,
        statements: 70,
      },
    },
    setupFiles: ["./tests/setup.ts"],
    reporters: ["verbose", "html"],
    include: ["**/*.test.ts"],
    poolOptions: {
      threads: {
        singleThread: true,
      },
    },
  },
});
