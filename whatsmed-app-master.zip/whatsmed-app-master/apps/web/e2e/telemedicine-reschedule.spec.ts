import { expect, test } from "@playwright/test";
import { ConvexHttpClient } from "convex/browser";
import fs from "node:fs";
import path from "node:path";

import { api } from "../../../packages/backend/convex/_generated/api.js";

function readEnvValue(name: string) {
  const envPath = path.resolve(process.cwd(), ".env");
  const content = fs.readFileSync(envPath, "utf8");
  const match = content.match(new RegExp(`^${name}=(.*)$`, "m"));
  return match?.[1]?.trim();
}

const convexUrl = process.env.VITE_CONVEX_URL || readEnvValue("VITE_CONVEX_URL");
const apiAny = api as any;

async function ensureTestUser(email: string, password: string) {
  const response = await fetch("http://127.0.0.1:3001/api/auth/sign-up/email", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      email,
      password,
      name: "Playwright E2E",
    }),
  });

  if (response.ok) {
    return;
  }

  const body = await response.text();
  if (/exists|already|duplicate/i.test(body)) {
    return;
  }

  throw new Error(`Unable to create test user: ${response.status} ${body}`);
}

test("manual telemedicine reschedule updates the appointment through the UI", async ({
  page,
}: {
  page: any;
}) => {
  const suffix = `${Date.now()}${Math.floor(Math.random() * 1000)}`;
  const clinicId = "clinic-demo";
  const email = `playwright.${suffix}@example.test`;
  const password = `Pass!${suffix}Aa`;

  if (!convexUrl) {
    throw new Error("Missing VITE_CONVEX_URL for Playwright test");
  }

  const client = new ConvexHttpClient(convexUrl);
  const seeded = await client.mutation(apiAny.fixtures.seedTelemedicineRescheduleScenario, {
    clinicId,
    suffix,
  });

  await ensureTestUser(email, password);

  await page.goto("/login");
  await page.getByLabel("Endereço de E-mail").fill(email);
  await page.getByLabel("Senha").fill(password);
  await page.getByRole("button", { name: "Entrar" }).click();

  await page.waitForURL((url: any) => !url.pathname.startsWith("/login"), { timeout: 15_000 });
  await page.goto("/appointments");

  await page.getByText("Lista").click();
  const appointmentCard = page
    .locator('[data-slot="card"]')
    .filter({ hasText: seeded.patientName })
    .first();

  await expect(appointmentCard).toContainText(seeded.patientName);
  await appointmentCard.getByRole("button", { name: "Detalhes" }).click();

  const detailsDialog = page.getByRole("dialog").first();
  await detailsDialog.getByRole("button", { name: "Reagendar" }).click();

  const rescheduleDialog = page.getByRole("dialog").last();
  await rescheduleDialog.getByRole("button", { name: /doctor e2e/i }).click();
  await rescheduleDialog
    .getByRole("button", { name: new RegExp(seeded.targetDateDisplay) })
    .click();
  await rescheduleDialog.getByRole("button", { name: seeded.targetTime }).click();
  await rescheduleDialog.getByRole("button", { name: "Confirmar Reagendamento" }).click();

  await expect(page.getByText(/consulta reagendada com sucesso/i)).toBeVisible();

  await page.goto("/appointments");
  await page.getByText("Lista").click();
  const updatedCard = page
    .locator('[data-slot="card"]')
    .filter({ hasText: seeded.patientName })
    .first();
  await expect(updatedCard).toContainText(seeded.targetTime);
});
