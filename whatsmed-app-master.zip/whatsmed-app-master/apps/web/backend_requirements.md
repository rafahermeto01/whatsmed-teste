# Backend Integration Requirements

Organized by feature/module. Includes endpoints, request/response formats, authentication, error handling, and validation rules. Comments in code are marked as `backend-required-action` at call sites.

## Tenancy & Clinic Context

- Multi-tenant: every record is scoped by `clinicId`; no cross-clinic access.
- Users belong to a clinic; a clinic can have many users. RBAC (admin/staff/viewer) is evaluated within clinic context.
- Access tokens must carry `clinicId`; all queries/mutations enforce `clinicId` filtering.
- Uniqueness is per clinic (patient phone/email, API key prefix+clinic, payment methods, webhooks, uploads quota, audit logs).
- Errors: deny cross-clinic access with `403 { code: "FORBIDDEN" }` or `404` when appropriate to avoid enumeration.

## Auth

- Endpoints
  - POST `/api/auth/login`
    - Request: `{ email: string, password: string }`
    - Response: `{ token: string, user: { id: string, email: string } }`
    - Auth: none
    - Errors: `401 { code: "INVALID_CREDENTIALS", message }`, `422 { code: "VALIDATION_ERROR", fieldErrors }`
  - POST `/api/auth/reset-password`
    - Request: `{ newPassword: string }`
    - Auth: reset token via header `Authorization: Bearer <token>` or cookie
    - Response: `204 No Content`
    - Errors: `400`, `401`, `422`
- Notes: Full auth already implemented via Better-Auth + Convex at `packages/backend/convex/auth.ts` and `apps/web/src/routes/api/auth/$.ts`

## Patients

- Endpoints
  - GET `/api/patients?search=&status=` → `{ items: Patient[], page: number, total: number }`
    - Query: `search` (name or phone), `status` (active|inactive), `limit`, `cursor`
    - Location: `apps/web/src/routes/patients.tsx` lines 19, 25
  - POST `/api/patients` → create
    - Request: `{ name: string, phone: string, email?: string, status?: "active" | "inactive" }`
    - Location: `apps/web/src/routes/patients.tsx` line 38, `apps/web/src/components/AddPatientModal.tsx`
  - PUT `/api/patients/:id` → update
    - Request: same as POST
    - Location: `apps/web/src/routes/patients.tsx` line 38, `apps/web/src/components/AddPatientModal.tsx`
  - DELETE `/api/patients/:id` → delete
    - Location: `apps/web/src/routes/patients.tsx` line 109
  - POST `/api/patients/import` (multipart/form-data CSV)
    - Location: `apps/web/src/components/BulkImportModal.tsx`
    - Response: `{ success: boolean, imported: number, errors: string[] }`
- Models
  - Patient: `{ id: string, clinicId: string, name: string, phone: string, email?: string, nextAppointment?: string, status: "active" | "inactive", createdAt: string, updatedAt: string }`
- Validation
  - `phone`: E.164 or country-specific; normalize and store canonical
  - `name`: required, min 2 chars
  - `email`: RFC 5322 compliant if provided
- Errors: `404 { code: "NOT_FOUND" }`, `409 { code: "DUPLICATE" }`
- Notes: Patient listing with search/filtering, bulk CSV import support needed
- Scope all patient operations to the current `clinicId`; enforce per-clinic uniqueness.

## WhatsApp Messaging

- Endpoints
  - GET `/api/whatsapp/chats` → chat list with unread counts
    - Query: `status` (open|closed), `search`
    - Response: `{ items: Chat[], total: number }`
    - Location: `apps/web/src/routes/whatsapp.tsx` lines 52-58
  - GET `/api/whatsapp/chats/:id/messages` → messages
    - Query: `limit`, `cursor`
    - Response: `{ items: Message[], cursor?: string }`
    - Location: `apps/web/src/routes/whatsapp.tsx` lines 60-66
  - POST `/api/whatsapp/messages` `{ chatId, text, attachments?: string[] }` → send
    - Location: `apps/web/src/routes/whatsapp.tsx` line 70-73
  - POST `/api/whatsapp/chats/:id/resolve` → mark resolved
    - Location: `apps/web/src/routes/whatsapp.tsx` (chat resolution action)
  - GET `/api/whatsapp/status` → connection status
    - Response: `{ connected: boolean, lastSync?: string, qrCode?: string }`
- Models
  - Chat: `{ id: string, clinicId: string, name: string, phone: string, lastMessage?: string, lastMessageTime?: string, status: "open" | "closed", unread: number, avatar?: string, online?: boolean, patientId?: string }`
  - Message: `{ id: string, clinicId: string, chatId: string, text: string, sent: boolean, timestamp: string, status: "sent" | "delivered" | "read", attachments?: string[] }`
- Auth: bearer token required
- Errors: `429` rate limiting, `502` upstream provider errors
- Notes: Integration with Evolution API, requires webhook handler for incoming messages
- Scope chats/messages/status by `clinicId`; webhook handler must resolve clinic and reject cross-clinic access.

## Appointments

- Endpoints
  - GET `/api/appointments?date=YYYY-MM-DD&patientId=&status=` → list
    - Location: `apps/web/src/routes/appointments.tsx` lines 26-33
    - Response: `{ items: Appointment[], total: number }`
  - GET `/api/appointments/:id` → get details
    - Response: `Appointment`
    - Location: `apps/web/src/routes/appointments.tsx` line 28
  - POST `/api/appointments` → schedule
    - Request: `{ patientId: string, date: string, time: string, doctorId?: string, procedureType?: string, notes?: string }`
    - Location: `apps/web/src/components/AppointmentDetailsModal.tsx`
  - PATCH `/api/appointments/:id` → reschedule/cancel/update status
    - Request: `{ date?: string, time?: string, status?: "confirmed" | "pending" | "cancelled" | "completed", notes?: string }`
    - Location: `apps/web/src/routes/appointments.tsx` lines 267-275
- Models
  - Appointment: `{ id: string, clinicId: string, patientId: string, patientName: string, doctorId?: string, doctorName?: string, date: string, time: string, procedureType?: string, status: "confirmed" | "pending" | "cancelled" | "completed", notes?: string, createdAt: string, updatedAt: string }`
- Validation
  - Date and time in ISO 8601 format
  - Timezone handling explicit (store in UTC, display in clinic timezone)
  - Date cannot be in the past
  - Patient must exist
- Notes: Calendar views for month/week/day, timeline view, appointment status tracking
- Scope all appointment operations to the current `clinicId`; patient lookups must match the same clinic.

## Billing & Wallet

- Endpoints
  - GET `/api/billing/wallet` → `{ balance: number, currency: string, transactions: Transaction[] }`
    - Location: `apps/web/src/routes/billing.tsx` lines 23-58
  - POST `/api/billing/wallet/topup` `{ amount: number, paymentMethodId?: string }` → top up
    - Location: `apps/web/src/components/billing/AddFundsModal.tsx`
    - Response: `{ success: boolean, transactionId: string, newBalance: number }`
  - GET `/api/billing/cards` → list payment methods
    - Response: `{ items: PaymentMethod[] }`
    - Location: `apps/web/src/routes/billing.tsx` lines 131-148
  - POST `/api/billing/cards` → add payment method
    - Request: `{ type: "card", cardNumber: string, expiryMonth: number, expiryYear: number, cvv: string, holderName: string }`
    - Response: `{ id: string, last4: string, brand: string, isDefault: boolean }`
  - PUT `/api/billing/cards/:id` → update card (set as default)
    - Location: `apps/web/src/components/billing/ManageCardsModal.tsx`
  - DELETE `/api/billing/cards/:id` → remove card
  - GET `/api/billing/auto-recharge` → get settings
    - Response: `{ enabled: boolean, threshold: number, amount: number }`
  - PUT `/api/billing/auto-recharge` → update settings
    - Request: `{ enabled: boolean, threshold: number, amount: number }`
    - Location: `apps/web/src/components/billing/AutoRechargeModal.tsx`
  - GET `/api/billing/transactions` → transaction history
    - Query: `limit`, `cursor`, `type`
    - Response: `{ items: Transaction[], cursor?: string }`
- Models
  - Transaction: `{ id: string, clinicId: string, date: string, description: string, amount: number, type: 'debit' | 'credit', status: 'completed' | 'pending' | 'failed' }`
  - PaymentMethod: `{ id: string, clinicId: string, type: string, last4: string, brand: string, expiryMonth: number, expiryYear: number, isDefault: boolean }`
- Auth: bearer token required
- Integration: Asaas payment provider (ASAAS_API_KEY, ASAAS_API_URL env vars)
- Errors: `402 PAYMENT_REQUIRED`, `409 CONFLICT`, `422 VALIDATION_ERROR`
- Wallet, payment methods, transactions are per `clinicId`; enforce isolation on all queries and mutations.

## Integrations

- API Keys Management
  - GET `/api/integrations/api-keys` → list keys
    - Response: `{ items: APIKey[] }`
    - Location: `apps/web/src/components/integrations/APIKeyModal.tsx` lines 22-35
  - POST `/api/integrations/api-keys` → generate new key
    - Request: `{ name: string }`
    - Response: `{ key: string, prefix: string, createdAt: string }`
    - Location: `apps/web/src/components/integrations/APIKeyModal.tsx` lines 41-48
  - DELETE `/api/integrations/api-keys/:id` → revoke key
    - Location: `apps/web/src/components/integrations/APIKeyModal.tsx` line 50
  - Model: APIKey: `{ id: string, clinicId: string, name: string, prefix: string, createdAt: string, lastUsed?: string }`
  - Validation: Keys must start with `wm_` prefix, minimum 32 chars

- Webhooks Management
  - GET `/api/integrations/webhooks` → get webhook config
    - Response: `{ url?: string, events: string[], isActive: boolean, secret?: string }`
  - PUT `/api/integrations/webhooks` → update config
    - Request: `{ url: string, events: string[], isActive: boolean }`
    - Location: `apps/web/src/components/integrations/WebhookModal.tsx`
  - POST `/api/integrations/webhooks/test` `{ url: string }` → test webhook
    - Response: `{ success: boolean, latencyMs: number, statusCode: number, response?: string }`
    - Location: `apps/web/src/components/integrations/WebhookModal.tsx`
  - GET `/api/integrations/webhooks/events` → recent events log
    - Query: `limit`, `cursor`
    - Response: `{ items: WebhookEvent[], cursor?: string }`
  - Model: WebhookEvent: `{ id: string, clinicId: string, timestamp: string, status: string, sourceIp: string, eventType: string, payload: any }`
- Validation: Webhook URL must be HTTPS, return 200 OK for verification
- Events: `appointment.created`, `appointment.updated`, `appointment.cancelled`, `patient.created`, `whatsapp.message_received`, `whatsapp.message_sent`
- Notes: Webhook endpoint URL format `https://api.whatsmed.com/v1/clinic/webhook/{webhookId}`

## Automation Settings

- GET `/api/automation/settings` → get automation rules
  - Response: `{ reminders: { sevenDay: { enabled: boolean, message: string, hoursBefore: number }, twentyFourHour: { enabled: boolean, message: string, hoursBefore: number } }, aiAgent: { enabled: boolean, model?: string, prompt?: string } }`
  - Location: `apps/web/src/routes/automation.tsx` lines 17-26
- PUT `/api/automation/settings` → update settings
  - Request: same as GET response
  - Location: `apps/web/src/routes/automation.tsx` line 142
- Validation: `hoursBefore` 1–72, message templates support variables: `{{patient_name}}`, `{{appointment_date}}`, `{{appointment_time}}`
- Trigger: Automated reminders sent via WhatsApp integration
- Notes: AI agent integration placeholder exists, requires OpenAI/GPT configuration

## Clinic Settings

- GET `/api/settings/clinic` → get clinic profile
  - Response: `{ name: string, address?: string, phone?: string, email?: string, timezone: string, logoUrl?: string }`
- PUT `/api/settings/clinic` → update profile
  - Request: same as GET response
- GET `/api/settings/preferences` → get user preferences
  - Response: `{ theme: "light" | "dark" | "system", locale: string, notifications: { email: boolean, whatsapp: boolean } }`
  - Location: `apps/web/src/routes/settings.tsx`
- PUT `/api/settings/preferences` → update preferences
  - Request: same as GET response
- Validation: Timezone must be IANA timezone format, locale ISO 639-1
- Scope clinic settings to `clinicId`; preferences are per user within the clinic.

## Audit Logs

- GET `/api/audit/logs?limit=&cursor=&userId=&action=` → query logs
  - Query: `limit` (default 50, max 1000), `cursor` for pagination, `userId` filter, `action` filter, `dateFrom`, `dateTo`
  - Response: `{ items: Log[], cursor?: string, total?: number }`
  - Location: `apps/web/src/components/AuditLogs.tsx` lines 18-77
- Models
  - Log: `{ id: string, clinicId: string, timestamp: string, userId: string, userName: string, action: string, ipAddress: string, metadata: Record<string, any> }`
- Actions tracked: `LOGIN`, `CREATE_PATIENT`, `UPDATE_PATIENT`, `DELETE_PATIENT`, `CREATE_APPOINTMENT`, `UPDATE_APPOINTMENT`, `DELETE_APPOINTMENT`, `EXPORT_PATIENTS`, `UPDATE_CLINIC_SETTINGS`, `CREATE_API_KEY`, `DELETE_API_KEY`
- Retention: 90 days automatic deletion via Convex cron job
- Notes: Expandable rows for metadata, IP geolocation optional

## User Management

- GET `/api/users?role=&search=` → list users
  - Query: `role` (admin|staff|viewer), `search`, `limit`, `cursor`
  - Response: `{ items: User[], total: number, cursor?: string }`
  - Location: `apps/web/src/components/UserManagement.tsx`
- POST `/api/users` → invite/create user
  - Request: `{ email: string, name: string, role: "admin" | "staff" | "viewer", phone?: string }`
  - Response: `{ id: string, email: string, name: string, role: string, inviteToken?: string }`
- PUT `/api/users/:id` → update user role
  - Request: `{ role: "admin" | "staff" | "viewer" }`
  - Location: `apps/web/src/components/UserManagement.tsx`
- DELETE `/api/users/:id` → remove user
  - Location: `apps/web/src/components/UserManagement.tsx`
- Scope all operations to the current `clinicId`; clinics can have multiple users; cross-clinic access forbidden.
- Models: User: `{ id: string, clinicId: string, email: string, name: string, role: "admin" | "staff" | "viewer", phone?: string, createdAt: string, lastLogin?: string, isActive: boolean }`
- RBAC:
  - `admin`: Full access, user management, billing, settings
  - `staff`: Patient management, appointments, messaging, limited settings
  - `viewer`: Read-only access to patients and appointments
- Notes: Soft delete users, cascade to audit logs

## WhatsApp Connection Health

- WebSocket/SSE endpoint for real-time connection status
- Poll endpoint: GET `/api/health/whatsapp`
  - Response: `{ connected: boolean, lastSync?: string, error?: string, qrCode?: string }`
  - Location: `apps/web/src/routes/dashboard.tsx` lines 77-173 (disconnect alert)
- Trigger: Webhook from Evolution API when connection status changes
- Auto-retry: Exponential backoff for reconnection attempts
- UI Alert: Show reconnect button when disconnected

## Dashboard Analytics

- GET `/api/analytics/appointments?dateFrom=&dateTo=` → appointment metrics
  - Response: `{ total: number, confirmed: number, rescheduled: number, cancelled: number, statusBreakdown: { confirmed: number, pending: number, rescheduled: number, cancelled: number }, funnel: { initiated: number, scheduled: number, attended: number } }`
  - Location: `apps/web/src/routes/dashboard.tsx` lines 85-96
- GET `/api/analytics/efficiency?dateFrom=&dateTo=` → efficiency metrics
  - Response: `{ confirmationRate: number, cancellationRate: number, manualIntervention: number, trends: { confirmationRate: string, cancellationRate: string, manualIntervention: string } }`
  - Location: `apps/web/src/routes/dashboard.tsx` lines 80-82
- Query parameters must respect date range picker selection
- Caching: Cache for 5 minutes, invalidate on appointment changes

## File Uploads (Media)

- POST `/api/uploads` → upload files (images, documents)
  - Content-Type: multipart/form-data
  - Request: File(s) with metadata
  - Response: `{ id: string, url: string, filename: string, size: number, mimeType: string }`
- DELETE `/api/uploads/:id` → delete file
- Storage: Integration with upload provider (S3, Cloudflare R2, etc.)
- Use cases: Patient attachments, WhatsApp media, clinic logo
- Limits: 10MB per file, 100MB per clinic
- All uploads are tied to `clinicId`; enforce per-clinic quota and isolation.

## Authentication Requirements

- Use `Authorization: Bearer <token>` for API calls; set via login
- On web, store token in http-only cookie or header managed by Convex auth client
- Session expiry and refresh: 1h access token + refresh token endpoint at `/api/auth/refresh`
- Tokens must include `clinicId`; backend must scope all reads/writes by `clinicId` from the token.
- CORS: Configure allowed origins in Convex HTTP routes
- Rate limiting: 100 requests per minute per IP (Stricter for auth endpoints: 10/m)
- Webhook signature verification: Use HMAC-SHA256 with webhook secret

## Error Handling Specifications

- Standard error body: `{ code: string, message: string, details?: any, requestId?: string }`
- Status codes: `200 OK`, `201 Created`, `204 No Content`, `400 Bad Request`, `401 Unauthorized`, `403 Forbidden`, `404 Not Found`, `409 Conflict`, `422 Validation Error`, `429 Too Many Requests`, `500 Internal Server Error`, `502 Bad Gateway`
- Frontend must surface toasts and inline validation messages
- Rate limit headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`

## Data Validation Rules

- Email: RFC 5322 compliant, unique per clinic
- Password: min 8 chars, number, special char (Auth handled by Better-Auth)
- Phone: E.164 format (`+5511999999999`), unique per clinic
- Dates: ISO 8601, timezone-aware (store UTC, convert for display)
- Names: 2-100 characters, sanitize for XSS prevention
- IDs: UUID v4 format (or Convex auto-generated)
- Currency: All amounts in smallest unit (e.g., cents) to avoid floating point precision issues

## Implementation Notes

- **Backend Location**: All endpoints implemented in Convex via `packages/backend/convex/` directory
- **Implementation Pattern**: Create Convex HTTP actions for each endpoint at `packages/backend/convex/http/*.ts`
- **Authentication**: Leverage existing Better-Auth integration in `packages/backend/convex/auth.ts`
- **Database Operations**: Use Convex mutations and queries with proper indexing
- **Validation**: Implement Zod schemas for request validation
- **Multi-tenancy**: All tables and queries must include `clinicId`; enforce isolation on every endpoint.
- **Environment Variables**: Dependencies on Asaas, Evolution API, SMTP configured in `turbo.json`
- **Convex Integration**: Use Convex React client in frontend already configured in `apps/web/src/router.tsx`
- **Testing**: Use Vitest for API testing, mock Convex database operations

## Pagination

- Pagination via `limit`/`cursor` for large lists (patients, logs, messages, transactions)
- Use cursor-based pagination for real-time data (chats, messages)
- Default limit: 50, max limit: 1000
- Response format: `{ items: T[], cursor?: string, total?: number }`

## Idempotency

- Idempotency for top-ups and webhook tests recommended via `Idempotency-Key` header
- Store idempotency keys for 24 hours

## Monitoring

- Implement health check endpoint `GET /api/health` returning 200 OK
- Track API endpoint latency and error rates in Convex
- Monitor WhatsApp connection status and webhook delivery success rate
