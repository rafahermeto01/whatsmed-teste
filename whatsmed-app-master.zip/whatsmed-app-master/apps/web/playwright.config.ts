import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "./e2e",
  timeout: 60_000,
  expect: {
    timeout: 10_000,
  },
  fullyParallel: false,
  reporter: [["list"]],
  use: {
    baseURL: "http://127.0.0.1:3001",
    headless: true,
    trace: "off",
    screenshot: "off",
    video: "off",
    channel: "chrome",
    timezoneId: "America/Sao_Paulo",
  },
  webServer: {
    command: "bun run dev -- --host 127.0.0.1",
    port: 3001,
    reuseExistingServer: true,
    timeout: 120_000,
  },
});
