import { useAction, useMutation, useQuery } from "convex/react";
import { Loader2, RefreshCw, QrCode, Key, CheckCircle, AlertTriangle } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

interface WhatsAppConnectModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function WhatsAppConnectModal({ open, onOpenChange }: WhatsAppConnectModalProps) {
  const instance = useQuery(api.integrations.getWhatsAppInstance);
  const connectInstance = useAction(api.integrations.connectInstance);
  const deleteInstance = useAction(api.integrations.deleteInstance);
  const updateMetaConfig = useMutation(api.integrations.updateMetaConfig);
  const switchProvider = useMutation(api.integrations.switchWhatsAppProvider);

  const [loading, setLoading] = useState(false);
  const [qrCode, setQrCode] = useState<string | null>(null);

  // Meta Form State
  const [metaPhoneId, setMetaPhoneId] = useState("");
  const [metaWabaId, setMetaWabaId] = useState("");
  const [metaToken, setMetaToken] = useState("");

  // Sync state with loaded instance
  useEffect(() => {
    if (instance) {
      if (instance.qrcode) setQrCode(instance.qrcode);
      if (instance.metaPhoneNumberId) setMetaPhoneId(instance.metaPhoneNumberId);
      if (instance.metaWabaId) setMetaWabaId(instance.metaWabaId);
    }
  }, [instance]);

  const handleConnectEvolution = async () => {
    setLoading(true);
    try {
      const result = await connectInstance();
      if (result.base64) {
        setQrCode(result.base64);
      }
      // Ensure we switch to evolution mode if connecting via QR
      if (instance?.provider !== "evolution") {
        await switchProvider({ provider: "evolution" });
      }
    } catch (error) {
      toast.error("Erro ao iniciar conexão: " + error);
    } finally {
      setLoading(false);
    }
  };

  const handleRefreshQR = async () => {
    setLoading(true);
    try {
      // Reuse connectInstance to refresh the QR code
      const result = await connectInstance();
      if (result.base64) {
        setQrCode(result.base64);
      }
    } catch (error) {
      toast.error("Erro ao atualizar QR Code: " + error);
    } finally {
      setLoading(false);
    }
  };

  const handleDisconnect = async () => {
    setLoading(true);
    try {
      await deleteInstance();
      setQrCode(null);
      toast.success("Desconectado com sucesso");
    } catch (error) {
      toast.error("Erro ao desconectar: " + error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveMeta = async () => {
    if (!metaPhoneId || !metaWabaId || !metaToken) {
      toast.error("Preencha todos os campos da API Meta");
      return;
    }
    setLoading(true);
    try {
      await updateMetaConfig({
        phoneNumberId: metaPhoneId,
        wabaId: metaWabaId,
        accessToken: metaToken,
      });
      toast.success("Configurações da Meta salvas!");
      // Switch to Meta mode
      await switchProvider({ provider: "meta" });
    } catch (error) {
      toast.error("Erro ao salvar configurações: " + error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Conectar WhatsApp</DialogTitle>
          <DialogDescription>
            Escolha o método de conexão. Recomendamos a API Oficial (Meta) para maior estabilidade.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="evolution" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="evolution">QR Code (Unofficial)</TabsTrigger>
            <TabsTrigger value="meta">Meta Cloud API (Official)</TabsTrigger>
          </TabsList>

          {/* Evolution / QR Code Tab */}
          <TabsContent value="evolution" className="space-y-4 py-4">
            <div className="flex flex-col items-center justify-center space-y-4">
              {instance?.status === "connected" && instance.provider === "evolution" ? (
                <div className="flex flex-col items-center gap-2 text-green-600">
                  <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center">
                    <CheckCircle className="h-8 w-8" />
                  </div>
                  <p className="font-medium">Conectado via Evolution API</p>
                  <Button variant="outline" onClick={handleDisconnect} disabled={loading}>
                    {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    Desconectar
                  </Button>
                </div>
              ) : (
                <>
                  {qrCode ? (
                    <div className="relative group">
                      <img src={qrCode} alt="QR Code" className="w-64 h-64 border rounded-lg" />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-lg">
                        <Button variant="secondary" onClick={handleRefreshQR} disabled={loading}>
                          <RefreshCw className="mr-2 h-4 w-4" /> Atualizar QR
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="h-64 w-64 bg-muted/20 border-2 border-dashed rounded-lg flex flex-col items-center justify-center gap-2 text-muted-foreground">
                      <QrCode className="h-12 w-12 opacity-50" />
                      <span className="text-sm">QR Code não gerado</span>
                    </div>
                  )}

                  <div className="flex flex-col gap-2 w-full">
                    {!qrCode ? (
                      <Button
                        onClick={handleConnectEvolution}
                        disabled={loading}
                        className="w-full"
                      >
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                        Gerar QR Code
                      </Button>
                    ) : (
                      <p className="text-xs text-center text-muted-foreground">
                        Abra o WhatsApp no seu celular {">"} Aparelhos conectados {">"} Conectar
                        aparelho
                      </p>
                    )}
                  </div>
                </>
              )}
            </div>
          </TabsContent>

          {/* Meta Cloud API Tab */}
          <TabsContent value="meta" className="space-y-4 py-4">
            <Alert variant="default" className="bg-blue-50 text-blue-900 border-blue-200">
              <AlertTriangle className="h-4 w-4 text-blue-900" />
              <AlertTitle>Modo Phantom (Simulação)</AlertTitle>
              <AlertDescription>
                A integração com a Meta Cloud API está em modo de simulação. Mensagens serão
                registradas mas não enviadas realmente.
              </AlertDescription>
            </Alert>

            <div className="space-y-3">
              <div className="space-y-1">
                <Label htmlFor="phone-id">Phone Number ID</Label>
                <Input
                  id="phone-id"
                  placeholder="Ex: 100609346..."
                  value={metaPhoneId}
                  onChange={(e) => setMetaPhoneId(e.target.value)}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="waba-id">WhatsApp Business Account ID</Label>
                <Input
                  id="waba-id"
                  placeholder="Ex: 100609346..."
                  value={metaWabaId}
                  onChange={(e) => setMetaWabaId(e.target.value)}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="token">Access Token</Label>
                <Input
                  id="token"
                  type="password"
                  placeholder="EAAG..."
                  value={metaToken}
                  onChange={(e) => setMetaToken(e.target.value)}
                />
              </div>

              <Button onClick={handleSaveMeta} disabled={loading} className="w-full mt-4">
                {loading ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Key className="mr-2 h-4 w-4" />
                )}
                Salvar e Ativar Meta API
              </Button>

              {instance?.provider === "meta" && (
                <div className="flex items-center justify-center gap-2 text-green-600 mt-2">
                  <CheckCircle className="h-4 w-4" />
                  <span className="text-sm font-medium">Ativo atualmente</span>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
