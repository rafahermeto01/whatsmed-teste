import { Trash2, Plus, Copy, Check, AlertTriangle } from "lucide-react";
import { useState } from "react";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface APIKeyModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface APIKey {
  id: string;
  name: string;
  prefix: string;
  createdAt: string;
}

export function APIKeyModal({ open, onOpenChange }: APIKeyModalProps) {
  const [keys, setKeys] = useState<APIKey[]>([
    {
      id: "1",
      name: "ERP Prod",
      prefix: "sk_live_abc123...",
      createdAt: "2025-11-15",
    },
    {
      id: "2",
      name: "Development",
      prefix: "sk_test_xyz789...",
      createdAt: "2025-12-01",
    },
  ]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newKeyName, setNewKeyName] = useState("");
  const [generatedKey, setGeneratedKey] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate key generation
    const key = `sk_live_${Math.random().toString(36).substring(2, 15)}`;
    setGeneratedKey(key);
    setNewKeyName("");
    setShowCreateForm(false);
  };

  const handleRevoke = (keyId: string) => {
    setKeys(keys.filter((key) => key.id !== keyId));
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const onClose = () => onOpenChange(false);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>API Keys</DialogTitle>
          <p className="text-muted-foreground text-sm">
            Gerencie as chaves de API para autenticação externa
          </p>
        </DialogHeader>

        {/* Warning Banner */}
        <Alert variant="destructive" className="mb-2">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Atenção</AlertTitle>
          <AlertDescription>
            As chaves concedem acesso total à sua conta. Não compartilhe suas chaves de API.
          </AlertDescription>
        </Alert>

        {/* Generated Key Display */}
        {generatedKey && (
          <div className="p-4 bg-accent/10 border border-accent rounded-md mb-6">
            <div className="text-sm text-foreground mb-3 font-medium">
              Nova chave gerada! Copie-a agora, você não poderá vê-la novamente.
            </div>
            <div className="flex items-center gap-2">
              <code className="flex-1 px-3 py-2 bg-muted text-foreground text-sm break-all rounded-md font-mono">
                {generatedKey}
              </code>
              <Button
                variant="default"
                size="sm"
                onClick={() => handleCopy(generatedKey, "generated")}
              >
                {copiedId === "generated" ? <Check size={16} /> : <Copy size={16} />}
              </Button>
            </div>
          </div>
        )}

        {/* Key List */}
        <div className="space-y-4 mb-2">
          <h4 className="font-medium">Chaves Existentes</h4>
          <div className="space-y-3">
            {keys.map((key) => (
              <div
                key={key.id}
                className="flex items-center justify-between p-4 bg-muted/50 border rounded-lg"
              >
                <div className="flex-1">
                  <h5 className="font-medium mb-1">{key.name}</h5>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground font-mono">
                    <code>{key.prefix}</code>
                    <span>•</span>
                    <span>Criada em {new Date(key.createdAt).toLocaleDateString("pt-BR")}</span>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  className="text-destructive hover:text-destructive hover:bg-destructive/10"
                  onClick={() => handleRevoke(key.id)}
                >
                  <Trash2 size={16} className="mr-2" />
                  Revogar
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* Create New Key */}
        {!showCreateForm ? (
          <Button
            variant="outline"
            className="w-full h-12 border-dashed border-2 flex items-center justify-center gap-2"
            onClick={() => setShowCreateForm(true)}
          >
            <Plus size={18} />
            Gerar Nova Chave
          </Button>
        ) : (
          <form onSubmit={handleCreate} className="space-y-4">
            <div className="p-4 bg-muted/50 border rounded-lg space-y-4">
              <h4 className="font-medium">Nova Chave de API</h4>
              <div className="space-y-2">
                <Label htmlFor="keyName">Nome da Chave</Label>
                <Input
                  id="keyName"
                  value={newKeyName}
                  onChange={(e) => setNewKeyName(e.target.value)}
                  placeholder="ex: Produção, Desenvolvimento"
                  required
                />
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => {
                  setShowCreateForm(false);
                  setNewKeyName("");
                }}
              >
                Cancelar
              </Button>
              <Button type="submit" className="flex-1">
                Gerar Chave
              </Button>
            </div>
          </form>
        )}

        {/* Close Button */}
        {!showCreateForm && (
          <DialogFooter className="mt-4">
            <Button onClick={onClose} className="px-6">
              Fechar
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}
