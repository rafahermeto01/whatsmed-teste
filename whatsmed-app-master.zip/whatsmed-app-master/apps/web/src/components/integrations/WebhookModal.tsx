import { Copy, Check, ExternalLink } from "lucide-react";
import { useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";

interface WebhookModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface WebhookEvent {
  id: string;
  timestamp: string;
  status: string;
  sourceIp: string;
}

export function WebhookModal({ open, onOpenChange }: WebhookModalProps) {
  const webhookUrl = "https://api.whatsmed.com/v1/clinic/webhook/abc123xyz";
  const [copied, setCopied] = useState(false);

  const recentEvents: WebhookEvent[] = [
    {
      id: "1",
      timestamp: "2025-12-09 14:23:15",
      status: "200 OK",
      sourceIp: "192.168.1.100",
    },
    {
      id: "2",
      timestamp: "2025-12-09 13:45:32",
      status: "200 OK",
      sourceIp: "192.168.1.100",
    },
    {
      id: "3",
      timestamp: "2025-12-08 09:12:44",
      status: "400 Error",
      sourceIp: "192.168.1.105",
    },
  ];

  const examplePayload = {
    event: "appointment.created",
    timestamp: "2025-12-09T14:23:15Z",
    data: {
      appointment_id: "apt_abc123",
      patient_name: "Maria Silva",
      doctor_name: "Dr. João",
      date: "2025-12-15",
      time: "14:00",
    },
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const onClose = () => onOpenChange(false);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Webhook de Entrada</DialogTitle>
          <p className="text-muted-foreground text-sm">
            Configure webhooks para receber eventos em tempo real
          </p>
        </DialogHeader>

        {/* Endpoint URL */}
        <div className="space-y-2">
          <Label>URL do Endpoint</Label>
          <div className="flex items-center gap-2">
            <Input value={webhookUrl} readOnly className="font-mono text-xs bg-muted" />
            <Button
              size="icon"
              onClick={() => handleCopy(webhookUrl)}
              className="shrink-0"
              title="Copiar URL"
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Use esta URL para receber eventos do WhatsMed em seu sistema
          </p>
        </div>

        {/* Documentation */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="font-medium text-sm">Payload JSON Esperado</h4>
            <a href="#" className="text-xs text-primary hover:underline flex items-center gap-1">
              Ver Documentação
              <ExternalLink size={12} />
            </a>
          </div>

          <div className="p-4 bg-slate-950 text-slate-50 rounded-md overflow-x-auto">
            <pre className="text-xs font-mono">
              <code>{JSON.stringify(examplePayload, null, 2)}</code>
            </pre>
          </div>
        </div>

        {/* Recent Events Log */}
        <div className="space-y-2">
          <h4 className="font-medium text-sm">Eventos Recentes</h4>
          <div className="border rounded-md overflow-hidden">
            <Table>
              <TableHeader className="bg-muted/50">
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>IP de Origem</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentEvents.map((event) => (
                  <TableRow key={event.id}>
                    <TableCell className="font-mono text-xs">{event.timestamp}</TableCell>
                    <TableCell>
                      <Badge
                        variant={event.status.includes("200") ? "default" : "destructive"}
                        className={
                          event.status.includes("200")
                            ? "bg-green-100 text-green-700 hover:bg-green-100 dark:bg-green-900/30 dark:text-green-400"
                            : ""
                        }
                      >
                        {event.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{event.sourceIp}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>

        {/* Info Banner */}
        <div className="p-4 bg-accent/10 border border-accent/20 rounded-md">
          <p className="text-sm">
            <strong>Dica:</strong> Webhooks permitem que seu sistema receba notificações em tempo
            real sobre eventos importantes, como novos agendamentos, mensagens recebidas e
            atualizações de pacientes.
          </p>
        </div>

        <DialogFooter>
          <Button onClick={onClose}>Fechar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
