import { useAction, useQuery, useMutation } from "convex/react";
import { Calendar, CheckCircle2, AlertCircle, RefreshCw, Save } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { toast } from "sonner";

import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

interface GoogleConnectModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function GoogleConnectModal({ open, onOpenChange }: GoogleConnectModalProps) {
  const [loading, setLoading] = useState(false);
  const [calendars, setCalendars] = useState<any[]>([]);
  const [loadingCalendars, setLoadingCalendars] = useState(false);

  // Mutations & Actions
  const getOAuthUrl = useAction(api.googleCalendarActions.getOAuthUrl);
  const disconnect = useMutation(api.googleCalendar.disconnect);
  const listCalendars = useAction(api.googleCalendarActions.listCalendars);
  const saveSettings = useMutation(api.googleCalendar.saveSettings);
  const syncEvents = useAction(api.googleCalendarActions.syncEvents);

  // Queries
  const tokens = useQuery(api.googleCalendar.getTokens);
  const settings = useQuery(api.googleCalendar.getSettings);

  const connected = tokens?.connected ?? false;

  // Local state for form
  const [primaryCalendarId, setPrimaryCalendarId] = useState<string>("primary");
  const [blockedCalendarIds, setBlockedCalendarIds] = useState<string[]>([]);
  const oauthPopupRef = useRef<Window | null>(null);

  // Initialize form when settings load
  useEffect(() => {
    if (settings) {
      if (settings.primaryCalendarId) setPrimaryCalendarId(settings.primaryCalendarId);
      if (settings.blockedCalendarIds) setBlockedCalendarIds(settings.blockedCalendarIds);
    }
  }, [settings]);

  // Fetch calendars when connected
  useEffect(() => {
    if (connected && open) {
      fetchCalendars();
    }
  }, [connected, open]);

  const fetchCalendars = async () => {
    setLoadingCalendars(true);
    try {
      const result = await listCalendars();
      setCalendars(result);
    } catch (error) {
      console.error("Failed to fetch calendars", error);
      toast.error("Erro ao carregar lista de calendários");
    } finally {
      setLoadingCalendars(false);
    }
  };

  // Listen for OAuth success message from popup
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.origin !== window.location.origin) return;
      if (oauthPopupRef.current && event.source !== oauthPopupRef.current) return;

      if (event.data.type === "GOOGLE_OAUTH_SUCCESS") {
        toast.success("Google Calendar conectado com sucesso!");
        // Refresh tokens query - wait for Convex to update or use invalidation if available
        // Force reloading the page causes React error if the component is unmounting
        // window.location.reload();
      }
    };

    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, [onOpenChange]);

  const handleConnect = async () => {
    setLoading(true);
    try {
      const { authUrl } = await getOAuthUrl();

      // Open OAuth flow in popup window
      const width = 500;
      const height = 600;
      const left = window.screen.width / 2 - width / 2;
      const top = window.screen.height / 2 - height / 2;

      const popup = window.open(
        authUrl,
        "Google OAuth",
        `width=${width},height=${height},left=${left},top=${top},toolbar=no,location=no,status=no,menubar=no`,
      );

      if (!popup) {
        toast.error("Popup bloqueado. Por favor, permita popups para este site.");
        return;
      }

      oauthPopupRef.current = popup;

      // Check if popup is closed (user cancelled)
      const checkClosed = setInterval(() => {
        if (popup.closed) {
          clearInterval(checkClosed);
          oauthPopupRef.current = null;
          setLoading(false);
        }
      }, 500);
    } catch (error: any) {
      toast.error(error.message || "Falha ao iniciar conexão com Google Calendar");
      setLoading(false);
    }
  };

  const handleDisconnect = async () => {
    if (!confirm("Tem certeza? Isso irá remover a sincronização e apagar eventos importados."))
      return;

    setLoading(true);
    try {
      await disconnect();
      toast.success("Google Calendar desconectado");
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message || "Falha ao desconectar");
    } finally {
      setLoading(false);
    }
  };

  const handleSaveSettings = async () => {
    setLoading(true);
    try {
      await saveSettings({
        primaryCalendarId,
        blockedCalendarIds,
      });
      toast.success("Configurações salvas com sucesso!");

      // Trigger initial sync
      toast.info("Iniciando sincronização...");
      const result = await syncEvents({});
      toast.success(`Sincronização concluída! ${result.synced} eventos processados.`);
    } catch (error: any) {
      toast.error(error.message || "Falha ao salvar configurações");
    } finally {
      setLoading(false);
    }
  };

  const handleSyncNow = async () => {
    setLoading(true);
    try {
      const result = await syncEvents({});
      toast.success(`Sincronização concluída! ${result.synced} eventos processados.`);
    } catch (error: any) {
      toast.error(error.message || "Falha na sincronização");
    } finally {
      setLoading(false);
    }
  };

  // Auto-select primary calendar as blocked if user wants
  useEffect(() => {
    if (primaryCalendarId && !blockedCalendarIds.includes(primaryCalendarId)) {
      setBlockedCalendarIds((prev) => [...prev, primaryCalendarId]);
    }
  }, [primaryCalendarId]);

  const toggleBlockedCalendar = (id: string) => {
    setBlockedCalendarIds((prev) => {
      // If user is trying to uncheck the primary calendar, don't allow it
      // Or just let them, but re-checking logic above might conflict.
      // Better UX: If it's primary, it should probably be forced checked or just added logic-wise.
      // The user asked "automatically selected", so let's just add it.

      if (prev.includes(id)) {
        return prev.filter((c) => c !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Integração Google Calendar
          </DialogTitle>
          <DialogDescription>
            Gerencie a conexão e sincronização com sua agenda do Google.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto py-4 pr-2">
          {!connected ? (
            <div className="space-y-4">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Conecte sua conta do Google para criar reuniões do Google Meet automaticamente e
                  sincronizar sua disponibilidade.
                </AlertDescription>
              </Alert>

              <div className="rounded-lg border p-4 bg-muted/50">
                <h4 className="font-medium text-sm mb-2">Funcionalidades:</h4>
                <ul className="text-xs text-muted-foreground space-y-2 list-disc list-inside">
                  <li>Sincronização bidirecional de eventos</li>
                  <li>Bloqueio automático de horários ocupados</li>
                  <li>Criação de links do Google Meet para teleconsultas</li>
                </ul>
              </div>

              <div className="flex justify-center py-4">
                <Button
                  onClick={handleConnect}
                  disabled={loading}
                  size="lg"
                  className="w-full sm:w-auto"
                >
                  {loading ? "Conectando..." : "Conectar com Google"}
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <Alert className="border-green-200 bg-green-50 dark:bg-green-900/20">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800 dark:text-green-200 flex justify-between items-center">
                  <span>Conectado com sucesso.</span>
                  <div className="text-xs opacity-70">
                    Última sincronização:{" "}
                    {tokens?.lastSyncAt ? new Date(tokens.lastSyncAt).toLocaleString() : "Nunca"}
                  </div>
                </AlertDescription>
              </Alert>

              {loadingCalendars ? (
                <div className="flex justify-center py-8">
                  <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : (
                <>
                  <div className="space-y-3">
                    <Label className="text-base font-semibold">Calendário Principal</Label>
                    <p className="text-sm text-muted-foreground">
                      Onde os novos agendamentos serão criados.
                    </p>
                    <Select value={primaryCalendarId} onValueChange={setPrimaryCalendarId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um calendário" />
                      </SelectTrigger>
                      <SelectContent>
                        {calendars.map((cal) => (
                          <SelectItem key={cal.id} value={cal.id}>
                            {cal.summary} {cal.primary && "(Principal)"}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-base font-semibold">Calendários Bloqueados</Label>
                      <Button variant="ghost" size="sm" onClick={fetchCalendars}>
                        <RefreshCw className="h-3 w-3 mr-1" /> Atualizar Lista
                      </Button>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Selecione os calendários que devem bloquear sua disponibilidade no sistema.
                    </p>

                    <ScrollArea className="h-[200px] border rounded-md p-4">
                      <div className="space-y-4">
                        {calendars.map((cal) => (
                          <div key={cal.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={`blocked-${cal.id}`}
                              checked={blockedCalendarIds.includes(cal.id)}
                              onCheckedChange={() => toggleBlockedCalendar(cal.id)}
                            />
                            <Label
                              htmlFor={`blocked-${cal.id}`}
                              className="text-sm font-normal cursor-pointer flex items-center gap-2"
                            >
                              <span
                                className="w-3 h-3 rounded-full inline-block"
                                style={{ backgroundColor: cal.backgroundColor }}
                              />
                              {cal.summary}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          {connected ? (
            <div className="flex w-full justify-between sm:justify-end gap-2">
              <Button
                variant="destructive"
                onClick={handleDisconnect}
                disabled={loading}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                Desconectar
              </Button>
              <div className="flex gap-2">
                <Button variant="secondary" onClick={handleSyncNow} disabled={loading}>
                  <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
                  Sincronizar
                </Button>
                <Button onClick={handleSaveSettings} disabled={loading}>
                  <Save className="h-4 w-4 mr-2" />
                  Salvar
                </Button>
              </div>
            </div>
          ) : (
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Fechar
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
