import { useMutation } from "convex/react";
import { Camera, RefreshCw, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

interface QRScannerProps {
  urlToken: string;
  onScanSuccess: () => void;
}

export function QRScanner({ urlToken, onScanSuccess }: QRScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [scanning, setScanning] = useState(false);
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Store the controls object returned by decodeFromVideoDevice
  const scannerControlsRef = useRef<{ stop: () => void } | null>(null);
  // Guard to prevent multiple scans
  const hasScannedRef = useRef(false);

  const scanAndValidateQR = useMutation(api.checkin.scanAndValidateQR);

  useEffect(() => {
    // Clean up when component unmounts
    return () => {
      if (scannerControlsRef.current) {
        scannerControlsRef.current.stop();
        scannerControlsRef.current = null;
      }
    };
  }, []);

  const startScan = async () => {
    try {
      setScanning(true);
      setCameraError(null);
      hasScannedRef.current = false;

      // Check if camera is available
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      });
      setHasCameraPermission(true);

      // Stop stream after checking permission
      stream.getTracks().forEach((track) => track.stop());

      // Dynamically import the zxing library (client-side only)
      const { BrowserQRCodeReader } = await import("@zxing/browser");

      // Create BarcodeReader instance
      const reader = new BrowserQRCodeReader();

      if (!videoRef.current) {
        throw new Error("Elemento de vídeo não encontrado");
      }

      // Dynamically import Exception for error checking
      const { Exception } = await import("@zxing/library");

      // Start reading from video element - this returns controls with stop()
      const controls = await reader.decodeFromVideoDevice(
        undefined,
        videoRef.current,
        (result, error) => {
          // Guard against multiple scans
          if (hasScannedRef.current) {
            return;
          }

          if (error) {
            // Handle non-fatal errors (e.g., no QR code in frame)
            if (error instanceof Exception && !error.name.includes("NotFoundException")) {
              console.error("QR Scanner error:", error);
            }
            return;
          }

          if (result) {
            // Mark as scanned immediately to prevent duplicate calls
            hasScannedRef.current = true;
            // QR Code detected successfully
            handleScannedQR(result.getText());
          }
        },
      );

      // Store controls for cleanup
      scannerControlsRef.current = controls;
    } catch (error: any) {
      console.error("Camera error:", error);
      setScanning(false);

      if (error.name === "NotAllowedError" || error.name === "PermissionDeniedError") {
        setHasCameraPermission(false);
        setCameraError(
          "Permissão de câmera negada. Por favor, habilite o acesso à câmera nas configurações do navegador.",
        );
      } else if (error.name === "NotFoundError") {
        setCameraError(
          "Nenhuma câmera encontrada. Por favor, verifique se seu dispositivo tem uma câmera.",
        );
      } else {
        setCameraError("Erro ao acessar a câmera. Por favor, tente novamente.");
      }
    }
  };

  const handleScannedQR = async (qrToken: string) => {
    try {
      setIsProcessing(true);

      // Stop scanning immediately
      if (scannerControlsRef.current) {
        scannerControlsRef.current.stop();
        scannerControlsRef.current = null;
      }
      setScanning(false);

      // Validate and complete check-in
      await scanAndValidateQR({
        qrToken: qrToken,
        urlToken: urlToken,
      });

      onScanSuccess();
      toast.success("Check-in realizado com sucesso!");
    } catch (error: any) {
      console.error("Check-in error:", error);
      toast.error(error.message || "Erro ao processar QR Code");

      // Reset for retry
      hasScannedRef.current = false;
      setIsProcessing(false);
    }
  };

  const stopScan = () => {
    if (scannerControlsRef.current) {
      scannerControlsRef.current.stop();
      scannerControlsRef.current = null;
    }
    setScanning(false);
    setHasCameraPermission(null);
    hasScannedRef.current = false;
  };

  const handleRetry = () => {
    setCameraError(null);
    setHasCameraPermission(null);
    hasScannedRef.current = false;
  };

  // Inject animation styles on mount
  useEffect(() => {
    const styleId = "qr-scanner-animation-styles";
    if (!document.getElementById(styleId)) {
      const style = document.createElement("style");
      style.id = styleId;
      style.textContent = `
        @keyframes scanLine {
          0%, 100% {
            top: 8px;
            opacity: 0;
          }
          10% {
            opacity: 1;
          }
          90% {
            opacity: 1;
          }
          100% {
            top: calc(100% - 8px);
            opacity: 0;
          }
        }
      `;
      document.head.appendChild(style);
    }
  }, []);

  return (
    <div className="flex flex-col items-center justify-center space-y-6 text-center py-8">
      <div className="relative w-64 h-64 bg-black rounded-3xl flex items-center justify-center overflow-hidden border-4 border-muted shadow-xl">
        {cameraError ? (
          // Error State
          <div className="absolute inset-0 bg-slate-900 flex flex-col items-center justify-center p-4 z-30">
            <X className="w-12 h-12 text-red-500 mb-2" />
            <p className="text-white text-sm text-center mb-4">{cameraError}</p>
            <Button
              size="sm"
              onClick={handleRetry}
              variant="outline"
              className="text-white border-white"
            >
              Tentar Novamente
            </Button>
          </div>
        ) : isProcessing ? (
          // Processing State
          <div className="flex flex-col items-center gap-3 p-4">
            <RefreshCw className="w-16 h-16 text-primary animate-spin" />
            <p className="text-muted-foreground text-sm px-4">Processando check-in...</p>
          </div>
        ) : scanning ? (
          // Active Scanning State
          <>
            <video
              ref={videoRef}
              className="absolute inset-0 w-full h-full object-cover"
              playsInline
              muted
            />
            <div className="absolute inset-0 bg-black/50 z-10" />

            {/* QR Scan Overlay */}
            <div className="absolute inset-0 flex items-center justify-center z-20">
              <div className="w-48 h-48 border-4 border-primary/80 rounded-xl relative">
                {/* Corner markers */}
                <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-primary" />
                <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-primary" />
                <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-primary" />
                <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-primary" />

                {/* Scan line animation */}
                <div
                  className="absolute top-0 left-2 right-2 h-1 bg-primary/80 shadow-lg"
                  style={{
                    animation: "scanLine 2s ease-in-out infinite",
                  }}
                />
              </div>
            </div>

            {/* Status text */}
            <div className="absolute bottom-4 left-0 right-0 text-center z-30">
              <div className="inline-flex items-center gap-2 bg-black/70 text-white px-4 py-2 rounded-full text-sm">
                <RefreshCw className="w-4 h-4 animate-spin" />
                Escaneando QR Code...
              </div>
            </div>
          </>
        ) : (
          // Idle State
          <div className="flex flex-col items-center gap-3 p-4">
            <Camera className="w-16 h-16 text-muted-foreground" />
            <p className="text-muted-foreground text-sm px-4">
              {hasCameraPermission === false
                ? "Permissão de câmera necessária"
                : "Toque no botão abaixo para abrir a câmera"}
            </p>
          </div>
        )}
      </div>

      <div className="space-y-4 max-w-xs mx-auto">
        <h3 className="text-xl font-semibold">Hora do Check-in!</h3>
        <p className="text-sm text-muted-foreground">
          Aponte a câmera do seu celular para o QR Code exibido na recepção da clínica.
        </p>

        {scanning ? (
          <Button size="lg" className="w-full gap-2" variant="outline" onClick={stopScan}>
            <X className="w-5 h-5" />
            Cancelar
          </Button>
        ) : (
          <Button
            size="lg"
            className="w-full gap-2"
            onClick={startScan}
            disabled={hasCameraPermission === false || isProcessing}
          >
            <Camera className="w-5 h-5" />
            {isProcessing ? "Processando..." : "Escanear QR Code"}
          </Button>
        )}
      </div>
    </div>
  );
}
