import { useQuery, useMutation } from "convex/react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Calendar as CalendarIcon, Loader2, Check } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

import type { Id } from "@whatsmed-app/backend/convex/_generated/dataModel";

interface PublicSchedulerProps {
  clinicId: string;
  patientId: string;
  doctorId: string;
  procedureId?: string; // Optional - if not provided, will try to find default procedure
  onScheduled: () => void;
  onCancel: () => void;
}

export function PublicScheduler({
  clinicId,
  patientId,
  doctorId,
  procedureId,
  onScheduled,
  onCancel,
}: PublicSchedulerProps) {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [isScheduling, setIsScheduling] = useState(false);

  // Fetch doctor's procedures to find default or use provided procedureId
  const procedures = useQuery(
    api.procedures.listByDoctor,
    doctorId && clinicId ? { doctorId: doctorId as any, clinicId } : "skip",
  );

  // Use provided procedureId or first procedure if available
  const effectiveProcedureId =
    procedureId || (procedures && procedures.length > 0 ? procedures[0]._id : null);

  // Get available slots for selected date (mode 2)
  const slots = useQuery(
    api.appointments.getAvailableSlots,
    effectiveProcedureId && date && clinicId
      ? {
          clinicId,
          doctorId: doctorId as any,
          procedureId: effectiveProcedureId as any,
          date: format(date, "yyyy-MM-dd"),
        }
      : "skip",
  );

  const createAppointment = useMutation(api.appointments.create);

  const handleSchedule = async () => {
    if (!selectedSlot || !date || !effectiveProcedureId) return;

    setIsScheduling(true);
    try {
      const slotDate = new Date(selectedSlot);
      const selectedProcedure = procedures?.find((p: any) => p._id === effectiveProcedureId);
      const durationMinutes = selectedProcedure?.durationMinutes || 30;
      const endAt = new Date(slotDate.getTime() + durationMinutes * 60 * 1000);

      await createAppointment({
        clinicId,
        patientId: patientId as any,
        doctorId: doctorId as any,
        startAt: slotDate.getTime(),
        endAt: endAt.getTime(),
        status: "pending",
        procedure: selectedProcedure?.name || "Retorno",
        procedureId: effectiveProcedureId as Id<"procedures">,
        notes: "Agendado via Formulário de Retorno",
      });

      toast.success("Retorno agendado com sucesso!");
      onScheduled();
    } catch (error) {
      console.error(error);
      toast.error("Erro ao agendar retorno.");
    } finally {
      setIsScheduling(false);
    }
  };

  return (
    <div className="space-y-4 border rounded-lg p-4 bg-background">
      <div className="space-y-2">
        <h3 className="font-medium text-lg">Agendar Retorno</h3>
        <p className="text-sm text-muted-foreground">
          Selecione uma data e horário para sua consulta de retorno.
        </p>
      </div>

      <div className="space-y-4">
        <div className="flex flex-col space-y-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant={"outline"}
                className={cn(
                  "w-full justify-start text-left font-normal",
                  !date && "text-muted-foreground",
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, "PPP", { locale: ptBR }) : <span>Selecione uma data</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                disabled={(date) => date < new Date()}
                initialFocus
              />
            </PopoverContent>
          </Popover>
        </div>

        {!effectiveProcedureId && (
          <div className="rounded-md bg-yellow-50 dark:bg-yellow-950 p-3 text-sm text-yellow-800 dark:text-yellow-200">
            Nenhum procedimento disponível para este médico.
          </div>
        )}
        {date && effectiveProcedureId && (
          <div className="grid grid-cols-3 gap-2">
            {!slots ? (
              <div className="col-span-3 text-center py-4">
                <Loader2 className="h-4 w-4 animate-spin mx-auto" />
              </div>
            ) : !Array.isArray(slots) || slots.length === 0 ? (
              <div className="col-span-3 text-center py-4 text-sm text-muted-foreground">
                Nenhum horário disponível nesta data.
              </div>
            ) : (
              slots.map((slot: { start: string; end: string }) => {
                const startTime = new Date(slot.start);
                const timeString = format(startTime, "HH:mm");
                const isSelected = selectedSlot === slot.start;

                return (
                  <Button
                    key={slot.start}
                    variant={isSelected ? "default" : "outline"}
                    className="text-sm"
                    onClick={() => setSelectedSlot(slot.start)}
                  >
                    {timeString}
                    {isSelected && <Check className="ml-2 h-3 w-3" />}
                  </Button>
                );
              })
            )}
          </div>
        )}
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button variant="ghost" onClick={onCancel} disabled={isScheduling}>
          Pular
        </Button>
        <Button
          onClick={handleSchedule}
          disabled={!selectedSlot || isScheduling || !effectiveProcedureId}
        >
          {isScheduling ? "Agendando..." : "Confirmar Agendamento"}
        </Button>
      </div>
    </div>
  );
}
