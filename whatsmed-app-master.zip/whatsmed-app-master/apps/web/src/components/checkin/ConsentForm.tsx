import { useMutation } from "convex/react";
import { Eraser, Loader2 } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import SignaturePad from "signature_pad";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

interface ConsentFormProps {
  onComplete: () => void;
  onBack: () => void;
  clinicId: string;
  patientId: string;
  appointmentId?: string;
}

export function ConsentForm({
  onComplete,
  onBack,
  clinicId,
  patientId,
  appointmentId,
}: ConsentFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [signatureEmpty, setSignatureEmpty] = useState(true);
  const saveConsent = useMutation(api.checkin.saveConsent);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const signaturePadRef = useRef<SignaturePad | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [consents, setConsents] = useState({
    lgpd: false,
    telehealth: false,
    procedures: false,
  });

  const allChecked = consents.lgpd && consents.telehealth && consents.procedures;

  const resizeCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ratio = Math.max(window.devicePixelRatio || 1, 1);
    const width = container.clientWidth;
    const height = container.clientHeight;

    canvas.width = width * ratio;
    canvas.height = height * ratio;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.scale(ratio, ratio);
    }

    // Clear after resize since canvas content is lost
    signaturePadRef.current?.clear();
    setSignatureEmpty(true);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const pad = new SignaturePad(canvas, {
      backgroundColor: "rgb(255, 255, 255)",
      penColor: "rgb(0, 0, 0)",
    });

    pad.addEventListener("endStroke", () => {
      setSignatureEmpty(pad.isEmpty());
    });

    signaturePadRef.current = pad;
    resizeCanvas();

    const observer = new ResizeObserver(() => resizeCanvas());
    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => {
      observer.disconnect();
      pad.off();
    };
  }, [resizeCanvas]);

  const handleClear = () => {
    signaturePadRef.current?.clear();
    setSignatureEmpty(true);
  };

  const handleSubmit = async () => {
    if (!allChecked || signatureEmpty) return;

    setIsSubmitting(true);
    try {
      const timestamp = Date.now();
      const signature = signaturePadRef.current!.toDataURL("image/png");

      await Promise.all([
        saveConsent({
          clinicId,
          patientId,
          appointmentId,
          type: "lgpd",
          version: "1.0",
          signature,
          acceptedAt: timestamp,
        }),
        saveConsent({
          clinicId,
          patientId,
          appointmentId,
          type: "telehealth",
          version: "1.0",
          signature,
          acceptedAt: timestamp,
        }),
        saveConsent({
          clinicId,
          patientId,
          appointmentId,
          type: "procedures",
          version: "1.0",
          signature,
          acceptedAt: timestamp,
        }),
      ]);

      toast.success("Termos aceitos com sucesso!");
      onComplete();
    } catch (error) {
      console.error(error);
      toast.error("Erro ao salvar termos. Tente novamente.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h3 className="text-lg font-medium">Termos de Consentimento</h3>
        <p className="text-sm text-muted-foreground">
          Para sua segurança e conformidade legal, precisamos do seu aceite nos termos abaixo.
        </p>
      </div>

      <div className="space-y-6">
        <div className="space-y-3 p-4 border rounded-md bg-muted/20">
          <div className="flex items-start space-x-3">
            <Checkbox
              id="lgpd"
              checked={consents.lgpd}
              onCheckedChange={(c) => setConsents({ ...consents, lgpd: c === true })}
            />
            <div className="grid gap-1.5 leading-none">
              <Label
                htmlFor="lgpd"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Consentimento LGPD
              </Label>
              <p className="text-sm text-muted-foreground">
                Autorizo o tratamento dos meus dados pessoais sensíveis para fins de prestação de
                serviços médicos, conforme a Lei Geral de Proteção de Dados (13.709/2018).
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-3 p-4 border rounded-md bg-muted/20">
          <div className="flex items-start space-x-3">
            <Checkbox
              id="telehealth"
              checked={consents.telehealth}
              onCheckedChange={(c) => setConsents({ ...consents, telehealth: c === true })}
            />
            <div className="grid gap-1.5 leading-none">
              <Label
                htmlFor="telehealth"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Termo de Telemedicina
              </Label>
              <p className="text-sm text-muted-foreground">
                Compreendo que consultas remotas têm limitações e autorizo o atendimento via
                videochamada quando aplicável.
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-3 p-4 border rounded-md bg-muted/20">
          <div className="flex items-start space-x-3">
            <Checkbox
              id="procedures"
              checked={consents.procedures}
              onCheckedChange={(c) => setConsents({ ...consents, procedures: c === true })}
            />
            <div className="grid gap-1.5 leading-none">
              <Label
                htmlFor="procedures"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Autorização de Procedimentos
              </Label>
              <p className="text-sm text-muted-foreground">
                Declaro ter sido informado sobre os procedimentos agendados e autorizo sua
                realização pela equipe clínica.
              </p>
            </div>
          </div>
        </div>

        {/* Digital Signature Canvas */}
        <div className="pt-4 border-t">
          <div className="flex items-center justify-between mb-2">
            <Label>Assinatura Digital</Label>
            <Button
              type="button"
              size="sm"
              variant="ghost"
              onClick={handleClear}
              disabled={signatureEmpty}
            >
              <Eraser className="w-4 h-4 mr-1" />
              Limpar
            </Button>
          </div>
          <div
            ref={containerRef}
            className="h-32 border-2 border-muted-foreground/30 rounded-md overflow-hidden bg-white"
          >
            <canvas ref={canvasRef} className="touch-none cursor-crosshair" />
          </div>
          {signatureEmpty && (
            <p className="text-xs text-muted-foreground mt-1">
              Desenhe sua assinatura no campo acima.
            </p>
          )}
        </div>
      </div>

      <div className="flex gap-3 pt-4">
        <Button variant="outline" onClick={onBack} className="w-1/3" disabled={isSubmitting}>
          Voltar
        </Button>
        <Button
          onClick={handleSubmit}
          disabled={!allChecked || signatureEmpty || isSubmitting}
          className="w-2/3"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Assinando...
            </>
          ) : (
            "Assinar e Finalizar"
          )}
        </Button>
      </div>
    </div>
  );
}
