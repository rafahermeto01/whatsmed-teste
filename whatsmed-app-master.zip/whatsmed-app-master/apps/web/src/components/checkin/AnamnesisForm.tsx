import { useMutation } from "convex/react";
import { Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

interface AnamnesisFormProps {
  onComplete: () => void;
  clinicId: string;
  patientId: string;
  checkinSessionId: string;
  initialData?: {
    phone?: string;
    address?: string;
  };
}

export function AnamnesisForm({
  onComplete,
  clinicId,
  patientId,
  checkinSessionId,
  initialData,
}: AnamnesisFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const submitAnamnesis = useMutation(api.checkin.submitAnamnesisData);

  const [formData, setFormData] = useState({
    phone: initialData?.phone || "",
    address: initialData?.address || "",
    allergies: "",
    medications: "",
    history: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await submitAnamnesis({
        clinicId,
        patientId,
        checkinSessionId,
        data: formData,
      });

      toast.success("Dados salvos com sucesso!");
      onComplete();
    } catch (error) {
      console.error(error);
      toast.error("Erro ao salvar dados. Tente novamente.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h3 className="text-lg font-medium">Atualização Cadastral e Anamnese</h3>
        <p className="text-sm text-muted-foreground">
          Por favor, confirme seus dados e atualize seu histórico médico antes da consulta.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 gap-4">
          <div className="space-y-2">
            <Label htmlFor="phone">Telefone para Contato</Label>
            <Input
              id="phone"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="(00) 00000-0000"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">Endereço Atual</Label>
            <Input
              id="address"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="allergies">Alergias (Medicamentos/Alimentos)</Label>
            <Input
              id="allergies"
              placeholder="Ex: Dipirona, Penicilina, Amendoim..."
              value={formData.allergies}
              onChange={(e) => setFormData({ ...formData, allergies: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="medications">Medicamentos em Uso</Label>
            <Textarea
              id="medications"
              placeholder="Liste os medicamentos que você toma regularmente..."
              value={formData.medications}
              onChange={(e) => setFormData({ ...formData, medications: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="history">Histórico Recente / Queixa Principal</Label>
            <Textarea
              id="history"
              placeholder="Descreva brevemente o motivo da consulta ou sintomas recentes..."
              value={formData.history}
              onChange={(e) => setFormData({ ...formData, history: e.target.value })}
              rows={4}
              required
            />
          </div>
        </div>

        <Button type="submit" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Salvando...
            </>
          ) : (
            "Confirmar e Prosseguir"
          )}
        </Button>
      </form>
    </div>
  );
}
