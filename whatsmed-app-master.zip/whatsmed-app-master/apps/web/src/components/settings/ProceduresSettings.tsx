import { useMutation, useQuery } from "convex/react";
import { Clock, Pencil, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useClinicId, useEffectiveAppUser } from "@/hooks/patients";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

import type { Id } from "@whatsmed-app/backend/convex/_generated/dataModel";

interface Procedure {
  _id: Id<"procedures">;
  name: string;
  description?: string;
  durationMinutes: number;
  price?: number;
  isActive: boolean;
  isTelemedicine?: boolean;
  isInPerson?: boolean;
}

export function ProceduresSettings() {
  const { clinicId, role } = useClinicId();
  const currentUser = useEffectiveAppUser();

  // Get doctors list for admins/super_admin
  const doctors = useQuery(
    api.users.list,
    clinicId && (role === "admin" || role === "super_admin")
      ? {
          clinicId,
          role: "doctor",
        }
      : "skip",
  );

  // Selected doctor ID for admins
  const [selectedDoctorId, setSelectedDoctorId] = useState<Id<"users"> | null>(null);

  // Procedures query - filter by doctorId based on role
  const procedures = useQuery(
    api.procedures.list,
    clinicId && (role !== "doctor" || currentUser?._id)
      ? {
          clinicId,
          doctorId:
            role === "doctor"
              ? currentUser?._id
              : role === "admin" || role === "super_admin"
                ? selectedDoctorId || undefined
                : undefined,
          includeInactive: true,
          paginationOpts: { numItems: 100, cursor: null },
        }
      : "skip",
  );

  const createProcedure = useMutation(api.procedures.create);
  const updateProcedure = useMutation(api.procedures.update);
  const deleteProcedure = useMutation(api.procedures.softDelete);

  const [isOpen, setIsOpen] = useState(false);
  const [editingProcedure, setEditingProcedure] = useState<Procedure | null>(null);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    durationMinutes: 30,
    price: 0,
    isTelemedicine: false,
    isInPerson: false,
  });

  // Show for doctors, admins, and super_admin
  if (!clinicId || (role !== "doctor" && role !== "admin" && role !== "super_admin")) {
    return null;
  }

  const isAdmin = role === "admin" || role === "super_admin";

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      durationMinutes: 30,
      price: 0,
      isTelemedicine: false,
      isInPerson: false,
    });
    setEditingProcedure(null);
  };

  const handleOpenChange = (open: boolean) => {
    setIsOpen(open);
    if (!open) {
      resetForm();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      toast.error("Nome do procedimento é obrigatório");
      return;
    }

    if (formData.durationMinutes < 15 || formData.durationMinutes > 480) {
      toast.error("Duração deve ser entre 15 e 480 minutos");
      return;
    }

    if (!formData.isTelemedicine && !formData.isInPerson) {
      toast.error("Selecione pelo menos um tipo de atendimento (Teleconsulta ou Presencial)");
      return;
    }

    // For admins, require selectedDoctorId when creating
    if (!editingProcedure && isAdmin && !selectedDoctorId) {
      toast.error("Selecione um médico para criar o procedimento");
      return;
    }

    setSaving(true);
    try {
      if (editingProcedure) {
        await updateProcedure({
          id: editingProcedure._id,
          name: formData.name.trim(),
          description: formData.description.trim() || undefined,
          durationMinutes: formData.durationMinutes,
          price: formData.price || undefined,
          isTelemedicine: formData.isTelemedicine,
          isInPerson: formData.isInPerson,
        });
        toast.success("Procedimento atualizado com sucesso!");
      } else {
        // Create procedure with or without doctorId based on role
        if (isAdmin && selectedDoctorId) {
          await createProcedure({
            doctorId: selectedDoctorId,
            name: formData.name.trim(),
            description: formData.description.trim() || undefined,
            durationMinutes: formData.durationMinutes,
            price: formData.price || undefined,
            isTelemedicine: formData.isTelemedicine,
            isInPerson: formData.isInPerson,
          });
        } else {
          // Doctor creates without doctorId (backend defaults to current user)
          await createProcedure({
            name: formData.name.trim(),
            description: formData.description.trim() || undefined,
            durationMinutes: formData.durationMinutes,
            price: formData.price || undefined,
            isTelemedicine: formData.isTelemedicine,
            isInPerson: formData.isInPerson,
          });
        }
        toast.success("Procedimento criado com sucesso!");
      }

      handleOpenChange(false);
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar procedimento");
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (procedure: Procedure) => {
    setEditingProcedure(procedure);
    setFormData({
      name: procedure.name,
      description: procedure.description || "",
      durationMinutes: procedure.durationMinutes,
      price: procedure.price || 0,
      isTelemedicine: procedure.isTelemedicine ?? false,
      isInPerson: procedure.isInPerson ?? false,
    });
    setIsOpen(true);
  };

  const handleDelete = async (procedure: Procedure) => {
    if (!confirm(`Tem certeza que deseja excluir o procedimento "${procedure.name}"?`)) return;

    try {
      await deleteProcedure({ id: procedure._id });
      toast.success("Procedimento excluído com sucesso!");
    } catch (error: any) {
      toast.error(error.message || "Erro ao excluir procedimento");
    }
  };

  const handleToggleActive = async (procedure: Procedure) => {
    try {
      await updateProcedure({
        id: procedure._id,
        isActive: !procedure.isActive,
      });
      toast.success(procedure.isActive ? "Procedimento desativado" : "Procedimento ativado");
    } catch (error: any) {
      toast.error(error.message || "Erro ao atualizar procedimento");
    }
  };

  const formatDuration = (minutes: number) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    if (remainingMinutes === 0) return `${hours}h`;
    return `${hours}h ${remainingMinutes}min`;
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Procedimentos</CardTitle>
          <CardDescription>
            {isAdmin
              ? "Gerencie os procedimentos dos médicos e suas durações."
              : "Gerencie os procedimentos que você oferece e suas durações."}
          </CardDescription>
        </div>
        <Dialog open={isOpen} onOpenChange={handleOpenChange}>
          <DialogTrigger asChild>
            <Button size="sm" disabled={isAdmin && !selectedDoctorId}>
              <Plus className="h-4 w-4 mr-2" />
              Adicionar
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingProcedure ? "Editar Procedimento" : "Novo Procedimento"}
              </DialogTitle>
              <DialogDescription>
                {editingProcedure
                  ? "Atualize as informações do procedimento."
                  : "Adicione um novo procedimento à sua lista."}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nome *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ex: Consulta de Rotina"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Descricao (opcional)</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Descricao do procedimento..."
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="duration">Duracao (minutos) *</Label>
                  <Input
                    id="duration"
                    type="number"
                    min={15}
                    max={480}
                    value={formData.durationMinutes}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        durationMinutes: parseInt(e.target.value) || 30,
                      })
                    }
                    required
                  />
                  <p className="text-xs text-muted-foreground">Entre 15 e 480 minutos</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="price">Preco (opcional)</Label>
                  <Input
                    id="price"
                    type="number"
                    min={0}
                    step={0.01}
                    value={formData.price || ""}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        price: parseFloat(e.target.value) || 0,
                      })
                    }
                    placeholder="0,00"
                  />
                </div>
              </div>
              <div className="space-y-3">
                <Label>Tipo de Atendimento *</Label>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="telemedicine"
                      checked={formData.isTelemedicine}
                      onCheckedChange={(checked) =>
                        setFormData({ ...formData, isTelemedicine: checked === true })
                      }
                    />
                    <Label htmlFor="telemedicine" className="cursor-pointer font-normal">
                      Teleconsulta
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="inPerson"
                      checked={formData.isInPerson}
                      onCheckedChange={(checked) =>
                        setFormData({ ...formData, isInPerson: checked === true })
                      }
                    />
                    <Label htmlFor="inPerson" className="cursor-pointer font-normal">
                      Presencial
                    </Label>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  Selecione pelo menos um tipo de atendimento
                </p>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => handleOpenChange(false)}>
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  disabled={saving || (!formData.isTelemedicine && !formData.isInPerson)}
                >
                  {saving ? "Salvando..." : "Salvar"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Doctor selector for admins */}
        {isAdmin && (
          <div className="space-y-2">
            <Label htmlFor="doctor-select">Médico</Label>
            <Select
              value={selectedDoctorId || "all"}
              onValueChange={(value) =>
                setSelectedDoctorId(value === "all" ? null : (value as Id<"users">))
              }
            >
              <SelectTrigger id="doctor-select">
                <SelectValue placeholder="Selecione um médico ou veja todos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os médicos</SelectItem>
                {doctors?.items.map((doctor: any) => (
                  <SelectItem key={doctor._id} value={doctor._id}>
                    {doctor.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {doctors?.items.length === 0 && (
              <p className="text-sm text-muted-foreground">Nenhum médico cadastrado na clínica</p>
            )}
          </div>
        )}

        {/* Procedures list */}
        {!procedures || procedures.page.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>
              {isAdmin
                ? selectedDoctorId
                  ? "Nenhum procedimento cadastrado para este médico"
                  : "Nenhum procedimento cadastrado"
                : "Nenhum procedimento cadastrado"}
            </p>
            <p className="text-sm">
              {isAdmin && !selectedDoctorId
                ? "Selecione um médico para criar procedimentos."
                : 'Clique em "Adicionar" para criar seu primeiro procedimento.'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {procedures.page.map((procedure: any) => (
              <div
                key={procedure._id}
                className={`flex items-center justify-between p-4 border rounded-lg transition-opacity ${
                  !procedure.isActive ? "opacity-50 bg-muted/30" : "bg-background"
                }`}
              >
                <div className="flex items-center gap-4">
                  <Switch
                    checked={procedure.isActive}
                    onCheckedChange={() => handleToggleActive(procedure as Procedure)}
                    title={procedure.isActive ? "Desativar procedimento" : "Ativar procedimento"}
                  />
                  <div>
                    <p className="font-medium">{procedure.name}</p>
                    <div className="flex items-center gap-3 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {formatDuration(procedure.durationMinutes)}
                      </span>
                      {procedure.price !== undefined && procedure.price > 0 && (
                        <span>{formatPrice(procedure.price)}</span>
                      )}
                    </div>
                    {procedure.description && (
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-1">
                        {procedure.description}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => handleEdit(procedure as Procedure)}
                    title="Editar procedimento"
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => handleDelete(procedure as Procedure)}
                    className="text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                    title="Excluir procedimento"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
