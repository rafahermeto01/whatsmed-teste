import { useMutation } from "convex/react";
import { Plus, Trash2, Copy, ClipboardPaste } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";

import { AutoSaveIndicator } from "@/components/ui/auto-save-indicator";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { TimePicker } from "@/components/ui/time-picker";
import { useEffectiveAppUser } from "@/hooks/patients";
import { useAutoSave } from "@/hooks/useAutoSave";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

const DAYS = [
  { id: 0, label: "Domingo" },
  { id: 1, label: "Segunda-feira" },
  { id: 2, label: "Terça-feira" },
  { id: 3, label: "Quarta-feira" },
  { id: 4, label: "Quinta-feira" },
  { id: 5, label: "Sexta-feira" },
  { id: 6, label: "Sábado" },
];

export function WorkingHoursSettings() {
  const user = useEffectiveAppUser();
  const updateWorkingHours = useMutation(api.users.updateWorkingHours);

  const [schedule, setSchedule] = useState<any[]>([]);
  const [clipboard, setClipboard] = useState<any[] | null>(null);

  useEffect(() => {
    if (user?.workingHours) {
      setSchedule(user.workingHours);
    } else if (user) {
      // Default init if empty
      setSchedule([]);
    }
  }, [user]);

  // Validation function - checks for overlapping slots
  const validateSchedule = useCallback((data: any[]) => {
    for (const day of data) {
      const sortedSlots = [...day.slots].sort((a: any, b: any) => a.start.localeCompare(b.start));
      for (let i = 0; i < sortedSlots.length - 1; i++) {
        const current = sortedSlots[i];
        const next = sortedSlots[i + 1];
        if (current.end > next.start) {
          // Show error toast for overlapping slots
          toast.error(
            `Conflito de horários no ${DAYS.find((d) => d.id === day.dayOfWeek)?.label}: ${current.start}-${current.end} sobrepõe ${next.start}-${next.end}`,
          );
          return false;
        }
      }
    }
    return true;
  }, []);

  // Autosave callback
  const handleSaveSchedule = useCallback(
    async (data: any[]) => {
      if (!user) return;

      await updateWorkingHours({
        id: user._id,
        workingHours: data,
      });
    },
    [user, updateWorkingHours],
  );

  // Autosave hook
  const { status: saveStatus, error: saveError } = useAutoSave({
    data: schedule,
    onSave: handleSaveSchedule,
    validate: validateSchedule,
    enabled: !!user,
    debounceMs: 800,
  });

  const handleAddSlot = (dayOfWeek: number) => {
    // Calculate new slot values before updating state
    const dayConfig = schedule.find((d) => d.dayOfWeek === dayOfWeek);
    let newStart = "09:00";
    let newEnd = "12:00";

    if (dayConfig && dayConfig.slots.length > 0) {
      const sortedSlots = [...dayConfig.slots].sort((a, b) => a.end.localeCompare(b.end));
      const lastSlot = sortedSlots[sortedSlots.length - 1];

      newStart = lastSlot.end;

      // If we are at the end of the day, we can't add more slots
      if (newStart >= "23:59") {
        toast.error("Não é possível adicionar mais horários neste dia.");
        return;
      }

      // Default duration: 1 hour, or until 23:59
      const [h, m] = newStart.split(":").map(Number);
      let endH = h + 1;
      let endM = m;

      if (endH > 23) {
        endH = 23;
        endM = 59;
      }

      newEnd = `${endH.toString().padStart(2, "0")}:${endM.toString().padStart(2, "0")}`;
    }

    setSchedule((prev) => {
      const dayConfig = prev.find((d) => d.dayOfWeek === dayOfWeek);
      if (dayConfig) {
        return prev.map((d) =>
          d.dayOfWeek === dayOfWeek
            ? {
                ...d,
                slots: [
                  ...d.slots,
                  { start: newStart, end: newEnd, types: ["in_person", "telemedicine"] },
                ],
              }
            : d,
        );
      } else {
        return [
          ...prev,
          {
            dayOfWeek,
            slots: [{ start: "09:00", end: "12:00", types: ["in_person", "telemedicine"] }],
          },
        ];
      }
    });
  };

  const handleRemoveSlot = (dayOfWeek: number, index: number) => {
    setSchedule((prev) => {
      return prev
        .map((d) => {
          if (d.dayOfWeek === dayOfWeek) {
            const newSlots = d.slots.filter((_: any, i: any) => i !== index);
            if (newSlots.length === 0) return null; // Remove day if no slots
            return { ...d, slots: newSlots };
          }
          return d;
        })
        .filter(Boolean) as any[];
    });
  };

  const handleUpdateSlot = (dayOfWeek: number, index: number, field: string, value: any) => {
    setSchedule((prev) =>
      prev.map((d) => {
        if (d.dayOfWeek === dayOfWeek) {
          const newSlots = [...d.slots];
          newSlots[index] = { ...newSlots[index], [field]: value };
          return { ...d, slots: newSlots };
        }
        return d;
      }),
    );
  };

  const toggleDay = (dayOfWeek: number, enabled: boolean) => {
    if (enabled) {
      handleAddSlot(dayOfWeek);
    } else {
      setSchedule((prev) => prev.filter((d) => d.dayOfWeek !== dayOfWeek));
    }
  };

  const handleCopy = (dayOfWeek: number) => {
    const dayConfig = schedule.find((d) => d.dayOfWeek === dayOfWeek);
    if (dayConfig) {
      setClipboard(dayConfig.slots);
      toast.success("Horários copiados!");
    }
  };

  const handlePaste = (dayOfWeek: number) => {
    if (!clipboard) return;

    // Deep copy the clipboard to avoid reference issues
    const newSlots = JSON.parse(JSON.stringify(clipboard));

    setSchedule((prev) => {
      const exists = prev.find((d) => d.dayOfWeek === dayOfWeek);
      if (exists) {
        return prev.map((d) => (d.dayOfWeek === dayOfWeek ? { ...d, slots: newSlots } : d));
      } else {
        return [...prev, { dayOfWeek, slots: newSlots }];
      }
    });
  };

  if (!user) return <div>Carregando...</div>;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Horários de Atendimento</CardTitle>
            <CardDescription>
              Configure seus horários de trabalho, intervalos e tipos de atendimento.
            </CardDescription>
          </div>
          <AutoSaveIndicator status={saveStatus} error={saveError} />
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {DAYS.map((day) => {
          const dayConfig = schedule.find((s) => s.dayOfWeek === day.id);
          const isEnabled = !!dayConfig;

          return (
            <div key={day.id} className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={isEnabled}
                    onCheckedChange={(checked) => toggleDay(day.id, checked)}
                  />
                  <span className={`font-medium ${isEnabled ? "" : "text-muted-foreground"}`}>
                    {day.label}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {isEnabled && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleCopy(day.id)}
                      className="h-8 text-muted-foreground hover:text-foreground"
                      title="Copiar horários"
                    >
                      <Copy size={16} />
                    </Button>
                  )}
                  {clipboard && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handlePaste(day.id)}
                      className="h-8 text-muted-foreground hover:text-foreground"
                      title="Colar horários"
                    >
                      <ClipboardPaste size={16} />
                    </Button>
                  )}
                  {isEnabled && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleAddSlot(day.id)}
                      className="h-8 text-primary"
                    >
                      <Plus size={16} className="mr-1" /> Adicionar intervalo
                    </Button>
                  )}
                </div>
              </div>

              {isEnabled && dayConfig && (
                <div className="mt-4 space-y-3">
                  {dayConfig.slots.map((slot: any, index: number) => {
                    // Logic to determine blocked times for this specific picker
                    // For Start Time: Can't overlap with previous slot's end (if sorted)
                    // For End Time: Can't overlap with next slot's start
                    // However, since slots can be unsorted in the UI array until save,
                    // a robust solution requires finding the immediate neighbor in time.

                    // Let's assume for simplicity we just want to block overlapping with ANY other slot.
                    // But TimePicker takes minTime/maxTime ranges.
                    // Complex "gap" logic is hard for simple min/max.
                    // Instead, let's implement the basic requested feature:
                    // "make it so that that the user does not have the option to select overlapping times"
                    // If we assume slots are mostly sequential:
                    // Find the closest slot ending BEFORE this one starts -> minTime
                    // Find the closest slot starting AFTER this one ends -> maxTime

                    const otherSlots = dayConfig.slots.filter((_: any, i: any) => i !== index);

                    // For Start Time Picker:
                    // It cannot be earlier than the end of any slot that ends before the current *end time*.
                    // Actually, simpler: Start time must be > max(end times of all slots that are strictly before this one)
                    // AND < current end time.

                    // Let's find the "bounding box" for this slot in the day.
                    // Sort all *other* slots by start time.
                    const sortedOthers = [...otherSlots].sort((a, b) =>
                      a.start.localeCompare(b.start),
                    );

                    // Find the gap this slot currently resides in.
                    // We use the current slot's values to identify which gap it belongs to,
                    // or just use the neighboring slots based on time.

                    let minStart = undefined;
                    let maxEnd = undefined;

                    // Find closest slot before current start
                    const prevSlot = sortedOthers
                      .filter((s) => s.end <= slot.start)
                      .sort((a, b) => b.end.localeCompare(a.end))[0];
                    if (prevSlot) minStart = prevSlot.end;

                    // Find closest slot after current end
                    const nextSlot = sortedOthers
                      .filter((s) => s.start >= slot.end)
                      .sort((a, b) => a.start.localeCompare(b.start))[0];
                    if (nextSlot) maxEnd = nextSlot.start;

                    return (
                      <div
                        key={index}
                        className="flex flex-wrap items-center gap-4 p-3 bg-muted/30 rounded-md border"
                      >
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-2">
                            <TimePicker
                              value={slot.start}
                              onChange={(val) => handleUpdateSlot(day.id, index, "start", val)}
                              className="w-24 h-9"
                              minTime={minStart}
                              maxTime={slot.end} // Start can't be after End
                            />
                            <span className="text-muted-foreground text-sm">até</span>
                            <TimePicker
                              value={slot.end}
                              onChange={(val) => handleUpdateSlot(day.id, index, "end", val)}
                              className="w-24 h-9"
                              minTime={slot.start} // End can't be before Start
                              maxTime={maxEnd}
                            />
                          </div>
                        </div>

                        <div className="h-6 w-px bg-border hidden sm:block mx-2" />

                        <div className="flex items-center gap-4 flex-1">
                          <div
                            className="flex items-center gap-2 cursor-pointer hover:bg-muted/50 p-1.5 rounded transition-colors"
                            onClick={() => {
                              const newTypes = !slot.types.includes("in_person")
                                ? [...slot.types, "in_person"]
                                : slot.types.filter((t: string) => t !== "in_person");
                              handleUpdateSlot(day.id, index, "types", newTypes);
                            }}
                          >
                            <Checkbox
                              id={`in-person-${day.id}-${index}`}
                              checked={slot.types.includes("in_person")}
                              onCheckedChange={() => {}} // Handled by parent div
                            />
                            <Label
                              htmlFor={`in-person-${day.id}-${index}`}
                              className="cursor-pointer text-sm font-normal"
                            >
                              Presencial
                            </Label>
                          </div>
                          <div
                            className="flex items-center gap-2 cursor-pointer hover:bg-muted/50 p-1.5 rounded transition-colors"
                            onClick={() => {
                              const newTypes = !slot.types.includes("telemedicine")
                                ? [...slot.types, "telemedicine"]
                                : slot.types.filter((t: string) => t !== "telemedicine");
                              handleUpdateSlot(day.id, index, "types", newTypes);
                            }}
                          >
                            <Checkbox
                              id={`telemed-${day.id}-${index}`}
                              checked={slot.types.includes("telemedicine")}
                              onCheckedChange={() => {}} // Handled by parent div
                            />
                            <Label
                              htmlFor={`telemed-${day.id}-${index}`}
                              className="cursor-pointer text-sm font-normal"
                            >
                              Telemedicina
                            </Label>
                          </div>
                        </div>

                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleRemoveSlot(day.id, index)}
                          className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10 ml-auto"
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    );
                  })}
                  {dayConfig.slots.length === 0 && (
                    <p className="text-sm text-destructive pl-2">
                      Adicione pelo menos um intervalo ou desative o dia.
                    </p>
                  )}
                </div>
              )}
              <Separator />
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
