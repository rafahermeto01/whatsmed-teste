import { Megaphone, X, MessageSquare } from "lucide-react";

import { Button } from "@/components/ui/button";

interface PatientActionbarProps {
  selectedCount: number;
  onClear: () => void;
  onQuickMessage: () => void;
  onSendCampaign: () => void;
}

export function PatientActionbar({
  selectedCount,
  onClear,
  onQuickMessage,
  onSendCampaign,
}: PatientActionbarProps) {
  if (selectedCount === 0) return null;

  return (
    <div className="sticky top-0 z-20 -mx-4 px-4 py-3 bg-primary/5 border-b border-primary/20 backdrop-blur-sm">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="font-medium text-primary">
            {selectedCount} paciente{selectedCount !== 1 ? "s" : ""} selecionado
            {selectedCount !== 1 ? "s" : ""}
          </span>
          <Button variant="ghost" size="sm" onClick={onClear} className="h-7 text-xs">
            <X className="w-3 h-3 mr-1" />
            Limpar
          </Button>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={onQuickMessage}>
            <MessageSquare className="w-4 h-4 mr-2" />
            Mensagem Rápida
          </Button>
          <Button size="sm" onClick={onSendCampaign}>
            <Megaphone className="w-4 h-4 mr-2" />
            Enviar Campanha
          </Button>
        </div>
      </div>
    </div>
  );
}
