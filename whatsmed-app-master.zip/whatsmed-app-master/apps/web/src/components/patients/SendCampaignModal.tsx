import { useMutation, useQuery } from "convex/react";
import { Loader2, Megaphone, Zap, Calendar, Gift, XCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

interface SendCampaignModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  clinicId: string | undefined;
  patientIds: string[];
  patientCount: number;
  onSuccess?: () => void;
}

const TRIGGER_TYPE_ICONS: Record<string, React.ReactNode> = {
  time_after_appointment: <Calendar className="w-4 h-4" />,
  time_after_procedure: <Zap className="w-4 h-4" />,
  birthday: <Gift className="w-4 h-4" />,
  no_show: <XCircle className="w-4 h-4" />,
  custom: <Megaphone className="w-4 h-4" />,
};

const TRIGGER_TYPE_LABELS: Record<string, string> = {
  time_after_appointment: "Pós-Consulta",
  time_after_procedure: "Pós-Procedimento",
  birthday: "Aniversário",
  no_show: "Falta",
  custom: "Manual",
};

export function SendCampaignModal({
  open,
  onOpenChange,
  clinicId,
  patientIds,
  patientCount,
  onSuccess,
}: SendCampaignModalProps) {
  const [selectedCampaignId, setSelectedCampaignId] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);

  const campaigns = useQuery(
    api.automation.listCampaignsForBroadcast,
    clinicId ? { clinicId } : "skip",
  );

  const triggerCampaign = useMutation(api.automation.triggerCampaign);

  const selectedCampaign = campaigns?.find((c: any) => c._id === selectedCampaignId);

  const handleSend = async () => {
    if (!selectedCampaignId) {
      toast.error("Selecione uma campanha");
      return;
    }

    if (!clinicId) {
      toast.error("Clínica não encontrada");
      return;
    }

    if (patientIds.length === 0) {
      toast.error("Nenhum paciente selecionado");
      return;
    }

    setIsSending(true);
    try {
      const result = await triggerCampaign({
        clinicId,
        campaignId: selectedCampaignId as any,
        patientIds: patientIds as any,
      });

      const summary = [
        `${result.sent} enviado${result.sent !== 1 ? "s" : ""}`,
        result.noPhone > 0 ? `${result.noPhone} sem telefone` : null,
        result.noChat > 0 ? `${result.noChat} sem conversa` : null,
        result.failed > 0 ? `${result.failed} falhou` : null,
      ]
        .filter(Boolean)
        .join(", ");

      if (result.sent > 0) {
        toast.success(`Campanha enviada! ${summary}`);
      } else {
        toast.warning(`Nenhuma mensagem enviada: ${summary}`);
      }

      setSelectedCampaignId(null);
      onOpenChange(false);
      onSuccess?.();
    } catch (error: any) {
      console.error(error);
      toast.error(error.message || "Erro ao enviar campanha");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Enviar Campanha</DialogTitle>
          <DialogDescription>
            Selecione uma campanha ativa para enviar para {patientCount} paciente
            {patientCount !== 1 ? "s" : ""} selecionado{patientCount !== 1 ? "s" : ""}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Campanha</Label>
            <Select value={selectedCampaignId || ""} onValueChange={setSelectedCampaignId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione uma campanha" />
              </SelectTrigger>
              <SelectContent>
                {campaigns?.map((campaign: any) => (
                  <SelectItem key={campaign._id} value={campaign._id}>
                    <div className="flex items-center gap-2">
                      {TRIGGER_TYPE_ICONS[campaign.triggerType]}
                      <span>{campaign.name}</span>
                    </div>
                  </SelectItem>
                ))}
                {(!campaigns || campaigns.length === 0) && (
                  <SelectItem value="_none" disabled>
                    Nenhuma campanha ativa
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>

          {selectedCampaign && (
            <div className="space-y-3 p-3 border rounded-lg bg-muted/30">
              <div className="flex items-center justify-between">
                <span className="font-medium">{selectedCampaign.name}</span>
                <Badge variant="outline" className="gap-1">
                  {TRIGGER_TYPE_ICONS[selectedCampaign.triggerType]}
                  {TRIGGER_TYPE_LABELS[selectedCampaign.triggerType] ||
                    selectedCampaign.triggerType}
                </Badge>
              </div>

              <div className="text-sm text-muted-foreground">
                {selectedCampaign.steps.length} mensagem
                {selectedCampaign.steps.length !== 1 ? "s" : ""} na sequência
              </div>

              <ScrollArea className="h-40 rounded border bg-background">
                <div className="p-2 space-y-2">
                  {selectedCampaign.steps.map((step: any, index: any) => (
                    <div key={index} className="p-2 bg-muted/50 rounded text-xs">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium">Passo {step.order}</span>
                        {step.delayHours > 0 && (
                          <span className="text-muted-foreground">+{step.delayHours}h</span>
                        )}
                      </div>
                      <p className="text-muted-foreground line-clamp-2">{step.message}</p>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSend} disabled={isSending || !selectedCampaignId}>
            {isSending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            <Megaphone className="w-4 h-4 mr-2" />
            Enviar para {patientCount} paciente{patientCount !== 1 ? "s" : ""}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
