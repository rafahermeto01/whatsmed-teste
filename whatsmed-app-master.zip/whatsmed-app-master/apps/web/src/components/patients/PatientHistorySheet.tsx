import { useQuery } from "convex/react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Calendar, Clock, User, Stethoscope, FileText, Loader2 } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

import type { Patient } from "@/components/AddPatientModal";

interface PatientHistorySheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  patient: Patient | null;
  clinicId: string;
}

const statusConfig: Record<
  string,
  { label: string; variant: "default" | "secondary" | "destructive" | "outline" }
> = {
  pending: { label: "Pendente", variant: "secondary" },
  confirmed: { label: "Confirmado", variant: "default" },
  cancelled: { label: "Cancelado", variant: "destructive" },
  completed: { label: "Concluído", variant: "outline" },
  arrived: { label: "Chegou", variant: "default" },
};

export function PatientHistorySheet({
  open,
  onOpenChange,
  patient,
  clinicId,
}: PatientHistorySheetProps) {
  // Query appointments for this patient
  const appointmentsResult = useQuery(
    api.appointments.list,
    patient?.id && clinicId
      ? {
          clinicId,
          patientId: patient.id as any,
          limit: 50,
        }
      : "skip",
  );

  const loading = appointmentsResult === undefined;
  const appointments = appointmentsResult?.items ?? [];

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-lg">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Histórico do Paciente
          </SheetTitle>
          <SheetDescription>
            {patient?.name ? (
              <span className="font-medium text-foreground">{patient.name}</span>
            ) : (
              "Selecione um paciente"
            )}
          </SheetDescription>
        </SheetHeader>

        <ScrollArea className="h-[calc(100vh-140px)] mt-6 pr-4">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : appointments.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Calendar className="h-12 w-12 text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">Nenhuma consulta encontrada</p>
              <p className="text-sm text-muted-foreground/70">
                Este paciente ainda não possui histórico de consultas.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {appointments.map((appointment: any) => {
                const status = statusConfig[appointment.status] ?? {
                  label: appointment.status,
                  variant: "secondary" as const,
                };
                const startDate = new Date(appointment.startAt);
                const endDate = new Date(appointment.endAt);

                return (
                  <Card key={appointment._id} className="relative">
                    <CardContent className="p-4">
                      {/* Status badge */}
                      <div className="absolute top-3 right-3">
                        <Badge variant={status.variant}>{status.label}</Badge>
                      </div>

                      {/* Date and time */}
                      <div className="flex items-center gap-2 mb-3">
                        <Calendar className="h-4 w-4 text-primary" />
                        <span className="font-medium">
                          {format(startDate, "EEEE, dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                        <Clock className="h-4 w-4" />
                        <span>
                          {format(startDate, "HH:mm")} - {format(endDate, "HH:mm")}
                        </span>
                      </div>

                      {/* Doctor */}
                      {appointment.doctor && (
                        <div className="flex items-center gap-2 text-sm mb-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span>Dr(a). {appointment.doctor}</span>
                        </div>
                      )}

                      {/* Procedure */}
                      {appointment.procedure && (
                        <div className="flex items-center gap-2 text-sm mb-2">
                          <Stethoscope className="h-4 w-4 text-muted-foreground" />
                          <span>{appointment.procedure}</span>
                        </div>
                      )}

                      {/* Notes */}
                      {appointment.notes && (
                        <div className="flex items-start gap-2 text-sm mt-3 pt-3 border-t">
                          <FileText className="h-4 w-4 text-muted-foreground mt-0.5" />
                          <p className="text-muted-foreground">{appointment.notes}</p>
                        </div>
                      )}

                      {/* Telemedicine indicator */}
                      {appointment.isTelemedicine && (
                        <div className="mt-3">
                          <Badge variant="outline" className="text-xs">
                            Teleconsulta
                          </Badge>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}
