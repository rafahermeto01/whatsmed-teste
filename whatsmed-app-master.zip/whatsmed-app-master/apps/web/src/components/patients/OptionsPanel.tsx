import { format, subDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Search, Download, Plus, Upload, Settings2, Calendar as CalendarIcon } from "lucide-react";
import { type DateRange } from "react-day-picker";

import { ColumnVisibility, type ColumnDef } from "@/components/ColumnVisibility";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

interface OptionsPanelProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  statusFilter: string;
  setStatusFilter: (status: string) => void;
  hasEmail: "any" | "yes" | "no";
  setHasEmail: (val: "any" | "yes" | "no") => void;
  hasPhone: "any" | "yes" | "no";
  setHasPhone: (val: "any" | "yes" | "no") => void;
  dateRange: DateRange | undefined;
  setDateRange: (range: DateRange | undefined) => void;
  logic: "and" | "or";
  setLogic: (val: "and" | "or") => void;
  onClearFilters: () => void;
  onAddPatient: () => void;
  onImportCSV: () => void;
  onExportCSV: () => void;
  columns: ColumnDef[];
  setColumns: (cols: ColumnDef[]) => void;
  storageKey: string;
}

export function OptionsPanel({
  searchTerm,
  setSearchTerm,
  statusFilter,
  setStatusFilter,
  hasEmail,
  setHasEmail,
  hasPhone,
  setHasPhone,
  dateRange,
  setDateRange,
  logic,
  setLogic,
  onClearFilters,
  onAddPatient,
  onImportCSV,
  onExportCSV,
  columns,
  setColumns,
  storageKey,
}: OptionsPanelProps) {
  return (
    <Card className="h-fit w-full border-none shadow-none lg:border lg:shadow-sm">
      <CardHeader className="pb-3 px-0 lg:px-6 pt-0">
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <Settings2 className="h-5 w-5" />
          Controles
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6 px-0 lg:px-6">
        {/* Section 1: Ações */}
        <div className="space-y-2">
          <Label className="text-xs font-semibold text-muted-foreground uppercase">Ações</Label>
          <Button className="w-full justify-start" onClick={onAddPatient}>
            <Plus className="mr-2 h-4 w-4" /> Novo Paciente
          </Button>
          <Button variant="outline" className="w-full justify-start" onClick={onImportCSV}>
            <Upload className="mr-2 h-4 w-4" /> Importar CSV
          </Button>
        </div>

        <Separator />

        {/* Section 2: Busca */}
        <div className="space-y-2">
          <Label className="text-xs font-semibold text-muted-foreground uppercase">Busca</Label>
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Nome ou telefone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>

        <Separator />

        {/* Section 3: Filtros */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label className="text-xs font-semibold text-muted-foreground uppercase">Filtros</Label>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearFilters}
              className="h-auto p-0 text-xs text-muted-foreground hover:text-destructive"
            >
              Limpar
            </Button>
          </div>

          <div className="space-y-2">
            <Label>Status</Label>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="active">Ativos</SelectItem>
                <SelectItem value="inactive">Inativos</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Período</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !dateRange && "text-muted-foreground",
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateRange?.from ? (
                    dateRange.to ? (
                      <>
                        {format(dateRange.from, "dd/MM/yyyy")} -{" "}
                        {format(dateRange.to, "dd/MM/yyyy")}
                      </>
                    ) : (
                      format(dateRange.from, "dd/MM/yyyy")
                    )
                  ) : (
                    <span>Selecione um período</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <div className="flex flex-col sm:flex-row">
                  <div className="p-3 border-b sm:border-b-0 sm:border-r space-y-2 flex flex-col">
                    <span className="text-sm font-medium text-muted-foreground mb-1">Período</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="justify-start font-normal"
                      onClick={() => setDateRange({ from: new Date(), to: new Date() })}
                    >
                      Hoje
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="justify-start font-normal"
                      onClick={() => setDateRange({ from: subDays(new Date(), 6), to: new Date() })}
                    >
                      Últimos 7 dias
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="justify-start font-normal"
                      onClick={() =>
                        setDateRange({ from: subDays(new Date(), 29), to: new Date() })
                      }
                    >
                      Últimos 30 dias
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="justify-start font-normal"
                      onClick={() =>
                        setDateRange({ from: subDays(new Date(), 89), to: new Date() })
                      }
                    >
                      Últimos 90 dias
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="justify-start font-normal text-muted-foreground"
                      onClick={() => setDateRange(undefined)}
                    >
                      Limpar
                    </Button>
                  </div>
                  <Calendar
                    initialFocus
                    mode="range"
                    defaultMonth={dateRange?.from}
                    selected={dateRange}
                    onSelect={setDateRange}
                    numberOfMonths={2}
                    locale={ptBR}
                  />
                </div>
              </PopoverContent>
            </Popover>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-2">
              <Label>Email</Label>
              <Select value={hasEmail} onValueChange={(v) => setHasEmail(v as any)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any">Qualquer</SelectItem>
                  <SelectItem value="yes">Com Email</SelectItem>
                  <SelectItem value="no">Sem Email</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Telefone</Label>
              <Select value={hasPhone} onValueChange={(v) => setHasPhone(v as any)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any">Qualquer</SelectItem>
                  <SelectItem value="yes">Com Tel.</SelectItem>
                  <SelectItem value="no">Sem Tel.</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center justify-between rounded-lg border p-3 shadow-sm">
            <div className="space-y-0.5">
              <Label>Lógica de Filtro</Label>
              <div className="text-xs text-muted-foreground">
                {logic === "and" ? "Todas (AND)" : "Qualquer (OR)"}
              </div>
            </div>
            <Switch
              checked={logic === "or"}
              onCheckedChange={(checked) => setLogic(checked ? "or" : "and")}
            />
          </div>
        </div>

        <Separator />

        {/* Section 4: Visualização */}
        <div className="space-y-2">
          <Label className="text-xs font-semibold text-muted-foreground uppercase">
            Visualização
          </Label>
          <div className="w-full">
            <ColumnVisibility columns={columns} onChange={setColumns} storageKey={storageKey} />
          </div>
        </div>

        <Separator />

        {/* Section 5: Exportação */}
        <div className="space-y-2">
          <Label className="text-xs font-semibold text-muted-foreground uppercase">
            Exportação
          </Label>
          <Button variant="secondary" className="w-full justify-start" onClick={onExportCSV}>
            <Download className="mr-2 h-4 w-4" /> Exportar CSV
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
