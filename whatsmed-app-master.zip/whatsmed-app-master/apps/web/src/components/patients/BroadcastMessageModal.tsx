import { useMutation, useQuery } from "convex/react";
import { Loader2 } from "lucide-react";
import { useState, useRef } from "react";
import { toast } from "sonner";

import { VariableInserter } from "@/components/automation/VariableInserter";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

interface BroadcastMessageModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  clinicId: string | undefined;
  patientIds: string[];
  patientCount: number;
  onSuccess?: () => void;
}

export function BroadcastMessageModal({
  open,
  onOpenChange,
  clinicId,
  patientIds,
  patientCount,
  onSuccess,
}: BroadcastMessageModalProps) {
  const [message, setMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const clinic = useQuery(api.clinics.getClinic, clinicId ? { clinicId } : "skip");

  const sendBroadcast = useMutation(api.automation.sendBroadcast);

  const handleInsertVariable = (variable: string) => {
    if (textareaRef.current) {
      const start = textareaRef.current.selectionStart;
      const end = textareaRef.current.selectionEnd;
      const newText = message.substring(0, start) + variable + message.substring(end);
      setMessage(newText);

      setTimeout(() => {
        textareaRef.current?.focus();
        textareaRef.current?.setSelectionRange(start + variable.length, start + variable.length);
      }, 0);
    }
  };

  const handleSend = async () => {
    if (!message.trim()) {
      toast.error("Digite uma mensagem");
      return;
    }

    if (!clinicId) {
      toast.error("Clínica não encontrada");
      return;
    }

    if (patientIds.length === 0) {
      toast.error("Nenhum paciente selecionado");
      return;
    }

    setIsSending(true);
    try {
      const result = await sendBroadcast({
        clinicId,
        patientIds: patientIds as any,
        message: message.trim(),
      });

      const summary = [
        `${result.sent} enviado${result.sent !== 1 ? "s" : ""}`,
        result.noPhone > 0 ? `${result.noPhone} sem telefone` : null,
        result.noChat > 0 ? `${result.noChat} sem conversa` : null,
        result.failed > 0 ? `${result.failed} falhou` : null,
      ]
        .filter(Boolean)
        .join(", ");

      if (result.sent > 0) {
        toast.success(`Mensagem enviada! ${summary}`);
      } else {
        toast.warning(`Nenhuma mensagem enviada: ${summary}`);
      }

      setMessage("");
      onOpenChange(false);
      onSuccess?.();
    } catch (error: any) {
      console.error(error);
      toast.error(error.message || "Erro ao enviar mensagem");
    } finally {
      setIsSending(false);
    }
  };

  const previewMessage = message
    .replace(/{{patient\.name}}/gi, "João Silva")
    .replace(/{{patient\.phone}}/gi, "(11) 99999-9999")
    .replace(/{{patient\.email}}/gi, "joao@email.com")
    .replace(/{{clinic\.name}}/gi, clinic?.name || "Clínica")
    .replace(/{{clinic\.phone}}/gi, clinic?.phone || "(11) 3333-3333")
    .replace(/{{clinic\.address}}/gi, clinic?.address || "Rua Exemplo, 123")
    .replace(/{{date\.today}}/gi, new Date().toLocaleDateString("pt-BR"))
    .replace(
      /{{date\.now}}/gi,
      new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
    );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Mensagem Rápida</DialogTitle>
          <DialogDescription>
            Enviar mensagem para {patientCount} paciente{patientCount !== 1 ? "s" : ""} selecionado
            {patientCount !== 1 ? "s" : ""}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <Label>Mensagem</Label>
              <VariableInserter onInsert={handleInsertVariable} />
            </div>
            <Textarea
              ref={textareaRef}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Olá {{patient.name}}! Gostaríamos de lembrar..."
              rows={5}
              className="resize-none"
            />
          </div>

          {message && (
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Pré-visualização</Label>
              <div className="p-3 bg-muted/50 rounded-md text-sm whitespace-pre-wrap">
                {previewMessage}
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSend} disabled={isSending || !message.trim()}>
            {isSending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Enviar para {patientCount} paciente{patientCount !== 1 ? "s" : ""}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
