import { useQuery } from "convex/react";
import { Lock } from "lucide-react";
import { useState } from "react";

import { PlanSelectionModal } from "@/components/billing/PlanSelectionModal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useBillingPaymentMethods } from "@/hooks/billing";
import { useClinic } from "@/hooks/clinics";
import { useClinicId } from "@/hooks/patients";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

type PlanFeature =
  | "appointments"
  | "advancedAi"
  | "integrations"
  | "nps"
  | "checkin"
  | "telemedicine"
  | "apiAccess";

interface PlanGateProps {
  feature: PlanFeature;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export function PlanGate({ feature, children, fallback }: PlanGateProps) {
  const { clinicId } = useClinicId();
  const clinic = useClinic(clinicId);
  const [showPlanModal, setShowPlanModal] = useState(false);
  const paymentMethods = useBillingPaymentMethods(clinicId);
  const hasCard = (paymentMethods?.length ?? 0) > 0;

  const access = useQuery(
    api.planEnforcement.checkFeatureAccessPublic,
    clinicId ? { clinicId, feature } : "skip",
  );

  if (!clinicId || access === undefined) {
    return null; // Loading state
  }

  if (!access.allowed) {
    if (fallback) {
      return <>{fallback}</>;
    }

    return (
      <>
        <Card className="border-yellow-500/50 bg-yellow-500/5">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Lock className="h-5 w-5 text-yellow-600" />
              <CardTitle>Recurso Disponível no Plano {access.requiredPlan}</CardTitle>
            </div>
            <CardDescription>
              Este recurso está disponível apenas para planos {access.requiredPlan} ou superiores.
              Faça upgrade para desbloquear.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => setShowPlanModal(true)}>Fazer Upgrade</Button>
          </CardContent>
        </Card>

        {clinic && (
          <PlanSelectionModal
            open={showPlanModal}
            onOpenChange={setShowPlanModal}
            clinicId={clinicId}
            currentPlan={clinic.plan || "free"}
            hasCard={hasCard}
            onNeedCard={() => {
              // Could navigate to billing page or show card modal
              setShowPlanModal(false);
            }}
          />
        )}
      </>
    );
  }

  return <>{children}</>;
}
