import { Copy, Video, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface TelehealthModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  patientName: string;
  meetingLink?: string;
}

export function TelehealthModal({
  open,
  onOpenChange,
  patientName,
  meetingLink,
}: TelehealthModalProps) {
  const handleCopyLink = () => {
    if (meetingLink) {
      navigator.clipboard.writeText(meetingLink);
      toast.success("Link copiado para a área de transferência");
    }
  };

  const handleJoinCall = () => {
    if (meetingLink) {
      window.open(meetingLink, "_blank", "noopener,noreferrer");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] flex flex-col">
        <DialogHeader>
          <DialogTitle>Teleconsulta - {patientName}</DialogTitle>
          <DialogDescription>
            {meetingLink
              ? "Clique no botão abaixo para entrar na sala de vídeo."
              : "O link da reunião ainda não foi gerado."}
          </DialogDescription>
        </DialogHeader>

        {meetingLink ? (
          <>
            <div className="bg-muted p-4 rounded-lg flex items-center justify-between">
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-medium text-muted-foreground uppercase">
                  Link da Sala
                </span>
                <span className="font-mono text-sm truncate">{meetingLink}</span>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={handleCopyLink}
                className="ml-3 shrink-0"
              >
                <Copy className="w-4 h-4 mr-2" />
                Copiar
              </Button>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Cancelar
              </Button>
              <Button onClick={handleJoinCall} className="bg-green-600 hover:bg-green-700">
                <Video className="w-4 h-4 mr-2" />
                Iniciar Atendimento
              </Button>
            </DialogFooter>
          </>
        ) : (
          <div className="py-8 flex flex-col items-center gap-3 text-center">
            <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
            <p className="text-sm text-muted-foreground">
              Aguardando geração do link. Verifique se o Google Calendar está conectado.
            </p>
            <DialogFooter className="w-full pt-4">
              <Button variant="outline" onClick={() => onOpenChange(false)} className="w-full">
                Fechar
              </Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
