import { useMutation, useQuery, useAction } from "convex/react";
import { Bell, CheckCircle2, Clock, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

interface WaitlistEntry {
  _id: string;
  patientId: string;
  patientName: string;
  phone: string;
  avatarUrl?: string;
  priority: number;
  since: string;
  requestedAt: number;
  status: "waiting" | "notified" | "assigned";
  notifiedAt?: number;
  doctorId: string;
  appointmentId?: string;
  appointment?: {
    _id: string;
    startAt: number;
    endAt: number;
    status: string;
  };
  notes?: string;
  tags: string[];
}

interface WaitlistSectionProps {
  clinicId?: string;
}

export function WaitlistSection({ clinicId }: WaitlistSectionProps) {
  const waitlistData = useQuery(
    api.waitlists.listWaitlist,
    clinicId
      ? {
          clinicId,
          status: "waiting",
          paginationOpts: { numItems: 50, cursor: undefined },
        }
      : "skip",
  );

  const notifyPatient = useMutation(api.waitlists.notifyPatient);
  const sendNotification = useAction(api.waitlists.sendWaitlistNotification);

  const handleNotify = async (entry: WaitlistEntry) => {
    try {
      await notifyPatient({ waitlistId: entry._id });
      toast.success("Paciente notificado com sucesso!");
    } catch (error: any) {
      toast.error(error.message || "Erro ao notificar paciente");
      return;
    }

    // Send WhatsApp notification
    try {
      await sendNotification({
        waitlistId: entry._id,
      });
    } catch (error) {
      console.error("Failed to send WhatsApp notification:", error);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Fila de Espera (Prioridade)</h3>
        <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-100">
          {waitlistData?.items.length || 0} aguardando
        </Badge>
      </div>

      {!waitlistData ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      ) : waitlistData.items.length === 0 ? (
        <Card className="p-8 text-center">
          <p className="text-sm text-muted-foreground">Nenhum paciente na fila de espera</p>
        </Card>
      ) : (
        <div className="space-y-3">
          {waitlistData.items.map((entry: any) => (
            <Card
              key={entry._id}
              className="p-3 flex items-center justify-between hover:shadow-sm transition-shadow"
            >
              <div className="flex items-center gap-3">
                <div className="font-mono text-sm font-bold text-muted-foreground w-4 text-center">
                  {entry.priority}
                </div>
                <Avatar className="h-9 w-9">
                  {entry.avatarUrl ? (
                    <AvatarImage src={entry.avatarUrl} alt={entry.patientName} />
                  ) : (
                    <AvatarFallback className="bg-primary/10 text-primary text-xs">
                      {entry.patientName.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  )}
                </Avatar>
                <div>
                  <p className="text-sm font-medium leading-none">{entry.patientName}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {entry.since}
                    </span>
                    {entry.tags.map((tag: any) => (
                      <Badge key={tag} variant="outline" className="text-[10px] h-4 px-1 py-0">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {entry.status === "waiting" && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8"
                    onClick={() => handleNotify(entry)}
                  >
                    <Bell className="w-3 h-3 mr-1" /> Notificar
                  </Button>
                )}
                {entry.status === "notified" && (
                  <Badge variant="secondary" className="bg-yellow-100 text-yellow-700 border-none">
                    <Clock className="w-3 h-3 mr-1" /> Notificado
                  </Badge>
                )}
                {entry.status === "assigned" && (
                  <Badge variant="secondary" className="bg-green-100 text-green-700 border-none">
                    <CheckCircle2 className="w-3 h-3 mr-1" /> Agendado
                  </Badge>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
