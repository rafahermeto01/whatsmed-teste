import { useQuery, useAction } from "convex/react";
import { Calendar, Clock, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

interface RescheduleSuggestionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  patientId: string;
  appointmentId: string;
  doctorId: string;
  clinicId: string;
}

export function RescheduleSuggestionModal({
  open,
  onOpenChange,
  patientId,
  appointmentId,
  doctorId: _doctorId,
  clinicId,
}: RescheduleSuggestionModalProps) {
  const [selectedSlot, setSelectedSlot] = useState<string>("");

  // Fetch appointment to get procedureId
  const appointment = useQuery(
    api.appointments.getById,
    open && appointmentId
      ? {
          id: appointmentId as any,
          clinicId,
        }
      : "skip",
  );

  // Fetch available slots from backend (mode 3: first 5 slots in time range)
  const availableSlots = useQuery(
    api.appointments.getAvailableSlots,
    open && appointment?.procedureId && appointment.doctorId
      ? {
          clinicId,
          doctorId: appointment.doctorId,
          procedureId: appointment.procedureId,
          startTime: new Date().toISOString(),
          endTime: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // Next 7 days
        }
      : "skip",
  );
  const loadingSlots = (availableSlots === undefined && open) || appointment === undefined;

  const sendRescheduleOptions = useAction(api.appointments.sendRescheduleOptions);

  const handleConfirm = async () => {
    if (!selectedSlot) return;
    try {
      const slotsArray = Array.isArray(availableSlots) ? availableSlots : [];
      const slot = slotsArray[parseInt(selectedSlot) - 1];
      if (!slot) {
        toast.error("Opção selecionada inválida");
        return;
      }

      await sendRescheduleOptions({
        patientId: patientId as any,
        appointmentId: appointmentId as any,
        availableSlots: slotsArray,
        clinicId,
      });

      toast.success("Sugestão de horário enviada para o paciente via WhatsApp!");
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message || "Erro ao enviar opções de reagendamento");
    }
  };

  const handleSendAll = async () => {
    const slotsArray = Array.isArray(availableSlots) ? availableSlots : [];
    if (slotsArray.length === 0) {
      toast.error("Nenhum horário disponível encontrado");
      return;
    }

    try {
      await sendRescheduleOptions({
        patientId: patientId as any,
        appointmentId: appointmentId as any,
        availableSlots: slotsArray,
        clinicId,
      });

      toast.success("Enviando as 3 opções para o paciente...");
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message || "Erro ao enviar opções de reagendamento");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Sugestão de Reagendamento</DialogTitle>
        </DialogHeader>

        <div className="py-4 space-y-4">
          {loadingSlots ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : !appointment?.procedureId ? (
            <p className="text-sm text-muted-foreground text-center py-4">
              Não é possível reagendar: a consulta não possui procedimento associado.
            </p>
          ) : !availableSlots || (Array.isArray(availableSlots) && availableSlots.length === 0) ? (
            <p className="text-sm text-muted-foreground text-center py-4">
              Nenhum horário disponível nos próximos 7 dias
            </p>
          ) : (
            <>
              <p className="text-sm text-muted-foreground">
                Selecione um horário abaixo para oferecer ao paciente ou envie todas as opções.
              </p>

              <RadioGroup value={selectedSlot} onValueChange={setSelectedSlot} className="gap-3">
                {(Array.isArray(availableSlots) ? availableSlots : [])
                  .slice(0, 3)
                  .map((slot, index) => {
                    const start = new Date(slot.start);
                    const dateStr = start.toLocaleDateString("pt-BR", {
                      day: "2-digit",
                      month: "2-digit",
                    });
                    const timeStr = start.toLocaleTimeString("pt-BR", {
                      hour: "2-digit",
                      minute: "2-digit",
                    });

                    return (
                      <div
                        key={index}
                        className="flex items-center space-x-2 border p-3 rounded-md hover:bg-muted/50 transition-colors"
                      >
                        <RadioGroupItem value={(index + 1).toString()} id={`slot-${index}`} />
                        <Label
                          htmlFor={`slot-${index}`}
                          className="flex-1 cursor-pointer flex justify-between items-center"
                        >
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-muted-foreground" />
                            <span>{dateStr}</span>
                          </div>
                          <div className="flex items-center gap-2 font-semibold">
                            <Clock className="w-4 h-4 text-muted-foreground" />
                            <span>{timeStr}</span>
                          </div>
                        </Label>
                      </div>
                    );
                  })}
              </RadioGroup>
            </>
          )}
        </div>

        <DialogFooter className="flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            onClick={handleSendAll}
            disabled={
              loadingSlots ||
              !availableSlots ||
              !Array.isArray(availableSlots) ||
              availableSlots.length === 0 ||
              !appointment?.procedureId
            }
          >
            Enviar Todas as Opções
          </Button>
          <Button
            onClick={handleConfirm}
            disabled={!selectedSlot || loadingSlots || !appointment?.procedureId}
          >
            Confirmar Seleção
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
