import { useMutation, useQuery } from "convex/react";
import { RefreshCw } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";

import { useEffectiveAppUser } from "@/hooks/patients";
import { cn } from "@/lib/utils";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

interface ClinicQRCodeProps {
  clinicId: string;
  size?: number;
  className?: string;
}

export function ClinicQRCode({ clinicId, size = 256, className }: ClinicQRCodeProps) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);
  const isGeneratingRef = useRef(false);
  const nearExpiryTriggeredRef = useRef(false);
  const missingQrTriggeredRef = useRef(false);

  // Get current user for userId
  const appUser = useEffectiveAppUser();
  const userId = appUser?._id;

  // Query active totem QR code
  const activeQR = useQuery(api.checkin.getActiveTotemQR, { clinicId });

  // Mutation to generate new QR code
  const generateQR = useMutation(api.checkin.generateTotemQR);

  useEffect(() => {
    isGeneratingRef.current = isGenerating;
  }, [isGenerating]);

  const handleGenerateQR = useCallback(async () => {
    if (!userId) {
      console.warn("Cannot generate QR: userId not available yet");
      return;
    }
    if (isGeneratingRef.current) {
      return;
    }

    isGeneratingRef.current = true;
    try {
      setIsGenerating(true);
      await generateQR({
        clinicId,
        userId,
        expiresInMinutes: 15, // QR expires in 15 minutes
      });
      toast.success("Novo QR Code gerado");
    } catch (error: any) {
      console.error("Error generating QR code:", error);
      toast.error(error.message || "Erro ao gerar QR Code");
    } finally {
      isGeneratingRef.current = false;
      setIsGenerating(false);
    }
  }, [clinicId, generateQR, userId]);

  // Auto-refresh QR code when it's about to expire (30 seconds before)
  useEffect(() => {
    // Wait for userId to be available before generating
    if (!userId) return;

    if (!activeQR) {
      // No active QR, generate one
      setTimeLeft(0);
      if (!missingQrTriggeredRef.current) {
        missingQrTriggeredRef.current = true;
        void handleGenerateQR();
      }
      return;
    }
    missingQrTriggeredRef.current = false;

    // Calculate time remaining
    const now = Date.now();
    const remaining = Math.max(0, activeQR.remainingSeconds);

    setTimeLeft(remaining);

    if (remaining > 30) {
      nearExpiryTriggeredRef.current = false;
    } else if (!nearExpiryTriggeredRef.current && !isGeneratingRef.current) {
      nearExpiryTriggeredRef.current = true;
      void handleGenerateQR();
    }

    // Update timer every second
    const timer = setInterval(() => {
      const elapsed = Math.floor((Date.now() - now) / 1000);
      const newRemaining = Math.max(0, remaining - elapsed);
      setTimeLeft(newRemaining);

      if (newRemaining > 30) {
        nearExpiryTriggeredRef.current = false;
      } else if (!nearExpiryTriggeredRef.current && !isGeneratingRef.current) {
        nearExpiryTriggeredRef.current = true;
        void handleGenerateQR();
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [activeQR, handleGenerateQR, userId]);

  const handleManualRefresh = () => {
    handleGenerateQR();
  };

  if (!userId || !activeQR || isGenerating) {
    return (
      <div className={cn("flex flex-col items-center gap-4", className)}>
        <div className="relative p-4 bg-white rounded-xl shadow-lg border-2 border-primary/20 min-w-[300px] h-[300px] flex items-center justify-center">
          <RefreshCw className="w-12 h-12 text-muted-foreground animate-spin" />
        </div>
        <p className="text-sm text-muted-foreground">
          {!userId
            ? "Carregando usuário..."
            : isGenerating
              ? "Gerando QR Code..."
              : "Carregando QR Code..."}
        </p>
      </div>
    );
  }

  // QR code only contains the validation token - NO session token
  // Session must be authenticated via WhatsApp link separately
  // This ensures security: only patients with valid WhatsApp link can check-in
  const qrCodeValue = activeQR.qrCode;

  return (
    <div className={cn("flex flex-col items-center gap-4", className)}>
      <div className="relative p-4 bg-white rounded-xl shadow-lg border-2 border-primary/20">
        <div className="bg-white flex items-center justify-center relative overflow-hidden">
          <QRCodeSVG value={qrCodeValue} size={size} level="H" includeMargin={true} />
          {/* Security Overlay */}
          <div className="absolute inset-0 pointer-events-none opacity-10 bg-[url('https://www.transparenttextures.com/patterns/diagmonds-light.png')]" />
        </div>

        {/* Timer Ring */}
        <div className="absolute -top-4 -right-4 bg-primary text-primary-foreground font-bold w-14 h-14 flex items-center justify-center rounded-full shadow-md border-2 border-white">
          <div className="text-center">
            <div className="text-base font-bold">
              {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, "0")}
            </div>
          </div>
        </div>
      </div>

      {/* Status Bar */}
      <div className="w-full max-w-[300px] bg-slate-100 dark:bg-slate-800 rounded-lg p-3 space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Status:</span>
          <span className="text-green-600 font-medium flex items-center gap-1">
            <div className="w-2 h-2 bg-green-600 rounded-full animate-pulse" />
            Ativo
          </span>
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Expira:</span>
          <span className="font-medium text-slate-900 dark:text-slate-100">
            {activeQR.expiresAtFormatted}
          </span>
        </div>
      </div>

      {/* Refresh Button */}
      <button
        onClick={handleManualRefresh}
        disabled={isGenerating}
        className={cn(
          "flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors",
          isGenerating && "opacity-50 cursor-not-allowed",
        )}
      >
        <RefreshCw className={cn("w-3 h-3", isGenerating && "animate-spin")} />
        <span>Atualizar manualmente</span>
      </button>
    </div>
  );
}
