import { useMutation } from "convex/react";
import { Plus, Trash2, Info } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { toast } from "sonner";

import { VariableInserter } from "@/components/automation/VariableInserter";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useEffectiveCurrentUser } from "@/hooks/patients";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

// Trigger type configuration
const TRIGGER_TYPES = {
  time_after_appointment: {
    label: "Após Consulta",
    description: "Dispara X horas após a consulta ser concluída",
    needsDelay: true,
    delayLabel: "Horas após o término",
    defaultDelay: 24,
  },
  time_after_procedure: {
    label: "Após Procedimento",
    description: "Dispara X horas após um procedimento específico",
    needsDelay: true,
    delayLabel: "Horas após o procedimento",
    defaultDelay: 48,
  },
  birthday: {
    label: "Aniversário",
    description: "Dispara automaticamente no dia do aniversário do paciente",
    needsDelay: false,
    delayLabel: "",
    defaultDelay: 0,
  },
  no_show: {
    label: "Falta",
    description: "Dispara quando o paciente falta à consulta",
    needsDelay: true,
    delayLabel: "Horas após a falta",
    defaultDelay: 2,
  },
  custom: {
    label: "Manual (Tag)",
    description: "Dispara manualmente quando uma tag é adicionada",
    needsDelay: false,
    delayLabel: "",
    defaultDelay: 0,
  },
} as const;

type TriggerType = keyof typeof TRIGGER_TYPES;

interface CampaignStep {
  message: string;
  delayHours: number;
  order?: number;
  channel?: string;
}

interface CampaignData {
  _id: string;
  name: string;
  triggerType: TriggerType;
  triggerDelayHours?: number;
  steps: CampaignStep[];
}

interface CampaignBuilderModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingCampaign?: CampaignData | null;
}

export function CampaignBuilderModal({
  open,
  onOpenChange,
  editingCampaign,
}: CampaignBuilderModalProps) {
  const user = useEffectiveCurrentUser();
  const createCampaign = useMutation(api.automation.createCampaign);
  const updateCampaign = useMutation(api.automation.updateCampaign);

  const [name, setName] = useState("");
  const [triggerType, setTriggerType] = useState<TriggerType>("time_after_appointment");
  const [triggerDelayHours, setTriggerDelayHours] = useState(24);
  const [steps, setSteps] = useState([{ message: "", delayHours: 0 }]);

  const stepRefs = useRef<(HTMLTextAreaElement | null)[]>([]);

  const isEditing = !!editingCampaign;

  // Initialize form with editing campaign data
  useEffect(() => {
    if (editingCampaign && open) {
      setName(editingCampaign.name);
      setTriggerType(editingCampaign.triggerType as TriggerType);
      setTriggerDelayHours(
        editingCampaign.triggerDelayHours ||
          TRIGGER_TYPES[editingCampaign.triggerType as TriggerType].defaultDelay,
      );
      setSteps(
        editingCampaign.steps.map((s) => ({
          message: s.message,
          delayHours: s.delayHours,
        })),
      );
    }
  }, [editingCampaign, open]);

  const handleTriggerTypeChange = (value: TriggerType) => {
    setTriggerType(value);
    setTriggerDelayHours(TRIGGER_TYPES[value].defaultDelay);
  };

  const addStep = () => {
    setSteps([...steps, { message: "", delayHours: 0 }]);
  };

  const removeStep = (index: number) => {
    if (steps.length > 1) {
      setSteps(steps.filter((_, i) => i !== index));
    }
  };

  const updateStep = (index: number, field: string, value: any) => {
    const newSteps = [...steps];
    newSteps[index] = { ...newSteps[index], [field]: value };
    setSteps(newSteps);
  };

  const resetForm = () => {
    setName("");
    setTriggerType("time_after_appointment");
    setTriggerDelayHours(24);
    setSteps([{ message: "", delayHours: 0 }]);
  };

  const handleSave = async () => {
    if (!name.trim()) {
      toast.error("Nome da campanha é obrigatório");
      return;
    }

    if (steps.some((s) => !s.message.trim())) {
      toast.error("Todas as mensagens são obrigatórias");
      return;
    }

    if (!user?.clinicId) {
      toast.error("Erro: Clínica não encontrada");
      return;
    }

    const stepsData = steps.map((s, index) => ({
      order: index + 1,
      channel: "whatsapp" as const,
      message: s.message.trim(),
      delayHours: s.delayHours,
    }));

    try {
      if (isEditing && editingCampaign) {
        // Update existing campaign
        await updateCampaign({
          clinicId: user.clinicId,
          campaignId: editingCampaign._id as any,
          name: name.trim(),
          triggerType: triggerType,
          triggerDelayHours: TRIGGER_TYPES[triggerType].needsDelay ? triggerDelayHours : undefined,
          steps: stepsData,
        });
        toast.success("Campanha atualizada com sucesso!");
      } else {
        // Create new campaign
        await createCampaign({
          clinicId: user.clinicId,
          name: name.trim(),
          triggerType: triggerType,
          triggerDelayHours: TRIGGER_TYPES[triggerType].needsDelay ? triggerDelayHours : undefined,
          steps: stepsData,
        });
        toast.success("Campanha criada com sucesso!");
      }

      onOpenChange(false);
      resetForm();
    } catch (error) {
      console.error(error);
      toast.error(isEditing ? "Erro ao atualizar campanha" : "Erro ao criar campanha");
    }
  };

  const insertVariable = (index: number, variable: string) => {
    const ref = stepRefs.current[index];
    if (ref) {
      const start = ref.selectionStart;
      const end = ref.selectionEnd;
      const text = steps[index].message;
      const newText = text.substring(0, start) + variable + text.substring(end);

      updateStep(index, "message", newText);

      setTimeout(() => {
        ref.focus();
        const newCursorPos = start + variable.length;
        ref.setSelectionRange(newCursorPos, newCursorPos);
      }, 0);
    }
  };

  const currentTrigger = TRIGGER_TYPES[triggerType];

  return (
    <Dialog
      open={open}
      onOpenChange={(isOpen) => {
        if (!isOpen) resetForm();
        onOpenChange(isOpen);
      }}
    >
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Editar Campanha" : "Nova Campanha de Engajamento"}
          </DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Modifique as configurações da campanha existente."
              : "Crie uma sequência de mensagens automáticas para seus pacientes."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Label>Nome da Campanha</Label>
            <Input
              placeholder="Ex: Pós-Operatório Catarata"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Gatilho de Início</Label>
                <Select value={triggerType} onValueChange={handleTriggerTypeChange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(TRIGGER_TYPES).map(([key, config]) => (
                      <SelectItem key={key} value={key}>
                        {config.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {currentTrigger.needsDelay && (
                <div className="space-y-2">
                  <Label>{currentTrigger.delayLabel}</Label>
                  <Input
                    type="number"
                    min="0"
                    value={triggerDelayHours}
                    onChange={(e) =>
                      setTriggerDelayHours(Math.max(0, parseInt(e.target.value) || 0))
                    }
                  />
                </div>
              )}
            </div>

            <div className="flex items-start gap-2 p-3 bg-muted/50 rounded-md">
              <Info className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
              <p className="text-xs text-muted-foreground">{currentTrigger.description}</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Sequência de Mensagens</Label>
              <Button variant="outline" size="sm" onClick={addStep}>
                <Plus className="w-4 h-4 mr-2" /> Adicionar Passo
              </Button>
            </div>

            {steps.map((step, index) => (
              <div key={index} className="p-4 border rounded-lg space-y-3 bg-muted/20">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Passo {index + 1}</span>
                  {steps.length > 1 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive h-8 w-8 p-0"
                      onClick={() => removeStep(index)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <Label className="text-xs">Mensagem</Label>
                    <VariableInserter onInsert={(v) => insertVariable(index, v)} />
                  </div>
                  <Textarea
                    ref={(el) => {
                      stepRefs.current[index] = el;
                    }}
                    value={step.message}
                    onChange={(e) => updateStep(index, "message", e.target.value)}
                    placeholder="Olá {{patient.name}}..."
                    rows={3}
                  />
                </div>

                {index > 0 && (
                  <div className="flex items-center gap-2">
                    <Label className="text-xs whitespace-nowrap">Esperar (horas):</Label>
                    <Input
                      type="number"
                      min="0"
                      step="0.5"
                      value={step.delayHours}
                      onChange={(e) =>
                        updateStep(index, "delayHours", parseFloat(e.target.value) || 0)
                      }
                      className="w-24 h-8"
                    />
                    <span className="text-xs text-muted-foreground">após passo anterior</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave}>
            {isEditing ? "Atualizar Campanha" : "Salvar Campanha"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
