import { Braces } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

export const AVAILABLE_VARIABLES = [
  { label: "Nome do Paciente", value: "{{patient.name}}", desc: "Ex: João Silva" },
  { label: "Telefone do Paciente", value: "{{patient.phone}}", desc: "Ex: +5511999999999" },
  { label: "Email do Paciente", value: "{{patient.email}}", desc: "Ex: joao@email.com" },
  { label: "CPF do Paciente", value: "{{patient.cpf}}", desc: "Ex: 123.456.789-00" },
  { label: "Nome da Clínica", value: "{{clinic.name}}", desc: "Ex: Clínica Saúde" },
  { label: "Endereço da Clínica", value: "{{clinic.address}}", desc: "Ex: Av. Paulista, 1000" },
  { label: "Site da Clínica", value: "{{clinic.website}}", desc: "Ex: www.clinica.com.br" },
  { label: "Data de Hoje", value: "{{date.today}}", desc: "Ex: 24/10/2024" },
  { label: "Hora Atual", value: "{{date.now}}", desc: "Ex: 14:30" },
  { label: "Dia da Semana", value: "{{date.weekday}}", desc: "Ex: segunda-feira" },
  { label: "Data da Consulta", value: "{{appointment.date}}", desc: "Ex: 25/10/2024" },
  { label: "Hora da Consulta", value: "{{appointment.time}}", desc: "Ex: 15:00" },
  { label: "Procedimento", value: "{{appointment.procedure}}", desc: "Ex: Consulta" },
  { label: "Tipo da Consulta", value: "{{appointment.type}}", desc: "Ex: Teleconsulta" },
  {
    label: "Link da Teleconsulta",
    value: "{{appointment.meetingLink}}",
    desc: "Ex: https://meet.google.com/...",
  },
  { label: "Nome do Doutor", value: "{{doctor.name}}", desc: "Ex: Dr. Pedro" },
  { label: "Opções de Reagendamento", value: "{{reschedule.options}}", desc: "Lista formatada" },
  { label: "Motivo do Cancelamento", value: "{{cancellation.reason}}", desc: "Texto opcional" },
  { label: "Link Google Review", value: "{{nps.googleMapsLink}}", desc: "URL do Google" },
  { label: "Nota NPS", value: "{{nps.score}}", desc: "Ex: 4" },
  { label: "Feedback NPS", value: "{{nps.feedback}}", desc: "Comentário do paciente" },
];

interface VariableInserterProps {
  onInsert: (variable: string) => void;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

export function VariableInserter({ onInsert, open, onOpenChange }: VariableInserterProps) {
  const [internalOpen, setInternalOpen] = useState(false);
  const isControlled = open !== undefined;
  const isOpen = isControlled ? open : internalOpen;
  const handleOpenChange = isControlled ? onOpenChange : setInternalOpen;

  return (
    <Popover open={isOpen} onOpenChange={handleOpenChange}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="h-7 gap-1 text-xs">
          <Braces size={12} />
          Inserir Variável
        </Button>
      </PopoverTrigger>
      <PopoverContent className="p-0 w-64" align="end">
        <Command>
          <CommandInput placeholder="Buscar variável..." />
          <CommandList>
            <CommandEmpty>Nenhuma variável encontrada.</CommandEmpty>
            <CommandGroup heading="Variáveis Disponíveis">
              {AVAILABLE_VARIABLES.map((v) => (
                <CommandItem
                  key={v.value}
                  value={v.label}
                  onSelect={() => {
                    onInsert(v.value);
                    if (handleOpenChange) handleOpenChange(false);
                  }}
                  className="flex flex-col items-start"
                >
                  <span className="font-medium">{v.label}</span>
                  <span className="text-xs text-muted-foreground">{v.value}</span>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
