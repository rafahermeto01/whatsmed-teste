import { useQuery } from "convex/react";
import { format, parse, setHours, setMinutes } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  Calendar,
  Clock,
  Loader2,
  ArrowLeft,
  AlertCircle,
  CheckCircle2,
  Video,
  Building2,
} from "lucide-react";
import { useState, useMemo, useEffect } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { useAppointmentsList, useUpdateAppointment } from "@/hooks/appointments";
import { cn } from "@/lib/utils";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

import type { Id } from "@whatsmed-app/backend/convex/_generated/dataModel";

interface RescheduleAppointmentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  patientId: Id<"patients">;
  clinicId: string;
  patientName?: string;
  initialAppointment?: Appointment;
}

type Step = "select-appointment" | "select-slot" | "confirming";

interface Appointment {
  _id: Id<"appointments">;
  startAt: number;
  endAt?: number;
  status: string;
  doctor?: string;
  doctorId?: Id<"users">;
  procedure?: string;
  procedureId?: Id<"procedures">;
  patientName?: string;
  isTelemedicine?: boolean;
}

export function RescheduleAppointmentModal({
  open,
  onOpenChange,
  patientId,
  clinicId,
  patientName,
  initialAppointment,
}: RescheduleAppointmentModalProps) {
  const [step, setStep] = useState<Step>("select-appointment");
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isTelemedicine, setIsTelemedicine] = useState<boolean>(false);

  const updateAppointment = useUpdateAppointment();

  // Stable reference time to avoid infinite re-renders from Date.now() changing on each render
  const [queryStartAt] = useState(() => Date.now());

  // Memoize the args object to prevent infinite loops
  const appointmentsQueryArgs = useMemo(
    () => ({
      clinicId,
      patientId: patientId as string,
      startAt: queryStartAt, // Stable reference - only future appointments
      limit: 20,
    }),
    [clinicId, patientId, queryStartAt],
  );

  // Fetch upcoming appointments for this patient
  const appointmentsResult = useAppointmentsList(appointmentsQueryArgs);

  // Filter to only pending/confirmed appointments
  const upcomingAppointments = useMemo(() => {
    const appointments = (appointmentsResult?.items || []) as Appointment[];
    const filteredAppointments = appointments.filter(
      (apt) => apt.status === "pending" || apt.status === "confirmed",
    );

    if (!initialAppointment || initialAppointment.status === "completed") {
      return filteredAppointments;
    }

    const existingInitialAppointment = appointments.find(
      (apt) => apt._id === initialAppointment._id,
    );
    const manualAppointment = existingInitialAppointment || initialAppointment;

    return [
      manualAppointment,
      ...filteredAppointments.filter((apt) => apt._id !== manualAppointment._id),
    ];
  }, [appointmentsResult, initialAppointment]);

  // Check if selected appointment has required data for slot fetching
  const canFetchSlots = selectedAppointment?.doctorId && selectedAppointment?.procedureId;

  // Reset date/time when telemedicine mode changes
  useEffect(() => {
    setSelectedDate(null);
    setSelectedTime(null);
  }, [isTelemedicine]);

  // Fetch available days when appointment is selected (using current isTelemedicine state)
  const availableDays = useQuery(
    api.appointments.getAvailableSlots,
    canFetchSlots
      ? {
          clinicId,
          doctorId: selectedAppointment.doctorId!,
          procedureId: selectedAppointment.procedureId!,
          isTelemedicine,
        }
      : "skip",
  );

  // Fetch available slots for selected day
  const availableSlots = useQuery(
    api.appointments.getAvailableSlots,
    canFetchSlots && selectedDate
      ? {
          clinicId,
          doctorId: selectedAppointment!.doctorId!,
          procedureId: selectedAppointment!.procedureId!,
          date: selectedDate,
          isTelemedicine,
        }
      : "skip",
  );
  // Reset state when modal closes
  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      setStep("select-appointment");
      setSelectedAppointment(null);
      setSelectedDate(null);
      setSelectedTime(null);
      setIsSubmitting(false);
      setIsTelemedicine(false);
    }
    onOpenChange(newOpen);
  };

  // Handle appointment selection
  const handleSelectAppointment = (apt: Appointment) => {
    setSelectedAppointment(apt);
    setSelectedDate(null);
    setSelectedTime(null);
    setIsTelemedicine(apt.isTelemedicine ?? false);

    if (apt.doctorId && apt.procedureId) {
      setStep("select-slot");
    }
  };

  // Handle back button
  const handleBack = () => {
    if (step === "select-slot") {
      if (selectedDate) {
        setSelectedDate(null);
        setSelectedTime(null);
        return;
      }

      setStep("select-appointment");
      setSelectedAppointment(null);
      setSelectedDate(null);
      setSelectedTime(null);
    }
  };

  // Handle reschedule submission
  const handleReschedule = async () => {
    if (!selectedAppointment || !selectedDate || !selectedTime) {
      toast.error("Selecione uma data e horário");
      return;
    }

    setIsSubmitting(true);
    setStep("confirming");

    try {
      // Parse selected time (format: HH:mm)
      const [hours, minutes] = selectedTime.split(":").map(Number);
      // Parse selected date (format: YYYY-MM-DD)
      const dateObj = parse(selectedDate, "yyyy-MM-dd", new Date());
      const startAt = setMinutes(setHours(dateObj, hours), minutes);

      // Calculate end time based on original duration
      const originalDuration =
        (selectedAppointment.endAt ?? selectedAppointment.startAt + 30 * 60 * 1000) -
        selectedAppointment.startAt;
      const endAt = new Date(startAt.getTime() + originalDuration);

      const newStartAtTimestamp = startAt.getTime();

      // Update the appointment with new time and telemedicine status
      await updateAppointment({
        id: selectedAppointment._id,
        clinicId,
        startAt: newStartAtTimestamp,
        endAt: endAt.getTime(),
        isTelemedicine,
        rescheduleStatus: "rescheduled",
      });

      toast.success("Consulta reagendada com sucesso! Uma mensagem foi enviada ao paciente.");
      handleOpenChange(false);
    } catch (error: any) {
      console.error("Failed to reschedule:", error);
      toast.error(error.message || "Erro ao reagendar consulta");
      setStep("select-slot");
    } finally {
      setIsSubmitting(false);
    }
  };

  const isLoading = appointmentsResult === undefined;
  const selectedDateLabel = selectedDate
    ? format(parse(selectedDate, "yyyy-MM-dd", new Date()), "EEEE, dd/MM", {
        locale: ptBR,
      })
    : null;
  const getAppointmentStatusLabel = (appointmentStatus: string) => {
    switch (appointmentStatus) {
      case "confirmed":
        return { label: "Confirmado", className: "bg-green-100 text-green-700" };
      case "pending":
        return { label: "Pendente", className: "bg-yellow-100 text-yellow-700" };
      case "arrived":
        return { label: "Na recepcao", className: "bg-blue-100 text-blue-700" };
      case "cancelled":
        return { label: "Cancelado", className: "bg-red-100 text-red-700" };
      default:
        return { label: appointmentStatus, className: "bg-muted text-muted-foreground" };
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[85vh] overflow-hidden flex flex-col min-h-0">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {step === "select-slot" && (
              <Button variant="ghost" size="icon" className="h-6 w-6 -ml-1" onClick={handleBack}>
                <span className="sr-only">Voltar</span>
                <ArrowLeft className="h-4 w-4" />
              </Button>
            )}
            Reagendar Consulta
          </DialogTitle>
          <DialogDescription>{patientName && `Paciente: ${patientName}`}</DialogDescription>
        </DialogHeader>

        <div className="flex-1 min-h-0 overflow-y-auto px-6 pb-6">
          {/* Step 1: Select Appointment */}
          {step === "select-appointment" && (
            <div className="space-y-4 py-4">
              <Label>Selecione a consulta para reagendar</Label>

              {isLoading ? (
                <div className="flex items-center justify-center p-8 text-muted-foreground">
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Carregando consultas...
                </div>
              ) : upcomingAppointments.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-8 text-center">
                  <AlertCircle className="h-10 w-10 text-muted-foreground mb-3" />
                  <p className="text-muted-foreground">
                    Nenhuma consulta futura encontrada para este paciente.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {upcomingAppointments.map((apt: Appointment) => {
                    const startDate = new Date(apt.startAt);
                    const hasMissingData = !apt.doctorId || !apt.procedureId;

                    const statusBadge = getAppointmentStatusLabel(apt.status);

                    return (
                      <button
                        key={apt._id}
                        onClick={() => handleSelectAppointment(apt)}
                        disabled={hasMissingData}
                        className={cn(
                          "w-full p-4 rounded-lg border text-left transition-colors",
                          hasMissingData
                            ? "opacity-50 cursor-not-allowed bg-muted"
                            : "hover:bg-accent hover:border-primary",
                        )}
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-medium flex items-center gap-2">
                              <Calendar className="h-4 w-4 text-muted-foreground" />
                              {format(startDate, "EEEE, dd 'de' MMMM", { locale: ptBR })}
                            </div>
                            <div className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                              <Clock className="h-3 w-3" />
                              {format(startDate, "HH:mm", { locale: ptBR })}
                              {apt.doctor && ` • Dr(a). ${apt.doctor}`}
                            </div>
                            {apt.procedure && (
                              <div className="text-sm text-muted-foreground mt-1">
                                {apt.procedure}
                                {apt.isTelemedicine && " (Teleconsulta)"}
                              </div>
                            )}
                          </div>
                          <span
                            className={cn("text-xs px-2 py-1 rounded-full", statusBadge.className)}
                          >
                            {statusBadge.label}
                          </span>
                        </div>
                        {hasMissingData && (
                          <p className="text-xs text-destructive mt-2">
                            Esta consulta não pode ser reagendada automaticamente (dados
                            incompletos).
                          </p>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Step 2: Select New Slot */}
          {step === "select-slot" && selectedAppointment && (
            <div className="space-y-6 py-4 pb-40">
              {/* Current appointment info */}
              <div className="bg-muted/50 rounded-lg p-3 text-sm">
                <p className="font-medium">Consulta atual:</p>
                <p className="text-muted-foreground">
                  {format(new Date(selectedAppointment.startAt), "EEEE, dd/MM 'às' HH:mm", {
                    locale: ptBR,
                  })}
                  {selectedAppointment.doctor && ` • Dr(a). ${selectedAppointment.doctor}`}
                </p>
              </div>

              {/* Telemedicine Toggle */}
              <div className="space-y-2">
                <Label>Tipo de Atendimento</Label>
                <div className="flex items-center gap-4 p-3 border rounded-lg">
                  <button
                    type="button"
                    onClick={() => setIsTelemedicine(false)}
                    className={cn(
                      "flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-md transition-colors",
                      !isTelemedicine
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted hover:bg-muted/80",
                    )}
                  >
                    <Building2 className="h-4 w-4" />
                    <span className="text-sm font-medium">Presencial</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsTelemedicine(true)}
                    className={cn(
                      "flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-md transition-colors",
                      isTelemedicine
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted hover:bg-muted/80",
                    )}
                  >
                    <Video className="h-4 w-4" />
                    <span className="text-sm font-medium">Teleconsulta</span>
                  </button>
                </div>
              </div>

              {!selectedDate ? (
                <div className="space-y-2">
                  <Label>Nova Data</Label>
                  {availableDays === undefined ? (
                    <div className="flex items-center justify-center p-4 text-sm text-muted-foreground border rounded-md">
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Buscando dias disponíveis...
                    </div>
                  ) : availableDays &&
                    "dates" in availableDays &&
                    availableDays.dates.length > 0 ? (
                    <div className="grid grid-cols-3 gap-2 border rounded-md p-2">
                      {availableDays.dates.map((dateStr: string) => {
                        const dateObj = parse(dateStr, "yyyy-MM-dd", new Date());
                        return (
                          <Button
                            key={dateStr}
                            type="button"
                            variant="outline"
                            className="h-auto py-2 px-3 flex flex-col items-start"
                            onClick={() => {
                              setSelectedDate(dateStr);
                              setSelectedTime(null);
                            }}
                          >
                            <span className="text-xs opacity-70">
                              {format(dateObj, "EEE", { locale: ptBR })}
                            </span>
                            <span className="font-medium">
                              {format(dateObj, "dd/MM", { locale: ptBR })}
                            </span>
                          </Button>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="rounded-md bg-muted p-3 text-sm text-muted-foreground">
                      Nenhum dia disponível nos próximos 7 dias
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-3">
                    <div className="space-y-1">
                      <Label className="flex items-center gap-2">
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 -ml-2"
                          aria-label="Voltar para datas"
                          onClick={() => {
                            setSelectedDate(null);
                            setSelectedTime(null);
                          }}
                        >
                          <ArrowLeft className="h-4 w-4" />
                        </Button>
                        Novo Horário
                      </Label>
                      {selectedDateLabel && (
                        <p className="text-sm text-muted-foreground capitalize">
                          {selectedDateLabel}
                        </p>
                      )}
                    </div>
                  </div>

                  {availableSlots === undefined ? (
                    <div className="flex items-center justify-center p-4 text-sm text-muted-foreground border rounded-md">
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Buscando horários...
                    </div>
                  ) : availableSlots &&
                    Array.isArray(availableSlots) &&
                    availableSlots.length > 0 ? (
                    <div className="max-h-[170px] overflow-y-auto rounded-md border bg-background p-2">
                      <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
                        {availableSlots.map((slot: { start: string; end: string }) => {
                          const slotDate = new Date(slot.start);
                          const timeStr = format(slotDate, "HH:mm", { locale: ptBR });
                          const isSelected = selectedTime === timeStr;
                          return (
                            <Button
                              key={slot.start}
                              type="button"
                              variant={isSelected ? "default" : "outline"}
                              className="h-auto py-2"
                              onClick={() => setSelectedTime(timeStr)}
                            >
                              {timeStr}
                            </Button>
                          );
                        })}
                      </div>
                    </div>
                  ) : (
                    <div className="rounded-md bg-muted p-3 text-sm text-muted-foreground">
                      Nenhum horário disponível para este dia
                    </div>
                  )}
                </div>
              )}

              {/* Summary */}
              {selectedDate && selectedTime && (
                <div className="bg-green-50 dark:bg-green-950 rounded-lg p-3 text-sm">
                  <div className="flex items-center gap-2 text-green-700 dark:text-green-300 font-medium">
                    <CheckCircle2 className="h-4 w-4" />
                    Novo horário selecionado
                  </div>
                  <p className="text-green-600 dark:text-green-400 mt-1">
                    {format(parse(selectedDate, "yyyy-MM-dd", new Date()), "EEEE, dd/MM", {
                      locale: ptBR,
                    })}{" "}
                    às {selectedTime}
                  </p>
                  <p className="text-green-600 dark:text-green-400 flex items-center gap-1 mt-1">
                    {isTelemedicine ? (
                      <>
                        <Video className="h-3 w-3" /> Teleconsulta
                      </>
                    ) : (
                      <>
                        <Building2 className="h-3 w-3" /> Presencial
                      </>
                    )}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Step 3: Confirming */}
          {step === "confirming" && (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
              <p className="text-muted-foreground">Reagendando consulta...</p>
            </div>
          )}
        </div>

        <DialogFooter className="relative z-20 shrink-0 border-t bg-background px-6 py-4">
          <Button variant="outline" onClick={() => handleOpenChange(false)}>
            Cancelar
          </Button>
          {step === "select-slot" && (
            <Button
              onClick={handleReschedule}
              disabled={!selectedDate || !selectedTime || isSubmitting}
            >
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Confirmar Reagendamento
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
