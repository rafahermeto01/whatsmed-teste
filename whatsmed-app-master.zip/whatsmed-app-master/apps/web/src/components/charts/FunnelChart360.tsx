import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Cell,
} from "recharts";

interface FunnelStep {
  name: string;
  value: number;
  fill: string;
}

const emptyData: FunnelStep[] = [
  { name: "Enviados", value: 0, fill: "#3b82f6" },
  { name: "Engajados (IA)", value: 0, fill: "#8b5cf6" },
  { name: "Confirmados", value: 0, fill: "#22c55e" },
  { name: "Compareceram", value: 0, fill: "#15803d" },
];

export function FunnelChart360({ data }: { data?: FunnelStep[] }) {
  const chartData = data || emptyData;

  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={chartData}
          layout="vertical"
          margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
        >
          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="hsl(var(--border))" />
          <XAxis type="number" hide />
          <YAxis
            dataKey="name"
            type="category"
            width={120}
            tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }}
            interval={0}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip
            cursor={{ fill: "hsl(var(--muted))", opacity: 0.1, radius: 8 }}
            contentStyle={{
              backgroundColor: "hsl(var(--popover))",
              borderRadius: "var(--radius)",
              border: "1px solid hsl(var(--border))",
              color: "hsl(var(--popover-foreground))",
              boxShadow: "var(--shadow-sm)",
            }}
            itemStyle={{ color: "hsl(var(--foreground))" }}
            labelStyle={{ display: "none" }}
            formatter={(value: number, _name: string, props: any) => [value, props.payload.name]}
          />
          <Bar
            dataKey="value"
            radius={[0, 4, 4, 0]}
            barSize={32}
            activeBar={{
              stroke: "hsl(var(--background))",
              strokeWidth: 2,
              fillOpacity: 1,
            }}
          >
            {chartData.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={entry.fill}
                className="transition-all duration-300 ease-in-out hover:opacity-100 opacity-90"
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
