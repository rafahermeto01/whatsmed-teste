import { Handle, Position } from "@xyflow/react";
import { MessageSquare, AlertCircle, AlertTriangle } from "lucide-react";

/**
 * MessageNode - Custom React Flow node for sending messages
 *
 * Visual design:
 * - Rounded rectangle with icon and message preview
 * - Blue color scheme for message nodes
 * - Connection handles (input left, output right) always visible
 *
 * Features:
 * - Message preview showing first 50-60 characters
 * - Empty state placeholder when no message is set
 * - Selected state with blue border and ring
 * - Error state with red border and ring (added in Plan 02-08)
 */
export function MessageNode({ data, selected }: any) {
  // Extract first 50-60 chars for preview, or show placeholder
  const messagePreview = data.message ? data.message.slice(0, 60) : "Digite uma mensagem...";

  // Determine validation styling (FBUI-06 - critical red, warning yellow)
  const getValidationClasses = () => {
    if (!data.validationError) return "";

    const { severity } = data.validationError;
    if (severity === "critical") {
      return "border-red-500 ring-2 ring-red-500";
    }
    if (severity === "warning") {
      return "border-yellow-500 ring-2 ring-yellow-500";
    }
    return "";
  };

  return (
    <div
      className={`
        min-w-[200px] rounded-lg border shadow-sm bg-white
        ${selected ? "border-blue-500 ring-2 ring-blue-500" : "border-gray-200"}
        ${getValidationClasses()}
      `}
    >
      {/* Header with icon and type label */}
      <div className="flex items-center gap-2 p-3 border-b border-gray-200">
        <MessageSquare className="text-blue-500" size={16} />
        <span className="font-medium text-sm">Mensagem</span>
      </div>

      {/* Message preview */}
      <div className="p-3 text-sm text-gray-600 truncate">{messagePreview}</div>

      {/* Validation Error Display (FBUI-06) */}
      {data.validationError && (
        <div
          className={`
            px-3 py-2 border-t
            ${
              data.validationError.severity === "critical"
                ? "border-red-200 bg-red-50"
                : "border-yellow-200 bg-yellow-50"
            }
          `}
        >
          <div className="flex items-center gap-2">
            {data.validationError.severity === "critical" ? (
              <AlertCircle className="w-4 h-4 text-red-500" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-yellow-600" />
            )}
            <span
              className={`text-sm ${
                data.validationError.severity === "critical" ? "text-red-700" : "text-yellow-800"
              }`}
            >
              {data.validationError.message}
            </span>
          </div>
        </div>
      )}

      {/* Connection handles - always visible per CONTEXT.md decision */}
      {/* Input handle (left) - hidden but functional (Pitfall 5 from RESEARCH.md) */}
      <Handle
        type="target"
        position={Position.Left}
        style={{ visibility: "hidden", width: 1, height: 1 }}
      />

      {/* Output handle (right) - visible with unique ID */}
      <Handle type="source" position={Position.Right} id="message" />
    </div>
  );
}
