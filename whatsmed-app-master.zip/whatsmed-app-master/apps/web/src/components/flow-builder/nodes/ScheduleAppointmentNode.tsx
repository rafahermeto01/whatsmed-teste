import { Handle, Position } from "@xyflow/react";
import { Calendar, Info } from "lucide-react";

export function ScheduleAppointmentNode({ selected }: any) {
  return (
    <div
      className={`
        px-4 py-3 rounded-lg border-2 shadow-md
        ${selected ? "border-blue-600 ring-2 ring-blue-600/50" : "border-blue-500"}
        bg-blue-50
      `}
      style={{
        minWidth: "260px",
      }}
    >
      <Handle type="target" position={Position.Left} className="w-3 h-3 !bg-blue-500" />

      <div className="space-y-2">
        <div className="flex items-center gap-2 pb-2 border-b border-blue-200">
          <Calendar className="w-5 h-5 text-blue-700" />
          <h3 className="font-bold text-blue-900">Agendar Consulta</h3>
        </div>

        <p className="text-xs text-blue-700 mb-3 leading-relaxed">
          Usa ferramenta de agendamento para criar consulta
        </p>

        <div className="flex items-start gap-2 p-2 bg-white border border-blue-200 rounded">
          <Info className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
          <div className="text-xs text-blue-600 space-y-1">
            <p className="font-semibold">Parâmetros da Ferramenta:</p>
            <ul className="list-disc list-inside ml-2 space-y-0.5">
              <li>
                <code className="bg-blue-100 px-1.5 py-0.5 rounded text-blue-800">patientId</code> -
                ID do paciente
              </li>
              <li>
                <code className="bg-blue-100 px-1.5 py-0.5 rounded text-blue-800">date</code> - Data
                da consulta
              </li>
              <li>
                <code className="bg-blue-100 px-1.5 py-0.5 rounded text-blue-800">time</code> -
                Horário da consulta
              </li>
              <li>
                <code className="bg-blue-100 px-1.5 py-0.5 rounded text-blue-800">doctorId</code> -
                ID do médico
              </li>
            </ul>
          </div>
        </div>
      </div>

      <Handle type="source" position={Position.Right} className="w-3 h-3 !bg-blue-500" />
    </div>
  );
}
