import { Handle, Position } from "@xyflow/react";
import { Type, AlertCircle, AlertTriangle } from "lucide-react";

export function InputNode({ data, selected }: any) {
  // Extract first 50-60 chars of prompt for preview
  const preview = data.prompt
    ? data.prompt.length > 55
      ? `${data.prompt.substring(0, 55)}...`
      : data.prompt
    : "Configure entrada...";

  // Variable name display (if set)
  const variableDisplay = data.variableName ? `→ ${data.variableName}` : null;

  // Determine validation styling (FBUI-06 - critical red, warning yellow)
  const getValidationClasses = () => {
    if (!data.validationError) return "";

    const { severity } = data.validationError;
    if (severity === "critical") {
      return "border-red-500 ring-2 ring-red-500";
    }
    if (severity === "warning") {
      return "border-yellow-500 ring-2 ring-yellow-500";
    }
    return "";
  };

  return (
    <div
      className={`
        min-w-[200px] rounded-lg border-2 shadow-sm
        ${selected ? "border-green-500 ring-2 ring-green-500" : "border-gray-200 bg-white"}
        ${getValidationClasses()}
      `}
    >
      {/* Input handle - hidden but present for connections */}
      <Handle
        type="target"
        position={Position.Left}
        style={{ visibility: "hidden", width: 1, height: 1 }}
      />

      {/* Header with icon and type label */}
      <div className="flex items-center gap-2 p-3 border-b border-gray-200">
        <Type className="text-green-500" size={16} />
        <span className="font-medium">Entrada</span>
      </div>

      {/* Input prompt preview */}
      <div className="p-3 text-sm text-gray-600 truncate">{preview}</div>

      {/* Variable name (if set) */}
      {variableDisplay && <div className="px-3 pb-3 text-xs text-gray-400">{variableDisplay}</div>}

      {/* Validation Error Display (FBUI-06) */}
      {data.validationError && (
        <div
          className={`
            px-3 py-2 border-t
            ${
              data.validationError.severity === "critical"
                ? "border-red-200 bg-red-50"
                : "border-yellow-200 bg-yellow-50"
            }
          `}
        >
          <div className="flex items-center gap-2">
            {data.validationError.severity === "critical" ? (
              <AlertCircle className="w-4 h-4 text-red-500" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-yellow-600" />
            )}
            <span
              className={`text-sm ${
                data.validationError.severity === "critical" ? "text-red-700" : "text-yellow-800"
              }`}
            >
              {data.validationError.message}
            </span>
          </div>
        </div>
      )}

      {/* Output handle - visible for connections */}
      <Handle type="source" position={Position.Right} />
    </div>
  );
}
