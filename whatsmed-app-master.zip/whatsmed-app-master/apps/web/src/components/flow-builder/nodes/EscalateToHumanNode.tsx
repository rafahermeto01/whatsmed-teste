import { Handle, Position } from "@xyflow/react";
import { UserCog, Info } from "lucide-react";

export function EscalateToHumanNode({ selected }: any) {
  return (
    <div
      className={`
        px-4 py-3 rounded-lg border-2 shadow-md
        ${selected ? "border-red-600 ring-2 ring-red-600/50" : "border-red-500"}
        bg-red-50
      `}
      style={{
        minWidth: "260px",
      }}
    >
      <Handle type="target" position={Position.Left} className="w-3 h-3 !bg-red-500" />

      <div className="space-y-2">
        <div className="flex items-center gap-2 pb-2 border-b border-red-200">
          <UserCog className="w-5 h-5 text-red-700" />
          <h3 className="font-bold text-red-900">Escalar para Humano</h3>
        </div>

        <p className="text-xs text-red-700 mb-3 leading-relaxed">
          Transfere a conversa para um atendente humano
        </p>

        <div className="flex items-start gap-2 p-2 bg-white border border-red-200 rounded">
          <Info className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
          <div className="text-xs text-red-600 space-y-1">
            <p className="font-semibold">Parâmetros da Ferramenta:</p>
            <ul className="list-disc list-inside ml-2 space-y-0.5">
              <li>
                <code className="bg-red-100 px-1.5 py-0.5 rounded text-red-800">reason</code> -
                Motivo da escalação
              </li>
              <li>
                <code className="bg-red-100 px-1.5 py-0.5 rounded text-red-800">urgency</code> -
                Urgência (low, medium, high)
              </li>
              <li>
                <code className="bg-red-100 px-1.5 py-0.5 rounded text-red-800">assignTo</code> - ID
                do atendente
              </li>
            </ul>
          </div>
        </div>
      </div>

      <Handle type="source" position={Position.Right} className="w-3 h-3 !bg-red-500" />
    </div>
  );
}
