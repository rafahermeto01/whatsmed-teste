import { Handle, Position } from "@xyflow/react";
import { Bot, ShieldAlert, Zap } from "lucide-react";

export function StartNode({ data, selected }: any) {
  const onDataChange = (updates: any) => {
    if (data && typeof data.onUpdate === "function") {
      data.onUpdate(updates);
    }
  };

  return (
    <div
      className={`
        px-6 py-4 rounded-lg border-2 shadow-lg
        ${selected ? "border-yellow-500 ring-2 ring-yellow-500/50" : "border-yellow-400"}
        bg-gradient-to-br from-yellow-50 to-yellow-100
      `}
      style={{
        minWidth: "320px",
      }}
    >
      <Handle type="target" position={Position.Left} className="w-3 h-3 !bg-yellow-500" />

      <div className="space-y-4">
        <div className="flex items-center gap-3 pb-3 border-b border-yellow-200">
          <Bot className="w-6 h-6 text-yellow-700" />
          <h3 className="font-bold text-yellow-900 text-lg">Guia da IA</h3>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-xs font-bold text-yellow-800 uppercase tracking-wider block mb-2">
              Instruções do Sistema
            </label>
            <textarea
              className="w-full p-3 text-sm border-2 border-yellow-300 rounded-lg bg-white focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/50 resize-none"
              placeholder="Descreva como a IA deve se comportar..."
              rows={3}
              value={data?.instructions || ""}
              onChange={(e) => onDataChange({ instructions: e.target.value })}
            />
          </div>

          <div>
            <label className="text-xs font-bold text-yellow-800 uppercase tracking-wider block mb-2">
              Tom de Voz
            </label>
            <select
              className="w-full p-3 text-sm border-2 border-yellow-300 rounded-lg bg-white focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/50"
              value={data?.tone || "empathetic"}
              onChange={(e) => onDataChange({ tone: e.target.value })}
            >
              <option value="empathetic">Empático e Acolhedor</option>
              <option value="formal">Formal e Clínico</option>
              <option value="casual">Casual e Amigável</option>
              <option value="direct">Direto e Objetivo</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-bold text-yellow-800 uppercase tracking-wider block mb-2 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4" />
              Regras de Escalação
            </label>
            <textarea
              className="w-full p-3 text-sm border-2 border-yellow-300 rounded-lg bg-white focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/50 resize-none"
              placeholder="Quando escalar para humano?"
              rows={2}
              value={data?.escalationRules || ""}
              onChange={(e) => onDataChange({ escalationRules: e.target.value })}
            />
          </div>

          <div>
            <label className="text-xs font-bold text-yellow-800 uppercase tracking-wider block mb-2 flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Prioridades e Metas
            </label>
            <textarea
              className="w-full p-3 text-sm border-2 border-yellow-300 rounded-lg bg-white focus:border-yellow-500 focus:ring-2 focus:ring-yellow-500/50 resize-none"
              placeholder="O que a IA deve priorizar?"
              rows={2}
              value={data?.goals || ""}
              onChange={(e) => onDataChange({ goals: e.target.value })}
            />
          </div>
        </div>
      </div>

      <Handle type="source" position={Position.Right} className="w-3 h-3 !bg-yellow-500" />
    </div>
  );
}
