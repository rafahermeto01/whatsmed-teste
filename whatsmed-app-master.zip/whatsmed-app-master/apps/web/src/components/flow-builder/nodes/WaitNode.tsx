import { Handle, Position } from "@xyflow/react";
import { Timer, AlertCircle, AlertTriangle } from "lucide-react";

export function WaitNode({ data, selected }: any) {
  // Format duration display
  const formatDuration = (): string => {
    if (data.duration === undefined || data.unit === undefined) {
      return "Configure espera...";
    }

    const unitLabels: Record<string, string> = {
      seconds: "segundos",
      minutes: "minutos",
      hours: "horas",
      days: "dias",
    };

    return `${data.duration} ${unitLabels[data.unit]}`;
  };

  // Determine validation styling (FBUI-06 - critical red, warning yellow)
  const getValidationClasses = () => {
    if (!data.validationError) return "";

    const { severity } = data.validationError;
    if (severity === "critical") {
      return "border-red-500 ring-2 ring-red-500";
    }
    if (severity === "warning") {
      return "border-yellow-500 ring-2 ring-yellow-500";
    }
    return "";
  };

  return (
    <div
      className={`
        min-w-[200px] rounded-lg border-2 shadow-sm bg-white
        ${selected ? "border-purple-500 ring-2 ring-purple-500 ring-offset-2" : "border-gray-200"}
        ${getValidationClasses()}
        hover:border-purple-300 transition-colors
      `}
    >
      {/* Header with icon and label */}
      <div className="flex items-center gap-2 p-3 border-b border-gray-200">
        <Timer className="text-purple-500" size={16} />
        <span className="font-medium text-gray-900">Aguardar</span>
      </div>

      {/* Duration preview */}
      <div className="p-3">
        <p className="text-sm text-gray-600">{formatDuration()}</p>
      </div>

      {/* Validation Error Display (FBUI-06) */}
      {data.validationError && (
        <div
          className={`
            px-3 py-2 border-t
            ${
              data.validationError.severity === "critical"
                ? "border-red-200 bg-red-50"
                : "border-yellow-200 bg-yellow-50"
            }
          `}
        >
          <div className="flex items-center gap-2">
            {data.validationError.severity === "critical" ? (
              <AlertCircle className="w-4 h-4 text-red-500" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-yellow-600" />
            )}
            <span
              className={`text-sm ${
                data.validationError.severity === "critical" ? "text-red-700" : "text-yellow-800"
              }`}
            >
              {data.validationError.message}
            </span>
          </div>
        </div>
      )}

      {/* Input handle (hidden but functional for hit testing) */}
      <Handle
        type="target"
        position={Position.Left}
        style={{ visibility: "hidden", width: 1, height: 1 }}
      />

      {/* Output handle */}
      <Handle type="source" position={Position.Right} className="!bg-purple-500" />
    </div>
  );
}
