import { Handle, Position } from "@xyflow/react";
import { Sparkles, Plus, X } from "lucide-react";

export function AnalyzeIntentNode({ data, selected }: any) {
  const intents = data?.intents || [
    { id: "message", label: "Enviar Mensagem", color: "bg-blue-500", handleColor: "!bg-blue-500" },
    {
      id: "schedule",
      label: "Agendar Consulta",
      color: "bg-green-500",
      handleColor: "!bg-green-500",
    },
    {
      id: "patient_lookup",
      label: "Buscar Paciente",
      color: "bg-cyan-500",
      handleColor: "!bg-cyan-500",
    },
    {
      id: "escalation",
      label: "Escalar para Humano",
      color: "bg-red-500",
      handleColor: "!bg-red-500",
    },
  ];

  const defaultIntent = data?.defaultIntent || "general";

  const onDataChange = (updates: any) => {
    if (data && typeof data.onUpdate === "function") {
      data.onUpdate(updates);
    }
  };

  const handleAddIntent = () => {
    const newIntents = [...(data?.intents || [])];
    newIntents.push({
      id: `custom_${Date.now()}`,
      label: "Nova Intenção",
      color: "bg-gray-500",
      handleColor: "!bg-gray-500",
    });
    onDataChange({ intents: newIntents });
  };

  const handleRemoveIntent = (intentId: string) => {
    const newIntents = (data?.intents || []).filter((i: any) => i.id !== intentId);
    onDataChange({ intents: newIntents });
  };

  const handleUpdateIntentLabel = (intentId: string, label: string) => {
    const newIntents = (data?.intents || []).map((i: any) =>
      i.id === intentId ? { ...i, label } : i,
    );
    onDataChange({ intents: newIntents });
  };

  return (
    <div
      className={`
        px-4 py-3 rounded-lg border-2 shadow-md
        ${selected ? "border-purple-500 ring-2 ring-purple-500/50" : "border-purple-400"}
        bg-purple-50
      `}
      style={{
        minWidth: "280px",
      }}
    >
      <Handle type="target" position={Position.Left} className="w-3 h-3 !bg-purple-500" />

      <div className="space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-purple-200">
          <Sparkles className="w-5 h-5 text-purple-700" />
          <h3 className="font-bold text-purple-900">Analisar Intenção</h3>
        </div>

        <p className="text-xs text-purple-700 mb-2 leading-relaxed">
          Analisa a mensagem do paciente e roteia para a intenção correspondente
        </p>

        <div className="space-y-2">
          <label className="text-xs font-bold text-purple-800 uppercase tracking-wider block mb-2">
            Ramificações de Intenção
          </label>

          <div className="space-y-1.5">
            {intents.map((intent: any) => (
              <div key={intent.id} className="flex items-center gap-2 group">
                <Handle
                  type="source"
                  position={Position.Right}
                  id={intent.id}
                  className={`w-3 h-3 ${intent.handleColor}`}
                />

                <input
                  type="text"
                  className="flex-1 p-2 text-xs border border-purple-300 rounded bg-white focus:border-purple-500 focus:ring-1 focus:ring-purple-500/50"
                  value={intent.label}
                  onChange={(e) => handleUpdateIntentLabel(intent.id, e.target.value)}
                />

                <button
                  type="button"
                  onClick={() => handleRemoveIntent(intent.id)}
                  className="h-6 w-6 text-destructive hover:bg-destructive/10 rounded flex items-center justify-center transition-colors"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}

            <button
              type="button"
              onClick={handleAddIntent}
              className="w-full p-2 text-xs border-2 border-dashed border-purple-300 rounded text-purple-700 hover:bg-purple-100 hover:border-purple-400 transition-colors flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Adicionar Intenção
            </button>
          </div>
        </div>

        <div className="mt-3 pt-3 border-t border-purple-200">
          <label className="text-xs font-bold text-purple-800 uppercase tracking-wider block mb-1">
            Padrão (Quando nada corresponder)
          </label>
          <select
            className="w-full p-2 text-xs border-2 border-purple-300 rounded bg-white focus:border-purple-500 focus:ring-1 focus:ring-purple-500/50"
            value={defaultIntent}
            onChange={(e) => onDataChange({ defaultIntent: e.target.value })}
          >
            <option value="general">Continuar normalmente (Sem fluxo)</option>
            <option value="message">Enviar mensagem genérica</option>
            <option value="escalation">Escalar para humano</option>
          </select>

          <Handle
            type="source"
            position={Position.Right}
            id="default"
            className="w-3 h-3 !bg-gray-400 mt-1"
          />
        </div>
      </div>
    </div>
  );
}
