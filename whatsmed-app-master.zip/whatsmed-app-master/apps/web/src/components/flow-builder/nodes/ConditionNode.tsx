import { Handle, Position } from "@xyflow/react";
import { GitBranch, AlertCircle, AlertTriangle } from "lucide-react";

export function ConditionNode({ data, selected }: any) {
  // Format condition logic preview
  const getConditionPreview = () => {
    const operatorMap = {
      equals: "==",
      notEquals: "!=",
      contains: "contém",
      notContains: "não contém",
    };

    const operator = operatorMap[data.conditionType as keyof typeof operatorMap];

    if (!data.variable && !data.value) {
      return "Configure condição...";
    }

    const variable = data.variable || "variável";
    const value = data.value ? `'${data.value}'` : "valor";

    return `${variable} ${operator} ${value}`;
  };

  // Determine validation styling (FBUI-06 - critical red, warning yellow)
  const getValidationClasses = () => {
    if (!data.validationError) return "";

    const { severity } = data.validationError;
    if (severity === "critical") {
      return "border-red-500 ring-2 ring-red-500";
    }
    if (severity === "warning") {
      return "border-yellow-500 ring-2 ring-yellow-500";
    }
    return "";
  };

  return (
    <div
      className={`
        min-w-[220px] rounded-lg border shadow-sm bg-white
        ${selected ? "border-orange-500 ring-2 ring-orange-500" : "border-gray-200"}
        ${getValidationClasses()}
      `}
    >
      {/* Header with icon and type label */}
      <div className="flex items-center gap-2 p-3 border-b border-gray-200">
        <GitBranch className="text-orange-500" size={16} />
        <span className="font-medium text-sm">Condição</span>
      </div>

      {/* Condition logic preview */}
      <div className="p-3 text-sm text-gray-600">{getConditionPreview()}</div>

      {/* Validation Error Display (FBUI-06) */}
      {data.validationError && (
        <div
          className={`
            px-3 py-2 border-t
            ${
              data.validationError.severity === "critical"
                ? "border-red-200 bg-red-50"
                : "border-yellow-200 bg-yellow-50"
            }
          `}
        >
          <div className="flex items-center gap-2">
            {data.validationError.severity === "critical" ? (
              <AlertCircle className="w-4 h-4 text-red-500" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-yellow-600" />
            )}
            <span
              className={`text-sm ${
                data.validationError.severity === "critical" ? "text-red-700" : "text-yellow-800"
              }`}
            >
              {data.validationError.message}
            </span>
          </div>
        </div>
      )}

      {/* Input handle - hidden visibility (Pitfall 5 from RESEARCH.md) */}
      <Handle
        type="target"
        position={Position.Left}
        style={{ visibility: "hidden", width: 1, height: 1 }}
      />

      {/* Output handles - multiple branches (yes/no) */}
      <Handle
        type="source"
        position={Position.Right}
        id="yes"
        className="!w-3 !h-3 !bg-orange-500"
      />
      <Handle
        type="source"
        position={Position.Bottom}
        id="no"
        className="!w-3 !h-3 !bg-orange-500"
      />
    </div>
  );
}
