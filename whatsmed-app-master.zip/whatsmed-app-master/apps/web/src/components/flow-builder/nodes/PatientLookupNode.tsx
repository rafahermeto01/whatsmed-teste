import { Handle, Position } from "@xyflow/react";
import { Search, Info } from "lucide-react";

export function PatientLookupNode({ selected }: any) {
  return (
    <div
      className={`
        px-4 py-3 rounded-lg border-2 shadow-md
        ${selected ? "border-cyan-600 ring-2 ring-cyan-600/50" : "border-cyan-500"}
        bg-cyan-50
      `}
      style={{
        minWidth: "260px",
      }}
    >
      <Handle type="target" position={Position.Left} className="w-3 h-3 !bg-cyan-500" />

      <div className="space-y-2">
        <div className="flex items-center gap-2 pb-2 border-b border-cyan-200">
          <Search className="w-5 h-5 text-cyan-700" />
          <h3 className="font-bold text-cyan-900">Buscar Paciente</h3>
        </div>

        <p className="text-xs text-cyan-700 mb-3 leading-relaxed">
          Busca informações de paciente no banco de dados
        </p>

        <div className="flex items-start gap-2 p-2 bg-white border border-cyan-200 rounded">
          <Info className="w-4 h-4 text-cyan-500 mt-0.5 flex-shrink-0" />
          <div className="text-xs text-cyan-600 space-y-1">
            <p className="font-semibold">Parâmetros da Ferramenta:</p>
            <ul className="list-disc list-inside ml-2 space-y-0.5">
              <li>
                <code className="bg-cyan-100 px-1.5 py-0.5 rounded text-cyan-800">identifier</code>{" "}
                - Identificador do paciente (telefone, CPF, etc.)
              </li>
              <li>
                <code className="bg-cyan-100 px-1.5 py-0.5 rounded text-cyan-800">lookupType</code>{" "}
                - Tipo de busca (phone, cpf, name)
              </li>
            </ul>
          </div>
        </div>
      </div>

      <Handle type="source" position={Position.Right} className="w-3 h-3 !bg-cyan-500" />
    </div>
  );
}
