import { Settings, Info, Trash2 } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

interface NodePropertiesPanelProps {
  selectedNode: any;
  onUpdateNodeData: (nodeId: string, newData: Record<string, unknown>) => void;
  onDelete?: () => void;
}

export function NodePropertiesPanel({
  selectedNode,
  onUpdateNodeData,
  onDelete,
}: NodePropertiesPanelProps) {
  if (!selectedNode) {
    return (
      <Card className="m-4">
        <CardContent className="pt-6">
          <div className="text-center">
            <Settings className="mx-auto h-12 w-12 text-muted-foreground/50" />
            <h3 className="mt-4 font-medium">Nenhum nó selecionado</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Clique em um nó para configurar suas propriedades
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <Tabs defaultValue="properties" className="flex flex-col h-full">
        <TabsList className="border-b bg-muted/30">
          <TabsTrigger value="properties" className="flex-1">
            <Settings className="w-4 h-4 mr-2" />
            Propriedades
          </TabsTrigger>
          <TabsTrigger value="info" className="flex-1">
            <Info className="w-4 h-4 mr-2" />
            Informações
          </TabsTrigger>
        </TabsList>

        <TabsContent value="properties" className="flex-1 overflow-y-auto p-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">
                  Configurar Nó: {String(selectedNode.data?.label || selectedNode.type || "")}
                </CardTitle>
                {onDelete && (
                  <button
                    onClick={onDelete}
                    disabled={!selectedNode}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-destructive text-destructive-foreground hover:bg-destructive/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm font-medium"
                    title="Excluir nó selecionado"
                  >
                    <Trash2 size={16} />
                    Excluir
                  </button>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedNode.type === "message" && (
                <MessageNodeProperties node={selectedNode} onUpdateNodeData={onUpdateNodeData} />
              )}
              {selectedNode.type === "condition" && (
                <ConditionNodeProperties node={selectedNode} onUpdateNodeData={onUpdateNodeData} />
              )}
              {selectedNode.type === "input" && (
                <InputNodeProperties node={selectedNode} onUpdateNodeData={onUpdateNodeData} />
              )}
              {selectedNode.type === "wait" && (
                <WaitNodeProperties node={selectedNode} onUpdateNodeData={onUpdateNodeData} />
              )}
              {!["message", "condition", "input", "wait"].includes(
                String(selectedNode.type || ""),
              ) && (
                <p className="text-sm text-muted-foreground">
                  Tipo de nó desconhecido: {String(selectedNode.type || "")}
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="info" className="flex-1 overflow-y-auto p-4">
          <Card>
            <CardHeader>
              <CardTitle>Informações do Nó</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-muted-foreground text-xs">ID</Label>
                <p className="text-sm font-mono">{selectedNode.id}</p>
              </div>
              <div>
                <Label className="text-muted-foreground text-xs">Tipo</Label>
                <p className="text-sm capitalize">{selectedNode.type}</p>
              </div>
              <div>
                <Label className="text-muted-foreground text-xs">Posição</Label>
                <p className="text-sm font-mono">
                  x: {Math.round(selectedNode.position.x)}, y: {Math.round(selectedNode.position.y)}
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function MessageNodeProperties({
  node,
  onUpdateNodeData,
}: {
  node: any;
  onUpdateNodeData: (nodeId: string, newData: Record<string, unknown>) => void;
}) {
  const handleMessageChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onUpdateNodeData(node.id, { message: e.target.value });
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="message">Mensagem</Label>
        <Textarea
          id="message"
          value={node.data.message || ""}
          onChange={handleMessageChange}
          placeholder="Digite a mensagem..."
          rows={6}
          className="resize-none"
        />
        <p className="text-xs text-muted-foreground">
          Use {"{{variable}}"} para referenciar variáveis definidas no fluxo
        </p>
      </div>

      <div className="p-3 bg-muted rounded-lg border border-border">
        <p className="text-xs text-muted-foreground mb-2">
          <strong>Sintaxe de variáveis:</strong>
        </p>
        <code className="text-xs bg-background px-2 py-1 rounded">{"{{nome_paciente}}"}</code>
        <p className="text-xs text-muted-foreground mt-2">
          Variáveis serão substituídas durante a execução do fluxo
        </p>
      </div>
    </div>
  );
}

function ConditionNodeProperties({
  node,
  onUpdateNodeData,
}: {
  node: any;
  onUpdateNodeData: (nodeId: string, newData: Record<string, unknown>) => void;
}) {
  const handleConditionTypeChange = (value: string) => {
    onUpdateNodeData(node.id, { conditionType: value });
  };

  const handleVariableChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdateNodeData(node.id, { variable: e.target.value });
  };

  const handleValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdateNodeData(node.id, { value: e.target.value });
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="conditionType">Tipo de condição</Label>
        <Select
          value={node.data.conditionType || "equals"}
          onValueChange={handleConditionTypeChange}
        >
          <SelectTrigger id="conditionType">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="equals">Igual a (equals)</SelectItem>
            <SelectItem value="notEquals">Diferente de (notEquals)</SelectItem>
            <SelectItem value="contains">Contém (contains)</SelectItem>
            <SelectItem value="notContains">Não contém (notContains)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="variable">Variável</Label>
        <Input
          id="variable"
          value={node.data.variable || ""}
          onChange={handleVariableChange}
          placeholder="nome_da_variavel"
        />
        <p className="text-xs text-muted-foreground">
          Nome da variável para avaliar (use {"{{variavel}}"})
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="value">Valor</Label>
        <Input
          id="value"
          value={node.data.value || ""}
          onChange={handleValueChange}
          placeholder="Valor esperado"
        />
      </div>

      <div className="p-3 bg-muted rounded-lg border border-border">
        <p className="text-xs text-muted-foreground">
          <strong>Lógica de bifurcação:</strong>
        </p>
        <ul className="text-xs text-muted-foreground list-disc list-inside mt-2 space-y-1">
          <li>
            <strong>Sim (Sim):</strong> Conexão superior (handle "yes")
          </li>
          <li>
            <strong>Não (Não):</strong> Conexão inferior (handle "no")
          </li>
        </ul>
      </div>
    </div>
  );
}

function InputNodeProperties({
  node,
  onUpdateNodeData,
}: {
  node: any;
  onUpdateNodeData: (nodeId: string, newData: Record<string, unknown>) => void;
}) {
  const handlePromptChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onUpdateNodeData(node.id, { prompt: e.target.value });
  };

  const handleVariableNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdateNodeData(node.id, { variableName: e.target.value });
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="prompt">Prompt</Label>
        <Textarea
          id="prompt"
          value={node.data.prompt || ""}
          onChange={handlePromptChange}
          placeholder="Digite o prompt para o paciente..."
          rows={4}
          className="resize-none"
        />
        <p className="text-xs text-muted-foreground">
          Texto exibido ao paciente antes da coleta de entrada
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="variableName">Nome da variável</Label>
        <Input
          id="variableName"
          value={node.data.variableName || ""}
          onChange={handleVariableNameChange}
          placeholder="nome_da_variavel"
        />
        <p className="text-xs text-muted-foreground">
          A resposta do paciente será armazenada nesta variável
        </p>
      </div>

      <div className="p-3 bg-muted rounded-lg border border-border">
        <p className="text-xs text-muted-foreground">
          <strong>Uso da variável:</strong>
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          Use {"{{" + node.data.variableName + "}}"} para referenciar a resposta em mensagens
          subsequentes
        </p>
      </div>
    </div>
  );
}

function WaitNodeProperties({
  node,
  onUpdateNodeData,
}: {
  node: any;
  onUpdateNodeData: (nodeId: string, newData: Record<string, unknown>) => void;
}) {
  const handleDurationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value, 10);
    if (!isNaN(value) && value > 0) {
      onUpdateNodeData(node.id, { duration: value });
    }
  };

  const handleUnitChange = (value: string) => {
    onUpdateNodeData(node.id, { unit: value });
  };

  const handleTimeoutActionChange = (value: string) => {
    onUpdateNodeData(node.id, { timeoutAction: value });
  };

  const handleResumeConditionChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdateNodeData(node.id, { resumeCondition: e.target.value });
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="duration">Duração</Label>
        <Input
          id="duration"
          type="number"
          min="1"
          value={node.data.duration || 5}
          onChange={handleDurationChange}
          placeholder="Duração"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="unit">Unidade</Label>
        <Select value={node.data.unit || "minutes"} onValueChange={handleUnitChange}>
          <SelectTrigger id="unit">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="seconds">Segundos</SelectItem>
            <SelectItem value="minutes">Minutos</SelectItem>
            <SelectItem value="hours">Horas</SelectItem>
            <SelectItem value="days">Dias</SelectItem>
          </SelectContent>
        </Select>
        <p className="text-xs text-muted-foreground">
          O que fazer quando o tempo de espera expirar
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="timeoutAction">Ação após timeout</Label>
        <Select
          value={node.data.timeoutAction || "resume"}
          onValueChange={handleTimeoutActionChange}
        >
          <SelectTrigger id="timeoutAction">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="resume">Continuar fluxo</SelectItem>
            <SelectItem value="escalate">Escalonar para humano</SelectItem>
          </SelectContent>
        </Select>
        <p className="text-xs text-muted-foreground">
          O que fazer quando o tempo de espera expirar
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="resumeCondition">Condição para retomada (opcional)</Label>
        <Input
          id="resumeCondition"
          value={node.data.resumeCondition || ""}
          onChange={handleResumeConditionChange}
          placeholder="Ex: userResponseReceived"
        />
        <p className="text-xs text-muted-foreground">
          Nome da condição que pode retomar o fluxo antes do timeout
        </p>
      </div>

      <div className="p-3 bg-muted rounded-lg border border-border">
        <p className="text-xs text-muted-foreground">
          <strong>Comportamento:</strong>
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          O fluxo pausará por {node.data.duration || 5}{" "}
          {node.data.unit === "days"
            ? "dias"
            : node.data.unit === "hours"
              ? "horas"
              : node.data.unit === "seconds"
                ? "segundos"
                : "minutos"}{" "}
          {node.data.timeoutAction === "escalate"
            ? "e será escalonado para humano"
            : "antes de continuar"}{" "}
          após o timeout
        </p>
      </div>
    </div>
  );
}
