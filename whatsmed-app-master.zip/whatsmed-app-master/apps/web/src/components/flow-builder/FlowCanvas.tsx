// REQUIRED: React Flow CSS import (Pitfall 1 from RESEARCH.md)
import "@xyflow/react/dist/style.css";

import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  BackgroundVariant,
  useReactFlow,
  MarkerType,
} from "@xyflow/react";
import { X } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";

// Import custom node components
import { AnalyzeIntentNode } from "./nodes/AnalyzeIntentNode";
import { ConditionNode } from "./nodes/ConditionNode";
import { EscalateToHumanNode } from "./nodes/EscalateToHumanNode";
import { InputNode } from "./nodes/InputNode";
import { MessageNode } from "./nodes/MessageNode";
import { PatientLookupNode } from "./nodes/PatientLookupNode";
import { ScheduleAppointmentNode } from "./nodes/ScheduleAppointmentNode";
import { StartNode } from "./nodes/StartNode";
import { WaitNode } from "./nodes/WaitNode";
// Import validation module (Plan 02-08)
import { validateFlow, type ValidationError } from "./validation/FlowValidator";

import type { Node, Edge, EdgeProps, OnSelectionChangeParams } from "@xyflow/react";

// Custom edge component with 'x' button on hover (per CONTEXT.md locked decision)
function CustomEdge({ id, sourceX, sourceY, targetX, targetY, selected }: EdgeProps) {
  const [isHovered, setIsHovered] = useState(false);

  // Find edge geometry to position 'x' button using bezier curve
  const edgePath = `M${sourceX},${sourceY} C${sourceX + 100},${sourceY} ${targetX - 100},${targetY} ${targetX},${targetY}`;

  const handleDeleteEdge = useCallback(() => {
    // This will be handled by parent via edge deletion callback
    const deleteEvent = new CustomEvent("delete-edge", { detail: { edgeId: id } });
    window.dispatchEvent(deleteEvent);
  }, [id]);

  return (
    <g onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
      <path
        id={id}
        style={{
          stroke: isHovered || selected ? "#64748b" : "#94a3b8",
          strokeWidth: isHovered || selected ? 3 : 2,
        }}
        className="react-flow__edge-path"
        d={edgePath}
      />
      {/* 'x' button on hover - positioned at midpoint of edge */}
      {isHovered && (
        <foreignObject
          x={(sourceX + targetX) / 2 - 12}
          y={(sourceY + targetY) / 2 - 12}
          width="24"
          height="24"
        >
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleDeleteEdge();
            }}
            style={{
              width: "20px",
              height: "20px",
              borderRadius: "50%",
              backgroundColor: "#ef4444",
              color: "white",
              border: "none",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: 0,
            }}
            title="Remover conexão"
          >
            <X size={12} />
          </button>
        </foreignObject>
      )}
    </g>
  );
}

export function FlowCanvas({
  nodes,
  edges,
  onNodeClick,
  onPaneClick,
  onValidationErrors,
  onNodesChange,
  onEdgesChange,
}: {
  nodes?: Node[];
  edges?: Edge[];
  onNodeClick?: (event: React.MouseEvent, node: Node) => void;
  onPaneClick?: (event: React.MouseEvent) => void;
  onValidationErrors?: (errors: ValidationError[]) => void;
  onNodesChange?: (changes: any) => void;
  onEdgesChange?: (changes: any) => void;
}) {
  // Track selected nodes for delete functionality (FBUI-07)
  const [selectedNodes, setSelectedNodes] = useState<Node[]>([]);

  // Helper for converting screen coordinates to flow coordinates
  const { screenToFlowPosition } = useReactFlow();

  // Define node types for custom components
  const nodeTypes: any = {
    message: MessageNode,
    condition: ConditionNode,
    input: InputNode,
    wait: WaitNode,
    start: StartNode,
    analyzeIntent: AnalyzeIntentNode,
    scheduleAppointment: ScheduleAppointmentNode,
    patientLookup: PatientLookupNode,
    escalateToHuman: EscalateToHumanNode,
  };

  // Register custom edge type
  const edgeTypes = {
    custom: CustomEdge,
  };

  // Handle drag-and-drop from NodePalette
  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();

    if (!e.dataTransfer.types.includes("application/reactflow")) {
      return;
    }

    const nodeType = e.dataTransfer.getData("application/reactflow");

    let newNode: Node | null = null;
    const position = screenToFlowPosition({
      x: e.clientX,
      y: e.clientY,
    });

    if (nodeType === "message") {
      newNode = {
        id: `node-${Date.now()}`,
        type: "message",
        position,
        data: { message: "" },
      };
    } else if (nodeType === "condition") {
      newNode = {
        id: `node-${Date.now()}`,
        type: "condition",
        position,
        data: { conditionType: "equals", variable: "", value: "" },
      };
    } else if (nodeType === "input") {
      newNode = {
        id: `node-${Date.now()}`,
        type: "input",
        position,
        data: { prompt: "", variableName: "" },
      };
    } else if (nodeType === "wait") {
      newNode = {
        id: `node-${Date.now()}`,
        type: "wait",
        position,
        data: { duration: 5, unit: "minutes", timeoutAction: "resume", resumeCondition: "" },
      };
    } else if (nodeType === "start") {
      newNode = {
        id: `node-${Date.now()}`,
        type: "start",
        position,
        data: {
          title: "Guia da IA",
          instructions: "Seja útil, empático e profissional.",
          tone: "empathetic",
          escalationRules: "Escalar quando necessário",
          goals: "Priorizar agendamentos e respostas",
        },
      };
    } else if (nodeType === "analyzeIntent") {
      newNode = {
        id: `node-${Date.now()}`,
        type: "analyzeIntent",
        position,
        data: {
          intents: [],
          defaultIntent: "general",
        },
      };
    } else if (nodeType === "scheduleAppointment") {
      newNode = {
        id: `node-${Date.now()}`,
        type: "scheduleAppointment",
        position,
        data: { description: "Agendar consulta para paciente" },
      };
    } else if (nodeType === "patientLookup") {
      newNode = {
        id: `node-${Date.now()}`,
        type: "patientLookup",
        position,
        data: { description: "Buscar informações de paciente" },
      };
    } else if (nodeType === "escalateToHuman") {
      newNode = {
        id: `node-${Date.now()}`,
        type: "escalateToHuman",
        position,
        data: { description: "Escalar conversa para humano" },
      };
    }

    if (newNode) {
      onNodesChange?.([{ type: "add", item: newNode } as any]);
    }
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.types.includes("application/reactflow")) {
      e.dataTransfer.dropEffect = "move";
    }
  };

  // Handle edge creation when connecting nodes
  const onConnect = useCallback(
    (connection: any) => {
      const newEdge: Edge = {
        id: `edge-${Date.now()}`,
        source: connection.source,
        target: connection.target,
        sourceHandle: connection.sourceHandle,
        targetHandle: connection.targetHandle,
      };
      onEdgesChange?.([{ type: "add", item: newEdge } as any]);
    },
    [onEdgesChange],
  );

  // Handle selection changes (for delete functionality)
  const handleSelectionChange = useCallback(({ nodes }: OnSelectionChangeParams) => {
    setSelectedNodes(nodes || []);
  }, []);

  // Add isValidConnection callback (always return true for now)
  const isValidConnection = useCallback(() => true, []);

  // Validate flow and compute errors (FBUI-06)
  const validationErrors = useMemo(() => {
    return validateFlow(nodes || [], edges || []);
  }, [nodes, edges]);

  // Compute nodes with validation errors attached
  const nodesWithValidation = useMemo(() => {
    return (nodes || []).map((node) => ({
      ...node,
      data: {
        ...node.data,
        validationError: validationErrors.find((e) => e.nodeId === node.id),
      },
    }));
  }, [nodes, validationErrors]);

  // Notify parent component about validation errors
  useEffect(() => {
    if (onValidationErrors) {
      onValidationErrors(validationErrors);
    }
  }, [validationErrors, onValidationErrors]);

  useEffect(() => {
    const handleDeleteEdge = (event: CustomEvent) => {
      const { edgeId } = event.detail;
      onEdgesChange?.([{ type: "remove", id: edgeId } as any]);
    };

    const handleDeleteNodes = () => {
      if (selectedNodes.length > 0) {
        const selectedNodeIds = selectedNodes.map((node) => node.id);
        // Remove nodes
        const nodeChanges = selectedNodeIds.map((id) => ({ type: "remove" as const, id }));
        onNodesChange?.(nodeChanges as any);
        // Remove connected edges
        const edgeChanges = (edges || [])
          .filter(
            (edge) =>
              selectedNodeIds.includes(edge.source) || selectedNodeIds.includes(edge.target),
          )
          .map((edge) => ({ type: "remove" as const, id: edge.id }));
        if (edgeChanges.length > 0) {
          onEdgesChange?.(edgeChanges as any);
        }
      }
    };

    window.addEventListener("delete-edge", handleDeleteEdge as EventListener);
    window.addEventListener("delete-selected-nodes", handleDeleteNodes);

    return () => {
      window.removeEventListener("delete-edge", handleDeleteEdge as EventListener);
      window.removeEventListener("delete-selected-nodes", handleDeleteNodes);
    };
  }, [selectedNodes, edges, onNodesChange, onEdgesChange]);
  return (
    <div className="w-full h-full bg-white">
      <ReactFlow
        nodes={nodesWithValidation}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onDrop={onDrop}
        onDragOver={onDragOver}
        onNodeClick={onNodeClick}
        onPaneClick={onPaneClick}
        onSelectionChange={handleSelectionChange}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        defaultEdgeOptions={{
          type: "custom",
          animated: false,
          style: { stroke: "#94a3b8", strokeWidth: 2 },
          markerEnd: { type: MarkerType.ArrowClosed, color: "#94a3b8" },
        }}
        onConnect={onConnect}
        isValidConnection={isValidConnection}
        fitView={true}
      >
        <Background variant={BackgroundVariant.Dots} gap={20} size={1} color="#e5e7eb" />
        <Controls />
        <MiniMap nodeColor="#e2e8f0" maskColor="rgba(0, 0, 0, 0.1)" />
      </ReactFlow>
    </div>
  );
}
