import { Plus, Trash2 } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

export interface FlowVariable {
  name: string;
  type: "string" | "number" | "boolean";
  defaultValue?: string | number | boolean;
  description?: string;
}

export function FlowSettingsPanel({
  flowName,
  flowDescription,
  variables,
  onSave,
}: {
  flowName: string;
  flowDescription?: string;
  variables: FlowVariable[];
  onSave: (params: { name?: string; description?: string; variables: FlowVariable[] }) => void;
}) {
  // Local state for name and description
  const [name, setName] = useState(flowName);
  const [description, setDescription] = useState(flowDescription || "");

  const handleNameChange = (value: string) => {
    setName(value);
    onSave({ name: value, variables });
  };

  const handleDescriptionChange = (value: string) => {
    setDescription(value);
    onSave({ description: value, variables });
  };

  const addVariable = () => {
    onSave({
      variables: [...variables, { name: "", type: "string" }],
    });
  };

  const updateVariable = (index: number, updates: Partial<FlowVariable>) => {
    const newVariables = [...variables];
    newVariables[index] = { ...newVariables[index], ...updates };
    onSave({ variables: newVariables });
  };

  const removeVariable = (index: number) => {
    const newVariables = variables.filter((_, i) => i !== index);
    onSave({ variables: newVariables });
  };

  return (
    <div className="space-y-6">
      {/* Flow Metadata */}
      <Card>
        <CardHeader>
          <CardTitle>Informações do Fluxo</CardTitle>
          <CardDescription>Configure o nome e descrição do fluxo</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Flow Name */}
          <div className="space-y-2">
            <Label htmlFor="flow-name">Nome do Fluxo</Label>
            <Input
              id="flow-name"
              value={name}
              onChange={(e) => handleNameChange(e.target.value)}
              placeholder="Digite o nome do fluxo"
            />
          </div>

          {/* Flow Description */}
          <div className="space-y-2">
            <Label htmlFor="flow-description">Descrição</Label>
            <Textarea
              id="flow-description"
              value={description}
              onChange={(e) => handleDescriptionChange(e.target.value)}
              placeholder="Digite uma descrição opcional..."
              rows={4}
            />
          </div>
        </CardContent>
      </Card>

      {/* Variables Section (FMAN-07) */}
      <Card>
        <CardHeader>
          <CardTitle>Variáveis</CardTitle>
          <CardDescription>
            Defina variáveis que podem ser usadas nas mensagens com a sintaxe {"{{variável}}"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Variables List */}
          {variables.length === 0 ? (
            <div className="text-center py-6 text-muted-foreground text-sm">
              Nenhuma variável definida
            </div>
          ) : (
            <div className="space-y-3">
              {variables.map((variable, index) => (
                <div
                  key={index}
                  className="flex items-start gap-3 p-3 border rounded-lg bg-muted/30"
                >
                  {/* Delete Button */}
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeVariable(index)}
                    className="mt-1 text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 size={16} />
                  </Button>

                  {/* Variable Fields */}
                  <div className="flex-1 space-y-2">
                    {/* Variable Name */}
                    <div>
                      <Label className="text-xs">Nome</Label>
                      <Input
                        value={variable.name}
                        onChange={(e) => updateVariable(index, { name: e.target.value })}
                        placeholder="nome_da_variavel"
                        className="h-8"
                      />
                    </div>

                    {/* Variable Type and Default Value */}
                    <div className="flex gap-2">
                      {/* Variable Type */}
                      <div className="flex-1">
                        <Label className="text-xs">Tipo</Label>
                        <Select
                          value={variable.type}
                          onValueChange={(value) =>
                            updateVariable(index, {
                              type: value as "string" | "number" | "boolean",
                            })
                          }
                        >
                          <SelectTrigger className="h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="string">Texto (string)</SelectItem>
                            <SelectItem value="number">Número (number)</SelectItem>
                            <SelectItem value="boolean">Verdadeiro/Falso (boolean)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Default Value */}
                      <div className="flex-1">
                        <Label className="text-xs">Valor Padrão</Label>
                        {variable.type === "boolean" ? (
                          <Select
                            value={variable.defaultValue?.toString() || "false"}
                            onValueChange={(value) =>
                              updateVariable(index, {
                                defaultValue: value === "true",
                              })
                            }
                          >
                            <SelectTrigger className="h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="false">Falso</SelectItem>
                              <SelectItem value="true">Verdadeiro</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : variable.type === "number" ? (
                          <Input
                            type="number"
                            value={variable.defaultValue?.toString() || ""}
                            onChange={(e) =>
                              updateVariable(index, {
                                defaultValue: parseFloat(e.target.value),
                              })
                            }
                            placeholder="0"
                            className="h-8"
                          />
                        ) : (
                          <Input
                            type="text"
                            value={variable.defaultValue?.toString() || ""}
                            onChange={(e) =>
                              updateVariable(index, {
                                defaultValue: e.target.value,
                              })
                            }
                            placeholder="Valor padrão"
                            className="h-8"
                          />
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Add Variable Button */}
          <Button onClick={addVariable} variant="outline" className="w-full">
            <Plus className="w-4 h-4 mr-2" />
            Adicionar Variável
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
