import {
  MessageSquare,
  GitBranch,
  Type,
  Timer,
  Calendar,
  Search,
  UserCog,
  Sparkles,
  Bot,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface NodePaletteProps {
  onDragStart: (event: React.DragEvent, nodeType: string) => void;
}

const nodeTypes = [
  // Structure nodes
  {
    type: "message",
    label: "Mensagem",
    icon: MessageSquare,
    color: "bg-blue-500",
    category: "structure",
  },
  {
    type: "condition",
    label: "Condição",
    icon: GitBranch,
    color: "bg-orange-500",
    category: "structure",
  },
  { type: "input", label: "Entrada", icon: Type, color: "bg-green-500", category: "structure" },
  { type: "wait", label: "Aguardar", icon: Timer, color: "bg-purple-500", category: "structure" },

  // AI Tool nodes
  {
    type: "scheduleAppointment",
    label: "Agendar Consulta",
    icon: Calendar,
    color: "bg-blue-600",
    category: "tools",
  },
  {
    type: "patientLookup",
    label: "Buscar Paciente",
    icon: Search,
    color: "bg-cyan-600",
    category: "tools",
  },
  {
    type: "escalateToHuman",
    label: "Escalar para Humano",
    icon: UserCog,
    color: "bg-red-600",
    category: "tools",
  },
  {
    type: "analyzeIntent",
    label: "Analisar Intenção",
    icon: Sparkles,
    color: "bg-purple-600",
    category: "tools",
  },

  // Special nodes
  {
    type: "start",
    label: "Início (Guia IA)",
    icon: Bot,
    color: "bg-yellow-600",
    category: "special",
  },
];

export function NodePalette({ onDragStart }: NodePaletteProps) {
  return (
    <Card className="border-0 shadow-none">
      <CardContent className="p-4 space-y-6">
        {/* Structure Category */}
        <div>
          <CardHeader className="pb-2 px-0">
            <CardTitle className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Estrutura
            </CardTitle>
          </CardHeader>
          <div className="space-y-2">
            {nodeTypes
              .filter((n) => n.category === "structure")
              .map((node) => {
                const Icon = node.icon;
                return (
                  <Button
                    key={node.type}
                    variant="outline"
                    draggable={true}
                    onDragStart={(e) => onDragStart(e, node.type)}
                    className="w-full justify-start gap-3 h-auto py-2.5 px-3 hover:bg-accent/50 cursor-grab active:cursor-grabbing"
                  >
                    <div className={`p-1.5 rounded-md ${node.color}`}>
                      <Icon className="h-4 w-4 text-white" />
                    </div>
                    <span className="font-medium text-sm">{node.label}</span>
                  </Button>
                );
              })}
          </div>
        </div>

        {/* AI Tools Category */}
        <div>
          <CardHeader className="pb-2 px-0">
            <CardTitle className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Ferramentas da IA
            </CardTitle>
          </CardHeader>
          <div className="space-y-2">
            {nodeTypes
              .filter((n) => n.category === "tools")
              .map((node) => {
                const Icon = node.icon;
                return (
                  <Button
                    key={node.type}
                    variant="outline"
                    draggable={true}
                    onDragStart={(e) => onDragStart(e, node.type)}
                    className="w-full justify-start gap-3 h-auto py-2.5 px-3 hover:bg-accent/50 cursor-grab active:cursor-grabbing"
                  >
                    <div className={`p-1.5 rounded-md ${node.color}`}>
                      <Icon className="h-4 w-4 text-white" />
                    </div>
                    <span className="font-medium text-sm">{node.label}</span>
                  </Button>
                );
              })}
          </div>
        </div>

        {/* Special Category */}
        <div>
          <CardHeader className="pb-2 px-0">
            <CardTitle className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Especial
            </CardTitle>
          </CardHeader>
          <div className="space-y-2">
            {nodeTypes
              .filter((n) => n.category === "special")
              .map((node) => {
                const Icon = node.icon;
                return (
                  <Button
                    key={node.type}
                    variant="outline"
                    draggable={true}
                    onDragStart={(e) => onDragStart(e, node.type)}
                    className="w-full justify-start gap-3 h-auto py-2.5 px-3 hover:bg-accent/50 cursor-grab active:cursor-grabbing"
                  >
                    <div className={`p-1.5 rounded-md ${node.color}`}>
                      <Icon className="h-4 w-4 text-white" />
                    </div>
                    <span className="font-medium text-sm">{node.label}</span>
                  </Button>
                );
              })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
