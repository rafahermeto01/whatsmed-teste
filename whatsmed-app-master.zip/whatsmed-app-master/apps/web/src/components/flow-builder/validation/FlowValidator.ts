import type { Node, Edge } from "@xyflow/react";

/**
 * ValidationError interface for flow validation results
 * @property nodeId - The ID of the node with the error
 * @property severity - "critical" or "warning" level
 * @property message - Human-readable error message in Portuguese
 */
export interface ValidationError {
  nodeId: string;
  severity: "critical" | "warning";
  message: string;
}

/**
 * validateFlow - Validates a flow by checking node configurations and connections
 *
 * Critical errors (blocks saving/activating):
 * - Message nodes without message text
 * - Condition nodes without variable/value configured
 * - Input nodes without prompt or variable name
 * - Wait nodes with invalid duration
 *
 * Warnings (can save but user should review):
 * - Nodes without incoming connections (except potential start nodes)
 *
 * @param nodes - Array of React Flow nodes
 * @param edges - Array of React Flow edges
 * @returns Array of validation errors
 */
export function validateFlow(nodes: Node[], edges: Edge[]): ValidationError[] {
  const errors: ValidationError[] = [];

  // Rule 1: Message nodes require message text
  nodes
    .filter((n) => n.type === "message")
    .forEach((node) => {
      const message = (node.data as { message?: string }).message;
      if (!message || message.trim() === "") {
        errors.push({
          nodeId: node.id,
          severity: "critical",
          message: "Mensagem é obrigatória",
        });
      }
    });

  // Rule 2: Condition nodes require condition logic (variable and value)
  nodes
    .filter((n) => n.type === "condition")
    .forEach((node) => {
      const data = node.data as {
        conditionType?: string;
        variable?: string;
        value?: string;
      };
      if (!data.variable || data.variable.trim() === "") {
        errors.push({
          nodeId: node.id,
          severity: "critical",
          message: "Configure variável da condição",
        });
      }
      if (!data.value || data.value.trim() === "") {
        errors.push({
          nodeId: node.id,
          severity: "critical",
          message: "Configure valor da condição",
        });
      }
    });

  // Rule 3: Input nodes require prompt and variable name
  nodes
    .filter((n) => n.type === "input")
    .forEach((node) => {
      const data = node.data as { prompt?: string; variableName?: string };

      if (!data.prompt || data.prompt.trim() === "") {
        errors.push({
          nodeId: node.id,
          severity: "critical",
          message: "Prompt é obrigatório",
        });
      }

      if (!data.variableName || data.variableName.trim() === "") {
        errors.push({
          nodeId: node.id,
          severity: "critical",
          message: "Nome da variável é obrigatório",
        });
      }
    });

  // Rule 4: Wait nodes require valid duration
  nodes
    .filter((n) => n.type === "wait")
    .forEach((node) => {
      const data = node.data as { duration?: number };
      if (!data.duration || data.duration <= 0) {
        errors.push({
          nodeId: node.id,
          severity: "critical",
          message: "Duração deve ser maior que zero",
        });
      }
    });

  // Rule 5: Nodes without incoming connections (warning, except for potential start nodes)
  const nodesWithIncoming = new Set(edges.map((e) => e.target));

  // If there are multiple nodes, warn about nodes without incoming connections
  if (nodes.length > 1) {
    nodes
      .filter((n) => !nodesWithIncoming.has(n.id))
      .forEach((node) => {
        // Skip warning if this could be the start node (no outgoing connections either)
        const hasOutgoing = edges.some((e) => e.source === node.id);
        if (!hasOutgoing) {
          // This is likely the start node, no warning needed
          return;
        }

        errors.push({
          nodeId: node.id,
          severity: "warning",
          message: "Nó sem conexão de entrada",
        });
      });
  }

  return errors;
}
