import { Link } from "@tanstack/react-router";
import { useQuery, useMutation } from "convex/react";
import {
  LayoutDashboard,
  Users,
  Calendar,
  Settings,
  Bot,
  Zap,
  Wallet,
  MessageSquareHeart,
  Shield,
  ClipboardList,
  ChevronsUpDown,
  Building2,
  Check,
  Kanban,
} from "lucide-react";
import { Lock } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useClinic } from "@/hooks/clinics";
import { useImpersonation } from "@/hooks/impersonation";
import { useClinicId, usePermissions } from "@/hooks/patients";
import { authClient } from "@/lib/auth-client";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

const WhatsAppIcon = ({ size = 20, className }: { size?: number; className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
  >
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);

export function MainLayout({ children }: { children: React.ReactNode }) {
  const { isPending } = authClient.useSession();
  const { stopImpersonation } = useImpersonation();
  const { clinicId, role, actualClinicId, actualRole, impersonation, isImpersonating } =
    useClinicId();
  const { canAccessSettings, canManageAutomation, canManageBilling } = usePermissions();

  // Data for clinic switcher
  const userClinics = useQuery(api.users.getUserClinics) || [];
  const switchClinic = useMutation(api.users.switchClinic);

  // All hooks must be called before any conditional returns
  const activeClinicRecord = useClinic(actualClinicId);
  const viewedClinicRecord = useClinic(clinicId);
  const appointmentsAccess = useQuery(
    api.planEnforcement.checkFeatureAccessPublic,
    clinicId ? { clinicId, feature: "appointments" } : "skip",
  );
  const integrationsAccess = useQuery(
    api.planEnforcement.checkFeatureAccessPublic,
    clinicId ? { clinicId, feature: "integrations" } : "skip",
  );
  const npsAccess = useQuery(
    api.planEnforcement.checkFeatureAccessPublic,
    clinicId ? { clinicId, feature: "nps" } : "skip",
  );

  const activeClinic = userClinics.find((c: any) => c.clinicId === actualClinicId);

  const displayedClinicName = isImpersonating
    ? impersonation?.clinicName || viewedClinicRecord?.name || clinicId || "Clínica"
    : activeClinic?.name || activeClinicRecord?.name || viewedClinicRecord?.name || "Minha Clínica";

  const getRoleLabel = (value?: string) => {
    switch (value) {
      case "admin":
        return "Administrador";
      case "super_admin":
        return "Super Admin";
      case "doctor":
        return "Médico";
      case "viewer":
        return "Visualizador";
      default:
        return "Equipe";
    }
  };

  const handleSwitchClinic = async (newClinicId: string) => {
    if (newClinicId === actualClinicId) return;
    try {
      await switchClinic({ clinicId: newClinicId });
      toast.success("Clínica alterada com sucesso");
      // Optional: Force reload if context doesn't update cleanly,
      // but Convex reactivity should handle it if useClinicId uses useQuery.
      // However, useClinicId uses `api.users.getByEmail` which is reactive.
    } catch (err) {
      console.error(err);
      toast.error("Erro ao alterar clínica");
    }
  };

  // Show loading state while session is being fetched
  if (isPending) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const navItems = [
    { to: "/dashboard", label: "Painel", icon: LayoutDashboard },
    { to: "/whatsapp", label: "WhatsApp", icon: WhatsAppIcon },
    { to: "/patients", label: "Pacientes", icon: Users },
    {
      to: "/appointments",
      label: "Consultas",
      icon: Calendar,
      locked: appointmentsAccess && !appointmentsAccess.allowed,
    },
    { to: "/kanban", label: "Kanban", icon: Kanban },
    { to: "/forms", label: "Formulários", icon: ClipboardList },
    ...(canManageAutomation ? [{ to: "/automation", label: "Automação", icon: Bot }] : []),
    {
      to: "/nps",
      label: "NPS & Avaliações",
      icon: MessageSquareHeart,
      locked: npsAccess && !npsAccess.allowed,
    },
    ...(canManageBilling ? [{ to: "/billing", label: "Carteira", icon: Wallet }] : []),
    {
      to: "/integrations",
      label: "Integrações",
      icon: Zap,
      locked: integrationsAccess && !integrationsAccess.allowed,
    },
    ...(canAccessSettings ? [{ to: "/settings", label: "Configurações", icon: Settings }] : []),
    // Only show System screen for super_admin
    ...(actualRole === "super_admin" ? [{ to: "/system", label: "Sistema", icon: Shield }] : []),
  ];

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar */}
      <aside className="bg-sidebar border-r border-sidebar-border flex flex-col sticky top-0 h-screen overflow-y-auto w-64">
        {/* Logo & Clinic Switcher */}
        <div className="flex flex-col gap-4 px-4 py-6 border-b border-sidebar-border">
          <div className="flex items-center gap-2">
            <img src="/logos/logo.svg" alt="WhatsMed" className="h-8 w-auto" />
          </div>

          {/* Clinic Switcher */}
          {isImpersonating ? (
            <div className="w-full rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-3">
              <div className="flex items-center gap-3 text-left overflow-hidden">
                <div className="flex items-center justify-center w-8 h-8 rounded-md bg-amber-500/20 text-amber-700 shrink-0">
                  <Building2 size={16} />
                </div>
                <div className="flex flex-col truncate">
                  <span className="text-sm font-medium truncate">{displayedClinicName}</span>
                  <span className="text-xs text-amber-800/80 truncate">
                    Visualizando como {getRoleLabel(role)}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-between h-auto py-3 px-3 border-sidebar-border bg-sidebar-accent/5 hover:bg-sidebar-accent/10"
                >
                  <div className="flex items-center gap-3 text-left overflow-hidden">
                    <div className="flex items-center justify-center w-8 h-8 rounded-md bg-primary/10 text-primary shrink-0">
                      <Building2 size={16} />
                    </div>
                    <div className="flex flex-col truncate">
                      <span className="text-sm font-medium truncate">{displayedClinicName}</span>
                      <span className="text-xs text-muted-foreground truncate capitalize">
                        {getRoleLabel(role)}
                      </span>
                    </div>
                  </div>
                  <ChevronsUpDown size={14} className="text-muted-foreground shrink-0 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-[220px]" align="start">
                <DropdownMenuLabel className="text-xs text-muted-foreground">
                  Alternar Clínica
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                {userClinics.map((clinic: any) => (
                  <DropdownMenuItem
                    key={clinic.clinicId}
                    className="gap-2 cursor-pointer"
                    onClick={() => handleSwitchClinic(clinic.clinicId)}
                  >
                    <div className="flex items-center justify-center w-6 h-6 rounded bg-primary/10 text-primary shrink-0">
                      <Building2 size={12} />
                    </div>
                    <div className="flex flex-col flex-1 truncate">
                      <span className="text-sm font-medium truncate">{clinic.name}</span>
                      <span className="text-[10px] text-muted-foreground capitalize">
                        {clinic.role}
                      </span>
                    </div>
                    {clinic.clinicId === actualClinicId && (
                      <Check size={14} className="text-primary ml-auto" />
                    )}
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link
                    to="/create-clinic"
                    className="gap-2 cursor-pointer flex w-full items-center select-none rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50"
                  >
                    <div className="flex items-center justify-center w-6 h-6 rounded border border-dashed border-muted-foreground/30 shrink-0">
                      <PlusIcon size={12} />
                    </div>
                    <span className="text-muted-foreground">Criar nova clínica</span>
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isLocked = item.locked;

            return (
              <Link
                key={item.to}
                to={item.to}
                className={`w-full flex items-center gap-3 px-3 py-2 transition-colors rounded-[var(--radius)] ${
                  isLocked ? "opacity-60 cursor-not-allowed" : ""
                }`}
                activeProps={{
                  className: "bg-sidebar-accent text-sidebar-accent-foreground font-medium",
                }}
                inactiveProps={{
                  className: "text-sidebar-foreground hover:bg-sidebar-accent/50",
                }}
                onClick={(e) => {
                  if (isLocked) {
                    e.preventDefault();
                  }
                }}
              >
                <Icon size={20} />
                <span className="flex-1">{item.label}</span>
                {isLocked && <Lock size={14} className="text-muted-foreground" />}
              </Link>
            );
          })}
        </nav>

        {/* User Profile / Logout could go here at bottom */}
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 min-w-0">
        {/* Page Content */}
        <main className="p-6 space-y-4">
          {isImpersonating && impersonation && (
            <div className="flex flex-col gap-3 rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-sm font-medium text-amber-900">
                  Voce esta visualizando o sistema como {impersonation.name}
                </p>
                <p className="text-sm text-amber-800/80">
                  {impersonation.email} · {displayedClinicName} · {getRoleLabel(role)}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" asChild>
                  <Link to="/system">Abrir painel</Link>
                </Button>
                <Button
                  variant="secondary"
                  onClick={() => {
                    stopImpersonation();
                    toast.success("Visualizacao encerrada");
                  }}
                >
                  Encerrar visualizacao
                </Button>
              </div>
            </div>
          )}
          {children}
        </main>
      </div>
    </div>
  );
}

const PlusIcon = ({ size }: { size: number }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M5 12h14" />
    <path d="M12 5v14" />
  </svg>
);
