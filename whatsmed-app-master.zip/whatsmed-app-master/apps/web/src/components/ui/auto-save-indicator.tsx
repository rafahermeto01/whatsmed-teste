import { Check, Loader2, AlertCircle } from "lucide-react";

import { cn } from "@/lib/utils";

import type { AutoSaveStatus } from "@/hooks/useAutoSave";

interface AutoSaveIndicatorProps {
  status: AutoSaveStatus;
  error?: string | null;
  className?: string;
}

export function AutoSaveIndicator({ status, error, className }: AutoSaveIndicatorProps) {
  if (status === "idle") {
    return null;
  }

  return (
    <div
      className={cn("flex items-center gap-1.5 text-xs transition-opacity duration-200", className)}
    >
      {status === "saving" && (
        <>
          <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" />
          <span className="text-muted-foreground">Salvando...</span>
        </>
      )}
      {status === "saved" && (
        <>
          <Check className="h-3 w-3 text-green-500" />
          <span className="text-green-600">Salvo</span>
        </>
      )}
      {status === "error" && (
        <>
          <AlertCircle className="h-3 w-3 text-destructive" />
          <span className="text-destructive">{error || "Erro ao salvar"}</span>
        </>
      )}
    </div>
  );
}
