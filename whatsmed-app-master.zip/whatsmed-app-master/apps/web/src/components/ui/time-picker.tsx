import * as React from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverAnchor } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface TimePickerProps {
  value: string;
  onChange: (value: string) => void;
  className?: string;
  minTime?: string;
  maxTime?: string;
}

export function TimePicker({ value, onChange, className, minTime, maxTime }: TimePickerProps) {
  const [isOpen, setIsOpen] = React.useState(false);
  const [hours, minutes] = value ? value.split(":") : ["09", "00"];

  const hoursList = Array.from({ length: 24 }, (_, i) => i.toString().padStart(2, "0"));
  const minutesList = Array.from({ length: 12 }, (_, i) => (i * 5).toString().padStart(2, "0")); // 5-minute intervals

  const isTimeDisabled = (h: string, m?: string) => {
    const timeVal = parseInt(h) * 60 + (m ? parseInt(m) : 0);

    if (minTime) {
      const [minH, minM] = minTime.split(":").map(Number);
      const minVal = minH * 60 + minM;
      // If checking only hour, assume minute is 59 (end of hour) to see if ANY minute in this hour is valid
      // Actually, if we are checking hour '09', and min is '09:30', then '09' is valid (because 09:30+ is valid).
      // If min is '10:00', then '09' is invalid.
      if (m === undefined) {
        if (parseInt(h) < minH) return true;
      } else {
        if (timeVal <= minVal) return true; // Strict inequality for overlaps? Usually start < end.
        // Let's stick to standard <= for "unavailable before this".
      }
    }

    if (maxTime) {
      const [maxH, maxM] = maxTime.split(":").map(Number);
      const maxVal = maxH * 60 + maxM;

      if (m === undefined) {
        if (parseInt(h) > maxH) return true;
      } else {
        if (timeVal >= maxVal) return true;
      }
    }

    return false;
  };

  const handleTimeChange = (type: "hour" | "minute", val: string) => {
    let newTime = "";
    if (type === "hour") {
      newTime = `${val}:${minutes}`;
    } else {
      newTime = `${hours}:${val}`;
    }

    // Basic validation to not select disabled time
    const [h, m] = newTime.split(":");
    if (isTimeDisabled(h, m)) return;

    onChange(newTime);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    onChange(newValue);
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverAnchor asChild>
        <div className="relative">
          <Input
            value={value}
            onChange={handleInputChange}
            className={cn("text-center", className)}
            onFocus={() => setIsOpen(true)}
            onClick={() => setIsOpen(true)}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === "Escape") {
                setIsOpen(false);
                e.currentTarget.blur();
              }
            }}
          />
        </div>
      </PopoverAnchor>
      <PopoverContent
        className="w-48 p-0"
        align="start"
        onOpenAutoFocus={(e) => e.preventDefault()} // Prevent stealing focus from input
      >
        <div className="flex h-52 divide-x">
          <ScrollArea className="flex-1">
            <div className="flex flex-col p-1">
              <div className="px-2 py-1 text-xs text-muted-foreground text-center font-medium sticky top-0 bg-popover z-10">
                Horas
              </div>
              {hoursList.map((h) => {
                const disabled = isTimeDisabled(h); // Check if hour is completely out of bounds?
                // Refined logic: disabled if ALL minutes in this hour are disabled.
                // Simpler: just check if h < minH or h > maxH
                return (
                  <Button
                    key={h}
                    variant={hours === h ? "default" : "ghost"}
                    size="sm"
                    disabled={disabled}
                    className="justify-center font-normal"
                    onClick={() => handleTimeChange("hour", h)}
                  >
                    {h}
                  </Button>
                );
              })}
            </div>
          </ScrollArea>
          <ScrollArea className="flex-1">
            <div className="flex flex-col p-1">
              <div className="px-2 py-1 text-xs text-muted-foreground text-center font-medium sticky top-0 bg-popover z-10">
                Minutos
              </div>
              {minutesList.map((m) => {
                const disabled = isTimeDisabled(hours, m);
                return (
                  <Button
                    key={m}
                    variant={minutes === m ? "default" : "ghost"}
                    size="sm"
                    disabled={disabled}
                    className="justify-center font-normal"
                    onClick={() => handleTimeChange("minute", m)}
                  >
                    {m}
                  </Button>
                );
              })}
            </div>
          </ScrollArea>
        </div>
      </PopoverContent>
    </Popover>
  );
}
