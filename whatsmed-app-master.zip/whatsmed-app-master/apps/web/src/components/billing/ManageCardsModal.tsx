import { Trash2, Star, Plus, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  useAddPaymentMethod,
  useBillingPaymentMethods,
  useRemovePaymentMethod,
  useSetDefaultPaymentMethod,
} from "@/hooks/billing";
import { useClinicId } from "@/hooks/patients";

interface ManageCardsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ManageCardsModal({ open, onOpenChange }: ManageCardsModalProps) {
  const { clinicId, user } = useClinicId();
  const paymentMethods = useBillingPaymentMethods(clinicId);
  const addCard = useAddPaymentMethod();
  const removeCard = useRemovePaymentMethod();
  const setDefaultCard = useSetDefaultPaymentMethod();

  const [showAddForm, setShowAddForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [newCard, setNewCard] = useState({
    number: "",
    holder: "",
    expiry: "",
    cvv: "",
    // Holder info
    email: "",
    cpfCnpj: "",
    phone: "",
    postalCode: "",
    addressNumber: "",
  });

  // Initialize email from user when form is shown
  const handleShowAddForm = () => {
    setNewCard((prev) => ({
      ...prev,
      email: user?.email || "",
    }));
    setShowAddForm(true);
  };

  const cards = paymentMethods || [];

  const handleSetDefault = async (cardId: string) => {
    if (!clinicId) return;
    try {
      await setDefaultCard({ clinicId, paymentMethodId: cardId as any });
      toast.success("Cartão padrão atualizado");
    } catch {
      toast.error("Erro ao definir cartão padrão");
    }
  };

  const handleDelete = async (cardId: string) => {
    if (!clinicId) return;
    if (!confirm("Tem certeza que deseja remover este cartão?")) return;
    try {
      await removeCard({ clinicId, paymentMethodId: cardId as any });
      toast.success("Cartão removido");
    } catch {
      toast.error("Erro ao remover cartão");
    }
  };

  const handleAddCard = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clinicId) return;

    setLoading(true);
    try {
      // Split expiry MM/AA or MM/AAAA
      const [expMonth, expYear] = newCard.expiry.split("/");
      if (!expMonth || !expYear) throw new Error("Data de validade inválida");

      // We need more holder info for Asaas tokenization usually,
      // For now asking for minimal or using defaults if allowed, but Asaas needs holder info.
      // I added fields to state.

      await addCard({
        clinicId,
        creditCard: {
          holderName: newCard.holder,
          number: newCard.number.replace(/\s/g, ""),
          expiryMonth: expMonth,
          expiryYear: expYear.length === 2 ? `20${expYear}` : expYear,
          ccv: newCard.cvv,
        },
        creditCardHolderInfo: {
          name: newCard.holder,
          email: newCard.email,
          cpfCnpj: newCard.cpfCnpj,
          postalCode: newCard.postalCode,
          addressNumber: newCard.addressNumber,
          phone: newCard.phone,
        },
      });

      toast.success("Cartão adicionado com sucesso");
      setShowAddForm(false);
      setNewCard({
        number: "",
        holder: "",
        expiry: "",
        cvv: "",
        email: "",
        cpfCnpj: "",
        phone: "",
        postalCode: "",
        addressNumber: "",
      });
    } catch (error: any) {
      toast.error(error.message || "Erro ao adicionar cartão");
    } finally {
      setLoading(false);
    }
  };

  const onClose = () => onOpenChange(false);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Gerenciar Cartões</DialogTitle>
          <p className="text-muted-foreground text-sm">
            Adicione, remova ou defina seu cartão padrão
          </p>
        </DialogHeader>

        {/* Existing Cards */}
        <div className="space-y-3">
          {cards.length === 0 && !showAddForm && (
            <p className="text-center text-muted-foreground py-4">Nenhum cartão cadastrado</p>
          )}
          {cards.map((card: any) => (
            <div
              key={card._id}
              className="flex items-center justify-between p-4 bg-muted/50 border rounded-lg"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary flex items-center justify-center rounded-md font-bold text-primary-foreground text-xs">
                  {card.brand.toUpperCase()}
                </div>
                <div>
                  <p className="font-medium">
                    {card.brand} terminando em {card.last4}
                  </p>
                  {card.isDefault && (
                    <span className="text-xs text-primary font-medium">Cartão Padrão</span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleSetDefault(card._id)}
                  disabled={card.isDefault}
                  title="Definir como padrão"
                  className={card.isDefault ? "text-primary opacity-100" : "text-muted-foreground"}
                >
                  <Star size={18} fill={card.isDefault ? "currentColor" : "none"} />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleDelete(card._id)}
                  disabled={card.isDefault}
                  className="text-destructive hover:text-destructive hover:bg-destructive/10"
                  title="Remover cartão"
                >
                  <Trash2 size={18} />
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Add New Card Section */}
        {!showAddForm ? (
          <Button
            variant="outline"
            className="w-full h-12 border-dashed border-2 flex items-center justify-center gap-2"
            onClick={handleShowAddForm}
          >
            <Plus size={18} />
            Adicionar Novo Cartão
          </Button>
        ) : (
          <form onSubmit={handleAddCard} className="mt-4">
            <div className="p-4 bg-muted/50 border rounded-lg space-y-4">
              <h4 className="font-medium">Novo Cartão</h4>

              <div className="grid gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cardNumber">Número do Cartão</Label>
                  <Input
                    id="cardNumber"
                    value={newCard.number}
                    onChange={(e) => setNewCard({ ...newCard, number: e.target.value })}
                    placeholder="1234 5678 9012 3456"
                    maxLength={19}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="holderName">Nome do Titular</Label>
                  <Input
                    id="holderName"
                    value={newCard.holder}
                    onChange={(e) => setNewCard({ ...newCard, holder: e.target.value })}
                    placeholder="Nome como está no cartão"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="expiry">Validade</Label>
                    <Input
                      id="expiry"
                      value={newCard.expiry}
                      onChange={(e) => setNewCard({ ...newCard, expiry: e.target.value })}
                      placeholder="MM/AA"
                      maxLength={5}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cvv">CVV</Label>
                    <Input
                      id="cvv"
                      value={newCard.cvv}
                      onChange={(e) => setNewCard({ ...newCard, cvv: e.target.value })}
                      placeholder="123"
                      maxLength={4}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Dados do Titular (para nota fiscal)</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <Input
                      placeholder="Email"
                      type="email"
                      value={newCard.email}
                      onChange={(e) => setNewCard({ ...newCard, email: e.target.value })}
                      required
                      className="col-span-2"
                    />
                    <Input
                      placeholder="CPF/CNPJ"
                      value={newCard.cpfCnpj}
                      onChange={(e) => setNewCard({ ...newCard, cpfCnpj: e.target.value })}
                      required
                    />
                    <Input
                      placeholder="Telefone"
                      value={newCard.phone}
                      onChange={(e) => setNewCard({ ...newCard, phone: e.target.value })}
                      required
                    />
                    <Input
                      placeholder="CEP"
                      value={newCard.postalCode}
                      onChange={(e) => setNewCard({ ...newCard, postalCode: e.target.value })}
                      required
                    />
                    <Input
                      placeholder="Número"
                      value={newCard.addressNumber}
                      onChange={(e) => setNewCard({ ...newCard, addressNumber: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="pt-2 text-xs text-muted-foreground text-center">
                  🔒 Protegido por Asaas
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    setShowAddForm(false);
                  }}
                  disabled={loading}
                >
                  Cancelar
                </Button>
                <Button type="submit" className="flex-1" disabled={loading}>
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Adicionar Cartão
                </Button>
              </div>
            </div>
          </form>
        )}

        {!showAddForm && (
          <DialogFooter className="mt-6">
            <Button onClick={onClose} className="px-6">
              Fechar
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}
