import { useState } from "react";

import { PurchaseCreditsModal } from "./PurchaseCreditsModal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useConversationCredits } from "@/hooks/billing";
import { useClinicId } from "@/hooks/patients";

export function CreditsWidget() {
  const { clinicId } = useClinicId();
  const creditStatus = useConversationCredits(clinicId);
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);

  if (!creditStatus) {
    return null;
  }

  const { used, planLimit, purchased, available } = creditStatus;
  const usagePercent = planLimit > 0 ? (used / planLimit) * 100 : 0;

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Créditos de Conversa</CardTitle>
          <CardDescription>
            {used} / {planLimit} conversas usadas neste ciclo
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Uso do Plano</span>
              <span className="font-medium">{Math.round(usagePercent)}%</span>
            </div>
            <Progress value={usagePercent} className="h-2" />
          </div>

          {purchased > 0 && (
            <div className="p-3 bg-muted rounded-md">
              <p className="text-sm font-medium">+ {purchased} créditos extras disponíveis</p>
              <p className="text-xs text-muted-foreground mt-1">Créditos comprados não expiram</p>
            </div>
          )}

          <div className="flex items-center justify-between pt-2">
            <div className="text-sm text-muted-foreground">
              <p>Total disponível: {available} créditos</p>
            </div>
            <Button onClick={() => setShowPurchaseModal(true)} size="sm">
              Comprar Mais
            </Button>
          </div>
        </CardContent>
      </Card>

      <PurchaseCreditsModal open={showPurchaseModal} onOpenChange={setShowPurchaseModal} />
    </>
  );
}
