import { Check, Loader2, AlertTriangle, ExternalLink, CreditCard } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useSubscribeToPlan } from "@/hooks/billing";

interface PlanSelectionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  clinicId: string;
  currentPlan: string;
  hasCard: boolean;
  onNeedCard: () => void;
}

const PLANS = [
  {
    id: "free" as const,
    name: "Gratuito",
    price: 0,
    description: "Para começar",
    features: ["10 conversas/ciclo", "1 usuário", "Suporte por email"],
  },
  {
    id: "starter" as const,
    name: "Inicial",
    price: 497,
    description: "Para clínicas pequenas",
    features: ["100 conversas/ciclo", "1 usuário", "Suporte prioritário", "Relatórios básicos"],
  },
  {
    id: "professional" as const,
    name: "Profissional",
    price: 697,
    description: "Para clínicas em crescimento",
    features: [
      "1.000 conversas/ciclo",
      "3 usuários",
      "Agenda/Agendamentos",
      "IA Avançada",
      "Integrações",
      "NPS",
      "Check-in Antecipado",
      "Teleconsulta",
      "Suporte 24/7",
      "Relatórios avançados",
    ],
    popular: true,
  },
  {
    id: "enterprise" as const,
    name: "Empresarial",
    price: 997,
    description: "Para grandes operações",
    features: [
      "Conversas ilimitadas",
      "Usuários ilimitados",
      "API completa",
      "Gerente de conta dedicado",
      "SLA garantido",
      "White-label",
    ],
  },
];

export function PlanSelectionModal({
  open,
  onOpenChange,
  clinicId,
  currentPlan,
  hasCard,
  onNeedCard,
}: PlanSelectionModalProps) {
  const [subscribing, setSubscribing] = useState(false);
  const [threeDSData, setThreeDSData] = useState<{
    authorizationUrl: string;
    subscriptionId: string;
  } | null>(null);
  const subscribeToPlan = useSubscribeToPlan();

  const handleSubscribe = async (planId: "starter" | "professional" | "enterprise") => {
    if (!hasCard) {
      toast.error("Adicione um cartão de crédito antes de assinar um plano.");
      onOpenChange(false);
      onNeedCard();
      return;
    }

    setSubscribing(true);
    try {
      const result = await subscribeToPlan({ clinicId, plan: planId });

      if (result.requires3DS && result.authorizationUrl) {
        // 3DS required
        setThreeDSData({
          authorizationUrl: result.authorizationUrl,
          subscriptionId: result.subscriptionId || "",
        });
        toast.info("Autenticação 3DS necessária. Complete a verificação para ativar o plano.");
      } else {
        toast.success("Plano assinado com sucesso!");
        onOpenChange(false);
      }
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : "Erro ao assinar plano";
      toast.error(errorMessage);
    } finally {
      setSubscribing(false);
    }
  };

  const handle3DSAuthentication = () => {
    if (!threeDSData?.authorizationUrl) return;

    try {
      const parsedUrl = new URL(threeDSData.authorizationUrl);
      if (parsedUrl.protocol !== "https:") {
        toast.error("URL de autorização inválida.");
        return;
      }
    } catch {
      toast.error("URL de autorização inválida.");
      return;
    }

    window.open(threeDSData.authorizationUrl, "_blank", "width=500,height=600,noopener,noreferrer");
    toast.info(
      "Complete a autenticação na janela aberta. O plano será ativado após a confirmação.",
    );
  };

  const resetState = () => {
    setThreeDSData(null);
    setSubscribing(false);
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) resetState();
        onOpenChange(o);
      }}
    >
      <DialogContent className="max-w-[95vw] w-full sm:max-w-[900px] lg:max-w-[1100px] p-0 gap-0 overflow-hidden">
        {threeDSData ? (
          <>
            <DialogHeader className="p-6 pb-4">
              <DialogTitle className="text-xl">Autenticação 3D Secure</DialogTitle>
              <DialogDescription>Complete a verificação para ativar seu plano</DialogDescription>
            </DialogHeader>
            <div className="px-6 pb-6">
              <div className="flex flex-col items-center space-y-4 py-4">
                <div className="mx-auto w-16 h-16 rounded-full bg-yellow-100 dark:bg-yellow-900/30 flex items-center justify-center mb-2">
                  <CreditCard className="w-8 h-8 text-yellow-600 dark:text-yellow-400" />
                </div>
                <p className="text-sm text-muted-foreground text-center max-w-md">
                  Seu banco requer uma verificação adicional para completar a assinatura. Clique no
                  botão abaixo para abrir a página de autenticação.
                </p>
                <Button className="w-full max-w-sm" onClick={handle3DSAuthentication}>
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Completar Autenticação
                </Button>
                <p className="text-xs text-muted-foreground text-center">
                  O plano será ativado automaticamente após a autenticação.
                </p>
                <Button
                  variant="outline"
                  className="w-full max-w-sm"
                  onClick={() => {
                    resetState();
                    onOpenChange(false);
                  }}
                >
                  Fechar
                </Button>
              </div>
            </div>
          </>
        ) : (
          <>
            <DialogHeader className="p-6 pb-4">
              <DialogTitle className="text-xl">Escolha seu Plano</DialogTitle>
              <DialogDescription>Selecione o plano ideal para sua clínica</DialogDescription>
            </DialogHeader>

            <div className="px-6 pb-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {PLANS.map((plan) => {
                  const isCurrent = currentPlan === plan.id;
                  const isPaid = plan.id !== "free";

                  return (
                    <div
                      key={plan.id}
                      className={`relative rounded-lg border p-5 flex flex-col h-full transition-all ${
                        plan.popular
                          ? "border-primary ring-2 ring-primary bg-primary/5"
                          : "border-border hover:border-muted-foreground/50"
                      } ${isCurrent ? "bg-muted" : ""}`}
                    >
                      {plan.popular && (
                        <Badge className="absolute -top-2.5 left-1/2 -translate-x-1/2 whitespace-nowrap">
                          Mais Popular
                        </Badge>
                      )}

                      <div className="text-center mb-4">
                        <h3 className="font-semibold text-lg">{plan.name}</h3>
                        <p className="text-sm text-muted-foreground">{plan.description}</p>
                      </div>

                      <div className="text-center mb-4">
                        <span className="text-3xl font-bold">R$ {plan.price}</span>
                        {plan.price > 0 && (
                          <span className="text-muted-foreground text-sm">/mês</span>
                        )}
                      </div>

                      <ul className="space-y-2 mb-5 flex-1">
                        {plan.features.map((feature, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm">
                            <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>

                      <Button
                        className="w-full"
                        variant={isCurrent ? "outline" : plan.popular ? "default" : "outline"}
                        disabled={isCurrent || subscribing || !isPaid}
                        onClick={() => {
                          if (isPaid) {
                            handleSubscribe(plan.id as "starter" | "professional" | "enterprise");
                          }
                        }}
                      >
                        {subscribing ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : isCurrent ? (
                          "Plano Atual"
                        ) : !isPaid ? (
                          "Gratuito"
                        ) : (
                          "Assinar"
                        )}
                      </Button>
                    </div>
                  );
                })}
              </div>

              {!hasCard && (
                <div className="mt-4 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg flex items-start gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-500 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-yellow-200">
                    Você precisa adicionar um cartão de crédito antes de assinar um plano pago.
                  </p>
                </div>
              )}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
