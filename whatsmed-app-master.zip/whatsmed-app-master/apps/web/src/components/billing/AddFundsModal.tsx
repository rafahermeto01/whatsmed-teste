import { Copy, CreditCard, QrCode, Loader2, ExternalLink } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useBillingPaymentMethods, useCreateTopUp } from "@/hooks/billing";
import { useClinicId } from "@/hooks/patients";

interface AddFundsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddFundsModal({ open, onOpenChange }: AddFundsModalProps) {
  const { clinicId } = useClinicId();
  const [selectedAmount, setSelectedAmount] = useState(100);
  const [customAmount, setCustomAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"CREDIT_CARD" | "PIX">("CREDIT_CARD");
  const [selectedCardId, setSelectedCardId] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [pixData, setPixData] = useState<{
    encodedImage: string;
    payload: string;
    expirationDate: string;
  } | null>(null);
  const [threeDSData, setThreeDSData] = useState<{
    authorizationUrl: string;
    paymentId: string;
  } | null>(null);

  const paymentMethods = useBillingPaymentMethods(clinicId);
  const createTopUp = useCreateTopUp();

  const quickAmounts = [50, 100, 200];
  const finalAmount = customAmount ? parseFloat(customAmount) : selectedAmount;

  const handleSubmit = async () => {
    if (!clinicId) return;
    if (finalAmount <= 0) {
      toast.error("Valor inválido");
      return;
    }

    if (paymentMethod === "CREDIT_CARD" && !selectedCardId) {
      toast.error("Selecione um cartão");
      return;
    }

    setLoading(true);
    try {
      const result = await createTopUp({
        clinicId,
        amount: finalAmount,
        billingType: paymentMethod,
        cardId: paymentMethod === "CREDIT_CARD" ? (selectedCardId as any) : undefined,
      });

      if (paymentMethod === "PIX" && result.pixQrCode) {
        setPixData(result.pixQrCode);
        toast.success("QR Code gerado com sucesso!");
      } else if (result.requires3DS && result.authorizationUrl) {
        // 3DS required - show authorization UI
        setThreeDSData({
          authorizationUrl: result.authorizationUrl,
          paymentId: result.paymentId,
        });
        toast.info(
          "Autenticação 3DS necessária. Complete a verificação para concluir o pagamento.",
        );
      } else if (result.status === "CONFIRMED" || result.status === "RECEIVED") {
        toast.success("Pagamento processado com sucesso!");
        onOpenChange(false);
      } else {
        // Payment pending (will be confirmed via webhook)
        toast.success("Pagamento em processamento. Você será notificado quando for confirmado.");
        onOpenChange(false);
      }
    } catch (error: any) {
      toast.error(error.message || "Erro ao processar pagamento");
    } finally {
      setLoading(false);
    }
  };

  const handleCopyPix = () => {
    if (pixData?.payload) {
      navigator.clipboard.writeText(pixData.payload);
      toast.success("Código Pix copiado!");
    }
  };

  const resetState = () => {
    setPixData(null);
    setThreeDSData(null);
    setLoading(false);
    setSelectedAmount(100);
    setCustomAmount("");
  };

  const handle3DSAuthentication = () => {
    if (!threeDSData?.authorizationUrl) return;

    try {
      const parsedUrl = new URL(threeDSData.authorizationUrl);
      if (parsedUrl.protocol !== "https:") {
        toast.error("URL de autorização inválida.");
        return;
      }
    } catch {
      toast.error("URL de autorização inválida.");
      return;
    }

    // Open 3DS authentication in a new window
    window.open(threeDSData.authorizationUrl, "_blank", "width=500,height=600,noopener,noreferrer");
    toast.info(
      "Complete a autenticação na janela aberta. O saldo será creditado automaticamente após a confirmação.",
    );
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) resetState();
        onOpenChange(o);
      }}
    >
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Adicionar Fundos</DialogTitle>
        </DialogHeader>

        {threeDSData ? (
          <div className="flex flex-col items-center space-y-4 py-4">
            <div className="text-center space-y-2">
              <div className="mx-auto w-16 h-16 rounded-full bg-yellow-100 dark:bg-yellow-900/30 flex items-center justify-center mb-2">
                <CreditCard className="w-8 h-8 text-yellow-600 dark:text-yellow-400" />
              </div>
              <h3 className="font-medium text-lg">Autenticação 3D Secure</h3>
              <p className="text-sm text-muted-foreground">
                Seu banco requer uma verificação adicional para completar este pagamento.
              </p>
            </div>

            <div className="w-full p-4 bg-muted rounded-lg">
              <p className="text-sm text-center">
                Clique no botão abaixo para abrir a página de autenticação do seu banco. Após
                completar a verificação, o pagamento será processado automaticamente.
              </p>
            </div>

            <Button className="w-full" onClick={handle3DSAuthentication}>
              <ExternalLink className="mr-2 h-4 w-4" />
              Completar Autenticação
            </Button>

            <div className="text-sm text-center text-muted-foreground">
              <p>O saldo será adicionado assim que a autenticação for confirmada.</p>
            </div>

            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                onOpenChange(false);
                resetState();
              }}
            >
              Fechar
            </Button>
          </div>
        ) : pixData ? (
          <div className="flex flex-col items-center space-y-4 py-4">
            <div className="text-center space-y-2">
              <h3 className="font-medium text-lg">Pague via Pix</h3>
              <p className="text-sm text-muted-foreground">
                Escaneie o QR Code ou copie o código abaixo
              </p>
            </div>

            <div className="border p-4 rounded-lg bg-white">
              <img
                src={`data:image/png;base64,${pixData.encodedImage}`}
                alt="Pix QR Code"
                className="w-48 h-48"
              />
            </div>

            <div className="w-full space-y-2">
              <Label>Copia e Cola</Label>
              <div className="flex gap-2">
                <Input value={pixData.payload} readOnly />
                <Button size="icon" variant="outline" onClick={handleCopyPix}>
                  <Copy size={16} />
                </Button>
              </div>
            </div>

            <div className="text-sm text-center text-muted-foreground pt-2">
              <p>O saldo será adicionado assim que o pagamento for confirmado.</p>
            </div>

            <Button
              variant="outline"
              className="w-full mt-4"
              onClick={() => {
                onOpenChange(false);
                resetState();
              }}
            >
              Fechar
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="space-y-3">
              <Label>Valor da Recarga</Label>
              <div className="grid grid-cols-3 gap-3">
                {quickAmounts.map((amount) => (
                  <Button
                    key={amount}
                    variant={selectedAmount === amount && !customAmount ? "default" : "outline"}
                    onClick={() => {
                      setSelectedAmount(amount);
                      setCustomAmount("");
                    }}
                    className="h-12"
                  >
                    R$ {amount}
                  </Button>
                ))}
              </div>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">
                  R$
                </span>
                <Input
                  type="number"
                  value={customAmount}
                  onChange={(e) => {
                    setCustomAmount(e.target.value);
                    setSelectedAmount(0);
                  }}
                  placeholder="Outro valor"
                  min="5"
                  step="0.01"
                  className="pl-10"
                />
              </div>
            </div>

            <Tabs
              value={paymentMethod}
              onValueChange={(v) => setPaymentMethod(v as "CREDIT_CARD" | "PIX")}
            >
              <TabsList className="grid grid-cols-2 w-full">
                <TabsTrigger value="CREDIT_CARD">
                  <CreditCard className="mr-2 h-4 w-4" /> Cartão
                </TabsTrigger>
                <TabsTrigger value="PIX">
                  <QrCode className="mr-2 h-4 w-4" /> Pix
                </TabsTrigger>
              </TabsList>

              <TabsContent value="CREDIT_CARD" className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label>Selecione o Cartão</Label>
                  {paymentMethods && paymentMethods.length > 0 ? (
                    <Select value={selectedCardId} onValueChange={setSelectedCardId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione..." />
                      </SelectTrigger>
                      <SelectContent>
                        {paymentMethods.map((card: any) => (
                          <SelectItem key={card._id} value={card._id}>
                            {card.brand} •••• {card.last4}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ) : (
                    <div className="text-sm text-muted-foreground p-3 border rounded-md bg-muted/50">
                      Nenhum cartão cadastrado. Adicione um cartão em "Gerenciar Cartões".
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="PIX" className="pt-4">
                <div className="text-sm text-muted-foreground">
                  QR Code será gerado na próxima etapa. Pagamento instantâneo.
                </div>
              </TabsContent>
            </Tabs>

            <div className="p-4 bg-muted rounded-md flex items-center justify-between">
              <span className="text-sm font-medium">Total a Pagar:</span>
              <span className="text-lg font-bold">R$ {finalAmount?.toFixed(2) || "0.00"}</span>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
                Cancelar
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={
                  loading ||
                  !finalAmount ||
                  finalAmount <= 0 ||
                  (paymentMethod === "CREDIT_CARD" && !selectedCardId)
                }
              >
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {paymentMethod === "PIX" ? "Gerar QR Code" : "Pagar Agora"}
              </Button>
            </DialogFooter>

            <div className="text-center">
              <p className="text-xs text-muted-foreground">🔒 Protegido por Asaas</p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
