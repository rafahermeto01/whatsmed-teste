import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useBillingWallet, useUpdateAutoRechargeSettings } from "@/hooks/billing";
import { useClinicId } from "@/hooks/patients";

interface AutoRechargeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AutoRechargeModal({ open, onOpenChange }: AutoRechargeModalProps) {
  const { clinicId } = useClinicId();
  const wallet = useBillingWallet(clinicId);
  const updateSettings = useUpdateAutoRechargeSettings();

  const [enabled, setEnabled] = useState(false);
  const [thresholdAmount, setThresholdAmount] = useState("20.00");
  const [rechargeAmount, setRechargeAmount] = useState("50.00");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (wallet) {
      setEnabled(wallet.autoRechargeEnabled);
      if (wallet.autoRechargeThreshold) {
        setThresholdAmount(wallet.autoRechargeThreshold.toFixed(2));
      }
      if (wallet.autoRechargeAmount) {
        setRechargeAmount(wallet.autoRechargeAmount.toFixed(2));
      }
    }
  }, [wallet]);

  const handleSave = async () => {
    if (!clinicId) return;
    setLoading(true);
    try {
      await updateSettings({
        clinicId,
        enabled,
        threshold: parseFloat(thresholdAmount),
        amount: parseFloat(rechargeAmount),
      });
      toast.success("Configurações de recarga automática atualizadas");
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar configurações");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Configurar Recarga Automática</DialogTitle>
          <p className="text-muted-foreground text-sm">
            Configure a recarga automática para nunca ficar sem saldo
          </p>
        </DialogHeader>

        {/* Enable Toggle */}
        <div className="flex items-center justify-between p-4 bg-muted rounded-md mb-4">
          <div className="space-y-0.5">
            <h4 className="text-sm font-medium">Habilitar Recarga Automática</h4>
            <p className="text-xs text-muted-foreground">
              Recarregue automaticamente quando o saldo estiver baixo
            </p>
          </div>
          <Switch checked={enabled} onCheckedChange={setEnabled} />
        </div>

        {enabled && (
          <div className="space-y-4">
            {/* Logic Inputs */}

            {/* Threshold */}
            <div className="space-y-2">
              <Label htmlFor="threshold">Quando o saldo cair abaixo de</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">
                  R$
                </span>
                <Input
                  id="threshold"
                  type="number"
                  value={thresholdAmount}
                  onChange={(e) => setThresholdAmount(e.target.value)}
                  min="0"
                  step="0.01"
                  className="pl-10"
                />
              </div>
            </div>

            {/* Recharge Amount */}
            <div className="space-y-2">
              <Label htmlFor="recharge">Adicionar automaticamente</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">
                  R$
                </span>
                <Input
                  id="recharge"
                  type="number"
                  value={rechargeAmount}
                  onChange={(e) => setRechargeAmount(e.target.value)}
                  min="0"
                  step="0.01"
                  className="pl-10"
                />
              </div>
            </div>

            {/* Note about card */}
            <div className="p-4 bg-accent/10 border border-accent/20 rounded-md text-sm text-foreground">
              <strong>Nota:</strong> A recarga automática utilizará o seu cartão definido como
              padrão.
            </div>

            {/* Preview */}
            <div className="text-sm text-muted-foreground">
              Resumo: Quando seu saldo cair abaixo de{" "}
              <strong>R$ {parseFloat(thresholdAmount || "0").toFixed(2)}</strong>, será
              automaticamente adicionado{" "}
              <strong>R$ {parseFloat(rechargeAmount || "0").toFixed(2)}</strong>.
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={loading}>
            {loading ? "Salvando..." : "Salvar Configurações"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
