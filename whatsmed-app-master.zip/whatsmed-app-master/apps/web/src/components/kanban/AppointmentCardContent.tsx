import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Calendar, Clock, User, Stethoscope, Phone } from "lucide-react";

import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface AppointmentCardContentProps {
  patientName: string;
  patientPhone?: string;
  startAt: number;
  doctor?: string;
  procedure?: string;
  status: string;
  onClick?: () => void;
}

const statusColors: Record<string, string> = {
  pending: "border-l-yellow-500",
  confirmed: "border-l-green-500",
  arrived: "border-l-purple-500",
  completed: "border-l-blue-500",
  cancelled: "border-l-red-500",
};

export function AppointmentCardContent({
  patientName,
  patientPhone,
  startAt,
  doctor,
  procedure,
  status,
  onClick,
}: AppointmentCardContentProps) {
  const date = new Date(startAt);

  return (
    <Card
      className={cn(
        "p-3 bg-card border-l-4 hover:shadow-md transition-shadow cursor-pointer",
        statusColors[status] || "border-l-gray-500",
      )}
      onClick={onClick}
    >
      <div className="space-y-2">
        {/* Patient Name */}
        <div className="flex items-center gap-2">
          <User className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="font-semibold text-sm truncate">{patientName}</span>
        </div>

        {/* Date & Time */}
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            <span>{format(date, "dd/MM", { locale: ptBR })}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>{format(date, "HH:mm")}</span>
          </div>
        </div>

        {/* Doctor */}
        {doctor && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Stethoscope className="h-3 w-3" />
            <span className="truncate">{doctor}</span>
          </div>
        )}

        {/* Procedure */}
        {procedure && (
          <div className="text-xs text-muted-foreground bg-muted/50 px-2 py-1 rounded truncate">
            {procedure}
          </div>
        )}

        {/* Phone */}
        {patientPhone && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Phone className="h-3 w-3" />
            <span>{patientPhone}</span>
          </div>
        )}
      </div>
    </Card>
  );
}
