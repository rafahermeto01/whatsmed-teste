import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useSensor,
  useSensors,
  closestCenter,
} from "@dnd-kit/core";
import { useState, useCallback } from "react";

import { KanbanCard } from "./KanbanCard";
import { KanbanColumn } from "./KanbanColumn";

import type { DragEndEvent, DragStartEvent } from "@dnd-kit/core";

export interface KanbanItem {
  _id: string;
  name?: string;
  patientName?: string;
  phone?: string;
  patientPhone?: string;
  startAt?: number;
  doctor?: string;
  procedure?: string;
}

export interface KanbanBoardProps<T extends KanbanItem> {
  columns: {
    id: string;
    title: string;
    color: string;
    items: T[];
  }[];
  onDragEnd: (itemId: string, fromColumn: string, toColumn: string) => void;
  renderCard: (item: T) => React.ReactNode;
  isLoading?: boolean;
}

export function KanbanBoard<T extends KanbanItem>({
  columns,
  onDragEnd,
  renderCard,
  isLoading,
}: KanbanBoardProps<T>) {
  const [activeItem, setActiveItem] = useState<T | null>(null);
  const [activeColumnId, setActiveColumnId] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
  );

  const handleDragStart = useCallback(
    (event: DragStartEvent) => {
      const { active } = event;
      const itemId = active.id as string;

      // Find which column contains this item
      for (const column of columns) {
        const item = column.items.find((i) => i._id === itemId);
        if (item) {
          setActiveItem(item);
          setActiveColumnId(column.id);
          break;
        }
      }
    },
    [columns],
  );

  const handleDragEnd = useCallback(
    (event: DragEndEvent) => {
      const { active, over } = event;

      setActiveItem(null);
      setActiveColumnId(null);

      if (!over || !activeColumnId) return;

      const itemId = active.id as string;
      const toColumnId = over.id as string;

      // Only trigger if dropped on a different column
      if (activeColumnId !== toColumnId) {
        onDragEnd(itemId, activeColumnId, toColumnId);
      }
    },
    [activeColumnId, onDragEnd],
  );

  const handleDragCancel = useCallback(() => {
    setActiveItem(null);
    setActiveColumnId(null);
  }, []);

  if (isLoading) {
    return (
      <div className="flex gap-4 pb-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div
            key={i}
            className="flex-1 min-w-[250px] h-[400px] bg-muted/50 rounded-lg animate-pulse"
          />
        ))}
      </div>
    );
  }

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      onDragCancel={handleDragCancel}
    >
      <div className="flex gap-4 pb-4 min-h-[500px]">
        {columns.map((column) => (
          <KanbanColumn
            key={column.id}
            id={column.id}
            title={column.title}
            color={column.color}
            count={column.items.length}
          >
            {column.items.map((item) => (
              <KanbanCard key={item._id} id={item._id}>
                {renderCard(item)}
              </KanbanCard>
            ))}
          </KanbanColumn>
        ))}
      </div>

      <DragOverlay>
        {activeItem ? (
          <div className="opacity-80 rotate-3 scale-105 shadow-2xl">{renderCard(activeItem)}</div>
        ) : null}
      </DragOverlay>
    </DndContext>
  );
}
