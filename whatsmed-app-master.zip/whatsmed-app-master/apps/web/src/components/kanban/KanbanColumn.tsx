import { useDroppable } from "@dnd-kit/core";

import { cn } from "@/lib/utils";

interface KanbanColumnProps {
  id: string;
  title: string;
  color: string;
  count: number;
  children: React.ReactNode;
}

export function KanbanColumn({ id, title, color, count, children }: KanbanColumnProps) {
  const { setNodeRef, isOver } = useDroppable({
    id,
  });

  return (
    <div
      ref={setNodeRef}
      className={cn(
        "flex-1 min-w-[250px] bg-muted/30 rounded-lg border border-border transition-all duration-200",
        isOver && "ring-2 ring-primary ring-offset-2 bg-primary/5",
      )}
    >
      {/* Column Header */}
      <div className="p-3 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className={cn("w-3 h-3 rounded-full", color)} />
            <h3 className="font-semibold text-sm text-foreground">{title}</h3>
          </div>
          <span className="text-xs font-medium text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
            {count}
          </span>
        </div>
      </div>

      {/* Column Content */}
      <div className="p-2 space-y-2 min-h-[300px] max-h-[calc(100vh-300px)] overflow-y-auto">
        {children}

        {count === 0 && (
          <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">
            Nenhum item
          </div>
        )}
      </div>
    </div>
  );
}
