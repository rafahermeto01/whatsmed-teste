import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { User, Phone, Mail, Calendar } from "lucide-react";

import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface PatientCardContentProps {
  name: string;
  phone?: string;
  email?: string;
  lastCompletedAppointmentAt?: number;
  nextScheduledAppointmentAt?: number;
  stage?: string;
  onClick?: () => void;
}

const stageColors: Record<string, string> = {
  // Remarketing stages
  needs_contact: "border-l-orange-500",
  contacted: "border-l-blue-500",
  scheduled: "border-l-green-500",
  not_interested: "border-l-gray-500",
  // Lead stages
  new_lead: "border-l-purple-500",
  converted: "border-l-emerald-500",
};

export function PatientCardContent({
  name,
  phone,
  email,
  lastCompletedAppointmentAt,
  nextScheduledAppointmentAt,
  stage,
  onClick,
}: PatientCardContentProps) {
  return (
    <Card
      className={cn(
        "p-3 bg-card border-l-4 hover:shadow-md transition-shadow cursor-pointer",
        stage ? stageColors[stage] || "border-l-gray-400" : "border-l-gray-400",
      )}
      onClick={onClick}
    >
      <div className="space-y-2">
        {/* Patient Name */}
        <div className="flex items-center gap-2">
          <User className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="font-semibold text-sm truncate">{name}</span>
        </div>

        {/* Phone */}
        {phone && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Phone className="h-3 w-3" />
            <span>{phone}</span>
          </div>
        )}

        {/* Email */}
        {email && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Mail className="h-3 w-3" />
            <span className="truncate">{email}</span>
          </div>
        )}

        {/* Last completed appointment */}
        {lastCompletedAppointmentAt && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Calendar className="h-3 w-3" />
            <span>
              Última consulta:{" "}
              {format(new Date(lastCompletedAppointmentAt), "dd/MM/yyyy", { locale: ptBR })}
            </span>
          </div>
        )}

        {/* Next scheduled appointment */}
        {nextScheduledAppointmentAt && nextScheduledAppointmentAt > Date.now() && (
          <div className="flex items-center gap-2 text-xs text-green-600">
            <Calendar className="h-3 w-3" />
            <span>
              Próxima:{" "}
              {format(new Date(nextScheduledAppointmentAt), "dd/MM/yyyy", { locale: ptBR })}
            </span>
          </div>
        )}
      </div>
    </Card>
  );
}
