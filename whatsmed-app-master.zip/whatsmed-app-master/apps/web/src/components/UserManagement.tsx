import { useAction, useMutation, useQuery } from "convex/react";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { MoreVertical, Plus, Search, Shield, Trash2, User as UserIcon } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

type UserRole = "admin" | "staff" | "viewer" | "doctor" | "super_admin";

export function UserManagement({ clinicId }: { clinicId?: string }) {
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<UserRole | "all">("all");
  const [showCreateUserModal, setShowCreateUserModal] = useState(false);
  const [userData, setUserData] = useState({
    email: "",
    role: "staff" as UserRole,
    name: "",
    phone: "",
    password: "",
  });

  const users = useQuery(
    api.users.list,
    clinicId
      ? {
          clinicId,
          search: search || undefined,
          role: roleFilter === "all" ? undefined : roleFilter,
        }
      : "skip",
  );

  const createUser = useAction(api.users.createUser);
  const updateRole = useMutation(api.users.updateRole);
  const deleteUser = useMutation(api.users.softDelete);

  const resetCreateUserForm = () => {
    setShowCreateUserModal(false);
    setUserData({
      email: "",
      role: "staff",
      name: "",
      phone: "",
      password: "",
    });
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clinicId) return;

    try {
      await createUser({
        email: userData.email,
        role: userData.role,
        name: userData.name,
        phone: userData.phone || undefined,
        password: userData.password,
      });

      toast.success("Usuário criado", {
        description: `${userData.email} já pode entrar com a senha cadastrada.`,
      });

      resetCreateUserForm();
    } catch (err: any) {
      console.error(err);
      toast.error("Erro ao criar usuário", {
        description: err?.message || "Não foi possível criar o usuário agora.",
      });
    }
  };

  const handleUpdateRole = async (userId: string, newRole: UserRole) => {
    try {
      await updateRole({ id: userId, role: newRole, clinicId });
      toast.success("Função atualizada", {
        description: "A permissão do usuário foi alterada com sucesso.",
      });
    } catch (err) {
      console.error(err);
      toast.error("Erro ao atualizar", {
        description: "Não foi possível alterar a função.",
      });
    }
  };

  const handleDelete = async (userId: string) => {
    if (!confirm("Tem certeza que deseja remover este usuário?")) return;

    try {
      await deleteUser({ id: userId, clinicId });
      toast.success("Usuário removido", {
        description: "O usuário foi removido da equipe.",
      });
    } catch (err) {
      console.error(err);
      toast.error("Erro ao remover", {
        description: "Não foi possível remover o usuário.",
      });
    }
  };

  if (!clinicId) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        Selecione uma clínica para gerenciar usuários.
      </div>
    );
  }

  return (
    <Card className="border-none shadow-none">
      <CardHeader className="px-0 pt-0 pb-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <CardTitle>Membros da Equipe</CardTitle>
            <CardDescription>Gerencie o acesso e as permissões dos usuários.</CardDescription>
          </div>
          <Button onClick={() => setShowCreateUserModal(true)}>
            <Plus size={18} className="mr-2" />
            Criar Usuário
          </Button>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mt-6">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por nome ou email..."
              className="pl-9"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Select
            value={roleFilter}
            onValueChange={(val) => setRoleFilter(val as UserRole | "all")}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtrar por função" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as funções</SelectItem>
              <SelectItem value="admin">Administrador</SelectItem>
              <SelectItem value="staff">Equipe</SelectItem>
              <SelectItem value="doctor">Médico</SelectItem>
              <SelectItem value="viewer">Visualizador</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>

      <CardContent className="px-0">
        <div className="space-y-4">
          {users === undefined ? (
            Array.from({ length: 3 }).map((_, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-4 bg-muted/20 rounded-lg border"
              >
                <div className="flex items-center gap-4">
                  <Skeleton className="w-12 h-12 rounded-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-48" />
                  </div>
                </div>
                <Skeleton className="h-8 w-24" />
              </div>
            ))
          ) : users.items.length === 0 ? (
            <div className="text-center py-12 border rounded-lg bg-muted/10">
              <UserIcon className="mx-auto h-12 w-12 text-muted-foreground/50 mb-3" />
              <h3 className="text-lg font-medium text-foreground">Nenhum usuário encontrado</h3>
              <p className="text-muted-foreground mt-1">
                {search || roleFilter !== "all"
                  ? "Tente ajustar seus filtros de busca."
                  : "Comece criando membros para sua equipe."}
              </p>
            </div>
          ) : (
            users.items.map((user: any) => (
              <div
                key={user._id}
                className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-card hover:bg-accent/5 transition-colors rounded-lg border gap-4"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium border border-primary/20 shrink-0">
                    {user.name
                      .split(" ")
                      .map((part: string) => part[0])
                      .join("")
                      .toUpperCase()
                      .slice(0, 2)}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium text-foreground">{user.name}</h4>
                      {user.isActive ? (
                        <Badge
                          variant="outline"
                          className="bg-green-500/10 text-green-600 border-green-500/20 h-5 px-1.5 text-[10px]"
                        >
                          Ativo
                        </Badge>
                      ) : (
                        <Badge
                          variant="outline"
                          className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20 h-5 px-1.5 text-[10px]"
                        >
                          Pendente
                        </Badge>
                      )}
                    </div>
                    <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3 text-sm text-muted-foreground mt-0.5">
                      <span>{user.email}</span>
                      {user.lastLoginAt && (
                        <>
                          <span className="hidden sm:inline text-muted-foreground/30">•</span>
                          <span className="text-xs">
                            Acesso:{" "}
                            {formatDistanceToNow(user.lastLoginAt, {
                              addSuffix: true,
                              locale: ptBR,
                            })}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 self-end sm:self-auto">
                  <Badge variant="secondary" className="capitalize font-normal">
                    {user.role === "admin"
                      ? "Administrador"
                      : user.role === "doctor"
                        ? "Médico"
                        : user.role === "viewer"
                          ? "Visualizador"
                          : "Equipe"}
                  </Badge>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreVertical size={16} className="text-muted-foreground" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56">
                      <DropdownMenuLabel>Gerenciar Acesso</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <div className="p-2">
                        <p className="text-xs font-medium text-muted-foreground mb-2">
                          Alterar Função
                        </p>
                        <div className="grid gap-1">
                          {(["admin", "staff", "doctor", "viewer"] as const).map((role) => (
                            <DropdownMenuItem
                              key={role}
                              className="flex items-center justify-between cursor-pointer"
                              disabled={user.role === role}
                              onClick={() => handleUpdateRole(user._id, role)}
                            >
                              <span className="capitalize">
                                {role === "admin"
                                  ? "Administrador"
                                  : role === "doctor"
                                    ? "Médico"
                                    : role === "viewer"
                                      ? "Visualizador"
                                      : "Equipe"}
                              </span>
                              {user.role === role && <Shield size={14} className="text-primary" />}
                            </DropdownMenuItem>
                          ))}
                        </div>
                      </div>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        className="text-destructive focus:text-destructive focus:bg-destructive/10 cursor-pointer"
                        onClick={() => handleDelete(user._id)}
                      >
                        <Trash2 size={14} className="mr-2" /> Remover Usuário
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>

      <Dialog
        open={showCreateUserModal}
        onOpenChange={(open) => {
          if (!open) {
            resetCreateUserForm();
            return;
          }

          setShowCreateUserModal(true);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Criar Usuário</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCreateUser} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="createUserName">Nome</Label>
              <Input
                id="createUserName"
                value={userData.name}
                onChange={(e) => setUserData({ ...userData, name: e.target.value })}
                placeholder="Nome completo"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="createUserEmail">E-mail</Label>
              <Input
                id="createUserEmail"
                type="email"
                value={userData.email}
                onChange={(e) => setUserData({ ...userData, email: e.target.value })}
                placeholder="usuario@exemplo.com"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="createUserPhone">Telefone</Label>
              <Input
                id="createUserPhone"
                type="tel"
                value={userData.phone}
                onChange={(e) => setUserData({ ...userData, phone: e.target.value })}
                placeholder="+5511999999999"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="createUserPassword">Senha</Label>
              <Input
                id="createUserPassword"
                type="password"
                value={userData.password}
                onChange={(e) => setUserData({ ...userData, password: e.target.value })}
                placeholder="Pelo menos 8 caracteres"
                minLength={8}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="createUserRole">Função</Label>
              <Select
                value={userData.role}
                onValueChange={(val) => setUserData({ ...userData, role: val as UserRole })}
              >
                <SelectTrigger id="createUserRole">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="staff">Equipe</SelectItem>
                  <SelectItem value="admin">Administrador</SelectItem>
                  <SelectItem value="doctor">Médico</SelectItem>
                  <SelectItem value="viewer">Visualizador</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={resetCreateUserForm}>
                Cancelar
              </Button>
              <Button type="submit">Criar Usuário</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
