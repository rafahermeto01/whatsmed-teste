import { Link } from "@tanstack/react-router";

export default function Header() {
  const links = [
    { to: "/dashboard", label: "Home" },
    { to: "/dashboard", label: "Dashboard" },
    { to: "/whatsapp", label: "WhatsApp" },
    { to: "/patients", label: "Pacientes" },
    { to: "/appointments", label: "Consultas" },
    { to: "/automation", label: "Automação" },
    { to: "/billing", label: "Cobrança" },
    { to: "/integrations", label: "Integrações" },
    { to: "/settings", label: "Configurações" },
  ] as const;

  return (
    <div>
      <div className="flex flex-row items-center justify-between px-2 py-1">
        <nav className="flex flex-wrap gap-4 text-sm md:text-lg">
          {links.map(({ to, label }) => {
            return (
              <Link key={to} to={to}>
                {label}
              </Link>
            );
          })}
        </nav>
        <div className="flex items-center gap-2"></div>
      </div>
      <hr />
    </div>
  );
}
