import { Upload, File, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useClinicId, useImportPatients } from "@/hooks/patients";

function parseCSVLine(line: string, delimiter: "," | ";" = ","): string[] {
  const result: string[] = [];
  let current = "";
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    const nextChar = line[i + 1];

    if (inQuotes) {
      if (char === '"' && nextChar === '"') {
        current += '"';
        i++;
      } else if (char === '"') {
        inQuotes = false;
      } else {
        current += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === delimiter || char === ";") {
        result.push(current.trim());
        current = "";
      } else {
        current += char;
      }
    }
  }
  result.push(current.trim());
  return result;
}

function detectDelimiter(text: string): "," | ";" {
  const firstLine = text.split(/\r?\n/)[0] || "";
  const commaCount = (firstLine.match(/,/g) || []).length;
  const semicolonCount = (firstLine.match(/;/g) || []).length;
  return semicolonCount > commaCount ? ";" : ",";
}

export function BulkImportModal({
  open,
  onOpenChange,
  onSuccess,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [mappings, setMappings] = useState<Record<string, string>>({});
  const [step, setStep] = useState<"upload" | "mapping">("upload");
  const [importing, setImporting] = useState(false);
  const [fileHeaders, setFileHeaders] = useState<string[]>([]);
  const importPatients = useImportPatients();
  const { clinicId } = useClinicId();

  const systemFields = [
    { value: "name", label: "Nome" },
    { value: "phone", label: "Telefone" },
    { value: "email", label: "Email" },
    { value: "cpf", label: "CPF" },
    { value: "dateOfBirth", label: "Data de Nascimento" },
    { value: "gender", label: "Gênero" },
    { value: "address", label: "Endereço" },
    { value: "city", label: "Cidade" },
    { value: "state", label: "Estado" },
    { value: "zip", label: "CEP" },
    { value: "country", label: "País" },
    { value: "externalId", label: "ID Externo" },
    { value: "notes", label: "Notas" },
    { value: "tags", label: "Tags (separadas por ;)" },
    { value: "status", label: "Status (active/inactive)" },
  ];

  const processFile = async (f: File) => {
    try {
      setFile(f);
      const text = await f.text();
      const delimiter = detectDelimiter(text);
      const firstLine = text.split(/\r?\n/)[0];
      if (firstLine) {
        const headers = parseCSVLine(firstLine, delimiter);
        setFileHeaders(headers);

        const newMappings: Record<string, string> = {};
        headers.forEach((h) => {
          const lower = h.toLowerCase();
          if (lower.includes("nome") && !lower.includes("usuario")) newMappings[h] = "name";
          else if (
            lower.includes("tel") ||
            lower.includes("fone") ||
            lower.includes("cel") ||
            lower.includes("whats")
          )
            newMappings[h] = "phone";
          else if (lower.includes("mail") || lower.includes("e-mail")) newMappings[h] = "email";
          else if (lower.includes("cpf")) newMappings[h] = "cpf";
          else if (lower.includes("nasc") || lower.includes("birth") || lower.includes("data nasc"))
            newMappings[h] = "dateOfBirth";
          else if (lower.includes("sexo") || lower.includes("gênero") || lower.includes("gender"))
            newMappings[h] = "gender";
          else if (lower.includes("end") && !lower.includes("email")) newMappings[h] = "address";
          else if (lower.includes("cidade") || lower.includes("city")) newMappings[h] = "city";
          else if (lower.includes("uf") || lower.includes("estado")) newMappings[h] = "state";
          else if (lower.includes("cep")) newMappings[h] = "zip";
          else if (lower.includes("país") || lower.includes("country")) newMappings[h] = "country";
          else if (lower.includes("id") && (lower.includes("ext") || lower.includes("externo")))
            newMappings[h] = "externalId";
          else if (lower.includes("nota") || lower.includes("obs") || lower.includes("obser"))
            newMappings[h] = "notes";
          else if (lower.includes("tag")) newMappings[h] = "tags";
          else if (lower.includes("status")) newMappings[h] = "status";
        });
        setMappings(newMappings);
      }
      setStep("mapping");
    } catch (err) {
      console.error(err);
      toast.error("Erro ao ler arquivo");
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const parseCSV = async (f: File) => {
    const text = await f.text();
    const lines = text.split(/\r?\n/).filter((line) => line.trim());
    if (lines.length < 2) return [];

    const delimiter = detectDelimiter(text);
    const headers = parseCSVLine(lines[0], delimiter);

    const result = [];
    for (let i = 1; i < lines.length; i++) {
      const values = parseCSVLine(lines[i], delimiter);
      const obj: any = {};
      let hasData = false;

      headers.forEach((h, index) => {
        if (mappings[h] && mappings[h] !== "ignore" && values[index]) {
          obj[mappings[h]] = values[index];
          hasData = true;
        }
      });

      if (hasData && obj.name) {
        result.push(obj);
      }
    }
    return result;
  };

  const handleSubmit = async () => {
    if (!file) return;
    setImporting(true);

    try {
      const patients = await parseCSV(file);
      if (patients.length === 0) {
        toast.error(
          "Nenhum paciente válido encontrado. Verifique o mapeamento (Nome é obrigatório).",
        );
        setImporting(false);
        return;
      }

      if (!clinicId) throw new Error("Sem clínica");
      const data = await importPatients({ clinicId, patients });
      if (data.failed > 0) {
        toast.warning(
          `Importação: ${data.success} sucessos, ${data.failed} falhas. Verifique logs/erros.`,
        );
      } else {
        toast.success(`${data.success} pacientes importados com sucesso!`);
      }

      onSuccess?.();
      onOpenChange(false);

      // Reset
      setFile(null);
      setStep("upload");
      setMappings({});
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || "Erro na importação");
    } finally {
      setImporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Importação em Massa</DialogTitle>
          <p className="text-muted-foreground text-sm">
            Importe múltiplos pacientes de um arquivo CSV
          </p>
        </DialogHeader>

        {step === "upload" ? (
          <div>
            <div
              onDrop={handleDrop}
              onDragOver={(e) => e.preventDefault()}
              className="border-2 border-dashed border-border p-12 text-center cursor-pointer hover:border-primary transition-colors rounded-[var(--radius)]"
              onClick={() => document.getElementById("fileInput")?.click()}
            >
              <Upload size={48} className="mx-auto mb-4 text-muted-foreground" />
              <p className="text-foreground mb-2">Arraste e solte o arquivo CSV aqui</p>
              <p className="text-sm text-muted-foreground mb-4">ou clique para selecionar</p>
              <input
                id="fileInput"
                type="file"
                accept=".csv"
                onChange={handleFileChange}
                className="hidden"
              />
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* File Info */}
            <div className="flex items-center gap-3 p-3 bg-muted rounded-[var(--radius)]">
              <File size={20} className="text-muted-foreground" />
              <span className="text-foreground text-sm">{file?.name}</span>
            </div>

            {/* Mapping Section */}
            <div>
              <h4 className="text-foreground mb-4 font-medium">Mapear Colunas</h4>
              <p className="text-sm text-muted-foreground mb-4">
                Associe as colunas do arquivo aos campos do sistema
              </p>

              <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2">
                {fileHeaders.map((header, index) => (
                  <div key={index} className="grid grid-cols-2 gap-4 items-center">
                    <div
                      className="px-3 py-2 bg-muted rounded-[var(--radius)] truncate"
                      title={header}
                    >
                      <span className="text-foreground text-sm">{header}</span>
                    </div>
                    <Select
                      value={mappings[header] || ""}
                      onValueChange={(val) =>
                        setMappings((prev) => ({
                          ...prev,
                          [header]: val,
                        }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o campo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ignore">Não mapear</SelectItem>
                        {systemFields.map((field) => (
                          <SelectItem key={field.value} value={field.value}>
                            {field.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                ))}
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setStep("upload")} disabled={importing}>
                Voltar
              </Button>
              <Button onClick={handleSubmit} disabled={importing}>
                {importing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {importing ? "Importando..." : "Iniciar Importação"}
              </Button>
            </DialogFooter>
          </div>
        )}

        {step === "upload" && (
          <DialogFooter>
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Fechar
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}
