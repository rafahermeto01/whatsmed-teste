import { useQuery } from "convex/react";
import {
  Video,
  Building2,
  Calendar,
  Clock,
  User,
  FileText,
  Loader2,
  Check,
  CalendarClock,
  DollarSign,
  Timer,
  UserCheck,
} from "lucide-react";
import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { toast } from "sonner";

import { TelehealthModal } from "@/components/appointments/TelehealthModal";
import { RescheduleAppointmentModal } from "@/components/RescheduleAppointmentModal";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { useUpdateAppointment, useClinicId } from "@/hooks/appointments";
import { cn } from "@/lib/utils";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

import type { Id } from "@whatsmed-app/backend/convex/_generated/dataModel";

interface Appointment {
  _id: string;
  patientId?: Id<"patients">;
  startAt: number;
  endAt?: number;
  patientName: string;
  doctor?: string;
  doctorId?: Id<"users">;
  procedure?: string;
  procedureId?: Id<"procedures">;
  status: "confirmed" | "pending" | "cancelled" | "completed" | "arrived";
  notes?: string;
  createdAt: number;
  isTelemedicine?: boolean;
  meetingLink?: string;
  rescheduleStatus?: "none" | "awaiting_response" | "rescheduled";
  actualArrivalTime?: number;
}

interface AppointmentDetailsModalProps {
  appointment: Appointment | null;
  onClose: () => void;
}

type AppointmentStatus = "confirmed" | "pending" | "cancelled" | "completed" | "arrived";

export function AppointmentDetailsModal({ appointment, onClose }: AppointmentDetailsModalProps) {
  const [status, setStatus] = useState<AppointmentStatus>("pending");
  const [notes, setNotes] = useState("");
  const [telehealthOpen, setTelehealthOpen] = useState(false);
  const [rescheduleOpen, setRescheduleOpen] = useState(false);
  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved">("idle");

  const updateAppointment = useUpdateAppointment();
  const { clinicId } = useClinicId();

  // Track initial values for change detection
  const initialValuesRef = useRef<{ status: AppointmentStatus; notes: string } | null>(null);
  const saveTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const savedIndicatorTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Fetch procedure details if procedureId exists
  const procedure = useQuery(
    api.procedures.getById,
    appointment?.procedureId && clinicId ? { id: appointment.procedureId, clinicId } : "skip",
  );

  // Initialize state when appointment changes
  useEffect(() => {
    if (appointment) {
      const initialStatus = appointment.status;
      const initialNotes = appointment.notes || "";
      setStatus(initialStatus);
      setNotes(initialNotes);
      initialValuesRef.current = { status: initialStatus, notes: initialNotes };
      setSaveState("idle");
    }
  }, [appointment]);

  // Cleanup timeouts on unmount
  useEffect(() => {
    return () => {
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
      if (savedIndicatorTimeoutRef.current) clearTimeout(savedIndicatorTimeoutRef.current);
    };
  }, []);

  // Autosave function
  const performSave = useCallback(
    async (newStatus: AppointmentStatus, newNotes: string) => {
      if (!appointment || !clinicId) return;

      try {
        setSaveState("saving");
        await updateAppointment({
          id: appointment._id as Id<"appointments">,
          clinicId,
          status: newStatus,
          notes: newNotes,
        });
        setSaveState("saved");

        // Update initial values after successful save
        initialValuesRef.current = { status: newStatus, notes: newNotes };

        // Clear "saved" indicator after 2 seconds
        if (savedIndicatorTimeoutRef.current) {
          clearTimeout(savedIndicatorTimeoutRef.current);
        }
        savedIndicatorTimeoutRef.current = setTimeout(() => {
          setSaveState("idle");
        }, 2000);
      } catch (error) {
        console.error("Autosave failed:", error);
        toast.error("Erro ao salvar alterações");
        setSaveState("idle");
      }
    },
    [appointment, clinicId, updateAppointment],
  );

  // Debounced autosave effect
  const debouncedSave = useMemo(() => {
    return (newStatus: AppointmentStatus, newNotes: string) => {
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }
      saveTimeoutRef.current = setTimeout(() => {
        performSave(newStatus, newNotes);
      }, 800);
    };
  }, [performSave]);

  // Handle status change
  const handleStatusChange = (newStatus: AppointmentStatus) => {
    setStatus(newStatus);
    // Immediate save for status changes (more important)
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }
    performSave(newStatus, notes);
  };

  // Handle notes change with debounce
  const handleNotesChange = (newNotes: string) => {
    setNotes(newNotes);
    if (initialValuesRef.current && newNotes !== initialValuesRef.current.notes) {
      debouncedSave(status, newNotes);
    }
  };

  if (!appointment) return null;

  const date = new Date(appointment.startAt);
  const formattedDate = date.toLocaleDateString("pt-BR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  const formattedTime = date.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });

  // Calculate duration
  const durationMinutes = appointment.endAt
    ? Math.round((appointment.endAt - appointment.startAt) / 60000)
    : procedure?.durationMinutes || 30;

  // Timeline status
  const isArrived = ["arrived", "completed"].includes(status);
  const isConfirmed = ["confirmed", "arrived", "completed"].includes(status);
  const isCompleted = status === "completed";
  const isCancelled = status === "cancelled";

  const timelineEvents = [
    { label: "Agendado", completed: true },
    { label: "Confirmado", completed: isConfirmed },
    { label: "Na Clínica", completed: isArrived },
    { label: "Concluído", completed: isCompleted },
  ];

  // Appointment type
  const isTelemedicine = appointment.isTelemedicine === true;
  const canRescheduleAppointment = status !== "completed";
  const hasRescheduleContext = Boolean(appointment.patientId && clinicId);

  // Status badge colors
  const getStatusBadge = () => {
    const statusConfig: Record<string, { label: string; className: string }> = {
      pending: { label: "Pendente", className: "bg-yellow-100 text-yellow-800 border-yellow-200" },
      confirmed: { label: "Confirmada", className: "bg-green-100 text-green-800 border-green-200" },
      arrived: {
        label: "Na Recepção",
        className: "bg-purple-100 text-purple-800 border-purple-200",
      },
      completed: { label: "Concluída", className: "bg-blue-100 text-blue-800 border-blue-200" },
      cancelled: { label: "Cancelada", className: "bg-red-100 text-red-800 border-red-200" },
    };
    const config = statusConfig[status] || statusConfig.pending;
    return (
      <Badge variant="outline" className={cn("font-medium", config.className)}>
        {config.label}
      </Badge>
    );
  };

  // Reschedule status badge
  const getRescheduleStatusBadge = () => {
    if (!appointment.rescheduleStatus || appointment.rescheduleStatus === "none") return null;
    const config: Record<string, { label: string; className: string }> = {
      awaiting_response: {
        label: "Aguardando Resposta",
        className: "bg-orange-100 text-orange-800",
      },
      rescheduled: { label: "Reagendado", className: "bg-teal-100 text-teal-800" },
    };
    const statusConfig = config[appointment.rescheduleStatus];
    if (!statusConfig) return null;
    return (
      <Badge variant="outline" className={statusConfig.className}>
        {statusConfig.label}
      </Badge>
    );
  };

  // Format price
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(price);
  };

  return (
    <>
      <Dialog open={!!appointment} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="sm:max-w-[650px] max-h-[90vh] overflow-y-auto">
          <DialogHeader className="space-y-3">
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <DialogTitle className="text-xl font-semibold">
                  {appointment.patientName}
                </DialogTitle>
                <DialogDescription className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4" />
                  <span className="capitalize">{formattedDate}</span>
                  <span className="text-muted-foreground">•</span>
                  <Clock className="h-4 w-4" />
                  <span>{formattedTime}</span>
                </DialogDescription>
              </div>
              {/* Autosave indicator */}
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                {saveState === "saving" && (
                  <>
                    <Loader2 className="h-3 w-3 animate-spin" />
                    <span>Salvando...</span>
                  </>
                )}
                {saveState === "saved" && (
                  <>
                    <Check className="h-3 w-3 text-green-600" />
                    <span className="text-green-600">Salvo</span>
                  </>
                )}
              </div>
            </div>

            {/* Status badges */}
            <div className="flex items-center gap-2 flex-wrap">
              {getStatusBadge()}
              {getRescheduleStatusBadge()}
              {isTelemedicine ? (
                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                  <Video className="h-3 w-3 mr-1" />
                  Teleconsulta
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-slate-50 text-slate-700 border-slate-200">
                  <Building2 className="h-3 w-3 mr-1" />
                  Presencial
                </Badge>
              )}
            </div>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Timeline */}
            {!isCancelled && (
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-muted-foreground">Progresso</h4>
                <div className="relative">
                  <div className="flex items-center justify-between px-2">
                    {timelineEvents.map((event, index) => (
                      <div key={index} className="flex flex-col items-center gap-1.5 z-10">
                        <div
                          className={cn(
                            "w-4 h-4 rounded-full border-2 transition-colors",
                            event.completed
                              ? "bg-primary border-primary"
                              : "bg-background border-muted-foreground/30",
                          )}
                        />
                        <span
                          className={cn(
                            "text-[10px] font-medium",
                            event.completed ? "text-foreground" : "text-muted-foreground",
                          )}
                        >
                          {event.label}
                        </span>
                      </div>
                    ))}
                  </div>
                  <div className="absolute top-2 left-4 right-4 h-[2px] bg-muted -z-0">
                    <div
                      className="h-full bg-primary transition-all duration-300"
                      style={{
                        width: isCompleted
                          ? "100%"
                          : isArrived
                            ? "66%"
                            : isConfirmed
                              ? "33%"
                              : "0%",
                      }}
                    />
                  </div>
                </div>
              </div>
            )}

            <Separator />

            {/* Status selector */}
            <div className="grid gap-2">
              <Label htmlFor="status" className="text-sm font-medium">
                Alterar Status
              </Label>
              <Select value={status} onValueChange={handleStatusChange}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Selecione o status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pendente</SelectItem>
                  <SelectItem value="confirmed">Confirmada</SelectItem>
                  <SelectItem value="arrived">Na Recepção</SelectItem>
                  <SelectItem value="completed">Concluída</SelectItem>
                  <SelectItem value="cancelled">Cancelada</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Separator />

            {/* Info Grid */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-muted-foreground">Detalhes</h4>
              <div className="grid grid-cols-2 gap-4">
                {/* Doctor */}
                <div className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                  <User className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div className="space-y-0.5">
                    <p className="text-xs text-muted-foreground">Médico</p>
                    <p className="text-sm font-medium">{appointment.doctor || "Não atribuído"}</p>
                  </div>
                </div>

                {/* Procedure */}
                <div className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                  <FileText className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div className="space-y-0.5">
                    <p className="text-xs text-muted-foreground">Procedimento</p>
                    <p className="text-sm font-medium">
                      {procedure?.name || appointment.procedure || "Consulta Geral"}
                    </p>
                  </div>
                </div>

                {/* Duration */}
                <div className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                  <Timer className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div className="space-y-0.5">
                    <p className="text-xs text-muted-foreground">Duração</p>
                    <p className="text-sm font-medium">{durationMinutes} minutos</p>
                  </div>
                </div>

                {/* Price (if available) */}
                {procedure?.price && (
                  <div className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                    <DollarSign className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div className="space-y-0.5">
                      <p className="text-xs text-muted-foreground">Valor</p>
                      <p className="text-sm font-medium">{formatPrice(procedure.price)}</p>
                    </div>
                  </div>
                )}

                {/* Arrival time (if checked in) */}
                {appointment.actualArrivalTime && (
                  <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg col-span-2">
                    <UserCheck className="h-4 w-4 text-green-600 mt-0.5" />
                    <div className="space-y-0.5">
                      <p className="text-xs text-green-600">Check-in realizado</p>
                      <p className="text-sm font-medium text-green-700">
                        {new Date(appointment.actualArrivalTime).toLocaleTimeString("pt-BR", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <Separator />

            {/* Notes */}
            <div className="space-y-2">
              <Label htmlFor="notes" className="text-sm font-medium">
                Notas Internas
              </Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => handleNotesChange(e.target.value)}
                placeholder="Adicione notas clínicas ou observações..."
                rows={3}
                className="resize-none"
              />
              <p className="text-xs text-muted-foreground">As notas são salvas automaticamente.</p>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-between pt-4 border-t">
            <div className="flex gap-2">
              {/* Reschedule button */}
              {canRescheduleAppointment && (
                <Button
                  variant="outline"
                  disabled={!hasRescheduleContext}
                  title={
                    hasRescheduleContext
                      ? undefined
                      : "Vincule este agendamento a um paciente para reagendar manualmente"
                  }
                  onClick={() => setRescheduleOpen(true)}
                >
                  <CalendarClock className="h-4 w-4 mr-2" />
                  Reagendar
                </Button>
              )}

              {/* Telehealth button */}
              {isTelemedicine && status !== "cancelled" && (
                <Button
                  variant="outline"
                  className="border-blue-200 text-blue-700 hover:bg-blue-50"
                  onClick={() => setTelehealthOpen(true)}
                >
                  <Video className="h-4 w-4 mr-2" />
                  Sala de Vídeo
                </Button>
              )}
            </div>

            <Button variant="outline" onClick={onClose}>
              Fechar
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Telehealth Modal */}
      <TelehealthModal
        open={telehealthOpen}
        onOpenChange={setTelehealthOpen}
        patientName={appointment.patientName}
        meetingLink={appointment.meetingLink}
      />

      {/* Reschedule Modal */}
      {appointment.patientId && clinicId && (
        <RescheduleAppointmentModal
          open={rescheduleOpen}
          onOpenChange={setRescheduleOpen}
          patientId={appointment.patientId}
          clinicId={clinicId}
          patientName={appointment.patientName}
          initialAppointment={appointment}
        />
      )}
    </>
  );
}
