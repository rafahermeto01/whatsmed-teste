import { Loader2 } from "lucide-react";
import { useState } from "react";

import { type FormData, type Question, type QuestionOption } from "./FormBuilder";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

interface FormRendererProps {
  form: FormData;
  onSubmit: (data: Record<string, any>) => void;
  isSubmitting?: boolean;
  onCancel?: () => void;
  initialData?: Record<string, any>;
}

// Helper to get option label and value regardless of format
const getOptionLabel = (opt: string | QuestionOption) => {
  return typeof opt === "string" ? opt : opt.label;
};

const getOptionValue = (opt: string | QuestionOption) => {
  return typeof opt === "string" ? opt : opt.label; // Use label as value for now to maintain compat with simple strings
};

export function FormRenderer({
  form,
  onSubmit,
  isSubmitting,
  onCancel,
  initialData = {},
}: FormRendererProps) {
  const [answers, setAnswers] = useState<Record<string, any>>(initialData);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};
    let isValid = true;

    form.questions.forEach((q) => {
      if (q.required) {
        const value = answers[q.id];
        if (value === undefined || value === "" || (Array.isArray(value) && value.length === 0)) {
          newErrors[q.id] = "Este campo é obrigatório";
          isValid = false;
        }
      }
    });

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit(answers);
    }
  };

  const handleChange = (questionId: string, value: any) => {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
    // Clear error
    if (errors[questionId]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[questionId];
        return next;
      });
    }
  };

  const renderQuestionInput = (q: Question) => {
    switch (q.type) {
      case "text":
        return (
          <Input
            id={q.id}
            value={answers[q.id] || ""}
            onChange={(e) => handleChange(q.id, e.target.value)}
            placeholder={q.label}
          />
        );
      case "textarea":
        return (
          <Textarea
            id={q.id}
            value={answers[q.id] || ""}
            onChange={(e) => handleChange(q.id, e.target.value)}
            placeholder={q.label}
            rows={4}
          />
        );
      case "number":
        return (
          <Input
            id={q.id}
            type="number"
            value={answers[q.id] || ""}
            onChange={(e) => handleChange(q.id, e.target.value)}
            placeholder={q.label}
          />
        );
      case "date":
        return (
          <Input
            id={q.id}
            type="date"
            value={answers[q.id] || ""}
            onChange={(e) => handleChange(q.id, e.target.value)}
          />
        );
      case "select":
        return (
          <Select value={answers[q.id] || ""} onValueChange={(v) => handleChange(q.id, v)}>
            <SelectTrigger id={q.id}>
              <SelectValue placeholder="Selecione..." />
            </SelectTrigger>
            <SelectContent>
              {q.options?.map((opt, idx) => {
                const val = getOptionValue(opt);
                const label = getOptionLabel(opt);
                return (
                  <SelectItem key={idx} value={val}>
                    {label}
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        );
      case "checkbox": {
        const currentValues: string[] = Array.isArray(answers[q.id]) ? answers[q.id] : [];
        return (
          <div className="space-y-2">
            {q.options?.map((opt, idx) => {
              const val = getOptionValue(opt);
              const label = getOptionLabel(opt);
              return (
                <div key={idx} className="flex items-center space-x-2">
                  <Checkbox
                    id={`${q.id}-${idx}`}
                    checked={currentValues.includes(val)}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        handleChange(q.id, [...currentValues, val]);
                      } else {
                        handleChange(
                          q.id,
                          currentValues.filter((v) => v !== val),
                        );
                      }
                    }}
                  />
                  <Label htmlFor={`${q.id}-${idx}`} className="font-normal cursor-pointer">
                    {label}
                  </Label>
                </div>
              );
            })}
          </div>
        );
      }
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h2 className="text-xl font-bold">{form.title}</h2>
        {form.description && <p className="text-muted-foreground">{form.description}</p>}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {form.questions.map((q) => (
          <div key={q.id} className="space-y-2">
            <Label htmlFor={q.id}>
              {q.label} {q.required && <span className="text-red-500">*</span>}
            </Label>
            {renderQuestionInput(q)}
            {errors[q.id] && <p className="text-sm text-red-500">{errors[q.id]}</p>}
          </div>
        ))}

        <div className="flex gap-4 pt-4">
          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Enviando...
              </>
            ) : (
              "Enviar Formulário"
            )}
          </Button>
          {onCancel && (
            <Button
              type="button"
              variant="outline"
              className="w-full"
              onClick={onCancel}
              disabled={isSubmitting}
            >
              Cancelar
            </Button>
          )}
        </div>
      </form>
    </div>
  );
}
