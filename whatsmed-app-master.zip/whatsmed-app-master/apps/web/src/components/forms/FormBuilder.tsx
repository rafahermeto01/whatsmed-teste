import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Plus, Trash2, GripVertical, X } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";

export type QuestionType = "text" | "textarea" | "number" | "select" | "checkbox" | "date";

export interface QuestionOption {
  id: string;
  label: string;
}

export interface Question {
  id: string;
  type: QuestionType;
  label: string;
  options?: string[] | QuestionOption[];
  required: boolean;
}

export interface FormData {
  title: string;
  description: string;
  type: "anamnesis" | "post_op" | "return";
  questions: Question[];
}

interface FormBuilderProps {
  initialData?: FormData;
  onSave: (data: FormData) => void;
  onCancel: () => void;
  isSaving?: boolean;
}

function SortableOptionItem({
  option,
  onRemove,
  onChange,
}: {
  option: QuestionOption;
  onRemove: () => void;
  onChange: (value: string) => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: option.id,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 1 : 0,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div ref={setNodeRef} style={style} className="flex items-center gap-2 mb-2">
      <div
        {...attributes}
        {...listeners}
        className="cursor-move text-muted-foreground hover:text-foreground touch-none"
      >
        <GripVertical className="h-4 w-4" />
      </div>
      <Input
        value={option.label}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Opção"
        className="flex-1"
      />
      <Button
        variant="ghost"
        size="icon"
        onClick={onRemove}
        className="h-8 w-8 text-muted-foreground hover:text-destructive"
      >
        <X className="h-4 w-4" />
      </Button>
    </div>
  );
}

function OptionListEditor({
  options = [],
  onChange,
}: {
  options?: string[] | QuestionOption[];
  onChange: (options: QuestionOption[]) => void;
}) {
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  );

  // Ensure we work with QuestionOption[] with stable IDs
  // We assume the parent passes stable objects. If strings are passed, we map them once but this is dangerous for re-renders.
  // Ideally, parent ensures QuestionOption[].
  const items: QuestionOption[] = options.map((o) => {
    if (typeof o === "string") {
      // This is a fallback, but IDs will be unstable if strings are duplicates or if this runs on every render without memoization in parent
      return { id: o, label: o };
    }
    return o;
  });

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = items.findIndex((item) => item.id === active.id);
      const newIndex = items.findIndex((item) => item.id === over.id);
      onChange(arrayMove(items, oldIndex, newIndex));
    }
  };

  const addOption = () => {
    const newOption = { id: Math.random().toString(36).substring(7), label: "" };
    onChange([...items, newOption]);
  };

  const removeOption = (id: string) => {
    onChange(items.filter((item) => item.id !== id));
  };

  const updateOption = (id: string, label: string) => {
    onChange(items.map((item) => (item.id === id ? { ...item, label } : item)));
  };

  return (
    <div className="space-y-2">
      <Label>Opções</Label>
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
        <SortableContext items={items} strategy={verticalListSortingStrategy}>
          <div className="space-y-2">
            {items.map((option) => (
              <SortableOptionItem
                key={option.id}
                option={option}
                onRemove={() => removeOption(option.id)}
                onChange={(val) => updateOption(option.id, val)}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>
      <Button type="button" variant="outline" size="sm" onClick={addOption} className="mt-2">
        <Plus className="w-4 h-4 mr-2" />
        Adicionar Opção
      </Button>
    </div>
  );
}

export function FormBuilder({ initialData, onSave, onCancel, isSaving }: FormBuilderProps) {
  const [formData, setFormData] = useState<FormData>(() => {
    const data = initialData || {
      title: "",
      description: "",
      type: "anamnesis",
      questions: [],
    };

    // Normalize options to ensure stable IDs for DnD
    return {
      ...data,
      questions: data.questions.map((q) => ({
        ...q,
        options: q.options?.map((o) =>
          typeof o === "string" ? { id: Math.random().toString(36).substring(7), label: o } : o,
        ),
      })),
    };
  });

  const addQuestion = () => {
    const newQuestion: Question = {
      id: Math.random().toString(36).substring(7),
      type: "text",
      label: "",
      required: false,
      options: [],
    };
    setFormData({ ...formData, questions: [...formData.questions, newQuestion] });
  };

  const updateQuestion = (index: number, updates: Partial<Question>) => {
    const newQuestions = [...formData.questions];
    newQuestions[index] = { ...newQuestions[index], ...updates };
    setFormData({ ...formData, questions: newQuestions });
  };

  const removeQuestion = (index: number) => {
    const newQuestions = formData.questions.filter((_, i) => i !== index);
    setFormData({ ...formData, questions: newQuestions });
  };

  const handleOptionsChange = (index: number, options: QuestionOption[]) => {
    updateQuestion(index, { options });
  };

  const handleSave = () => {
    // Convert QuestionOption[] back to string[] for backend compatibility
    // and filter out empty options
    const dataToSave = {
      ...formData,
      questions: formData.questions.map((q) => ({
        ...q,
        options: q.options
          ?.map((o) => (typeof o === "string" ? o : o.label))
          .filter((o) => o.trim() !== ""),
      })),
    };
    onSave(dataToSave);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="title">Título do Formulário</Label>
          <Input
            id="title"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            placeholder="Ex: Anamnese Geral"
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="type">Tipo de Formulário</Label>
          <Select
            value={formData.type}
            onValueChange={(v: any) => setFormData({ ...formData, type: v })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="anamnesis">Anamnese</SelectItem>
              <SelectItem value="post_op">Pós-Operatório</SelectItem>
              <SelectItem value="return">Retorno</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Descrição (Opcional)</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Instruções para o paciente..."
        />
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label className="text-lg font-medium">Perguntas</Label>
          <Button onClick={addQuestion} variant="outline" size="sm">
            <Plus className="w-4 h-4 mr-2" />
            Adicionar Pergunta
          </Button>
        </div>

        {formData.questions.length === 0 && (
          <div className="text-center py-8 text-muted-foreground border-2 border-dashed rounded-lg">
            Nenhuma pergunta adicionada. Clique no botão acima para começar.
          </div>
        )}

        {formData.questions.map((q, index) => (
          <Card key={q.id} className="relative group">
            <CardContent className="p-4 space-y-4">
              <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-destructive hover:text-destructive"
                  onClick={() => removeQuestion(index)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>

              <div className="grid grid-cols-[1fr,auto] gap-4 items-start pr-8">
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Pergunta</Label>
                      <Input
                        value={q.label}
                        onChange={(e) => updateQuestion(index, { label: e.target.value })}
                        placeholder="Ex: Qual sua idade?"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Tipo de Resposta</Label>
                      <Select
                        value={q.type}
                        onValueChange={(v: QuestionType) => updateQuestion(index, { type: v })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="text">Texto Curto</SelectItem>
                          <SelectItem value="textarea">Texto Longo</SelectItem>
                          <SelectItem value="number">Número</SelectItem>
                          <SelectItem value="select">Seleção Única</SelectItem>
                          <SelectItem value="checkbox">Seleção Múltipla</SelectItem>
                          <SelectItem value="date">Data</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {(q.type === "select" || q.type === "checkbox") && (
                    <OptionListEditor
                      options={q.options || []}
                      onChange={(options) => handleOptionsChange(index, options)}
                    />
                  )}
                </div>

                <div className="pt-8">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={q.required}
                      onCheckedChange={(c) => updateQuestion(index, { required: c })}
                    />
                    <Label>Obrigatória</Label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex justify-end gap-2 pt-4 border-t">
        <Button variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        <Button onClick={handleSave} disabled={isSaving || !formData.title}>
          {isSaving ? "Salvando..." : "Salvar Formulário"}
        </Button>
      </div>
    </div>
  );
}
