import { useQuery } from "convex/react";
import { Music, File, Loader2, AlertCircle, Download } from "lucide-react";

import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

interface MediaMessageProps {
  message: {
    _id: string;
    mediaType?: "audio" | "video" | "image" | "document" | "sticker";
    mediaStatus?: "pending" | "processing" | "ready" | "failed";
    mediaMimetype?: string;
    mediaFileName?: string;
    body?: string; // Caption
    direction: "in" | "out";
  };
}

export function MediaMessage({ message }: MediaMessageProps) {
  const mediaUrl = useQuery(
    api.whatsappQueries.getMediaUrl,
    message.mediaStatus === "ready" && message._id ? { messageId: message._id as any } : "skip",
  );

  // Loading state
  if (
    message.mediaStatus === "pending" ||
    message.mediaStatus === "processing" ||
    (message.mediaStatus === "ready" && !mediaUrl)
  ) {
    return (
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="h-3 w-3 animate-spin" />
          <span>Processando mídia...</span>
        </div>
        <Skeleton className="h-48 w-full rounded-lg" />
      </div>
    );
  }

  // Error state
  if (message.mediaStatus === "failed") {
    return (
      <div className="flex items-center gap-2 p-3 bg-destructive/10 rounded-lg border border-destructive/20">
        <AlertCircle className="h-4 w-4 text-destructive" />
        <span className="text-sm text-destructive">Falha ao carregar mídia</span>
      </div>
    );
  }

  // No media URL available
  if (!mediaUrl) {
    return (
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <AlertCircle className="h-3 w-3" />
        <span>Mídia não disponível</span>
      </div>
    );
  }

  // Render based on media type
  switch (message.mediaType) {
    case "image":
    case "sticker":
      return (
        <div className="flex flex-col gap-2">
          <div className="rounded-lg overflow-hidden max-w-full bg-muted/20 min-h-[100px] flex items-center justify-center">
            <img
              src={mediaUrl}
              alt={message.body || "Imagem"}
              className={cn(
                "max-h-[400px] w-auto object-contain rounded-lg",
                message.mediaType === "sticker" && "max-h-[200px]",
              )}
              onError={(e) => {
                console.error("Image load failed:", mediaUrl);
                e.currentTarget.style.display = "none";
                // Show error placeholder instead of hiding
                const parent = e.currentTarget.parentElement;
                if (parent) {
                  parent.innerHTML =
                    '<div class="flex flex-col items-center justify-center h-full text-muted-foreground"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-8 w-8 mb-2 opacity-50"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg><span class="text-xs">Erro ao carregar imagem</span></div>';
                }
              }}
            />
          </div>
          {message.mediaType === "image" && message.body && (
            <p className="text-sm leading-relaxed break-words">{message.body}</p>
          )}
        </div>
      );

    case "video":
      return (
        <div className="flex flex-col gap-2">
          <div className="rounded-lg overflow-hidden max-w-full">
            <video
              src={mediaUrl}
              controls
              playsInline
              className="w-full max-h-[400px] object-contain rounded-lg"
            >
              Seu navegador não suporta o elemento de vídeo.
            </video>
          </div>
          {message.body && <p className="text-sm leading-relaxed break-words">{message.body}</p>}
        </div>
      );

    case "audio":
      return (
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg border">
            <Music className="h-5 w-5 text-muted-foreground shrink-0" />
            <audio src={mediaUrl} controls className="flex-1 h-8">
              Seu navegador não suporta o elemento de áudio.
            </audio>
          </div>
        </div>
      );

    case "document":
      return (
        <a
          href={mediaUrl}
          download={message.mediaFileName || "documento"}
          className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg border hover:bg-muted/70 transition-colors cursor-pointer"
        >
          <File className="h-5 w-5 text-muted-foreground shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{message.mediaFileName || "Documento"}</p>
            {message.mediaMimetype && (
              <p className="text-xs text-muted-foreground">{message.mediaMimetype}</p>
            )}
          </div>
          <Download className="h-4 w-4 text-muted-foreground shrink-0" />
        </a>
      );

    default:
      // Fallback to text if media type is unknown
      return message.body ? (
        <p className="text-sm leading-relaxed break-words">{message.body}</p>
      ) : (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <AlertCircle className="h-3 w-3" />
          <span>Tipo de mídia desconhecido</span>
        </div>
      );
  }
}
