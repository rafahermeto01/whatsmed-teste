import { useQuery } from "convex/react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { User, Phone, Mail, MapPin, Calendar, FileText, Tag, Loader2, Copy } from "lucide-react";
import { toast } from "sonner";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

import type { Id } from "@whatsmed-app/backend/convex/_generated/dataModel";

interface PatientProfileModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  patientId: Id<"patients">;
  clinicId: string;
}

const birthDateFormatter = new Intl.DateTimeFormat("pt-BR", {
  timeZone: "UTC",
});

export function PatientProfileModal({
  open,
  onOpenChange,
  patientId,
  clinicId,
}: PatientProfileModalProps) {
  const patient = useQuery(api.patients.getById, open ? { id: patientId, clinicId } : "skip");

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copiado!`);
  };

  const formatBirthDate = (timestamp: number) => {
    const date = new Date(timestamp);
    if (Number.isNaN(date.getTime())) {
      return "-";
    }
    return birthDateFormatter.format(date);
  };

  const isLoading = patient === undefined;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[85vh] overflow-hidden flex flex-col p-0">
        <DialogHeader className="px-6 pt-6 pb-4">
          <DialogTitle>Perfil do Paciente</DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : !patient ? (
          <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
            <User className="h-12 w-12 mb-3" />
            <p>Paciente não encontrado</p>
          </div>
        ) : (
          <ScrollArea className="flex-1">
            <div className="px-6 pb-6 space-y-6">
              {/* Header with Avatar */}
              <div className="flex items-center gap-4">
                <Avatar className="h-20 w-20 ring-2 ring-muted">
                  {patient.avatarUrl && <AvatarImage src={patient.avatarUrl} alt={patient.name} />}
                  <AvatarFallback className="text-2xl bg-primary/10 text-primary">
                    {patient.name?.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold">{patient.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge
                      variant={patient.status === "active" ? "default" : "secondary"}
                      className={cn(
                        patient.status === "active"
                          ? "bg-green-100 text-green-700 hover:bg-green-100"
                          : "bg-gray-100 text-gray-700",
                      )}
                    >
                      {patient.status === "active" ? "Ativo" : "Inativo"}
                    </Badge>
                    {patient.externalId && (
                      <span className="text-xs text-muted-foreground">
                        ID: {patient.externalId}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <Separator />

              {/* Contact Information */}
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                  Contato
                </h4>

                {patient.phone && (
                  <div className="flex items-center justify-between group">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-muted rounded-lg">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Telefone</p>
                        <p className="font-medium">{patient.phone}</p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => copyToClipboard(patient.phone!, "Telefone")}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                )}

                {patient.email && (
                  <div className="flex items-center justify-between group">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-muted rounded-lg">
                        <Mail className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Email</p>
                        <p className="font-medium">{patient.email}</p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => copyToClipboard(patient.email!, "Email")}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                )}

                {!patient.phone && !patient.email && (
                  <p className="text-sm text-muted-foreground italic">Nenhum contato cadastrado</p>
                )}
              </div>

              <Separator />

              {/* Personal Information */}
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                  Dados Pessoais
                </h4>

                <div className="grid grid-cols-2 gap-4">
                  {patient.cpf && (
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-muted rounded-lg">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">CPF</p>
                        <p className="font-medium">{patient.cpf}</p>
                      </div>
                    </div>
                  )}

                  {patient.dateOfBirth && patient.dateOfBirth > 0 && (
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-muted rounded-lg">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Nascimento</p>
                        <p className="font-medium">{formatBirthDate(patient.dateOfBirth)}</p>
                      </div>
                    </div>
                  )}

                  {patient.gender && (
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-muted rounded-lg">
                        <User className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Gênero</p>
                        <p className="font-medium">
                          {patient.gender === "male"
                            ? "Masculino"
                            : patient.gender === "female"
                              ? "Feminino"
                              : "Outro"}
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {!patient.cpf &&
                  (!patient.dateOfBirth || patient.dateOfBirth <= 0) &&
                  !patient.gender && (
                    <p className="text-sm text-muted-foreground italic">
                      Nenhum dado pessoal cadastrado
                    </p>
                  )}
              </div>

              {/* Address */}
              {(patient.address || patient.city || patient.state) && (
                <>
                  <Separator />
                  <div className="space-y-3">
                    <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                      Endereço
                    </h4>
                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-muted rounded-lg">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <div>
                        {patient.address && <p className="font-medium">{patient.address}</p>}
                        <p className="text-muted-foreground">
                          {[patient.city, patient.state, patient.zip, patient.country]
                            .filter(Boolean)
                            .join(", ")}
                        </p>
                      </div>
                    </div>
                  </div>
                </>
              )}

              {/* Tags */}
              {patient.tags && patient.tags.length > 0 && (
                <>
                  <Separator />
                  <div className="space-y-3">
                    <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                      Tags
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {patient.tags.map((tag: any, index: any) => (
                        <Badge key={index} variant="secondary">
                          <Tag className="h-3 w-3 mr-1" />
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </>
              )}

              {/* Notes */}
              {patient.notes && (
                <>
                  <Separator />
                  <div className="space-y-3">
                    <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                      Observações
                    </h4>
                    <p className="text-sm bg-muted/50 rounded-lg p-3">{patient.notes}</p>
                  </div>
                </>
              )}

              {/* Metadata */}
              <Separator />
              <div className="text-xs text-muted-foreground space-y-1">
                <p>
                  Cadastrado em:{" "}
                  {format(new Date(patient.createdAt), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                </p>
                {patient.updatedAt && (
                  <p>
                    Última atualização:{" "}
                    {format(new Date(patient.updatedAt), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                  </p>
                )}
              </div>
            </div>
          </ScrollArea>
        )}
      </DialogContent>
    </Dialog>
  );
}
