import { usePaginatedQuery } from "convex/react";
import { ChevronDown, ChevronRight, FileText, Loader2 } from "lucide-react";
import { Fragment, useState } from "react";

import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import { useClinicId } from "@/hooks/patients";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

const ACTION_LABELS: Record<string, string> = {
  LOGIN: "Login",
  RESET_REQUEST: "Solicitar Redefinição de Senha",
  RESET_CONFIRM: "Redefinir Senha",
  USER_CREATE: "Criar Usuário",
  USER_UPDATE_ROLE: "Atualizar Função do Usuário",
  USER_DELETE: "Excluir Usuário",
  PATIENT_CREATE: "Criar Paciente",
  PATIENT_UPDATE: "Atualizar Paciente",
  PATIENT_DELETE: "Excluir Paciente",
  PATIENT_IMPORT: "Importar Pacientes",
  EXPORT_PATIENTS: "Exportar Pacientes",
  DELETE_APPOINTMENT: "Excluir Consulta",
  UPDATE_CLINIC_SETTINGS: "Atualizar Configurações",
  CREATE_PATIENT: "Criar Paciente",
};

export function AuditLogs() {
  const { clinicId } = useClinicId();
  const [expandedLog, setExpandedLog] = useState<string | null>(null);

  const {
    results: logs,
    status,
    loadMore,
  } = usePaginatedQuery(api.auditLogs.list, clinicId ? { clinicId } : "skip", {
    initialNumItems: 20,
  });

  const getActionLabel = (action: string) => {
    return ACTION_LABELS[action] || action;
  };

  const getActionColor = (action: string) => {
    if (action.includes("DELETE") || action.includes("REMOVE")) return "text-red-500";
    if (action.includes("CREATE") || action.includes("IMPORT")) return "text-green-500";
    if (action.includes("UPDATE") || action.includes("RESET")) return "text-blue-500";
    if (action === "LOGIN") return "text-amber-500";
    return "text-foreground";
  };

  if (!clinicId) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="text-center text-muted-foreground">
            <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Selecione uma clínica para visualizar os logs de auditoria</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Logs de Auditoria</CardTitle>
        <CardDescription>
          Registro detalhado de todas as ações realizadas no sistema
        </CardDescription>
      </CardHeader>

      <CardContent>
        {status === "LoadingFirstPage" ? (
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex items-center gap-4">
                <Skeleton className="h-4 w-4" />
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-28" />
              </div>
            ))}
          </div>
        ) : logs.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Nenhum log de auditoria registrado</p>
          </div>
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-8"></TableHead>
                  <TableHead>Data/Hora</TableHead>
                  <TableHead>Usuário</TableHead>
                  <TableHead>Ação</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.map((log) => (
                  <Fragment key={log._id}>
                    <TableRow
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => setExpandedLog(expandedLog === log._id ? null : log._id)}
                    >
                      <TableCell>
                        {expandedLog === log._id ? (
                          <ChevronDown size={16} className="text-muted-foreground" />
                        ) : (
                          <ChevronRight size={16} className="text-muted-foreground" />
                        )}
                      </TableCell>
                      <TableCell className="font-mono text-xs">
                        {new Date(log.createdAt).toLocaleString("pt-BR")}
                      </TableCell>
                      <TableCell>{log.userName}</TableCell>
                      <TableCell className={`font-medium ${getActionColor(log.action)}`}>
                        {getActionLabel(log.action)}
                      </TableCell>
                    </TableRow>
                    {expandedLog === log._id && (
                      <TableRow className="bg-muted/30 hover:bg-muted/30">
                        <TableCell colSpan={4}>
                          <div className="pl-8 py-2">
                            <h5 className="text-sm font-medium mb-2">Metadados</h5>
                            <div className="p-3 bg-muted rounded-md overflow-x-auto">
                              <pre className="text-xs font-mono">
                                {log.metadata
                                  ? JSON.stringify(log.metadata, null, 2)
                                  : "Nenhum metadado disponível"}
                              </pre>
                            </div>
                            {log.userAgent && (
                              <div className="mt-2 text-xs text-muted-foreground">
                                <span className="font-medium">Dispositivo:</span> {log.userAgent}
                              </div>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </Fragment>
                ))}
              </TableBody>
            </Table>

            {status === "CanLoadMore" && (
              <div className="flex justify-center pt-4">
                <Button variant="outline" size="sm" onClick={() => loadMore(20)}>
                  Carregar mais
                </Button>
              </div>
            )}

            {status === "LoadingMore" && (
              <div className="flex justify-center pt-4">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              </div>
            )}

            <div className="pt-4 text-xs text-muted-foreground border-t mt-4">
              Mostrando {logs.length} registros. Logs são mantidos por 90 dias.
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
