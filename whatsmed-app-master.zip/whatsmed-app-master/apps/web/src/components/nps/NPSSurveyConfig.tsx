import { useMutation, useQuery } from "convex/react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useRef, useState, useEffect, useCallback } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
} from "recharts";

import { VariableInserter } from "@/components/automation/VariableInserter";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

export function NPSSurveyConfig() {
  const npsSettings = useQuery(api.nps.getNpsSettings);
  const isLoading = npsSettings === undefined;
  const npsData = useQuery(api.nps.calculateNpsScore);
  const npsHistory = useQuery(api.nps.getNpsHistory, { days: 30 });
  const npsResponses = useQuery(api.nps.getNpsResponses, {});

  const updateNpsSettings = useMutation(api.nps.updateNpsSettings);
  const [isSaving, setIsSaving] = useState(false);

  // Simple debounce function
  const debounce = (fn: Function, ms: number) => {
    let timeoutId: ReturnType<typeof setTimeout>;
    return function (this: any, ...args: any[]) {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => fn.apply(this, args), ms);
    };
  };

  // Initialize local state from backend data
  const [enabled, setEnabled] = useState(npsSettings?.enabled ?? true);
  const [delay, setDelay] = useState([npsSettings?.delayMinutes ?? 2]); // hours
  const [googleReviewUrl, setGoogleReviewUrl] = useState(npsSettings?.googleMapsLink ?? "");
  const [alertOnDetractor, setAlertOnDetractor] = useState(npsSettings?.alertOnDetractor ?? true);
  const [messageTemplate, setMessageTemplate] = useState(
    npsSettings?.reviewLink ??
      "Olá {{patient.name}}, como foi sua experiência hoje na {{clinic.name}}? Por favor, avalie de 0 a 10 respondendo esta mensagem.",
  );
  const [isVariablePopoverOpen, setIsVariablePopoverOpen] = useState(false);
  const messageTemplateRef = useRef<HTMLTextAreaElement>(null);

  // Debounced save function
  const debouncedSave = useCallback(
    debounce(async (settings: any) => {
      setIsSaving(true);
      try {
        await updateNpsSettings(settings);
      } catch (error) {
        console.error("Autosave failed:", error);
      } finally {
        setIsSaving(false);
      }
    }, 1000),
    [updateNpsSettings],
  );

  // Trigger autosave when values change
  useEffect(() => {
    if (!isLoading && npsSettings) {
      // Check if values actually changed to avoid unnecessary saves on mount/sync
      const currentSettings = {
        enabled,
        delayMinutes: delay[0],
        reviewLink: messageTemplate,
        googleMapsLink: googleReviewUrl,
        alertOnDetractor,
        sendOnCompletion: true,
        thresholds: {
          promoter: 9,
          passive: 7,
          detractor: 6,
        },
      };

      const hasChanged =
        enabled !== npsSettings.enabled ||
        delay[0] !== npsSettings.delayMinutes ||
        messageTemplate !== npsSettings.reviewLink ||
        googleReviewUrl !== npsSettings.googleMapsLink ||
        alertOnDetractor !== (npsSettings.alertOnDetractor ?? true);

      if (hasChanged) {
        debouncedSave(currentSettings);
      }
    }
  }, [
    enabled,
    delay,
    messageTemplate,
    googleReviewUrl,
    alertOnDetractor,
    npsSettings,
    isLoading,
    debouncedSave,
  ]);

  // Update local state when backend data changes
  useEffect(() => {
    if (npsSettings && !isLoading) {
      setEnabled(npsSettings.enabled ?? true);
      setDelay([npsSettings.delayMinutes ?? 2]);
      setGoogleReviewUrl(npsSettings.googleMapsLink ?? "");
      setAlertOnDetractor(npsSettings.alertOnDetractor ?? true);
      setMessageTemplate(
        npsSettings.reviewLink ??
          "Olá {{patient.name}}, como foi sua experiência hoje na {{clinic.name}}? Por favor, avalie de 0 a 10 respondendo esta mensagem.",
      );
    }
  }, [npsSettings, isLoading]);

  // Get NPS score and determine quality zone
  const npsScore = npsData?.score ?? 0;
  const getNpsZone = (score: number) => {
    if (score >= 70) return { text: "Zona de Qualidade", variant: "default" as const };
    if (score >= 50) return { text: "Zona de Melhoria", variant: "secondary" as const };
    if (score >= 0) return { text: "Zona Crítica", variant: "destructive" as const };
    return { text: "Sem dados", variant: "outline" as const };
  };

  const npsZone = getNpsZone(npsScore);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Pesquisa de Satisfação (NPS)</CardTitle>
              <CardDescription>
                Configure o envio automático de pesquisas após as consultas
              </CardDescription>
            </div>
            <div className="flex items-center gap-4">
              {isSaving && (
                <span className="text-xs text-muted-foreground animate-pulse">Salvando...</span>
              )}
              <Switch checked={enabled} onCheckedChange={setEnabled} />
            </div>
          </div>
        </CardHeader>

        {enabled && (
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Atraso no Envio (Horas após consulta)</Label>
                <div className="flex items-center gap-4">
                  <Slider
                    value={delay}
                    onValueChange={setDelay}
                    max={24}
                    step={1}
                    className="flex-1"
                  />
                  <span className="w-12 text-center font-medium">{delay[0]}h</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Tempo de espera após o status "Concluído" antes de enviar a mensagem.
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label htmlFor="template">Modelo de Mensagem</Label>
                  <VariableInserter
                    open={isVariablePopoverOpen}
                    onOpenChange={setIsVariablePopoverOpen}
                    onInsert={(variable) => {
                      const textarea = messageTemplateRef.current;
                      if (textarea) {
                        const start = textarea.selectionStart;
                        const end = textarea.selectionEnd;
                        const newValue =
                          messageTemplate.substring(0, start) +
                          variable +
                          messageTemplate.substring(end);
                        setMessageTemplate(newValue);
                        // Reset cursor position after variable insertion
                        setTimeout(() => {
                          textarea.focus();
                          textarea.setSelectionRange(
                            start + variable.length,
                            start + variable.length,
                          );
                        }, 0);
                      } else {
                        setMessageTemplate(messageTemplate + variable);
                      }
                    }}
                  />
                </div>
                <Textarea
                  ref={messageTemplateRef}
                  id="template"
                  value={messageTemplate}
                  onChange={(e) => setMessageTemplate(e.target.value)}
                  onSelect={() => setIsVariablePopoverOpen(false)}
                  rows={3}
                  placeholder="Olá {{patient.name}}, como foi sua experiência hoje na {{clinic.name}}?"
                />
                <p className="text-xs text-muted-foreground">
                  Use variáveis como {"{{patient.name}}"}, {"{{clinic.name}}"}, {"{{doctor.name}}"},
                  etc.
                </p>
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <h3 className="font-medium">Gestão de Reputação</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2 p-4 border rounded-lg bg-green-50 dark:bg-green-900/10 border-green-200 dark:border-green-900">
                  <Label className="text-green-800 dark:text-green-400 font-semibold">
                    Promotores (Notas 9-10)
                  </Label>
                  <p className="text-xs text-muted-foreground mb-3">
                    Pacientes satisfeitos serão convidados a avaliar no Google.
                  </p>
                  <Input
                    placeholder="Cole seu link do Google Reviews aqui..."
                    value={googleReviewUrl}
                    onChange={(e) => setGoogleReviewUrl(e.target.value)}
                    className="bg-white dark:bg-slate-950"
                  />
                </div>

                <div className="space-y-2 p-4 border rounded-lg bg-red-50 dark:bg-red-900/10 border-red-200 dark:border-red-900">
                  <Label className="text-red-800 dark:text-red-400 font-semibold">
                    Detratores (Notas 0-6)
                  </Label>
                  <p className="text-xs text-muted-foreground mb-3">
                    Alertas serão enviados para o gerente da clínica.
                  </p>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="alert-manager"
                      checked={alertOnDetractor}
                      onCheckedChange={setAlertOnDetractor}
                    />
                    <Label htmlFor="alert-manager" className="font-normal">
                      Alertar gerência via WhatsApp
                    </Label>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-4">
              {/* Manual save removed in favor of autosave */}
            </div>
          </CardContent>
        )}
      </Card>

      {/* Preview and Analytics Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">Status Atual</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center py-6">
            {isLoading ? (
              <div className="text-5xl font-bold text-primary mb-2">...</div>
            ) : (
              <>
                <div className="text-5xl font-bold text-primary mb-2">{npsScore}</div>
                <div className="flex gap-1 mb-4">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div
                      key={i}
                      className={cn(
                        "w-4 h-4 rounded-full",
                        i <= (npsScore + 100) / 40 ? "bg-primary" : "bg-muted",
                      )}
                    />
                  ))}
                </div>
                <Badge
                  variant="outline"
                  className={cn(
                    "px-4 py-1 text-sm font-semibold",
                    npsZone.variant === "destructive"
                      ? "text-red-600 bg-red-50 border-red-200"
                      : npsZone.variant === "secondary"
                        ? "text-yellow-600 bg-yellow-50 border-yellow-200"
                        : "text-green-600 bg-green-50 border-green-200",
                  )}
                >
                  {npsZone.text}
                </Badge>
                <div className="mt-6 w-full space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Respostas Totais</span>
                    <span className="font-medium">{npsData?.totalResponses || 0}</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-1.5 overflow-hidden flex">
                    <div
                      className="bg-green-500 h-full"
                      style={{ width: `${npsData?.promoterPercentage || 0}%` }}
                    />
                    <div
                      className="bg-yellow-500 h-full"
                      style={{
                        width: `${
                          100 -
                          (npsData?.promoterPercentage || 0) -
                          (npsData?.detractorPercentage || 0)
                        }%`,
                      }}
                    />
                    <div
                      className="bg-red-500 h-full"
                      style={{ width: `${npsData?.detractorPercentage || 0}%` }}
                    />
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Evolução do Score (30 dias)</CardTitle>
          </CardHeader>
          <CardContent className="h-[240px]">
            {isLoading || !npsHistory ? (
              <div className="h-full flex items-center justify-center text-muted-foreground">
                Carregando histórico...
              </div>
            ) : npsHistory.length === 0 ? (
              <div className="h-full flex items-center justify-center text-muted-foreground border border-dashed rounded-md">
                Dados insuficientes para gerar o gráfico
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={npsHistory}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
                  <XAxis
                    dataKey="date"
                    tickFormatter={(str) => format(new Date(str), "dd/MM")}
                    fontSize={10}
                    tickMargin={10}
                  />
                  <YAxis domain={[-100, 100]} fontSize={10} />
                  <RechartsTooltip
                    labelFormatter={(label) =>
                      format(new Date(label), "dd 'de' MMMM", { locale: ptBR })
                    }
                    contentStyle={{
                      borderRadius: "8px",
                      border: "none",
                      boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="score"
                    stroke="hsl(var(--primary))"
                    strokeWidth={3}
                    dot={{ r: 4, fill: "hsl(var(--primary))", strokeWidth: 2, stroke: "#fff" }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">Distribuição</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            {!npsData ? (
              <div className="h-full flex items-center justify-center text-muted-foreground">
                ...
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={[
                    { name: "Promotores", value: npsData.promoters, color: "#22c55e" },
                    { name: "Passivos", value: npsData.passives, color: "#eab308" },
                    { name: "Detratores", value: npsData.detractors, color: "#ef4444" },
                  ]}
                  layout="vertical"
                  margin={{ left: -20 }}
                >
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" fontSize={12} width={80} />
                  <RechartsTooltip cursor={{ fill: "transparent" }} />
                  <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={30}>
                    {npsData && [
                      <Cell key="prom" fill="#22c55e" />,
                      <Cell key="pass" fill="#eab308" />,
                      <Cell key="detr" fill="#ef4444" />,
                    ]}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Histórico de Avaliações</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[300px] pr-4">
              <div className="space-y-4">
                {npsResponses?.map((resp: any) => (
                  <div
                    key={resp._id}
                    className="p-3 border rounded-lg space-y-2 hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-sm">{resp.patientName}</p>
                        <p className="text-[10px] text-muted-foreground">
                          {format(resp.respondedAt, "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })} •
                          Dr. {resp.doctorName}
                        </p>
                      </div>
                      <Badge
                        className={cn(
                          "h-7 w-7 rounded-full flex items-center justify-center p-0 text-white font-bold",
                          resp.promoterType === "promoter"
                            ? "bg-green-500"
                            : resp.promoterType === "passive"
                              ? "bg-yellow-500"
                              : "bg-red-500",
                        )}
                      >
                        {resp.score}
                      </Badge>
                    </div>
                    {resp.feedback && (
                      <p className="text-xs text-muted-foreground italic bg-muted/30 p-2 rounded">
                        "{resp.feedback}"
                      </p>
                    )}
                  </div>
                ))}
                {(!npsResponses || npsResponses.length === 0) && (
                  <div className="text-center py-12 text-muted-foreground text-sm">
                    Nenhuma avaliação recebida ainda.
                  </div>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
