import { useMutation, useQuery, useAction } from "convex/react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Clock, Copy, FileText, Send, Trash2, Upload } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

import type { Id } from "@whatsmed-app/backend/convex/_generated/dataModel";

interface DocumentUploaderProps {
  clinicId: string;
}

export function DocumentUploader({ clinicId }: DocumentUploaderProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [isPatientModalOpen, setIsPatientModalOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<{
    id: Id<"uploads">;
    name: string;
  } | null>(null);
  const [patientSearch, setPatientSearch] = useState("");

  // Query documents from backend
  const documents = useQuery(api.documents.listDocuments, {
    clinicId,
  });

  const patients = useQuery(api.patients.list, {
    clinicId,
    search: patientSearch,
    limit: 5,
  });

  // Mutations and actions
  const generateUploadUrl = useMutation(api.documents.generateUploadUrl);
  const saveDocument = useMutation(api.documents.saveDocument);
  const deleteDocument = useMutation(api.documents.deleteDocument);
  const getSecureDocumentUrl = useMutation(api.documents.getSecureDocumentUrl);
  const sendDocumentViaWhatsApp = useAction(api.documents.sendDocumentViaWhatsApp);

  const handleUpload = async () => {
    const fileInput = document.getElementById("doc-upload") as HTMLInputElement;
    if (!fileInput?.files?.[0]) return;

    const file = fileInput.files[0];

    // Validate size (10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error("Arquivo muito grande. Máximo: 10MB");
      return;
    }

    // Validate type
    const allowedTypes = ["application/pdf", "image/jpeg", "image/png"];
    if (!allowedTypes.includes(file.type)) {
      toast.error("Formato inválido. Use PDF, JPG ou PNG");
      return;
    }

    try {
      setIsUploading(true);

      // Step 1: Get a short-lived upload URL
      const postUrl = await generateUploadUrl();

      // Step 2: POST the file to the URL
      const result = await fetch(postUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });

      if (!result.ok) {
        throw new Error(`Upload failed: ${result.statusText}`);
      }

      const { storageId } = await result.json();

      // Step 3: Save the newly uploaded file to the table
      await saveDocument({
        clinicId,
        filename: file.name,
        size: file.size,
        mimeType: file.type,
        storageId,
      });

      toast.success("Documento enviado com sucesso!");
      fileInput.value = "";
    } catch (error: any) {
      console.error("Error uploading document:", error);
      toast.error(error.message || "Erro ao enviar documento");
    } finally {
      setIsUploading(false);
    }
  };

  const handleCopyLink = async (documentId: Id<"uploads">) => {
    try {
      const result = await getSecureDocumentUrl({ documentId });

      if (result.url) {
        await navigator.clipboard.writeText(result.url);
        toast.success("Link seguro copiado!");
      } else {
        toast.error(result.error || "Documento expirado ou não encontrado");
      }
    } catch (error: any) {
      console.error("Error copying link:", error);
      toast.error("Erro ao copiar link");
    }
  };

  const handleSendWhatsApp = (documentId: Id<"uploads">, documentName: string) => {
    setSelectedDocument({ id: documentId, name: documentName });
    setIsPatientModalOpen(true);
  };

  const handleConfirmSend = async (patientId: Id<"patients">) => {
    if (!selectedDocument) return;
    try {
      await sendDocumentViaWhatsApp({
        documentId: selectedDocument.id,
        patientId,
      });
      toast.success("Enviado via WhatsApp!");
      setIsPatientModalOpen(false);
    } catch (error: any) {
      console.error("Error sending document via WhatsApp:", error);
      toast.error(error.message || "Erro ao enviar documento");
    }
  };

  const handleDelete = async (documentId: Id<"uploads">) => {
    try {
      await deleteDocument({ documentId });
      toast.success("Documento removido.");
      // Automatically removed from list by reactivity
    } catch (error: any) {
      console.error("Error deleting document:", error);
      toast.error("Erro ao remover documento");
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(2) + " MB";
  };

  const formatExpiresAt = (expiresAt: number): string => {
    const now = Date.now();
    const remaining = expiresAt - now;
    const hours = Math.floor(remaining / (1000 * 60 * 60));
    const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));

    if (remaining <= 0) {
      return "Expirado";
    }

    return `${hours}h ${minutes}m`;
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Entrega Segura de Documentos</CardTitle>
          <CardDescription>
            Envie exames e receitas com links temporários (expiram em 48h).
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Upload Area */}
          <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 flex flex-col items-center justify-center text-center hover:bg-muted/50 transition-colors">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Upload className={`w-6 h-6 text-primary ${isUploading ? "animate-pulse" : ""}`} />
            </div>
            <h3 className="font-medium text-lg mb-1">
              {isUploading ? "Enviando..." : "Arraste arquivos aqui ou clique para selecionar"}
            </h3>
            <p className="text-sm text-muted-foreground mb-4">PDF, JPG ou PNG (Máx. 10MB)</p>
            <div className="flex gap-2">
              <Input
                id="doc-upload"
                type="file"
                className="hidden"
                accept=".pdf,.jpg,.jpeg,.png"
                disabled={isUploading}
                onChange={handleUpload}
              />
              <Button
                variant="outline"
                disabled={isUploading}
                onClick={() => document.getElementById("doc-upload")?.click()}
              >
                Selecionar Arquivo
              </Button>
            </div>
          </div>

          {/* Documents List */}
          <div>
            <h4 className="font-medium mb-4">Envios Recentes</h4>
            {!documents || documents.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>Nenhum documento enviado ainda</p>
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Enviado em</TableHead>
                      <TableHead>Expira em</TableHead>
                      <TableHead className="text-center">Downloads</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {documents.map((doc: any) => (
                      <TableRow key={doc._id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4 text-muted-foreground" />
                            {doc.filename}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {formatFileSize(doc.size)} • {doc.mimeType}
                          </div>
                        </TableCell>
                        <TableCell>
                          {format(doc.createdAt, "dd/MM/yyyy HH:mm", {
                            locale: ptBR,
                          })}
                        </TableCell>
                        <TableCell>
                          <div
                            className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full w-fit ${
                              doc.expiresAt < Date.now()
                                ? "bg-red-50 text-red-600"
                                : "bg-orange-50 text-orange-600"
                            }`}
                          >
                            <Clock className="w-3 h-3" />
                            {formatExpiresAt(doc.expiresAt)}
                          </div>
                        </TableCell>
                        <TableCell className="text-center">{doc.downloads}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              size="icon"
                              variant="ghost"
                              title="Copiar Link"
                              onClick={() => handleCopyLink(doc._id)}
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              title="Enviar no WhatsApp"
                              onClick={() => handleSendWhatsApp(doc._id, doc.filename)}
                            >
                              <Send className="w-4 h-4" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="text-destructive hover:text-destructive"
                              onClick={() => handleDelete(doc._id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={isPatientModalOpen} onOpenChange={setIsPatientModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Enviar "{selectedDocument?.name}"</DialogTitle>
            <DialogDescription>
              Selecione o paciente para enviar o documento via WhatsApp.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Buscar Paciente</Label>
              <Input
                placeholder="Nome ou telefone..."
                value={patientSearch}
                onChange={(e) => setPatientSearch(e.target.value)}
              />
            </div>
            <div className="border rounded-md divide-y max-h-[200px] overflow-y-auto">
              {!patients ? (
                <div className="p-4 text-center text-sm text-muted-foreground">Carregando...</div>
              ) : patients.items.length === 0 ? (
                <div className="p-4 text-center text-sm text-muted-foreground">
                  Nenhum paciente encontrado
                </div>
              ) : (
                patients.items.map((patient: any) => (
                  <div
                    key={patient._id}
                    className="p-3 hover:bg-muted cursor-pointer flex justify-between items-center"
                    onClick={() => handleConfirmSend(patient._id)}
                  >
                    <div>
                      <p className="font-medium text-sm">{patient.name}</p>
                      <p className="text-xs text-muted-foreground">{patient.phone}</p>
                    </div>
                    <Send className="w-4 h-4 text-muted-foreground" />
                  </div>
                ))
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
