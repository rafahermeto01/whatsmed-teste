import { X } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { authClient } from "@/lib/auth-client";

interface ForgotPasswordModalProps {
  onClose: () => void;
}

export function ForgotPasswordModal({ onClose }: ForgotPasswordModalProps) {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await authClient.forgetPassword({
        email,
        redirectTo: `${window.location.origin}/reset-password`,
      });
      setSubmitted(true);
      setTimeout(() => {
        onClose();
      }, 2000);
    } catch (err) {
      console.error(err);
      toast.error("Erro ao enviar e-mail de recuperação");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div
        className="relative w-full max-w-md bg-popover border border-border p-6 mx-4"
        style={{
          borderRadius: "var(--radius)",
          boxShadow: "var(--shadow-lg)",
        }}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors"
        >
          <X size={20} />
        </button>

        {/* Header */}
        <div className="mb-6">
          <h3 className="text-popover-foreground text-lg font-medium">Redefinir Senha</h3>
        </div>

        {submitted ? (
          <div className="space-y-4">
            <p className="text-foreground">
              Instruções enviadas! Verifique seu e-mail para o link de redefinição de senha.
            </p>
          </div>
        ) : (
          <>
            {/* Body Text */}
            <div className="mb-6">
              <p className="text-foreground text-sm">
                Digite o e-mail associado à sua conta e enviaremos um e-mail com instruções para
                redefinir sua senha.
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label htmlFor="reset-email" className="block text-foreground font-medium text-sm">
                  Endereço de E-mail
                </label>
                <input
                  id="reset-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="nome@clinica.com"
                  className="w-full h-10 px-3 bg-input-background border border-input focus:border-ring focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 transition-all"
                  style={{ borderRadius: "var(--radius)" }}
                  required
                />
              </div>

              {/* Actions */}
              <div className="flex gap-3 justify-end">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 h-10 text-muted-foreground hover:text-foreground transition-colors text-sm font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-6 h-10 bg-primary text-primary-foreground hover:opacity-90 transition-opacity text-sm font-medium disabled:opacity-50"
                  style={{ borderRadius: "var(--radius)" }}
                >
                  {loading ? "Enviando..." : "Enviar Instruções"}
                </button>
              </div>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
