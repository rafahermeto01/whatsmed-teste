import { useQuery } from "convex/react";
import { format, addMinutes, parse, setHours, setMinutes, isBefore } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Clock, ChevronsUpDown, User, Search, Loader2, Info } from "lucide-react";
import { useState, useEffect, type UIEvent } from "react";
import { toast } from "sonner";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useCreateAppointment } from "@/hooks/appointments";
import { usePatientsList, useClinicId } from "@/hooks/patients";
import { useDoctorsList } from "@/hooks/users";
import { cn } from "@/lib/utils";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

import type { Id } from "@whatsmed-app/backend/convex/_generated/dataModel";

const PATIENTS_PAGE_SIZE = 25;
const TELEMEDICINE_GOOGLE_CALENDAR_REQUIRED_MESSAGE =
  "Conecte o Google Calendar do médico em Integrações para usar teleconsulta.";

interface CreateAppointmentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CreateAppointmentModal({ open, onOpenChange }: CreateAppointmentModalProps) {
  const { clinicId } = useClinicId();
  const createAppointment = useCreateAppointment();
  const doctors = useDoctorsList(clinicId);
  const forms = useQuery(api.forms.list, { clinicId: clinicId || "" });

  // Form State
  const [selectedPatient, setSelectedPatient] = useState<{
    id: string;
    name: string;
    email?: string;
  } | null>(null);
  const [selectedDoctor, setSelectedDoctor] = useState<string>("");
  const [selectedProcedure, setSelectedProcedure] = useState<string>("");
  const [selectedProcedureType, setSelectedProcedureType] = useState<
    "telemedicine" | "in_person" | null
  >(null);
  const [selectedForms, setSelectedForms] = useState<string[]>([]);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [patientEmail, setPatientEmail] = useState("");

  // Fetch procedures for selected doctor
  const procedures = useQuery(
    api.procedures.listByDoctor,
    selectedDoctor && clinicId ? { doctorId: selectedDoctor as Id<"users">, clinicId } : "skip",
  );
  const doctorGoogleCalendarStatus = useQuery(
    api.googleCalendar.getDoctorConnectionStatus,
    selectedDoctor && clinicId ? { doctorId: selectedDoctor as Id<"users"> } : "skip",
  );

  // Patient Search State
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [patientCursor, setPatientCursor] = useState<string | undefined>(undefined);
  const [loadedPatients, setLoadedPatients] = useState<any[]>([]);
  const [patientsCanLoadMore, setPatientsCanLoadMore] = useState(false);
  const [loadingMorePatients, setLoadingMorePatients] = useState(false);

  // Fetch available days (mode 1: no date/time params)
  const availableDays = useQuery(
    api.appointments.getAvailableSlots,
    selectedDoctor && selectedProcedure && clinicId
      ? {
          clinicId: clinicId,
          doctorId: selectedDoctor as Id<"users">,
          procedureId: selectedProcedure as Id<"procedures">,
        }
      : "skip",
  );

  // Fetch available slots for selected day (mode 2: date param)
  const availableSlots = useQuery(
    api.appointments.getAvailableSlots,
    selectedDoctor && selectedProcedure && selectedDate && clinicId
      ? {
          clinicId: clinicId,
          doctorId: selectedDoctor as Id<"users">,
          procedureId: selectedProcedure as Id<"procedures">,
          date: selectedDate,
        }
      : "skip",
  );

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchTerm);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  const normalizedSearch = debouncedSearch.trim();
  const patientsResult = usePatientsList({
    clinicId: open ? clinicId : undefined,
    search: normalizedSearch || undefined,
    limit: PATIENTS_PAGE_SIZE,
    status: "active",
    cursor: patientCursor,
  });
  const nextPatientsCursor = patientsResult?.cursor ?? null;
  const isInitialPatientsLoading = patientsResult === undefined && loadedPatients.length === 0;

  // Reset form when closed
  useEffect(() => {
    if (!open) {
      // Reset form state when modal closes
      setSelectedPatient(null);
      setSelectedDoctor("");
      setSelectedProcedure("");
      setSelectedProcedureType(null);
      setSelectedForms([]);
      setNotes("");
      setPatientEmail("");
      setSelectedDate(null);
      setSelectedTime(null);
      setSearchOpen(false);
      setSearchTerm("");
      setDebouncedSearch("");
      setPatientCursor(undefined);
      setLoadedPatients([]);
      setPatientsCanLoadMore(false);
      setLoadingMorePatients(false);
    }
  }, [open]);

  useEffect(() => {
    setPatientCursor(undefined);
    setLoadedPatients([]);
    setPatientsCanLoadMore(false);
    setLoadingMorePatients(false);
  }, [clinicId, normalizedSearch]);

  useEffect(() => {
    if (!patientsResult) {
      return;
    }

    setLoadedPatients((prev) => {
      const merged = new Map<string, any>();
      const source = patientCursor ? [...prev, ...patientsResult.items] : patientsResult.items;

      for (const patient of source) {
        merged.set(patient._id, patient);
      }

      return Array.from(merged.values());
    });

    setPatientsCanLoadMore(!patientsResult.isDone && Boolean(patientsResult.cursor));
    setLoadingMorePatients(false);
  }, [patientCursor, patientsResult]);

  const handlePatientsScroll = (event: UIEvent<HTMLDivElement>) => {
    if (loadingMorePatients || !patientsCanLoadMore || !nextPatientsCursor) {
      return;
    }

    const target = event.currentTarget;
    const distanceToBottom = target.scrollHeight - target.scrollTop - target.clientHeight;

    if (distanceToBottom <= 24) {
      setLoadingMorePatients(true);
      setPatientCursor(nextPatientsCursor);
    }
  };

  // Reset dependent fields when doctor changes
  useEffect(() => {
    setSelectedProcedure("");
    setSelectedProcedureType(null);
    setSelectedDate(null);
    setSelectedTime(null);
  }, [selectedDoctor]);

  // Derive procedure type and reset when procedure changes
  useEffect(() => {
    if (selectedProcedure && procedures) {
      const procedure = procedures.find((p: any) => p._id === selectedProcedure);
      if (procedure) {
        // Derive type from procedure flags
        if (procedure.isTelemedicine && !procedure.isInPerson) {
          setSelectedProcedureType("telemedicine");
        } else if (!procedure.isTelemedicine && procedure.isInPerson) {
          setSelectedProcedureType("in_person");
        } else if (procedure.isTelemedicine && procedure.isInPerson) {
          // Both supported - keep current type or default to in_person
          if (!selectedProcedureType) {
            setSelectedProcedureType("in_person");
          }
        }
      }
    } else {
      setSelectedProcedureType(null);
    }
    setSelectedDate(null);
    setSelectedTime(null);
  }, [selectedProcedure, procedures]);

  // Reset time when date changes
  useEffect(() => {
    setSelectedTime(null);
  }, [selectedDate]);

  const isTelemedicineSelected = selectedProcedureType === "telemedicine";
  const isDoctorGoogleCalendarLoading =
    !!selectedDoctor && isTelemedicineSelected && doctorGoogleCalendarStatus === undefined;
  const isDoctorGoogleCalendarConnected = doctorGoogleCalendarStatus?.connected ?? false;
  const isTelemedicineBlocked =
    !!selectedDoctor &&
    isTelemedicineSelected &&
    doctorGoogleCalendarStatus !== undefined &&
    !isDoctorGoogleCalendarConnected;

  const handleSubmit = async () => {
    if (!selectedPatient) {
      toast.error("Selecione um paciente");
      return;
    }
    if (!selectedDoctor || selectedDoctor === "none") {
      toast.error("Selecione um médico");
      return;
    }
    if (!selectedProcedure) {
      toast.error("Selecione um procedimento");
      return;
    }
    if (!selectedProcedureType) {
      toast.error("Selecione o tipo de atendimento");
      return;
    }
    if (!selectedDate) {
      toast.error("Selecione uma data");
      return;
    }
    if (!selectedTime) {
      toast.error("Selecione um horário");
      return;
    }

    // Validate telemedicine requirements
    if (selectedProcedureType === "telemedicine") {
      if (isDoctorGoogleCalendarLoading) {
        toast.error("Verificando conexão do Google Calendar do médico...");
        return;
      }
      if (isTelemedicineBlocked) {
        toast.error(TELEMEDICINE_GOOGLE_CALENDAR_REQUIRED_MESSAGE);
        return;
      }

      const finalPatientEmail = selectedPatient.email || patientEmail;
      if (!finalPatientEmail) {
        toast.error("Email do paciente é obrigatório para teleconsulta");
        return;
      }
    }

    // Parse selected time (format: HH:mm)
    const [hours, minutes] = selectedTime.split(":").map(Number);
    // Parse selected date (format: YYYY-MM-DD)
    const dateObj = parse(selectedDate, "yyyy-MM-dd", new Date());
    const startAt = setMinutes(setHours(dateObj, hours), minutes);

    if (isBefore(startAt, new Date())) {
      toast.error("A data do agendamento deve ser futura");
      return;
    }

    // Get procedure duration
    const selectedProcedureData = procedures?.find((p: any) => p._id === selectedProcedure);
    const durationMinutes = selectedProcedureData?.durationMinutes || 30;
    const endAt = addMinutes(startAt, durationMinutes);

    setLoading(true);
    try {
      const selectedDoctorData = doctors.find((d: any) => d._id === selectedDoctor);
      const appointmentData: any = {
        clinicId: clinicId!,
        patientId: selectedPatient.id as Id<"patients">,
        startAt: startAt.getTime(),
        endAt: endAt.getTime(),
        status: "pending",
        procedure: selectedProcedureData?.name || "consulta",
        procedureId: selectedProcedure as Id<"procedures">,
        notes: notes,
        doctor: selectedDoctorData?.name || "Dr. Demo",
        doctorId: selectedDoctor as Id<"users">,
        isTelemedicine: selectedProcedureType === "telemedicine",
      };

      // Add telemedicine fields if needed
      if (selectedProcedureType === "telemedicine") {
        const finalPatientEmail = selectedPatient.email || patientEmail;
        if (finalPatientEmail) {
          appointmentData.patientEmail = finalPatientEmail;
        }
        appointmentData.timeZone = "America/Sao_Paulo";
      }

      await createAppointment(appointmentData);

      toast.success("Agendamento criado com sucesso!");
      onOpenChange(false);
      // Reset critical fields
      setSelectedPatient(null);
      setSelectedDoctor("");
      setSelectedProcedure("");
      setSelectedProcedureType(null);
      setSelectedDate(null);
      setSelectedTime(null);
      setNotes("");
      setPatientEmail("");
    } catch (error: any) {
      console.error(error);
      toast.error(error?.message || "Erro ao criar agendamento");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Criar Novo Agendamento</DialogTitle>
          <DialogDescription>
            Preencha os dados abaixo para agendar uma nova consulta.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-6 py-4">
          {/* Patient Selection */}
          <div className="grid gap-2">
            <Label>Paciente</Label>
            <Popover open={searchOpen} onOpenChange={setSearchOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={searchOpen}
                  className="w-full justify-between"
                >
                  {selectedPatient ? (
                    <div className="flex items-center gap-2">
                      <User size={16} />
                      {selectedPatient.name}
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Search size={16} />
                      Buscar paciente...
                    </div>
                  )}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent
                className="w-[var(--radix-popover-trigger-width)] min-w-[300px] p-0"
                align="start"
              >
                <div className="p-2 border-b">
                  <Input
                    placeholder="Digite nome, CPF ou telefone..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="border-none focus-visible:ring-0"
                    autoFocus
                  />
                </div>
                <div className="max-h-[200px] overflow-y-auto p-1" onScroll={handlePatientsScroll}>
                  {isInitialPatientsLoading ? (
                    <div className="py-4 flex items-center justify-center text-sm text-muted-foreground">
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      Carregando pacientes...
                    </div>
                  ) : loadedPatients.length === 0 ? (
                    <div className="py-6 text-center text-sm text-muted-foreground">
                      Nenhum paciente encontrado.
                    </div>
                  ) : (
                    loadedPatients.map((patient: any) => (
                      <div
                        key={patient._id}
                        className={cn(
                          "flex flex-col px-3 py-2 text-sm rounded-sm cursor-pointer hover:bg-accent hover:text-accent-foreground",
                          selectedPatient?.id === patient._id && "bg-accent text-accent-foreground",
                        )}
                        onClick={() => {
                          setSelectedPatient({
                            id: patient._id,
                            name: patient.name,
                            email: patient.email,
                          });
                          // Auto-fill patient email if available
                          if (patient.email) {
                            setPatientEmail(patient.email);
                          } else {
                            setPatientEmail("");
                          }
                          setSearchOpen(false);
                        }}
                      >
                        <span className="font-medium">{patient.name}</span>
                        <span className="text-xs text-muted-foreground">
                          CPF: {patient.cpf || "N/A"} • Tel: {patient.phone || "N/A"}
                        </span>
                      </div>
                    ))
                  )}
                  {loadingMorePatients && (
                    <div className="py-2 flex items-center justify-center text-xs text-muted-foreground">
                      <Loader2 className="h-3.5 w-3.5 animate-spin mr-2" />
                      Carregando mais pacientes...
                    </div>
                  )}
                  {!isInitialPatientsLoading &&
                    !loadingMorePatients &&
                    loadedPatients.length > 0 &&
                    !patientsCanLoadMore && (
                      <div className="py-2 text-center text-xs text-muted-foreground">
                        Fim dos resultados.
                      </div>
                    )}
                </div>
              </PopoverContent>
            </Popover>
          </div>

          {/* Doctor Selection - Moved to top */}
          <div className="grid gap-2">
            <Label>
              Médico <span className="text-red-500">*</span>
            </Label>
            <Select value={selectedDoctor} onValueChange={setSelectedDoctor}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione um médico" />
              </SelectTrigger>
              <SelectContent>
                {doctors.length === 0 ? (
                  <SelectItem value="none" disabled>
                    Nenhum médico disponível
                  </SelectItem>
                ) : (
                  doctors.map((doc: any) => (
                    <SelectItem key={doc._id} value={doc._id}>
                      {doc.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Selecione o médico para visualizar a disponibilidade
            </p>
          </div>

          {/* Procedure Selection - Required */}
          {selectedDoctor && procedures && procedures.length > 0 && (
            <div className="grid gap-2">
              <Label>
                Procedimento <span className="text-red-500">*</span>
              </Label>
              <Select
                value={selectedProcedure || ""}
                onValueChange={(value) => {
                  setSelectedProcedure(value);
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um procedimento" />
                </SelectTrigger>
                <SelectContent>
                  {procedures.map((procedure: any) => (
                    <SelectItem key={procedure._id} value={procedure._id}>
                      {procedure.name} ({procedure.durationMinutes} min)
                      {procedure.isTelemedicine && procedure.isInPerson
                        ? " • Ambos"
                        : procedure.isTelemedicine
                          ? " • Teleconsulta"
                          : " • Presencial"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedProcedure && procedures.find((p: any) => p._id === selectedProcedure) && (
                <p className="text-xs text-muted-foreground">
                  Duração:{" "}
                  {procedures.find((p: any) => p._id === selectedProcedure)?.durationMinutes}{" "}
                  minutos
                </p>
              )}
            </div>
          )}

          {selectedDoctor && (!procedures || procedures.length === 0) && (
            <div className="rounded-md bg-yellow-50 dark:bg-yellow-950 p-3 text-sm text-yellow-800 dark:text-yellow-200">
              <Info className="inline h-4 w-4 mr-2" />
              Este médico não possui procedimentos cadastrados. Configure os procedimentos nas
              configurações.
            </div>
          )}

          {/* Procedure Type Toggle - Only show if procedure supports both types */}
          {selectedProcedure &&
            procedures?.find((p: any) => p._id === selectedProcedure)?.isTelemedicine &&
            procedures?.find((p: any) => p._id === selectedProcedure)?.isInPerson && (
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="type-in-person"
                    checked={selectedProcedureType === "in_person"}
                    onCheckedChange={(checked) => {
                      if (checked) setSelectedProcedureType("in_person");
                    }}
                  />
                  <Label htmlFor="type-in-person" className="cursor-pointer font-normal">
                    Presencial
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="type-telemedicine"
                    checked={selectedProcedureType === "telemedicine"}
                    disabled={
                      !!selectedDoctor &&
                      doctorGoogleCalendarStatus !== undefined &&
                      !isDoctorGoogleCalendarConnected
                    }
                    onCheckedChange={(checked) => {
                      if (checked) setSelectedProcedureType("telemedicine");
                    }}
                  />
                  <Label htmlFor="type-telemedicine" className="cursor-pointer font-normal">
                    Teleconsulta
                  </Label>
                </div>
              </div>
            )}

          {isTelemedicineSelected && (
            <Alert
              className={cn(
                "border",
                isTelemedicineBlocked
                  ? "border-amber-300 bg-amber-50 text-amber-950"
                  : "border-sky-200 bg-sky-50 text-sky-950",
              )}
            >
              <Info className="h-4 w-4" />
              <AlertTitle>
                {isDoctorGoogleCalendarLoading
                  ? "Verificando Google Calendar"
                  : isTelemedicineBlocked
                    ? "Google Calendar necessario"
                    : "Google Calendar pronto"}
              </AlertTitle>
              <AlertDescription className="flex flex-col gap-2">
                <span>
                  {isDoctorGoogleCalendarLoading
                    ? "Estamos validando a conexão do médico para liberar a teleconsulta."
                    : isTelemedicineBlocked
                      ? TELEMEDICINE_GOOGLE_CALENDAR_REQUIRED_MESSAGE
                      : "A teleconsulta usará um link do Google Meet para este médico."}
                </span>
                {isTelemedicineBlocked && (
                  <a
                    href="/integrations"
                    className="text-sm font-medium underline underline-offset-4"
                  >
                    Abrir Integrações
                  </a>
                )}
              </AlertDescription>
            </Alert>
          )}

          <div className="grid md:grid-cols-2 gap-4">
            {/* Forms */}
            <div className="grid gap-2">
              <Label>Formulários Obrigatórios</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    className={cn(
                      "w-full justify-between font-normal bg-background hover:bg-accent hover:text-accent-foreground",
                      selectedForms.length === 0 && "text-muted-foreground",
                    )}
                  >
                    {selectedForms.length > 0
                      ? `${selectedForms.length} formulário(s) selecionado(s)`
                      : "Selecione formulários (opcional)"}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent
                  className="w-[var(--radix-popover-trigger-width)] min-w-[300px] p-0"
                  align="start"
                >
                  <div className="p-2 max-h-[200px] overflow-y-auto space-y-2">
                    {forms?.map((form: any) => (
                      <div key={form._id} className="flex items-center space-x-2">
                        <Checkbox
                          id={form._id}
                          checked={selectedForms.includes(form._id)}
                          onCheckedChange={(checked) => {
                            if (checked) setSelectedForms([...selectedForms, form._id]);
                            else setSelectedForms(selectedForms.filter((id) => id !== form._id));
                          }}
                        />
                        <Label htmlFor={form._id} className="text-sm font-normal cursor-pointer">
                          {form.title}
                        </Label>
                      </div>
                    ))}
                    {(!forms || forms.length === 0) && (
                      <p className="text-sm text-muted-foreground p-2">
                        Nenhum formulário disponível.
                      </p>
                    )}
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Available Days Selection */}
          {selectedProcedure && selectedProcedureType && (
            <div className="grid gap-2">
              <Label>
                Data Disponível <span className="text-red-500">*</span>
              </Label>
              {availableDays === undefined ? (
                <div className="flex items-center justify-center p-4 text-sm text-muted-foreground border rounded-md">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Buscando dias disponíveis...
                </div>
              ) : availableDays && "dates" in availableDays && availableDays.dates.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-[200px] overflow-y-auto border rounded-md p-2">
                  {availableDays.dates.map((dateStr: string) => {
                    const dateObj = parse(dateStr, "yyyy-MM-dd", new Date());
                    const isSelected = selectedDate === dateStr;
                    return (
                      <Button
                        key={dateStr}
                        type="button"
                        variant={isSelected ? "default" : "outline"}
                        className="h-auto py-2 px-3 flex flex-col items-start"
                        onClick={() => setSelectedDate(dateStr)}
                      >
                        <span className="text-xs opacity-70">
                          {format(dateObj, "EEE", { locale: ptBR })}
                        </span>
                        <span className="font-medium">
                          {format(dateObj, "dd/MM", { locale: ptBR })}
                        </span>
                      </Button>
                    );
                  })}
                </div>
              ) : (
                <div className="rounded-md bg-muted p-3 text-sm text-muted-foreground">
                  Nenhum dia disponível nos próximos 7 dias
                </div>
              )}
            </div>
          )}

          {/* Available Slots Selection */}
          {selectedDate && selectedProcedure && (
            <div className="grid gap-2">
              <Label>
                Horário Disponível <span className="text-red-500">*</span>
              </Label>
              {availableSlots === undefined ? (
                <div className="flex items-center justify-center p-4 text-sm text-muted-foreground border rounded-md">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Buscando horários...
                </div>
              ) : availableSlots && Array.isArray(availableSlots) && availableSlots.length > 0 ? (
                <div className="grid grid-cols-3 md:grid-cols-4 gap-2 max-h-[200px] overflow-y-auto border rounded-md p-2">
                  {availableSlots.map((slot: { start: string; end: string }) => {
                    const slotDate = new Date(slot.start);
                    const timeStr = format(slotDate, "HH:mm", { locale: ptBR });
                    const isSelected = selectedTime === timeStr;
                    return (
                      <Button
                        key={slot.start}
                        type="button"
                        variant={isSelected ? "default" : "outline"}
                        className="h-auto py-2"
                        onClick={() => setSelectedTime(timeStr)}
                      >
                        {timeStr}
                      </Button>
                    );
                  })}
                </div>
              ) : (
                <div className="rounded-md bg-muted p-3 text-sm text-muted-foreground">
                  Nenhum horário disponível para este dia
                </div>
              )}
            </div>
          )}

          {/* Telemedicine Fields - Only show patient email if patient has no email */}
          {selectedProcedureType === "telemedicine" &&
            selectedPatient &&
            !selectedPatient.email && (
              <div className="grid gap-2">
                <Label>
                  Email do Paciente <span className="text-red-500">*</span>
                </Label>
                <Input
                  type="email"
                  placeholder="email@exemplo.com"
                  value={patientEmail}
                  onChange={(e) => setPatientEmail(e.target.value)}
                  required
                />
                <p className="text-xs text-muted-foreground">
                  Email necessário para enviar o convite da consulta por vídeo
                </p>
              </div>
            )}

          {/* Notes */}

          <div className="grid gap-2">
            <Label>Observações</Label>
            <Textarea
              placeholder="Adicione notas ou observações importantes..."
              value={notes}
              onChange={(e) => setNotes(e.target.value.slice(0, 500))}
              className="resize-none"
              rows={3}
            />
            <div className="text-xs text-right text-muted-foreground">
              {notes.length}/500 caracteres
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={loading || isDoctorGoogleCalendarLoading || isTelemedicineBlocked}
          >
            {loading && <Clock className="mr-2 h-4 w-4 animate-spin" />}
            Confirmar Agendamento
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
