import { Star, Check, AlertCircle, Lock } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useSetDefaultFlow, useDefaultFlow } from "@/hooks/clinicSettings";
import { useClinicId } from "@/hooks/patients";

import type { Id } from "@whatsmed-app/backend/convex/_generated/dataModel";

/**
 * Flow item interface for the selector
 */
interface FlowItem {
  id: string;
  name: string;
  version?: number;
  status?: "draft" | "active" | "archived";
}

/**
 * Props for the DefaultFlowSelector component
 */
interface DefaultFlowSelectorProps {
  /** Array of available flows to select from (should be filtered to active flows) */
  flows: FlowItem[];
  /** Callback when default flow changes */
  onChange?: (flowId: string | null) => void;
  /** Whether the selector is disabled (for non-admin users) */
  disabled?: boolean;
}

/**
 * DefaultFlowSelector Component
 *
 * A dropdown selector for choosing the clinic's default flow. Displays a star icon
 * and badge for the selected flow. Includes proper accessibility, loading states,
 * and role-based access control.
 *
 * @example
 * ```tsx
 * <DefaultFlowSelector
 *   flows={activeFlows}
 *   onChange={(flowId) => console.log("Default flow changed to:", flowId)}
 * />
 * ```
 */
export function DefaultFlowSelector({
  flows,
  onChange,
  disabled: disabledProp = false,
}: DefaultFlowSelectorProps) {
  const { clinicId, role } = useClinicId();
  const setDefaultFlowMutation = useSetDefaultFlow();
  const { defaultFlowId, isLoading } = useDefaultFlow(clinicId);
  const [isUpdating, setIsUpdating] = useState(false);

  const isAdmin = role === "admin" || role === "super_admin";
  const isDisabled = disabledProp || !isAdmin || isLoading || isUpdating;

  const selectedFlow = flows.find((f) => f.id === defaultFlowId);
  const selectedFlowName = selectedFlow?.name ?? null;

  /**
   * Handle flow selection change
   */
  const handleValueChange = async (value: string) => {
    if (!clinicId) {
      toast.error("Erro: Clínica não identificada");
      return;
    }

    // "none" is the special value for no default flow
    const flowId = value === "none" ? null : value;

    // Validate that the flow is active
    if (flowId) {
      const flow = flows.find((f) => f.id === flowId);
      if (!flow) {
        toast.error("Erro: Fluxo não encontrado");
        return;
      }
      if (flow.status !== "active") {
        toast.error("Apenas fluxos ativos podem ser definidos como padrão");
        return;
      }
    }

    setIsUpdating(true);

    try {
      if (flowId) {
        await setDefaultFlowMutation({
          clinicId,
          flowId: flowId as Id<"flows">,
        });

        const flowName = flows.find((f) => f.id === flowId)?.name ?? "Desconhecido";
        toast.success(`Fluxo padrão atualizado para: ${flowName}`);
      } else {
        toast.info("Desativar fluxo padrão ainda não implementado");
      }

      onChange?.(flowId);
    } catch (error) {
      console.error("Failed to set default flow:", error);

      // Handle specific error types
      if (error instanceof Error) {
        if (error.message.includes("forbidden") || error.message.includes("Admin role required")) {
          toast.error("Apenas administradores podem alterar o fluxo padrão.");
        } else if (error.message.includes("not found")) {
          toast.error("Fluxo ou clínica não encontrado.");
        } else {
          toast.error("Erro de conexão. Tente novamente.");
        }
      } else {
        toast.error("Erro ao atualizar fluxo padrão");
      }
    } finally {
      setIsUpdating(false);
    }
  };

  // Filter to only active flows
  const activeFlows = flows.filter((f) => f.status === "active");

  // Show tooltip for non-admin users
  if (!isAdmin && !disabledProp) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="flex items-center gap-2 opacity-60 cursor-not-allowed">
              <Star className="h-4 w-4 text-muted-foreground" />
              <div className="flex flex-col gap-1.5">
                <Label className="text-sm font-medium">Fluxo Padrão</Label>
                <Select disabled>
                  <SelectTrigger className="w-[240px]" aria-label="Fluxo Padrão (apenas admin)">
                    <Star className="h-4 w-4 mr-2 text-yellow-500" />
                    <SelectValue
                      placeholder="Selecione um fluxo..."
                      aria-label={selectedFlowName ?? "Nenhum fluxo padrão definido"}
                    >
                      {selectedFlowName ? (
                        <span className="flex items-center gap-2">
                          {selectedFlowName}
                          <Badge variant="default" className="ml-2 bg-yellow-500 text-white">
                            Padrão
                          </Badge>
                        </span>
                      ) : (
                        "Nenhum (desativado)"
                      )}
                    </SelectValue>
                  </SelectTrigger>
                </Select>
              </div>
            </div>
          </TooltipTrigger>
          <TooltipContent side="bottom">
            <div className="flex items-center gap-2">
              <Lock className="h-4 w-4" />
              <span>Apenas administradores podem alterar o fluxo padrão</span>
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <Star className="h-4 w-4 text-muted-foreground" />
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="default-flow-select" className="text-sm font-medium">
          Fluxo Padrão
        </Label>
        <Select
          value={defaultFlowId ?? "none"}
          onValueChange={handleValueChange}
          disabled={isDisabled}
        >
          <SelectTrigger
            id="default-flow-select"
            className="w-[240px]"
            aria-label="Selecionar fluxo padrão"
            aria-busy={isUpdating}
          >
            <Star className="h-4 w-4 mr-2 text-yellow-500" />
            <SelectValue placeholder="Selecione um fluxo...">
              {selectedFlowName ? (
                <span className="flex items-center gap-2">
                  {selectedFlowName}
                  <Badge variant="default" className="ml-2 bg-yellow-500 text-white">
                    Padrão
                  </Badge>
                </span>
              ) : (
                "Nenhum (desativado)"
              )}
            </SelectValue>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none" className="text-muted-foreground">
              <span className="flex items-center gap-2">
                <AlertCircle className="h-4 w-4" />
                Nenhum (desativado)
              </span>
            </SelectItem>
            {activeFlows.length === 0 ? (
              <SelectItem value="no-flows" disabled>
                <span className="text-muted-foreground">Nenhum fluxo ativo disponível</span>
              </SelectItem>
            ) : (
              activeFlows.map((flow) => (
                <SelectItem key={flow.id} value={flow.id}>
                  <span className="flex items-center gap-2">
                    {flow.name}
                    {flow.id === defaultFlowId && (
                      <>
                        <Check className="h-4 w-4 text-green-500" />
                        <Badge variant="default" className="bg-yellow-500 text-white">
                          Padrão
                        </Badge>
                      </>
                    )}
                  </span>
                </SelectItem>
              ))
            )}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}

export type { DefaultFlowSelectorProps, FlowItem };
