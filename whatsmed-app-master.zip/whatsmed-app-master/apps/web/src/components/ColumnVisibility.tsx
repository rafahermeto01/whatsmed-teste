import { useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export type ColumnDef = { id: string; label: string; visible: boolean };

export function ColumnVisibility({
  columns,
  onChange,
  storageKey,
}: {
  columns: ColumnDef[];
  onChange: (cols: ColumnDef[]) => void;
  storageKey: string;
}) {
  const [state, setState] = useState<ColumnDef[]>(columns);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    // Only run this logic once on mount to merge defaults with storage
    if (initialized) return;

    try {
      const raw = localStorage.getItem(storageKey);
      if (raw) {
        const saved: ColumnDef[] = JSON.parse(raw);
        // Merge saved preferences with current column definitions (defaults)
        // This ensures new columns (not in storage) appear with their default visibility
        const merged = columns.map((col) => {
          const savedCol = saved.find((s) => s.id === col.id);
          return savedCol ? { ...col, visible: savedCol.visible } : col;
        });

        setState(merged);
        onChange(merged);
      } else {
        onChange(columns);
      }
    } catch {
      onChange(columns);
    } finally {
      setInitialized(true);
    }
  }, [storageKey, initialized]); // Remove 'columns' from deps to avoid re-triggering on change

  const update = (id: string, visible: boolean) => {
    const next = state.map((c) => (c.id === id ? { ...c, visible } : c));
    setState(next);
    localStorage.setItem(storageKey, JSON.stringify(next));
    onChange(next);
  };

  const reset = () => {
    // We can't easily reset to "defaults" because we don't have a persistent reference to them
    // after the parent state updates.
    // However, usually showing all or a specific set is desired.
    // For now, we will just make them all visible as a "safe" reset,
    // or we could try to use the 'columns' prop if it was static, but it's not.
    // A better approach for 'reset' in this architecture requires the parent to pass 'defaultColumns' separately.
    // But sticking to the current contract: let's make all visible or keep current labels.

    // Actually, since we updated 'state' to be the merged version,
    // if we want to reset to "defaults", we rely on the fact that we don't store defaults separately.
    // Let's just make all visible as a simple reset strategy for now, or revert to the initial state if we tracked it.

    // Modification: Use the current state structure but set all to true?
    // Or just clear storage and reload? Clearing storage is cleaner.
    localStorage.removeItem(storageKey);
    // Force a page reload or just let the next visit handle it?
    // Better: manually set all known columns to visible=true (or some default heuristic).
    // Since we don't know the true "default" anymore (it was overwritten),
    // let's assume "reset" means "show all" or "clear storage".

    // Let's go with: Clear storage and rely on the fact that 'columns' prop *currently* holds the structure.
    // But 'columns' prop holds the *current* visibility.
    // This is a limitation of the current component design (using state for both definition and value).

    // WORKAROUND: We will set all to visible: true.
    const next = state.map((c) => ({ ...c, visible: true }));
    setState(next);
    onChange(next);
    localStorage.removeItem(storageKey);
  };

  return (
    <div className="flex items-center gap-2">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline">Colunas</Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="max-h-[300px] overflow-y-auto">
          {state.map((c) => (
            <DropdownMenuCheckboxItem
              key={c.id}
              checked={c.visible}
              onCheckedChange={(v) => update(c.id, !!v)}
            >
              {c.label}
            </DropdownMenuCheckboxItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
      <Button variant="ghost" onClick={reset}>
        Resetar
      </Button>
    </div>
  );
}
