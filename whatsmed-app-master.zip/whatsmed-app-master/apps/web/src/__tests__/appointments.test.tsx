import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, it, expect, vi, afterEach } from "vitest";

import * as appointmentsHooks from "../hooks/appointments";
import { Route } from "../routes/appointments";

// Mock hooks
vi.mock("../hooks/patients", async () => {
  return {
    useClinicId: () => ({ clinicId: "clinic-123" }),
    usePatientsList: vi.fn(),
  };
});

vi.mock("../hooks/appointments", async () => {
  return {
    useClinicId: () => ({ clinicId: "clinic-123" }),
    useAppointmentsList: vi.fn(),
    useUpdateAppointment: vi.fn(() => async () => {}),
    useCreateAppointment: vi.fn(() => async () => {}),
  };
});

vi.mock("convex/react", () => ({
  useQuery: vi.fn(() => undefined),
  useAction: vi.fn(() => async () => {}),
  useMutation: vi.fn(() => async () => {}),
}));

vi.mock("../components/PlanGate", () => ({
  PlanGate: ({ children }: { children: any }) => <>{children}</>,
}));

vi.mock("../components/CreateAppointmentModal", () => ({
  CreateAppointmentModal: ({ open }: { open: boolean }) =>
    open ? <div role="dialog">Criar Novo Agendamento</div> : null,
}));

vi.mock("../components/AppointmentDetailsModal", () => ({
  AppointmentDetailsModal: ({ appointment }: { appointment: { patientName: string } }) => (
    <div role="dialog">{appointment.patientName}</div>
  ),
}));

vi.mock("../components/appointments/TelehealthModal", () => ({
  TelehealthModal: () => null,
}));

vi.mock("../components/appointments/RescheduleSuggestionModal", () => ({
  RescheduleSuggestionModal: () => null,
}));

// Mock ResizeObserver for Recharts or other UI components if needed
global.ResizeObserver = class ResizeObserver {
  observe() {}
  unobserve() {}
  disconnect() {}
};

describe("AppointmentsPage", () => {
  afterEach(() => {
    vi.useRealTimers();
  });

  it("renders calendar view by default", () => {
    (appointmentsHooks.useAppointmentsList as any).mockReturnValue({ items: [] });
    const Comp = Route.options.component as any;
    render(<Comp />);

    expect(screen.getByText(/Mês/i)).toBeTruthy();
    // Should see days of week
    expect(screen.getByText("Dom")).toBeTruthy();
  });

  it("renders appointments in list view", async () => {
    const now = new Date();
    (appointmentsHooks.useAppointmentsList as any).mockReturnValue({
      items: [
        {
          _id: "apt1",
          patientName: "John Doe",
          startAt: now.getTime(),
          status: "pending",
          clinicId: "clinic-123",
          doctor: "Dr. Smith",
        },
      ],
    });

    const Comp = Route.options.component as any;
    render(<Comp />);

    // Switch to list view
    const listBtn = screen.getByText("Lista");
    fireEvent.click(listBtn);

    await waitFor(() => {
      expect(screen.getByText("John Doe")).toBeTruthy();
      expect(screen.getByText(/Dr. Smith/)).toBeTruthy();
    });
  });

  it("shows the full selected date in day view", () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-03-11T10:00:00.000Z"));

    (appointmentsHooks.useAppointmentsList as any).mockReturnValue({ items: [] });

    const Comp = Route.options.component as any;
    render(<Comp />);

    fireEvent.click(screen.getByText("Dia"));

    expect(screen.getByRole("heading", { name: /11 de março de 2026/i })).toBeTruthy();
  });

  it("keeps month and list views showing the month label", () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-03-11T10:00:00.000Z"));

    (appointmentsHooks.useAppointmentsList as any).mockReturnValue({ items: [] });

    const Comp = Route.options.component as any;
    render(<Comp />);

    expect(screen.getByRole("heading", { name: /março 2026/i })).toBeTruthy();

    fireEvent.click(screen.getByText("Lista"));

    expect(screen.getByRole("heading", { name: /março 2026/i })).toBeTruthy();
  });

  it("opens modal when clicking details", async () => {
    const now = new Date();
    (appointmentsHooks.useAppointmentsList as any).mockReturnValue({
      items: [
        {
          _id: "apt1",
          patientName: "John Doe",
          startAt: now.getTime(),
          status: "pending",
          clinicId: "clinic-123",
        },
      ],
    });

    const Comp = Route.options.component as any;
    render(<Comp />);

    // Switch to list view to easily find button
    fireEvent.click(screen.getByText("Lista"));

    const detailsBtn = await screen.findByText("Detalhes");
    fireEvent.click(detailsBtn);

    // Modal should appear
    expect(screen.getByRole("dialog")).toBeTruthy();
    expect(screen.getAllByText("John Doe").length).toBeGreaterThan(1);
  });

  it("opens create appointment modal", async () => {
    (appointmentsHooks.useAppointmentsList as any).mockReturnValue({ items: [] });
    const Comp = Route.options.component as any;
    render(<Comp />);

    const createBtn = screen.getByText("Novo Agendamento");
    fireEvent.click(createBtn);

    expect(screen.getByRole("dialog")).toBeTruthy();
    expect(screen.getByText("Criar Novo Agendamento")).toBeTruthy();
  });
});
