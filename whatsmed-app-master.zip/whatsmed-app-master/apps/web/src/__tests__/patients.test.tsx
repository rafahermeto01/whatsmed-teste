import { render, screen } from "@testing-library/react";
import * as convexReact from "convex/react";
import { describe, it, expect, vi } from "vitest";

import * as PatientsPageModule from "../routes/patients";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

vi.spyOn(PatientsPageModule.Route, "useSearch").mockImplementation(() => ({ search: "" }) as any);

vi.mock("convex/react", () => ({
  useQuery: vi.fn(),
  useMutation: vi.fn(),
}));

vi.mocked(convexReact.useQuery).mockImplementation((fn: any, args?: any) => {
  if (fn === api.auth.getCurrentUser) {
    return { clinicId: "clinic-demo", role: "admin" };
  }
  if (fn === api.patients.list) {
    if (args === "skip") return undefined as any;
    return { items: [{ _id: "p1", name: "Maria", phone: "123", status: "active" }] } as any;
  }
  return undefined as any;
});

vi.mocked(convexReact.useMutation).mockImplementation((_fn: any) => {
  const mutation = vi.fn(async () => ({}));
  (mutation as any).withOptimisticUpdate = vi.fn(() => mutation);
  return mutation as any;
});

describe("PatientsPage", () => {
  it("renders loading state", () => {
    (convexReact.useQuery as any).mockImplementation((fn: any, args?: any) => {
      if (fn === api.auth.getCurrentUser) {
        return { clinicId: "clinic-demo", role: "admin" };
      }
      if (fn === api.patients.list) {
        if (args === "skip") return undefined as any;
        return undefined;
      }
      return undefined as any;
    });

    const Comp = (PatientsPageModule as any).Route.options.component;
    render(<Comp />);
    expect(screen.getByText("Carregando...")).toBeTruthy();
  });

  it("renders patients list", async () => {
    (convexReact.useQuery as any).mockImplementation((fn: any, args?: any) => {
      if (fn === api.auth.getCurrentUser) {
        return { clinicId: "clinic-demo", role: "admin" };
      }
      if (fn === api.patients.list) {
        if (args === "skip") return undefined as any;
        return { items: [{ _id: "p1", name: "Maria", phone: "123", status: "active" }] } as any;
      }
      return undefined as any;
    });

    const Comp = (PatientsPageModule as any).Route.options.component;
    render(<Comp />);
    expect(await screen.findByText("Maria")).toBeTruthy();
  });
});
