import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { format } from "date-fns";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { RescheduleAppointmentModal } from "../components/RescheduleAppointmentModal";

const { mockToastError } = vi.hoisted(() => ({
  mockToastError: vi.fn(),
}));

const mockUpdateAppointment = vi.fn();
const mockAppointmentsList = vi.fn();

vi.mock("../hooks/appointments", () => ({
  useAppointmentsList: vi.fn((...args) => mockAppointmentsList(...args)),
  useUpdateAppointment: vi.fn(() => mockUpdateAppointment),
}));

vi.mock("convex/react", () => ({
  useQuery: vi.fn((_fn, args) => {
    if (args === "skip") {
      return undefined;
    }

    if (args?.date) {
      return [
        {
          start: "2026-03-16T13:00:00.000Z",
          end: "2026-03-16T14:00:00.000Z",
        },
      ];
    }

    return {
      dates: ["2026-03-16"],
    };
  }),
}));

vi.mock("sonner", () => ({
  toast: {
    success: vi.fn(),
    error: mockToastError,
  },
}));

describe("RescheduleAppointmentModal", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockUpdateAppointment.mockResolvedValue({});
    mockAppointmentsList.mockReturnValue({
      items: [
        {
          _id: "appointment-1",
          startAt: Date.UTC(2026, 2, 16, 12, 0, 0),
          endAt: Date.UTC(2026, 2, 16, 13, 0, 0),
          status: "confirmed",
          doctor: "Doctor Test",
          doctorId: "doctor-1",
          procedure: "Teleconsulta Teste",
          procedureId: "procedure-1",
          patientName: "Paciente Teste",
          isTelemedicine: true,
        },
      ],
    });
  });

  it("sends rescheduleStatus when confirming a manual reschedule", async () => {
    const slotLabel = format(new Date("2026-03-16T13:00:00.000Z"), "HH:mm");

    render(
      <RescheduleAppointmentModal
        open
        onOpenChange={() => {}}
        patientId={"patient-1" as any}
        clinicId="clinic-demo"
        patientName="Paciente Teste"
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: /doctor test/i }));
    fireEvent.click(await screen.findByRole("button", { name: /16\/03/i }));
    fireEvent.click(await screen.findByRole("button", { name: slotLabel }));
    fireEvent.click(screen.getByRole("button", { name: /confirmar reagendamento/i }));

    await waitFor(() => {
      expect(mockUpdateAppointment).toHaveBeenCalledWith(
        expect.objectContaining({
          clinicId: "clinic-demo",
          id: "appointment-1",
          isTelemedicine: true,
          rescheduleStatus: "rescheduled",
        }),
      );
    });
  });

  it("includes the current appointment even when it is outside the default patient query", async () => {
    mockAppointmentsList.mockReturnValue({ items: [] });

    render(
      <RescheduleAppointmentModal
        open
        onOpenChange={() => {}}
        patientId={"patient-1" as any}
        clinicId="clinic-demo"
        patientName="Paciente Teste"
        initialAppointment={{
          _id: "appointment-current",
          startAt: Date.UTC(2026, 2, 16, 12, 0, 0),
          endAt: Date.UTC(2026, 2, 16, 13, 0, 0),
          status: "cancelled",
          doctor: "Doctor Test",
          doctorId: "doctor-1",
          procedure: "Teleconsulta Teste",
          procedureId: "procedure-1",
          patientName: "Paciente Teste",
          isTelemedicine: true,
        }}
      />,
    );

    expect(await screen.findByRole("button", { name: /doctor test/i })).toBeTruthy();
    expect(screen.getByText("Cancelado")).toBeTruthy();
  });

  it("switches to time selection after choosing a day and allows going back", async () => {
    render(
      <RescheduleAppointmentModal
        open
        onOpenChange={() => {}}
        patientId={"patient-1" as any}
        clinicId="clinic-demo"
        patientName="Paciente Teste"
      />,
    );

    fireEvent.click(await screen.findByRole("button", { name: /doctor test/i }));
    fireEvent.click(await screen.findByRole("button", { name: /16\/03/i }));

    expect(screen.getByText("Novo Horário")).toBeTruthy();
    expect(screen.queryByText("Nova Data")).toBeNull();

    fireEvent.click(screen.getByRole("button", { name: /voltar para datas/i }));

    expect(screen.getByText("Nova Data")).toBeTruthy();
  });
});
