import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { AppointmentDetailsModal } from "../components/AppointmentDetailsModal";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

const mockUpdateAppointment = vi.fn();

vi.mock("../hooks/appointments", () => ({
  useClinicId: () => ({ clinicId: "clinic-123" }),
  useUpdateAppointment: () => mockUpdateAppointment,
}));

vi.mock("@/components/appointments/TelehealthModal", () => ({
  TelehealthModal: () => null,
}));

vi.mock("@/components/RescheduleAppointmentModal", () => ({
  RescheduleAppointmentModal: ({ open, initialAppointment }: any) =>
    open ? <div data-testid="reschedule-modal">{initialAppointment?._id}</div> : null,
}));

vi.mock("convex/react", () => ({
  useQuery: vi.fn((fn: any) => {
    if (fn === api.procedures.getById) {
      return {
        _id: "procedure-1",
        name: "Consulta Geral",
        durationMinutes: 30,
      };
    }

    return undefined;
  }),
}));

describe("AppointmentDetailsModal", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockUpdateAppointment.mockResolvedValue({});
  });

  it("keeps manual reschedule available for cancelled appointments with a linked patient", () => {
    render(
      <AppointmentDetailsModal
        appointment={
          {
            _id: "apt-cancelled",
            patientId: "patient-1",
            patientName: "John Doe",
            startAt: Date.now(),
            endAt: Date.now() + 30 * 60 * 1000,
            status: "cancelled",
            createdAt: Date.now(),
          } as any
        }
        onClose={() => {}}
      />,
    );

    const button = screen.getByRole("button", { name: "Reagendar" });
    expect(button.hasAttribute("disabled")).toBe(false);

    fireEvent.click(button);
    expect(screen.getByTestId("reschedule-modal").textContent).toBe("apt-cancelled");
  });

  it("shows disabled manual reschedule when patient is not linked", () => {
    render(
      <AppointmentDetailsModal
        appointment={
          {
            _id: "apt-no-patient",
            patientName: "John Doe",
            startAt: Date.now(),
            endAt: Date.now() + 30 * 60 * 1000,
            status: "pending",
            createdAt: Date.now(),
          } as any
        }
        onClose={() => {}}
      />,
    );

    expect(screen.getByRole("button", { name: "Reagendar" }).hasAttribute("disabled")).toBe(true);
  });
});
