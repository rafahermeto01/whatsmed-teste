import { render, screen } from "@testing-library/react";
import * as convexReact from "convex/react";
import { describe, it, expect, vi } from "vitest";

import * as PatientsPageModule from "../routes/patients";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

vi.spyOn(PatientsPageModule.Route, "useSearch").mockImplementation(() => ({ search: "" }) as any);

vi.mock("convex/react", () => ({
  useQuery: vi.fn(),
  useMutation: vi.fn(() => vi.fn(async () => ({}))),
}));

describe("PatientsPage integration-like", () => {
  it("shows empty state when no patients", async () => {
    vi.mocked(convexReact.useQuery).mockImplementation((fn: any, _args?: any) => {
      if (fn === api.auth.getCurrentUser) return { clinicId: "clinic-demo" };
      if (fn === api.patients.list) return { items: [] } as any;
      return undefined as any;
    });
    const Comp = (PatientsPageModule as any).Route.options.component;
    render(<Comp />);
    expect(await screen.findByText("Nenhum paciente encontrado")).toBeTruthy();
  });
});
