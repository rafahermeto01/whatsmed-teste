import { fireEvent, render, screen } from "@testing-library/react";
import * as React from "react";
import { beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

import { AppointmentDetailsModal } from "../components/AppointmentDetailsModal";
import { CreateAppointmentModal } from "../components/CreateAppointmentModal";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

const { mockDoctorConnectionStatus, mockToastError } = vi.hoisted(() => ({
  mockDoctorConnectionStatus: vi.fn((_: unknown) => ({ connected: true })),
  mockToastError: vi.fn(),
}));

vi.mock("date-fns", async (importOriginal) => {
  const actual = await importOriginal<typeof import("date-fns")>();
  return {
    ...actual,
    isBefore: () => false,
  };
});

const mockCreateAppointment = vi.fn();
const mockUpdateAppointment = vi.fn();

const mockDoctors = [
  { _id: "user-1", name: "Dr. House", email: "house@clinic.com" },
  { _id: "user-2", name: "Dr. Wilson", email: "wilson@clinic.com" },
];

const mockPatientsResult = {
  items: [
    {
      _id: "patient-1",
      name: "John Doe",
      email: "john@example.com",
      cpf: "12345678901",
      phone: "5511999999999",
    },
  ],
  cursor: null,
  isDone: true,
};

let mockProcedures = [
  {
    _id: "procedure-1",
    name: "Consulta Geral",
    durationMinutes: 30,
    isTelemedicine: false,
    isInPerson: true,
  },
];

vi.mock("../hooks/patients", () => ({
  useClinicId: () => ({ clinicId: "clinic-123", role: "admin" }),
  usePatientsList: () => mockPatientsResult,
}));

vi.mock("../hooks/users", () => ({
  useDoctorsList: () => mockDoctors,
}));

vi.mock("../hooks/appointments", () => ({
  useClinicId: () => ({ clinicId: "clinic-123" }),
  useCreateAppointment: () => mockCreateAppointment,
  useUpdateAppointment: () => mockUpdateAppointment,
}));

vi.mock("@/components/ui/select", () => {
  const SelectContext = React.createContext<{ onValueChange?: (value: string) => void }>({});

  return {
    Select: ({ onValueChange, children }: any) => (
      <SelectContext.Provider value={{ onValueChange }}>{children}</SelectContext.Provider>
    ),
    SelectTrigger: ({ children }: any) => <div role="combobox">{children}</div>,
    SelectValue: ({ placeholder }: any) => <span>{placeholder}</span>,
    SelectContent: ({ children }: any) => <div>{children}</div>,
    SelectItem: ({ value, children }: any) => {
      const ctx = React.useContext(SelectContext);
      return (
        <button type="button" onClick={() => ctx.onValueChange?.(value)}>
          {children}
        </button>
      );
    },
  };
});

vi.mock("@/components/appointments/TelehealthModal", () => ({
  TelehealthModal: () => null,
}));

vi.mock("@/components/RescheduleAppointmentModal", () => ({
  RescheduleAppointmentModal: () => null,
}));

vi.mock("convex/react", () => ({
  useQuery: vi.fn((fn: any, args: any) => {
    if (args === "skip") {
      return undefined;
    }

    if (args?.doctorId && !args?.clinicId && !args?.procedureId) {
      return mockDoctorConnectionStatus(args);
    }

    if (args?.clinicId && !args?.doctorId && !args?.patientId && !args?.procedureId) {
      return [];
    }

    if (args?.doctorId && args?.clinicId && !args?.procedureId && !args?.date) {
      return mockProcedures;
    }

    if (fn === api.appointments.getAvailableSlots) {
      if (args?.date) {
        return [
          {
            start: "2026-03-20T13:00:00",
            end: "2026-03-20T13:30:00",
          },
        ];
      }

      return {
        dates: ["2026-03-20"],
      };
    }

    if (fn === api.procedures.getById) {
      return {
        _id: "procedure-1",
        name: "Consulta Geral",
        durationMinutes: 30,
      };
    }

    return undefined;
  }),
}));

vi.mock("sonner", () => ({
  toast: {
    success: vi.fn(),
    error: mockToastError,
  },
}));

describe("Doctor Assignment", () => {
  beforeAll(() => {
    Object.defineProperty(Element.prototype, "scrollIntoView", {
      configurable: true,
      value: vi.fn(),
    });
  });

  beforeEach(() => {
    vi.clearAllMocks();
    mockCreateAppointment.mockResolvedValue({});
    mockUpdateAppointment.mockResolvedValue({});
    mockDoctorConnectionStatus.mockReturnValue({ connected: true });
    mockProcedures = [
      {
        _id: "procedure-1",
        name: "Consulta Geral",
        durationMinutes: 30,
        isTelemedicine: false,
        isInPerson: true,
      },
    ];
  });

  describe("CreateAppointmentModal", () => {
    it("shows procedure options for the selected doctor", async () => {
      render(<CreateAppointmentModal open={true} onOpenChange={() => {}} />);

      fireEvent.click(screen.getByText("Buscar paciente..."));
      fireEvent.click(screen.getByText("John Doe"));

      fireEvent.click(screen.getByText("Selecione um médico"));
      fireEvent.click(await screen.findByText("Dr. House"));

      expect(await screen.findByText(/Consulta Geral/)).toBeTruthy();
    });

    it("shows a clear error and blocks telemedicine when the doctor has no Google Calendar", async () => {
      mockProcedures = [
        {
          _id: "procedure-tele-1",
          name: "Teleconsulta",
          durationMinutes: 30,
          isTelemedicine: true,
          isInPerson: false,
        },
      ];
      mockDoctorConnectionStatus.mockReturnValue({ connected: false });

      render(<CreateAppointmentModal open={true} onOpenChange={() => {}} />);

      fireEvent.click(screen.getByText("Buscar paciente..."));
      fireEvent.click(screen.getByText("John Doe"));

      fireEvent.click(screen.getByText("Selecione um médico"));
      fireEvent.click(await screen.findByText("Dr. House"));

      fireEvent.click(screen.getAllByRole("combobox")[2]!);
      fireEvent.click(await screen.findByText(/Teleconsulta/));

      expect(
        await screen.findByText(/conecte o google calendar do médico em integrações/i),
      ).toBeTruthy();
      expect(screen.getByRole("link", { name: /abrir integrações/i })).toBeTruthy();
      expect(
        (screen.getByRole("button", { name: /confirmar agendamento/i }) as HTMLButtonElement)
          .disabled,
      ).toBe(true);
      expect(mockCreateAppointment).not.toHaveBeenCalled();
    });
  });

  describe("AppointmentDetailsModal", () => {
    it("shows assigned doctor in details", () => {
      render(
        <AppointmentDetailsModal
          appointment={
            {
              _id: "apt-1",
              patientName: "John Doe",
              startAt: Date.now(),
              status: "pending",
              doctorId: "user-1",
              doctor: "Dr. House",
              createdAt: Date.now(),
            } as any
          }
          onClose={() => {}}
        />,
      );

      expect(screen.getByText("Dr. House")).toBeTruthy();
    });

    it("shows unassigned label when appointment has no doctor", () => {
      render(
        <AppointmentDetailsModal
          appointment={
            {
              _id: "apt-2",
              patientName: "John Doe",
              startAt: Date.now(),
              status: "pending",
              createdAt: Date.now(),
            } as any
          }
          onClose={() => {}}
        />,
      );

      expect(screen.getByText("Não atribuído")).toBeTruthy();
    });
  });
});
