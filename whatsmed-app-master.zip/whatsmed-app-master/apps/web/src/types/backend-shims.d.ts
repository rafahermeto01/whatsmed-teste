import type { Id as ConvexId } from "convex/values";

declare module "@whatsmed-app/backend/convex/_generated/dataModel" {
  export type TableNames = string;
  export type Id<TableName extends string = TableNames> = ConvexId<TableName>;
  export type Doc<TableName extends string = TableNames> = {
    _id: Id<TableName>;
    _creationTime: number;
  } & Record<string, unknown>;
  export type DataModel = Record<
    string,
    {
      document: Doc;
      fieldPaths: string;
      indexes: string;
      searchIndexes: string;
      vectorIndexes: string;
    }
  >;
}
