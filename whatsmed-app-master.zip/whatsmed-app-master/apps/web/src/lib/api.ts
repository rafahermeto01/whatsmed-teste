export function apiUrl(path: string) {
  if (path.startsWith("/api/")) return path;
  const base = `${import.meta.env.VITE_CONVEX_URL}/http`;
  return `${base}${path}`;
}

export async function apiFetch(path: string, init?: RequestInit) {
  const url = apiUrl(path);
  const res = await fetch(url, {
    credentials: "include",
    ...init,
  });
  return res;
}
