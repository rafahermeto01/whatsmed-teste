/* eslint-disable no-console */
import { onCLS, onINP, onLCP, onTTFB } from "web-vitals";

export function startPerfLogging(prefix: string) {
  onCLS((m) => console.log(`${prefix} CLS`, m.value));
  onINP((m) => console.log(`${prefix} INP`, m.value));
  onLCP((m) => console.log(`${prefix} LCP`, m.value));
  onTTFB((m) => console.log(`${prefix} TTFB`, m.value));
}
