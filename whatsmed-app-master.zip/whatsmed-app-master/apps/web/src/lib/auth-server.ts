import { setupFetchClient } from "@convex-dev/better-auth/react-start";
import { getCookie } from "@tanstack/react-start/server";

const createAuthCookieAdapter = (() => ({ options: {} })) as never;

export const { fetchQuery, fetchMutation, fetchAction } = await setupFetchClient(
  createAuthCookieAdapter,
  getCookie,
);
