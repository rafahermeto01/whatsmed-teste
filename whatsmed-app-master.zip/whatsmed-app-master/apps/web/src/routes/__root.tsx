import { ConvexBetterAuthProvider } from "@convex-dev/better-auth/react";
import { fetchAuth as fetchServerAuth } from "@convex-dev/better-auth/react-start";
import {
  HeadContent,
  Outlet,
  Scripts,
  createRootRouteWithContext,
  useRouteContext,
  redirect,
  useLocation,
} from "@tanstack/react-router";
import { TanStackRouterDevtools } from "@tanstack/react-router-devtools";
import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";

import { MainLayout } from "../components/MainLayout";
import appCss from "../index.css?url";
import { Toaster } from "@/components/ui/sonner";
import { authClient } from "@/lib/auth-client";

import type { ConvexQueryClient } from "@convex-dev/react-query";
import type { QueryClient } from "@tanstack/react-query";
import type { ConvexReactClient } from "convex/react";

const fetchAuth = createServerFn({ method: "GET" }).handler(async () => {
  const request = getRequest();
  const auth = await fetchServerAuth(request);

  return {
    userId: auth?.userId,
    token: auth?.token,
  };
});

export interface RouterAppContext {
  queryClient: QueryClient;
  convexClient: ConvexReactClient;
  convexQueryClient: ConvexQueryClient;
}

export const Route = createRootRouteWithContext<RouterAppContext>()({
  head: () => ({
    meta: [
      {
        charSet: "utf-8",
      },
      {
        name: "viewport",
        content: "width=device-width, initial-scale=1",
      },
      {
        title: "Whatsmed",
      },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      {
        rel: "icon",
        type: "image/svg+xml",
        href: "/logos/favicon.svg",
      },
    ],
  }),

  component: RootDocument,
  beforeLoad: async (ctx) => {
    const isPublicRoute =
      ctx.location.pathname.startsWith("/login") ||
      ctx.location.pathname.startsWith("/reset-password") ||
      ctx.location.pathname.startsWith("/api/auth") ||
      ctx.location.pathname.startsWith("/api/oauth") ||
      ctx.location.pathname.startsWith("/checkin") ||
      ctx.location.pathname.startsWith("/totem") ||
      ctx.location.pathname.startsWith("/accept-invite");

    // Skip auth check for public routes to prevent loops
    if (isPublicRoute) {
      return {};
    }

    try {
      const { userId, token } = await fetchAuth();

      if (token) {
        ctx.context.convexQueryClient.serverHttpClient?.setAuth(token);
      }

      if (userId) {
        return { userId, token };
      }

      throw redirect({
        to: "/login",
        search: {
          redirect: ctx.location.href,
        },
      });
    } catch (error) {
      if (error && typeof error === "object" && "to" in error) {
        throw error;
      }
      throw redirect({
        to: "/login",
        search: {
          redirect: ctx.location.href,
        },
      });
    }
  },
});

function RootDocument() {
  const context = useRouteContext({ from: Route.id });
  const location = useLocation();
  const isPublicRoute =
    location.pathname.startsWith("/login") ||
    location.pathname.startsWith("/reset-password") ||
    location.pathname.startsWith("/api/auth") ||
    location.pathname.startsWith("/api/oauth") ||
    location.pathname.startsWith("/checkin") ||
    location.pathname.startsWith("/totem") ||
    location.pathname.startsWith("/accept-invite");

  return (
    <ConvexBetterAuthProvider client={context.convexClient} authClient={authClient}>
      <html lang="en">
        <head>
          <HeadContent />
        </head>
        <body>
          {isPublicRoute ? (
            <Outlet />
          ) : (
            <MainLayout>
              <Outlet />
            </MainLayout>
          )}
          <Toaster richColors />
          <TanStackRouterDevtools position="bottom-left" />
          <Scripts />
        </body>
      </html>
    </ConvexBetterAuthProvider>
  );
}
