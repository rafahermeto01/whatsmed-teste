import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Authenticated, Unauthenticated } from "convex/react";
import { Eye, EyeOff, Check } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { authClient } from "@/lib/auth-client";

export const Route = createFileRoute("/reset-password")({
  validateSearch: (search: Record<string, unknown>) => {
    return {
      token: (search.token as string) || "",
    };
  },
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const search = Route.useSearch();
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);

  const [validations, setValidations] = useState({
    minLength: false,
    hasNumber: false,
    hasSpecial: false,
    passwordsMatch: false,
  });

  useEffect(() => {
    setValidations({
      minLength: newPassword.length >= 8,
      hasNumber: /\d/.test(newPassword),
      hasSpecial: /[!@#$%^&*(),.?":{}|<>]/.test(newPassword),
      passwordsMatch: newPassword.length > 0 && newPassword === confirmPassword,
    });
  }, [newPassword, confirmPassword]);

  const isFormValid = Object.values(validations).every(Boolean);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFormValid) return;
    setLoading(true);
    try {
      const { error } = await authClient.resetPassword({
        newPassword,
        token: search.token,
      });
      if (error) {
        throw new Error(error.message);
      }
      toast.success("Senha atualizada com sucesso");
      navigate({ to: "/login", search: { redirect: "/" } });
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || "Não foi possível atualizar a senha");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-svh items-center justify-center px-4">
      <Authenticated>
        <Card className="w-full max-w-md p-6">
          <p className="text-sm">You are signed in.</p>
          <Button className="mt-3" onClick={() => navigate({ to: "/dashboard" })}>
            Go to Dashboard
          </Button>
        </Card>
      </Authenticated>
      <Unauthenticated>
        <div
          className="w-full max-w-md bg-card border border-border p-10 space-y-8"
          style={{
            borderRadius: "var(--radius)",
            boxShadow: "var(--shadow-lg)",
          }}
        >
          {/* Logo */}
          <div className="flex flex-col items-center space-y-2">
            <img src="/logos/stacked.svg" alt="WhatsMed" className="h-16 w-auto" />
          </div>

          <div className="text-center space-y-2">
            <h2 className="text-foreground text-xl font-medium">Redefinir Senha</h2>
            <p className="text-muted-foreground text-sm">Crie uma senha forte para sua conta</p>
          </div>

          <form onSubmit={onSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="newPassword" className="block text-foreground font-medium text-base">
                Nova Senha
              </Label>
              <div className="relative">
                <Input
                  id="newPassword"
                  type={showNew ? "text" : "password"}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  className="w-full h-10 px-3 pr-10 bg-input-background border border-input focus:border-ring focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 transition-all"
                  style={{ borderRadius: "var(--radius)" }}
                />
                <button
                  type="button"
                  onClick={() => setShowNew((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showNew ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <Label
                htmlFor="confirmPassword"
                className="block text-foreground font-medium text-base"
              >
                Confirmar Nova Senha
              </Label>
              <div className="relative">
                <Input
                  id="confirmPassword"
                  type={showConfirm ? "text" : "password"}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  className="w-full h-10 px-3 pr-10 bg-input-background border border-input focus:border-ring focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 transition-all"
                  style={{ borderRadius: "var(--radius)" }}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirm((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showConfirm ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="space-y-2 p-4 bg-muted" style={{ borderRadius: "var(--radius)" }}>
              <p className="mb-3 text-sm text-foreground">A senha deve conter:</p>
              <ValidationItem text="Pelo menos 8 caracteres" isValid={validations.minLength} />
              <ValidationItem text="Pelo menos um número" isValid={validations.hasNumber} />
              <ValidationItem
                text="Pelo menos um caractere especial"
                isValid={validations.hasSpecial}
              />
              {confirmPassword.length > 0 && (
                <ValidationItem text="As senhas coincidem" isValid={validations.passwordsMatch} />
              )}
            </div>

            <button
              type="submit"
              disabled={!isFormValid || loading}
              className="w-full h-10 bg-primary text-primary-foreground hover:opacity-90 transition-opacity font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ borderRadius: "var(--radius)" }}
            >
              {loading ? "Atualizando..." : "Atualizar Senha"}
            </button>
          </form>
        </div>
      </Unauthenticated>
    </div>
  );
}

function ValidationItem({ text, isValid }: { text: string; isValid: boolean }) {
  return (
    <div className="flex items-center gap-2 text-sm">
      <div
        className={`w-4 h-4 flex items-center justify-center ${isValid ? "bg-accent" : "bg-muted-foreground/20"}`}
        style={{ borderRadius: "calc(var(--radius) / 2)" }}
      >
        {isValid && <Check size={12} className="text-white" />}
      </div>
      <span className={isValid ? "text-accent" : "text-muted-foreground"}>{text}</span>
    </div>
  );
}
