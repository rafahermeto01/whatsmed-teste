import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "convex/react";
import { MoreVertical, Edit, Eye, Trash2, SlidersHorizontal } from "lucide-react";
import { useMemo, useState, useEffect, useCallback } from "react";
import { type DateRange } from "react-day-picker";
import { toast } from "sonner";
import { z } from "zod";

import { AddPatientModal, type Patient } from "@/components/AddPatientModal";
import { BulkImportModal } from "@/components/BulkImportModal";
import { type ColumnDef } from "@/components/ColumnVisibility";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { BroadcastMessageModal } from "@/components/patients/BroadcastMessageModal";
import { OptionsPanel } from "@/components/patients/OptionsPanel";
import { PatientActionbar } from "@/components/patients/PatientActionbar";
import { PatientHistorySheet } from "@/components/patients/PatientHistorySheet";
import { SendCampaignModal } from "@/components/patients/SendCampaignModal";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  useClinicId,
  usePatientsList,
  useCreatePatient,
  useUpdatePatient,
  useDeletePatient,
} from "@/hooks/patients";
import { startPerfLogging } from "@/lib/perf";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

const PAGE_SIZE_OPTIONS = [10, 25, 50, 100] as const;

const searchSchema = z.object({
  search: z.string().optional(),
});

function formatDateInputUtc(timestamp?: number): string {
  if (!timestamp) return "";
  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) return "";
  const year = date.getUTCFullYear();
  const month = String(date.getUTCMonth() + 1).padStart(2, "0");
  const day = String(date.getUTCDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export const Route = createFileRoute("/patients")({
  validateSearch: searchSchema,
  component: PatientsPage,
});

function mapPatientDocToView(p: any): Patient {
  return {
    id: p._id,
    name: p.name,
    phone: p.phone || "",
    email: p.email || "",
    cpf: p.cpf || "",
    gender: p.gender,
    address: p.address || "",
    city: p.city || "",
    state: p.state || "",
    zip: p.zip || "",
    country: p.country || "",
    tags: p.tags || [],
    notes: p.notes || "",
    status: p.status,
    dateOfBirth: formatDateInputUtc(p.dateOfBirth),
    externalId: p.externalId || "",
    createdAt: p.createdAt,
    updatedAt: p.updatedAt,
    nextAppointment: "-",
  };
}

function sanitizeCsvCell(value: unknown): string {
  const stringValue = String(value ?? "");
  return /^[\t ]*[=+\-@]/.test(stringValue) ? `'${stringValue}` : stringValue;
}

function PatientsPage() {
  const { search: initialSearch } = Route.useSearch();
  const [searchTerm, setSearchTerm] = useState(initialSearch || "");
  const [statusFilter, setStatusFilter] = useState("all");
  const [addOpen, setAddOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [historyPatient, setHistoryPatient] = useState<Patient | null>(null);
  const [debouncedSearch, setDebouncedSearch] = useState(initialSearch || "");
  const [selectedPatients, setSelectedPatients] = useState<Set<string>>(new Set());
  const [showBulkConfirm, setShowBulkConfirm] = useState(false);
  const [broadcastModalOpen, setBroadcastModalOpen] = useState(false);
  const [campaignModalOpen, setCampaignModalOpen] = useState(false);
  const [hasEmail, setHasEmail] = useState<"any" | "yes" | "no">("any");
  const [hasPhone, setHasPhone] = useState<"any" | "yes" | "no">("any");
  const [dateRange, setDateRange] = useState<DateRange | undefined>(undefined);
  const [logic, setLogic] = useState<"and" | "or">("and");
  const [sortBy, setSortBy] = useState<"createdAt" | "status">("createdAt");
  const [order, setOrder] = useState<"asc" | "desc">("desc");
  const [cursor, setCursor] = useState<string | null>(null);
  const [cursorHistory, setCursorHistory] = useState<string[]>([]);
  const [itemsPerPage, setItemsPerPage] = useState<number>(25);
  const [currentPage, setCurrentPage] = useState(1);
  const [existingPatientId, setExistingPatientId] = useState<string | null>(null);
  const [columns, setColumns] = useState<ColumnDef[]>([
    { id: "createdAt", label: "Criado", visible: true },
    { id: "updatedAt", label: "Atualizado", visible: false },
    { id: "name", label: "Nome", visible: true },
    { id: "cpf", label: "CPF", visible: true },
    { id: "phone", label: "Telefone", visible: true },
    { id: "email", label: "Email", visible: true },
    { id: "dateOfBirth", label: "Nascimento", visible: true },
    { id: "gender", label: "Gênero", visible: false },
    { id: "address", label: "Endereço", visible: true },
    { id: "city", label: "Cidade", visible: true },
    { id: "state", label: "Estado", visible: true },
    { id: "zip", label: "CEP", visible: false },
    { id: "country", label: "País", visible: false },
    { id: "tags", label: "Tags", visible: false },
    { id: "notes", label: "Notas", visible: false },
    { id: "externalId", label: "ID Externo", visible: true },
    { id: "status", label: "Status", visible: true },
    { id: "actions", label: "Ações", visible: true },
  ]);
  const { clinicId, role } = useClinicId();
  const createPatient = useCreatePatient();
  const updatePatient = useUpdatePatient();
  const deletePatientMutation = useDeletePatient();

  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(searchTerm), 500);
    return () => clearTimeout(t);
  }, [searchTerm]);

  const statusArg = useMemo(
    () => (statusFilter === "all" ? undefined : (statusFilter as "active" | "inactive")),
    [statusFilter],
  );
  const listResult = usePatientsList({
    clinicId,
    status: statusArg,
    search: debouncedSearch || undefined,
    limit: itemsPerPage,
    cursor: cursor || undefined,
    sortBy,
    order,
    dateStart: dateRange?.from ? dateRange.from.getTime() : undefined,
    dateEnd: dateRange?.to ? dateRange.to.getTime() : undefined,
    hasEmail: hasEmail === "any" ? undefined : hasEmail === "yes",
    hasPhone: hasPhone === "any" ? undefined : hasPhone === "yes",
    orFilters: logic === "or",
  } as any);

  // Reset pagination when filters change
  useEffect(() => {
    setCursor(null);
    setCursorHistory([]);
    setCurrentPage(1);
  }, [
    debouncedSearch,
    statusArg,
    itemsPerPage,
    sortBy,
    order,
    dateRange,
    hasEmail,
    hasPhone,
    logic,
  ]);

  const loading = listResult === undefined;
  const patientsData = listResult?.items ?? [];
  const nextCursor = (listResult as any)?.cursor ?? null;
  const existingPatient = useQuery(
    api.patients.getById,
    clinicId && existingPatientId ? { id: existingPatientId as any, clinicId } : "skip",
  );

  useEffect(() => {
    if (!existingPatient) return;
    setSelectedPatient(mapPatientDocToView(existingPatient));
    setAddOpen(true);
    setExistingPatientId(null);
  }, [existingPatient]);

  const handleNextPage = useCallback(() => {
    if (nextCursor) {
      setCursorHistory((prev) => [...prev, cursor || ""]);
      setCursor(nextCursor);
      setCurrentPage((p) => p + 1);
    }
  }, [nextCursor, cursor]);

  const handlePrevPage = useCallback(() => {
    if (cursorHistory.length > 0) {
      const newHistory = [...cursorHistory];
      const prevCursor = newHistory.pop();
      setCursorHistory(newHistory);
      setCursor(prevCursor === "" ? null : prevCursor || null);
      setCurrentPage((p) => Math.max(1, p - 1));
    }
  }, [cursorHistory]);

  const handleFirstPage = useCallback(() => {
    setCursor(null);
    setCursorHistory([]);
    setCurrentPage(1);
  }, []);

  const handleItemsPerPageChange = useCallback((value: string) => {
    setItemsPerPage(Number(value));
  }, []);

  useEffect(() => {
    startPerfLogging("PatientsPage");
  }, []);

  const patients = useMemo<Patient[]>(() => patientsData.map(mapPatientDocToView), [patientsData]);

  const savePatient = async (p: Patient) => {
    try {
      const isEdit = !!p.id;
      if (!clinicId) throw new Error("Sem clínica");
      if (isEdit) {
        await updatePatient({
          id: p.id as any,
          clinicId,
          name: p.name,
          phone: p.phone,
          email: p.email || undefined,
          cpf: p.cpf || undefined,
          dateOfBirth: p.dateOfBirth,
          gender: p.gender,
          address: p.address || undefined,
          city: p.city || undefined,
          state: p.state || undefined,
          zip: p.zip || undefined,
          country: p.country || undefined,
          externalId: p.externalId,
          notes: p.notes || undefined,
          tags: p.tags,
          status: p.status,
        });
      } else {
        await createPatient({
          clinicId,
          name: p.name,
          phone: p.phone,
          email: p.email || undefined,
          cpf: p.cpf || undefined,
          dateOfBirth: p.dateOfBirth,
          gender: p.gender,
          address: p.address || undefined,
          city: p.city || undefined,
          state: p.state || undefined,
          zip: p.zip || undefined,
          country: p.country || undefined,
          externalId: p.externalId,
          notes: p.notes || undefined,
          tags: p.tags,
          status: p.status,
        });
      }

      toast.success(isEdit ? "Paciente atualizado" : "Paciente criado");
      setAddOpen(false);
      setSelectedPatient(null);
    } catch (error: any) {
      const duplicatePatientId = error?.data?.patientId as string | undefined;
      if (error?.data?.code === "PATIENT_ALREADY_EXISTS" && duplicatePatientId) {
        const existingOnPage = patients.find((item) => item.id === duplicatePatientId) ?? null;
        if (existingOnPage) {
          setSelectedPatient(existingOnPage);
          setAddOpen(true);
        } else {
          setExistingPatientId(duplicatePatientId);
        }
        toast.warning("Paciente já existe");
        return;
      }
      toast.error(error.message || "Erro ao salvar paciente");
    }
  };

  const deletePatient = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este paciente?")) return;

    try {
      if (!clinicId) throw new Error("Sem clínica");
      await deletePatientMutation({ id: id as any, clinicId });

      toast.success("Paciente excluído");
    } catch {
      toast.error("Erro ao excluir paciente");
    }
  };

  const handleExportCSV = () => {
    const headers = [
      "Criado",
      "Atualizado",
      "Nome",
      "CPF",
      "Telefone",
      "Email",
      "Nascimento",
      "Gênero",
      "Endereço",
      "Cidade",
      "Estado",
      "CEP",
      "País",
      "Tags",
      "Notas",
      "ID Externo",
      "Status",
    ];
    const rows = patients.map((p) => [
      p.createdAt && !isNaN(new Date(p.createdAt).getTime())
        ? new Date(p.createdAt).toLocaleDateString()
        : "",
      p.updatedAt && !isNaN(new Date(p.updatedAt).getTime())
        ? new Date(p.updatedAt).toLocaleDateString()
        : "",
      p.name,
      p.cpf,
      p.phone,
      p.email,
      p.dateOfBirth,
      p.gender || "",
      p.address,
      p.city,
      p.state,
      p.zip,
      p.country,
      (p.tags || []).join("; "),
      p.notes,
      p.externalId,
      p.status,
    ]);
    const csv = [headers, ...rows]
      .map((r) => r.map((v) => `"${sanitizeCsvCell(v).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "pacientes.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const clearFilters = () => {
    setSearchTerm("");
    setStatusFilter("all");
    setHasEmail("any");
    setHasPhone("any");
    setDateRange(undefined);
    setLogic("and");
  };

  // Selection handlers
  const isAllSelected = patients.length > 0 && selectedPatients.size === patients.length;
  const isSomeSelected = selectedPatients.size > 0 && selectedPatients.size < patients.length;

  const handleSelectAll = useCallback(() => {
    if (isAllSelected) {
      setSelectedPatients(new Set());
      setShowBulkConfirm(false);
    } else {
      setShowBulkConfirm(true);
    }
  }, [isAllSelected]);

  const confirmSelectAll = useCallback(() => {
    const allIds = new Set(patients.map((p) => p.id).filter((id): id is string => !!id));
    setSelectedPatients(allIds);
    setShowBulkConfirm(false);
  }, [patients]);

  const handleSelectPatient = useCallback((patientId: string, checked: boolean) => {
    setSelectedPatients((prev) => {
      const next = new Set(prev);
      if (checked) {
        next.add(patientId);
      } else {
        next.delete(patientId);
      }
      return next;
    });
  }, []);

  const panelProps = {
    searchTerm,
    setSearchTerm,
    statusFilter,
    setStatusFilter,
    hasEmail,
    setHasEmail,
    hasPhone,
    setHasPhone,
    dateRange,
    setDateRange,
    logic,
    setLogic,
    onClearFilters: clearFilters,
    onAddPatient: () => {
      setSelectedPatient(null);
      setAddOpen(true);
    },
    onImportCSV: () => setImportOpen(true),
    onExportCSV: handleExportCSV,
    columns,
    setColumns,
    storageKey: `patients.columns.${role ?? "user"}.${clinicId ?? "clinic"}`,
  };

  return (
    <ErrorBoundary fallback={<div className="p-6">Falha ao carregar pacientes</div>}>
      <div className="flex flex-col gap-6 lg:flex-row lg:items-start">
        {/* Mobile Filter Button */}
        <div className="lg:hidden">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full">
                <SlidersHorizontal className="mr-2 h-4 w-4" />
                Filtros e Opções
              </Button>
            </DialogTrigger>
            <DialogContent className="p-0 max-h-[85vh] overflow-y-auto">
              <OptionsPanel {...panelProps} />
            </DialogContent>
          </Dialog>
        </div>

        {/* Left Column: Table */}
        <div className="flex-1 space-y-4">
          {/* Patient Action Bar */}
          <PatientActionbar
            selectedCount={selectedPatients.size}
            onClear={() => setSelectedPatients(new Set())}
            onQuickMessage={() => setBroadcastModalOpen(true)}
            onSendCampaign={() => setCampaignModalOpen(true)}
          />

          {/* Bulk selection confirmation */}
          {showBulkConfirm && (
            <div className="flex items-center gap-3 p-3 bg-muted rounded-md">
              <span className="text-sm">Selecionar todos os {patients.length} pacientes?</span>
              <Button size="sm" onClick={confirmSelectAll}>
                Confirmar
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setShowBulkConfirm(false)}>
                Cancelar
              </Button>
            </div>
          )}

          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">
                    <Checkbox
                      checked={isAllSelected}
                      ref={(el) => {
                        if (el) {
                          (el as HTMLButtonElement & { indeterminate: boolean }).indeterminate =
                            isSomeSelected;
                        }
                      }}
                      onCheckedChange={handleSelectAll}
                      aria-label="Selecionar todos"
                    />
                  </TableHead>
                  {columns.find((c) => c.id === "createdAt")?.visible && (
                    <TableHead
                      onClick={() => {
                        setSortBy("createdAt");
                        setOrder(order === "asc" ? "desc" : "asc");
                      }}
                      title="Data de criação"
                      className="cursor-pointer hover:bg-muted/50"
                    >
                      Criado
                    </TableHead>
                  )}
                  {columns.find((c) => c.id === "updatedAt")?.visible && (
                    <TableHead>Atualizado</TableHead>
                  )}
                  {columns.find((c) => c.id === "name")?.visible && <TableHead>Nome</TableHead>}
                  {columns.find((c) => c.id === "cpf")?.visible && <TableHead>CPF</TableHead>}
                  {columns.find((c) => c.id === "phone")?.visible && (
                    <TableHead title="Telefone principal">Telefone</TableHead>
                  )}
                  {columns.find((c) => c.id === "email")?.visible && (
                    <TableHead title="Email">Email</TableHead>
                  )}
                  {columns.find((c) => c.id === "dateOfBirth")?.visible && (
                    <TableHead title="Data de nascimento">Nascimento</TableHead>
                  )}
                  {columns.find((c) => c.id === "gender")?.visible && <TableHead>Gênero</TableHead>}
                  {columns.find((c) => c.id === "address")?.visible && (
                    <TableHead>Endereço</TableHead>
                  )}
                  {columns.find((c) => c.id === "city")?.visible && <TableHead>Cidade</TableHead>}
                  {columns.find((c) => c.id === "state")?.visible && <TableHead>UF</TableHead>}
                  {columns.find((c) => c.id === "zip")?.visible && <TableHead>CEP</TableHead>}
                  {columns.find((c) => c.id === "country")?.visible && <TableHead>País</TableHead>}
                  {columns.find((c) => c.id === "tags")?.visible && <TableHead>Tags</TableHead>}
                  {columns.find((c) => c.id === "notes")?.visible && <TableHead>Notas</TableHead>}
                  {columns.find((c) => c.id === "externalId")?.visible && (
                    <TableHead title="ID Externo">ID Externo</TableHead>
                  )}
                  {columns.find((c) => c.id === "status")?.visible && (
                    <TableHead
                      onClick={() => {
                        setSortBy("status");
                        setOrder(order === "asc" ? "desc" : "asc");
                      }}
                      title="Status do paciente"
                      className="cursor-pointer hover:bg-muted/50"
                    >
                      Status
                    </TableHead>
                  )}
                  {columns.find((c) => c.id === "actions")?.visible && <TableHead>Ações</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell
                      colSpan={columns.filter((c) => c.visible).length + 1}
                      className="text-center py-8"
                    >
                      Carregando...
                    </TableCell>
                  </TableRow>
                ) : (
                  patients.map((p) => (
                    <TableRow
                      key={p.id}
                      className={p.id && selectedPatients.has(p.id) ? "bg-primary/5" : ""}
                    >
                      <TableCell className="w-[50px]">
                        <Checkbox
                          checked={p.id ? selectedPatients.has(p.id) : false}
                          onCheckedChange={(checked) =>
                            p.id && handleSelectPatient(p.id, checked === true)
                          }
                          aria-label={`Selecionar ${p.name}`}
                        />
                      </TableCell>
                      {columns.find((c) => c.id === "createdAt")?.visible && (
                        <TableCell>
                          {p.createdAt ? new Date(p.createdAt).toLocaleDateString() : "-"}
                        </TableCell>
                      )}
                      {columns.find((c) => c.id === "updatedAt")?.visible && (
                        <TableCell>
                          {p.updatedAt ? new Date(p.updatedAt).toLocaleDateString() : "-"}
                        </TableCell>
                      )}
                      {columns.find((c) => c.id === "name")?.visible && (
                        <TableCell className="font-medium">{p.name}</TableCell>
                      )}
                      {columns.find((c) => c.id === "cpf")?.visible && (
                        <TableCell>{p.cpf || "-"}</TableCell>
                      )}
                      {columns.find((c) => c.id === "phone")?.visible && (
                        <TableCell>{p.phone}</TableCell>
                      )}
                      {columns.find((c) => c.id === "email")?.visible && (
                        <TableCell>{p.email || "-"}</TableCell>
                      )}
                      {columns.find((c) => c.id === "dateOfBirth")?.visible && (
                        <TableCell>{p.dateOfBirth || "-"}</TableCell>
                      )}
                      {columns.find((c) => c.id === "gender")?.visible && (
                        <TableCell>{p.gender || "-"}</TableCell>
                      )}
                      {columns.find((c) => c.id === "address")?.visible && (
                        <TableCell>{p.address || "-"}</TableCell>
                      )}
                      {columns.find((c) => c.id === "city")?.visible && (
                        <TableCell>{p.city || "-"}</TableCell>
                      )}
                      {columns.find((c) => c.id === "state")?.visible && (
                        <TableCell>{p.state || "-"}</TableCell>
                      )}
                      {columns.find((c) => c.id === "zip")?.visible && (
                        <TableCell>{p.zip || "-"}</TableCell>
                      )}
                      {columns.find((c) => c.id === "country")?.visible && (
                        <TableCell>{p.country || "-"}</TableCell>
                      )}
                      {columns.find((c) => c.id === "tags")?.visible && (
                        <TableCell>{p.tags?.join(", ") || "-"}</TableCell>
                      )}
                      {columns.find((c) => c.id === "notes")?.visible && (
                        <TableCell className="max-w-[200px] truncate" title={p.notes}>
                          {p.notes || "-"}
                        </TableCell>
                      )}
                      {columns.find((c) => c.id === "externalId")?.visible && (
                        <TableCell>{p.externalId || "-"}</TableCell>
                      )}
                      {columns.find((c) => c.id === "status")?.visible && (
                        <TableCell>
                          <span
                            className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${p.status === "active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}`}
                          >
                            {p.status === "active" ? "Ativo" : "Inativo"}
                          </span>
                        </TableCell>
                      )}
                      {columns.find((c) => c.id === "actions")?.visible && (
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreVertical size={16} />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem
                                onClick={() => {
                                  setSelectedPatient(p);
                                  setAddOpen(true);
                                }}
                              >
                                <Edit size={14} className="mr-2" /> Editar
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => {
                                  setHistoryPatient(p);
                                  setHistoryOpen(true);
                                }}
                              >
                                <Eye size={14} className="mr-2" /> Ver Histórico
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="text-destructive focus:text-destructive"
                                onClick={() => p.id && deletePatient(p.id)}
                              >
                                <Trash2 size={14} className="mr-2" /> Excluir
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      )}
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>

            {!loading && patients.length === 0 && (
              <div className="py-12 text-center text-muted-foreground">
                Nenhum paciente encontrado
              </div>
            )}
          </Card>

          {/* Pagination Controls */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 py-2">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleFirstPage}
                disabled={currentPage === 1}
              >
                Primeira
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handlePrevPage}
                disabled={cursorHistory.length === 0}
              >
                Anterior
              </Button>
              <Button variant="outline" size="sm" onClick={handleNextPage} disabled={!nextCursor}>
                Próxima
              </Button>
            </div>

            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>
                Mostrando {patients.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0}-
                {(currentPage - 1) * itemsPerPage + patients.length}
              </span>

              <div className="flex items-center gap-2">
                <span>Por página:</span>
                <Select value={String(itemsPerPage)} onValueChange={handleItemsPerPageChange}>
                  <SelectTrigger className="w-[80px] h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PAGE_SIZE_OPTIONS.map((size) => (
                      <SelectItem key={size} value={String(size)}>
                        {size}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: OptionsPanel (Desktop) */}
        <aside className="hidden w-full lg:block lg:w-80 lg:sticky lg:top-0 lg:self-start lg:h-fit">
          <OptionsPanel {...panelProps} />
        </aside>
      </div>

      <AddPatientModal
        open={addOpen}
        onOpenChange={(o) => {
          if (!o) setSelectedPatient(null);
          setAddOpen(o);
        }}
        patient={selectedPatient}
        onSave={savePatient}
      />
      <BulkImportModal
        open={importOpen}
        onOpenChange={setImportOpen}
        onSuccess={() => {
          toast.success("Importação concluída");
        }}
      />
      <PatientHistorySheet
        open={historyOpen}
        onOpenChange={(o) => {
          if (!o) setHistoryPatient(null);
          setHistoryOpen(o);
        }}
        patient={historyPatient}
        clinicId={clinicId ?? ""}
      />
      <BroadcastMessageModal
        open={broadcastModalOpen}
        onOpenChange={setBroadcastModalOpen}
        clinicId={clinicId}
        patientIds={Array.from(selectedPatients)}
        patientCount={selectedPatients.size}
        onSuccess={() => setSelectedPatients(new Set())}
      />
      <SendCampaignModal
        open={campaignModalOpen}
        onOpenChange={setCampaignModalOpen}
        clinicId={clinicId}
        patientIds={Array.from(selectedPatients)}
        patientCount={selectedPatients.size}
        onSuccess={() => setSelectedPatients(new Set())}
      />
    </ErrorBoundary>
  );
}
