import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation } from "convex/react";
import { Plus, Pencil, Trash2, ClipboardList } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { FormBuilder, type FormData } from "@/components/forms/FormBuilder";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useClinicId } from "@/hooks/patients";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

export const Route = createFileRoute("/forms")({
  component: FormsPage,
});

function FormsPage() {
  const { clinicId } = useClinicId();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedForm, setSelectedForm] = useState<any>(null);
  const [isSaving, setIsSaving] = useState(false);

  const forms = useQuery(api.forms.list, { clinicId: clinicId || "" });
  const createForm = useMutation(api.forms.create);
  const updateForm = useMutation(api.forms.update);
  const deleteForm = useMutation(api.forms.deleteForm);

  const handleSave = async (data: FormData) => {
    if (!clinicId) return;
    setIsSaving(true);
    try {
      if (selectedForm) {
        await updateForm({
          id: selectedForm._id,
          title: data.title,
          description: data.description,
          questions: data.questions,
        });
        toast.success("Formulário atualizado com sucesso!");
      } else {
        await createForm({
          clinicId,
          title: data.title,
          description: data.description,
          type: data.type,
          questions: data.questions,
        });
        toast.success("Formulário criado com sucesso!");
      }
      setIsCreateOpen(false);
      setSelectedForm(null);
    } catch (error) {
      console.error(error);
      toast.error("Erro ao salvar formulário.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: any) => {
    if (!confirm("Tem certeza que deseja excluir este formulário?")) return;
    try {
      await deleteForm({ id });
      toast.success("Formulário excluído.");
    } catch {
      toast.error("Erro ao excluir formulário.");
    }
  };

  const openEdit = (form: any) => {
    setSelectedForm(form);
    setIsCreateOpen(true);
  };

  const openCreate = () => {
    setSelectedForm(null);
    setIsCreateOpen(true);
  };

  if (!clinicId) return <div>Carregando...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Formulários</h1>
          <p className="text-muted-foreground">
            Gerencie anamneses, pós-operatórios e outros formulários.
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="mr-2 h-4 w-4" />
          Novo Formulário
        </Button>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Meus Formulários</CardTitle>
            <CardDescription>Lista de todos os formulários ativos na clínica.</CardDescription>
          </CardHeader>
          <CardContent>
            {forms === undefined ? (
              <div className="text-center py-4">Carregando...</div>
            ) : forms.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <ClipboardList className="mx-auto h-12 w-12 opacity-50 mb-4" />
                <p>Nenhum formulário encontrado.</p>
                <Button variant="link" onClick={openCreate}>
                  Criar o primeiro formulário
                </Button>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Título</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Perguntas</TableHead>
                    <TableHead>Criado em</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {forms.map((form: any) => (
                    <TableRow key={form._id}>
                      <TableCell className="font-medium">{form.title}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">
                          {form.type === "anamnesis"
                            ? "Anamnese"
                            : form.type === "post_op"
                              ? "Pós-Operatório"
                              : "Retorno"}
                        </Badge>
                      </TableCell>
                      <TableCell>{form.questions.length}</TableCell>
                      <TableCell>{new Date(form.createdAt).toLocaleDateString()}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" onClick={() => openEdit(form)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-destructive hover:text-destructive"
                            onClick={() => handleDelete(form._id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog
        open={isCreateOpen}
        onOpenChange={(open) => {
          if (!open) setSelectedForm(null);
          setIsCreateOpen(open);
        }}
      >
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedForm ? "Editar Formulário" : "Novo Formulário"}</DialogTitle>
            <DialogDescription>Configure as perguntas e opções do formulário.</DialogDescription>
          </DialogHeader>
          <FormBuilder
            initialData={selectedForm || undefined}
            onSave={handleSave}
            onCancel={() => setIsCreateOpen(false)}
            isSaving={isSaving}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
