import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useAction } from "convex/react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  Search,
  Send,
  Paperclip,
  MoreVertical,
  CheckCheck,
  Smile,
  User,
  Calendar,
  AlertCircle,
  AlertTriangle,
  CreditCard,
  MessageSquareHeart,
  Cloud,
  Plus,
  Smartphone,
  Bot,
  Filter,
  X,
  ClipboardCheck,
} from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { toast } from "sonner";

import { PatientProfileModal } from "@/components/PatientProfileModal";
import { RescheduleAppointmentModal } from "@/components/RescheduleAppointmentModal";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Switch } from "@/components/ui/switch";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { MediaMessage } from "@/components/whatsapp/MediaMessage";
import { useEffectiveCurrentUser } from "@/hooks/patients";
import { cn } from "@/lib/utils";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

import type { Id } from "@whatsmed-app/backend/convex/_generated/dataModel";

export const Route = createFileRoute("/whatsapp")({
  component: WhatsAppInboxPage,
});

// Tag Input Component
function TagInput({ onAddTag }: { onAddTag: (tag: string) => void }) {
  const [tagInput, setTagInput] = useState("");

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && tagInput.trim()) {
      e.preventDefault();
      onAddTag(tagInput.trim());
      setTagInput("");
    }
  };

  return (
    <Input
      value={tagInput}
      onChange={(e) => setTagInput(e.target.value)}
      onKeyDown={handleKeyDown}
      placeholder="Digite e pressione Enter..."
      className="h-8 text-xs"
    />
  );
}

function ResponsibleBadge({ name, compact = false }: { name?: string; compact?: boolean }) {
  if (!name) {
    return null;
  }

  return (
    <Badge
      variant="outline"
      className={cn(
        "max-w-full border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-800 dark:bg-blue-950/40 dark:text-blue-200",
        compact ? "h-5 px-1.5 text-[10px]" : "h-5 px-2 text-[10px]",
      )}
    >
      <span className="truncate">{compact ? name : `Atend.: ${name}`}</span>
    </Badge>
  );
}

// Format phone number from WhatsApp ID (e.g., "5511999999999@s.whatsapp.net" -> "+55 (11) 99999-9999")
function formatPhoneNumber(whatsappId: string): string {
  // Remove @s.whatsapp.net suffix
  const phone = whatsappId.replace("@s.whatsapp.net", "").replace(/\D/g, "");

  // Brazilian format: +55 (XX) XXXXX-XXXX or +55 (XX) XXXX-XXXX
  if (phone.startsWith("55") && phone.length >= 12) {
    const countryCode = phone.slice(0, 2);
    const areaCode = phone.slice(2, 4);
    const rest = phone.slice(4);

    if (rest.length === 9) {
      // Mobile: 9 digits
      return `+${countryCode} (${areaCode}) ${rest.slice(0, 5)}-${rest.slice(5)}`;
    } else if (rest.length === 8) {
      // Landline: 8 digits
      return `+${countryCode} (${areaCode}) ${rest.slice(0, 4)}-${rest.slice(4)}`;
    }
  }

  // Fallback: just add + prefix if it looks like a number
  if (phone.length > 0) {
    return `+${phone}`;
  }

  return whatsappId;
}

function parseAttendantPrefixedMessage(body?: string) {
  if (!body) {
    return null;
  }

  const match = body.match(/^\*([^*\n]+)\*\n([\s\S]+)$/);
  if (!match) {
    return null;
  }

  return {
    attendantName: match[1],
    content: match[2],
  };
}

function formatChatPreview(body?: string) {
  const parsed = parseAttendantPrefixedMessage(body);
  if (!parsed) {
    return body;
  }

  return `${parsed.attendantName}: ${parsed.content}`;
}

function WhatsAppInboxPage() {
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [rescheduleModalOpen, setRescheduleModalOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [filterDrawerOpen, setFilterDrawerOpen] = useState(false);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState<"open" | "resolved" | undefined>(undefined);
  const [aiModeFilter, setAiModeFilter] = useState<"active" | "inactive" | "all">("all");
  const [needsReviewFilter, setNeedsReviewFilter] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const getOrCreateChat = useMutation(api.whatsappQueries.getOrCreateChat);
  const updateChatTags = useMutation(api.whatsappQueries.updateChatTags);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchTerm);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Fetch patients if searching
  const searchedPatients =
    useQuery(
      api.whatsappQueries.searchPatients,
      debouncedSearch && debouncedSearch.length > 2
        ? { search: debouncedSearch, limit: 5 }
        : "skip",
    ) || [];

  const handlePatientClick = async (patient: any) => {
    if (!patient.phone) {
      toast.error("Paciente sem telefone cadastrado");
      return;
    }
    try {
      const chatId = await getOrCreateChat({
        patientId: patient._id,
        phone: patient.phone,
        patientName: patient.name,
      });
      setSelectedChatId(chatId);
      setSearchTerm("");
    } catch (error) {
      toast.error("Erro ao iniciar conversa: " + error);
    }
  };

  // Ensure user exists in app's users table (handles users who signed up before trigger existed)
  const ensureUser = useMutation(api.integrations.ensureUser);
  useEffect(() => {
    ensureUser().catch(console.error);
  }, [ensureUser]);

  const instance = useQuery(api.integrations.getWhatsAppInstance);
  const currentUser = useEffectiveCurrentUser();
  const globalAiSettings = useQuery(
    api.automation.getAiSettings,
    currentUser?.clinicId ? { clinicId: currentUser.clinicId } : "skip",
  );
  const globalAiEnabled = globalAiSettings?.enabled !== false;
  const fetchStatus = useAction(api.integrations.fetchInstanceStatus);
  const switchProvider = useMutation(api.integrations.switchWhatsAppProvider);

  // Sync status on load
  useEffect(() => {
    if (instance) {
      fetchStatus().catch(console.error);
    }
  }, [instance?._id, instance?.status]);

  const chats = useQuery(api.whatsappQueries.listChats, {
    search: debouncedSearch,
    tags: selectedTags.length > 0 ? selectedTags : undefined,
    status: statusFilter,
    aiMode: aiModeFilter,
    needsReview: needsReviewFilter || undefined,
  });

  const uniqueTags = useQuery(api.whatsappQueries.getUniqueChatTags);

  const messages = useQuery(
    api.whatsappQueries.getChatMessages,
    selectedChatId ? { chatId: selectedChatId as any } : "skip",
  );

  useEffect(() => {
    if (messages) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const sendMessage = useMutation(api.whatsappQueries.sendMessage);
  const triggerDataCollection = useAction(api.checkin.triggerDataCollection);
  const sendCheckinLink = useAction(api.checkin.sendCheckinLink);
  const sendNpsSurvey = useAction(api.nps.sendNpsSurveyManual);
  const markAsRead = useMutation(api.whatsappQueries.markAsRead);
  const toggleAiMode = useMutation(api.whatsappQueries.toggleAiMode);
  const unraiseChat = useMutation(api.whatsappQueries.unraiseChat);

  const selectedChat = chats?.find((c: any) => c._id === selectedChatId);
  const canOpenManualReschedule = Boolean(selectedChat?.patientId && selectedChat?.clinicId);

  const hasUpcomingAppointment = useQuery(
    api.checkin.getPatientHasUpcomingAppointment,
    selectedChat?.patientId && selectedChat?.clinicId
      ? { clinicId: selectedChat.clinicId, patientId: selectedChat.patientId as Id<"patients"> }
      : "skip",
  );

  // Auto-select first chat if none selected and chats loaded
  useEffect(() => {
    if (!selectedChatId && chats && chats.length > 0) {
      setSelectedChatId(chats[0]._id);
    }
  }, [chats, selectedChatId]);

  // Mark as read when chat is selected
  useEffect(() => {
    if (selectedChatId) {
      markAsRead({ chatId: selectedChatId as any });
    }
  }, [selectedChatId, messages?.length]); // Re-mark when new messages arrive if chat is open

  const handleTriggerData = async (type: "id_card" | "insurance_card" | "referral") => {
    if (!selectedChat?.patientId) {
      toast.error("Paciente não identificado nesta conversa");
      return;
    }

    try {
      await triggerDataCollection({
        patientId: selectedChat.patientId,
        clinicId: selectedChat.clinicId,
        type,
      });
      toast.success("Solicitação enviada com sucesso!");
    } catch (error) {
      console.error(error);
      toast.error("Erro ao enviar solicitação");
    }
  };

  const handleSendMessage = async () => {
    if (!message.trim() || !selectedChatId) return;

    try {
      await sendMessage({
        chatId: selectedChatId as any,
        text: message,
      });
      setMessage("");
    } catch (error) {
      console.error("Failed to send message:", error);
      toast.error("Erro ao enviar mensagem");
    }
  };

  const handleSendNPS = async () => {
    if (!selectedChat || !selectedChat?.patientId || !selectedChat?.clinicId) {
      toast.error("Selecione um paciente para enviar a pesquisa NPS");
      return;
    }

    try {
      await sendNpsSurvey({
        patientId: selectedChat.patientId,
        clinicId: selectedChat.clinicId,
      });
      toast.success("Pesquisa NPS enviada com sucesso!");
    } catch (error: any) {
      console.error("Failed to send NPS survey:", error);
      toast.error(`Erro ao enviar pesquisa: ${error.message || error}`);
    }
  };

  const handleSendCheckinLink = async () => {
    if (!selectedChat || !selectedChat?.patientId || !selectedChat?.clinicId) {
      toast.error("Selecione um paciente para enviar o link de check-in");
      return;
    }

    try {
      await sendCheckinLink({
        patientId: selectedChat.patientId,
        clinicId: selectedChat.clinicId,
      });
      toast.success("Link de check-in enviado com sucesso!");
    } catch (error: any) {
      console.error("Failed to send check-in link:", error);
      toast.error(`Erro ao enviar link: ${error.message || error}`);
    }
  };

  const handleToggleProvider = async (checked: boolean) => {
    const newProvider = checked ? "meta" : "evolution";
    try {
      await switchProvider({ provider: newProvider });
      toast.success(
        `Modo API alterado para: ${checked ? "Oficial (Meta)" : "Unofficial (Evolution)"}`,
      );
    } catch (error) {
      toast.error("Erro ao alterar modo API: " + error);
    }
  };

  if (instance === undefined) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-3.5rem)]">
        <div className="text-sm text-muted-foreground">Carregando WhatsApp...</div>
      </div>
    );
  }

  if (!instance || instance.status !== "connected") {
    // If provider is Meta (Phantom), it might show as disconnected but we allow it if we consider Phantom "always on" or checking health.
    // For now, if Meta is selected, we assume it's "connected" for UI purposes if config exists.
    // But since fetchStatus updates it, we rely on DB status.
    // Let's modify this check: If connected OR (provider is meta and config exists - phantom logic)
    const isMetaConfigured = instance?.provider === "meta" && instance?.hasMetaAccessToken;

    if (!isMetaConfigured && (!instance || instance.status !== "connected")) {
      return (
        <div className="flex flex-col items-center justify-center h-[calc(100vh-3.5rem)] gap-4">
          <div className="bg-muted/20 p-8 rounded-full">
            <AlertCircle size={48} className="text-muted-foreground" />
          </div>
          <h2 className="text-xl font-semibold">WhatsApp não conectado</h2>
          <p className="text-muted-foreground text-center max-w-md">
            Para acessar o inbox, você precisa conectar sua conta do WhatsApp Business na página de
            integrações.
          </p>
          <Link to="/integrations">
            <Button>Ir para Integrações</Button>
          </Link>
        </div>
      );
    }
  }

  const isMetaMode = instance.provider === "meta";

  return (
    <div className="-m-6 flex h-[calc(100vh-3.5rem)] overflow-hidden bg-background">
      {/* Sidebar */}
      <div className="w-80 flex-shrink-0 border-r bg-muted/10 flex flex-col overflow-hidden">
        <div className="p-3 bg-background border-b flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <Avatar className="h-9 w-9 cursor-pointer hover:opacity-80 transition-opacity">
              <AvatarFallback className="bg-primary/10 text-primary text-xs">EU</AvatarFallback>
            </Avatar>
          </div>

          {/* API Mode Toggle */}
          <div className="flex items-center gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-2 bg-muted/50 p-1.5 rounded-full border">
                    <Switch
                      checked={isMetaMode}
                      onCheckedChange={handleToggleProvider}
                      className="scale-75 data-[state=checked]:bg-blue-600"
                    />
                    {isMetaMode ? (
                      <Cloud className="h-4 w-4 text-blue-600" />
                    ) : (
                      <Smartphone className="h-4 w-4 text-green-600" />
                    )}
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>
                    {isMetaMode
                      ? "Modo Oficial (Meta Cloud API)"
                      : "Modo Unofficial (Evolution API)"}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {isMetaMode
                      ? "Mais estável. Requer templates após 24h."
                      : "Mais flexível. Usa QR Code."}
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <Sheet open={filterDrawerOpen} onOpenChange={setFilterDrawerOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full">
                  <Filter className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80 sm:w-96">
                <SheetHeader>
                  <SheetTitle>Filtros</SheetTitle>
                  <SheetDescription>
                    Filtre as conversas por tags, status e modo IA
                  </SheetDescription>
                </SheetHeader>
                <div className="mt-6 space-y-6 px-4 pb-4">
                  {/* Tags Filter */}
                  <div className="space-y-3">
                    <Label className="text-sm font-medium">Tags</Label>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {uniqueTags && uniqueTags.length > 0 ? (
                        uniqueTags.map((tag: any) => (
                          <div key={tag} className="flex items-center space-x-2">
                            <Checkbox
                              id={`tag-${tag}`}
                              checked={selectedTags.includes(tag)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setSelectedTags([...selectedTags, tag]);
                                } else {
                                  setSelectedTags(selectedTags.filter((t: any) => t !== tag));
                                }
                              }}
                            />
                            <Label
                              htmlFor={`tag-${tag}`}
                              className="text-sm font-normal cursor-pointer"
                            >
                              {tag}
                            </Label>
                          </div>
                        ))
                      ) : (
                        <p className="text-sm text-muted-foreground">Nenhuma tag disponível</p>
                      )}
                    </div>
                  </div>

                  <Separator />

                  {/* Status Filter */}
                  <div className="space-y-3">
                    <Label className="text-sm font-medium">Status</Label>
                    <RadioGroup
                      value={statusFilter || "all"}
                      onValueChange={(value) =>
                        setStatusFilter(
                          value === "all" ? undefined : (value as "open" | "resolved"),
                        )
                      }
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="all" id="status-all" />
                        <Label htmlFor="status-all" className="text-sm font-normal cursor-pointer">
                          Todos
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="open" id="status-open" />
                        <Label htmlFor="status-open" className="text-sm font-normal cursor-pointer">
                          Abertos
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="resolved" id="status-resolved" />
                        <Label
                          htmlFor="status-resolved"
                          className="text-sm font-normal cursor-pointer"
                        >
                          Resolvidos
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <Separator />

                  {/* AI Mode Filter */}
                  <div className="space-y-3">
                    <Label className="text-sm font-medium">Modo IA</Label>
                    <RadioGroup
                      value={aiModeFilter}
                      onValueChange={(value) =>
                        setAiModeFilter(value as "active" | "inactive" | "all")
                      }
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="all" id="ai-all" />
                        <Label htmlFor="ai-all" className="text-sm font-normal cursor-pointer">
                          Todos
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="active" id="ai-active" />
                        <Label htmlFor="ai-active" className="text-sm font-normal cursor-pointer">
                          IA Ativa
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="inactive" id="ai-inactive" />
                        <Label htmlFor="ai-inactive" className="text-sm font-normal cursor-pointer">
                          Modo Humano
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <Separator />

                  {/* Needs Review Filter */}
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="needs-review"
                      checked={needsReviewFilter}
                      onCheckedChange={(checked) => setNeedsReviewFilter(checked === true)}
                    />
                    <Label htmlFor="needs-review" className="text-sm font-normal cursor-pointer">
                      Apenas com revisão pendente
                    </Label>
                  </div>

                  <Separator />

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        setSelectedTags([]);
                        setStatusFilter(undefined);
                        setAiModeFilter("all");
                        setNeedsReviewFilter(false);
                      }}
                    >
                      Limpar Filtros
                    </Button>
                    <Button className="flex-1" onClick={() => setFilterDrawerOpen(false)}>
                      Aplicar
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        <div className="p-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Pesquisar ou começar nova conversa"
              className="pl-9 bg-muted/50 border-none focus-visible:ring-1 h-9 text-sm"
            />
          </div>
        </div>

        <ScrollArea className="flex-1 min-h-0">
          <div className="flex flex-col">
            {/* Patients Search Results */}
            {searchedPatients.length > 0 && (
              <>
                <div className="px-4 py-2 text-xs font-semibold text-muted-foreground bg-muted/20">
                  PACIENTES ENCONTRADOS
                </div>
                {searchedPatients.map((patient: any) => (
                  <button
                    key={patient._id}
                    onClick={() => handlePatientClick(patient)}
                    className="flex items-center gap-3 px-3 py-3 hover:bg-muted/50 transition-colors text-left w-full border-b border-border/40"
                  >
                    <Avatar className="h-12 w-12">
                      <AvatarFallback className="bg-blue-100 text-blue-700 font-medium">
                        {patient.name?.substring(0, 2).toUpperCase() || "??"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0 grid gap-1">
                      <span className="font-semibold text-sm truncate">{patient.name}</span>
                      <span className="text-xs text-muted-foreground truncate">
                        {patient.phone}
                      </span>
                    </div>
                    <Plus className="h-4 w-4 text-muted-foreground" />
                  </button>
                ))}
                <div className="px-4 py-2 text-xs font-semibold text-muted-foreground bg-muted/20">
                  CONVERSAS RECENTES
                </div>
              </>
            )}

            {chats?.map((chat: any, _index: any) => {
              return (
                <button
                  key={chat._id}
                  onClick={() => setSelectedChatId(chat._id)}
                  className={cn(
                    "flex items-center gap-3 px-3 py-3 hover:bg-muted/50 transition-colors text-left w-full border-b border-border/40 last:border-0",
                    selectedChatId === chat._id && "bg-muted",
                  )}
                >
                  <div className="relative">
                    <Avatar className="h-12 w-12">
                      {chat.avatarUrl && (
                        <AvatarImage src={chat.avatarUrl} alt={chat.title || ""} />
                      )}
                      <AvatarFallback className="bg-primary/10 text-primary font-medium">
                        {chat.title?.substring(0, 2).toUpperCase() || "??"}
                      </AvatarFallback>
                    </Avatar>
                    {chat.online && (
                      <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-500 border-2 border-background" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0 grid gap-1">
                    <div className="flex justify-between items-baseline gap-2">
                      <div className="flex items-center gap-1.5 min-w-0 flex-1">
                        <div className="flex min-w-0 flex-1 items-center gap-1.5">
                          <span className="font-semibold text-sm truncate">
                            {chat.title || chat.whatsappChatId}
                          </span>
                          <div className="min-w-0 flex-shrink">
                            <ResponsibleBadge name={chat.responsibleUserName} compact />
                          </div>
                        </div>
                        {/* AI/Manual Mode Indicator */}
                        {chat.isAiActive !== false ? (
                          <Bot className="h-3.5 w-3.5 text-green-600 flex-shrink-0" />
                        ) : (
                          <User className="h-3.5 w-3.5 text-blue-600 flex-shrink-0" />
                        )}
                        {/* Escalation Warning Indicator */}
                        {chat.needsHumanReview && (
                          <AlertTriangle className="h-3.5 w-3.5 text-amber-500 flex-shrink-0 animate-pulse" />
                        )}
                      </div>
                      <span
                        className={cn(
                          "text-[10px] whitespace-nowrap flex-shrink-0",
                          chat.unreadCount > 0
                            ? "text-primary font-medium"
                            : "text-muted-foreground",
                        )}
                      >
                        {chat.lastMessageAt
                          ? format(chat.lastMessageAt, "HH:mm", { locale: ptBR })
                          : ""}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-muted-foreground truncate pr-2">
                        {formatChatPreview(chat.lastMessage) || "Clique para ver mensagens..."}
                      </span>
                      {chat.unreadCount > 0 && (
                        <Badge
                          variant="default"
                          className="h-5 min-w-5 px-1.5 flex items-center justify-center rounded-full text-[10px] bg-green-500 hover:bg-green-600 border-none"
                        >
                          {chat.unreadCount}
                        </Badge>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </ScrollArea>
      </div>

      {/* Main Chat Area */}
      {selectedChat ? (
        <div className="flex-1 flex flex-col bg-[url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png')] bg-repeat bg-fixed">
          {/* Chat Header */}
          <div className="h-16 px-4 py-2 border-b bg-background flex items-center justify-between shadow-sm z-10">
            <div className="flex items-center gap-3 cursor-pointer hover:bg-muted/50 p-1.5 rounded-lg transition-colors">
              <Avatar>
                {selectedChat.avatarUrl && (
                  <AvatarImage src={selectedChat.avatarUrl} alt={selectedChat.title || ""} />
                )}
                <AvatarFallback className="bg-primary/10 text-primary font-bold">
                  {selectedChat.title?.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-sm">{selectedChat.title}</span>
                  <ResponsibleBadge name={selectedChat.responsibleUserName} />
                </div>
                <span className="text-xs text-muted-foreground truncate">
                  {selectedChat.online ? "Online agora" : ""}
                </span>
                {selectedChat.needsHumanReview && (
                  <span className="text-[11px] text-amber-600 truncate">
                    Escalado para humano
                    {selectedChat.escalationReason ? ` - ${selectedChat.escalationReason}` : ""}
                  </span>
                )}
              </div>
            </div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <Badge variant={globalAiEnabled ? "default" : "secondary"} className="mr-2">
                IA Global {globalAiEnabled ? "Ativa" : "Desativada"}
              </Badge>
              {/* AI Toggle */}
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="flex items-center gap-2 bg-muted/50 p-1.5 rounded-full border mr-2">
                      <Switch
                        disabled={!globalAiEnabled}
                        checked={selectedChat.isAiActive !== false}
                        onCheckedChange={async (checked) => {
                          if (!globalAiEnabled) {
                            toast.error("A IA global está desativada na aba Automação");
                            return;
                          }
                          try {
                            await toggleAiMode({ chatId: selectedChat._id, isAiActive: checked });
                            toast.success(checked ? "IA ativada para esta conversa" : "IA pausada");
                          } catch {
                            toast.error("Não foi possível alterar o modo da IA");
                          }
                        }}
                        className="scale-75 data-[state=checked]:bg-green-600"
                      />
                      {selectedChat.isAiActive !== false ? (
                        <Bot className="h-4 w-4 text-green-600" />
                      ) : (
                        <User className="h-4 w-4 text-blue-600" />
                      )}
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>
                      {selectedChat.isAiActive !== false ? "Modo IA Ativo" : "Modo Humano Ativo"}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {selectedChat.isAiActive !== false
                        ? "A IA responderá automaticamente."
                        : "A IA está pausada. Você responde."}
                    </p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              {(selectedChat.isAiActive === false || selectedChat.needsHumanReview === true) && (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        className="mr-2"
                        onClick={async () => {
                          try {
                            await unraiseChat({ chatId: selectedChat._id });
                            toast.success("Conversa voltou para a IA");
                          } catch {
                            toast.error("Erro ao desfazer escalação");
                          }
                        }}
                      >
                        Voltar para IA
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Desfazer escalação e ativar respostas da IA neste chat</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}

              <Separator orientation="vertical" className="h-6 mx-1" />
              <Button variant="ghost" size="icon">
                <Search className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon">
                <MoreVertical className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {selectedChat && (
            <div className="border-b bg-background px-4 py-3 lg:hidden">
              <div className="flex gap-2 overflow-x-auto">
                <Button
                  variant="outline"
                  size="sm"
                  className="shrink-0"
                  disabled={!selectedChat.patientId}
                  onClick={() => setProfileModalOpen(true)}
                >
                  <User className="h-4 w-4 mr-2" /> Ver Perfil
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="shrink-0"
                  disabled={!canOpenManualReschedule}
                  onClick={() => setRescheduleModalOpen(true)}
                >
                  <Calendar className="h-4 w-4 mr-2" /> Reagendar Consulta
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="shrink-0"
                  disabled={!selectedChat.patientId || hasUpcomingAppointment === false}
                  onClick={handleSendCheckinLink}
                >
                  <ClipboardCheck className="h-4 w-4 mr-2" /> Enviar Check-in
                </Button>
              </div>
              {!selectedChat.patientId && (
                <p className="mt-2 text-xs text-muted-foreground">
                  Vincule o contato a um paciente para reagendar manualmente.
                </p>
              )}
            </div>
          )}

          {/* Messages */}
          <div className="flex-1 overflow-hidden relative">
            <div className="absolute inset-0 bg-background/90 backdrop-blur-[1px]" />
            <ScrollArea className="h-full p-4 md:p-8 relative z-10">
              <div className="space-y-6">
                {messages?.map((msg: any) => (
                  <div
                    key={msg._id}
                    className={cn(
                      "flex w-full mb-2",
                      msg.direction === "out" ? "justify-end" : "justify-start",
                    )}
                  >
                    <div
                      className={cn(
                        "relative max-w-[70%] sm:max-w-[60%] px-3 py-2 text-sm shadow-sm rounded-lg",
                        msg.direction === "out"
                          ? "bg-[#dcf8c6] dark:bg-primary/20 text-foreground rounded-tr-none"
                          : "bg-white dark:bg-muted text-foreground rounded-tl-none border border-border/50",
                      )}
                    >
                      {/* Quoted Message */}
                      {msg.replyToText && (
                        <div
                          className={cn(
                            "mb-2 rounded-md p-2 text-xs border-l-4 overflow-hidden cursor-pointer opacity-90",
                            msg.direction === "out"
                              ? "bg-black/5 dark:bg-black/20 border-green-600"
                              : "bg-black/5 dark:bg-white/10 border-primary",
                          )}
                        >
                          <div className="font-semibold text-primary/80 mb-0.5">
                            {msg.replyToSender ? "Resposta" : "Mensagem respondida"}
                          </div>
                          <div className="line-clamp-2 text-foreground/80">{msg.replyToText}</div>
                        </div>
                      )}

                      {/* Media or Text Message */}
                      {msg.type === "media" || msg.mediaType || msg.mediaStorageId ? (
                        <div className="pb-1">
                          <MediaMessage message={msg} />
                        </div>
                      ) : (
                        (() => {
                          const parsedMessage =
                            msg.direction === "out" && msg.authorUserId
                              ? parseAttendantPrefixedMessage(msg.body)
                              : null;

                          return parsedMessage ? (
                            <div className="pb-1 pr-6">
                              <p className="font-semibold leading-relaxed break-words">
                                {parsedMessage.attendantName}
                              </p>
                              <p className="leading-relaxed break-words">{parsedMessage.content}</p>
                            </div>
                          ) : (
                            <p className="leading-relaxed break-words pb-1 pr-6">{msg.body}</p>
                          );
                        })()
                      )}
                      <div
                        className={cn(
                          "flex items-center justify-end gap-1 text-[10px] mt-1",
                          "text-muted-foreground",
                        )}
                      >
                        {msg.direction === "in" && msg.provider === "meta" && (
                          <Cloud className="h-2.5 w-2.5 opacity-60" />
                        )}
                        {msg.direction === "in" &&
                          (msg.provider === "evolution" || !msg.provider) && (
                            <Smartphone className="h-2.5 w-2.5 opacity-60" />
                          )}
                        <span>{format(msg.sentAt, "HH:mm")}</span>
                        {msg.direction === "out" && (
                          <span
                            className={cn(
                              msg.status === "read" ? "text-blue-500" : "text-muted-foreground",
                            )}
                          >
                            <CheckCheck className="h-3 w-3" />
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>
          </div>

          {/* Input Area */}
          <div className="p-3 bg-background border-t">
            <div className="flex items-end gap-2 max-w-4xl mx-auto">
              <Button
                variant="ghost"
                size="icon"
                className="text-muted-foreground shrink-0 rounded-full"
              >
                <Smile className="h-6 w-6" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="text-muted-foreground shrink-0 rounded-full"
              >
                <Paperclip className="h-6 w-6" />
              </Button>
              <div className="flex-1 bg-muted rounded-2xl flex items-center px-4 py-2 gap-2 min-h-[44px]">
                <Input
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={
                    isMetaMode ? "Digite uma mensagem (Modo Simulação)" : "Digite uma mensagem"
                  }
                  className="flex-1 bg-transparent border-none shadow-none focus-visible:ring-0 p-0 text-sm placeholder:text-muted-foreground h-auto max-h-32 overflow-y-auto"
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                />
              </div>
              <Button
                onClick={handleSendMessage}
                size="icon"
                className={cn(
                  "rounded-full h-11 w-11 shadow-sm shrink-0",
                  isMetaMode && "bg-blue-600 hover:bg-blue-700",
                )}
                disabled={!message.trim()}
              >
                <Send className="h-5 w-5 ml-0.5" />
              </Button>
            </div>
            {isMetaMode && (
              <div className="text-center mt-1">
                <span className="text-[10px] text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                  Modo Phantom Ativo - Mensagens não serão enviadas realmente
                </span>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="flex-1 hidden md:flex flex-col items-center justify-center bg-muted/30 border-b-8 border-green-500 box-border">
          <div className="text-center space-y-4 p-8">
            <div className="inline-flex h-24 w-24 items-center justify-center rounded-full bg-muted">
              <Smile className="h-10 w-10 text-muted-foreground" />
            </div>
            <h2 className="text-2xl font-light text-foreground">WhatsApp Web</h2>
            <p className="text-muted-foreground text-sm max-w-sm">
              Envie e receba mensagens sem precisar manter seu celular conectado.
            </p>
          </div>
        </div>
      )}

      {/* Right Info Panel */}
      {selectedChat && (
        <div className="w-80 border-l bg-background hidden lg:flex flex-col h-full overflow-hidden">
          <div className="h-16 border-b flex items-center px-6">
            <span className="font-medium">Dados do contato</span>
          </div>
          <ScrollArea className="flex-1">
            <div className="flex flex-col items-center py-8 pb-4">
              <Avatar className="h-32 w-32 mb-4 ring-4 ring-muted">
                {selectedChat.avatarUrl && (
                  <AvatarImage src={selectedChat.avatarUrl} alt={selectedChat.title || ""} />
                )}
                <AvatarFallback className="bg-primary/10 text-primary text-4xl font-light">
                  {selectedChat.title?.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <h3 className="text-lg font-medium">{selectedChat.title}</h3>
              <ResponsibleBadge name={selectedChat.responsibleUserName} />
              <p className="text-muted-foreground text-sm">
                {formatPhoneNumber(selectedChat.whatsappChatId)}
              </p>

              {/* Tags Section */}
              <div className="w-full px-4 mt-4 space-y-2">
                <Label className="text-xs font-medium text-muted-foreground">Tags</Label>
                <div className="flex flex-wrap gap-2 min-h-[2rem]">
                  {selectedChat.tags && selectedChat.tags.length > 0 ? (
                    selectedChat.tags.map((tag: any) => (
                      <Badge key={tag} variant="secondary" className="flex items-center gap-1 pr-1">
                        {tag}
                        <button
                          onClick={async () => {
                            const newTags = (selectedChat.tags || []).filter((t: any) => t !== tag);
                            try {
                              await updateChatTags({
                                chatId: selectedChat._id,
                                tags: newTags,
                              });
                              toast.success("Tag removida");
                            } catch {
                              toast.error("Erro ao remover tag");
                            }
                          }}
                          className="ml-1 hover:text-destructive transition-colors"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))
                  ) : (
                    <p className="text-xs text-muted-foreground">Nenhuma tag</p>
                  )}
                </div>
                <TagInput
                  onAddTag={async (tag) => {
                    const currentTags = selectedChat.tags || [];
                    if (currentTags.includes(tag)) {
                      toast.error("Tag já existe");
                      return;
                    }
                    const newTags = [...currentTags, tag];
                    try {
                      await updateChatTags({
                        chatId: selectedChat._id,
                        tags: newTags,
                      });
                      toast.success("Tag adicionada");
                    } catch {
                      toast.error("Erro ao adicionar tag");
                    }
                  }}
                />
              </div>
            </div>

            <Separator />

            <div className="p-4 space-y-4">
              <div>
                <h4 className="text-xs font-medium text-muted-foreground uppercase mb-2">
                  Dados Prévios (IA)
                </h4>
                <div className="space-y-2">
                  <Button
                    variant="outline"
                    className="w-full justify-start text-xs h-8"
                    onClick={() => handleTriggerData("insurance_card")}
                  >
                    <CreditCard className="w-3 h-3 mr-2" /> Solicitar Carteirinha
                  </Button>
                </div>
              </div>
            </div>

            <Separator />

            <div className="p-2 space-y-2">
              <Button
                variant="outline"
                className="w-full justify-start gap-2"
                disabled={!selectedChat?.patientId}
                onClick={() => setProfileModalOpen(true)}
              >
                <User className="h-4 w-4" /> Ver Perfil Completo
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start gap-2"
                disabled={!canOpenManualReschedule}
                onClick={() => setRescheduleModalOpen(true)}
              >
                <Calendar className="h-4 w-4" /> Reagendar Consulta
              </Button>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className="w-full">
                      <Button
                        variant="outline"
                        className="w-full justify-start gap-2"
                        disabled={!selectedChat?.patientId || hasUpcomingAppointment === false}
                        onClick={handleSendCheckinLink}
                      >
                        <ClipboardCheck className="h-4 w-4" /> Enviar Link de Check-in
                      </Button>
                    </span>
                  </TooltipTrigger>
                  {hasUpcomingAppointment === false && (
                    <TooltipContent side="left">
                      <p>Paciente sem consulta agendada.</p>
                      <p className="text-xs text-muted-foreground">Agende uma consulta primeiro.</p>
                    </TooltipContent>
                  )}
                </Tooltip>
              </TooltipProvider>
              <Button
                variant="outline"
                className="w-full justify-start gap-2"
                onClick={handleSendNPS}
              >
                <MessageSquareHeart className="h-4 w-4" /> Enviar Pesquisa NPS
              </Button>
            </div>
          </ScrollArea>
        </div>
      )}

      {/* Patient Profile Modal */}
      {selectedChat?.patientId && selectedChat?.clinicId && (
        <PatientProfileModal
          open={profileModalOpen}
          onOpenChange={setProfileModalOpen}
          patientId={selectedChat.patientId as Id<"patients">}
          clinicId={selectedChat.clinicId}
        />
      )}

      {/* Reschedule Modal */}
      {selectedChat?.patientId && selectedChat?.clinicId && (
        <RescheduleAppointmentModal
          open={rescheduleModalOpen}
          onOpenChange={setRescheduleModalOpen}
          patientId={selectedChat.patientId as Id<"patients">}
          clinicId={selectedChat.clinicId}
          patientName={selectedChat.title}
        />
      )}
    </div>
  );
}
