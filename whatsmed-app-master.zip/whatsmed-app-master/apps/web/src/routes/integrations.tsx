import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useAction } from "convex/react";
import { MessageSquare, Network, Database, Settings as SettingsIcon, Calendar } from "lucide-react";
import { useState, useEffect } from "react";

import { APIKeyModal } from "@/components/integrations/APIKeyModal";
import { GoogleConnectModal } from "@/components/integrations/GoogleConnectModal";
import { WebhookModal } from "@/components/integrations/WebhookModal";
import { WhatsAppConnectModal } from "@/components/integrations/WhatsAppConnectModal";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

export const Route = createFileRoute("/integrations")({ component: IntegrationsPage });

interface Integration {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  status: "active" | "inactive" | "connecting";
}

function IntegrationsPage() {
  const [showAPIKeyModal, setShowAPIKeyModal] = useState(false);
  const [showWebhookModal, setShowWebhookModal] = useState(false);
  const [showWhatsAppModal, setShowWhatsAppModal] = useState(false);
  const [showGoogleModal, setShowGoogleModal] = useState(false);

  // Ensure user exists in app's users table (handles users who signed up before trigger existed)
  const ensureUser = useMutation(api.integrations.ensureUser);
  useEffect(() => {
    ensureUser().catch(console.error);
  }, [ensureUser]);

  // Fetch WhatsApp instance status
  const whatsappInstance = useQuery(api.integrations.getWhatsAppInstance);
  const fetchStatus = useAction(api.integrations.fetchInstanceStatus);

  // Fetch Google Calendar connection status
  const googleTokens = useQuery(api.googleCalendar.getTokens);

  // Sync status on load
  useEffect(() => {
    if (whatsappInstance) {
      fetchStatus().catch(console.error);
    }
  }, [whatsappInstance?._id, whatsappInstance?.status]);

  const whatsappStatus =
    whatsappInstance?.status === "connected"
      ? "active"
      : whatsappInstance?.status === "connecting"
        ? "connecting"
        : "inactive";

  const googleStatus = googleTokens?.connected ? "active" : "inactive";

  const integrations: Integration[] = [
    {
      id: "whatsapp",
      name: "WhatsApp Business",
      description: "Conecte sua conta do WhatsApp Business para enviar e receber mensagens",
      icon: MessageSquare,
      status: whatsappStatus as any,
    },
    {
      id: "erp",
      name: "ERP Personalizado",
      description: "Conecte seu sistema ERP existente via API",
      icon: Database,
      status: "inactive",
    },
    {
      id: "webhooks",
      name: "Webhooks",
      description: "Configure webhooks para receber eventos em tempo real",
      icon: Network,
      status: "inactive",
    },
    {
      id: "google",
      name: "Google Calendar",
      description:
        "Conecte sua conta do Google para criar reuniões do Google Meet automaticamente em teleconsultas",
      icon: Calendar,
      status: googleStatus as any,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-medium tracking-tight">Integrações</h3>
          <p className="text-muted-foreground">Conecte serviços externos e gerencie suas APIs</p>
        </div>
        <Button onClick={() => setShowAPIKeyModal(true)}>Gerenciar API Keys</Button>
      </div>

      {/* Integration Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {integrations.map((integration) => {
          const Icon = integration.icon;
          return (
            <Card key={integration.id}>
              <CardContent className="p-6">
                {/* Icon and Status */}
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-primary/10 flex items-center justify-center rounded-md">
                    <Icon size={24} className="text-primary" />
                  </div>
                  <Badge
                    variant={integration.status === "active" ? "default" : "secondary"}
                    className={
                      integration.status === "active"
                        ? "bg-green-100 text-green-700 hover:bg-green-100 dark:bg-green-900/30 dark:text-green-400"
                        : integration.status === "connecting"
                          ? "bg-yellow-100 text-yellow-700 hover:bg-yellow-100"
                          : ""
                    }
                  >
                    {integration.status === "active"
                      ? "Ativa"
                      : integration.status === "connecting"
                        ? "Conectando"
                        : "Não Conectada"}
                  </Badge>
                </div>

                {/* Content */}
                <h4 className="font-semibold mb-2">{integration.name}</h4>
                <p className="text-sm text-muted-foreground mb-6 min-h-[40px]">
                  {integration.description}
                </p>

                {/* Action Button */}
                <Button
                  variant={integration.status === "active" ? "outline" : "default"}
                  className="w-full gap-2"
                  onClick={() => {
                    if (integration.id === "webhooks") {
                      setShowWebhookModal(true);
                    } else if (integration.id === "whatsapp") {
                      setShowWhatsAppModal(true);
                    } else if (integration.id === "google") {
                      setShowGoogleModal(true);
                    }
                  }}
                >
                  <SettingsIcon size={16} />
                  {integration.status === "active" ? "Gerenciar" : "Conectar"}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Info Section */}
      <Card>
        <CardContent className="p-6">
          <h4 className="font-medium mb-3">Sobre Integrações</h4>
          <div className="space-y-2 text-sm text-muted-foreground">
            <p>
              • As integrações permitem que você conecte o WhatsMed a outros sistemas e serviços
            </p>
            <p>
              • Cada integração pode ter suas próprias configurações e requisitos de autenticação
            </p>
            <p>• Você pode gerenciar API keys e webhooks através dos botões de configuração</p>
            <p>
              • Para suporte técnico com integrações, consulte nossa{" "}
              <a href="#" className="text-primary hover:underline">
                documentação
              </a>
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Modals */}
      <APIKeyModal open={showAPIKeyModal} onOpenChange={setShowAPIKeyModal} />
      <WebhookModal open={showWebhookModal} onOpenChange={setShowWebhookModal} />
      <WhatsAppConnectModal open={showWhatsAppModal} onOpenChange={setShowWhatsAppModal} />
      <GoogleConnectModal open={showGoogleModal} onOpenChange={setShowGoogleModal} />
    </div>
  );
}
