import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useAction } from "convex/react";
import { format, subDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  Calendar as CalendarIcon,
  WifiOff,
  TrendingDown,
  AlertTriangle,
  Users,
  CalendarCheck,
  MessageSquare,
  QrCode,
  Star,
} from "lucide-react";
import { useState, useEffect } from "react";
import { type DateRange } from "react-day-picker";

import { FunnelChart360 } from "@/components/charts/FunnelChart360";
import { CreateAppointmentModal } from "@/components/CreateAppointmentModal";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useEffectiveCurrentUser } from "@/hooks/patients";
import { cn } from "@/lib/utils";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

export const Route = createFileRoute("/dashboard")({
  component: DashboardContent,
});

interface FunnelStep {
  name: string;
  value: number;
  fill: string;
}

function DashboardContent() {
  const user = useEffectiveCurrentUser();

  // Appointment modal state
  const [appointmentModalOpen, setAppointmentModalOpen] = useState(false);

  // 1. Date Range Picker State
  const [date, setDate] = useState<DateRange | undefined>({
    from: subDays(new Date(), 29),
    to: new Date(),
  });

  // Normalize dates to day boundaries for consistent querying
  const normalizedPeriod = date?.from
    ? {
        periodStart: new Date(
          date.from.getFullYear(),
          date.from.getMonth(),
          date.from.getDate(),
          0,
          0,
          0,
          0,
        ).getTime(),
        periodEnd: date.to
          ? new Date(
              date.to.getFullYear(),
              date.to.getMonth(),
              date.to.getDate(),
              23,
              59,
              59,
              999,
            ).getTime()
          : new Date(
              date.from.getFullYear(),
              date.from.getMonth(),
              date.from.getDate(),
              23,
              59,
              59,
              999,
            ).getTime(),
      }
    : null;

  const clinicId = user?.clinicId;
  const clinicMetricsArgs =
    clinicId && normalizedPeriod
      ? {
          clinicId,
          periodStart: normalizedPeriod.periodStart,
          periodEnd: normalizedPeriod.periodEnd,
        }
      : "skip";

  // 2. Fetch funnel metrics if user is authenticated and date range is selected
  const funnelMetrics = useQuery(api.analytics.getFunnelMetrics, clinicMetricsArgs);

  // Fetch dashboard metrics
  const dashboardMetrics = useQuery(api.analytics.getDashboardMetrics, clinicMetricsArgs);

  // Fetch NPS data
  const npsData = useQuery(
    api.nps.calculateNpsScore,
    normalizedPeriod
      ? {
          startDate: normalizedPeriod.periodStart,
          endDate: normalizedPeriod.periodEnd,
        }
      : "skip",
  );

  const npsResponses = useQuery(
    api.nps.getNpsResponses,
    normalizedPeriod
      ? {
          startDate: normalizedPeriod.periodStart,
          endDate: normalizedPeriod.periodEnd,
        }
      : "skip",
  );

  // Transform funnel metrics to chart data
  const funnelData: FunnelStep[] | undefined = funnelMetrics
    ? [
        { name: "Enviados", value: funnelMetrics.sent, fill: "#3b82f6" }, // Blue-500
        { name: "Engajados (IA)", value: funnelMetrics.engaged, fill: "#8b5cf6" }, // Violet-500
        { name: "Confirmados", value: funnelMetrics.confirmed, fill: "#22c55e" }, // Green-500
        { name: "Compareceram", value: funnelMetrics.arrived, fill: "#15803d" }, // Green-700
      ]
    : undefined;

  // 2. System Health Alert Logic
  const instance = useQuery(api.integrations.getWhatsAppInstance);
  const fetchStatus = useAction(api.integrations.fetchInstanceStatus);

  // Sync status on load
  useEffect(() => {
    if (instance) {
      fetchStatus().catch(console.error);
    }
  }, [instance?._id, instance?.status]);

  const isMetaConfigured = instance?.provider === "meta" && instance?.hasMetaAccessToken;
  // Show alert only if instance exists (user attempted setup) but is not connected
  // For Meta, we assume connected if configured (Phantom mode)
  // Also check if status is not "connecting" to avoid false alarms during connection
  const isDisconnected =
    instance &&
    !isMetaConfigured &&
    instance.status !== "connected" &&
    instance.status !== "connecting";

  // 3. Metric Widgets Data
  const efficiency = {
    value: dashboardMetrics ? `${Math.round(dashboardMetrics.confirmationRate)}%` : "-",
  };
  const performance = {
    value: dashboardMetrics ? `${Math.round(dashboardMetrics.cancellationRate)}%` : "-",
  }; // Lower cancellation is better
  const workload = {
    value: dashboardMetrics ? String(dashboardMetrics.manualInterventions) : "-",
  }; // Lower manual intervention is better
  const waitlist = {
    value: dashboardMetrics ? String(dashboardMetrics.waitlistCount) : "-",
  }; // Waitlist size

  // NPS Zone Logic
  const getNpsZone = (score: number, totalResponses: number) => {
    if (totalResponses === 0) return { text: "Sem dados", variant: "outline" as const };
    if (score >= 70) return { text: "Zona de Qualidade", variant: "default" as const };
    if (score >= 50) return { text: "Zona de Melhoria", variant: "secondary" as const };
    return { text: "Zona Crítica", variant: "destructive" as const };
  };

  const npsScore = npsData?.score ?? 0;
  const npsTotalResponses = npsData?.totalResponses ?? 0;
  const npsZone = getNpsZone(npsScore, npsTotalResponses);

  // Get latest reviews (first 5)
  const latestReviews = npsResponses?.slice(0, 5) || [];

  return (
    <div className="space-y-6 container mx-auto p-6 max-w-7xl">
      {/* Header Area with Date Picker */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">Visão geral da performance da sua clínica</p>
        </div>

        {/* 1. Date Range Picker */}
        <Popover>
          <PopoverTrigger asChild>
            <Button
              id="date"
              variant={"outline"}
              className={cn(
                "w-fit justify-start text-left font-normal",
                !date && "text-muted-foreground",
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {date?.from ? (
                date.to ? (
                  <>
                    {format(date.from, "dd/MM/yyyy")} - {format(date.to, "dd/MM/yyyy")}
                  </>
                ) : (
                  format(date.from, "dd/MM/yyyy")
                )
              ) : (
                <span>Selecione uma data</span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="end">
            <div className="flex flex-col sm:flex-row">
              <div className="p-3 border-b sm:border-b-0 sm:border-r space-y-2 flex flex-col">
                <span className="text-sm font-medium text-muted-foreground mb-1">Período</span>
                <Button
                  variant="ghost"
                  className="justify-start font-normal"
                  onClick={() => setDate({ from: new Date(), to: new Date() })}
                >
                  Hoje (1 dia)
                </Button>
                <Button
                  variant="ghost"
                  className="justify-start font-normal"
                  onClick={() => setDate({ from: subDays(new Date(), 6), to: new Date() })}
                >
                  Últimos 7 dias
                </Button>
                <Button
                  variant="ghost"
                  className="justify-start font-normal"
                  onClick={() => setDate({ from: subDays(new Date(), 29), to: new Date() })}
                >
                  Últimos 30 dias
                </Button>
                <Button
                  variant="ghost"
                  className="justify-start font-normal"
                  onClick={() => setDate({ from: subDays(new Date(), 359), to: new Date() })}
                >
                  Últimos 360 dias
                </Button>
              </div>
              <Calendar
                initialFocus
                mode="range"
                defaultMonth={date?.from}
                selected={date}
                onSelect={setDate}
                numberOfMonths={2}
                locale={ptBR}
              />
            </div>
          </PopoverContent>
        </Popover>
      </div>

      {/* 2. System Health Alert (Conditional) */}
      {isDisconnected && (
        <Alert
          variant="destructive"
          className="bg-red-50 dark:bg-red-900/10 border-red-200 dark:border-red-900"
        >
          <WifiOff className="h-4 w-4" />
          <AlertTitle>WhatsApp Desconectado</AlertTitle>
          <AlertDescription className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <span>Mensagens não estão sendo enviadas. Clique para reconectar.</span>
            <Link to="/integrations" className="font-bold underline whitespace-nowrap">
              Reconectar Número
            </Link>
          </AlertDescription>
        </Alert>
      )}

      {/* 3. Metric Widgets (Row 1) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Widget A: Efficiency */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase">
              TAXA DE CONFIRMAÇÃO
            </CardTitle>
            <CalendarCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{efficiency.value}</div>
          </CardContent>
        </Card>

        {/* Widget B: Performance */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase">
              TAXA DE CANCELAMENTO
            </CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{performance.value}</div>
          </CardContent>
        </Card>

        {/* Widget C: Workload */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase">
              INTERVENÇÃO MANUAL
            </CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{workload.value}</div>
          </CardContent>
        </Card>

        {/* Widget D: Waitlist (New) */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase">
              FILA DE ESPERA
            </CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{waitlist.value}</div>
          </CardContent>
        </Card>
      </div>

      {/* 4. Charts (Row 2) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* WhatsApp Conversion Funnel 360 */}
        <Card>
          <CardHeader>
            <CardTitle>Funil de Conversão 360º</CardTitle>
            <CardDescription>Jornada do paciente desde o envio até a presença</CardDescription>
          </CardHeader>
          <CardContent>
            <FunnelChart360 data={funnelData} />
          </CardContent>
        </Card>

        {/* NPS Score and Reviews */}
        <Card>
          <CardHeader>
            <CardTitle>NPS e Avaliações</CardTitle>
            <CardDescription>Score NPS atual e últimas avaliações</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* NPS Score Display */}
            <div className="flex flex-col items-center justify-center py-4">
              {npsData === undefined ? (
                <div className="text-5xl font-bold text-muted-foreground mb-2">...</div>
              ) : (
                <>
                  <div className="text-5xl font-bold text-primary mb-2">{npsScore}</div>
                  <Badge
                    variant={npsZone.variant}
                    className={
                      npsZone.variant === "destructive"
                        ? "text-red-600 bg-red-50 border-red-200 dark:text-red-400 dark:bg-red-900/20 dark:border-red-900"
                        : npsZone.variant === "secondary"
                          ? "text-yellow-600 bg-yellow-50 border-yellow-200 dark:text-yellow-400 dark:bg-yellow-900/20 dark:border-yellow-900"
                          : npsZone.variant === "outline"
                            ? "text-muted-foreground"
                            : "text-green-600 bg-green-50 border-green-200 dark:text-green-400 dark:bg-green-900/20 dark:border-green-900"
                    }
                  >
                    {npsZone.text}
                  </Badge>
                </>
              )}
            </div>

            {/* Distribution Bar */}
            {npsData && npsData.totalResponses > 0 && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Distribuição</span>
                  <span>{npsData.totalResponses} respostas</span>
                </div>
                <div className="flex h-2 rounded-full overflow-hidden bg-muted">
                  <div
                    className="bg-green-600"
                    style={{ width: `${npsData.promoterPercentage}%` }}
                  />
                  <div
                    className="bg-yellow-600"
                    style={{
                      width: `${100 - npsData.promoterPercentage - npsData.detractorPercentage}%`,
                    }}
                  />
                  <div
                    className="bg-red-600"
                    style={{ width: `${npsData.detractorPercentage}%` }}
                  />
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span className="text-green-600">
                    {npsData.promoters} Promotores ({npsData.promoterPercentage}%)
                  </span>
                  <span className="text-yellow-600">
                    {npsData.passives} Passivos (
                    {100 - npsData.promoterPercentage - npsData.detractorPercentage}%)
                  </span>
                  <span className="text-red-600">
                    {npsData.detractors} Detratores ({npsData.detractorPercentage}%)
                  </span>
                </div>
              </div>
            )}

            {/* Latest Reviews */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium">Últimas Avaliações</h4>
              {npsResponses === undefined ? (
                <div className="text-sm text-muted-foreground text-center py-4">Carregando...</div>
              ) : latestReviews.length === 0 ? (
                <div className="text-sm text-muted-foreground text-center py-4">
                  Nenhuma avaliação registrada
                </div>
              ) : (
                <div className="space-y-3 max-h-[200px] overflow-y-auto">
                  {latestReviews.map((review: any) => {
                    const firstName = review.patientName?.split(" ")[0] || "Paciente";
                    const truncatedFeedback =
                      review.feedback && review.feedback.length > 60
                        ? `${review.feedback.substring(0, 60)}...`
                        : review.feedback || "Sem comentário";
                    return (
                      <div key={review._id} className="p-3 rounded-lg border bg-muted/30 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{firstName}</span>
                          <div className="flex items-center gap-1">
                            <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                            <span className="text-sm font-semibold">{review.score}/10</span>
                          </div>
                        </div>
                        {truncatedFeedback && (
                          <p className="text-xs text-muted-foreground line-clamp-2">
                            {truncatedFeedback}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 5. Quick Actions (New) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div onClick={() => setAppointmentModalOpen(true)} className="block">
          <Card className="hover:bg-muted/50 transition-colors cursor-pointer h-full">
            <CardContent className="p-6 flex flex-col items-center text-center gap-3">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                <CalendarCheck size={24} />
              </div>
              <div>
                <h3 className="font-semibold">Agendar Consulta</h3>
                <p className="text-sm text-muted-foreground">Novo agendamento ou encaixe</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Link to="/whatsapp" className="block">
          <Card className="hover:bg-muted/50 transition-colors cursor-pointer h-full">
            <CardContent className="p-6 flex flex-col items-center text-center gap-3">
              <div className="w-12 h-12 rounded-full bg-green-100 text-green-700 flex items-center justify-center">
                <MessageSquare size={24} />
              </div>
              <div>
                <h3 className="font-semibold">Atendimentos</h3>
                <p className="text-sm text-muted-foreground">Ver mensagens não lidas</p>
              </div>
            </CardContent>
          </Card>
        </Link>

        <Link to="/totem" className="block">
          <Card className="hover:bg-muted/50 transition-colors cursor-pointer h-full">
            <CardContent className="p-6 flex flex-col items-center text-center gap-3">
              <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center">
                <QrCode size={24} />
              </div>
              <div>
                <h3 className="font-semibold">Totem de Check-in</h3>
                <p className="text-sm text-muted-foreground">Abrir QR Code da recepção</p>
              </div>
            </CardContent>
          </Card>
        </Link>

        {/* Placeholder for future action */}
        <Card className="hover:bg-muted/50 transition-colors cursor-pointer h-full opacity-60">
          <CardContent className="p-6 flex flex-col items-center text-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gray-100 text-gray-500 flex items-center justify-center">
              <Users size={24} />
            </div>
            <div>
              <h3 className="font-semibold">Gerenciar Equipe</h3>
              <p className="text-sm text-muted-foreground">Em breve</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Appointment Modal */}
      <CreateAppointmentModal open={appointmentModalOpen} onOpenChange={setAppointmentModalOpen} />
    </div>
  );
}
