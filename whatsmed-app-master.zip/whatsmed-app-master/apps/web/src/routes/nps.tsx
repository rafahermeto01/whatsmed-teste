import { createFileRoute } from "@tanstack/react-router";
import { MessageSquareHeart } from "lucide-react";

import { NPSSurveyConfig } from "@/components/nps/NPSSurveyConfig";

export const Route = createFileRoute("/nps")({
  component: NPSPage,
});

function NPSPage() {
  return (
    <div className="container mx-auto p-6 max-w-5xl space-y-8">
      <div className="flex items-center gap-3">
        <div className="p-3 bg-primary/10 rounded-lg">
          <MessageSquareHeart className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">NPS & Avaliações</h1>
          <p className="text-muted-foreground">
            Gerencie a satisfação dos pacientes e sua reputação online.
          </p>
        </div>
      </div>

      <NPSSurveyConfig />
    </div>
  );
}
