import { zodResolver } from "@hookform/resolvers/zod";
import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useMutation } from "convex/react";
import { Loader2, Building2 } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { isValidCpfCnpj, normalizeCpfCnpj } from "@/lib/brazilian-documents";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

export const Route = createFileRoute("/create-clinic")({
  component: CreateClinicPage,
});

const createClinicSchema = z.object({
  name: z.string().min(3, "O nome deve ter pelo menos 3 caracteres"),
  cpfCnpj: z.string().refine((value) => isValidCpfCnpj(value), "CPF/CNPJ inválido"),
  phone: z.string().optional(),
  address: z.string().optional(),
});

type CreateClinicFormValues = z.infer<typeof createClinicSchema>;

function CreateClinicPage() {
  const router = useRouter();
  const createOwnClinic = useMutation(api.clinics.createOwnClinic);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<CreateClinicFormValues>({
    resolver: zodResolver(createClinicSchema as any),
    defaultValues: {
      name: "",
      cpfCnpj: "",
      phone: "",
      address: "",
    },
  });

  const onSubmit = async (data: CreateClinicFormValues) => {
    setIsSubmitting(true);
    try {
      await createOwnClinic({
        name: data.name,
        cpfCnpj: normalizeCpfCnpj(data.cpfCnpj),
        phone: data.phone || undefined,
        address: data.address || undefined,
      });

      toast.success("Clínica criada com sucesso!");

      // Navigate to dashboard - the context should update automatically
      // because the backend mutation switches the user's active clinic
      router.navigate({ to: "/dashboard" });
    } catch (error) {
      console.error("Error creating clinic:", error);
      toast.error("Erro ao criar clínica. Tente novamente.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50/50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mx-auto mb-4">
            <Building2 size={24} />
          </div>
          <CardTitle className="text-2xl">Criar Nova Clínica</CardTitle>
          <CardDescription>
            Preencha os dados abaixo para começar a gerenciar sua clínica
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nome da Clínica</FormLabel>
                    <FormControl>
                      <Input placeholder="Ex: Clínica Saúde Total" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="cpfCnpj"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>CPF ou CNPJ</FormLabel>
                    <FormControl>
                      <Input placeholder="00.000.000/0000-00" {...field} />
                    </FormControl>
                    <FormDescription>Documento fiscal para faturamento</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Telefone (Opcional)</FormLabel>
                    <FormControl>
                      <Input placeholder="(00) 00000-0000" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Endereço (Opcional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Rua, Número, Bairro" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Criando...
                  </>
                ) : (
                  "Criar Clínica"
                )}
              </Button>
            </form>
          </Form>
        </CardContent>
        <CardFooter className="flex justify-center border-t p-4 mt-2">
          <Button
            variant="link"
            className="text-muted-foreground text-sm"
            onClick={() => router.history.go(-1)}
          >
            Voltar
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
