import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Upload, Users, FileText, LogOut, Settings, Moon, Sun, FileCheck } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

import { AuditLogs } from "@/components/AuditLogs";
import { DocumentUploader } from "@/components/DocumentUploader";
import { ProceduresSettings } from "@/components/settings/ProceduresSettings";
import { WorkingHoursSettings } from "@/components/settings/WorkingHoursSettings";
import { AutoSaveIndicator } from "@/components/ui/auto-save-indicator";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserManagement } from "@/components/UserManagement";
import { useClinic, useUpsertClinic } from "@/hooks/clinics";
import { useClinicSettings, useUpdateWhatsAppSettings } from "@/hooks/clinicSettings";
import { useClinicId, usePermissions } from "@/hooks/patients";
import { useAutoSave } from "@/hooks/useAutoSave";
import { authClient } from "@/lib/auth-client";
import { isValidCpfCnpj, normalizeCpfCnpj } from "@/lib/brazilian-documents";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  const navigate = useNavigate();
  const { clinicId, role } = useClinicId();
  const {
    canAccessSettings,
    canManageClinicSettings,
    canManageClinicUsers,
    canManageClinicDocuments,
    canViewAuditLogs,
    canManageOwnDoctorSettings,
  } = usePermissions();
  const clinic = useClinic(clinicId);
  const { settings: clinicSettings } = useClinicSettings(clinicId);
  const upsertClinic = useUpsertClinic();
  const updateWhatsAppSettings = useUpdateWhatsAppSettings();

  const [clinicData, setClinicData] = useState({
    name: "",
    cpfCnpj: "",
    address: "",
    phone: "",
    website: "",
    email: "",
  });
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [isDark, setIsDark] = useState(false);
  const [isUpdatingWhatsAppSettings, setIsUpdatingWhatsAppSettings] = useState(false);
  // Track if user has made changes (dirty flag)
  const [isDirty, setIsDirty] = useState(false);

  // Load clinic data when fetched
  useEffect(() => {
    if (clinic) {
      setClinicData({
        name: clinic.name || "",
        cpfCnpj: clinic.cpfCnpj || "",
        address: clinic.address || "",
        phone: clinic.phone || "",
        website: clinic.website || "",
        email: clinic.email || "",
      });
      setLogoUrl(clinic.logoUrl || null);
      // Reset dirty flag when server data loads
      setIsDirty(false);
    }
  }, [clinic]);

  useEffect(() => {
    setIsDark(document.documentElement.classList.contains("dark"));
  }, []);

  const toggleTheme = (checked: boolean) => {
    setIsDark(checked);
    if (checked) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setIsDirty(true);
    setClinicData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setIsDirty(true);
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Memoize the data object for autosave to avoid unnecessary re-renders
  const clinicSaveData = useMemo(() => ({ ...clinicData, logoUrl }), [clinicData, logoUrl]);

  // Autosave callback
  const handleClinicSave = useCallback(
    async (data: typeof clinicSaveData) => {
      if (!clinicId) return;

      await upsertClinic({
        clinicId,
        name: data.name,
        cpfCnpj: data.cpfCnpj ? normalizeCpfCnpj(data.cpfCnpj) : undefined,
        email: data.email || undefined,
        phone: data.phone || undefined,
        address: data.address || undefined,
        website: data.website || undefined,
        logoUrl: data.logoUrl || undefined,
      });
    },
    [clinicId, upsertClinic],
  );

  // Autosave hook for clinic settings - only enabled when user has made changes
  const { status: clinicSaveStatus, error: clinicSaveError } = useAutoSave({
    data: clinicSaveData,
    onSave: async (data) => {
      await handleClinicSave(data);
      // Reset dirty flag after successful save
      setIsDirty(false);
    },
    validate: (data) =>
      !!data.name && !!clinicId && (!data.cpfCnpj || isValidCpfCnpj(data.cpfCnpj)),
    enabled: !!clinicId && !!clinic && isDirty,
    debounceMs: 800,
  });

  const handleLogout = async () => {
    await authClient.signOut();
    navigate({ to: "/login", search: { redirect: "/" } });
  };

  // CPF/CNPJ is editable only if not already saved
  const cpfCnpjLocked = !!clinic?.cpfCnpj;
  const cpfCnpjIsValid = !clinicData.cpfCnpj || isValidCpfCnpj(clinicData.cpfCnpj);
  const canManageWhatsAppSettings = role === "admin" || role === "super_admin";
  const prependAttendantNameOnManualMessages =
    clinicSettings?.prependAttendantNameOnManualMessages === true;
  const defaultTab = canManageClinicSettings ? "clinic" : "preferences";

  if (!canAccessSettings) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Acesso restrito</CardTitle>
          <CardDescription>
            Seu perfil nao possui acesso as configuracoes deste workspace.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue={defaultTab} className="space-y-6">
        <TabsList className="bg-muted p-1 rounded-[var(--radius)]">
          {canManageClinicSettings && (
            <TabsTrigger value="clinic" className="px-4 py-2">
              Configurações da Clínica
            </TabsTrigger>
          )}
          {canManageClinicUsers && (
            <TabsTrigger value="users" className="px-4 py-2 flex items-center gap-2">
              <Users size={16} /> Usuários
            </TabsTrigger>
          )}
          {canManageClinicDocuments && (
            <TabsTrigger value="documents" className="px-4 py-2 flex items-center gap-2">
              <FileCheck size={16} /> Documentos
            </TabsTrigger>
          )}
          {canViewAuditLogs && (
            <TabsTrigger value="audit" className="px-4 py-2 flex items-center gap-2">
              <FileText size={16} /> Logs de Auditoria
            </TabsTrigger>
          )}
          <TabsTrigger value="preferences" className="px-4 py-2 flex items-center gap-2">
            <Settings size={16} /> Preferências
          </TabsTrigger>
        </TabsList>

        {canManageClinicSettings && (
          <TabsContent value="clinic">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-foreground font-medium text-lg">Informações da Clínica</h3>
                  <AutoSaveIndicator status={clinicSaveStatus} error={clinicSaveError} />
                </div>

                {/* Logo Upload */}
                <div className="mb-8">
                  <Label className="block mb-3">Logo da Clínica</Label>
                  <div className="flex items-center gap-6">
                    <div
                      className="relative w-24 h-24 rounded-full bg-muted flex items-center justify-center overflow-hidden group cursor-pointer"
                      onClick={() => document.getElementById("logoUpload")?.click()}
                    >
                      {logoUrl ? (
                        <img src={logoUrl} alt="Logo" className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-muted-foreground text-2xl">WM</span>
                      )}
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Upload size={24} className="text-white" />
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-foreground mb-1">
                        Clique na imagem para fazer upload
                      </p>
                      <p className="text-xs text-muted-foreground">
                        PNG ou JPG. Tamanho máximo 2MB.
                      </p>
                    </div>
                    <input
                      id="logoUpload"
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="hidden"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="col-span-2 space-y-2">
                    <Label htmlFor="name">Nome da Clínica *</Label>
                    <Input
                      id="name"
                      name="name"
                      value={clinicData.name}
                      onChange={handleChange}
                      placeholder="Nome da clínica ou razão social"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="cpfCnpj">
                      CPF/CNPJ {cpfCnpjLocked ? "(não editável)" : "*"}
                    </Label>
                    <Input
                      id="cpfCnpj"
                      name="cpfCnpj"
                      value={clinicData.cpfCnpj}
                      onChange={handleChange}
                      placeholder="000.000.000-00 ou 00.000.000/0000-00"
                      disabled={cpfCnpjLocked}
                      className={cpfCnpjLocked ? "bg-muted" : ""}
                    />
                    {cpfCnpjLocked && (
                      <p className="text-xs text-muted-foreground">
                        CPF/CNPJ não pode ser alterado após cadastrado para fins fiscais.
                      </p>
                    )}
                    {!cpfCnpjLocked && (
                      <p className="text-xs text-muted-foreground">
                        Necessário para emissão de cobranças. Não poderá ser alterado depois.
                      </p>
                    )}
                    {!cpfCnpjLocked && clinicData.cpfCnpj && !cpfCnpjIsValid && (
                      <p className="text-xs text-red-600">
                        Informe um CPF/CNPJ válido para salvar.
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">E-mail</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={clinicData.email}
                      onChange={handleChange}
                      placeholder="contato@clinica.com"
                    />
                  </div>

                  <div className="col-span-2 space-y-2">
                    <Label htmlFor="address">Endereço</Label>
                    <Input
                      id="address"
                      name="address"
                      value={clinicData.address}
                      onChange={handleChange}
                      placeholder="Rua, número, bairro, cidade - UF"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Telefone</Label>
                    <Input
                      id="phone"
                      name="phone"
                      value={clinicData.phone}
                      onChange={handleChange}
                      placeholder="(00) 00000-0000"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="website">Website</Label>
                    <Input
                      id="website"
                      name="website"
                      value={clinicData.website}
                      onChange={handleChange}
                      placeholder="www.clinica.com.br"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {canManageClinicUsers && (
          <TabsContent value="users">
            <UserManagement clinicId={clinicId} />
          </TabsContent>
        )}

        {canManageClinicDocuments && (
          <TabsContent value="documents">
            {clinicId ? (
              <DocumentUploader clinicId={clinicId} />
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <FileCheck className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>Selecione uma clínica para gerenciar documentos</p>
              </div>
            )}
          </TabsContent>
        )}

        {canViewAuditLogs && (
          <TabsContent value="audit">
            <AuditLogs />
          </TabsContent>
        )}

        <TabsContent value="preferences" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Preferências</CardTitle>
              <CardDescription>Gerencie suas preferências pessoais e da conta.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="font-medium">Aparência</p>
                  <p className="text-sm text-muted-foreground">
                    Alterne entre temas claro e escuro.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Sun size={16} className="text-muted-foreground" />
                  <Switch checked={isDark} onCheckedChange={toggleTheme} />
                  <Moon size={16} className="text-muted-foreground" />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="font-medium">Sair da conta</p>
                  <p className="text-sm text-muted-foreground">
                    Encerre sua sessão atual neste dispositivo.
                  </p>
                </div>
                <Button
                  variant="destructive"
                  onClick={handleLogout}
                  className="flex items-center gap-2"
                >
                  <LogOut size={16} />
                  Sair
                </Button>
              </div>

              {canManageWhatsAppSettings && (
                <div className="flex items-center justify-between gap-6">
                  <div className="space-y-1">
                    <p className="font-medium">Identificar atendente no WhatsApp</p>
                    <p className="text-sm text-muted-foreground">
                      Prefixa mensagens manuais com o nome da atendente em negrito na primeira
                      linha.
                    </p>
                  </div>
                  <Switch
                    checked={prependAttendantNameOnManualMessages}
                    disabled={!clinicId || isUpdatingWhatsAppSettings}
                    onCheckedChange={async (checked) => {
                      if (!clinicId) return;
                      setIsUpdatingWhatsAppSettings(true);
                      try {
                        await updateWhatsAppSettings({
                          clinicId,
                          prependAttendantNameOnManualMessages: checked,
                        });
                      } catch (error) {
                        console.error(error);
                        toast.error("Erro ao atualizar preferência do WhatsApp");
                      } finally {
                        setIsUpdatingWhatsAppSettings(false);
                      }
                    }}
                  />
                </div>
              )}
            </CardContent>
          </Card>

          {canManageOwnDoctorSettings && <WorkingHoursSettings />}

          {canManageOwnDoctorSettings && <ProceduresSettings />}
        </TabsContent>
      </Tabs>
    </div>
  );
}
