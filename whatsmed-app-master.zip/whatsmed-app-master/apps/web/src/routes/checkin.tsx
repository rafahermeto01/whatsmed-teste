import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation } from "convex/react";
import { CheckCircle2, ClipboardList, QrCode, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { AnamnesisForm } from "@/components/checkin/AnamnesisForm";
import { ConsentForm } from "@/components/checkin/ConsentForm";
import { PublicScheduler } from "@/components/checkin/PublicScheduler";
import { QRScanner } from "@/components/checkin/QRScanner";
import { FormRenderer } from "@/components/forms/FormRenderer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

// We'll use a search param for the token
interface CheckinSearch {
  token?: string;
}

export const Route = createFileRoute("/checkin")({
  component: CheckinPage,
  validateSearch: (search: Record<string, unknown>): CheckinSearch => {
    return {
      token: (search.token as string) || undefined,
    };
  },
});

type Step = "anamnesis" | "forms" | "consent" | "ready" | "scan" | "done";

function CheckinPage() {
  const { token } = Route.useSearch();
  const [currentStep, setCurrentStep] = useState<Step>("anamnesis");
  const [isSubmittingForm, setIsSubmittingForm] = useState(false);
  const [showScheduler, setShowScheduler] = useState(false);

  // Fetch session data
  const checkinData = useQuery(api.checkin.getCheckinSession, {
    token: token || "",
  });

  const session = checkinData && !("error" in checkinData) ? checkinData.session : null;

  const pendingForms = useQuery(
    api.patientForms.getPendingForCheckin,
    session
      ? {
          patientId: session.patientId,
          appointmentId: session.appointmentId,
        }
      : "skip",
  );

  const submitForm = useMutation(api.patientForms.submit);

  useEffect(() => {
    if (currentStep !== "forms") return;
    if (pendingForms === undefined) return;
    if (pendingForms.length === 0) {
      setCurrentStep("consent");
    }
  }, [currentStep, pendingForms]);

  const handleFormSubmit = async (formToken: string, data: any) => {
    setIsSubmittingForm(true);
    try {
      await submitForm({ token: formToken, submissionData: data });
      toast.success("Formulário enviado com sucesso!");
    } catch (error) {
      console.error(error);
      toast.error("Erro ao enviar formulário. Tente novamente.");
    } finally {
      setIsSubmittingForm(false);
    }
  };

  // Handle loading
  if (checkinData === undefined) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="mt-4 text-muted-foreground">Carregando sessão...</p>
      </div>
    );
  }

  // Handle invalid or expired session
  if (!checkinData || (checkinData as any).error) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4">
        <Card className="max-w-md w-full p-6 text-center border-none shadow-lg">
          <div className="mx-auto w-12 h-12 bg-red-100 text-red-600 rounded-full flex items-center justify-center mb-4">
            <ClipboardList className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-bold mb-2">Link Inválido ou Expirado</h2>
          <p className="text-muted-foreground mb-4">
            O link de check-in que você tentou acessar não é mais válido. Por favor, solicite um
            novo link pelo WhatsApp.
          </p>
        </Card>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="mt-4 text-muted-foreground">Carregando sessão...</p>
      </div>
    );
  }

  const { patient, appointment } = checkinData as any;

  // Step Progress Calculation
  const getProgress = () => {
    switch (currentStep) {
      case "anamnesis":
        return 25;
      case "consent":
        return 50;
      case "ready":
        return 75;
      case "scan":
        return 90;
      case "done":
        return 100;
      default:
        return 0;
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case "anamnesis":
        return (
          <AnamnesisForm
            onComplete={() => setCurrentStep("forms")}
            clinicId={session!.clinicId}
            patientId={patient?._id}
            checkinSessionId={session._id}
            initialData={patient}
          />
        );
      case "forms": {
        if (showScheduler && session && appointment?.doctorId) {
          return (
            <PublicScheduler
              clinicId={session!.clinicId}
              patientId={session.patientId}
              doctorId={appointment.doctorId}
              onScheduled={() => setShowScheduler(false)}
              onCancel={() => setShowScheduler(false)}
            />
          );
        }

        if (pendingForms === undefined || pendingForms.length === 0) {
          return <div className="text-center">Carregando...</div>;
        }
        const currentForm = pendingForms[0];

        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Formulários Pendentes: {pendingForms.length}</span>
            </div>
            <FormRenderer
              key={currentForm._id} // Re-mount on change
              form={{
                title: currentForm.formTitle!,
                description: currentForm.formDescription || "",
                type: currentForm.formType as any,
                questions: currentForm.formQuestions!,
              }}
              onSubmit={(data) => handleFormSubmit(currentForm.token!, data)}
              isSubmitting={isSubmittingForm}
            />
          </div>
        );
      }
      case "consent":
        return (
          <ConsentForm
            onComplete={() => setCurrentStep("ready")}
            onBack={() => setCurrentStep("anamnesis")}
            clinicId={session!.clinicId}
            patientId={patient?._id}
            appointmentId={appointment?._id}
          />
        );
      case "ready":
        return (
          <div className="flex flex-col items-center text-center space-y-6 py-8">
            <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center animate-bounce">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-bold">Tudo Pronto!</h2>
              <p className="text-muted-foreground max-w-sm mx-auto">
                Seu pré-cadastro foi concluído com sucesso. Quando chegar à clínica, clique no botão
                abaixo para fazer seu check-in.
              </p>
            </div>
            <div className="p-4 bg-muted rounded-lg w-full max-w-xs">
              <p className="text-xs font-mono text-muted-foreground break-all">
                Sessão segura validada. Nenhum dado sensível é exibido.
              </p>
            </div>
            <Button
              size="lg"
              className="w-full max-w-xs gap-2"
              onClick={() => setCurrentStep("scan")}
            >
              <QrCode className="w-5 h-5" />
              Estou na Clínica
            </Button>
          </div>
        );
      case "scan":
        return <QRScanner urlToken={token || ""} onScanSuccess={() => setCurrentStep("done")} />;
      case "done":
        return (
          <div className="flex flex-col items-center text-center space-y-6 py-12">
            <div className="w-24 h-24 bg-primary text-primary-foreground rounded-full flex items-center justify-center">
              <CheckCircle2 className="w-12 h-12" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-bold">Check-in Realizado!</h2>
              <p className="text-muted-foreground max-w-sm mx-auto">
                Sua presença foi confirmada. Por favor, aguarde na recepção e logo você será
                chamado.
              </p>
            </div>
            <div className="pt-8">
              <p className="text-sm font-medium text-primary">Tenha uma ótima consulta!</p>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md space-y-4">
        {/* Header */}
        <div className="flex items-center justify-center gap-2 mb-8">
          <div className="h-8 w-8 bg-primary rounded-md flex items-center justify-center text-primary-foreground font-bold">
            WM
          </div>
          <span className="font-bold text-xl">WhatsMed</span>
        </div>

        {/* Progress Bar */}
        {currentStep !== "done" && (
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-medium text-muted-foreground px-1">
              <span className={currentStep === "anamnesis" ? "text-primary" : ""}>Dados</span>
              <span className={currentStep === "forms" ? "text-primary" : ""}>Formulários</span>
              <span className={currentStep === "consent" ? "text-primary" : ""}>Termos</span>
              <span className={["ready", "scan"].includes(currentStep) ? "text-primary" : ""}>
                Check-in
              </span>
            </div>
            <Progress value={getProgress()} className="h-2" />
          </div>
        )}

        {/* Main Card */}
        <Card className="border-none shadow-lg">
          <CardContent className="p-6">{renderStep()}</CardContent>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-muted-foreground mt-8">
          Ambiente seguro • Protegido por criptografia de ponta a ponta
        </p>
      </div>
    </div>
  );
}
