import { fetchAuth } from "@convex-dev/better-auth/react-start";
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/patients")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const token = (await fetchAuth(request))?.token;
        const url = new URL(request.url);
        const qs = url.search;
        const target = `${import.meta.env.VITE_CONVEX_URL}/http/api/patients${qs}`;
        const res = await fetch(target, {
          method: "GET",
          headers: {
            Authorization: token ? `Bearer ${token}` : "",
          },
        });
        const body = await res.text();
        return new Response(body, {
          status: res.status,
          headers: { "Content-Type": "application/json" },
        });
      },
      POST: async ({ request }) => {
        const token = (await fetchAuth(request))?.token;
        const target = `${import.meta.env.VITE_CONVEX_URL}/http/api/patients`;
        const res = await fetch(target, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: token ? `Bearer ${token}` : "",
          },
          body: await request.text(),
        });
        const body = await res.text();
        return new Response(body, {
          status: res.status,
          headers: { "Content-Type": "application/json" },
        });
      },
    },
  },
});
