import { fetchAuth } from "@convex-dev/better-auth/react-start";
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/patients/$id")({
  server: {
    handlers: {
      PUT: async ({ params, request }) => {
        const token = (await fetchAuth(request))?.token;
        const target = `${import.meta.env.VITE_CONVEX_URL}/http/api/patients/${params.id}`;
        const res = await fetch(target, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: token ? `Bearer ${token}` : "",
          },
          body: await request.text(),
        });
        const body = await res.text();
        return new Response(body, {
          status: res.status,
          headers: { "Content-Type": "application/json" },
        });
      },
      DELETE: async ({ params, request }) => {
        const token = (await fetchAuth(request))?.token;
        const target = `${import.meta.env.VITE_CONVEX_URL}/http/api/patients/${params.id}`;
        const res = await fetch(target, {
          method: "DELETE",
          headers: {
            Authorization: token ? `Bearer ${token}` : "",
          },
        });
        const body = await res.text();
        return new Response(body, {
          status: res.status,
          headers: { "Content-Type": "application/json" },
        });
      },
    },
  },
});
