import { createFileRoute } from "@tanstack/react-router";
import { useAction } from "convex/react";
import { useEffect, useState, useRef } from "react";
import { toast } from "sonner";

import { api } from "@whatsmed-app/backend/convex/_generated/api";

export const Route = createFileRoute("/api/oauth/google/callback")({
  component: GoogleCallbackPage,
});

function GoogleCallbackPage() {
  const [status, setStatus] = useState<"processing" | "success" | "error">("processing");
  const [errorMsg, setErrorMsg] = useState("");
  const exchangeCode = useAction(api.googleCalendarActions.exchangeCodeForTokens);
  const processedRef = useRef(false); // Prevent double execution

  useEffect(() => {
    const handleCallback = async () => {
      if (processedRef.current) return;
      processedRef.current = true;

      const searchParams = new URLSearchParams(window.location.search);
      const code = searchParams.get("code");
      const state = searchParams.get("state");
      const error = searchParams.get("error");

      if (error) {
        setStatus("error");
        setErrorMsg(searchParams.get("error_description") || error);
        return;
      }

      if (!code || !state) {
        setStatus("error");
        setErrorMsg("Código de autorização inválido");
        return;
      }

      try {
        await exchangeCode({ code, state });
        setStatus("success");
        toast.success("Google Calendar conectado com sucesso!");

        // Notify opener window if it exists (popup flow)
        if (window.opener) {
          window.opener.postMessage({ type: "GOOGLE_OAUTH_SUCCESS" }, window.location.origin);
          setTimeout(() => window.close(), 2000);
        } else {
          // Redirect to integrations if not in popup
          setTimeout(() => (window.location.href = "/integrations"), 2000);
        }
      } catch (err: any) {
        console.error("OAuth Exchange Error:", err);
        setStatus("error");
        setErrorMsg(err.message || "Falha ao conectar conta Google");
      }
    };

    handleCallback();
  }, [exchangeCode]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 p-4">
      <div className="w-full max-w-md rounded-xl bg-white p-8 shadow-lg text-center">
        {status === "processing" && (
          <div className="flex flex-col items-center gap-4">
            <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent" />
            <h1 className="text-xl font-semibold text-gray-900">Conectando...</h1>
            <p className="text-gray-500">Estamos finalizando a integração com o Google.</p>
          </div>
        )}

        {status === "success" && (
          <div className="flex flex-col items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100 text-green-600">
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>
            <h1 className="text-xl font-semibold text-gray-900">Conectado!</h1>
            <p className="text-gray-500">A janela será fechada automaticamente.</p>
          </div>
        )}

        {status === "error" && (
          <div className="flex flex-col items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-red-100 text-red-600">
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </div>
            <h1 className="text-xl font-semibold text-gray-900">Erro na Conexão</h1>
            <p className="text-red-500">{errorMsg}</p>
            <button
              onClick={() => window.close()}
              className="mt-4 rounded-md bg-gray-100 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-200"
            >
              Fechar Janela
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
