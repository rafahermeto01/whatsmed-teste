import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Authenticated, Unauthenticated } from "convex/react";
import { Eye, EyeOff } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";

import { ForgotPasswordModal } from "@/components/ForgotPasswordModal";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { authClient } from "@/lib/auth-client";

export const Route = createFileRoute("/login")({
  validateSearch: (search: Record<string, unknown>) => {
    return {
      redirect: (search.redirect as string) || undefined,
    };
  },
  component: LoginPage,
});

function sanitizeRedirect(redirect?: string): string {
  if (!redirect || redirect === "/" || !redirect.startsWith("/") || redirect.startsWith("//")) {
    return "/dashboard";
  }
  return redirect;
}

export function LoginPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const { data, isPending } = authClient.useSession();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [mounted, setMounted] = useState(true);

  useEffect(() => {
    setMounted(true);
    return () => {
      setMounted(false);
    };
  }, []);

  useEffect(() => {
    if (!isPending && data?.user) {
      const destination = sanitizeRedirect(search.redirect);
      navigate({ to: destination });
    }
  }, [isPending, data, search.redirect, navigate]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setLoading(true);

    try {
      await authClient.signIn.email(
        {
          email,
          password,
        },
        {
          onSuccess: () => {
            // Use window.location for navigation after login to ensure cookies are sent
            // This forces a full page reload which includes cookies in the request
            const destination = sanitizeRedirect(search.redirect);
            window.location.href = destination;
          },
          onError: (ctx) => {
            toast.error(ctx.error.message || "Erro ao autenticar");
            setLoading(false);
          },
        },
      );
    } catch (err: any) {
      console.error("Login error:", err);
      if (mounted) {
        toast.error(err?.message ?? "Erro ao autenticar");
        setLoading(false);
      }
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <Authenticated>
        {/* Automatically redirecting... */}
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </Authenticated>
      <Unauthenticated>
        <div
          className="w-full max-w-md bg-card border border-border p-10 space-y-8"
          style={{
            borderRadius: "var(--radius)",
            boxShadow: "var(--shadow-lg)",
          }}
        >
          {/* Logo Area */}
          <div className="flex flex-col items-center space-y-2">
            <img src="/logos/stacked.svg" alt="WhatsMed" className="h-16 w-auto" />
          </div>

          {/* Typography */}
          <div className="text-center space-y-2">
            <h2 className="text-foreground text-xl font-medium">Bem-vindo de volta</h2>
            <p className="text-muted-foreground text-sm">
              Insira suas credenciais para acessar o gerenciador da clínica
            </p>
          </div>

          <form onSubmit={onSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="block text-foreground font-medium text-base">
                Endereço de E-mail
              </Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nome@clinica.com"
                required
                className="w-full h-10 px-3 bg-input-background border border-input focus:border-ring focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 transition-all"
                style={{ borderRadius: "var(--radius)" }}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="block text-foreground font-medium text-base">
                Senha
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full h-10 px-3 pr-10 bg-input-background border border-input focus:border-ring focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 transition-all"
                  style={{ borderRadius: "var(--radius)" }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
              <div className="text-right">
                <button
                  type="button"
                  onClick={() => setShowForgotModal(true)}
                  className="text-sm text-primary hover:underline transition-all font-medium"
                >
                  Esqueceu a senha?
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full h-10 bg-primary text-primary-foreground hover:opacity-90 transition-opacity font-medium disabled:opacity-50"
              style={{ borderRadius: "var(--radius)" }}
            >
              {loading ? "Entrando..." : "Entrar"}
            </button>
          </form>

          <div className="text-center text-sm text-muted-foreground">
            Não tem uma conta? Entre em contato com o Suporte
          </div>
        </div>
      </Unauthenticated>

      {/* Forgot Password Modal */}
      {showForgotModal && <ForgotPasswordModal onClose={() => setShowForgotModal(false)} />}
    </div>
  );
}
