import { createFileRoute } from "@tanstack/react-router";
import { useMutation } from "convex/react";
import {
  format,
  addMonths,
  subMonths,
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  addDays,
  isSameMonth,
  isSameDay,
} from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  ChevronLeft,
  ChevronRight,
  Check,
  X,
  List as ListIcon,
  Video,
  UserCheck,
  Calendar as CalendarIcon,
  Users,
} from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";

import { AppointmentDetailsModal } from "@/components/AppointmentDetailsModal";
import { RescheduleSuggestionModal } from "@/components/appointments/RescheduleSuggestionModal";
import { TelehealthModal } from "@/components/appointments/TelehealthModal";
import { WaitlistSection } from "@/components/appointments/WaitlistSection";
import { CreateAppointmentModal } from "@/components/CreateAppointmentModal";
import { PlanGate } from "@/components/PlanGate";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAppointmentsList, useClinicId, useUpdateAppointment } from "@/hooks/appointments";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

import type { Id } from "@whatsmed-app/backend/convex/_generated/dataModel";

export const Route = createFileRoute("/appointments")({
  component: AppointmentsPage,
});

type ViewMode = "month" | "week" | "day" | "list";

function AppointmentsPage() {
  const [viewMode, setViewMode] = useState<ViewMode>("month");
  const [currentDate, setCurrentDate] = useState(new Date());
  const [showTelehealthOnly, setShowTelehealthOnly] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<any>(null);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [telehealthOpen, setTelehealthOpen] = useState(false);
  const [rescheduleOpen, setRescheduleOpen] = useState(false);

  const { clinicId } = useClinicId();
  const updateAppointment = useUpdateAppointment();
  const checkInPatient = useMutation(api.appointments.checkInPatient);

  // Calculate date range for fetching
  const { startAt, endAt } = useMemo(() => {
    let start, end;
    if (viewMode === "month") {
      start = startOfMonth(currentDate);
      end = endOfMonth(currentDate);
      // Expand to full weeks for grid
      start = startOfWeek(start);
      end = endOfWeek(end);
    } else if (viewMode === "week") {
      start = startOfWeek(currentDate);
      end = endOfWeek(currentDate);
    } else if (viewMode === "day") {
      start = new Date(currentDate);
      start.setHours(0, 0, 0, 0);
      end = new Date(currentDate);
      end.setHours(23, 59, 59, 999);
    } else {
      // List view - fetch current month + next month
      start = startOfMonth(currentDate);
      end = addMonths(endOfMonth(currentDate), 1);
    }
    return { startAt: start.getTime(), endAt: end.getTime() };
  }, [viewMode, currentDate]);

  const appointmentsQuery = useAppointmentsList({
    clinicId,
    startAt,
    endAt,
    limit: 100,
  });

  const appointments = useMemo(() => {
    let items = appointmentsQuery?.items ?? [];
    if (showTelehealthOnly) {
      items = items.filter((apt: any) => apt.isTelemedicine === true);
    }
    return items;
  }, [appointmentsQuery, showTelehealthOnly]);

  const currentPeriodLabel = useMemo(() => {
    if (viewMode === "day") {
      return format(currentDate, "EEEE, dd 'de' MMMM 'de' yyyy", { locale: ptBR });
    }

    return format(currentDate, "MMMM yyyy", { locale: ptBR });
  }, [currentDate, viewMode]);

  const handleStatusChange = async (
    id: Id<"appointments">,
    status: "confirmed" | "cancelled" | "completed",
  ) => {
    if (!clinicId) return;
    try {
      await updateAppointment({ id, clinicId, status });

      if (status === "cancelled") {
        // Trigger reschedule suggestion flow for demo
        setRescheduleOpen(true);
      } else {
        toast.success(status === "confirmed" ? "Agendamento confirmado" : "Status atualizado");
      }
    } catch {
      toast.error("Erro ao atualizar status");
    }
  };

  const nextDate = () => {
    if (viewMode === "month") setCurrentDate(addMonths(currentDate, 1));
    else if (viewMode === "week") setCurrentDate(addDays(currentDate, 7));
    else setCurrentDate(addDays(currentDate, 1));
  };

  const prevDate = () => {
    if (viewMode === "month") setCurrentDate(subMonths(currentDate, 1));
    else if (viewMode === "week") setCurrentDate(addDays(currentDate, -7));
    else setCurrentDate(addDays(currentDate, -1));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-green-500";
      case "pending":
        return "bg-yellow-500";
      case "cancelled":
        return "bg-red-500";
      case "completed":
        return "bg-blue-500";
      case "arrived": // New status
        return "bg-purple-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "confirmed":
        return "Confirmada";
      case "pending":
        return "Pendente";
      case "cancelled":
        return "Cancelada";
      case "completed":
        return "Concluída";
      case "arrived":
        return "Na Recepção";
      default:
        return status;
    }
  };

  const renderCalendar = () => {
    const monthStart = startOfMonth(currentDate);
    const startDate = startOfWeek(monthStart);
    const endDate = endOfWeek(endOfMonth(currentDate));

    const rows = [];
    let days = [];
    let day = startDate;
    let formattedDate = "";

    while (day <= endDate) {
      for (let i = 0; i < 7; i++) {
        formattedDate = format(day, "d");
        const cloneDay = day;
        const dayAppointments = appointments.filter((apt: any) =>
          isSameDay(new Date(apt.startAt), cloneDay),
        );

        days.push(
          <div
            key={day.toString()}
            className={`min-h-[120px] p-2 border border-border transition-colors ${
              !isSameMonth(day, monthStart) ? "bg-muted/30 text-muted-foreground" : "bg-card"
            }`}
          >
            <div className="text-right text-sm font-medium mb-2">{formattedDate}</div>
            <div className="space-y-1">
              {dayAppointments.map((apt: any) => (
                <button
                  key={apt._id}
                  onClick={() => setSelectedAppointment(apt)}
                  className={`w-full px-2 py-1 text-xs text-left text-white rounded shadow-sm hover:opacity-90 transition-opacity truncate ${getStatusColor(apt.status)}`}
                >
                  <div className="flex items-center gap-1">
                    {apt.isTelemedicine && <Video size={10} />}
                    <span className="font-bold">{format(new Date(apt.startAt), "HH:mm")}</span>
                    <span className="truncate">{apt.patientName}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>,
        );
        day = addDays(day, 1);
      }
      rows.push(
        <div className="grid grid-cols-7" key={day.toString()}>
          {days}
        </div>,
      );
      days = [];
    }
    return <div className="border rounded-md overflow-hidden">{rows}</div>;
  };

  const renderWeekView = () => {
    const weekStart = startOfWeek(currentDate);
    const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
    const hours = Array.from({ length: 14 }, (_, i) => i + 6); // 6:00 to 19:00

    return (
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <div className="min-w-[800px]">
            {/* Header */}
            <div className="grid grid-cols-8 border-b bg-muted text-center text-xs font-semibold leading-6 text-muted-foreground">
              <div className="bg-background py-2 sticky left-0 z-10 border-r">Horário</div>
              {weekDays.map((day) => (
                <div
                  key={day.toString()}
                  className={`bg-background py-2 ${isSameDay(day, new Date()) ? "text-primary font-bold" : ""}`}
                >
                  {format(day, "EEE, d", { locale: ptBR })}
                </div>
              ))}
            </div>

            {/* Body */}
            <div className="grid grid-cols-8 divide-x">
              {/* Time Column */}
              <div className="bg-muted/10 sticky left-0 z-10 border-r">
                {hours.map((hour) => (
                  <div
                    key={hour}
                    className="h-24 text-xs text-muted-foreground p-2 text-right border-b last:border-0"
                  >
                    {hour}:00
                  </div>
                ))}
              </div>

              {/* Days Columns */}
              {weekDays.map((day) => {
                const dayAppointments = appointments.filter((apt: any) =>
                  isSameDay(new Date(apt.startAt), day),
                );
                return (
                  <div key={day.toString()} className="relative bg-card">
                    {hours.map((hour) => (
                      <div key={hour} className="h-24 border-b border-muted/50 p-1 relative group">
                        {/* Render appointments for this hour slot */}
                        {dayAppointments
                          .filter((apt: any) => new Date(apt.startAt).getHours() === hour)
                          .map((apt: any) => (
                            <button
                              key={apt._id}
                              onClick={() => setSelectedAppointment(apt)}
                              className={`w-full mb-1 px-2 py-1 text-xs text-left text-white rounded shadow-sm hover:opacity-90 transition-opacity truncate ${getStatusColor(apt.status)}`}
                            >
                              <div className="font-bold">
                                {format(new Date(apt.startAt), "HH:mm")}
                              </div>
                              <div className="truncate">{apt.patientName}</div>
                            </button>
                          ))}
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </Card>
    );
  };

  const renderDayView = () => {
    const hours = Array.from({ length: 14 }, (_, i) => i + 6); // 6:00 to 19:00
    const dayAppointments = appointments.filter((apt: any) =>
      isSameDay(new Date(apt.startAt), currentDate),
    );

    return (
      <Card>
        <div className="grid grid-cols-[80px_1fr] divide-x">
          {/* Time Column */}
          <div className="bg-muted/10 text-right border-r">
            {hours.map((hour) => (
              <div
                key={hour}
                className="h-24 text-sm text-muted-foreground p-4 border-b last:border-0"
              >
                {hour}:00
              </div>
            ))}
          </div>

          {/* Day Column */}
          <div className="bg-card">
            {hours.map((hour) => (
              <div key={hour} className="h-24 border-b border-muted/50 p-2 relative last:border-0">
                {/* Render appointments for this hour slot */}
                <div className="flex gap-2 h-full overflow-y-auto">
                  {dayAppointments
                    .filter((apt: any) => new Date(apt.startAt).getHours() === hour)
                    .map((apt: any) => (
                      <button
                        key={apt._id}
                        onClick={() => setSelectedAppointment(apt)}
                        className={`flex-1 max-w-[200px] h-full p-2 text-xs text-left text-white rounded shadow-sm hover:opacity-90 transition-opacity overflow-hidden ${getStatusColor(apt.status)}`}
                      >
                        <div className="font-bold">{format(new Date(apt.startAt), "HH:mm")}</div>
                        <div className="font-medium truncate">{apt.patientName}</div>
                        <div className="truncate opacity-80">{apt.procedure}</div>
                      </button>
                    ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    );
  };

  return (
    <PlanGate feature="appointments">
      <div className="space-y-6 p-6">
        <Tabs defaultValue="agenda" className="space-y-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <TabsList>
              <TabsTrigger value="agenda" className="flex items-center gap-2">
                <CalendarIcon className="w-4 h-4" /> Agenda
              </TabsTrigger>
              <TabsTrigger value="waitlist" className="flex items-center gap-2">
                <Users className="w-4 h-4" /> Fila de Espera
              </TabsTrigger>
            </TabsList>

            <div className="w-[200px]">
              <Button className="w-full" onClick={() => setCreateModalOpen(true)}>
                Novo Agendamento
              </Button>
            </div>
          </div>

          <TabsContent value="agenda" className="space-y-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2 bg-muted p-1 rounded-lg">
                <Button
                  variant={viewMode === "month" ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("month")}
                >
                  Mês
                </Button>
                <Button
                  variant={viewMode === "week" ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("week")}
                >
                  Semana
                </Button>
                <Button
                  variant={viewMode === "day" ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("day")}
                >
                  Dia
                </Button>
                <Button
                  variant={viewMode === "list" ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                >
                  <ListIcon size={16} className="mr-2" />
                  Lista
                </Button>

                <div className="w-px h-6 bg-border mx-2" />

                <Button
                  variant={showTelehealthOnly ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setShowTelehealthOnly(!showTelehealthOnly)}
                  className={
                    showTelehealthOnly
                      ? "bg-blue-100 text-blue-700 hover:bg-blue-200"
                      : "text-muted-foreground"
                  }
                >
                  <Video size={16} className="mr-2" />
                  Telemedicina
                </Button>
              </div>

              <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={prevDate}>
                  <ChevronLeft size={16} />
                </Button>
                <h2 className="text-lg font-semibold min-w-[200px] text-center capitalize">
                  {currentPeriodLabel}
                </h2>
                <Button variant="outline" size="icon" onClick={nextDate}>
                  <ChevronRight size={16} />
                </Button>
              </div>

              {/* Spacer to balance layout */}
              <div className="w-[200px] hidden md:block" />
            </div>

            {viewMode === "month" && (
              <Card>
                <div className="grid grid-cols-7 gap-px border-b bg-muted text-center text-xs font-semibold leading-6 text-muted-foreground lg:flex-none">
                  {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((day) => (
                    <div key={day} className="bg-background py-2">
                      {day}
                    </div>
                  ))}
                </div>
                {renderCalendar()}
              </Card>
            )}

            {viewMode === "week" && renderWeekView()}

            {viewMode === "day" && renderDayView()}

            {viewMode === "list" && (
              <div className="space-y-4">
                {appointments.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    Nenhum agendamento encontrado para este período.
                  </div>
                ) : (
                  appointments.map((apt: any) => (
                    <Card
                      key={apt._id}
                      className="flex items-center p-4 gap-4 hover:shadow-md transition-shadow"
                    >
                      <div className={`w-1 h-12 rounded-full ${getStatusColor(apt.status)}`} />
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-semibold">{apt.patientName}</h4>
                              {apt.isTelemedicine && <Video className="w-3 h-3 text-blue-500" />}
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {format(new Date(apt.startAt), "dd/MM/yyyy HH:mm")} •{" "}
                              {apt.doctor || "Sem médico"}
                            </p>
                          </div>
                          <div
                            className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(apt.status)} text-white opacity-80`}
                          >
                            {getStatusLabel(apt.status)}
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {/* Telehealth Button */}
                        {apt.isTelemedicine && apt.status !== "cancelled" && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-blue-200 text-blue-700 hover:bg-blue-50"
                            onClick={() => {
                              setSelectedAppointment(apt);
                              setTelehealthOpen(true);
                            }}
                          >
                            <Video className="w-4 h-4 mr-1" /> Sala
                          </Button>
                        )}

                        {/* Check-in Button (if confirmed and today) */}
                        {apt.status === "confirmed" &&
                          isSameDay(new Date(apt.startAt), new Date()) && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-green-200 text-green-700 hover:bg-green-50"
                              onClick={async () => {
                                try {
                                  await checkInPatient({
                                    appointmentId: apt._id,
                                    clinicId: clinicId,
                                  });
                                  toast.success(`${apt.patientName} realizou check-in!`);
                                } catch (error: any) {
                                  toast.error(error.message || "Erro ao fazer check-in");
                                }
                              }}
                            >
                              <UserCheck className="w-4 h-4 mr-1" /> Check-in
                            </Button>
                          )}

                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setSelectedAppointment(apt)}
                        >
                          Detalhes
                        </Button>

                        {apt.status === "pending" && (
                          <>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="text-green-600 hover:text-green-700 hover:bg-green-50"
                              onClick={() => handleStatusChange(apt._id, "confirmed")}
                            >
                              <Check size={16} />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                              onClick={() => handleStatusChange(apt._id, "cancelled")}
                            >
                              <X size={16} />
                            </Button>
                          </>
                        )}
                      </div>
                    </Card>
                  ))
                )}
              </div>
            )}
          </TabsContent>

          <TabsContent value="waitlist">
            <WaitlistSection clinicId={clinicId} />
          </TabsContent>
        </Tabs>

        {selectedAppointment && (
          <AppointmentDetailsModal
            appointment={selectedAppointment}
            onClose={() => setSelectedAppointment(null)}
          />
        )}

        <CreateAppointmentModal open={createModalOpen} onOpenChange={setCreateModalOpen} />

        {/* Telehealth Modal */}
        <TelehealthModal
          open={telehealthOpen}
          onOpenChange={setTelehealthOpen}
          patientName={selectedAppointment?.patientName || ""}
          meetingLink={selectedAppointment?.meetingLink}
        />

        {/* Reschedule Suggestion Modal */}
        <RescheduleSuggestionModal
          open={rescheduleOpen}
          onOpenChange={setRescheduleOpen}
          patientId={selectedAppointment?.patientId || ""}
          appointmentId={selectedAppointment?._id || ""}
          doctorId={selectedAppointment?.doctorId || ""}
          clinicId={clinicId || ""}
        />
      </div>
    </PlanGate>
  );
}
