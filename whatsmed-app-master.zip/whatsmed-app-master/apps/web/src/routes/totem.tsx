import { createFileRoute } from "@tanstack/react-router";
import { Clock } from "lucide-react";
import { useEffect, useState } from "react";

import { ClinicQRCode } from "@/components/ClinicQRCode";
import { Card } from "@/components/ui/card";
import { useClinic } from "@/hooks/clinics";
import { useClinicId } from "@/hooks/patients";

export const Route = createFileRoute("/totem")({
  component: TotemPage,
});

function TotemPage() {
  const { clinicId } = useClinicId(); // In a real totem, this might be hardcoded or set via auth
  const clinic = useClinic(clinicId);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="h-screen w-screen bg-slate-950 text-white flex flex-col items-center justify-center p-8 relative overflow-hidden fixed inset-0 overscroll-none">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-primary via-blue-500 to-purple-500" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-black -z-10" />

      {/* Header */}
      <div className="absolute top-8 left-8 flex items-center gap-3">
        {clinic?.logoUrl ? (
          <div className="h-10 w-10 bg-white rounded-lg flex items-center justify-center shadow-lg shadow-primary/20 overflow-hidden">
            <img src={clinic.logoUrl} alt={clinic.name} className="w-full h-full object-cover" />
          </div>
        ) : (
          <div className="h-10 w-10 bg-primary rounded-lg flex items-center justify-center font-bold text-xl shadow-lg shadow-primary/20">
            {clinic?.name ? clinic.name.substring(0, 2).toUpperCase() : "WM"}
          </div>
        )}
        <h1 className="text-2xl font-bold tracking-tight">{clinic?.name || "WhatsMed"}</h1>
      </div>

      {/* Clock */}
      <div className="absolute top-8 right-8 flex items-center gap-2 text-slate-400 bg-slate-900/50 px-4 py-2 rounded-full border border-slate-800">
        <Clock className="w-4 h-4" />
        <span className="font-mono text-lg font-medium">
          {currentTime.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
        </span>
      </div>

      {/* Main Content */}
      <div className="flex flex-col md:flex-row items-center gap-12 md:gap-24 z-10 max-w-6xl w-full">
        {/* Left Side: Instructions */}
        <div className="flex-1 space-y-8 text-center md:text-left">
          <div className="space-y-4">
            <h2 className="text-4xl md:text-6xl font-bold leading-tight">
              Bem-vindo! <br />
              <span className="text-primary bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-400">
                Faça seu Check-in
              </span>
            </h2>
            <p className="text-xl text-slate-400 max-w-lg mx-auto md:mx-0">
              Abra o link enviado para o seu WhatsApp e aponte a câmera para o QR Code ao lado.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-md mx-auto md:mx-0">
            <Card className="bg-slate-900/50 border-slate-800 p-4 flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">
                1
              </div>
              <div className="text-left">
                <p className="font-medium text-white">Abra o Link</p>
                <p className="text-xs text-slate-400">Recebido via WhatsApp</p>
              </div>
            </Card>
            <Card className="bg-slate-900/50 border-slate-800 p-4 flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">
                2
              </div>
              <div className="text-left">
                <p className="font-medium text-white">Escaneie</p>
                <p className="text-xs text-slate-400">O código ao lado</p>
              </div>
            </Card>
          </div>
        </div>

        {/* Right Side: QR Code */}
        <div className="flex-1 flex justify-center md:justify-end">
          <div className="relative">
            {/* Glow Effect */}
            <div className="absolute inset-0 bg-primary/20 blur-3xl rounded-full" />

            <ClinicQRCode
              clinicId={clinicId || "demo-clinic"}
              size={300}
              className="relative z-10"
            />
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="absolute bottom-8 text-center text-slate-500 text-sm">
        <p>Precisa de ajuda? Dirija-se à recepção.</p>
      </div>
    </div>
  );
}
