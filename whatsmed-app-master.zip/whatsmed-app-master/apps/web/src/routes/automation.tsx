import { createFileRoute, Outlet } from "@tanstack/react-router";
import { useQuery, useMutation } from "convex/react";
import {
  Bot,
  CalendarClock,
  Loader2,
  MessageSquare,
  Zap,
  Plus,
  Save,
  ShieldAlert,
  Sparkles,
  Timer,
  FileText,
  Mic,
  CalendarDays,
  XCircle,
  Megaphone,
  Calendar,
  Image,
  UserCog,
  Star,
  Pencil,
  Trash2,
} from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { toast } from "sonner";

import { CampaignBuilderModal } from "@/components/automation/CampaignBuilderModal";
import { VariableInserter } from "@/components/automation/VariableInserter";
import { AutoSaveIndicator } from "@/components/ui/auto-save-indicator";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useEffectiveCurrentUser, usePermissions } from "@/hooks/patients";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

export const Route = createFileRoute("/automation")({ component: AutomationPage });

function AutomationPage() {
  const isChildRoute = false; // flow routes deprecated
  const [showCampaignModal, setShowCampaignModal] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState<any | null>(null);
  const initialLoadRef = useRef(true);
  const remindersInitialLoadRef = useRef(true);
  const [hydrationReady, setHydrationReady] = useState(false);
  const [aiSaveStatus, setAiSaveStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [aiSaveError, setAiSaveError] = useState<string | null>(null);
  const [reminderSaveStatus, setReminderSaveStatus] = useState<
    "idle" | "saving" | "saved" | "error"
  >("idle");
  const [reminderSaveError, setReminderSaveError] = useState<string | null>(null);
  const user = useEffectiveCurrentUser();
  const { canManageAutomation } = usePermissions();
  const updateAiSettings = useMutation(api.automation.updateAiSettings);
  const createAiSystemPrompt = useMutation(api.automation.createAiSystemPrompt);
  const updateAiSystemPrompt = useMutation(api.automation.updateAiSystemPrompt);
  const setActiveAiSystemPrompt = useMutation(api.automation.setActiveAiSystemPrompt);
  const deleteAiSystemPrompt = useMutation(api.automation.deleteAiSystemPrompt);
  const updateReminderConfig = useMutation(api.automation.updateReminderConfig);
  const toggleCampaignStatus = useMutation(api.automation.toggleCampaignStatus);
  const deleteCampaign = useMutation(api.automation.deleteCampaign);

  const clinicId = user?.clinicId;

  // Fetch Data
  const aiSettings = useQuery(api.automation.getAiSettings, clinicId ? { clinicId } : "skip");
  const savedPrompts = useQuery(
    api.automation.listAiSystemPrompts,
    clinicId ? { clinicId } : "skip",
  );
  const reminderConfigs = useQuery(
    api.automation.getReminderConfigs,
    clinicId ? { clinicId } : "skip",
  );
  const campaignsList = useQuery(api.automation.listCampaigns, clinicId ? { clinicId } : "skip");

  // AI Settings State
  const [aiEnabled, setAiEnabled] = useState(true);
  const [delaySeconds, setDelaySeconds] = useState([15]);
  const [activeHoursStart, setActiveHoursStart] = useState("08:00");
  const [activeHoursEnd, setActiveHoursEnd] = useState("18:00");
  const [is247, setIs247] = useState(false);
  const [tone, setTone] = useState("empathetic");
  const [voiceNotesEnabled, setVoiceNotesEnabled] = useState(true);
  const [selectedPromptId, setSelectedPromptId] = useState<string | null>(null);
  const [promptName, setPromptName] = useState("");
  const [promptContent, setPromptContent] = useState("");
  const [promptDirty, setPromptDirty] = useState(false);
  const [promptAction, setPromptAction] = useState<
    "create" | "save" | "activate" | "delete" | "import" | null
  >(null);

  // Escalation Topics State
  const [escalationTopics, setEscalationTopics] = useState({
    legal: true,
    medicalEmergency: true,
    complaints: true,
    customKeywords: [] as string[],
  });
  const [customKeywordsInput, setCustomKeywordsInput] = useState("");

  // Enabled Tools State
  const [enabledTools, setEnabledTools] = useState({
    scheduling: true, // searchDoctors, checkDoctorAvailability, createAppointment, listProcedures
    nps: true, // saveNpsScore, getNpsSettings, requestGoogleReview
    documents: true, // analyzeDocument
    patientData: true, // updatePatientData, savePatientImage
  });

  // Automation message templates (NPS survey itself remains in the NPS tab)
  const [reminders, setReminders] = useState({
    appointmentConfirmation: {
      enabled: true,
      message:
        "Olá {{patient.name}}! ✅\n\nSua consulta foi agendada com sucesso!\n\n📅 Data: {{appointment.date}}\n⏰ Horário: {{appointment.time}}\n👨‍⚕️ Médico: {{appointment.doctor}}\n📋 Procedimento: {{appointment.procedure}}\n\nAguardamos você! 😊",
      channels: { whatsapp: true },
      useOfficialApi: false,
    },
    sevenDay: {
      enabled: true,
      message:
        "Olá {{patient.name}}! Lembramos que você tem uma consulta agendada para {{appointment.date}} às {{appointment.time}}. Aguardamos você! 😊",
      channels: { whatsapp: true },
      useOfficialApi: false,
    },
    twentyFourHour: {
      enabled: true,
      message:
        "Oi {{patient.name}}! Sua consulta é amanhã às {{appointment.time}}. Por favor, confirme sua presença respondendo SIM.",
      channels: { whatsapp: true },
      useOfficialApi: false,
    },
    oneHour: {
      enabled: true,
      message:
        "Olá {{patient.name}}! Sua consulta é em 1 hora ({{appointment.time}}). Estamos aguardando você! 🕐",
      channels: { whatsapp: true },
      useOfficialApi: false,
    },
    noShowRecovery: {
      enabled: true,
      message:
        "Olá {{patient.name}}, notamos que você não pôde comparecer. Gostaria de reagendar sua consulta?",
      channels: { whatsapp: true },
      useOfficialApi: false,
    },
    rescheduleOptions: {
      enabled: true,
      message:
        "Sem problema, {{patient.name}}. Posso reagendar sua {{appointment.procedure}} para uma destas opções:\n\n{{reschedule.options}}\n\nResponda com 1, 2 ou 3. Se não quiser nenhuma opção, responda NAO para cancelar.",
      channels: { whatsapp: true },
      useOfficialApi: false,
    },
    rescheduleConfirmation: {
      enabled: true,
      message:
        "Olá {{patient.name}}! Sua {{appointment.procedure}} foi reagendada.\n\n📅 Nova data: {{appointment.date}}\n⏰ Horário: {{appointment.time}}\n📍 Tipo: {{appointment.type}}\n\nCaso precise de algo, estamos à disposição!",
      channels: { whatsapp: true },
      useOfficialApi: false,
    },
    confirmationReply: {
      enabled: true,
      message:
        "Perfeito! Sua consulta está confirmada. Se precisar de algo antes do atendimento, estou por aqui.",
      channels: { whatsapp: true },
      useOfficialApi: false,
    },
    cancellationConfirmation: {
      enabled: true,
      message:
        "Tudo bem. Sua consulta foi cancelada{{cancellation.reason}}. Quando quiser, podemos buscar um novo horário para você.",
      channels: { whatsapp: true },
      useOfficialApi: false,
    },
    googleReviewFollowUp: {
      enabled: true,
      message:
        "Obrigado pela avaliação, {{patient.name}}! Se você puder, deixar uma avaliação no Google ajudaria muito: {{nps.googleMapsLink}}",
      channels: { whatsapp: true },
      useOfficialApi: false,
    },
    detractorAlert: {
      enabled: true,
      message:
        'ALERTA DE DETRATOR NPS\n\nPaciente: {{patient.name}}\nNota: {{nps.score}}/10\nFeedback: "{{nps.feedback}}"\nMédico: {{appointment.doctor}}\n\nVerifique o atendimento e entre em contato se necessário.',
      channels: { whatsapp: true },
      useOfficialApi: false,
    },
  });

  useEffect(() => {
    initialLoadRef.current = true;
    remindersInitialLoadRef.current = true;
    setHydrationReady(false);
    setAiSaveStatus("idle");
    setReminderSaveStatus("idle");
    setAiSaveError(null);
    setReminderSaveError(null);
  }, [clinicId]);

  // Sync state with fetched data (only on initial load to avoid overwriting user changes)
  useEffect(() => {
    if (aiSettings !== undefined && initialLoadRef.current) {
      if (aiSettings) {
        setAiEnabled(aiSettings.enabled);
        setTone(aiSettings.tone || "empathetic");
        setActiveHoursStart(aiSettings.activeHoursStart || "08:00");
        setActiveHoursEnd(aiSettings.activeHoursEnd || "18:00");
        setIs247(aiSettings.is247 ?? false);
        setVoiceNotesEnabled(true);
        setDelaySeconds([aiSettings.responseDelaySeconds || 0]);

        // Sync escalation topics
        if (aiSettings.escalationTopics) {
          setEscalationTopics(aiSettings.escalationTopics as any);
          setCustomKeywordsInput(
            (aiSettings.escalationTopics as any).customKeywords?.join(", ") || "",
          );
        } else if (aiSettings.escalationKeywords?.length) {
          // Migration: convert old keywords to new format
          setCustomKeywordsInput(aiSettings.escalationKeywords.join(", "));
          setEscalationTopics((prev) => ({
            ...prev,
            customKeywords: aiSettings.escalationKeywords || [],
          }));
        }

        // Sync enabled tools
        if (aiSettings.enabledTools) {
          const tools = aiSettings.enabledTools as string[];
          setEnabledTools({
            scheduling: tools.includes("scheduling"),
            nps: tools.includes("nps"),
            documents: tools.includes("documents"),
            patientData: tools.includes("patientData"),
          });
        }
      }
      initialLoadRef.current = false;
      if (!remindersInitialLoadRef.current) {
        setHydrationReady(true);
      }
    }
  }, [aiSettings]);

  // Sync reminders with fetched data (only on initial load to avoid overwriting user changes)
  useEffect(() => {
    if (reminderConfigs !== undefined && remindersInitialLoadRef.current) {
      const newReminders = { ...reminders };
      reminderConfigs.forEach((config: any) => {
        if (newReminders[config.type as keyof typeof reminders]) {
          newReminders[config.type as keyof typeof reminders] = {
            enabled: config.enabled,
            message: config.message,
            channels: { whatsapp: config.channels.includes("whatsapp") },
            useOfficialApi: config.useOfficialApi,
          };
        }
      });
      setReminders(newReminders);
      remindersInitialLoadRef.current = false;
      if (!initialLoadRef.current) {
        setHydrationReady(true);
      }
    }
  }, [reminderConfigs]);

  useEffect(() => {
    if (savedPrompts === undefined) return;

    const nextSelectedPromptId = savedPrompts.some((prompt: any) => prompt._id === selectedPromptId)
      ? selectedPromptId
      : aiSettings?.activePromptId || savedPrompts[0]?._id || null;

    if (nextSelectedPromptId !== selectedPromptId) {
      setSelectedPromptId(nextSelectedPromptId);
    }
  }, [savedPrompts, aiSettings?.activePromptId, selectedPromptId]);

  useEffect(() => {
    const selectedPrompt = savedPrompts?.find((prompt: any) => prompt._id === selectedPromptId);

    if (!selectedPrompt) {
      if (!selectedPromptId) {
        setPromptName("");
        setPromptContent("");
        setPromptDirty(false);
      }
      return;
    }

    setPromptName(selectedPrompt.name);
    setPromptContent(selectedPrompt.content);
    setPromptDirty(false);
  }, [savedPrompts, selectedPromptId]);

  type ReminderType = keyof typeof reminders;

  const reminderTitles: Record<ReminderType, string> = {
    appointmentConfirmation: "Confirmação de Agendamento",
    sevenDay: "Lembrete de 7 Dias",
    twentyFourHour: "Lembrete de 24 Horas",
    oneHour: "Lembrete de 1 Hora",
    noShowRecovery: "Recuperação de Faltas",
    rescheduleOptions: "Opções de Reagendamento",
    rescheduleConfirmation: "Confirmação de Reagendamento",
    confirmationReply: "Resposta de Confirmação",
    cancellationConfirmation: "Confirmação de Cancelamento",
    googleReviewFollowUp: "Pedido de Avaliação Google",
    detractorAlert: "Alerta de Detrator",
  };

  const reminderDescriptions: Record<ReminderType, string> = {
    appointmentConfirmation: "Enviado ao criar agendamento",
    sevenDay: "Pré-aviso de agendamento",
    twentyFourHour: "Confirmação principal",
    oneHour: "Urgência e local",
    noShowRecovery: "Reagendamento automático",
    rescheduleOptions: "Oferece novos horários após recusa",
    rescheduleConfirmation: "Confirma o novo horário escolhido",
    confirmationReply: "Resposta automática ao SIM do paciente",
    cancellationConfirmation: "Confirma cancelamentos automáticos",
    googleReviewFollowUp: "Follow-up após nota alta no NPS",
    detractorAlert: "Alerta interno após nota baixa no NPS",
  };

  const renderReminderIcon = (type: ReminderType) => {
    if (type === "appointmentConfirmation") return <Calendar className="text-primary w-5 h-5" />;
    if (type === "sevenDay") return <CalendarDays className="text-primary w-5 h-5" />;
    if (type === "twentyFourHour") return <MessageSquare className="text-primary w-5 h-5" />;
    if (type === "oneHour") return <Timer className="text-primary w-5 h-5" />;
    if (type === "noShowRecovery") return <XCircle className="text-muted-foreground w-5 h-5" />;
    if (type === "rescheduleOptions") return <CalendarClock className="text-primary w-5 h-5" />;
    if (type === "rescheduleConfirmation") return <Calendar className="text-green-600 w-5 h-5" />;
    if (type === "confirmationReply") return <MessageSquare className="text-green-600 w-5 h-5" />;
    if (type === "cancellationConfirmation")
      return <XCircle className="text-destructive w-5 h-5" />;
    if (type === "googleReviewFollowUp") return <Star className="text-yellow-500 w-5 h-5" />;
    return <ShieldAlert className="text-red-500 w-5 h-5" />;
  };

  // Refs for reminder textareas
  const reminderRefs = {
    appointmentConfirmation: useRef<HTMLTextAreaElement>(null),
    sevenDay: useRef<HTMLTextAreaElement>(null),
    twentyFourHour: useRef<HTMLTextAreaElement>(null),
    oneHour: useRef<HTMLTextAreaElement>(null),
    noShowRecovery: useRef<HTMLTextAreaElement>(null),
    rescheduleOptions: useRef<HTMLTextAreaElement>(null),
    rescheduleConfirmation: useRef<HTMLTextAreaElement>(null),
    confirmationReply: useRef<HTMLTextAreaElement>(null),
    cancellationConfirmation: useRef<HTMLTextAreaElement>(null),
    googleReviewFollowUp: useRef<HTMLTextAreaElement>(null),
    detractorAlert: useRef<HTMLTextAreaElement>(null),
  };

  const handleToggle = (reminderType: ReminderType) => {
    setReminders((prev) => ({
      ...prev,
      [reminderType]: {
        ...prev[reminderType],
        enabled: !prev[reminderType].enabled,
      },
    }));
  };

  const handleMessageChange = (reminderType: ReminderType, message: string) => {
    setReminders((prev) => ({
      ...prev,
      [reminderType]: {
        ...prev[reminderType],
        message,
      },
    }));
  };

  const handleApiToggle = (reminderType: ReminderType) => {
    setReminders((prev) => ({
      ...prev,
      [reminderType]: {
        ...prev[reminderType],
        useOfficialApi: !prev[reminderType].useOfficialApi,
      },
    }));
  };

  const handleSaveSettings = async () => {
    if (!clinicId) {
      console.error("No clinic ID for autosave");
      return;
    }

    try {
      setAiSaveStatus("saving");
      setAiSaveError(null);

      // Parse custom keywords from input
      const customKeywords = customKeywordsInput
        .split(",")
        .map((k) => k.trim())
        .filter((k) => k.length > 0);

      // Build enabled tools array
      const enabledToolsArray: string[] = [];
      if (enabledTools.scheduling) enabledToolsArray.push("scheduling");
      if (enabledTools.nps) enabledToolsArray.push("nps");
      if (enabledTools.documents) enabledToolsArray.push("documents");
      if (enabledTools.patientData) enabledToolsArray.push("patientData");

      await updateAiSettings({
        clinicId,
        enabled: aiEnabled,
        tone: tone as any,
        activeHoursStart,
        activeHoursEnd,
        is247,
        voiceNotesEnabled,
        responseDelaySeconds: delaySeconds[0],
        escalationTopics: {
          ...escalationTopics,
          customKeywords,
        },
        enabledTools: enabledToolsArray,
      });
      setAiSaveStatus("saved");
      setTimeout(() => setAiSaveStatus("idle"), 1500);
    } catch (error) {
      console.error("Autosave failed:", error);
      setAiSaveStatus("error");
      setAiSaveError(error instanceof Error ? error.message : "Erro ao salvar");
    }
  };

  // Autosave AI settings with debounce
  useEffect(() => {
    if (!clinicId || !hydrationReady) return;

    const timeoutId = setTimeout(() => {
      handleSaveSettings();
    }, 1000); // 1 second debounce

    return () => clearTimeout(timeoutId);
  }, [
    aiEnabled,
    tone,
    activeHoursStart,
    activeHoursEnd,
    is247,
    voiceNotesEnabled,
    delaySeconds,
    escalationTopics,
    customKeywordsInput,
    enabledTools,
    clinicId,
    hydrationReady,
  ]);

  const activePromptId = aiSettings?.activePromptId || null;
  const selectedPrompt =
    savedPrompts?.find((prompt: any) => prompt._id === selectedPromptId) || null;
  const hasLegacyInstructions =
    !activePromptId &&
    Boolean((aiSettings?.customInstructions || "").trim()) &&
    !savedPrompts?.length;

  const selectPrompt = (promptId: string) => {
    if (promptDirty && promptId !== selectedPromptId) {
      const shouldDiscard = confirm("Descartar alterações não salvas deste prompt?");
      if (!shouldDiscard) return;
    }

    setSelectedPromptId(promptId);
  };

  const handleCreatePrompt = async () => {
    if (!clinicId) return;

    if (promptDirty) {
      const shouldDiscard = confirm(
        "Descartar alterações não salvas antes de criar um novo prompt?",
      );
      if (!shouldDiscard) return;
    }

    try {
      setPromptAction("create");
      const createdPrompt = await createAiSystemPrompt({
        clinicId,
        name: `Prompt ${((savedPrompts?.length || 0) + 1).toString().padStart(2, "0")}`,
        content: "",
        makeActive: (savedPrompts?.length || 0) === 0,
      });

      setSelectedPromptId(createdPrompt?._id || null);
      toast.success("Novo prompt criado.");
    } catch (error) {
      console.error("Failed to create prompt:", error);
      toast.error(error instanceof Error ? error.message : "Erro ao criar prompt.");
    } finally {
      setPromptAction(null);
    }
  };

  const handleSavePrompt = async () => {
    if (!clinicId || !selectedPromptId) return;

    try {
      setPromptAction("save");
      await updateAiSystemPrompt({
        clinicId,
        promptId: selectedPromptId as any,
        name: promptName,
        content: promptContent,
      });
      setPromptDirty(false);
      toast.success("Prompt salvo.");
    } catch (error) {
      console.error("Failed to save prompt:", error);
      toast.error(error instanceof Error ? error.message : "Erro ao salvar prompt.");
    } finally {
      setPromptAction(null);
    }
  };

  const handleActivatePrompt = async () => {
    if (!clinicId || !selectedPromptId) return;

    if (promptDirty) {
      toast.error("Salve o prompt antes de ativar.");
      return;
    }

    try {
      setPromptAction("activate");
      await setActiveAiSystemPrompt({
        clinicId,
        promptId: selectedPromptId as any,
      });
      toast.success("Prompt ativo atualizado.");
    } catch (error) {
      console.error("Failed to activate prompt:", error);
      toast.error(error instanceof Error ? error.message : "Erro ao ativar prompt.");
    } finally {
      setPromptAction(null);
    }
  };

  const handleDeletePrompt = async () => {
    if (!clinicId || !selectedPromptId || !selectedPrompt) return;

    const confirmed = confirm(
      selectedPrompt.isActive
        ? "Excluir o prompt ativo? A IA voltará a usar apenas o prompt-base até outro prompt ser ativado."
        : `Excluir o prompt "${selectedPrompt.name}"?`,
    );

    if (!confirmed) return;

    try {
      setPromptAction("delete");
      await deleteAiSystemPrompt({
        clinicId,
        promptId: selectedPromptId as any,
      });

      const remainingPrompt = (savedPrompts || []).find(
        (prompt: any) => prompt._id !== selectedPromptId,
      );
      setSelectedPromptId(remainingPrompt?._id || null);
      setPromptDirty(false);
      toast.success("Prompt excluído.");
    } catch (error) {
      console.error("Failed to delete prompt:", error);
      toast.error(error instanceof Error ? error.message : "Erro ao excluir prompt.");
    } finally {
      setPromptAction(null);
    }
  };

  const handleImportLegacyPrompt = async () => {
    if (!clinicId || !aiSettings?.customInstructions) return;

    try {
      setPromptAction("import");
      const createdPrompt = await createAiSystemPrompt({
        clinicId,
        name: "Prompt atual",
        content: aiSettings.customInstructions,
        makeActive: true,
      });

      setSelectedPromptId(createdPrompt?._id || null);
      toast.success("Instruções atuais importadas para a biblioteca de prompts.");
    } catch (error) {
      console.error("Failed to import legacy prompt:", error);
      toast.error(error instanceof Error ? error.message : "Erro ao importar instruções atuais.");
    } finally {
      setPromptAction(null);
    }
  };

  const handleSaveReminders = async () => {
    if (!clinicId) return;

    try {
      setReminderSaveStatus("saving");
      setReminderSaveError(null);

      const promises = Object.entries(reminders).map(([type, config]) => {
        return updateReminderConfig({
          clinicId,
          type: type as any,
          enabled: config.enabled,
          message: config.message,
          channels: config.channels.whatsapp ? ["whatsapp"] : [],
          useOfficialApi: config.useOfficialApi,
        });
      });

      await Promise.all(promises);
      setReminderSaveStatus("saved");
      setTimeout(() => setReminderSaveStatus("idle"), 1500);
    } catch (error) {
      console.error("Autosave reminders failed:", error);
      setReminderSaveStatus("error");
      setReminderSaveError(error instanceof Error ? error.message : "Erro ao salvar lembretes");
    }
  };

  // Autosave reminders with debounce
  useEffect(() => {
    if (!clinicId || !hydrationReady) return;

    const timeoutId = setTimeout(() => {
      handleSaveReminders();
    }, 1000); // 1 second debounce

    return () => clearTimeout(timeoutId);
  }, [reminders, clinicId, hydrationReady]);

  const handleToggleCampaign = async (campaignId: any) => {
    if (!clinicId) return;
    try {
      await toggleCampaignStatus({ clinicId, campaignId });
      toast.success("Status da campanha atualizado!");
    } catch {
      toast.error("Erro ao atualizar campanha.");
    }
  };

  const handleDeleteCampaign = async (campaignId: any) => {
    if (!clinicId) return;
    if (!confirm("Tem certeza que deseja excluir esta campanha?")) return;

    try {
      await deleteCampaign({ clinicId, campaignId });
      toast.success("Campanha excluída com sucesso!");
    } catch {
      toast.error("Erro ao excluir campanha.");
    }
  };

  const insertVariable = (
    ref: React.RefObject<HTMLTextAreaElement | null>,
    text: string,
    setText: (val: string) => void,
    variable: string,
  ) => {
    if (ref.current) {
      const start = ref.current.selectionStart;
      const end = ref.current.selectionEnd;
      const newText = text.substring(0, start) + variable + text.substring(end);
      setText(newText);

      // Focus back
      setTimeout(() => {
        ref.current?.focus();
        const newCursorPos = start + variable.length;
        ref.current?.setSelectionRange(newCursorPos, newCursorPos);
      }, 0);
    }
  };

  const showAutomationAccessDenied = user !== undefined && user !== null && !canManageAutomation;

  return (
    <div>
      {showAutomationAccessDenied ? (
        <Card>
          <CardHeader>
            <CardTitle>Acesso restrito</CardTitle>
            <CardDescription>
              Apenas administradores podem alterar IA, lembretes e campanhas de automação.
            </CardDescription>
          </CardHeader>
        </Card>
      ) : (
        !isChildRoute && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-3xl font-bold tracking-tight">Automação Inteligente</h2>
                <p className="text-muted-foreground">
                  Gerencie o comportamento da IA, lembretes automáticos e campanhas de engajamento.
                </p>
              </div>
              <div className="flex flex-col items-end gap-1">
                <AutoSaveIndicator status={aiSaveStatus} error={aiSaveError} />
                <AutoSaveIndicator status={reminderSaveStatus} error={reminderSaveError} />
              </div>
            </div>

            <Tabs defaultValue="ai" className="space-y-6">
              <TabsList className="bg-muted p-1 rounded-md">
                <TabsTrigger value="ai" className="gap-2">
                  <Bot size={16} /> Inteligência Artificial
                </TabsTrigger>
                <TabsTrigger value="reminders" className="gap-2">
                  <CalendarClock size={16} /> Lembretes
                </TabsTrigger>
                <TabsTrigger value="campaigns" className="gap-2">
                  <Megaphone size={16} /> Campanhas
                </TabsTrigger>
              </TabsList>

              {/* --- TAB: AI SETTINGS --- */}
              <TabsContent value="ai">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-purple-100 flex items-center justify-center rounded-md text-purple-600">
                          <Bot size={20} />
                        </div>
                        <div>
                          <CardTitle>Configurações de Comportamento</CardTitle>
                          <CardDescription>
                            Personalize a personalidade e as regras de negócio do seu assistente.
                          </CardDescription>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Label htmlFor="ai-toggle-tab" className="text-sm font-medium">
                          {aiEnabled ? "IA Ativada" : "IA Desativada"}
                        </Label>
                        <Switch
                          id="ai-toggle-tab"
                          checked={aiEnabled}
                          onCheckedChange={setAiEnabled}
                        />
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {aiEnabled ? (
                      <>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-6">
                          {/* Left Column */}
                          <div className="space-y-6">
                            {/* Personality and Tone */}
                            <div className="space-y-4 p-4 border rounded-lg bg-muted/20">
                              <div className="flex items-center gap-2 font-medium">
                                <Sparkles className="w-4 h-4 text-purple-500" />
                                Personalidade e Tom
                              </div>
                              <div className="space-y-2">
                                <Label>Tom de Voz</Label>
                                <Select value={tone} onValueChange={setTone}>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Selecione o tom" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="empathetic">
                                      Empático e Acolhedor (Padrão)
                                    </SelectItem>
                                    <SelectItem value="formal">Formal e Clínico</SelectItem>
                                    <SelectItem value="casual">Casual e Amigável</SelectItem>
                                    <SelectItem value="direct">Direto e Objetivo</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>

                            {/* Tool Access - Capabilities */}
                            <div className="space-y-4 p-4 border rounded-lg">
                              <div className="flex items-center gap-2 font-medium">
                                <Bot className="w-4 h-4 text-blue-500" />
                                Capacidades do Bot
                              </div>
                              <p className="text-xs text-muted-foreground">
                                Escolha quais funcionalidades o bot pode usar automaticamente.
                              </p>

                              <div className="space-y-3">
                                <div className="flex items-center justify-between p-3 border rounded-md">
                                  <div className="flex items-center gap-3">
                                    <div className="bg-green-100 p-2 rounded-full text-green-600">
                                      <Calendar size={16} />
                                    </div>
                                    <div>
                                      <p className="font-medium text-sm">Agendamentos</p>
                                      <p className="text-xs text-muted-foreground">
                                        Buscar médicos, verificar disponibilidade e criar
                                        agendamentos
                                      </p>
                                    </div>
                                  </div>
                                  <Switch
                                    checked={enabledTools.scheduling}
                                    onCheckedChange={(checked) =>
                                      setEnabledTools((prev) => ({ ...prev, scheduling: checked }))
                                    }
                                  />
                                </div>

                                <div className="flex items-center justify-between p-3 border rounded-md">
                                  <div className="flex items-center gap-3">
                                    <div className="bg-yellow-100 p-2 rounded-full text-yellow-600">
                                      <Star size={16} />
                                    </div>
                                    <div>
                                      <p className="font-medium text-sm">Pesquisas NPS</p>
                                      <p className="text-xs text-muted-foreground">
                                        Processar avaliações e solicitar reviews no Google
                                      </p>
                                    </div>
                                  </div>
                                  <Switch
                                    checked={enabledTools.nps}
                                    onCheckedChange={(checked) =>
                                      setEnabledTools((prev) => ({ ...prev, nps: checked }))
                                    }
                                  />
                                </div>

                                <div className="flex items-center justify-between p-3 border rounded-md">
                                  <div className="flex items-center gap-3">
                                    <div className="bg-purple-100 p-2 rounded-full text-purple-600">
                                      <Image size={16} />
                                    </div>
                                    <div>
                                      <p className="font-medium text-sm">Análise de Documentos</p>
                                      <p className="text-xs text-muted-foreground">
                                        Analisar imagens, documentos e arquivos enviados
                                      </p>
                                    </div>
                                  </div>
                                  <Switch
                                    checked={enabledTools.documents}
                                    onCheckedChange={(checked) =>
                                      setEnabledTools((prev) => ({ ...prev, documents: checked }))
                                    }
                                  />
                                </div>

                                <div className="flex items-center justify-between p-3 border rounded-md">
                                  <div className="flex items-center gap-3">
                                    <div className="bg-orange-100 p-2 rounded-full text-orange-600">
                                      <UserCog size={16} />
                                    </div>
                                    <div>
                                      <p className="font-medium text-sm">Dados do Paciente</p>
                                      <p className="text-xs text-muted-foreground">
                                        Atualizar cadastro e salvar imagens do paciente
                                      </p>
                                    </div>
                                  </div>
                                  <Switch
                                    checked={enabledTools.patientData}
                                    onCheckedChange={(checked) =>
                                      setEnabledTools((prev) => ({ ...prev, patientData: checked }))
                                    }
                                  />
                                </div>

                                <div className="flex items-center justify-between p-3 border rounded-md">
                                  <div className="flex items-center gap-3">
                                    <div className="bg-blue-100 p-2 rounded-full text-blue-600">
                                      <Mic size={16} />
                                    </div>
                                    <div>
                                      <p className="font-medium text-sm">Transcrever Áudios</p>
                                      <p className="text-xs text-muted-foreground">
                                        Sempre ativo para a IA entender mensagens de voz
                                      </p>
                                    </div>
                                  </div>
                                  <Switch checked={true} disabled />
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Right Column */}
                          <div className="space-y-6">
                            {/* Operational Settings */}
                            <div className="space-y-4 p-4 border rounded-lg">
                              <h4 className="font-medium text-sm">Operacional</h4>

                              <div className="flex items-center justify-between p-3 border rounded-md">
                                <div className="flex items-center gap-2">
                                  <Zap className="w-4 h-4 text-yellow-500" />
                                  <div className="flex flex-col">
                                    <span className="text-sm font-medium">Atendimento 24/7</span>
                                    <span className="text-xs text-muted-foreground">
                                      Responder a qualquer hora
                                    </span>
                                  </div>
                                </div>
                                <Switch checked={is247} onCheckedChange={setIs247} />
                              </div>

                              {!is247 && (
                                <div className="grid grid-cols-2 gap-4">
                                  <div className="space-y-2">
                                    <Label className="text-xs">Horário Início</Label>
                                    <Input
                                      type="time"
                                      value={activeHoursStart}
                                      onChange={(e) => setActiveHoursStart(e.target.value)}
                                    />
                                  </div>
                                  <div className="space-y-2">
                                    <Label className="text-xs">Horário Fim</Label>
                                    <Input
                                      type="time"
                                      value={activeHoursEnd}
                                      onChange={(e) => setActiveHoursEnd(e.target.value)}
                                    />
                                  </div>
                                </div>
                              )}

                              <div className="pt-2">
                                <div className="flex justify-between text-sm mb-2">
                                  <span>Delay de Resposta</span>
                                  <span className="font-bold">{delaySeconds[0]}s</span>
                                </div>
                                <Slider
                                  value={delaySeconds}
                                  onValueChange={setDelaySeconds}
                                  max={60}
                                  step={1}
                                />
                              </div>
                            </div>

                            {/* Security Protocols - Escalation Topics */}
                            <div className="p-4 bg-red-50 dark:bg-red-900/10 rounded-lg border border-red-100 dark:border-red-900/20 space-y-4">
                              <div className="flex items-center gap-2 text-red-700 dark:text-red-400 font-medium text-sm">
                                <ShieldAlert size={16} /> Protocolos de Segurança
                              </div>
                              <p className="text-xs text-muted-foreground">
                                O bot irá escalar automaticamente para a equipe quando detectar
                                estes tópicos.
                              </p>

                              <div className="space-y-3">
                                <div className="flex items-center space-x-2">
                                  <Checkbox
                                    id="legal"
                                    checked={escalationTopics.legal}
                                    onCheckedChange={(checked) =>
                                      setEscalationTopics((prev) => ({ ...prev, legal: !!checked }))
                                    }
                                  />
                                  <Label htmlFor="legal" className="text-sm font-normal">
                                    Jurídico (processo, advogado, procon, justiça)
                                  </Label>
                                </div>

                                <div className="flex items-center space-x-2">
                                  <Checkbox
                                    id="medical"
                                    checked={escalationTopics.medicalEmergency}
                                    onCheckedChange={(checked) =>
                                      setEscalationTopics((prev) => ({
                                        ...prev,
                                        medicalEmergency: !!checked,
                                      }))
                                    }
                                  />
                                  <Label htmlFor="medical" className="text-sm font-normal">
                                    Emergência Médica (emergência, urgente, dor forte, sangramento)
                                  </Label>
                                </div>

                                <div className="flex items-center space-x-2">
                                  <Checkbox
                                    id="complaints"
                                    checked={escalationTopics.complaints}
                                    onCheckedChange={(checked) =>
                                      setEscalationTopics((prev) => ({
                                        ...prev,
                                        complaints: !!checked,
                                      }))
                                    }
                                  />
                                  <Label htmlFor="complaints" className="text-sm font-normal">
                                    Reclamações (reclamação, insatisfeito, péssimo, horrível)
                                  </Label>
                                </div>
                              </div>

                              <div className="space-y-2 pt-2">
                                <Label className="text-xs">Palavras-chave Personalizadas</Label>
                                <Input
                                  value={customKeywordsInput}
                                  onChange={(e) => setCustomKeywordsInput(e.target.value)}
                                  placeholder="palavra1, palavra2, palavra3..."
                                  className="h-8 text-xs bg-white dark:bg-background"
                                />
                                <p className="text-xs text-muted-foreground">
                                  Separe as palavras por vírgula
                                </p>
                              </div>
                            </div>

                            {/* Custom Instructions */}
                            <div className="p-4 border rounded-lg space-y-4">
                              <div className="flex items-center gap-2 font-medium">
                                <FileText className="w-4 h-4 text-blue-500" />
                                Prompts de Triagem
                              </div>
                              <p className="text-sm text-muted-foreground">
                                Cada prompt salvo <strong>complementa o comportamento base</strong>{" "}
                                da IA. Apenas um prompt fica ativo por vez para orientar a triagem e
                                o agendamento.
                              </p>

                              {hasLegacyInstructions && (
                                <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 space-y-3">
                                  <div>
                                    <p className="text-sm font-medium text-amber-900">
                                      Instruções legadas detectadas
                                    </p>
                                    <p className="text-xs text-amber-800/80">
                                      Suas instruções atuais ainda estao funcionando, mas ainda nao
                                      foram salvas como um prompt reutilizavel.
                                    </p>
                                  </div>
                                  <Button
                                    type="button"
                                    variant="outline"
                                    onClick={handleImportLegacyPrompt}
                                    disabled={promptAction !== null}
                                  >
                                    {promptAction === "import" && (
                                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    )}
                                    Importar instrucoes atuais
                                  </Button>
                                </div>
                              )}

                              <div className="grid grid-cols-1 xl:grid-cols-[220px,minmax(0,1fr)] gap-4">
                                <div className="space-y-3">
                                  <div className="flex items-center justify-between gap-2">
                                    <Label className="text-xs uppercase tracking-wide text-muted-foreground">
                                      Biblioteca
                                    </Label>
                                    <Button
                                      type="button"
                                      size="sm"
                                      variant="outline"
                                      onClick={handleCreatePrompt}
                                      disabled={promptAction !== null}
                                    >
                                      {promptAction === "create" ? (
                                        <Loader2 className="w-4 h-4 animate-spin" />
                                      ) : (
                                        <Plus className="w-4 h-4" />
                                      )}
                                    </Button>
                                  </div>

                                  <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
                                    {savedPrompts === undefined && (
                                      <div className="text-sm text-muted-foreground border rounded-md p-3">
                                        Carregando prompts...
                                      </div>
                                    )}

                                    {savedPrompts?.map((prompt: any) => (
                                      <button
                                        key={prompt._id}
                                        type="button"
                                        onClick={() => selectPrompt(prompt._id)}
                                        className={`w-full text-left rounded-lg border p-3 transition-colors ${selectedPromptId === prompt._id ? "border-primary bg-primary/5" : "hover:bg-muted/40"}`}
                                      >
                                        <div className="flex items-start justify-between gap-2">
                                          <div className="min-w-0">
                                            <p className="text-sm font-medium truncate">
                                              {prompt.name}
                                            </p>
                                            <p className="text-xs text-muted-foreground mt-1">
                                              Atualizado{" "}
                                              {new Date(prompt.updatedAt).toLocaleDateString(
                                                "pt-BR",
                                              )}
                                            </p>
                                          </div>
                                          {prompt.isActive && <Badge>Ativo</Badge>}
                                        </div>
                                      </button>
                                    ))}

                                    {savedPrompts !== undefined && savedPrompts.length === 0 && (
                                      <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
                                        Nenhum prompt salvo ainda.
                                      </div>
                                    )}
                                  </div>
                                </div>

                                <div className="space-y-4">
                                  {selectedPrompt ? (
                                    <>
                                      <div className="flex flex-wrap items-start justify-between gap-3">
                                        <div className="space-y-2 flex-1 min-w-[220px]">
                                          <Label htmlFor="prompt-name">Nome do prompt</Label>
                                          <Input
                                            id="prompt-name"
                                            value={promptName}
                                            onChange={(e) => {
                                              setPromptName(e.target.value);
                                              setPromptDirty(true);
                                            }}
                                            placeholder="Ex: Triagem respiratoria"
                                          />
                                        </div>
                                        <div className="flex items-center gap-2 pt-7">
                                          {selectedPrompt.isActive ? (
                                            <Badge className="bg-emerald-600 hover:bg-emerald-600">
                                              Prompt ativo
                                            </Badge>
                                          ) : (
                                            <Badge variant="outline">Prompt salvo</Badge>
                                          )}
                                        </div>
                                      </div>

                                      <div className="space-y-2">
                                        <Label htmlFor="prompt-content">Instrucoes</Label>
                                        <Textarea
                                          id="prompt-content"
                                          value={promptContent}
                                          onChange={(e) => {
                                            setPromptContent(e.target.value);
                                            setPromptDirty(true);
                                          }}
                                          placeholder="Ex: Priorizar sintomas respiratorios, perguntar intensidade e tempo de evolucao antes de oferecer horarios. Em sinais de gravidade, orientar pronto-socorro imediatamente..."
                                          rows={10}
                                          className="resize-none"
                                        />
                                        <p className="text-xs text-muted-foreground">
                                          Dica: descreva regras objetivas de triagem, excecoes da
                                          clinica e preferencias operacionais.
                                        </p>
                                      </div>

                                      <div className="flex flex-wrap items-center justify-between gap-2 border-t pt-3">
                                        <p className="text-xs text-muted-foreground">
                                          O prompt ativo complementa o prompt-base e preserva as
                                          regras obrigatorias de ferramentas e seguranca.
                                        </p>
                                        <div className="flex flex-wrap gap-2">
                                          <Button
                                            type="button"
                                            variant="outline"
                                            onClick={handleActivatePrompt}
                                            disabled={
                                              promptAction !== null ||
                                              !selectedPromptId ||
                                              selectedPrompt.isActive ||
                                              promptDirty
                                            }
                                          >
                                            {promptAction === "activate" && (
                                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            )}
                                            Ativar
                                          </Button>
                                          <Button
                                            type="button"
                                            variant="outline"
                                            className="text-destructive hover:bg-destructive/10"
                                            onClick={handleDeletePrompt}
                                            disabled={promptAction !== null || !selectedPromptId}
                                          >
                                            {promptAction === "delete" ? (
                                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            ) : (
                                              <Trash2 className="w-4 h-4 mr-2" />
                                            )}
                                            Excluir
                                          </Button>
                                          <Button
                                            type="button"
                                            onClick={handleSavePrompt}
                                            disabled={
                                              promptAction !== null ||
                                              !selectedPromptId ||
                                              !promptDirty
                                            }
                                          >
                                            {promptAction === "save" ? (
                                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            ) : (
                                              <Save className="w-4 h-4 mr-2" />
                                            )}
                                            Salvar prompt
                                          </Button>
                                        </div>
                                      </div>
                                    </>
                                  ) : (
                                    <div className="rounded-lg border border-dashed p-6 text-center space-y-3">
                                      <p className="text-sm font-medium">
                                        Selecione ou crie um prompt
                                      </p>
                                      <p className="text-sm text-muted-foreground">
                                        Monte bibliotecas de prompts para diferentes estrategias de
                                        triagem e deixe apenas um ativo por vez.
                                      </p>
                                      <Button
                                        type="button"
                                        variant="outline"
                                        onClick={handleCreatePrompt}
                                        disabled={promptAction !== null}
                                      >
                                        <Plus className="w-4 h-4 mr-2" />
                                        Criar primeiro prompt
                                      </Button>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-12 text-center space-y-4">
                        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center">
                          <Bot className="w-8 h-8 text-muted-foreground" />
                        </div>
                        <div className="space-y-2">
                          <h3 className="font-semibold text-lg">A IA está desativada</h3>
                          <p className="text-muted-foreground max-w-sm">
                            Ative a inteligência artificial para automatizar o atendimento e as
                            respostas aos seus pacientes.
                          </p>
                        </div>
                        <Button onClick={() => setAiEnabled(true)}>Ativar IA Agora</Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* --- TAB: REMINDERS --- */}
              <TabsContent value="reminders">
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {Object.entries(reminders).map(([type, config]) => (
                      <Card
                        key={type}
                        className={`flex flex-col ${type === "noShowRecovery" ? "border-dashed" : ""}`}
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              {renderReminderIcon(type as ReminderType)}
                              <CardTitle className="text-base">
                                {reminderTitles[type as ReminderType]}
                              </CardTitle>
                            </div>
                            <Switch
                              checked={config.enabled}
                              onCheckedChange={() => handleToggle(type as ReminderType)}
                            />
                          </div>
                          <CardDescription>
                            {reminderDescriptions[type as ReminderType]}
                          </CardDescription>
                        </CardHeader>
                        {config.enabled && (
                          <CardContent className="flex-1 space-y-4">
                            <div className="space-y-2">
                              <div className="flex justify-between items-center">
                                <Label>Mensagem</Label>
                                <VariableInserter
                                  onInsert={(v) =>
                                    insertVariable(
                                      reminderRefs[type as ReminderType],
                                      config.message,
                                      (val) => handleMessageChange(type as ReminderType, val),
                                      v,
                                    )
                                  }
                                />
                              </div>
                              <Textarea
                                ref={reminderRefs[type as ReminderType]}
                                value={config.message}
                                onChange={(e) =>
                                  handleMessageChange(type as ReminderType, e.target.value)
                                }
                                rows={4}
                                className="resize-none"
                              />
                            </div>
                            <div className="flex items-center justify-between pt-2 border-t">
                              <div className="flex items-center gap-2">
                                <Label htmlFor={`${type}-api`} className="text-sm font-normal">
                                  API Oficial
                                </Label>
                                <Switch
                                  id={`${type}-api`}
                                  checked={config.useOfficialApi}
                                  onCheckedChange={() => handleApiToggle(type as ReminderType)}
                                />
                              </div>
                              {config.channels.whatsapp && (
                                <div className="flex gap-2">
                                  <Badge
                                    variant="outline"
                                    className="bg-green-50 text-green-700 border-green-200"
                                  >
                                    WhatsApp
                                  </Badge>
                                </div>
                              )}
                            </div>
                          </CardContent>
                        )}
                      </Card>
                    ))}
                  </div>
                  <div className="flex justify-end pt-4"></div>
                </div>
              </TabsContent>

              {/* --- TAB: CAMPAIGNS --- */}
              <TabsContent value="campaigns">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-orange-100 flex items-center justify-center rounded-md text-orange-600">
                          <Zap size={20} />
                        </div>
                        <div>
                          <CardTitle>Engajamento e Campanhas</CardTitle>
                          <CardDescription>
                            Sequências automáticas para pós-venda e fidelização.
                          </CardDescription>
                        </div>
                      </div>
                      <Button
                        onClick={() => {
                          setEditingCampaign(null);
                          setShowCampaignModal(true);
                        }}
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Criar Campanha
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {campaignsList?.map((campaign: any) => (
                        <div
                          key={campaign._id}
                          className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <div
                              className={`w-2 h-2 rounded-full ${campaign.status === "active" ? "bg-green-500" : "bg-yellow-500"}`}
                            />
                            <div>
                              <p className="font-medium">{campaign.name}</p>
                              <p className="text-xs text-muted-foreground">
                                {campaign.steps.length} mensagens • {campaign.triggerCount} disparos
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant={campaign.status === "active" ? "default" : "secondary"}>
                              {campaign.status === "active" ? "Ativa" : "Pausada"}
                            </Badge>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                setEditingCampaign(campaign);
                                setShowCampaignModal(true);
                              }}
                              title="Editar campanha"
                            >
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleToggleCampaign(campaign._id)}
                            >
                              {campaign.status === "active" ? "Pausar" : "Ativar"}
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-destructive hover:bg-destructive/10"
                              onClick={() => handleDeleteCampaign(campaign._id)}
                            >
                              <XCircle className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                      {campaignsList === undefined && (
                        <div className="text-center py-8 text-muted-foreground text-sm">
                          Carregando campanhas...
                        </div>
                      )}
                      {campaignsList !== undefined && campaignsList.length === 0 && (
                        <div className="text-center py-8 text-muted-foreground text-sm">
                          Nenhuma campanha criada ainda.
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            <CampaignBuilderModal
              open={showCampaignModal}
              onOpenChange={(open) => {
                setShowCampaignModal(open);
                if (!open) setEditingCampaign(null);
              }}
              editingCampaign={editingCampaign}
            />
          </div>
        )
      )}
      <Outlet />
    </div>
  );
}
