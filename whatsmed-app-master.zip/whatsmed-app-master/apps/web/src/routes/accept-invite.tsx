import { Link, useSearch, useNavigate } from "@tanstack/react-router";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation } from "convex/react";
import { Loader2 } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { authClient } from "@/lib/auth-client";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

export const Route = createFileRoute("/accept-invite")({
  component: AcceptInvitePage,
  validateSearch: (search: Record<string, unknown>) => {
    return {
      token: (search.token as string) || "",
    };
  },
});

function AcceptInvitePage() {
  const { token } = useSearch({ from: "/accept-invite" }) as { token: string };
  const navigate = useNavigate();

  // State
  const [inviteDetails, setInviteDetails] = useState<{
    email: string;
    clinicName: string;
    role: string;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Mutations
  const getInvite = useMutation(api.invites.getByToken);
  const acceptInvite = useMutation(api.invites.accept);

  // Session
  const { data: session, isPending: isSessionPending } = authClient.useSession();

  // Fetch Invite
  useEffect(() => {
    if (!token) {
      setError("Token inválido ou ausente.");
      setIsLoading(false);
      return;
    }

    getInvite({ token })
      .then((data) => {
        setInviteDetails(data);
        setIsLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setError(err?.message ?? "Este convite é inválido ou já expirou.");
        setIsLoading(false);
      });
  }, [token, getInvite]);

  // Handle Accept for Existing User
  const handleAcceptExisting = async () => {
    setIsSubmitting(true);
    try {
      if (!session?.user) {
        // Should not happen if UI is correct, but just in case
        toast.error("Você precisa estar logado para aceitar.");
        return;
      }

      if (session.user.email !== inviteDetails?.email) {
        toast.error("O email do convite não corresponde ao usuário logado.");
        return;
      }

      await acceptInvite({
        token,
      });

      toast.success("Convite aceito com sucesso!");
      navigate({ to: "/dashboard" });
    } catch (err) {
      console.error(err);
      toast.error("Erro ao aceitar convite.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Registration & Accept
  const handleRegisterAndAccept = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      toast.error("As senhas não coincidem.");
      return;
    }

    if (password.length < 8) {
      toast.error("A senha deve ter pelo menos 8 caracteres.");
      return;
    }

    setIsSubmitting(true);
    try {
      // 1. Sign Up using Auth Client
      const { data, error } = await authClient.signUp.email({
        email: inviteDetails!.email,
        password,
        name,
        callbackURL: "/dashboard", // We handle redirect manually after accept
      });

      if (error) {
        throw new Error(error.message);
      }

      if (!data?.user?.id) {
        throw new Error("Falha ao criar usuário");
      }

      // 2. Accept Invite
      await acceptInvite({
        token,
      });

      toast.success("Conta criada e convite aceito!");
      navigate({ to: "/dashboard" });
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || "Erro ao criar conta.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading || isSessionPending) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-muted/30">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-destructive">Erro no Convite</CardTitle>
            <CardDescription>{error}</CardDescription>
          </CardHeader>
          <CardFooter>
            <Button asChild className="w-full">
              <Link to="/login" search={{ redirect: "/accept-invite" }}>
                Voltar para Login
              </Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  // Case 1: User is logged in
  if (session?.user) {
    const isCorrectUser = session.user.email === inviteDetails?.email;

    return (
      <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Aceitar Convite</CardTitle>
            <CardDescription>
              Você foi convidado para participar da clínica{" "}
              <strong>{inviteDetails?.clinicName}</strong>.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isCorrectUser ? (
              <div className="flex flex-col items-center gap-4 py-4">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xl font-bold">
                  {session.user.name?.charAt(0).toUpperCase()}
                </div>
                <div className="text-center">
                  <p className="font-medium">{session.user.name}</p>
                  <p className="text-sm text-muted-foreground">{session.user.email}</p>
                </div>
                <p className="text-sm text-center text-muted-foreground mt-2">
                  Deseja aceitar o convite e vincular esta clínica à sua conta?
                </p>
              </div>
            ) : (
              <div className="bg-destructive/10 p-4 rounded-md text-sm text-destructive">
                Você está logado como <strong>{session.user.email}</strong>, mas este convite é para{" "}
                <strong>{inviteDetails?.email}</strong>.
                <br />
                <br />
                Por favor, faça logout para aceitar este convite.
              </div>
            )}
          </CardContent>
          <CardFooter className="flex flex-col gap-2">
            {isCorrectUser ? (
              <Button className="w-full" onClick={handleAcceptExisting} disabled={isSubmitting}>
                {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Aceitar e Entrar
              </Button>
            ) : (
              <Button variant="outline" className="w-full" onClick={() => authClient.signOut()}>
                Sair da conta atual
              </Button>
            )}
          </CardFooter>
        </Card>
      </div>
    );
  }

  // Case 2: User is NOT logged in (Registration)
  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Criar sua conta</CardTitle>
          <CardDescription>
            Configure sua senha para aceitar o convite da clínica{" "}
            <strong>{inviteDetails?.clinicName}</strong>.
          </CardDescription>
        </CardHeader>
        <form onSubmit={handleRegisterAndAccept}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">E-mail</Label>
              <Input id="email" value={inviteDetails?.email} disabled className="bg-muted" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Nome Completo</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Seu nome"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={8}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirmar Senha</Label>
              <Input
                id="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-2">
            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Criar Conta e Aceitar
            </Button>
            <div className="text-center text-sm text-muted-foreground mt-2">
              Já tem uma conta?{" "}
              <Link
                to="/login"
                search={{ redirect: `/accept-invite?token=${token}` }}
                className="underline"
              >
                Faça login
              </Link>
            </div>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
