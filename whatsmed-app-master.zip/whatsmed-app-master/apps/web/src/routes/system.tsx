import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useAction, useQuery } from "convex/react";
import { ArrowRight, Eye, Plus, Search, ChevronsUpDown, Building } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useCreateClinic, useClinicsList, useSetClinicPlan } from "@/hooks/clinics";
import { useImpersonation } from "@/hooks/impersonation";
import { useClinicId } from "@/hooks/patients";
import { cn } from "@/lib/utils";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

interface Clinic {
  _id: string;
  clinicId: string;
  name: string;
  plan?: PlanType;
  planStatus?: "active" | "past_due" | "canceled" | "trialing";
}

type PlanType = "free" | "starter" | "professional" | "enterprise";

const PLAN_OPTIONS: Array<{ value: PlanType; label: string }> = [
  { value: "free", label: "Gratuito" },
  { value: "starter", label: "Inicial" },
  { value: "professional", label: "Profissional" },
  { value: "enterprise", label: "Empresarial" },
];

interface SystemUser {
  _id: string;
  authUserId?: string;
  clinicId: string;
  email: string;
  name: string;
  role: "admin" | "staff" | "viewer" | "doctor" | "super_admin";
  isActive?: boolean;
}

export const Route = createFileRoute("/system")({ component: SystemPage });

function SystemPage() {
  const navigate = useNavigate();
  const { startImpersonation } = useImpersonation();
  const { actualRole, impersonation, isImpersonating } = useClinicId();
  const createClinic = useCreateClinic();
  const setClinicPlan = useSetClinicPlan();
  const createUserAction = useAction(api.users.createUser);
  const clinicsQuery = useClinicsList();
  const clinics = (clinicsQuery ?? []) as Clinic[];
  const loading = clinicsQuery === undefined;
  const [selectedSystemClinicId, setSelectedSystemClinicId] = useState("");
  const [userSearchTerm, setUserSearchTerm] = useState("");
  const [showCreateUserModal, setShowCreateUserModal] = useState(false);
  const [userData, setUserData] = useState({
    email: "",
    name: "",
    role: "staff" as "admin" | "staff" | "viewer" | "doctor",
    clinicId: "",
    password: "",
  });
  const [clinicSearchOpen, setClinicSearchOpen] = useState(false);
  const [clinicSearchTerm, setClinicSearchTerm] = useState("");
  const [selectedClinic, setSelectedClinic] = useState<Clinic | null>(null);
  const [initialPlan, setInitialPlan] = useState<PlanType>("free");
  const [clinicPlanDrafts, setClinicPlanDrafts] = useState<Record<string, PlanType>>({});
  const [savingClinicPlanId, setSavingClinicPlanId] = useState<string | null>(null);
  const [newClinicName, setNewClinicName] = useState("");
  const [newClinicId, setNewClinicId] = useState("");
  const [createNewClinic, setCreateNewClinic] = useState(false);
  const [creatingClinic, setCreatingClinic] = useState(false);
  const systemUsersResult = useQuery(
    api.users.list,
    selectedSystemClinicId
      ? {
          clinicId: selectedSystemClinicId,
          search: userSearchTerm || undefined,
        }
      : "skip",
  );
  const systemUsers = (systemUsersResult?.items ?? []) as SystemUser[];
  const selectedSystemClinic =
    clinics.find((clinic) => clinic.clinicId === selectedSystemClinicId) ?? null;

  const resetCreateUserForm = () => {
    setShowCreateUserModal(false);
    setUserData({
      email: "",
      name: "",
      role: "staff",
      clinicId: "",
      password: "",
    });
    setSelectedClinic(null);
    setCreateNewClinic(false);
    setInitialPlan("free");
    setNewClinicId("");
    setNewClinicName("");
    setClinicSearchOpen(false);
    setClinicSearchTerm("");
  };

  const getPlanLabel = (plan?: PlanType) =>
    PLAN_OPTIONS.find((option) => option.value === plan)?.label ?? "Gratuito";

  const getRoleLabel = (value: SystemUser["role"] | string) => {
    switch (value) {
      case "admin":
        return "Administrador";
      case "super_admin":
        return "Super Admin";
      case "doctor":
        return "Médico";
      case "viewer":
        return "Visualizador";
      default:
        return "Equipe";
    }
  };

  // Check if user is super_admin
  useEffect(() => {
    if (actualRole && actualRole !== "super_admin") {
      toast.error("Acesso negado. Apenas super administradores podem acessar esta página.");
      // Redirect to dashboard if not super_admin
      window.location.href = "/dashboard";
    }
  }, [actualRole]);

  useEffect(() => {
    if (!selectedSystemClinicId && clinics.length > 0) {
      setSelectedSystemClinicId(clinics[0].clinicId);
    }
  }, [clinics, selectedSystemClinicId]);

  const handleCreateClinic = async () => {
    if (!newClinicId || !newClinicName) {
      toast.error("Preencha o ID e nome da clínica");
      return;
    }

    setCreatingClinic(true);
    try {
      const clinic = await createClinic({
        clinicId: newClinicId,
        name: newClinicName,
        plan: initialPlan,
      });

      if (!clinic) {
        throw new Error("Não foi possível criar clínica");
      }

      setSelectedClinic(clinic as Clinic);
      setUserData({ ...userData, clinicId: clinic.clinicId });
      setCreateNewClinic(false);
      setInitialPlan("free");
      setNewClinicId("");
      setNewClinicName("");
      toast.success("Clínica criada com sucesso!");
    } catch (err: any) {
      toast.error(err.message || "Erro ao criar clínica");
    } finally {
      setCreatingClinic(false);
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userData.clinicId) {
      toast.error("Selecione ou crie uma clínica");
      return;
    }
    if (!userData.password) {
      toast.error("Senha é obrigatória");
      return;
    }

    try {
      await createUserAction({
        email: userData.email,
        name: userData.name,
        role: userData.role,
        password: userData.password,
        clinicId: userData.clinicId,
      });

      toast.success("Usuário criado com sucesso!");
      resetCreateUserForm();
    } catch (err: any) {
      toast.error(err.message || "Erro ao criar usuário");
    }
  };

  const handleUpdateClinicPlan = async (clinicId: string) => {
    const plan =
      clinicPlanDrafts[clinicId] ?? clinics.find((clinic) => clinic.clinicId === clinicId)?.plan;
    if (!plan) {
      return;
    }

    setSavingClinicPlanId(clinicId);
    try {
      await setClinicPlan({ clinicId, plan });
      toast.success("Plano da clínica atualizado com sucesso!");
    } catch (err: any) {
      toast.error(err.message || "Erro ao atualizar plano da clínica");
    } finally {
      setSavingClinicPlanId(null);
    }
  };

  const filteredClinics = clinics.filter(
    (clinic) =>
      clinic.name.toLowerCase().includes(clinicSearchTerm.toLowerCase()) ||
      clinic.clinicId.toLowerCase().includes(clinicSearchTerm.toLowerCase()),
  );

  const handleImpersonateUser = async (user: SystemUser) => {
    startImpersonation({
      userId: user._id,
      authUserId: user.authUserId,
      clinicId: user.clinicId,
      clinicName: selectedSystemClinic?.name,
      email: user.email,
      name: user.name,
      role: user.role,
    });

    toast.success(`Agora voce esta visualizando como ${user.name}`);
    await navigate({ to: "/dashboard" });
  };

  if (actualRole !== "super_admin") {
    return null; // Or a loading/unauthorized message
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Sistema</h1>
        <p className="text-muted-foreground mt-2">
          Gerencie clínicas, crie contas e visualize a experiência de qualquer usuário
        </p>
      </div>

      {isImpersonating && impersonation && (
        <Card className="border-amber-500/30 bg-amber-500/10">
          <CardHeader>
            <CardTitle>Visualização ativa</CardTitle>
            <CardDescription>
              Você está navegando como {impersonation.name} ({impersonation.email}).
            </CardDescription>
          </CardHeader>
        </Card>
      )}

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-6">
          <div>
            <CardTitle>Clínicas</CardTitle>
            <CardDescription>Lista de todas as clínicas cadastradas no sistema</CardDescription>
          </div>
          <Button onClick={() => setShowCreateUserModal(true)}>
            <Plus size={18} className="mr-2" />
            Criar Usuário
          </Button>
        </CardHeader>

        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-muted-foreground">Carregando clínicas...</div>
          ) : clinics.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">Nenhuma clínica cadastrada</div>
          ) : (
            <div className="space-y-4">
              {clinics.map((clinic) => (
                <div
                  key={clinic._id}
                  className="flex flex-col gap-4 rounded-lg border bg-muted/50 p-4 md:flex-row md:items-center md:justify-between"
                >
                  <div>
                    <h4 className="font-medium text-foreground">{clinic.name}</h4>
                    <p className="text-sm text-muted-foreground">ID: {clinic.clinicId}</p>
                    <p className="text-sm text-muted-foreground">
                      Plano atual: {getPlanLabel(clinic.plan)}
                    </p>
                  </div>

                  <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                    <Select
                      value={clinicPlanDrafts[clinic.clinicId] ?? clinic.plan ?? "free"}
                      onValueChange={(value: PlanType) =>
                        setClinicPlanDrafts((current) => ({
                          ...current,
                          [clinic.clinicId]: value,
                        }))
                      }
                    >
                      <SelectTrigger className="w-full sm:w-[180px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PLAN_OPTIONS.map((plan) => (
                          <SelectItem key={plan.value} value={plan.value}>
                            {plan.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <Button
                      variant="outline"
                      onClick={() => handleUpdateClinicPlan(clinic.clinicId)}
                      disabled={
                        savingClinicPlanId === clinic.clinicId ||
                        (clinicPlanDrafts[clinic.clinicId] ?? clinic.plan ?? "free") ===
                          (clinic.plan ?? "free")
                      }
                    >
                      {savingClinicPlanId === clinic.clinicId ? "Salvando..." : "Salvar plano"}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Impersonar usuário</CardTitle>
          <CardDescription>
            Selecione uma clínica e abra o dashboard com o contexto visual daquele usuário.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-[280px_minmax(0,1fr)]">
            <div className="space-y-2">
              <Label htmlFor="system-clinic">Clínica</Label>
              <Select value={selectedSystemClinicId} onValueChange={setSelectedSystemClinicId}>
                <SelectTrigger id="system-clinic">
                  <SelectValue placeholder="Selecione uma clínica" />
                </SelectTrigger>
                <SelectContent>
                  {clinics.map((clinic) => (
                    <SelectItem key={clinic._id} value={clinic.clinicId}>
                      {clinic.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="user-search">Buscar usuário</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="user-search"
                  className="pl-9"
                  placeholder="Filtrar por nome ou e-mail"
                  value={userSearchTerm}
                  onChange={(e) => setUserSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </div>

          {!selectedSystemClinicId ? (
            <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
              Selecione uma clínica para listar seus usuários.
            </div>
          ) : systemUsersResult === undefined ? (
            <div className="rounded-lg border p-6 text-sm text-muted-foreground">
              Carregando usuários...
            </div>
          ) : systemUsers.length === 0 ? (
            <div className="rounded-lg border p-6 text-sm text-muted-foreground">
              Nenhum usuário encontrado para esta clínica.
            </div>
          ) : (
            <div className="space-y-3">
              {systemUsers.map((user) => {
                const isCurrentTarget = impersonation?.userId === user._id;

                return (
                  <div
                    key={user._id}
                    className="flex flex-col gap-4 rounded-xl border bg-card p-4 md:flex-row md:items-center md:justify-between"
                  >
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-medium text-foreground">{user.name}</h3>
                        <span className="rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">
                          {getRoleLabel(user.role)}
                        </span>
                        {isCurrentTarget && (
                          <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-xs text-amber-700">
                            Ativo agora
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{user.email}</p>
                    </div>

                    <Button
                      variant={isCurrentTarget ? "secondary" : "default"}
                      className="gap-2 self-start md:self-center"
                      onClick={() => handleImpersonateUser(user)}
                    >
                      {isCurrentTarget ? <Eye size={16} /> : <ArrowRight size={16} />}
                      {isCurrentTarget ? "Atualizar contexto" : "Ver como usuário"}
                    </Button>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create User Modal */}
      <Dialog
        open={showCreateUserModal}
        onOpenChange={(open) => {
          if (!open) {
            resetCreateUserForm();
            return;
          }
          setShowCreateUserModal(true);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Criar Usuário</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCreateUser} className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="clinicId">Clínica *</Label>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setCreateNewClinic(!createNewClinic);
                    if (!createNewClinic) {
                      setSelectedClinic(null);
                      setUserData({ ...userData, clinicId: "" });
                      setInitialPlan("free");
                    }
                  }}
                >
                  {createNewClinic ? "Buscar existente" : "Criar nova"}
                </Button>
              </div>

              {createNewClinic ? (
                <div className="space-y-2">
                  <Input
                    placeholder="ID da clínica (ex: clinic-001)"
                    value={newClinicId}
                    onChange={(e) => setNewClinicId(e.target.value)}
                    required={createNewClinic}
                  />
                  <Input
                    placeholder="Nome da clínica"
                    value={newClinicName}
                    onChange={(e) => setNewClinicName(e.target.value)}
                    required={createNewClinic}
                  />
                  <div className="space-y-2">
                    <Label htmlFor="initialPlan">Plano inicial</Label>
                    <Select
                      value={initialPlan}
                      onValueChange={(value: PlanType) => setInitialPlan(value)}
                    >
                      <SelectTrigger id="initialPlan">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PLAN_OPTIONS.map((plan) => (
                          <SelectItem key={plan.value} value={plan.value}>
                            {plan.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleCreateClinic}
                    className="w-full"
                    disabled={creatingClinic}
                  >
                    {creatingClinic ? "Criando..." : "Criar Clínica"}
                  </Button>
                </div>
              ) : (
                <Popover open={clinicSearchOpen} onOpenChange={setClinicSearchOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={clinicSearchOpen}
                      className="w-full justify-between"
                    >
                      {selectedClinic ? (
                        <div className="flex items-center gap-2">
                          <Building size={16} />
                          {selectedClinic.name} ({selectedClinic.clinicId})
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Search size={16} />
                          Buscar clínica...
                        </div>
                      )}
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
                    <div className="p-2 border-b">
                      <Input
                        placeholder="Digite para buscar..."
                        value={clinicSearchTerm}
                        onChange={(e) => setClinicSearchTerm(e.target.value)}
                        className="border-none focus-visible:ring-0"
                        autoFocus
                      />
                    </div>
                    <div className="max-h-[200px] overflow-y-auto p-1">
                      {filteredClinics.length === 0 ? (
                        <div className="py-6 text-center text-sm text-muted-foreground">
                          Nenhuma clínica encontrada.
                        </div>
                      ) : (
                        filteredClinics.map((clinic) => (
                          <div
                            key={clinic._id}
                            className={cn(
                              "flex flex-col px-3 py-2 text-sm rounded-sm cursor-pointer hover:bg-accent hover:text-accent-foreground",
                              selectedClinic?._id === clinic._id &&
                                "bg-accent text-accent-foreground",
                            )}
                            onClick={() => {
                              setSelectedClinic(clinic);
                              setUserData({ ...userData, clinicId: clinic.clinicId });
                              setClinicSearchOpen(false);
                            }}
                          >
                            <span className="font-medium">{clinic.name}</span>
                            <span className="text-xs text-muted-foreground">
                              ID: {clinic.clinicId}
                            </span>
                          </div>
                        ))
                      )}
                    </div>
                  </PopoverContent>
                </Popover>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">Nome *</Label>
              <Input
                id="name"
                value={userData.name}
                onChange={(e) => setUserData({ ...userData, name: e.target.value })}
                placeholder="Nome completo"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">E-mail *</Label>
              <Input
                id="email"
                type="email"
                value={userData.email}
                onChange={(e) => setUserData({ ...userData, email: e.target.value })}
                placeholder="usuario@exemplo.com"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Senha *</Label>
              <Input
                id="password"
                type="password"
                value={userData.password}
                onChange={(e) => setUserData({ ...userData, password: e.target.value })}
                placeholder="Senha do usuário"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">Função *</Label>
              <Select
                value={userData.role}
                onValueChange={(val: any) => setUserData({ ...userData, role: val })}
                required
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="staff">Equipe</SelectItem>
                  <SelectItem value="admin">Administrador</SelectItem>
                  <SelectItem value="viewer">Visualizador</SelectItem>
                  <SelectItem value="doctor">Médico</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={resetCreateUserForm}>
                Cancelar
              </Button>
              <Button type="submit">Criar Usuário</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
