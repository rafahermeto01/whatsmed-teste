import { createFileRoute, Link } from "@tanstack/react-router";
import { Plus, Settings, CreditCard, Calendar, AlertTriangle, Loader2, Crown } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";

import { AddFundsModal } from "@/components/billing/AddFundsModal";
import { AutoRechargeModal } from "@/components/billing/AutoRechargeModal";
import { CreditsWidget } from "@/components/billing/CreditsWidget";
import { ManageCardsModal } from "@/components/billing/ManageCardsModal";
import { PlanSelectionModal } from "@/components/billing/PlanSelectionModal";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import {
  useBillingPaymentMethods,
  useBillingSubscription,
  useBillingTransactions,
  useBillingWallet,
  useCancelSubscription,
  useInitializeWalletFromClinic,
} from "@/hooks/billing";
import { useClinic } from "@/hooks/clinics";
import { useClinicId, usePermissions } from "@/hooks/patients";

export const Route = createFileRoute("/billing")({ component: BillingPage });

// Plan name mapping
const PLAN_NAMES: Record<string, string> = {
  free: "Gratuito",
  starter: "Inicial",
  professional: "Profissional",
  enterprise: "Empresarial",
};

const attemptedWalletInitKeys = new Set<string>();
const inFlightWalletInitKeys = new Set<string>();

function BillingPage() {
  const { clinicId } = useClinicId();
  const { canManageBilling } = usePermissions();
  const [showAddFundsModal, setShowAddFundsModal] = useState(false);
  const [showAutoRechargeModal, setShowAutoRechargeModal] = useState(false);
  const [showManageCardsModal, setShowManageCardsModal] = useState(false);
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [initializing, setInitializing] = useState(false);
  const [walletInitError, setWalletInitError] = useState<string | null>(null);
  const [canceling, setCanceling] = useState(false);

  const effectiveClinicId = canManageBilling ? clinicId : undefined;

  const clinic = useClinic(effectiveClinicId);
  const wallet = useBillingWallet(effectiveClinicId);
  const transactionsQuery = useBillingTransactions({ clinicId: effectiveClinicId, limit: 20 });
  const paymentMethods = useBillingPaymentMethods(effectiveClinicId);
  const subscription = useBillingSubscription(effectiveClinicId);
  const cancelSubscription = useCancelSubscription();
  const initializeWalletFromClinic = useInitializeWalletFromClinic();

  const transactions = transactionsQuery?.page || [];
  const defaultCard = paymentMethods?.find((m: any) => m.isDefault);

  const walletBalance = wallet?.balance ?? 0;
  const autoRechargeEnabled = wallet?.autoRechargeEnabled ?? false;

  // Get current plan from clinic
  const currentPlan = clinic?.plan || "free";
  const planStatus = clinic?.planStatus || "active";
  const hasManagedSubscription = Boolean(clinic?.asaasSubscriptionId && subscription);

  // Check if wallet needs Asaas setup (exists but no asaasCustomerId, or doesn't exist)
  const walletNeedsAsaasSetup = wallet === null || (wallet && !wallet.asaasCustomerId);
  const walletInitKey =
    effectiveClinicId && clinic?.cpfCnpj ? `${effectiveClinicId}:${clinic.cpfCnpj}` : null;

  useEffect(() => {
    setWalletInitError(null);
  }, [walletInitKey]);

  // Auto-initialize wallet when clinic has CPF/CNPJ but wallet needs Asaas setup
  useEffect(() => {
    const tryInitialize = async () => {
      if (
        walletInitKey &&
        walletNeedsAsaasSetup &&
        !initializing &&
        !attemptedWalletInitKeys.has(walletInitKey) &&
        !inFlightWalletInitKeys.has(walletInitKey)
      ) {
        if (!effectiveClinicId) return;
        attemptedWalletInitKeys.add(walletInitKey);
        inFlightWalletInitKeys.add(walletInitKey);
        setInitializing(true);
        setWalletInitError(null);
        try {
          const result = await initializeWalletFromClinic({ clinicId: effectiveClinicId });
          if (result.needsSetup) {
            setWalletInitError(
              result.errorMessage ||
                "Revise o CPF/CNPJ da clínica antes de configurar o faturamento.",
            );
          } else if (result.created) {
            toast.success("Conta de pagamento configurada automaticamente!");
          } else if (result.asaasLinked) {
            toast.success("Conta de pagamento vinculada ao Asaas!");
          }
        } catch (error: unknown) {
          console.error("Failed to auto-initialize wallet:", error);
          setWalletInitError(
            error instanceof Error ? error.message : "Erro ao configurar conta de pagamento",
          );
          toast.error("Erro ao configurar conta de pagamento");
        } finally {
          inFlightWalletInitKeys.delete(walletInitKey);
          setInitializing(false);
        }
      }
    };

    tryInitialize();
  }, [
    effectiveClinicId,
    initializeWalletFromClinic,
    initializing,
    walletInitKey,
    walletNeedsAsaasSetup,
  ]);

  const handleCancelSubscription = async () => {
    if (!effectiveClinicId) return;

    if (
      !confirm(
        "Tem certeza que deseja cancelar sua assinatura? Você será movido para o plano gratuito.",
      )
    ) {
      return;
    }

    setCanceling(true);
    try {
      await cancelSubscription({ clinicId: effectiveClinicId });
      toast.success("Assinatura cancelada. Você foi movido para o plano gratuito.");
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : "Erro ao cancelar assinatura";
      toast.error(errorMessage);
    } finally {
      setCanceling(false);
    }
  };

  if (!clinicId) return <div className="p-8">Carregando...</div>;

  if (!canManageBilling) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Acesso restrito</CardTitle>
          <CardDescription>
            Apenas administradores podem gerenciar carteira e assinatura da clínica.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  // Show loading while initializing wallet or waiting for data
  if (wallet === undefined || initializing) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        <p className="text-muted-foreground">Carregando...</p>
      </div>
    );
  }

  // Show setup message if billing data is missing or invalid
  if (wallet === null && (!clinic || !clinic.cpfCnpj || walletInitError?.includes("CPF/CNPJ"))) {
    return (
      <div className="max-w-xl mx-auto py-12">
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 h-16 w-16 rounded-full bg-yellow-100 dark:bg-yellow-900/20 flex items-center justify-center">
              <AlertTriangle className="h-8 w-8 text-yellow-600 dark:text-yellow-500" />
            </div>
            <CardTitle className="text-xl">Configure seus dados fiscais</CardTitle>
            <CardDescription>
              {walletInitError ||
                "Para utilizar o sistema de cobrança, você precisa cadastrar um CPF/CNPJ válido nas configurações."}
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <Link to="/settings">
              <Button>
                <Settings className="mr-2 h-4 w-4" />
                Ir para Configurações
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Still waiting for wallet to be created or linked to Asaas
  if (walletNeedsAsaasSetup && clinic?.cpfCnpj && !walletInitError) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        <p className="text-muted-foreground">Configurando conta de pagamento...</p>
      </div>
    );
  }

  if (walletNeedsAsaasSetup && walletInitError) {
    return (
      <div className="max-w-xl mx-auto py-12">
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 h-16 w-16 rounded-full bg-red-100 dark:bg-red-900/20 flex items-center justify-center">
              <AlertTriangle className="h-8 w-8 text-red-600 dark:text-red-500" />
            </div>
            <CardTitle className="text-xl">Erro ao configurar conta</CardTitle>
            <CardDescription>{walletInitError}</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center gap-3">
            <Button
              variant="outline"
              onClick={() => {
                if (walletInitKey) {
                  attemptedWalletInitKeys.delete(walletInitKey);
                  inFlightWalletInitKeys.delete(walletInitKey);
                }
                setWalletInitError(null);
              }}
            >
              Tentar novamente
            </Button>
            <Link to="/settings">
              <Button>
                <Settings className="mr-2 h-4 w-4" />
                Revisar Configurações
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Final safety check
  if (!wallet || !wallet.asaasCustomerId) {
    return (
      <div className="max-w-xl mx-auto py-12">
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 h-16 w-16 rounded-full bg-red-100 dark:bg-red-900/20 flex items-center justify-center">
              <AlertTriangle className="h-8 w-8 text-red-600 dark:text-red-500" />
            </div>
            <CardTitle className="text-xl">Erro ao carregar conta</CardTitle>
            <CardDescription>
              Não foi possível carregar sua conta de pagamento. Tente recarregar a página.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <Button onClick={() => window.location.reload()}>Recarregar Página</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const currentPlanName = PLAN_NAMES[currentPlan] || "Gratuito";

  return (
    <div className="space-y-6">
      {/* Top Row - Wallet Balance and Auto-Recharge */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Wallet Balance Widget */}
        <Card
          className="border-none text-white overflow-hidden relative"
          style={{
            background: "linear-gradient(135deg, var(--primary) 0%, oklch(0.6 0.15 250) 100%)",
          }}
        >
          <CardContent className="p-8 relative z-10">
            <p className="text-white/80 mb-2 font-medium">Saldo Atual</p>
            <h2 className="text-4xl font-bold text-white mb-6">R$ {walletBalance.toFixed(2)}</h2>
            <Button
              variant="secondary"
              className="bg-white text-primary hover:bg-white/90"
              onClick={() => setShowAddFundsModal(true)}
            >
              <Plus size={18} className="mr-2" />
              Adicionar Fundos
            </Button>
          </CardContent>
          <div className="absolute -right-8 -top-8 w-32 h-32 rounded-full bg-white/10" />
          <div className="absolute -right-4 -bottom-4 w-24 h-24 rounded-full bg-white/10" />
        </Card>

        {/* Auto-Recharge Indicator */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-foreground font-medium mb-2">Recarga Automática</h3>
                <div className="flex items-center gap-2">
                  <div
                    className={`w-2 h-2 rounded-full ${autoRechargeEnabled ? "bg-green-500" : "bg-gray-400"}`}
                  />
                  <span className="text-sm text-muted-foreground">
                    {autoRechargeEnabled ? "Ativa" : "Inativa"}
                  </span>
                </div>
              </div>
              <Settings size={20} className="text-muted-foreground" />
            </div>

            {autoRechargeEnabled && wallet && (
              <div className="p-3 bg-muted rounded-md mb-4">
                <p className="text-sm text-foreground mb-1">
                  Quando o saldo cair abaixo de{" "}
                  <strong>R$ {wallet.autoRechargeThreshold?.toFixed(2)}</strong>
                </p>
                <p className="text-sm text-foreground">
                  Adicionar automaticamente{" "}
                  <strong>R$ {wallet.autoRechargeAmount?.toFixed(2)}</strong>
                </p>
              </div>
            )}

            <Button
              variant="outline"
              className="w-full"
              onClick={() => setShowAutoRechargeModal(true)}
            >
              Configurar Recarga Automática
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Credits Widget */}
      <CreditsWidget />

      {/* Subscription/Plan Card */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Crown className="h-5 w-5 text-yellow-500" />
                Plano Atual
              </CardTitle>
              <CardDescription>Gerencie a assinatura da sua clínica</CardDescription>
            </div>
            {planStatus !== "active" && planStatus !== "trialing" && (
              <Badge variant="destructive">
                {planStatus === "past_due" ? "Pagamento Atrasado" : "Cancelado"}
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row justify-between gap-6">
            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Plano</p>
                <p className="text-2xl font-bold">{currentPlanName}</p>
              </div>

              {currentPlan !== "free" && hasManagedSubscription && subscription && (
                <>
                  <div>
                    <p className="text-sm text-muted-foreground">Valor</p>
                    <p className="text-lg font-medium">R$ {subscription.value.toFixed(2)} / mês</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Próxima Cobrança</p>
                    <div className="flex items-center gap-2">
                      <Calendar size={16} className="text-muted-foreground" />
                      <span>{new Date(subscription.nextDueDate).toLocaleDateString("pt-BR")}</span>
                    </div>
                  </div>
                  {subscription.creditCard && (
                    <div>
                      <p className="text-sm text-muted-foreground">Cartão</p>
                      <div className="flex items-center gap-2">
                        <CreditCard size={16} className="text-muted-foreground" />
                        <span>
                          {subscription.creditCard.brand} •••• {subscription.creditCard.last4}
                        </span>
                      </div>
                    </div>
                  )}
                </>
              )}

              {currentPlan !== "free" && !hasManagedSubscription && (
                <div className="p-3 bg-muted rounded-md">
                  <p className="text-sm text-muted-foreground">
                    Plano definido manualmente pelo super admin. Esta clínica não possui assinatura
                    gerenciada pelo faturamento.
                  </p>
                </div>
              )}

              {currentPlan === "free" && (
                <div className="p-3 bg-muted rounded-md">
                  <p className="text-sm text-muted-foreground">
                    Faça upgrade para desbloquear mais recursos e aumentar seus limites.
                  </p>
                </div>
              )}
            </div>

            <div className="space-y-2 min-w-[200px]">
              <Button className="w-full" onClick={() => setShowPlanModal(true)}>
                {currentPlan === "free" ? "Fazer Upgrade" : "Alterar Plano"}
              </Button>
              {currentPlan !== "free" && hasManagedSubscription && (
                <Button
                  variant="outline"
                  className="w-full text-destructive hover:text-destructive"
                  onClick={handleCancelSubscription}
                  disabled={canceling}
                >
                  {canceling ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                  Cancelar Assinatura
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payment Methods Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium">Métodos de Pagamento</h3>
            <Button variant="outline" size="sm" onClick={() => setShowManageCardsModal(true)}>
              Gerenciar Cartões
            </Button>
          </div>

          {defaultCard ? (
            <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
              <div className="w-12 h-12 bg-primary flex items-center justify-center rounded-md">
                <CreditCard size={24} className="text-primary-foreground" />
              </div>
              <div>
                <p className="font-medium">
                  {defaultCard.brand} terminando em {defaultCard.last4}
                </p>
                <p className="text-sm text-muted-foreground">Cartão padrão</p>
              </div>
            </div>
          ) : (
            <div className="text-center py-4">
              <p className="text-muted-foreground text-sm mb-3">Nenhum cartão cadastrado.</p>
              <Button variant="outline" size="sm" onClick={() => setShowManageCardsModal(true)}>
                Adicionar Cartão
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Spending History Table */}
      <Card>
        <CardHeader className="border-b px-6 py-4">
          <CardTitle className="text-base">Histórico de Transações</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead className="px-6">Data</TableHead>
                <TableHead className="px-6">Descrição</TableHead>
                <TableHead className="px-6 text-right">Valor</TableHead>
                <TableHead className="px-6 text-center">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions.length > 0 ? (
                transactions.map((transaction: any) => (
                  <TableRow key={transaction._id}>
                    <TableCell className="px-6">
                      {new Date(transaction.createdAt).toLocaleDateString("pt-BR")}
                    </TableCell>
                    <TableCell className="px-6">
                      {transaction.type === "topup"
                        ? "Recarga"
                        : transaction.type === "refund"
                          ? "Reembolso"
                          : "Débito"}
                    </TableCell>
                    <TableCell
                      className={`px-6 text-right font-medium ${
                        transaction.type === "topup" || transaction.type === "refund"
                          ? "text-green-600 dark:text-green-400"
                          : ""
                      }`}
                    >
                      {transaction.type === "topup" || transaction.type === "refund" ? "+" : "-"}
                      R$ {transaction.amount.toFixed(2)}
                    </TableCell>
                    <TableCell className="px-6 text-center">
                      <span
                        className={`text-xs px-2 py-1 rounded-full ${
                          transaction.status === "succeeded"
                            ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
                            : transaction.status === "pending"
                              ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400"
                              : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"
                        }`}
                      >
                        {transaction.status === "succeeded"
                          ? "Confirmado"
                          : transaction.status === "pending"
                            ? "Pendente"
                            : "Falhou"}
                      </span>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                    Nenhuma transação encontrada.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Modals */}
      <PlanSelectionModal
        open={showPlanModal}
        onOpenChange={setShowPlanModal}
        clinicId={effectiveClinicId!}
        currentPlan={currentPlan}
        hasCard={!!defaultCard}
        onNeedCard={() => setShowManageCardsModal(true)}
      />
      <AddFundsModal open={showAddFundsModal} onOpenChange={setShowAddFundsModal} />
      <AutoRechargeModal open={showAutoRechargeModal} onOpenChange={setShowAutoRechargeModal} />
      <ManageCardsModal open={showManageCardsModal} onOpenChange={setShowManageCardsModal} />
    </div>
  );
}
