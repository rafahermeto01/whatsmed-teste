import { createFileRoute } from "@tanstack/react-router";
import { startOfMonth, endOfMonth, format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Calendar, Users, UserPlus, ChevronLeft, ChevronRight } from "lucide-react";
import { useState, useMemo, useCallback } from "react";
import { toast } from "sonner";

import { AppointmentDetailsModal } from "@/components/AppointmentDetailsModal";
import { KanbanBoard, AppointmentCardContent, PatientCardContent } from "@/components/kanban";
import { PatientProfileModal } from "@/components/PatientProfileModal";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  useKanbanAppointments,
  useRemarketingPatients,
  useNewPatients,
  useUpdateAppointmentStatus,
  useUpdateRemarketingStage,
  useUpdateLeadStage,
} from "@/hooks/kanban";
import { useClinicId } from "@/hooks/patients";

import type { Id } from "@whatsmed-app/backend/convex/_generated/dataModel";

export const Route = createFileRoute("/kanban")({
  component: KanbanPage,
});

type ViewType = "appointments" | "remarketing" | "new_patients";

// Column definitions for each view
const APPOINTMENT_COLUMNS = [
  { id: "pending", title: "Pendente", color: "bg-yellow-500" },
  { id: "confirmed", title: "Confirmada", color: "bg-green-500" },
  { id: "arrived", title: "Na Recepção", color: "bg-purple-500" },
  { id: "completed", title: "Concluída", color: "bg-blue-500" },
  { id: "cancelled", title: "Cancelada", color: "bg-red-500" },
];

const REMARKETING_COLUMNS = [
  { id: "needs_contact", title: "Precisa Contato", color: "bg-orange-500" },
  { id: "contacted", title: "Contatado", color: "bg-blue-500" },
  { id: "scheduled", title: "Agendado", color: "bg-green-500" },
  { id: "not_interested", title: "Sem Interesse", color: "bg-gray-500" },
];

const NEW_PATIENTS_COLUMNS = [
  { id: "new_lead", title: "Novo Lead", color: "bg-purple-500" },
  { id: "contacted", title: "Contatado", color: "bg-blue-500" },
  { id: "scheduled", title: "Agendado", color: "bg-green-500" },
  { id: "converted", title: "Convertido", color: "bg-emerald-500" },
];

function KanbanPage() {
  const [activeView, setActiveView] = useState<ViewType>("appointments");
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedAppointment, setSelectedAppointment] = useState<any>(null);
  const [selectedPatient, setSelectedPatient] = useState<any>(null);

  const { clinicId } = useClinicId();

  // Date range for appointments view
  const { startAt, endAt } = useMemo(() => {
    const start = startOfMonth(currentMonth);
    const end = endOfMonth(currentMonth);
    return { startAt: start.getTime(), endAt: end.getTime() };
  }, [currentMonth]);

  // Queries
  const appointmentsData = useKanbanAppointments({
    clinicId,
    startAt,
    endAt,
    limitPerColumn: 20,
  });

  const remarketingData = useRemarketingPatients({
    clinicId,
    limitPerColumn: 20,
  });

  const newPatientsData = useNewPatients({
    clinicId,
    limitPerColumn: 20,
  });

  // Mutations
  const updateAppointmentStatus = useUpdateAppointmentStatus();
  const updateRemarketingStage = useUpdateRemarketingStage();
  const updateLeadStage = useUpdateLeadStage();

  // Navigation handlers
  const prevMonth = useCallback(() => {
    setCurrentMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() - 1));
  }, []);

  const nextMonth = useCallback(() => {
    setCurrentMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() + 1));
  }, []);

  // Drag-and-drop handlers
  const handleAppointmentDragEnd = useCallback(
    async (itemId: string, _fromColumn: string, toColumn: string) => {
      if (!clinicId) return;

      try {
        await updateAppointmentStatus({
          appointmentId: itemId as Id<"appointments">,
          clinicId,
          status: toColumn as any,
        });
        toast.success("Status atualizado");
      } catch (error: any) {
        toast.error(error.message || "Erro ao atualizar status");
      }
    },
    [clinicId, updateAppointmentStatus],
  );

  const handleRemarketingDragEnd = useCallback(
    async (itemId: string, _fromColumn: string, toColumn: string) => {
      if (!clinicId) return;

      try {
        await updateRemarketingStage({
          patientId: itemId as Id<"patients">,
          clinicId,
          stage: toColumn as any,
        });
        toast.success("Estágio atualizado");
      } catch (error: any) {
        toast.error(error.message || "Erro ao atualizar estágio");
      }
    },
    [clinicId, updateRemarketingStage],
  );

  const handleNewPatientDragEnd = useCallback(
    async (itemId: string, _fromColumn: string, toColumn: string) => {
      if (!clinicId) return;

      try {
        await updateLeadStage({
          patientId: itemId as Id<"patients">,
          clinicId,
          stage: toColumn as any,
        });
        toast.success("Estágio atualizado");
      } catch (error: any) {
        toast.error(error.message || "Erro ao atualizar estágio");
      }
    },
    [clinicId, updateLeadStage],
  );

  // Build columns for appointments
  const appointmentColumns = useMemo(() => {
    if (!appointmentsData) return APPOINTMENT_COLUMNS.map((col) => ({ ...col, items: [] }));

    return APPOINTMENT_COLUMNS.map((col) => ({
      ...col,
      items: (appointmentsData as any)[col.id] || [],
    }));
  }, [appointmentsData]);

  // Build columns for remarketing
  const remarketingColumns = useMemo(() => {
    if (!remarketingData) return REMARKETING_COLUMNS.map((col) => ({ ...col, items: [] }));

    return REMARKETING_COLUMNS.map((col) => ({
      ...col,
      items: (remarketingData as any)[col.id] || [],
    }));
  }, [remarketingData]);

  // Build columns for new patients
  const newPatientsColumns = useMemo(() => {
    if (!newPatientsData) return NEW_PATIENTS_COLUMNS.map((col) => ({ ...col, items: [] }));

    return NEW_PATIENTS_COLUMNS.map((col) => ({
      ...col,
      items: (newPatientsData as any)[col.id] || [],
    }));
  }, [newPatientsData]);

  // Render appointment card
  const renderAppointmentCard = useCallback(
    (item: any) => (
      <AppointmentCardContent
        patientName={item.patientName}
        patientPhone={item.patientPhone}
        startAt={item.startAt}
        doctor={item.doctor}
        procedure={item.procedure}
        status={item.status}
        onClick={() => setSelectedAppointment(item)}
      />
    ),
    [],
  );

  // Render patient card for remarketing
  const renderRemarketingCard = useCallback(
    (item: any) => (
      <PatientCardContent
        name={item.name}
        phone={item.phone}
        email={item.email}
        lastCompletedAppointmentAt={item.lastCompletedAppointmentAt}
        nextScheduledAppointmentAt={item.nextScheduledAppointmentAt}
        stage={item.remarketingStage}
        onClick={() => setSelectedPatient(item)}
      />
    ),
    [],
  );

  // Render patient card for new patients
  const renderNewPatientCard = useCallback(
    (item: any) => (
      <PatientCardContent
        name={item.name}
        phone={item.phone}
        email={item.email}
        stage={item.leadStage}
        onClick={() => setSelectedPatient(item)}
      />
    ),
    [],
  );

  return (
    <div className="space-y-6 p-6">
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Kanban</h1>
          <p className="text-muted-foreground text-sm">
            Gerencie o ciclo de vida dos agendamentos e pacientes
          </p>
        </div>
      </div>

      <Tabs value={activeView} onValueChange={(v) => setActiveView(v as ViewType)}>
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <TabsList>
            <TabsTrigger value="appointments" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Agendamentos
            </TabsTrigger>
            <TabsTrigger value="remarketing" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Remarketing
            </TabsTrigger>
            <TabsTrigger value="new_patients" className="flex items-center gap-2">
              <UserPlus className="w-4 h-4" />
              Novos Pacientes
            </TabsTrigger>
          </TabsList>

          {/* Month navigation for appointments view */}
          {activeView === "appointments" && (
            <div className="flex items-center gap-4">
              <Button variant="outline" size="icon" onClick={prevMonth}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm font-medium min-w-[140px] text-center capitalize">
                {format(currentMonth, "MMMM yyyy", { locale: ptBR })}
              </span>
              <Button variant="outline" size="icon" onClick={nextMonth}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>

        {/* Appointments View */}
        <TabsContent value="appointments" className="mt-6">
          <KanbanBoard
            columns={appointmentColumns}
            onDragEnd={handleAppointmentDragEnd}
            renderCard={renderAppointmentCard}
            isLoading={!appointmentsData}
          />
        </TabsContent>

        {/* Remarketing View */}
        <TabsContent value="remarketing" className="mt-6">
          <div className="mb-4">
            <p className="text-sm text-muted-foreground">
              Pacientes com consultas anteriores mas sem retorno agendado
            </p>
          </div>
          <KanbanBoard
            columns={remarketingColumns}
            onDragEnd={handleRemarketingDragEnd}
            renderCard={renderRemarketingCard}
            isLoading={!remarketingData}
          />
        </TabsContent>

        {/* New Patients View */}
        <TabsContent value="new_patients" className="mt-6">
          <div className="mb-4">
            <p className="text-sm text-muted-foreground">
              Pacientes que ainda não realizaram uma consulta na clínica
            </p>
          </div>
          <KanbanBoard
            columns={newPatientsColumns}
            onDragEnd={handleNewPatientDragEnd}
            renderCard={renderNewPatientCard}
            isLoading={!newPatientsData}
          />
        </TabsContent>
      </Tabs>

      {/* Appointment Details Modal */}
      {selectedAppointment && (
        <AppointmentDetailsModal
          appointment={selectedAppointment}
          onClose={() => setSelectedAppointment(null)}
        />
      )}

      {/* Patient Profile Modal */}
      {selectedPatient && (
        <PatientProfileModal
          patientId={selectedPatient._id}
          clinicId={clinicId || ""}
          open={!!selectedPatient}
          onOpenChange={(open) => !open && setSelectedPatient(null)}
        />
      )}
    </div>
  );
}
