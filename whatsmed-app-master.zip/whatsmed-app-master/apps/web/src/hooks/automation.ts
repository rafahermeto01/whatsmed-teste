import { useMutation, useQuery } from "convex/react";

import { api } from "@whatsmed-app/backend/convex/_generated/api";

/**
 * AI Settings Hooks
 */

/**
 * Fetch AI settings for current clinic
 */
export function useAiSettings(_initialClinicId?: string) {
  const user = useQuery(api.auth.getCurrentUserWithClinic);
  const clinicId = user?.clinicId;

  return useQuery(api.automation.getAiSettings, clinicId ? { clinicId } : "skip");
}

/**
 * Update AI settings mutation
 */
export function useUpdateAiSettings() {
  return useMutation(api.automation.updateAiSettings);
}

/**
 * Toggle AI enabled status mutation
 */
export function useToggleAiEnabled() {
  return useMutation(api.automation.toggleAiEnabled);
}

/**
 * Update fallback channels (escalation keywords) mutation
 */
export function useUpdateFallbackChannels() {
  return useMutation(api.automation.updateFallbackChannels);
}

/**
 * Get clinic agent status
 */
export function useClinicAgentStatus(clinicId?: string) {
  return useQuery(api.automationAiHelpers.getClinicAgentStatus, clinicId ? { clinicId } : "skip");
}

// ============================================
// REMINDER CONFIGS HOOKS
// ============================================

/**
 * Get all reminder configs for current clinic
 */
export function useReminderConfigs(clinicId?: string) {
  const user = useQuery(api.auth.getCurrentUserWithClinic);
  const currentClinicId = user?.clinicId;
  const selectedClinicId = clinicId || currentClinicId;

  return useQuery(
    api.automation.getReminderConfigs,
    selectedClinicId ? { clinicId: selectedClinicId } : "skip",
  );
}

/**
 * Update a reminder config mutation
 */
export function useUpdateReminderConfig() {
  return useMutation(api.automation.updateReminderConfig);
}

/**
 * Toggle a reminder config enabled status mutation
 */
export function useToggleReminder() {
  return useMutation(api.automation.toggleReminder);
}

// ============================================
// CAMPAIGN BUILDER HOOKS
// ============================================

/**
 * List all campaigns for current clinic
 */
export function useCampaigns(clinicId?: string, status?: "active" | "paused" | "draft") {
  const user = useQuery(api.auth.getCurrentUserWithClinic);
  const currentClinicId = user?.clinicId;
  const selectedClinicId = clinicId || currentClinicId;

  return useQuery(
    api.automation.listCampaigns,
    selectedClinicId ? { clinicId: selectedClinicId, status } : "skip",
  );
}

/**
 * Get a single campaign by ID
 */
export function useCampaign(clinicId: string, campaignId: string) {
  return useQuery(api.automation.getCampaign, clinicId ? { clinicId, campaignId } : "skip");
}

/**
 * Create a new campaign mutation
 */
export function useCreateCampaign() {
  return useMutation(api.automation.createCampaign);
}

/**
 * Update a campaign mutation
 */
export function useUpdateCampaign() {
  return useMutation(api.automation.updateCampaign);
}

/**
 * Delete a campaign mutation
 */
export function useDeleteCampaign() {
  return useMutation(api.automation.deleteCampaign);
}

/**
 * Toggle campaign status mutation
 */
export function useToggleCampaignStatus() {
  return useMutation(api.automation.toggleCampaignStatus);
}

// ============================================
// COMBINED HOOKS (for convenience)
// ============================================

/**
 * Hook to manage all automation settings
 * Returns loading states and mutation functions
 */
export function useAutomation(clinicId?: string) {
  // Queries
  const aiSettings = useAiSettings(clinicId);
  const reminderConfigs = useReminderConfigs(clinicId);
  const campaigns = useCampaigns(clinicId);

  // Mutations
  const updateAiSettings = useUpdateAiSettings();
  const toggleAiEnabled = useToggleAiEnabled();
  const updateFallbackChannels = useUpdateFallbackChannels();
  const updateReminderConfig = useUpdateReminderConfig();
  const toggleReminder = useToggleReminder();
  const createCampaign = useCreateCampaign();
  const updateCampaign = useUpdateCampaign();
  const deleteCampaign = useDeleteCampaign();
  const toggleCampaignStatus = useToggleCampaignStatus();

  const isLoading = aiSettings.isLoading || reminderConfigs.isLoading || campaigns.isLoading;

  const isError = aiSettings.error || reminderConfigs.error || campaigns.error;

  return {
    // Data
    aiSettings: aiSettings.data,
    reminderConfigs: reminderConfigs.data,
    campaigns: campaigns.data,

    // Mutations
    updateAiSettings,
    toggleAiEnabled,
    updateFallbackChannels,
    updateReminderConfig,
    toggleReminder,
    createCampaign,
    updateCampaign,
    deleteCampaign,
    toggleCampaignStatus,

    // States
    isLoading,
    isError,
  };
}

/**
 * Hook for campaign CRUD operations
 * Simplified interface for campaign management
 */
export function useCampaignManager(clinicId?: string) {
  const campaigns = useCampaigns(clinicId);

  const createCampaign = useCreateCampaign();
  const updateCampaign = useUpdateCampaign();
  const deleteCampaign = useDeleteCampaign();
  const toggleCampaignStatus = useToggleCampaignStatus();

  return {
    campaigns: campaigns.data,
    isLoading: campaigns.isLoading,
    error: campaigns.error,

    createCampaign,
    isCreating: false,
    createCampaignError: null,

    updateCampaign,
    isUpdating: false,
    updateCampaignError: null,

    deleteCampaign,
    isDeleting: false,
    deleteCampaignError: null,

    toggleCampaignStatus,
    isToggling: false,
    toggleError: null,
  };
}
