import { useQuery, useMutation } from "convex/react";
import { useMemo } from "react";

import { useImpersonation } from "@/hooks/impersonation";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

export function useClinicId() {
  const authUser = useQuery(api.auth.getCurrentUser);
  const { impersonation } = useImpersonation();

  const actualEmail = authUser?.email as string | undefined;
  const actualClinicFromAuth = authUser?.clinicId as string | undefined;
  const actualAppUser = useQuery(
    api.users.getByEmail,
    actualEmail ? { email: actualEmail } : "skip",
  );

  const actualClinicId = actualClinicFromAuth ?? (actualAppUser?.clinicId as string | undefined);
  const actualRole =
    (actualAppUser?.role as string | undefined) ?? (authUser?.role as string | undefined);

  const effectiveImpersonation = actualRole === "super_admin" ? impersonation : null;
  const impersonatedAppUser = useQuery(
    api.users.getByEmail,
    effectiveImpersonation?.email ? { email: effectiveImpersonation.email } : "skip",
  );

  const appUser = effectiveImpersonation ? impersonatedAppUser : actualAppUser;
  const clinicId =
    (appUser?.clinicId as string | undefined) ?? effectiveImpersonation?.clinicId ?? actualClinicId;
  const role = (appUser?.role as string | undefined) ?? effectiveImpersonation?.role ?? actualRole;

  const user = useMemo(() => {
    if (!effectiveImpersonation) return authUser;

    return {
      ...(authUser ?? {}),
      _id: effectiveImpersonation.authUserId ?? authUser?._id,
      email: appUser?.email ?? effectiveImpersonation.email,
      name: appUser?.name ?? effectiveImpersonation.name,
      clinicId,
      role,
    };
  }, [appUser, authUser, clinicId, effectiveImpersonation, role]);

  return {
    clinicId,
    role,
    user,
    appUser,
    actualUser: authUser,
    actualAppUser,
    actualClinicId,
    actualRole,
    impersonation: effectiveImpersonation,
    isImpersonating: !!effectiveImpersonation,
  };
}

export function useEffectiveCurrentUser() {
  const { clinicId, role, user, appUser, impersonation, isImpersonating } = useClinicId();

  return useMemo(() => {
    if (user === undefined && !impersonation) return undefined;
    if (!user && !impersonation) return null;

    return {
      clinicId,
      email: appUser?.email ?? impersonation?.email ?? user?.email ?? "",
      name: appUser?.name ?? impersonation?.name ?? user?.name ?? "",
      role,
      isImpersonating,
    };
  }, [appUser, clinicId, impersonation, isImpersonating, role, user]);
}

export function useEffectiveAppUser() {
  const { appUser } = useClinicId();
  return appUser;
}

export function usePermissions() {
  const { role } = useClinicId();

  return useMemo(() => {
    const isAdmin = role === "admin" || role === "super_admin";
    const isDoctor = role === "doctor";
    const isStaff = role === "staff";
    const canAccessSettings = isAdmin || isDoctor || isStaff;

    return {
      role,
      isAdmin,
      isDoctor,
      isStaff,
      canAccessSettings,
      canManageClinicSettings: isAdmin,
      canManageClinicUsers: isAdmin,
      canManageClinicDocuments: isAdmin,
      canViewAuditLogs: isAdmin,
      canManageAutomation: isAdmin,
      canManageBilling: isAdmin,
      canManageOwnDoctorSettings: isAdmin || isDoctor,
    };
  }, [role]);
}

export function usePatientsList(args: {
  clinicId?: string;
  status?: "active" | "inactive";
  search?: string;
  limit?: number;
  cursor?: string;
  sortBy?: "createdAt" | "status";
  order?: "asc" | "desc";
  dateStart?: number;
  dateEnd?: number;
  hasEmail?: boolean;
  hasPhone?: boolean;
  externalId?: string;
  orFilters?: boolean;
}) {
  const {
    clinicId,
    status,
    search,
    limit,
    cursor,
    sortBy,
    order,
    dateStart,
    dateEnd,
    hasEmail,
    hasPhone,
    externalId,
    orFilters,
  } = args;

  const canRun = !!clinicId;
  const queryArgs = useMemo(() => {
    if (!canRun) return "skip" as const;
    return {
      clinicId: clinicId!,
      status,
      search,
      limit: limit ?? 50,
      cursor,
      sortBy,
      order,
      dateStart,
      dateEnd,
      hasEmail,
      hasPhone,
      externalId,
      orFilters,
    };
  }, [
    canRun,
    clinicId,
    status,
    search,
    limit,
    cursor,
    sortBy,
    order,
    dateStart,
    dateEnd,
    hasEmail,
    hasPhone,
    externalId,
    orFilters,
  ]);

  const result = useQuery(api.patients.list, queryArgs);
  return result;
}

export function useCreatePatient() {
  return useMutation(api.patients.create);
}

export function useUpdatePatient() {
  return useMutation(api.patients.update);
}

export function useDeletePatient() {
  return useMutation(api.patients.softDelete);
}

export function useImportPatients() {
  return useMutation(api.patients.importBatch);
}
