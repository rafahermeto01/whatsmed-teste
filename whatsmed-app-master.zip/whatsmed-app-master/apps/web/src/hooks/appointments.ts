import { useQuery, useMutation } from "convex/react";
import { useMemo } from "react";

import { useClinicId } from "./patients";
import { api } from "@whatsmed-app/backend/convex/_generated/api";

import type { Id } from "@whatsmed-app/backend/convex/_generated/dataModel";

export { useClinicId };

export function useAppointmentsList(args: {
  clinicId?: string;
  status?: "pending" | "confirmed" | "cancelled" | "completed";
  patientId?: string;
  startAt?: number;
  endAt?: number;
  limit?: number;
  cursor?: string;
}) {
  // Destructure to use primitives in dependency array - prevents infinite loops
  // when callers pass new object references with same values
  const { clinicId, status, patientId, startAt, endAt, limit, cursor } = args;
  const canRun = !!clinicId;

  const queryArgs = useMemo(() => {
    if (!canRun) return "skip" as const;
    return {
      clinicId: clinicId!,
      status,
      patientId: patientId as Id<"patients">,
      startAt,
      endAt,
      limit: limit ?? 50,
      cursor,
    };
  }, [canRun, clinicId, status, patientId, startAt, endAt, limit, cursor]);

  return useQuery(api.appointments.list, queryArgs);
}

export function useCreateAppointment() {
  return useMutation(api.appointments.create);
}

export function useUpdateAppointment() {
  return useMutation(api.appointments.update);
}

export function useDeleteAppointment() {
  return useMutation(api.appointments.softDelete);
}
