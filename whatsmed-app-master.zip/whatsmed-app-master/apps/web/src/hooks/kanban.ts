import { useQuery, useMutation } from "convex/react";

import { api } from "@whatsmed-app/backend/convex/_generated/api";

// =============================================================================
// KANBAN QUERIES
// =============================================================================

export function useKanbanAppointments(args: {
  clinicId?: string;
  startAt?: number;
  endAt?: number;
  limitPerColumn?: number;
}) {
  const { clinicId, startAt, endAt, limitPerColumn } = args;

  return useQuery(
    api.kanban.listAppointmentsByStatus,
    clinicId
      ? {
          clinicId,
          startAt,
          endAt,
          limitPerColumn,
        }
      : "skip",
  );
}

export function useRemarketingPatients(args: { clinicId?: string; limitPerColumn?: number }) {
  const { clinicId, limitPerColumn } = args;

  return useQuery(
    api.kanban.listRemarketingPatients,
    clinicId
      ? {
          clinicId,
          limitPerColumn,
        }
      : "skip",
  );
}

export function useNewPatients(args: { clinicId?: string; limitPerColumn?: number }) {
  const { clinicId, limitPerColumn } = args;

  return useQuery(
    api.kanban.listNewPatients,
    clinicId
      ? {
          clinicId,
          limitPerColumn,
        }
      : "skip",
  );
}

// =============================================================================
// KANBAN MUTATIONS
// =============================================================================

export function useUpdateAppointmentStatus() {
  return useMutation(api.kanban.updateAppointmentStatus);
}

export function useUpdateRemarketingStage() {
  return useMutation(api.kanban.updateRemarketingStage);
}

export function useUpdateLeadStage() {
  return useMutation(api.kanban.updateLeadStage);
}
