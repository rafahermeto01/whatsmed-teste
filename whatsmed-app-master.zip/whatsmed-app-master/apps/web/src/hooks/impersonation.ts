import { useCallback, useEffect, useState } from "react";

const IMPERSONATION_STORAGE_KEY = "whatsmed.super-admin-impersonation";
const IMPERSONATION_EVENT = "whatsmed-impersonation-changed";

export type ImpersonationRole = "admin" | "staff" | "viewer" | "doctor" | "super_admin";

export interface ImpersonationSession {
  userId: string;
  authUserId?: string;
  clinicId: string;
  clinicName?: string;
  email: string;
  name: string;
  role: ImpersonationRole;
  startedAt: number;
}

type StartImpersonationInput = Omit<ImpersonationSession, "startedAt">;

function isBrowser() {
  return typeof window !== "undefined";
}

function isValidSession(value: unknown): value is ImpersonationSession {
  if (!value || typeof value !== "object") return false;

  const candidate = value as Record<string, unknown>;

  return (
    typeof candidate.userId === "string" &&
    typeof candidate.clinicId === "string" &&
    typeof candidate.email === "string" &&
    typeof candidate.name === "string" &&
    typeof candidate.role === "string" &&
    typeof candidate.startedAt === "number"
  );
}

function readStoredImpersonation(): ImpersonationSession | null {
  if (!isBrowser()) return null;

  try {
    const stored = window.localStorage.getItem(IMPERSONATION_STORAGE_KEY);
    if (!stored) return null;

    const parsed = JSON.parse(stored);
    return isValidSession(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

function notifyImpersonationChange() {
  if (!isBrowser()) return;
  window.dispatchEvent(new Event(IMPERSONATION_EVENT));
}

export function startImpersonationSession(
  session: StartImpersonationInput,
): ImpersonationSession | null {
  if (!isBrowser()) return null;

  const nextSession: ImpersonationSession = {
    ...session,
    startedAt: Date.now(),
  };

  window.localStorage.setItem(IMPERSONATION_STORAGE_KEY, JSON.stringify(nextSession));
  notifyImpersonationChange();

  return nextSession;
}

export function stopImpersonationSession() {
  if (!isBrowser()) return;

  window.localStorage.removeItem(IMPERSONATION_STORAGE_KEY);
  notifyImpersonationChange();
}

export function useImpersonation() {
  const [impersonation, setImpersonation] = useState<ImpersonationSession | null>(() =>
    readStoredImpersonation(),
  );

  useEffect(() => {
    if (!isBrowser()) return;

    const sync = () => setImpersonation(readStoredImpersonation());

    window.addEventListener("storage", sync);
    window.addEventListener(IMPERSONATION_EVENT, sync);

    return () => {
      window.removeEventListener("storage", sync);
      window.removeEventListener(IMPERSONATION_EVENT, sync);
    };
  }, []);

  const startImpersonation = useCallback((session: StartImpersonationInput) => {
    const nextSession = startImpersonationSession(session);
    setImpersonation(nextSession);
    return nextSession;
  }, []);

  const stopImpersonation = useCallback(() => {
    stopImpersonationSession();
    setImpersonation(null);
  }, []);

  return {
    impersonation,
    isImpersonating: !!impersonation,
    startImpersonation,
    stopImpersonation,
  };
}
