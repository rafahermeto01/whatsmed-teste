import { useQuery } from "convex/react";

import { api } from "@whatsmed-app/backend/convex/_generated/api";

export function useDoctorsList(clinicId?: string) {
  const result = useQuery(api.users.listDoctors, clinicId ? { clinicId } : "skip");
  return result ?? [];
}
