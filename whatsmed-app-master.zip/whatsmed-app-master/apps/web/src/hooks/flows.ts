import { useQuery, useMutation } from "convex/react";

import { api } from "@whatsmed-app/backend/convex/_generated/api";

import type { Id } from "@whatsmed-app/backend/convex/_generated/dataModel";

export function useFlow(flowId: Id<"flows"> | string) {
  return useQuery(api.flows.getById, { id: flowId });
}

export function useSaveFlow() {
  const saveFlow = useMutation(api.flows.updateFlow);
  const createVersion = useMutation(api.flows.createFlowVersion);

  return {
    save: async (params: {
      flowId: Id<"flows">;
      name?: string;
      description?: string;
      nodes: unknown[];
      edges: unknown[];
      variables: Array<{ name: string; type: string; defaultValue?: unknown }>;
    }) => {
      // Create new version first
      const versionId = await createVersion({
        flowId: params.flowId,
        nodes: params.nodes as any,
        edges: params.edges as any,
        variables: params.variables as any,
      });

      // Update flow if name/description changed
      if (params.name || params.description) {
        await saveFlow({
          id: params.flowId,
          ...(params.name && { name: params.name }),
          ...(params.description && { description: params.description }),
        });
      }

      return versionId;
    },
    isPending: false,
    error: null,
  };
}

export function useCreateFlow() {
  const createFlow = useMutation(api.flows.createFlow);

  return {
    create: async (params: { clinicId: string; name: string; description?: string }) => {
      return await createFlow(params);
    },
    isPending: false,
    error: null,
  };
}
