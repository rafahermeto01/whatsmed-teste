import { useAction, useMutation, useQuery } from "convex/react";

import { api } from "@whatsmed-app/backend/convex/_generated/api";

export function useBillingWallet(clinicId?: string) {
  return useQuery(api.billing.getWallet, clinicId ? { clinicId } : "skip");
}

export function useBillingTransactions(args: {
  clinicId?: string;
  limit?: number;
  cursor?: string;
}) {
  const result = useQuery(
    api.billing.listTransactions,
    args.clinicId
      ? {
          clinicId: args.clinicId,
          limit: args.limit,
          cursor: args.cursor,
        }
      : "skip",
  );
  return result;
}

export function useBillingPaymentMethods(clinicId?: string) {
  return useQuery(api.billing.listPaymentMethods, clinicId ? { clinicId } : "skip");
}

export function useBillingSubscription(clinicId?: string) {
  return useQuery(api.billing.getSubscription, clinicId ? { clinicId } : "skip");
}

// Actions (make external API calls)
export function useInitializeWallet() {
  return useAction(api.billing.initializeWallet);
}

export function useInitializeWalletFromClinic() {
  return useAction(api.billing.initializeWalletFromClinic);
}

export function useCreateTopUp() {
  return useAction(api.billing.createTopUp);
}

export function useCreateSubscription() {
  return useAction(api.billing.createSubscription);
}

export function useCancelSubscription() {
  return useAction(api.billing.cancelSubscription);
}

export function useSubscribeToPlan() {
  return useAction(api.billing.subscribeToPlan);
}

export function useAddPaymentMethod() {
  return useAction(api.billing.addPaymentMethod);
}

// Mutations (database-only operations)
export function useRemovePaymentMethod() {
  return useMutation(api.billing.removePaymentMethod);
}

export function useSetDefaultPaymentMethod() {
  return useMutation(api.billing.setDefaultPaymentMethod);
}

export function useUpdateAutoRechargeSettings() {
  return useMutation(api.billing.updateAutoRechargeSettings);
}

export function useConversationCredits(clinicId?: string) {
  return useQuery(api.conversationCredits.getCreditStatus, clinicId ? { clinicId } : "skip");
}

export function usePurchaseCredits() {
  return useAction(api.billing.purchaseConversationCredits);
}
