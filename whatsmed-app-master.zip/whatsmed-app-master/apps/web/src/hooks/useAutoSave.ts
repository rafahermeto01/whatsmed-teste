import { useCallback, useEffect, useRef, useState } from "react";

export type AutoSaveStatus = "idle" | "saving" | "saved" | "error";

interface UseAutoSaveOptions<T> {
  /** The data to watch for changes */
  data: T;
  /** Function to call when saving (should return a promise) */
  onSave: (data: T) => Promise<void>;
  /** Debounce delay in milliseconds (default: 800) */
  debounceMs?: number;
  /** Validation function - return true if data is valid to save */
  validate?: (data: T) => boolean;
  /** Whether autosave is enabled (default: true) */
  enabled?: boolean;
  /** Duration to show "saved" status before returning to "idle" (default: 2000) */
  savedDurationMs?: number;
}

interface UseAutoSaveReturn {
  status: AutoSaveStatus;
  /** Error message if status is "error" */
  error: string | null;
  /** Manually trigger a save */
  saveNow: () => Promise<void>;
}

/**
 * Hook for auto-saving data with debounce
 * Shows status: idle -> saving -> saved -> idle (or error)
 *
 * IMPORTANT: The caller should manage a "dirty" flag and only set
 * enabled=true when the user has made actual changes.
 */
export function useAutoSave<T>({
  data,
  onSave,
  debounceMs = 800,
  validate,
  enabled = true,
  savedDurationMs = 2000,
}: UseAutoSaveOptions<T>): UseAutoSaveReturn {
  const [status, setStatus] = useState<AutoSaveStatus>("idle");
  const [error, setError] = useState<string | null>(null);

  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const savedTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Serialize data for dependency tracking
  const dataString = JSON.stringify(data);

  const performSave = useCallback(async () => {
    if (!enabled) return;

    // Validate before saving
    if (validate && !validate(data)) {
      return;
    }

    setStatus("saving");
    setError(null);

    try {
      await onSave(data);
      setStatus("saved");

      // Clear any existing "saved" timeout
      if (savedTimeoutRef.current) {
        clearTimeout(savedTimeoutRef.current);
      }

      // Return to "idle" after showing "saved"
      savedTimeoutRef.current = setTimeout(() => {
        setStatus("idle");
      }, savedDurationMs);
    } catch (err: any) {
      setStatus("error");
      setError(err?.message || "Erro ao salvar");
    }
  }, [data, onSave, validate, enabled, savedDurationMs]);

  // Watch for when enabled becomes true or data changes, and debounce save
  useEffect(() => {
    // Don't do anything if not enabled
    if (!enabled) return;

    // Clear existing timeout
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    // Set new debounced save
    timeoutRef.current = setTimeout(() => {
      performSave();
    }, debounceMs);

    // Cleanup
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [enabled, dataString, debounceMs, performSave]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      if (savedTimeoutRef.current) {
        clearTimeout(savedTimeoutRef.current);
      }
    };
  }, []);

  const saveNow = useCallback(async () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    await performSave();
  }, [performSave]);

  return { status, error, saveNow };
}
