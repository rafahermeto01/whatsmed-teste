import { useMutation, useQuery, useAction } from "convex/react";

import { api } from "@whatsmed-app/backend/convex/_generated/api";

export function useClinic(clinicId?: string) {
  return useQuery(api.clinics.getClinic, clinicId ? { clinicId } : "skip");
}

export function useClinicsList() {
  return useQuery(api.clinics.listAll, {});
}

export function useUpsertClinic() {
  return useMutation(api.clinics.upsertClinic);
}

export function useCreateClinic() {
  return useAction(api.clinics.createClinic);
}

export function useSetClinicPlan() {
  return useMutation(api.clinics.setClinicPlan);
}

export function useUpdateClinicBillingInfo() {
  return useMutation(api.clinics.updateClinicBillingInfo);
}
