import { useQuery, useMutation } from "convex/react";

import { api } from "@whatsmed-app/backend/convex/_generated/api";

import type { Id } from "@whatsmed-app/backend/convex/_generated/dataModel";

/**
 * Return type for useDefaultFlow hook
 */
interface UseDefaultFlowReturn {
  /** The currently set default flow ID, or null if not set */
  defaultFlowId: Id<"flows"> | null | undefined;
  /** Whether the query is loading */
  isLoading: boolean;
}

/**
 * Hook to get the currently set default flow for a clinic
 *
 * @param clinicId - The clinic ID to check (Id<"clinics">)
 * @returns Object containing defaultFlowId, loading state
 *
 * @example
 * ```tsx
 * function FlowSelector({ clinicId }: { clinicId: string }) {
 *   const { defaultFlowId, isLoading } = useDefaultFlow(clinicId);
 *
 *   if (isLoading) return <Spinner />;
 *
 *   return <div>Default flow: {defaultFlowId ?? "Not set"}</div>;
 * }
 * ```
 */
export function useDefaultFlow(clinicId: string | undefined): UseDefaultFlowReturn {
  const clinicSettingsApi = (api as any).clinicSettings;
  const result = useQuery(clinicSettingsApi?.getSettings, clinicId ? { clinicId } : "skip");

  return {
    defaultFlowId: result?.defaultFlowId ?? null,
    isLoading: result === undefined,
  };
}

/**
 * Hook to get a mutation function for setting the default flow
 *
 * This hook returns a function that can be called to set the default flow
 * for a clinic. Only users with admin role can successfully execute this.
 *
 * @returns The setDefaultFlow mutation function from Convex
 *
 * @example
 * ```tsx
 * function SetDefaultButton({ clinicId, flowId }: { clinicId: string; flowId: string }) {
 *   const setDefaultFlow = useSetDefaultFlow();
 *
 *   const handleClick = async () => {
 *     await setDefaultFlow({ clinicId, flowId });
 *     toast.success("Default flow updated");
 *   };
 *
 *   return (
 *     <Button onClick={handleClick}>
 *       Set as Default
 *     </Button>
 *   );
 * }
 * ```
 */
export function useSetDefaultFlow() {
  // Use type assertion to access clinicSettings API (will be available after Convex codegen)
  const clinicSettingsApi = (api as any).clinicSettings;
  return useMutation(clinicSettingsApi?.setDefaultFlow);
}

export function useUpdateWhatsAppSettings() {
  const clinicSettingsApi = (api as any).clinicSettings;
  return useMutation(clinicSettingsApi?.updateWhatsAppSettings);
}

/**
 * Type definition for clinic settings
 */
interface ClinicSettings {
  _id: Id<"clinicSettings">;
  clinicId: Id<"clinics">;
  defaultFlowId: Id<"flows"> | null;
  prependAttendantNameOnManualMessages?: boolean;
  createdAt?: number;
  updatedAt?: number;
}

/**
 * Return type for useClinicSettings hook
 */
interface UseClinicSettingsReturn {
  /** The full clinic settings object */
  settings: ClinicSettings | null | undefined;
  /** The default flow ID if set */
  defaultFlowId: Id<"flows"> | null | undefined;
  /** Whether the query is loading */
  isLoading: boolean;
}

/**
 * Hook to get the full clinic settings for a clinic
 *
 * Returns the complete clinicSettings object including defaultFlowId
 * and other configuration. This is useful when you need access to
 * multiple settings fields.
 *
 * @param clinicId - The clinic ID to check (Id<"clinics">)
 * @returns Object containing settings, loading state
 *
 * @example
 * ```tsx
 * function ClinicSettingsPanel({ clinicId }: { clinicId: string }) {
 *   const { settings, isLoading } = useClinicSettings(clinicId);
 *
 *   if (isLoading) return <Spinner />;
 *
 *   return (
 *     <div>
 *       <p>Default Flow: {settings?.defaultFlowId ?? "Not set"}</p>
 *     </div>
 *   );
 * }
 * ```
 */
export function useClinicSettings(clinicId: string | undefined): UseClinicSettingsReturn {
  const clinicSettingsApi = (api as any).clinicSettings;
  const result = useQuery(clinicSettingsApi?.getSettings, clinicId ? { clinicId } : "skip");

  return {
    settings: result,
    defaultFlowId: result?.defaultFlowId,
    isLoading: result === undefined,
  };
}
