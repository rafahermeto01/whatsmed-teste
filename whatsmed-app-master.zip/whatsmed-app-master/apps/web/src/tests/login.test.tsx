import * as router from "@tanstack/react-router";
import { render, screen, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";
import { describe, it, expect, vi, beforeEach } from "vitest";

import { authClient } from "../lib/auth-client";
import { LoginPage, Route } from "../routes/login";

// Mock authClient
vi.mock("../lib/auth-client", () => ({
  authClient: {
    useSession: vi.fn(),
    signIn: {
      email: vi.fn(),
    },
  },
}));

// Mock router
vi.mock("@tanstack/react-router", async () => {
  const actual = await vi.importActual("@tanstack/react-router");
  return {
    ...actual,
    useNavigate: vi.fn(),
    createFileRoute: () => () => ({
      useSearch: vi.fn(() => ({})),
    }),
  };
});

// Mock Route.useSearch
vi.spyOn(Route, "useSearch").mockImplementation(() => ({}));

// Mock Convex components
vi.mock("convex/react", () => ({
  Authenticated: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  Unauthenticated: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));

describe("LoginPage", () => {
  const navigateMock = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
    (router.useNavigate as any).mockReturnValue(navigateMock);
  });

  it("redirects to dashboard when authenticated", async () => {
    (authClient.useSession as any).mockReturnValue({
      data: { user: { id: "1" } },
      isPending: false,
    });

    render(<LoginPage />);

    await waitFor(() => {
      expect(navigateMock).toHaveBeenCalledWith({
        to: "/dashboard",
      });
    });
  });

  it("redirects to search.redirect when authenticated", async () => {
    (authClient.useSession as any).mockReturnValue({
      data: { user: { id: "1" } },
      isPending: false,
    });
    (Route.useSearch as any).mockReturnValue({ redirect: "/original-url" });

    render(<LoginPage />);

    await waitFor(() => {
      expect(navigateMock).toHaveBeenCalledWith({
        to: "/original-url",
      });
    });
  });

  it("redirects / to dashboard when authenticated", async () => {
    (authClient.useSession as any).mockReturnValue({
      data: { user: { id: "1" } },
      isPending: false,
    });
    (Route.useSearch as any).mockReturnValue({ redirect: "/" });

    render(<LoginPage />);

    await waitFor(() => {
      expect(navigateMock).toHaveBeenCalledWith({
        to: "/dashboard",
      });
    });
  });

  it("does not redirect when unauthenticated", async () => {
    (authClient.useSession as any).mockReturnValue({
      data: null,
      isPending: false,
    });

    render(<LoginPage />);

    await waitFor(
      () => {
        expect(navigateMock).not.toHaveBeenCalled();
      },
      { timeout: 100 },
    );

    // Should show login form content
    expect(screen.getByText("Bem-vindo de volta")).toBeInTheDocument();
  });
});
