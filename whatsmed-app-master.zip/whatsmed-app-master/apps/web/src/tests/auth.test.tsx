import * as router from "@tanstack/react-router";
import { render, screen, waitFor } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";

import { MainLayout } from "../components/MainLayout";
import { authClient } from "../lib/auth-client";

vi.mock("convex/react", () => ({
  useQuery: vi.fn(() => []),
  useMutation: vi.fn(() => vi.fn(async () => ({}))),
}));

vi.mock("../hooks/patients", () => ({
  useClinicId: () => ({
    clinicId: "clinic-demo",
    role: "admin",
    loading: false,
  }),
}));

// Mock authClient
vi.mock("../lib/auth-client", () => ({
  authClient: {
    useSession: vi.fn(),
  },
}));

// Mock router
vi.mock("@tanstack/react-router", async () => {
  const actual = await vi.importActual("@tanstack/react-router");
  return {
    ...actual,
    useNavigate: vi.fn(),
    useLocation: vi.fn(() => ({ href: "http://localhost/dashboard", pathname: "/dashboard" })),
    Link: ({ children, to }: any) => <a href={to}>{children}</a>,
  };
});

describe("Authentication Flow", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    (router.useNavigate as any).mockReturnValue(vi.fn());
  });

  it("shows loading state when session is pending", () => {
    (authClient.useSession as any).mockReturnValue({
      data: null,
      isPending: true,
    });

    render(<MainLayout>Protected Content</MainLayout>);

    // Check for spinner or absence of content
    expect(screen.queryByText("Protected Content")).toBeNull();
  });

  it("renders content when unauthenticated and session is resolved", async () => {
    (authClient.useSession as any).mockReturnValue({
      data: null,
      isPending: false,
    });

    render(<MainLayout>Protected Content</MainLayout>);

    await waitFor(() => {
      expect(screen.getByText("Protected Content")).toBeTruthy();
    });
  });

  it("renders content when authenticated", () => {
    (authClient.useSession as any).mockReturnValue({
      data: { user: { id: "1", email: "test@example.com" } },
      isPending: false,
    });

    render(<MainLayout>Protected Content</MainLayout>);

    expect(screen.getByText("Protected Content")).not.toBeNull();
  });
});
