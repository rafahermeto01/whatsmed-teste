# WhatsMed UX/UI Comprehensive Requirements Document

**Version:** 1.0
**Design System Reference:** WhatsMed Design System (DS-WM)
**Target Platform:** Web Application (Responsive SaaS)
**Visual Style:** Clean, Clinical Professional, High-Contrast Accessibility.

---

## 1. Global Design Language & Interface Standards

To ensure cohesion across all screens managed by different designers, strict adherence to the following visual standards is required based on the provided CSS variables.

- **Color Palette Usage:**
  - **Primary Action (CTA):** `var(--primary)` (#0052ab). Used for main buttons, active navigation states, and primary links.
  - **Accent/Highlights:** `var(--accent)` (#00bfc9). Used for focus rings, toggle switches (active state), and secondary data visualization elements.
  - **Backgrounds:** `var(--background)` for main page canvas; `var(--card)` for content containers.
  - **Typography:** `var(--font-sans)`. Headings must be bold and hierarchical. Body text uses `var(--foreground)`. Muted text (metadata, subtitles) uses `var(--muted-foreground)`.
- **Component Styling:**
  - **Cards:** All content widgets must use `var(--card)` background, a `1px` border using `var(--border)`, and a `var(--radius)` of `0.625rem`. Shadow depth should generally use `var(--shadow-sm)`.
  - **Inputs:** Height 40px, `var(--input)` border color. On focus, the border transitions to `var(--ring)` (#00bfc9) with a `2px` offset.
  - **Modals (Dialogs):** Centered overlay with `var(--background)` backdrop blur. Modal window uses `var(--popover)` background.
  - **Select Dropdowns:**
    - **Trigger:** Full width matching parent container (`w-full`), `cursor-pointer` for interactivity.
    - **Dropdown Menu:** Left-aligned (`align="start"`) content to match trigger's horizontal start position.
    - **Options:** Full width, `cursor-pointer`, consistent padding (`py-1.5 px-2`), left-aligned text.
    - **Visual Hierarchy:** Dropdown width must match or exceed trigger width.
- **Navigation Structure:**
  - **Sidebar (Left):** Fixed width (250px). Background `var(--sidebar)`. Contains Logo (top) and Navigation Links.
  - **Header (Top):** Sticky. Contains Page Title (Left) and User Profile/Notification/Theme Toggle (Right).

---

## 2. Detailed Screen Specifications

### 2.1. Authentication & Onboarding

#### Screen: Login

**Layout:** Centered Single Card layout on a `var(--background)` canvas.
**Components:**

1.  **Card Container:** Centered vertically and horizontally. `var(--card)` background, `var(--shadow-lg)`. Padding: 2.5rem.
2.  **Logo Area:** Top center of the card. WhatsMed logo (SVG).
3.  **Typography:**
    - Heading: "Welcome back" (H2, Semi-bold, `var(--foreground)`).
    - Subtext: "Enter your credentials to access the clinic manager" (`var(--muted-foreground)`).
4.  **Form Fields:**
    - **Email Input:** Label "Email Address". Placeholder "name@clinic.com". Standard Input styling.
    - **Password Input:** Label "Password". Icon toggle for visibility (Eye icon) on the right inner edge.
    - **Forgot Password Link:** Right-aligned under the password field. Text color `var(--primary)`, font-size `0.875rem`. Hover effect: Underline.
5.  **Action Button:** Full-width button. Background `var(--primary)`, Text `var(--primary-foreground)`. Label: "Sign In".
6.  **Footer:** "Don't have an account? Contact Support" centered at bottom.

#### Modal: Forgot Password

**Trigger:** Click on "Forgot Password" link.
**Components:**

- **Header:** "Reset Password" (H3).
- **Body Text:** "Enter the email associated with your account and we'll send an email with instructions to reset your password."
- **Input:** Single Email field. Focus state color `var(--ring)`.
- **Actions:**
  - "Cancel" (Ghost button, `var(--muted-foreground)`).
  - "Send Instructions" (Primary button, `var(--primary)`).

#### Screen: Reset Password

**Layout:** Identical to Login Screen.
**Components:**

- **Inputs:** Two fields: "New Password" and "Confirm New Password".
- **Validation:** Real-time feedback text below inputs (e.g., "Must contain 8 characters") changing from `var(--muted-foreground)` to `var(--accent)` when satisfied.
- **Action:** "Update Password" (Primary Button).

---

### 2.2. Dashboard (Home)

#### Screen: Main Analytics Dashboard

**Layout:** Standard App Layout (Sidebar Left, Header Top).
**Components:**

1.  **Date Range Picker (Top Right of Content):**
    - **Function:** Filters all downstream metrics and charts.
    - **Display:** Button-style trigger displaying current range (e.g., "Today", "Last 7 Days").
    - **Icon:** Calendar.
    - **Styling:** Outline button `var(--border)`.

2.  **System Health Alert (Conditional):**
    - **Logic:** Triggers if the connection manager detects a disconnection or ban risk.
    - **Background:** Light Red (alpha version of `var(--destructive)`) for critical errors, or Light Yellow for warnings.
    - **Icon:** Wifi-Off or Alert Triangle.
    - **Text:** "WhatsApp Disconnected: Messages are not being sent. Click to reconnect."
    - **Action Link:** "Reconnect Number" (Underlined, bold).

3.  **Metric Widgets (Row 1):**
    - **Grid:** 3 Equal Columns.
    - **Cards:** `var(--card)` background.
    - **Content:**
      - **Widget A: Efficiency (Confirmation Rate)**
        - _Label:_ Uppercase small font `var(--muted-foreground)` "CONFIRMATION RATE".
        - _Value:_ Large H2 font `var(--foreground)` (e.g., "85%").
        - _Trend:_ Small pill badge `+2.4%` (Green text/bg) representing the increase in automated confirmations compared to the previous period.
        - _Context:_ Percentage of "Scheduled" appointments that converted to "Confirmed" via the automation engine.
      - **Widget B: Performance (Cancellation Rate)**
        - _Label:_ Uppercase small font `var(--muted-foreground)` "CANCELLATION RATE".
        - _Value:_ Large H2 font `var(--foreground)` (e.g., "12%").
        - _Trend:_ Small pill badge `-5%` (Green text/bg) representing the decrease in cancellations compared to the previous period (Negative value is positive here).
      - **Widget C: Workload (Action Required)**
        - _Label:_ Uppercase small font `var(--muted-foreground)` "MANUAL INTERVENTION".
        - _Value:_ Large H2 font `var(--foreground)` (e.g., "4").
        - _Trend:_ Small pill badge `-2` (Green text/bg) representing the reduction in manual chats required compared to the previous period.
        - _Context:_ Count of active chats in the inbox requiring human reply (where the AI agent could not resolve).

4.  **Charts (Row 2):**
    - **Appointment Status Breakdown (Donut Chart):**
      - **Source:** Real-time stats comparing specific appointment statuses.
      - **Segments:**
        - "Confirmed" `var(--chart-1)`
        - "Scheduled" `var(--chart-2)`
        - "Rescheduled" `var(--chart-3)`
        - "Canceled" `var(--destructive)`
      - **Legend:** Positioned on the right.
    - **WhatsApp Conversion Funnel (Bar Chart):**
      - **Source:** Automation funnel metrics.
      - **Visual:** Vertical bars showing the drop-off flow.
      - **Stages:**
        - "Conversations Initiated" (Total automated triggers).
        - "Scheduled via Chat" (Patient confirmed).
        - "Actual Attendance" (Patient arrived).
      - **Styling:** Uses `var(--primary)` gradients.

---

### 2.3. WhatsApp Communication Module

#### Screen: Unified Inbox

**Layout:** Full-height application view (no internal scrolling of the page, only the panes scroll).
**Components:**

1.  **Left Pane (Chat List - 30% width):**
    - **Search Bar:** Top pinned. Input "Search patients...".
    - **List Item:**
      - Avatar (Circle, Initials).
      - Name (Bold).
      - Last Message (Truncated, `var(--muted-foreground)`).
      - Time (Top right, small).
      - **Status Badge:** Small dot or pill. Green (Open), Gray (Closed).
      - **Unread Badge:** Circle with number, background `var(--primary)`, text `var(--primary-foreground)`.
2.  **Right Pane (Chat Interface - 50% width):**
    - **Header:** Patient Name, Avatar, and "Resolve Chat" button (Outline).
    - **Message Area:** Bubble layout.
      - _Sent:_ Background `var(--primary)`, text `var(--primary-foreground)`. Aligned Right.
      - _Received:_ Background `var(--secondary)`, text `var(--secondary-foreground)`. Aligned Left.
    - **Input Area:** Bottom fixed.
      - Textarea (Auto-expanding).
      - Attachment Icon (Clip).
      - Send Button (Paper plane icon, `var(--primary)`).
3.  **Sidebar (Context - 20% width):**
    - **Patient Info Card:** "Upcoming Appointment: Dec 12, 14:00".
    - **Quick Actions:** "View Profile", "Reschedule".

#### Screen: Device Connection

**Layout:** Central empty state style.
**Components:**

- **Status Indicator:** Large Circle Icon. Green checkmark (Online) or Red pulse (Offline).
- **Text:** "WhatsApp Session is [Status]".
- **Button:** "Connect New Device" (`var(--primary)`) or "Disconnect Session" (`var(--destructive)` outline).

#### Modal: QR Code Scan

**Components:**

- **Title:** "Link WhatsApp".
- **QR Canvas:** Center square. High contrast black/white QR code.
- **Instructions:** Numbered list (1. Open WhatsApp, 2. Settings, 3. Linked Devices).
- **Refresh:** "Reload QR Code" text link below.

---

### 2.4. Patient Management

#### Screen: Patient Directory

**Components:**

1.  **Toolbar:**
    - Search Input ("Search by name or phone...").
    - Filter Dropdown ("Status").
    - **Primary Action:** "Add Patient" Button (`var(--primary)`).
    - **Secondary Action:** "Import CSV" Button (Outline).
2.  **Data Table:**
    - **Headers:** Name, Phone, Next Appointment, Status, Actions. Text `var(--muted-foreground)`, uppercase.
    - **Rows:** Height 60px. Hover background `var(--muted)`.
    - **Status Column:** Pills (Active = Green/Light Green, Inactive = Gray).
    - **Actions Column:** Ellipsis menu (...) triggering a Dropdown: "Edit", "View History", "Delete".

#### Modal: Add/Edit Patient

**Components:**

- **Form Grid:** 2 Columns.
- **Fields:** Name (Text), Phone (Masked Input +55...), Date of Birth (Date Picker), External ID (Text, Optional).
- **Footer:** "Cancel" and "Save Patient".

#### Modal: Bulk Import

**Components:**

- **Dropzone:** Dashed border area `var(--border)`. Icon: Cloud Upload. Text: "Drag & drop CSV/XLSX here".
- **Mapping Section (Appears after upload):**
  - Left column: "CSV Header". Right column: Dropdown "Map to System Field".
- **Action:** "Start Import".

---

### 2.5. Schedule & Appointments

#### Screen: Agenda View

**Components:**

1.  **View Switcher:** Segmented Control (Month | Week | Day). Active segment uses `var(--background)` with `var(--shadow-sm)`.
2.  **Calendar Grid:**
    - **Header:** Days of the week.
    - **Slots:** Grid cells.
    - **Appointment Cards (Chips):** Rounded rectangles inside slots.
      - Background color based on type/status (e.g., Consult = `var(--chart-3)`, Return = `var(--chart-4)`).
      - Text: Time + Patient Name. White text.
3.  **Navigation:** Arrows (< >) to change date range. Date Title "December 2025".

#### Screen: Appointment List View

**Components:**

- **Timeline Layout:** Vertical line connecting items.
- **Item Card:**
  - Time (Left, large bold).
  - Card Body: Patient Name, Doctor Name, Procedure Type.
  - Actions: "Check-in" (Green Button), "No-show" (Gray Button).

#### Modal: Appointment Details

**Components:**

- **Header:** Patient Name + Date/Time.
- **Timeline Widget:** Vertical dots showing "Reminder Sent (WhatsApp)" -> "Confirmed by Patient".
- **Status Override:** Dropdown (Confirmed, Pending, Cancelled, Completed).
- **Notes:** Textarea for internal clinical notes.

---

### 2.6. Automation & AI Configuration

#### Screen: Reminders Settings

**Components:**

1.  **Card: "7-Day Reminder"**
    - **Header:** Title + Toggle Switch (Green when active).
    - **Content:** Textarea "Message Template". Supports variables like `{{patient_name}}`.
    - **Helper Text:** "Sent 7 days before appointment."
2.  **Card: "24-Hour Reminder"**
    - Identical structure.
    - **Helper Text:** "Sent 24 hours before appointment. Requires confirmation."

#### Modal: AI Agent Settings

**Components:**

- **Master Toggle:** "Enable AI Auto-Replies".
- **System Prompt:** Large Textarea (Code font or Monospace). Background `var(--muted)`.
  - Placeholder: "You are a helpful assistant for Dr. Smith's clinic..."
- **Safety Settings:** Checkbox "Escalate to human if sentiment is negative".

---

### 2.7. Billing & Wallet

#### Screen: Billing Overview

**Layout:** Grid Dashboard.
**Components:**

1.  **Wallet Balance Widget (Prominent):**
    - Background: Gradient `var(--primary)` to `var(--chart-3)`.
    - Text: White. "Current Balance".
    - Value: Huge Font "R$ 150,00".
    - Action: "Add Funds" button (White background, Blue text).
2.  **Auto-Recharge Indicator:**
    - Card with Status Dot (Green = On).
    - Link: "Configure Auto-Recharge".
3.  **Spending History Table:**
    - Simple table. Date | Description | Amount.
    - Negative amounts in `var(--foreground)`, Positive (Credits) in Green.
4.  **Payment Methods Card:**
    - Icon: Credit Card (Brand logo).
    - Text: "\*\*\*\* 4242".
    - Button: "Manage Cards" (Outline).

#### Modal: Add Funds

**Components:**

- **Quick Select:** 3 Buttons: "R$ 50", "R$ 100", "R$ 200". Selecting one highlights it with `var(--ring)`.
- **Custom Amount:** Input with currency mask.
- **Summary:** "Total Charge: R$ 100,00".
- **Confirm Button:** "Pay with Card ending 4242".

#### Modal: Auto-Recharge Configuration

**Components:**

- **Toggle:** "Enable Auto-Recharge".
- **Logic Inputs:**
  - "When balance falls below" [Input R$].
  - "Automatically add" [Input R$].
- **Source:** Dropdown "Select Card".

#### Modal: Manage Cards

**Components:**

- **List:** Existing cards with Trash Icon (Delete) and Star Icon (Set Default).
- **New Card Form (Asaas Integration):**
  - Card Number (Icon validation).
  - Holder Name.
  - Expiry (MM/YY).
  - CVV.
  - Badge: "Secured by Asaas".

---

### 2.8. Integrations (External Systems)

#### Screen: Integrations Hub

**Components:**

- **Grid:** Cards representing services (Logo + Title).
- **Card Status:**
  - **WhatsApp:** Badge "Active" (Green). Button "Manage".
  - **OpenAI:** Badge "Active". Button "Settings".
  - **Custom ERP:** Badge "Not Connected" (Gray). Button "Connect".
  - **Webhooks:** Icon (Network). Button "Configure".

#### Modal: API Key Management

**Components:**

- **Header:** "API Keys".
- **Description:** Warning banner "Keys grant full access. Do not share."
- **Key List:**
  - Row: Key Name (e.g., "ERP Prod") | Prefix `sk_live_...` | Created Date.
  - Action: "Revoke" (Destructive text).
- **Create Button:** "Generate New Key".

#### Modal: Inbound Webhook Details

**Components:**

1.  **Endpoint URL:**
    - Input field (Read Only) containing `https://api.whatsmed.com/v1/clinic/...`
    - Button: "Copy" (Clipboard icon).
2.  **Documentation:**
    - Label: "Expected JSON Payload".
    - Code Block: Dark background `var(--foreground)`, text `var(--background)`. Syntax highlighted JSON example.
3.  **Recent Events Log:**
    - Small table: Timestamp | Status (200 OK, 400 Error) | Source IP.

---

### 2.9. Administration & Settings

#### Screen: Clinic Settings

**Components:**

- **Logo Upload:** Circle avatar with "Upload" overlay on hover.
- **Fields:** Clinic Name, Address, Support Phone, Website.
- **Save Button:** Floating or Fixed at bottom right.

#### Screen: User Management

**Components:**

- **Header:** "Team Members".
- **List:** User Avatar | Name | Email | Role (Admin/Staff) | Status.
- **Invite Button:** Triggers modal to enter email and select role.

#### Screen: Audit Logs

**Components:**

- **Table:** Highly technical.
  - Timestamp (ISO format).
  - User (Name).
  - Action (e.g., "EXPORT_PATIENTS", "DELETE_APPOINTMENT").
  - IP Address.
  - Metadata (Expandable JSON view).

---

### 2.10. Super Admin (Internal)

#### Screen: Global Dashboard

**Components:**

- **KPI Cards:** "Total Active Clinics", "Global MRR", "Total SMS Sent".
- **System Health:** Server Status indicators (Green/Yellow/Red).

#### Screen: Tenant Management

**Components:**

- **Table:** List of all Clinics.
- **Columns:** Clinic Name, Owner Email, Plan Type, Status (Active/Suspended).
- **Actions:**
  - **Impersonate:** Eye Icon (Logs into the clinic as an admin).
  - **Suspend:** Pause Icon (Destructive).
- **Action Button:** "Onboard New Clinic".

#### Modal: Onboard Clinic

**Components:**

- **Form:** Owner Name, Owner Email, Clinic Name, Initial Plan Selection.
- **Action:** "Create Tenant". (Triggers email invite to owner).

---

## 3. User Flow Diagram (Mermaid)

The following diagram illustrates the navigational paths and connections between the screens described above.

```mermaid
graph TD
    %% Nodes Style
    classDef page fill:#0052ab,stroke:#00bfc9,stroke-width:2px,color:#fff;
    classDef modal fill:#f5f5f5,stroke:#0a0a0a,stroke-width:1px,color:#0a0a0a,stroke-dasharray: 5 5;
    classDef external fill:#00bfc9,stroke:#0052ab,stroke-width:2px,color:#fff;

    %% Authentication
    Login[Login Screen]:::page
    ForgotModal(Forgot Password Modal):::modal
    ResetScreen[Reset Password Screen]:::page

    %% Main App
    Dashboard[Dashboard / Home]:::page

    %% WhatsApp Module
    WA_Inbox[Unified Inbox Screen]:::page
    WA_Connect[Device Connection Screen]:::page
    WA_QR(QR Code Scan Modal):::modal

    %% Patient Management
    Pat_Dir[Patient Directory Screen]:::page
    Pat_Add(Add/Edit Patient Modal):::modal
    Pat_Import(Bulk Import Modal):::modal

    %% Schedule
    Sched_Agenda[Agenda View Screen]:::page
    Sched_List[Appointment List View]:::page
    Sched_Detail(Appointment Details Modal):::modal

    %% Automation
    Auto_Remind[Reminders Settings Screen]:::page
    Auto_AI(AI Agent Settings Modal):::modal

    %% Billing
    Bill_Overview[Billing Overview Screen]:::page
    Bill_Add(Add Funds Modal):::modal
    Bill_Auto(Auto-Recharge Config Modal):::modal
    Bill_Cards(Manage Cards Modal):::modal

    %% Integrations
    Int_Hub[Integrations Hub Screen]:::page
    Int_API(API Key Modal):::modal
    Int_Webhook(Webhook Details Modal):::modal

    %% Admin
    Admin_Clinic[Clinic Settings Screen]:::page
    Admin_User[User Management Screen]:::page
    Admin_Audit[Audit Logs Screen]:::page

    %% Super Admin
    SA_Dash[Super Admin Dashboard]:::page
    SA_Tenants[Tenant Management Screen]:::page
    SA_Onboard(Onboard Clinic Modal):::modal

    %% Relationships - Auth
    Login --> |Click Forgot Password| ForgotModal
    ForgotModal --> |Link Sent| ResetScreen
    Login --> |Success| Dashboard
    ResetScreen --> |Success| Login

    %% Relationships - Navigation (Sidebar)
    Dashboard --> WA_Inbox
    Dashboard --> Pat_Dir
    Dashboard --> Sched_Agenda
    Dashboard --> Auto_Remind
    Dashboard --> Bill_Overview
    Dashboard --> Int_Hub
    Dashboard --> Admin_Clinic

    %% Relationships - WhatsApp
    WA_Inbox --> |Manage Connection| WA_Connect
    WA_Connect --> |Connect Device| WA_QR
    WA_Connect --> |Back| WA_Inbox

    %% Relationships - Patients
    Pat_Dir --> |Add/Edit| Pat_Add
    Pat_Dir --> |Import| Pat_Import

    %% Relationships - Schedule
    Sched_Agenda --> |Toggle View| Sched_List
    Sched_List --> |Toggle View| Sched_Agenda
    Sched_Agenda --> |Click Slot| Sched_Detail
    Sched_List --> |Click Item| Sched_Detail

    %% Relationships - Automation
    Auto_Remind --> |Configure AI| Auto_AI

    %% Relationships - Billing
    Bill_Overview --> |Add Funds| Bill_Add
    Bill_Overview --> |Config Auto-Recharge| Bill_Auto
    Bill_Overview --> |Manage Cards| Bill_Cards

    %% Relationships - Integrations
    Int_Hub --> |Gen Keys| Int_API
    Int_Hub --> |Setup Webhook| Int_Webhook

    %% Relationships - Admin
    Admin_Clinic --> Admin_User
    Admin_Clinic --> Admin_Audit

    %% Relationships - Super Admin (Separate Flow)
    Login --> |If Super Admin| SA_Dash
    SA_Dash --> SA_Tenants
    SA_Tenants --> |Add New| SA_Onboard
    SA_Tenants --> |Impersonate| Dashboard

```
