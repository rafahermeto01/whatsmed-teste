# 🏥 WhatsMed Platform – Feature Specification Document v2.1

## 1. Intelligent Scheduling & Agenda Management

_Focus: Maximizing slot utilization via AI-driven interactions._

### 1.1. AI-Powered Confirmation Engine (Sentiment Analysis)

**Technical Stack:** **OpenRouter API** (providing access to models like Llama 3, Claude 3, or GPT-4o for cost-effective, high-accuracy inference).

**Rationale:** Humans speak in nuances. The system uses OpenRouter to process natural language and determine intent/sentiment.

- **Sentiment & Intent Classification:**
  - **Positive/Commitment:** ("Com certeza", "Pode confirmar", "Estarei lá") → **Action:** Status updates to `CONFIRMED`.
  - **Negative/Cancellation:** ("Não vou conseguir", "Imprevisto", "Cancela") → **Action:** Triggers **Smart Rescheduling**.
  - **Uncertain/Soft Refusal:** ("Talvez", "Vou tentar", "Ainda não sei") → **Action:** Bot triggers a specific follow-up: _"I noticed you're unsure. Would you prefer to reschedule to a better time to avoid a cancellation fee?"_
- **Multi-Channel Fallback:**
  - **T-48h:** Initial AI WhatsApp message.
  - **T-24h (If Unresponsive):** Automated SMS or Voice Call (Robocall).
  - **T-1h:** Final urgent reminder.

### 1.2. Smart Rescheduling (Automated Recovery)

- **Trigger:** OpenRouter AI detects `Intent: Cancellation`.
- **Bot Logic:**
  - Bot queries database for next 3 available slots.
  - **Response:** _"I understand. To keep your treatment on track, I have these openings next week. Do any of these work? [Option A], [Option B], [Option C]."_

### 1.3. Automated Priority Waitlist ("Fila de Espera")

- **Mechanism:**
  - Opt-in for "Waitlist" on full days.
  - When a slot opens, top 5 patients get a WhatsApp blast.
  - First reply with `Intent: Accept` atomically locks the slot.

---

## 2. AI Conversational Triage (No Numbered Menus)

_Focus: Natural Language Understanding via OpenRouter._

### 2.1. Natural Language Intent Routing

**Rationale:** Eliminate "Press 1 for X".

- **The Flow:**
  - **User:** _"Hi, I need to show my blood test results to Dr. Silva."_
  - **AI Analysis (OpenRouter):**
    - **Intent:** `Post_Consultation_Review`
    - **Entity:** `Dr. Silva`
    - **Context:** `Blood Tests`
  - **Action:** Routes conversation to the **"Medical Results"** queue.
- **Supported Intents:** `Schedule_Appointment`, `Reschedule`, `Financial_Inquiry`, `Medical_Emergency`, `Location_Inquiry`.

### 2.2. Pre-Consultation Data Collection

asd

- **Dynamic Interview:**
  - _"Before we finalize, could you please send a photo of your insurance card?"_ (OCR processing).
  - _"Do you have a referral letter?"_
- **Auto-Tagging:** Chat is tagged (e.g., `#Cardiology`, `#Uninsured`) based on context analysis.

---

## 3. Smart Reception (Self-Check-In Flow)

_Focus: "Scan-to-Arrive" — Reducing reception workload._

### 3.1. The "Fast-Pass" Link

- **Trigger:** Sent 24 hours prior via WhatsApp.
- **Feature:** Secure web link (`app.whatsmed.com/checkin/{patient_token}`).
- **Step 1 (At Home/On the Go):**
  - Patient opens link.
  - Fills out/Updates anamnesis and contact info.
  - Digitally signs HIPAA/LGPD consent forms.
  - **Result:** The webpage updates to a "Ready to Scan" state (holding the patient's unique session active).

### 3.2. Clinic-Side Rotating QR Code (The "Totem")

- **The Device:** A tablet, monitor, or printed e-paper display at the clinic reception.
- **Security:** This device displays a **Dynamic QR Code** that regenerates every 24 hours (or shorter intervals if higher security is needed) containing a signed daily token (e.g., `clinic_id:date:random_hash`).
- **The Arrival Action:**
  1.  Patient arrives at the clinic.
  2.  Patient opens their "Ready to Scan" webpage on their phone.
  3.  Patient uses _their phone camera_ (via the web app interface) to scan the **Clinic's QR Code**.
- **The Trigger:**
  - The system validates the Clinic QR Token.
  - **Status Update:** Appointment status changes to `ARRIVED_WAITING_ROOM`.
  - **Notification:**
    - **Reception Dashboard:** Highlights patient as "Here".
    - **Doctor:** Receives a notification: _"Patient [Name] has arrived and forms are signed."_

---

## 4. Telehealth Module

_Focus: Secure, timed video consultations._

### 4.1. Secure Link Generation

- **Integration:** Google Meet API or Jitsi.
- **Just-in-Time:** Link sent 15 mins before session to prevent early joining.

---

## 5. Post-Care & Retention Ecosystem

### 5.1. Secure Document Delivery

- **Mechanism:** Admin uploads PDF -> System generates temp URL (48h expiry) -> Sent via WhatsApp.

### 5.2. Post-Op & Care Drip Campaigns

- **Sequence:** Automated messages based on procedure tags (e.g., _"Day 1: Ice the area"_).

### 5.3. NPS & Reputation Management

- **Trigger:** 2h post-appointment.
- **Logic:** Score 9-10 gets Google Reviews link; Score 0-6 alerts Manager.

---

## 6. Admin Dashboard & Analytics

### 6.1. Funnel Analytics 360

- **Metrics:** Sent -> Engaged (AI) -> Confirmed -> Presence (Verified by QR Scan).
- **Sentiment Breakdown:** Visual pie chart of patient sentiment trends via OpenRouter analysis.
