# WhatsMed Feature Implementation Checklist

This document tracks the status of new frontend features and their backend integration requirements.

**Legend:**

- ✅ = Complete (Frontend + Backend)
- 🟡 = Frontend Complete, Backend Partial
- 🔴 = Frontend Complete, Backend Missing
- ⚪ = Not Started

---

## 1. Dashboard & Analytics ✅

### Funnel Analytics 360 Chart

**Frontend:** ✅ `apps/web/src/components/charts/FunnelChart360.tsx`
**Backend:** ✅ Analytics API implemented

- [x] Implement aggregation query for funnel steps (Sent → Engaged → Confirmed → Arrived)
- [x] Create `analyticsData` records with `metricType: "funnel_step"`
- [x] Support date range filtering (periodStart, periodEnd)
- [x] Dashboard widget to fetch real-time metrics
      **Files:** `packages/backend/convex/analytics.ts`

### Sentiment Analysis Pie Chart

**Frontend:** ✅ `apps/web/src/components/charts/SentimentPieChart.tsx`
**Backend:** 🟡 Sentiment stats API implemented

- [x] Implement `getSentimentStats` query to aggregate Positive/Negative/Uncertain counts
- [x] Create `sentimentAnalysis` records when messages arrive (mutation implemented, AI integration pending)
- [x] Dashboard widget to fetch sentiment distribution
      **Files:** `packages/backend/convex/analytics.ts` (added getSentimentStats and recordSentimentAnalysis)

### Waitlist Widget

**Frontend:** ✅ `apps/web/src/routes/dashboard.tsx` (displays mock count "12")
**Backend:** ✅ Waitlist queries implemented

- [x] Implement `getWaitlistCount` query (filter by clinic, status: "waiting")
- [x] Implement `getWaitlistEntries` query for full waitlist management
- [x] Dashboard widget to fetch real-time count from backend
      **Schema:** ✅ `waitlists` table exists (Phase 1 complete)

---

## 2. Smart Scheduling & Appointments

### Waitlist Management UI

**Frontend:** ✅ `apps/web/src/components/appointments/WaitlistSection.tsx`
**Backend:** ✅ Waitlist mutations & queries implemented
**Mutations:**

- [x] `addToWaitlist` - Add patient to queue with priority (low/medium/high)
- [x] `notifyPatient` - Trigger WhatsApp notification to patient
- [x] `assignAppointment` - Move waitlist entry to scheduled appointment
      **Queries:**
- [x] `listWaitlist` - Fetch waiting patients by clinic with pagination
- [x] `getWaitlistCount` - Count by status (waiting/notified/assigned)
      **Schema:** ✅ `waitlists` table exists (Phase 1 complete)

### Telehealth Modal

**Frontend:** ✅ `apps/web/src/components/appointments/TelehealthModal.tsx`
**Backend:** ✅ Google Meet integration exists

- [x] Dynamic link generation via `createGoogleMeetEvent` action
- [x] Meeting data stored in `appointments` table (meetingLink, meetingId, conferenceData)
- [x] Error handling for failed Google Meet creation (already implemented)
      **Schema:** ✅ `appointments` table has telemedicine fields (Phase 1 complete)

### Reschedule Suggestion Modal

**Frontend:** ✅ `apps/web/src/components/appointments/RescheduleSuggestionModal.tsx`
**Backend:** ✅ Slot finding & WhatsApp options implemented
**Mutations:**

- [x] `setRescheduleStatus` - Mark appointment as awaiting response
      **Actions:**
- [x] `sendRescheduleOptions` - Action to send WhatsApp with 3 slot options
      **Queries:**
- [x] `getAvailableSlots` - Return next 3 available slots for given doctor
      **Schema:** ✅ `appointments` table ready (Phase 1 complete)

### Check-in Action

**Frontend:** ✅ `apps/web/src/routes/appointments.tsx`
**Backend:** ✅ Status enum updated

- [x] `update` mutation supports `"arrived"` status
- [x] `checkInPatient` - Shortcut mutation to mark appointment as arrived
- [x] Optional: Trigger NPS survey after check-in (if configured)
      **Schema:** ✅ `appointments` status has `"arrived"` (Phase 1 complete)

---

## 3. Automation & AI

### AI Confirmation Engine Settings

**Frontend:** ✅ `apps/web/src/routes/automation.tsx` (complete UI for persona, tone, temperature, escalation)
**Backend:** ✅ AI settings persistence implemented
**Mutations:**

- [x] `updateAiSettings` - Save AI configuration to `aiSettings` table
- [x] `toggleAiEnabled` - Enable/disable AI per clinic
      **Queries:**
- [x] `getAiSettings` - Fetch AI configuration by clinic
      **Schema:** ✅ `aiSettings` table exists (Phase 1 complete)

### Fallback Sequence UI

**Frontend:** ✅ (embedded in automation.tsx)
**Backend:** ✅ Fallback channel preferences implemented
**Mutations:**

- [x] `updateFallbackChannels` - Save channel preferences per clinic
- [x] `saveEscalationKeywords` - Update emergency keywords list (merged into updateFallbackChannels)
      **Schema:** ✅ `aiSettings` table has escalationKeywords field (Phase 1 complete)

### Drip Campaign Builder

**Frontend:** ✅ `apps/web/src/components/automation/CampaignBuilderModal.tsx`
**Backend:** ✅ Campaign CRUD & scheduler implemented
**Mutations:**

- [x] `createCampaign` - Insert new campaign with steps array
- [x] `updateCampaign` - Modify campaign (steps, status, trigger config)
- [x] `deleteCampaign` - Remove campaign
- [x] `toggleCampaignStatus` - Active/Paused
      **Actions:**
- [x] `scheduleCampaignExecution` - Cron job to trigger campaigns based on conditions
- [x] `incrementTriggerCount` - Update campaign stats when triggered
      **Queries:**
- [x] `listCampaigns` - Fetch all campaigns by clinic
- [x] `getCampaign` - Get campaign details for editing
      **Schema:** ✅ `campaigns` table exists (Phase 1 complete)

### Reminder Configurations (7-Day, 24h, 1h, Post-Consultation, No-Show)

**Frontend:** ✅ `apps/web/src/routes/automation.tsx` (5 reminder cards)
**Backend:** ✅ Reminder persistence & sending implemented
**Mutations:**

- [x] `updateReminderConfig` - Save reminder message, channels, delay
- [x] `toggleReminder` - Enable/disable each reminder type
      **Actions:**
- [x] `scheduleReminders` - Cron jobs to trigger reminders (7d, 24h, 1h before appointment)
- [x] `sendPostConsultationReminder` - After appointment completed
- [x] `handleNoShowRecovery` - When patient misses appointment
      **Queries:**
- [x] `getReminderConfigs` - Fetch all reminder settings by clinic
      **Schema:** ✅ `reminderConfigs` table exists (Phase 1 complete)

---

## 4. WhatsApp Inbox Enhancements

### Sentiment Badges

**Frontend:** ✅ `apps/web/src/components/SentimentBadge.tsx`
**Backend:** ✅ Sentiment classification pipeline implemented
**Actions:**

- [x] `classifyMessageAction` - Call Mastra (AI) on incoming messages
- [x] Store results in `sentimentAnalysis` table
      **Queries:**
- [x] `getMessageSentiment` - Fetch sentiment by message ID
- [x] WhatsApp inbox to display sentiment badge per message
      **Schema:** ✅ `sentimentAnalysis` table exists (Phase 1 complete)

### Intent Tags

**Frontend:** ✅ `apps/web/src/components/IntentTag.tsx`
**Backend:** ✅ Intent classification pipeline implemented
**Actions:**

- [x] `classifyMessageAction` - Call Mastra (AI) on incoming messages (combined with sentiment)
- [x] Store results in `messageIntents` table
      **Queries:**
- [x] `getMessageIntent` - Fetch intent by message ID
- [x] WhatsApp inbox to display intent tag per message
      **Schema:** ✅ `messageIntents` table exists (Phase 1 complete)

### Data Prompts

**Frontend:** ✅ `apps/web/src/routes/whatsapp.tsx` (UI placeholder)
**Backend:** 🔴 Data collection triggers not implemented
**Actions:**

- [ ] `triggerDataCollection` - Initiate OCR or specific data flows
- [ ] Link to `patientDataUpdates` for approval workflow
      **Schema:** ✅ `patientDataUpdates` table exists (Phase 1 complete)

---

## 5. Patient Self Check-in (Flow)

### Check-in Route

**Frontend:** ✅ `apps/web/src/routes/checkin.tsx` (token from URL)
**Backend:** 🔴 Token validation required
**Mutations:**

- [ ] `validateCheckinToken` - Verify token against `checkinSessions` table
- [ ] `createCheckinSession` - Generate secure token for patient/appointment
      **Queries:**
- [ ] `getCheckinSession` - Fetch session by token
- [ ] `getPatientCheckinStatus` - Check if patient has active check-in
      **Schema:** ✅ `checkinSessions` table exists (Phase 1 complete)

### Anamnesis Form

**Frontend:** ✅ `apps/web/src/components/checkin/AnamnesisForm.tsx`
**Backend:** 🔴 Patient data updates required
**Mutations:**

- [ ] `submitAnamnesisData` - Save form data to `patientDataUpdates` (pending approval)
- [ ] `approvePatientDataUpdate` - Admin approves/rejects data changes
      **Queries:**
- [ ] `getPendingPatientUpdates` - List updates needing approval
      **Schema:** ✅ `patientDataUpdates` table exists (Phase 1 complete)

### Consent Form

**Frontend:** ✅ `apps/web/src/components/checkin/ConsentForm.tsx`
**Backend:** 🔴 Consent storage required
**Mutations:**

- [ ] `saveConsent` - Store signed consent in `consents` table
- [ ] Link to `checkinSessions` and `appointments` for tracking
      **Queries:**
- [ ] `getPatientConsents` - Fetch consent history by patient
- [ ] `getAppointmentConsents` - Fetch consents for specific appointment
      **Schema:** ✅ `consents` table exists (Phase 1 complete)

### Clinic Totem Display

**Frontend:** ✅ `apps/web/src/routes/totem.tsx`
**Backend:** ✅ QR token generation implemented
**Mutations:**

- [x] `generateTotemQR` - Create rotating QR code in `totemQRs` table
- [x] `invalidatePreviousQR` - Deactivate old QR when new one generated
      **Queries:**
- [x] `getActiveTotemQR` - Fetch current active QR for display
      **Schema:** ✅ `totemQRs` table exists (Phase 1 complete)

### QR Scanner

**Frontend:** ✅ `apps/web/src/components/checkin/QRScanner.tsx`
**Backend:** ✅ QR token verification implemented
**Mutations:**

- [x] `scanAndValidateQR` - Verify scanned token against `totemQRs`
- [x] `completeCheckin` - Mark `checkinSessions` as "completed" (via scanAndValidateQR)
- [x] `updateAppointmentStatus` - Change appointment status to "arrived" (via scanAndValidateQR)
      **Actions:**
- [x] `sendCheckinConfirmation` - Send WhatsApp confirmation to patient on successful check-in
      **Schema:** ✅ `checkinSessions` and `totemQRs` tables exist (Phase 1 complete)

---

## 6. NPS & Reputation

### NPS Configuration

**Frontend:** ✅ `apps/web/src/components/nps/NPSSurveyConfig.tsx`
**Backend:** ✅ NPS settings persistence implemented
**Mutations:**

- [x] `updateNpsSettings` - Save delay, thresholds, links to `npsSettings` table
- [x] `toggleNpsEnabled` - Enable/disable NPS surveys
      **Queries:**
- [x] `getNpsSettings` - Fetch NPS configuration by clinic
      **Schema:** ✅ `npsSettings` table exists (Phase 1 complete)

### NPS Quick Action

**Frontend:** ✅ `apps/web/src/routes/whatsapp.tsx` (button in UI)
**Backend:** ✅ Manual survey trigger implemented
**Actions:**

- [x] `sendNpsSurveyAction` - Trigger NPS survey to patient (bypass delay)
- [x] `sendNpsSurveyManual` - Manual trigger for testing
- [x] `handleNpsResponseAction` - Process incoming NPS responses
      **Queries:**
- [x] `getNpsResponses` - Fetch survey responses for analytics
- [x] `calculateNpsScore` - Calculate NPS score from responses
      **Schema:** ✅ `npsResponses` table exists (Phase 1 complete)

---

## 7. Secure Documents

### Document Uploader

**Frontend:** ✅ `apps/web/src/components/DocumentUploader.tsx`
**Backend:** ✅ File upload & URL generation implemented
**Mutations:**

- [x] `uploadDocument` - Generate upload URL from Convex storage
- [x] `createDocumentRecord` - Insert metadata into `uploads` table (via uploadDocument)
      **Actions:**
- [x] `sendDocumentViaWhatsApp` - Send secure link via WhatsApp
      **Queries:**
- [x] `getDocumentUrl` - Fetch signed URL for download (via getSecureDocumentUrl)
- [x] `listDocuments` - List documents for clinic
      **Schema:** ✅ `uploads` table exists (pre-existing, Phase 1 verified)

---

## Summary Statistics

### Frontend Status

- **Complete UI Components:** 18/18 (100%)
- **Routes with Features:** 7/7 (100%)
- **Charts & Visualizations:** 2/2 (100%)

### Backend Status

- **Schema Tables:** 15/15 complete (Phase 1: ✅)
  - ✅ `waitlists`
  - ✅ `analyticsData`
  - ✅ `sentimentAnalysis`
  - ✅ `messageIntents`
  - ✅ `campaigns`
  - ✅ `aiSettings`
  - ✅ `reminderConfigs`
  - ✅ `checkinSessions`
  - ✅ `patientDataUpdates`
  - ✅ `consents`
  - ✅ `totemQRs`
  - ✅ `npsSettings`
  - ✅ `npsResponses`
  - ✅ `appointments` (updated with "arrived" status)
  - ✅ `uploads` (pre-existing)

- **Backend Functions:** 7/50+ estimated mutations/queries/actions needed (Funnel Analytics, Sentiment Stats, Waitlist Queries complete)

### Priority Order for Phase 2 (Backend Implementation)

**High Priority:**

1. Waitlist Management (5 mutations, 2 queries)
2. Check-in Flow (3 mutations, 3 queries)
3. NPS System (2 mutations, 2 queries, 2 actions)
4. Reminder System (5 mutations, 1 query, 1 action)

**Medium Priority:** 5. Campaign Builder (4 mutations, 2 queries, 1 action) 6. AI Settings (2 mutations, 1 query) 7. Analytics ✅ (1 query, 2 mutations implemented)

**Low Priority:** 8. Reschedule Logic (2 queries, 1 action) 9. Sentiment Analysis (1 action, 1 query) 10. Intent Classification (1 action, 1 query)

---

## Implementation Notes

### Files Created in Phase 1

- ✅ `packages/backend/convex/schema.ts` - Added 12 new tables + updated appointments status

### Next Steps

1. Create new backend modules as needed:
   - `packages/backend/convex/waitlists.ts`
   - `packages/backend/convex/analytics.ts` ✅ (implemented: Funnel Metrics, Sentiment Stats, Waitlist Queries)
   - `packages/backend/convex/campaigns.ts` (new file)
   - `packages/backend/convex/ai.ts` (new file)
   - `packages/backend/convex/checkin.ts` (new file)
   - `packages/backend/convex/nps.ts` (new file)

2. Implement core business logic in each module following Convex patterns
3. Test mutations/queries with `npx convex dev` environment
4. Connect frontend components to new backend functions via Convex client

### Cross-Feature Dependencies

- NPS surveys depend on `checkinSessions` completion
- Campaigns depend on `reminderConfigs` (for timing triggers)
- Sentiment/Intent analysis depends on OpenAI/OpenRouter integration
- Document uploads depend on Convex storage configuration
