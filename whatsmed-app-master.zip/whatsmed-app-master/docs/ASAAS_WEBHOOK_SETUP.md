# Configuração de Webhooks do Asaas

Para que o sistema de pagamentos funcione corretamente (confirmação de pagamentos, atualizações de assinatura), é necessário configurar os Webhooks no painel do Asaas.

## 1. Acesse a configuração de Webhooks

1. Faça login na sua conta Asaas (Sandbox ou Produção).
2. Vá em **Configurações do Sistema** (ícone de engrenagem) > **Integrações**.
3. Clique na aba **Webhooks**.
4. Clique em **Configurar Webhook** para Cobranças.

## 2. Dados do Webhook

Preencha os campos com as seguintes informações:

- **URL:** `https://<SUA-URL-CONVEX>.convex.site/api/webhooks/asaas`
  - Substitua `<SUA-URL-CONVEX>` pela URL do seu deployment Convex (ex: `https://happy-otter-123.convex.site`).
  - Você pode encontrar essa URL no dashboard do Convex em **Settings > URL & Deploy key**.

- **Email para notificações de erro:** Seu email de suporte.

- **Versão da API:** V3

- **Token de Autenticação (Auth Token):**
  - Gere uma string segura (ex: use `openssl rand -hex 32`).
  - Copie essa string.
  - Cole no campo "Token de Autenticação" no Asaas.
  - **IMPORTANTE:** Você deve configurar essa mesma string na variável de ambiente `ASAAS_WEBHOOK_SECRET` no seu dashboard Convex.

- **Fila de sincronização:** Ativada (recomendado).

## 3. Eventos

Selecione os seguintes eventos para monitorar:

### Cobranças

- [x] Pagamento confirmado (`PAYMENT_CONFIRMED`)
- [x] Pagamento recebido (`PAYMENT_RECEIVED`)
- [x] Pagamento estornado (`PAYMENT_REFUNDED`)

### Assinaturas

- [x] Assinatura atualizada (`SUBSCRIPTION_UPDATED`)
- [x] Assinatura inativada/cancelada (`SUBSCRIPTION_INACTIVATED`) (ou similar)

## 4. Variáveis de Ambiente no Convex

No dashboard do Convex, configure as seguintes variáveis:

| Variável               | Descrição                                                                  | Exemplo                   |
| ---------------------- | -------------------------------------------------------------------------- | ------------------------- |
| `ASAAS_API_KEY`        | Sua chave de API do Asaas (Sandbox ou Produção)                            | `$aact_YTU5...`           |
| `ASAAS_ENVIRONMENT`    | Ambiente da API                                                            | `sandbox` ou `production` |
| `ASAAS_WEBHOOK_SECRET` | O mesmo token que você definiu no campo "Token de Autenticação" do Webhook | `e5d...`                  |

## 5. Testando

### Sandbox

1. Use o ambiente Sandbox do Asaas para testes.
2. Gere um pagamento via Pix ou Cartão na aplicação.
3. No painel Sandbox do Asaas, você pode simular o pagamento da cobrança gerada.
4. Verifique se o saldo na aplicação foi atualizado automaticamente.

### Logs

Você pode verificar os logs de recebimento de webhook no dashboard do Convex em **Logs**. Procure por `[Asaas Webhook] Received event: ...`.
