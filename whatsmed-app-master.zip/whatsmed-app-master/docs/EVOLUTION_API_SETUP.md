# Evolution API Setup Guide

This project integrates with Evolution API v2 to handle WhatsApp functionality. This guide explains how to set up the Evolution API server and configure the integration.

## 1. Deploy Evolution API

You can deploy Evolution API using Docker or use a hosted version.

### Docker Compose

Create a `docker-compose.yml` file:

```yaml
version: "3.3"

services:
  evolution-api:
    container_name: evolution_api
    image: attri/evolution-api:v2.1.1
    restart: always
    ports:
      - "8080:8080"
    environment:
      - SERVER_TYPE=http
      - SERVER_PORT=8080
      - SERVER_URL=http://localhost:8080
      - API_KEY=CHANGE_ME_TO_A_SECURE_KEY
      - DATABASE_ENABLED=false
      # If you want to use database, configure PostgreSQL/MongoDB here
      # For this integration, we rely on webhooks, so local DB is optional but recommended for session persistence
    volumes:
      - evolution_store:/evolution/store

volumes:
  evolution_store:
```

Run:

```bash
docker-compose up -d
```

## 2. Configure Environment Variables

Update your `.env` file (or `.env.local`) in the root of the project with your Evolution API details:

```env
# Evolution API (WhatsApp)
EVOLUTION_API_URL=http://localhost:8080
EVOLUTION_API_KEY=CHANGE_ME_TO_A_SECURE_KEY

# Your Convex HTTP URL for webhooks
# Convex exposes http.route handlers on the .convex.site domain
CONVEX_SITE_URL=https://your-convex-site-url.convex.site
# Optional explicit override if you want Evolution to call a custom webhook URL
# EVOLUTION_WEBHOOK_URL=https://your-custom-domain.com/api/webhooks/evolution
```

## 3. Webhook Configuration

The integration automatically configures webhooks when you create a new instance. By default it points Evolution directly to the Convex HTTP endpoint, not your Vercel frontend. The webhook endpoint is:

`POST {CONVEX_SITE_URL}/api/webhooks/evolution`

This endpoint handles:

- QR Code updates
- Connection status changes
- Incoming messages

## 4. Usage Flow

1. Go to the **Integrations** page in the WhatsMed app.
2. Click "Connect" on the WhatsApp card.
3. A modal will appear. It will automatically create an instance on Evolution API.
4. Scan the displayed QR Code with your WhatsApp app (Linked Devices).
5. Once connected, the status will update to "Active".
6. Go to the **WhatsApp** page to view and send messages.

## 5. Troubleshooting

- **QR Code not appearing:** Check the browser console and Convex logs. Ensure `EVOLUTION_API_URL` is reachable from the backend.
- **Messages not arriving:** Check if the webhook URL is correctly set in Evolution API (you can check via Evolution API Manager or Swagger). It should normally be your `CONVEX_SITE_URL`, not the Vercel app domain.
- **Connection issues:** Restart the Evolution API container if it gets stuck.
