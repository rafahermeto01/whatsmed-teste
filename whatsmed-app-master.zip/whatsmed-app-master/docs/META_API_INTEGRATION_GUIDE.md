# Meta Cloud API Integration Guide

This project is set up with a dual-API architecture for WhatsApp, supporting both the **Evolution API** (unofficial, QR-code based) and the **Meta Cloud API** (official).

Currently, the Meta Cloud API integration is in **Phantom Mode**. This means it logs actions to the console but simulates successful responses without actually sending messages.

## How to Enable Real Meta Cloud API Integration

To switch from Phantom Mode to the real Meta Cloud API, follow these steps:

### 1. Create the Meta Client

Create a new file `packages/backend/convex/lib/whatsapp/meta.ts` that implements the `IWhatsAppProvider` interface using the real Meta Cloud API.

You can use the `metaPhantom.ts` file as a template.

**Key Implementation Details:**

- **Endpoint:** `https://graph.facebook.com/v19.0/${phoneNumberId}/messages`
- **Headers:**
  - `Authorization: Bearer ${accessToken}`
  - `Content-Type: application/json`
- **Payload (Text):**
  ```json
  {
    "messaging_product": "whatsapp",
    "recipient_type": "individual",
    "to": "PHONE_NUMBER",
    "type": "text",
    "text": { "body": "YOUR_MESSAGE" }
  }
  ```
- **24h Window:** Note that Meta allows free-form text messages only within 24 hours of the last user message. Outside this window, you must use **Templates**. The `sendText` method should handle this gracefully (e.g., by falling back to a template or throwing a specific error).

### 2. Update the Factory

Modify `packages/backend/convex/lib/whatsapp/factory.ts` to use your new `MetaProvider` instead of `MetaPhantomProvider`.

```typescript
// packages/backend/convex/lib/whatsapp/factory.ts

import { MetaProvider } from "./meta"; // Import the real provider

// ... inside getProvider ...
if (config.provider === "meta") {
  return new MetaProvider(config.metaPhoneNumberId, config.metaWabaId, config.metaAccessToken);
}
```

### 3. Configure Webhooks

The Meta Cloud API requires a webhook to receive incoming messages.

1.  **Create Endpoint:** You need to expose an endpoint at `/api/webhooks/meta`.
    - See `packages/backend/convex/http.ts`. You'll need to add a route handler there.
2.  **Verification:** Implement the GET verification challenge required by Meta.
    - Meta sends `hub.mode`, `hub.challenge`, and `hub.verify_token`.
    - You must return `hub.challenge` if the token matches.
3.  **Handling Messages:** Implement the POST handler to process incoming messages.
    - Normalize the Meta payload to match the internal `messages` table schema.
    - Call `internal.whatsapp.handleIncomingMessage` (similar to how Evolution webhook does it).

### 4. Switch Provider

Once implemented, you can switch any clinic to use the Meta API via the "API Mode" toggle in the WhatsApp Inbox or via the Connection Modal.

## Environment Variables

Ensure you have the necessary environment variables if you plan to verify webhooks using a secret token:

- `META_WEBHOOK_VERIFY_TOKEN`: A random string you define in your Meta App Dashboard.

## Resources

- [Meta Cloud API Documentation](https://developers.facebook.com/docs/whatsapp/cloud-api)
- [WhatsApp Business Platform](https://business.whatsapp.com/)
