---
status: resolved
trigger: "Investigate why appointment reminders are not reaching patients in this repository. Focus on the full reminder pipeline: appointment creation/reschedule -> automationActions.scheduleReminders/sendAppointmentConfirmation -> whatsappQueries/sendTextAction -> integrations/provider selection/UI. Look for runtime blockers, UI/backend mismatches, missing wiring, and config assumptions. Use code inspection only, plus any existing evidence from logs if available in repository context, but do not modify code. Return a concise ranked list of root causes with file paths and a short explanation of impact."
created: 2026-03-16T00:00:00Z
updated: 2026-03-16T01:00:00Z
---

## Current Focus

hypothesis: Multiple independent blockers exist: reminder configs may never be created, WhatsApp provider setup can remain disconnected, and Meta mode is simulation-only while the UI suggests it is usable.
test: Correlate appointment/reminder actions with reminder config lookup, sendTextAction provider gating, integration status mutations, and web provider-selection UI.
expecting: Code should show why confirmations/reminders are skipped or marked sent without real delivery.
next_action: report ranked root causes from code inspection

## Symptoms

expected: Appointment confirmations and reminders reach patients.
actual: Appointment reminders are not reaching patients.
errors: Unknown from prompt; inspect repository logs and code.
reproduction: Appointment creation/reschedule should flow into reminder scheduling and WhatsApp sending.
started: Unknown.

## Eliminated

## Evidence

- timestamp: 2026-03-16T00:20:00Z
  checked: `packages/backend/convex/appointments.ts` and `packages/backend/convex/automationActions.ts`
  found: Appointment creation always schedules `sendAppointmentConfirmation`, but that action exits early with `Config disabled or not found` when no `reminderConfigs` row exists; scheduled reminders only scan clinics returned by `getAllActiveReminderClinics`, which also depends on existing enabled `reminderConfigs` rows.
  implication: Clinics with no persisted reminder config never send confirmations or scheduled reminders at all.

- timestamp: 2026-03-16T00:30:00Z
  checked: `apps/web/src/routes/automation.tsx` and `packages/backend/convex/automation.ts`
  found: Reminder defaults live only in frontend state and are persisted only through autosave from the automation page; no backend seed/default creation path exists.
  implication: Reminders appear enabled in UI defaults but backend remains unconfigured until someone opens and saves the automation screen.

- timestamp: 2026-03-16T00:40:00Z
  checked: `apps/web/src/components/integrations/WhatsAppConnectModal.tsx` and `packages/backend/convex/integrations.ts`
  found: The QR flow calls `connectInstance()` directly, but `connectInstance` throws `Instance not found` unless `createInstance()` was called first; no UI caller invokes `createInstance`.
  implication: First-time Evolution setup is blocked, leaving clinics without a connected instance and causing sends to fail at runtime.

- timestamp: 2026-03-16T00:45:00Z
  checked: `apps/web/src/components/integrations/WhatsAppConnectModal.tsx`, `apps/web/src/routes/whatsapp.tsx`, `packages/backend/convex/integrations.ts`, and `packages/backend/convex/whatsapp.ts`
  found: Meta setup creates/switches a provider record but leaves status `disconnected`; the inbox UI treats configured Meta as usable, while `sendTextAction` hard-fails unless integration status is exactly `connected`. `fetchInstanceStatus` also always uses Evolution and will keep writing `disconnected` for Meta.
  implication: In Meta mode the UI can look connected while reminder sends fail with `WhatsApp instance not connected`.

- timestamp: 2026-03-16T00:50:00Z
  checked: `packages/backend/convex/lib/whatsapp/metaPhantom.ts`, `apps/web/src/components/integrations/WhatsAppConnectModal.tsx`, and `packages/backend/convex/whatsapp.ts`
  found: The Meta provider is explicitly a phantom/simulation provider that logs and returns fake success IDs; the modal warns `Mensagens serão registradas mas não enviadas realmente`.
  implication: Even if Meta mode were marked connected, patients still would not receive real WhatsApp reminders.

- timestamp: 2026-03-16T00:55:00Z
  checked: `apps/web/src/routes/automation.tsx`, `packages/backend/convex/automation.ts`, and `packages/backend/convex/whatsapp.ts`
  found: The reminder UI exposes a per-reminder `API Oficial` toggle and stores `useOfficialApi`, but send/dispatch code never reads that field; provider choice comes only from clinic-level `whatsappInstances.provider`.
  implication: Staff can configure reminder-level provider choices that have no effect, leading to false confidence and misdiagnosis.

## Resolution

root_cause: Reminder delivery is blocked by a combination of missing reminder config seeding, broken first-time Evolution setup, Meta-mode UI/backend mismatches, and Meta being simulation-only.
fix: No code changes applied.
verification: code inspection only; no repository logs with direct reminder runtime evidence were found.
files_changed: []
