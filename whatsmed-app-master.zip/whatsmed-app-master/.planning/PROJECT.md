# WhatsMed

## Current Milestone: v1.0 AI Flow Builder

**Goal:** Create a visual drag-and-drop flow builder that enables clinic admins to create proactive AI-driven conversation flows for WhatsApp.

**Target features:**

- Visual drag-and-drop flow builder UI
- Flow node types: Questions/Input, Message sending, Conditions/Logic, Tool execution, Flow control, AI integration
- Both conversational flows and scheduled campaign flows
- Flexible flow activation (per conversation and clinic-wide)
- AI manages flow execution with flow injected into system prompt
- Flow storage and management (create, edit, delete, activate/deactivate)
- Testing and debugging tools for flows

---

## What This Is

WhatsMed is a healthcare practice management SaaS for medical clinics in Brazil. It provides appointment scheduling, patient management, WhatsApp messaging with AI automation, billing with payment processing, and marketing automation. The platform enables clinics to communicate with patients via WhatsApp, manage appointments, handle payments, and automate patient outreach.

## Core Value

Clinics can efficiently communicate with patients via WhatsApp and automate patient interactions while maintaining professional service quality.

## Requirements

### Validated

<!-- Shipped and confirmed valuable. -->

- ✓ Multi-tenant clinic isolation with clinic-based data separation — Phase 0
- ✓ Role-based access control (admin, staff, doctor, viewer) — Phase 0
- ✓ User authentication with better-auth — Phase 0
- ✓ Appointment scheduling and management — Phase 0
- ✓ Patient management with profiles — Phase 0
- ✓ WhatsApp messaging with AI integration — Phase 0
- ✓ WhatsApp multi-provider support (Evolution API, Meta Cloud API) — Phase 0
- ✓ Google Calendar integration — Phase 0
- ✓ Billing and wallet system — Phase 0
- ✓ Asaas payment gateway integration — Phase 0
- ✓ Marketing automation (scheduled campaigns) — Phase 0
- ✓ Plan-based feature gating and subscription management — Phase 0

### Active

<!-- Current scope. Building toward these. -->

- [ ] Visual drag-and-drop flow builder UI for WhatsApp AI automation
- [ ] Flow node types: Questions/Input, Message sending, Conditions/Logic, Tool execution, Flow control, AI integration
- [ ] Flow storage and management (create, edit, delete, activate/deactivate)
- [ ] Flow execution engine with state management
- [ ] Flow injection into WhatsApp AI system prompts
- [ ] AI-managed flow execution with QA fallback
- [ ] Testing and debugging tools for flows
- [ ] Both conversational and scheduled campaign flow support
- [ ] Flexible flow activation (per conversation and clinic-wide)

### Out of Scope

<!-- Explicit boundaries. Includes reasoning to prevent re-adding. -->

- Video/telemedicine consultations — Not in this milestone
- Prescription management — Not in this milestone
- Advanced analytics and reporting — Not in this milestone
- Mobile applications — Not in this milestone

## Context

**Existing Codebase State:**

- Monorepo structure with TanStack Start frontend and Convex backend
- Multi-tenant architecture with clinic-based isolation
- Role-based access control already implemented
- WhatsApp AI system exists but is reactive-only (responds to patient questions, doesn't proactively drive conversations)
- Better-auth for authentication
- Asaas for payments, Evolution API and Meta Cloud API for WhatsApp
- Google Calendar integration for appointments

**Current WhatsApp AI Behavior:**

- AI is reactive - waits for patient messages
- Has access to tools (appointment booking, patient data lookup, etc.)
- Responds to patient questions and requests
- Does not proactively guide conversations or ask questions

**User Goal:**

- Enable clinic admins to build proactive conversation flows
- Visual drag-and-drop builder accessible via AI tab
- Flows should guide conversations while allowing AI to answer questions that arise
- AI should manage flow execution with flexibility (not rigid step-by-step)

**Technical Constraints:**

- Must integrate with existing WhatsApp AI system
- Must work with existing multi-tenant architecture
- Must respect existing RBAC and plan enforcement
- Must work with Evolution API and Meta Cloud API providers

## Constraints

- **Tech Stack**: Must use existing stack (React, TanStack Start, Convex, TypeScript) — Ensures consistency with existing codebase
- **Database**: All data stored in Convex with proper multi-tenant isolation — Existing infrastructure requirement
- **Authentication**: Use better-auth with existing session management — Security and consistency
- **Performance**: Flow execution must not block AI response times — Critical for user experience
- **Plans**: Flow builder features gated by subscription tiers — Business model alignment
- **UI/UX**: Must be intuitive for non-technical clinic admins — Usability requirement

## Key Decisions

<!-- Decisions that constrain future work. Add throughout project lifecycle. -->

| Decision                          | Rationale                                                         | Outcome   |
| --------------------------------- | ----------------------------------------------------------------- | --------- |
| Visual drag-and-drop builder      | Non-technical admins need intuitive way to create flows           | — Pending |
| AI manages flow execution         | Allows flexibility in conversation flow while following structure | — Pending |
| Flow injection into system prompt | Leverages existing AI capabilities with minimal changes           | — Pending |

---

_Last updated: 2026-02-04 after initial milestone definition_
