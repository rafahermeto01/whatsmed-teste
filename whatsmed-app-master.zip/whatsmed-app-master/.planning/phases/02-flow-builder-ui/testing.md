# Phase 2: Flow Builder UI - Manual Testing Checklist

**Created:** 2026-02-05
**Purpose:** Verify all Phase 2 success criteria through manual testing

---

## Prerequisites

- Dev server running at http://localhost:3001
- Convex functions deployed to production deployment
- Authenticated user with clinic account (login required)

---

## Test 1: Drag-and-Drop Node Creation (FBUI-01)

**Steps:**

1. Navigate to http://localhost:3001/flows
2. If not authenticated, login to your clinic account
3. Drag each node type from palette to canvas:
   - Message (blue)
   - Condition (orange)
   - Input (green)
   - Wait (purple)

**Expected Results:**

- [ ] All four node types appear in palette with icons
- [ ] Dragging a node shows visual feedback
- [ ] Dropped nodes render on canvas with correct design
- [ ] Nodes show icons and type labels
- [ ] Nodes show content previews (empty placeholders initially)

**Actual Results:**

```
_______________________________________________________________
```

---

## Test 2: Node Connections (FBUI-02, FBUI-03)

**Steps:**

1. Drag from output handle (right side of node) to input handle (left side of another node)
2. Create connections between different node types
3. Verify connections render as smooth bezier curves
4. Test edge removal:
   - Hover over a connection
   - Click the red 'x' button that appears at midpoint
   - Alternatively, select the connection and press Delete key

**Expected Results:**

- [ ] Connections follow mouse during drag (visual feedback)
- [ ] Connections create when dropped on input handle
- [ ] Connections render as smooth bezier curves (not straight lines)
- [ ] Arrow markers show flow direction at connection endpoints
- [ ] Hovering over connection shows red 'x' button at midpoint
- [ ] Clicking 'x' button removes only that connection
- [ ] Delete key removes selected connection
- [ ] Removing a connection doesn't affect other connections

**Actual Results:**

```
_______________________________________________________________
```

---

## Test 3: Node Configuration (FBUI-04)

**Steps:**

1. Click on a Message node
2. Verify Node Properties panel opens with correct fields
3. Edit message text: "Olá, como você está hoje?"
4. Verify node preview updates in real-time
5. Repeat for each node type:
   - **Condition node:** Configure condition (equals, patient.name, "João")
   - **Input node:** Configure prompt ("Qual é seu nome?") and variable name (nome)
   - **Wait node:** Configure duration (5, minutes)

**Expected Results:**

- [ ] Clicking node selects it with visual indicator (border/ring)
- [ ] Right sidebar shows "Propriedades" tab for selected node
- [ ] Node Properties panel shows correct fields for each node type:
  - Message: Textarea for message content
  - Condition: Type select, variable input, value input
  - Input: Textarea for prompt, input for variable name
  - Wait: Number input for duration, select for unit
- [ ] Editing field values updates node preview immediately
- [ ] Clicking canvas deselects nodes
- [ ] Clicking different node switches properties panel to new node

**Actual Results:**

```
_______________________________________________________________
```

---

## Test 4: Variable Support (FMAN-07, FMAN-08)

**Steps:**

1. Click on right sidebar "Configurações" (Flow Settings) tab
2. Click "+" button to add variable
3. Configure variable:
   - Name: patient_name
   - Type: string
   - Default value: (leave empty)
4. Switch to "Propriedades" (Node Properties) tab
5. Select a Message node
6. Edit message text with variable reference: "Olá {{patient_name}}, tudo bem?"

**Expected Results:**

- [ ] Flow Settings tab shows "Variáveis" section
- [ ] Add variable button creates new variable row
- [ ] Variable row shows name input, type select, default value input
- [ ] Delete button removes variable from list
- [ ] Variable types: string, number, boolean available
- [ ] Message text accepts {{variable}} syntax without error
- [ ] Variable reference displays in message preview

**Actual Results:**

```
_______________________________________________________________
```

---

## Test 5: Flow Validation (FBUI-06)

**Steps:**

1. Create Message node with empty message text
2. Create Condition node without variable/value configured
3. Create Input node without prompt configured
4. Create Wait node with duration 0 or empty
5. Verify validation errors appear

**Expected Results:**

- [ ] Incomplete Message node shows red border + ring
- [ ] Red AlertCircle icon appears on Message node
- [ ] Error message "Mensagem é obrigatória" displays below Message node
- [ ] Incomplete Condition node shows red border + ring
- [ ] Error message "Configure condição (variável e valor)" displays
- [ ] Incomplete Input node shows red border + ring
- [ ] Error message "Prompt é obrigatório" and/or "Nome da variável é obrigatório" displays
- [ ] Incomplete Wait node shows red border + ring
- [ ] Error message "Duração deve ser maior que zero" displays
- [ ] Validation summary badge shows error count (e.g., "4 erros críticos")

**Fix and Verify:**

1. Fix all errors (fill in required fields)
2. Verify red error indicators disappear
3. [ ] All red borders and error messages clear

**Actual Results:**

```
_______________________________________________________________
```

---

## Test 6: Canvas Navigation (FBUI-05)

**Steps:**

1. Use zoom controls (+/- buttons) to zoom in and out
2. Click fit-to-screen button (center square icon)
3. Click lock/unlock pan button (padlock icon)
4. Drag canvas background to pan
5. Use mouse wheel to zoom (if supported)

**Expected Results:**

- [ ] Zoom + button increases node sizes
- [ ] Zoom - button decreases node sizes
- [ ] Fit-to-screen button centers all nodes in view
- [ ] Pan is locked by default (dragging nodes doesn't pan canvas)
- [ ] Unlocking pan allows canvas background dragging
- [ ] Pan movement is smooth and responsive
- [ ] Mouse wheel zooms in/out (if supported)

**Actual Results:**

```
_______________________________________________________________
```

---

## Test 7: Node and Edge Deletion (FBUI-07)

**Steps:**

1. Click to select a node
2. Press Delete or Backspace key
3. Verify node is removed
4. Click to select a connection (edge)
5. Press Delete key
6. Verify connection is removed
7. Select multiple nodes (if supported) and delete
8. Verify deletion doesn't break other connections

**Expected Results:**

- [ ] Selected node shows visual indicator (border/ring)
- [ ] Delete key removes selected node
- [ ] All connections to/from deleted node are also removed
- [ ] Other nodes and connections unaffected
- [ ] Deleted node cannot be recovered (no undo yet)
- [ ] Connection selection shows visual indicator (thicker line)
- [ ] Delete key removes selected connection
- [ ] Remaining connections unaffected

**Actual Results:**

```
_______________________________________________________________
```

---

## Test 8: Flow Save and Load

**Steps:**

1. Create a test flow with all node types connected
2. Configure some nodes with sample data
3. Open Flow Settings tab
4. Edit flow name: "Test Flow - Phase 2 Verification"
5. Edit flow description: "Manual test flow for Phase 2"
6. Click "Salvar Fluxo" button
7. Verify success toast appears
8. Refresh page (F5 or Cmd+R)
9. Verify flow loads correctly

**Expected Results:**

- [ ] Flow name input updates flow metadata
- [ ] Flow description textarea saves description
- [ ] Save button shows loading state while saving
- [ ] Success toast "Fluxo salvo com sucesso" appears
- [ ] After refresh, all nodes load in correct positions
- [ ] All connections restore correctly
- [ ] Node configurations (message text, conditions, etc.) preserved
- [ ] Flow settings (name, description) restored
- [ ] Variables defined in Flow Settings persist

**Actual Results:**

```
_______________________________________________________________
```

---

## Test 9: Overall UX and Layout

**Steps:**

1. Verify three-column layout structure
2. Test tab switching between Node Properties and Flow Settings
3. Test node selection/deselection
4. Test responsiveness on different screen sizes (browser resize)
5. Check accessibility (keyboard navigation, screen reader compatibility)

**Expected Results:**

- [ ] Left: MainLayout navigation sidebar (280px)
- [ ] Center: Canvas with NodePalette toolbar above FlowCanvas
- [ ] Right: Tabbed properties panel (320px)
- [ ] Tabs work correctly (switch between Propriedades/Informações)
- [ ] Tab switches preserve state (form values don't reset)
- [ ] Clicking node selects it, shows properties
- [ ] Clicking canvas deselects, clears properties panel
- [ ] Layout remains usable at 1280x720 resolution
- [ ] Layout remains usable at smaller resolutions (flexible responsive)
- [ ] Colors are accessible (good contrast between text and background)
- [ ] Icons are clear and recognizable

**Actual Results:**

```
_______________________________________________________________
```

---

## Overall Verification

**Phase 2 Success Criteria:**

1. [ ] Clinic admin can create flows by dragging node types (Message, Condition, Input, Wait) onto canvas (FBUI-01)
2. [ ] Clinic admin can connect nodes to create flow logic and configure node properties (FBUI-02, FBUI-03, FBUI-04)
3. [ ] Clinic admin can define variables in flows and reference them in message text with {{variable}} syntax (FMAN-07, FMAN-08)
4. [ ] Clinic admin sees validation errors when flow is incomplete or broken (FBUI-06)
5. [ ] Clinic admin can navigate canvas with zoom/pan and delete nodes/connections (FBUI-05, FBUI-07)

**Phase 2 Status:**

- [ ] All success criteria met - Ready to proceed to Phase 3
- [ ] Partial completion - Some criteria met, issues found
- [ ] Not complete - Major issues blocking progression

**Issues Found (if any):**

```
_______________________________________________________________
```

---

## Notes

- Document any observations, unexpected behaviors, or bugs discovered
- Note any UX improvements or suggestions
- Record browser/version tested
- Note any performance issues or latency concerns

```
_______________________________________________________________
```

---

**Testing completed:** ******\*\*\*\*******\_******\*\*\*\*******
**Tested by:** ******\*\*\*\*******\_******\*\*\*\*******
**Next step:** After approval, run `/gsd-execute-phase 2 --continue` to complete phase
