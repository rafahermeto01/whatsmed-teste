# Phase 2: Flow Builder UI - Context

**Gathered:** 2026-02-04
**Status:** Ready for planning

<domain>
## Phase Boundary

Visual drag-and-drop interface where clinic admins create flows by adding, connecting, and configuring nodes (Message, Condition, Input, Wait) on a canvas. Users can define variables, see validation errors, navigate the canvas, and delete nodes/connections.

</domain>

<decisions>
## Implementation Decisions

### Canvas layout & panels

- Maintain existing left sidebar (platform navigation)
- Center canvas for flow building
- Right sidebar contains both node properties and flow settings
- Tabbed interface at top of right sidebar: "Node Properties" tab and "Flow Settings" tab

### Node visual design

- Rectangle with rounded edges, following the visual language of the rest of the platform
- Node types distinguished by both color coding and unique icons
- Nodes display icon + preview of content (first line of message, condition logic preview, wait duration)
- Connection handles (ports) always visible on nodes

### Connection behavior

- Smooth bezier curves for connection lines between nodes
- Input/output based connection rules (Condition nodes have multiple output branches, others have single input/output)
- Remove connections by clicking 'x' button on the connection line when hovered

### Claude's Discretion

- Connection creation visual feedback during drag (live line preview, ghost line, or cursor trail)
- Specific color scheme for node type color coding
- Exact position and style of connection handles on nodes
- Handle placement rules (which nodes have inputs/outputs, how many)
- Spacing, sizing, and shadow effects for nodes

### Validation & errors

- Validation errors displayed inline on affected nodes
- Error indicator: red border + icon on nodes with errors
- Two severity levels: Critical errors (red, blocks saving/activating) and Warnings (yellow/amber, can save)
- Error messages always visible below or on the affected node

</decisions>

<specifics>
## Specific Ideas

- Flow builder should feel consistent with the rest of the platform's visual language
- User wants to maintain existing left sidebar for platform navigation
- Tabbed interface in right sidebar to separate node configuration from flow-level settings

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope

</deferred>

---

_Phase: 02-flow-builder-ui_
_Context gathered: 2026-02-04_
