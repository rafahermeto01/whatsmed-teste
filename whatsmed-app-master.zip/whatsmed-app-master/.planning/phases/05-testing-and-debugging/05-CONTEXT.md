# Phase 5: Testing & Debugging - Context

**Gathered:** 2026-02-05
**Status:** Ready for planning

<domain>
## Phase Boundary

Tools that clinic admins USE to verify flows work correctly before deploying to real patients. Includes manual testing interface for simulating patient conversations, execution monitoring, and debugging capabilities. Does NOT include automated testing suites or CI/CD pipelines.

</domain>

<decisions>
## Implementation Decisions

### Manual testing interface

- Chat-like interface (bottom input, conversation history scrolls above — WhatsApp web style)
- Full testing controls: play/pause/reset/step through nodes
- Real AI responses during testing (actual AI calls with flow context)
- Side panel for viewing and editing variable values in real-time during testing

### Claude's Discretion

- Exact visual design of side panel (variable editor)
- Layout proportions for chat vs controls
- Loading states during AI response
- Error state visuals within testing interface

</decisions>

<specifics>
## Specific Ideas

- "Full controls" means: pause on conditions, step through node by node, resume normal flow
- Real AI responses are essential — testing with mocks doesn't validate actual AI behavior
- Variables editable during conversation lets admin test edge cases without restarting

</specifics>

<deferred>
## Deferred Ideas

- Execution history display format — did not discuss (timeline vs table, filters)
- Error presentation details — did not discuss (inline vs panel, severity levels)
- Testing environment isolation — did not discuss (sandbox vs real data)

</deferred>

---

_Phase: 05-testing-and-debugging_
_Context gathered: 2026-02-05_
