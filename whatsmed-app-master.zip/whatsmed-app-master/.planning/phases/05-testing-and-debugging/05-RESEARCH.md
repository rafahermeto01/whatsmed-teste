# Phase 05: Testing & Debugging - Research

**Researched:** 2026-02-05
**Domain:** React/Convex/Mastra testing interface for flow execution debugging
**Confidence:** MEDIUM-HIGH

## Summary

This phase requires building a clinic admin testing interface for WhatsApp-style flow conversations with full debugging controls. The research reveals that modern 2025 patterns favor **real-time, visual debugging** over traditional log-based approaches.

The standard approach combines:

1. **Chat simulation UI** with WhatsApp-style message bubbles, infinite scroll, and real-time AI responses
2. **Visual flow debugging** via React Flow DevTools with animated edge highlighting for active execution paths
3. **Side panel variable editing** allowing real-time state modification during paused execution
4. **Convex real-time subscriptions** for live testing updates and execution logging
5. **Mastra workflow streaming** for step-by-step execution with pause/resume capabilities

**Primary recommendation:** Build a unified testing canvas with chat on the left, visual flow with highlighted execution path in the center, and variable inspector side panel on the right. Use Convex subscriptions for all real-time updates and Mastra's `.stream()` API for step-through debugging.

## Standard Stack

### Core

| Library               | Version | Purpose                                | Why Standard                                                                        |
| --------------------- | ------- | -------------------------------------- | ----------------------------------------------------------------------------------- |
| @xyflow/react         | 12.x    | Visual flow builder with DevTools      | Industry standard for node-based UIs; DevTools provide built-in debugging           |
| convex                | Latest  | Real-time database + execution logging | Native WebSocket subscriptions; built-in execution history via queries              |
| @mastra/core          | Latest  | Flow execution engine                  | Supports `.stream()` for step-through debugging; built-in workflow state management |
| @tanstack/react-query | 5.x     | Data fetching + caching                | Integrates with Convex; supports optimistic updates for variable editing            |

### Supporting

| Library        | Version | Purpose                     | When to Use                                    |
| -------------- | ------- | --------------------------- | ---------------------------------------------- |
| react-virtuoso | Latest  | Message list virtualization | When conversation history exceeds 100 messages |
| zustand        | 5.x     | Local testing state         | Managing play/pause/step mode UI state         |
| shadcn/ui      | Latest  | Testing UI components       | Pre-built chat bubbles, panels, controls       |
| lucide-react   | Latest  | Testing control icons       | Play/pause/step/reset icons                    |

### Alternatives Considered

| Instead of             | Could Use        | Tradeoff                                                  |
| ---------------------- | ---------------- | --------------------------------------------------------- |
| Mastra's `.stream()`   | Custom WebSocket | Mastra handles backpressure, resume state, error recovery |
| Custom variable editor | Monaco Editor    | Monaco is heavy; simple key-value editor sufficient       |
| AG Grid for history    | TanStack Table   | TanStack Table lighter for simple execution logs          |

**Installation:**

```bash
npm install react-virtuoso zustand lucide-react
```

## Architecture Patterns

### Recommended Project Structure

```
src/
├── app/
│   ├── routes/
│   │   ├── __root.tsx                    # Root layout
│   │   ├── flows.$flowId.testing.tsx     # Testing interface page
│   │   └── flows.$flowId.history.tsx     # Execution history page
│   └── components/
│       └── testing/
│           ├── TestingCanvas.tsx         # Main container
│           ├── ChatSimulator.tsx         # WhatsApp-style chat
│           ├── FlowDebugger.tsx          # Visual flow + highlights
│           ├── VariableInspector.tsx     # Side panel editor
│           ├── TestControls.tsx          # Play/pause/step/reset
│           └── ExecutionLog.tsx          # Real-time step log
├── convex/
│   ├── flows/
│   │   ├── testing.ts                   # Testing mutations/queries
│   │   └── executions.ts                # Execution logging
│   └── schema.ts                        # Execution history tables
└── lib/
    ├── flow-engine/
    │   ├── test-runner.ts               # Mastra test runner wrapper
    │   └── execution-logger.ts          # Convex logging integration
    └── testing/
        └── useTestSession.ts            # Test session state hook
```

### Pattern 1: Real-Time Test Session State

**What:** Use Zustand for local UI state combined with Convex subscriptions for execution state
**When to use:** When you need instant UI feedback (play/pause buttons) + server-synced state (execution progress)
**Example:**

```typescript
// Source: Convex docs (https://docs.convex.dev/client/react) + 2025 patterns
import { create } from "zustand";
import { useQuery } from "convex/react";

interface TestSessionState {
  mode: "playing" | "paused" | "stepping";
  currentNodeId: string | null;
  setMode: (mode: "playing" | "paused" | "stepping") => void;
}

const useTestSessionStore = create<TestSessionState>((set) => ({
  mode: "paused",
  currentNodeId: null,
  setMode: (mode) => set({ mode }),
}));

// In component
function TestingCanvas({ flowId }: { flowId: string }) {
  // Local UI state (instant)
  const { mode, setMode } = useTestSessionStore();

  // Server-synced execution state (real-time via Convex)
  const execution = useQuery(api.flows.testing.getActiveExecution, { flowId });

  // Sync server state to local when paused
  useEffect(() => {
    if (execution?.currentNodeId && mode === "paused") {
      useTestSessionStore.setState({ currentNodeId: execution.currentNodeId });
    }
  }, [execution?.currentNodeId, mode]);
}
```

### Pattern 2: Chat Simulation with Virtualization

**What:** WhatsApp-style chat with reverse infinite scroll and message grouping
**When to use:** When testing conversations may exceed 50+ messages
**Example:**

```typescript
// Source: 2025 React chat patterns + React Virtuoso docs
import { Virtuoso } from 'react-virtuoso';
import { useQuery } from 'convex/react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  nodeId?: string; // Which flow node generated this
}

function ChatSimulator({ flowId }: { flowId: string }) {
  // Real-time messages via Convex subscription
  const messages = useQuery(api.flows.testing.getMessages, { flowId });

  return (
    <Virtuoso
      data={messages || []}
      followOutput="auto" // Auto-scroll to new messages
      itemContent={(index, message) => (
        <MessageBubble
          message={message}
          isActive={activeNodeId === message.nodeId} // Highlight from current step
        />
      )}
    />
  );
}

// Message grouping: consecutive same-sender messages within 5 min
function shouldGroup(current: ChatMessage, previous: ChatMessage): boolean {
  return (
    current.role === previous.role &&
    current.timestamp - previous.timestamp < 5 * 60 * 1000
  );
}
```

### Pattern 3: Visual Execution Path Highlighting

**What:** Animate edges and highlight active nodes during flow execution
**When to use:** When debugging which path through the flow was taken
**Example:**

```typescript
// Source: React Flow DevTools patterns (https://reactflow.dev/learn/advanced-use/devtools-and-debugging)
import { useNodes, useEdges } from '@xyflow/react';

function FlowDebugger({ flowId }: { flowId: string }) {
  const nodes = useNodes();
  const edges = useEdges();

  // Get current execution state from Convex
  const execution = useQuery(api.flows.testing.getExecutionState, { flowId });

  // Highlight active node and path
  const nodesWithStatus = nodes.map(node => ({
    ...node,
    className: cn(
      node.className,
      execution?.currentNodeId === node.id && 'ring-2 ring-blue-500',
      execution?.completedNodes?.includes(node.id) && 'opacity-50'
    ),
  }));

  // Animate edge from previous to current node
  const edgesWithAnimation = edges.map(edge => ({
    ...edge,
    animated: execution?.activeEdge?.id === edge.id,
    style: {
      ...edge.style,
      stroke: execution?.activeEdge?.id === edge.id ? '#3b82f6' : undefined,
    },
  }));

  return (
    <ReactFlow
      nodes={nodesWithStatus}
      edges={edgesWithAnimation}
      // ... other props
    />
  );
}
```

### Pattern 4: Variable Inspector Side Panel

**What:** Real-time variable editor that syncs with execution state
**When to use:** When admin needs to test edge cases by changing variables mid-flow
**Example:**

```typescript
// Source: Claude's discretion area (visual design recommendation)
import { useMutation, useQuery } from 'convex/react';

interface Variable {
  name: string;
  value: unknown;
  type: 'string' | 'number' | 'boolean' | 'object';
  lastModified: number;
  modifiedBy: 'flow' | 'user' | 'ai';
}

function VariableInspector({ flowId }: { flowId: string }) {
  const variables = useQuery(api.flows.testing.getVariables, { flowId });
  const updateVariable = useMutation(api.flows.testing.updateVariable);

  return (
    <div className="w-80 border-l bg-gray-50 p-4 flex flex-col">
      <h3 className="font-semibold mb-4">Variables</h3>

      <div className="flex-1 overflow-y-auto space-y-2">
        {variables?.map((variable) => (
          <VariableEditor
            key={variable.name}
            variable={variable}
            onChange={async (newValue) => {
              await updateVariable({
                flowId,
                name: variable.name,
                value: newValue,
                modifiedBy: 'user',
              });
            }}
            disabled={executionMode === 'playing'} // Lock during auto-play
          />
        ))}
      </div>
    </div>
  );
}

// Individual variable editor with type-aware input
function VariableEditor({ variable, onChange, disabled }: VariableEditorProps) {
  return (
    <div className={cn(
      "p-2 rounded border",
      variable.modifiedBy === 'user' && "border-yellow-400 bg-yellow-50",
      disabled && "opacity-50"
    )}>
      <div className="flex justify-between items-center mb-1">
        <span className="font-medium text-sm">{variable.name}</span>
        <span className="text-xs text-gray-500">{variable.type}</span>
      </div>

      {variable.type === 'string' && (
        <input
          type="text"
          value={variable.value as string}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
          className="w-full px-2 py-1 text-sm border rounded"
        />
      )}

      {variable.type === 'object' && (
        <textarea
          value={JSON.stringify(variable.value, null, 2)}
          onChange={(e) => onChange(JSON.parse(e.target.value))}
          disabled={disabled}
          className="w-full px-2 py-1 text-xs font-mono border rounded h-20"
        />
      )}
    </div>
  );
}
```

### Pattern 5: Execution History Logging

**What:** Persist all flow executions to Convex with filtering and pagination
**When to use:** When admin needs to review past test runs and compare results
**Example:**

```typescript
// Source: Convex schema patterns (https://docs.convex.dev/database/reading-data)
// convex/schema.ts
import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  flowExecutions: defineTable({
    flowId: v.id("flows"),
    flowVersion: v.number(),
    patientId: v.optional(v.string()), // Simulated patient for testing
    status: v.union(
      v.literal("running"),
      v.literal("completed"),
      v.literal("failed"),
      v.literal("paused"),
    ),
    startedAt: v.number(),
    completedAt: v.optional(v.number()),
    result: v.optional(v.any()),
    error: v.optional(
      v.object({
        message: v.string(),
        stack: v.optional(v.string()),
        nodeId: v.optional(v.string()),
      }),
    ),
  })
    .index("by_flow", ["flowId", "startedAt"])
    .index("by_status", ["status", "startedAt"]),

  executionSteps: defineTable({
    executionId: v.id("flowExecutions"),
    nodeId: v.string(),
    stepNumber: v.number(),
    input: v.any(),
    output: v.any(),
    variables: v.any(), // Snapshot of all variables at this step
    timestamp: v.number(),
    durationMs: v.number(),
  }).index("by_execution", ["executionId", "stepNumber"]),
});

// convex/flows/executions.ts
import { query, mutation } from "./_generated/server";

export const getExecutionHistory = query({
  args: {
    flowId: v.id("flows"),
    limit: v.optional(v.number()),
    cursor: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("flowExecutions")
      .withIndex("by_flow", (q) => q.eq("flowId", args.flowId))
      .order("desc")
      .paginate(args);
  },
});

export const logExecutionStep = mutation({
  args: {
    executionId: v.id("flowExecutions"),
    nodeId: v.string(),
    input: v.any(),
    output: v.any(),
    variables: v.any(),
    durationMs: v.number(),
  },
  handler: async (ctx, args) => {
    const execution = await ctx.db.get(args.executionId);
    if (!execution) throw new Error("Execution not found");

    // Count existing steps to determine step number
    const existingSteps = await ctx.db
      .query("executionSteps")
      .withIndex("by_execution", (q) => q.eq("executionId", args.executionId))
      .collect();

    await ctx.db.insert("executionSteps", {
      executionId: args.executionId,
      nodeId: args.nodeId,
      stepNumber: existingSteps.length + 1,
      input: args.input,
      output: args.output,
      variables: args.variables,
      timestamp: Date.now(),
      durationMs: args.durationMs,
    });
  },
});
```

### Anti-Patterns to Avoid

- **Logging to console only:** Execution data must be persisted to Convex for history review; console logs disappear on refresh
- **Storing execution state only in React state:** Use Convex as source of truth so multiple tabs/devices see same testing state
- **Polling for execution updates:** Use Convex subscriptions (WebSocket) instead of polling for real-time updates
- **Editing variables without tracking:** Always record `modifiedBy` and timestamp for audit trail

## Don't Hand-Roll

| Problem                      | Don't Build                | Use Instead                         | Why                                                            |
| ---------------------------- | -------------------------- | ----------------------------------- | -------------------------------------------------------------- |
| Chat message virtualization  | Custom scroll handling     | react-virtuoso                      | Handles reverse scroll, auto-scroll, dynamic heights correctly |
| Flow execution engine        | Custom step runner         | Mastra workflows                    | Handles suspend/resume, error recovery, state persistence      |
| Real-time data sync          | Custom WebSocket           | Convex subscriptions                | Automatic reconnection, caching, optimistic updates            |
| Variable state tracking      | useState/useReducer        | Zustand + Convex                    | Time-travel debugging, persistence, cross-tab sync             |
| Execution path visualization | Custom SVG overlay         | React Flow edges + animated styling | Built-in zoom, pan, node positioning                           |
| Testing control UI           | Custom buttons             | shadcn/ui Button + Toggle           | Accessible, keyboard navigable, consistent styling             |
| Date/time formatting         | Intl.DateTimeFormat manual | date-fns                            | Relative time ("2 min ago"), timezone handling                 |

**Key insight:** The combination of Mastra (execution) + Convex (real-time sync) + React Flow (visualization) provides 90% of what's needed. Custom code should only handle UI layout and testing-specific business logic.

## Common Pitfalls

### Pitfall 1: Lost Execution State on Server Restart

**What goes wrong:** Test runs disappear or reset when the dev server restarts because execution state is only in memory
**Why it happens:** Mastra's default in-memory storage loses state on restart; Convex actions don't persist execution state by default
**How to avoid:**

- Configure Mastra with persistent storage provider (Convex-compatible)
- Save execution snapshots to Convex after each step
- Use `workflow.restart()` capability for resuming interrupted runs
  **Warning signs:** Test runs start from beginning after page refresh; variables reset unexpectedly

### Pitfall 2: Variable Edit Race Conditions

**What goes wrong:** User edits variable but next step overwrites it with old value because AI response was in flight
**Why it happens:** Variables updated via mutation, but AI action started with old values; race between user edit and AI completion
**How to avoid:**

- Lock variable editing when `executionMode === 'playing'`
- Queue variable changes when AI is processing
- Show "pending" state on variables modified during execution
  **Warning signs:** Variable values "jump back" to previous values; edits don't stick

### Pitfall 3: Memory Leak from Subscriptions

**What goes wrong:** Browser slows down after multiple test runs; lag when switching between flows
**Why it happens:** Convex subscriptions not cleaned up when unmounting; old test sessions still receiving updates
**How to avoid:**

- Always unsubscribe in useEffect cleanup
- Use "skip" pattern for conditional queries: `useQuery(api.x.y, condition ? { args } : 'skip')`
- Limit execution history queries with pagination
  **Warning signs:** Tab becomes sluggish; network tab shows increasing WebSocket traffic

### Pitfall 4: Infinite Re-render Loops

**What goes wrong:** Testing UI refreshes constantly, making it unusable; CPU spikes
**Why it happens:** Zustand state update triggers Convex mutation, which triggers subscription update, which updates Zustand state
**How to avoid:**

- Separate "UI mode" (local Zustand) from "execution state" (Convex)
- Use `useMemo` for derived values (active edge calculation)
- Debounce rapid state changes
  **Warning signs:** React DevTools Profiler shows hundreds of commits per second

### Pitfall 5: Chat Scroll Jank

**What goes wrong:** Chat scroll jumps around when new AI message arrives; user loses their place
**Why it happens:** Missing virtualization or incorrect scroll handling with reverse infinite scroll
**How to avoid:**

- Use react-virtuoso with `followOutput="auto"` for auto-scroll
- Implement "scroll to bottom" button when user scrolls up
- Maintain scroll position when loading older messages
  **Warning signs:** Scrollbar thumb bounces; messages appear above viewport unexpectedly

## Code Examples

### Mastra Workflow Streaming for Testing

```typescript
// Source: Mastra docs (https://mastra.ai/docs/workflows/overview)
// lib/flow-engine/test-runner.ts
import { Mastra } from "@mastra/core/mastra";

export async function runTestWithControls(
  workflow: any,
  input: any,
  controls: { mode: "play" | "pause" | "step" },
) {
  const run = await workflow.createRun();

  if (controls.mode === "play") {
    // Normal execution
    return await run.start({ inputData: input });
  }

  if (controls.mode === "step") {
    // Step-through: stream and pause after each step
    const stream = run.stream({ inputData: input });
    const steps = [];

    for await (const chunk of stream.fullStream) {
      steps.push(chunk);

      // Pause after each step for UI update
      if (chunk.type === "step-complete") {
        await waitForUserContinue(); // UI signal
      }
    }

    return await stream.result;
  }
}
```

### Real-Time Testing State Hook

```typescript
// Source: Convex React patterns + Zustand
// lib/testing/useTestSession.ts
import { useCallback } from "react";
import { useQuery, useMutation } from "convex/react";
import { create } from "zustand";

interface TestSession {
  executionId: string | null;
  mode: "idle" | "playing" | "paused" | "stepping";
  currentStep: number;
}

export function useTestSession(flowId: string) {
  // Server state
  const execution = useQuery(api.flows.testing.getActiveExecution, { flowId });

  // Local UI state
  const { mode, setMode } = useTestSessionStore();

  // Controls
  const startTest = useMutation(api.flows.testing.startTest);
  const pauseTest = useMutation(api.flows.testing.pauseTest);
  const stepTest = useMutation(api.flows.testing.stepTest);
  const resetTest = useMutation(api.flows.testing.resetTest);

  const play = useCallback(async () => {
    setMode("playing");
    await startTest({ flowId });
  }, [flowId, startTest, setMode]);

  const pause = useCallback(async () => {
    setMode("paused");
    await pauseTest({ flowId });
  }, [flowId, pauseTest, setMode]);

  const step = useCallback(async () => {
    setMode("stepping");
    await stepTest({ flowId });
    setMode("paused");
  }, [flowId, stepTest, setMode]);

  const reset = useCallback(async () => {
    setMode("idle");
    await resetTest({ flowId });
  }, [flowId, resetTest, setMode]);

  return {
    execution,
    mode,
    play,
    pause,
    step,
    reset,
    isRunning: mode === "playing",
    canStep: mode === "paused" && execution?.status === "paused",
  };
}
```

### Testing Layout (Chat + Flow + Variables)

```typescript
// Source: Claude's discretion recommendations
// app/components/testing/TestingCanvas.tsx
export function TestingCanvas({ flowId }: { flowId: string }) {
  const { mode, play, pause, step, reset } = useTestSession(flowId);

  return (
    <div className="h-screen flex flex-col">
      {/* Toolbar */}
      <TestToolbar
        mode={mode}
        onPlay={play}
        onPause={pause}
        onStep={step}
        onReset={reset}
      />

      {/* Main content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Chat panel (left, 35%) */}
        <div className="w-[35%] border-r flex flex-col">
          <ChatSimulator flowId={flowId} />
          <MessageInput flowId={flowId} disabled={mode === 'playing'} />
        </div>

        {/* Flow visualization (center, 40%) */}
        <div className="w-[40%] relative">
          <FlowDebugger flowId={flowId} />
        </div>

        {/* Variable inspector (right, 25%) */}
        <VariableInspector flowId={flowId} />
      </div>

      {/* Bottom status bar */}
      <TestStatusBar flowId={flowId} />
    </div>
  );
}
```

## State of the Art

| Old Approach                            | Current Approach                                              | When Changed | Impact                                                         |
| --------------------------------------- | ------------------------------------------------------------- | ------------ | -------------------------------------------------------------- |
| Console.log debugging                   | Visual flow path highlighting + real-time variable inspection | 2024-2025    | 10x faster debugging; non-technical admins can identify issues |
| Manual refresh to see execution updates | Convex WebSocket subscriptions                                | 2023-2024    | Instant (<100ms) updates; no polling complexity                |
| Mock AI responses for testing           | Real AI calls with trace logging                              | 2025         | Tests validate actual AI behavior; catch prompt/context issues |
| Table-based execution history           | Split-pane with timeline + JSON inspector                     | 2025         | Faster navigation; inline diff viewing                         |
| Jest unit tests for flows               | Mastra Studio + live testing playground                       | 2025         | Visual step-through; human-in-the-loop validation              |

**Deprecated/outdated:**

- Redux for testing state: Replaced by Zustand + Convex (lighter, simpler)
- Custom WebSocket management: Replaced by Convex's built-in subscriptions
- Static error logging: Replaced by structured execution steps with variable snapshots

## Open Questions

1. **Execution history retention policy**
   - What we know: Convex has soft limits on table size; execution logs can grow large
   - What's unclear: How long to retain test executions vs production runs
   - Recommendation: Start with 30-day retention for test runs, archive to cold storage; add setting for clinic admin to configure

2. **Error severity classification**
   - What we know: Mastra returns `status: 'failed'` with error object
   - What's unclear: Should we categorize errors (AI failure, logic error, validation error, timeout) for filtering?
   - Recommendation: Add `errorCategory` field to execution logs based on error type; allow filtering in history view

3. **Multi-user testing scenarios**
   - What we know: Testing interface is for single admin currently
   - What's unclear: Will multiple admins test same flow simultaneously? Need conflict resolution?
   - Recommendation: Create isolated test sessions per admin; show "admin X is testing" indicator; prevent concurrent edits to same flow

## Sources

### Primary (HIGH confidence)

- Convex React documentation (https://docs.convex.dev/client/react) - useQuery, useMutation, subscriptions
- React Flow DevTools guide (https://reactflow.dev/learn/advanced-use/devtools-and-debugging) - NodeInspector, ChangeLogger, ViewportLogger patterns
- Mastra Workflows documentation (https://mastra.ai/docs/workflows/overview) - .stream(), .start(), workflow state management

### Secondary (MEDIUM confidence)

- 2025 Convex testing patterns (WebSearch) - Isolated stacks, property-based testing, reactive loop debugging
- 2025 React Flow debugging patterns (WebSearch) - Execution path highlighting, ghost node snapshots, AgentPrism
- 2025 Mastra execution patterns (WebSearch) - Workflow memory vs agent memory, tracing, Studio UI
- 2025 TanStack Query patterns (WebSearch) - Subscription manager, reactive invalidation, streamed queries
- 2025 Execution history UI patterns (WebSearch) - Split-pane inspector, hierarchical tree tables, branching timeline

### Tertiary (LOW confidence)

- 2025 Chat UI patterns (WebSearch) - Message grouping, virtualization, testing playgrounds
- 2025 Error logging patterns (WebSearch) - Severity levels, smart toasts, AI-assisted debugging

## Metadata

**Confidence breakdown:**

- Standard stack: HIGH - Based on official docs and established patterns
- Architecture: MEDIUM-HIGH - Some patterns inferred from multiple sources, not single authoritative doc
- Pitfalls: MEDIUM - Based on common React/Convex issues, not specifically tested for this exact use case

**Research date:** 2026-02-05
**Valid until:** 30 days (stable stack) / 7 days (fast-moving UI patterns)

**Research gaps:**

- Could not find Mastra-Convex direct integration docs; assumed standard action/mutation patterns apply
- React Flow DevTools package not fully documented; examples show patterns but not complete API
- No specific "variable inspector" component pattern found; designed based on general side panel patterns
