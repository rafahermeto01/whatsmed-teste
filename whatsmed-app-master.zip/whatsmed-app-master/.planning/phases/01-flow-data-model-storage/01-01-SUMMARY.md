---
phase: 01-flow-data-model-storage
plan: 01
subsystem: database
tags: convex, typescript, schema, multi-tenant, versioning

# Dependency graph
requires: []
provides:
  - Flows table with multi-tenant isolation and active version tracking
  - FlowVersions table with immutable version history
  - FlowExecutions table with sticky versioning for runtime tracking
  - TypeScript types exported for frontend consumption
affects: ["01-02", "01-03", "01-04", "01-05", "01-06", "01-07", "02-flow-builder-ui", "03-flow-execution-engine"]

# Tech tracking
tech-stack:
  added: []
  patterns:
    - Multi-tenant data isolation pattern with clinicId field on all tables
    - Immutable versioning pattern (no updatedAt on flowVersions)
    - Sticky versioning pattern (flowVersionId pins executions to starting version)
    - Sequential version numbering (1, 2, 3...)
    - React Flow compatible node/connection structure

key-files:
  created:
    - "packages/backend/convex/flows.ts" - Flow module with type exports and documentation
  modified:
    - "packages/backend/convex/schema.ts" - Added flows, flowVersions, and flowExecutions tables

key-decisions:
  - "Nodes and connections stored inline in flowVersions document (simpler reads, single document retrieval)"
  - "Variable definitions at flow-level (not per-node) - easier to manage and reference"
  - "Sequential version numbering (integers) rather than semantic versioning - simpler for flows"
  - "No updatedAt on flowVersions - immutable design enforces complete audit trail"
  - "flowVersionId on flowExecutions - sticky versioning prevents breaking changes during active sessions"

patterns-established:
  - Pattern 1: Multi-tenant isolation enforcement via clinicId field on all tables
  - Pattern 2: Immutable version storage with no mutation path once created
  - Pattern 3: Reference-based foreign keys (v.id("tableName")) for Convex relationships
  - Pattern 4: Composite indexes for common query patterns (clinic + status, clinic + createdAt)

# Metrics
duration: ~3 minutes
completed: 2026-02-04
---

# Phase 1 Plan 1: Define Convex Data Model for Flows, Versions, and Executions

**Multi-tenant flow storage with immutable versioning and sticky execution pinning**

## Performance

- **Duration:** ~3 minutes (2026-02-04T21:37:08Z to 2026-02-04T21:40:30Z)
- **Started:** 2026-02-04T21:37:08Z
- **Completed:** 2026-02-04T21:40:30Z
- **Tasks:** 4 completed
- **Files modified:** 2 files created/modified

## Accomplishments

- **Three new Convex tables** for flow data model (flows, flowVersions, flowExecutions)
- **Multi-tenant isolation** enforced via clinicId field on all tables
- **Immutable versioning** design (no updatedAt on flowVersions) ensuring complete audit trail
- **Sticky versioning** for flow executions (flowVersionId pins executions to starting version)
- **React Flow compatible** node and connection structure for seamless UI integration
- **Flow-level variable definitions** with type safety (string, number, boolean)
- **Comprehensive indexes** for efficient querying across all tables
- **TypeScript types exported** from flows.ts for frontend consumption

## Task Commits

Each task was committed atomically:

1. **Task 1: Add flows table to schema** - `6ecd678` (feat)
2. **Task 2: Add flowVersions table to schema** - `e05919f` (feat)
3. **Task 3: Add flowExecutions table to schema** - `36a3d2c` (feat)
4. **Task 4: Create flows module file** - `38fac47` (feat)

**Plan metadata:** TBD (docs: complete plan)

## Files Created/Modified

- `packages/backend/convex/schema.ts` - Added flows, flowVersions, and flowExecutions tables
  - flows table: Flow metadata with activeVersionId reference
  - flowVersions table: Immutable versions with nodes, connections, variables
  - flowExecutions table: Runtime execution tracking with flowVersionId pinning
- `packages/backend/convex/flows.ts` - New file with exported TypeScript types and documentation
  - Flow, FlowVersion, FlowExecution type definitions
  - JSDoc comments explaining module purpose and architecture
  - Placeholder TODOs for future Convex function implementations

## Decisions Made

- **Nodes stored inline in flowVersions document** - Simpler reads, single document retrieval rather than separate collection
- **Flow-level variable definitions** (not per-node) - Easier to manage and reference across nodes
- **Sequential version numbering** (1, 2, 3...) - Simpler than semantic versioning for flows, clear ordering
- **Immutable versioning** (no updatedAt on flowVersions) - Enforces complete audit trail, prevents accidental mutations
- **Sticky versioning** (flowVersionId on flowExecutions) - Prevents breaking changes from affecting active patient conversations

## Deviations from Plan

None - plan executed exactly as written.

## Issues Encountered

None - all tasks completed successfully without errors.

## User Setup Required

None - no external service configuration required.

## Next Phase Readiness

**Ready for Plan 01-02:** Flow CRUD operations can be implemented using the defined data model.

**Ready for Plan 01-03:** Version management can be implemented using the flowVersions table and immutable design.

**Ready for Plan 01-04:** Access control rules can leverage clinicId and role fields for defense-in-depth.

**Ready for Plan 01-05:** Audit logging can track operations on flows, flowVersions, and flowExecutions tables.

**Ready for Plan 01-06:** Variable sanitization can process flow-level variable definitions before execution.

**Ready for Plan 01-07:** HTTP API endpoints can be built on top of the Convex functions.

**No blockers or concerns** - Data model foundation is solid and supports all subsequent plans.

---

_Phase: 01-flow-data-model-storage_
_Completed: 2026-02-04_
