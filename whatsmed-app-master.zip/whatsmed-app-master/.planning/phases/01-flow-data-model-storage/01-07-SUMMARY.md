---
phase: 01-flow-data-model-storage
plan: 07
subsystem: api
tags: [rest-api, tanstack-start, convex, typescript, authentication, authorization]

# Dependency graph
requires:
  - phase: 01-flow-data-model-storage (01-06)
    provides: Variable sanitization functions for preventing injection attacks
  - phase: 01-flow-data-model-storage (01-03)
    provides: Flow version management functions (createFlowVersion, listFlowVersions, activateVersion)
  - phase: 01-flow-data-model-storage (01-02)
    provides: Flow CRUD operations with multi-tenant isolation
provides:
  - TanStack Start API routes for flow management (flows CRUD, versions)
  - Convex HTTP API endpoints for flow operations with authentication and authorization
  - TypeScript types for API requests and responses
affects: [02-flow-builder-ui, 03-flow-execution-engine]

# Tech tracking
tech-stack:
  added: []
  patterns:
    - Proxy pattern: TanStack Start routes forward to Convex HTTP API with auth tokens
    - Dual authentication: HTTP layer + Convex function layer (defense-in-depth)
    - File-based routing: TanStack Start with dynamic parameters ($id, $versionId)

key-files:
  created:
    - apps/web/src/routes/api/flows/flows.ts - GET/POST endpoints for flows
    - apps/web/src/routes/api/flows/$id.ts - GET/PATCH/DELETE endpoints for flow details
    - apps/web/src/routes/api/flows/$id/versions.ts - GET/POST endpoints for flow versions
    - apps/web/src/routes/api/flows/$id/versions/$versionId/activate.ts - POST endpoint for version activation
    - apps/web/src/routes/api/flows/types.ts - TypeScript types for API requests/responses
  modified:
    - packages/backend/convex/http.ts - Added 8 HTTP API endpoints for flow management

key-decisions:
  - "Used TanStack Start file-based routing instead of app/ directory structure specified in plan (follows existing codebase pattern)"
  - "Used proxy pattern for API routes forwarding to Convex HTTP API (matches existing pattern)"
  - "Kept dual authentication (HTTP layer + Convex functions) for defense-in-depth"

patterns-established:
  - "Pattern 1: TanStack Start routes proxy to Convex HTTP API with auth token from better-auth cookies"
  - "Pattern 2: Convex HTTP routes authenticate and authorize before calling Convex functions"
  - "Pattern 3: Dual-layer authentication provides defense-in-depth (HTTP layer validates first, functions validate again)"
  - "Pattern 4: Dynamic parameters use $id syntax (TanStack Start convention)"

# Metrics
duration: 35min
completed: 2026-02-04
---

# Phase 1 Plan 7: Flow API Endpoints Summary

**RESTful API endpoints for flow management with TanStack Start routing and Convex backend integration**

## Performance

- **Duration:** 35 min
- **Started:** 2026-02-04T22:06:00Z
- **Completed:** 2026-02-04T22:41:32Z
- **Tasks:** 6
- **Files modified:** 6 (5 new TanStack Start routes, 1 modified Convex HTTP file)

## Accomplishments

- Created complete RESTful API for flow CRUD operations with TanStack Start file-based routing
- Implemented proxy pattern forwarding requests to Convex HTTP API with auth tokens
- Added Convex HTTP API endpoints for flow operations with authentication and authorization
- Created TypeScript types for type-safe API requests and responses
- Established dual-layer authentication (HTTP + Convex) for defense-in-depth security
- Maintained consistency with existing codebase patterns (patients API structure)

## Task Commits

Each task was committed atomically:

1. **Task 1: Review existing API route patterns** - No commit (research task)
2. **Task 2: Create flows list and create endpoints** - `b764146` (feat)
3. **Task 3: Create flow detail endpoints** - `b764146` (feat)
4. **Task 4: Create flow version endpoints** - `b764146` (feat)
5. **Task 5: Create version activation endpoint** - `b764146` (feat)
6. **Task 6: Create TypeScript types for API responses** - `b764146` (feat)

**Plan metadata:** `3de27e6` (docs: complete plan)

_Note: Tasks 2-6 were committed together as a single atomic commit since they represent a cohesive API layer implementation._

## Files Created/Modified

- `apps/web/src/routes/api/flows/flows.ts` - GET/POST endpoints for flows (list, create)
- `apps/web/src/routes/api/flows/$id.ts` - GET/PATCH/DELETE endpoints for flow details
- `apps/web/src/routes/api/flows/$id/versions.ts` - GET/POST endpoints for flow versions
- `apps/web/src/routes/api/flows/$id/versions/$versionId/activate.ts` - POST endpoint to activate version
- `apps/web/src/routes/api/flows/types.ts` - TypeScript types for API requests and responses
- `packages/backend/convex/http.ts` - Added 8 Convex HTTP API endpoints for flow operations

## Decisions Made

1. **TanStack Start routing structure**: Used `src/routes/api/` with `$id` for dynamic parameters instead of `app/api/` with `[id]` as specified in plan. This aligns with existing codebase pattern.

2. **Proxy pattern for API routes**: TanStack Start routes forward requests to Convex HTTP API rather than calling Convex functions directly. This matches the existing pattern used for patients, users, and other APIs.

3. **Dual-layer authentication**: Kept authentication in both HTTP layer and Convex function layer for defense-in-depth. This is consistent with existing codebase patterns where both layers validate.

## Deviations from Plan

### Rule 3 - Blocking: Fixed incorrect directory structure in plan

- **Found during:** Task 2-5 (Creating API routes)
- **Issue:** Plan specified `apps/web/app/api/flows/` but the codebase uses `apps/web/src/routes/api/` with TanStack Start file-based routing
- **Fix:** Created routes in `apps/web/src/routes/api/flows/` with correct TanStack Start patterns:
  - `flows.ts` for `/api/flows`
  - `$id.ts` for `/api/flows/$id`
  - `$id/versions.ts` for `/api/flows/$id/versions`
  - `$id/versions/$versionId/activate.ts` for `/api/flows/$id/versions/$versionId/activate`
- **Files modified:** All route files created in correct directory structure
- **Verification:** Files created in correct location matching existing API patterns
- **Committed in:** b764146 (Task 2-6 commit)

### Rule 3 - Blocking: Added Convex HTTP API endpoints not explicitly in plan

- **Found during:** Task completion (Verification phase)
- **Issue:** TanStack Start routes need Convex HTTP API endpoints to proxy to, but plan only specified creating TanStack Start routes
- **Fix:** Added 8 Convex HTTP API endpoints in `packages/backend/convex/http.ts`:
  - GET /api/flows - list flows with status filter
  - POST /api/flows - create flow
  - GET /api/flows/:flowId - get flow
  - PATCH /api/flows/:flowId - update flow
  - DELETE /api/flows/:flowId - delete flow
  - GET /api/flows/:flowId/versions - list versions
  - POST /api/flows/:flowId/versions - create version
  - POST /api/flows/:flowId/versions/:versionId/activate - activate version
- **Files modified:** packages/backend/convex/http.ts
- **Verification:** All endpoints added with authentication, authorization, and proper error handling
- **Committed in:** 3de27e6 (Convex HTTP endpoints commit)

---

**Total deviations:** 2 auto-fixed (2 blocking)
**Impact on plan:** Both deviations were necessary to make the API functional. The directory structure change was required to match existing codebase patterns, and adding Convex HTTP endpoints was required for the proxy pattern to work.

## Issues Encountered

None - All implementation tasks completed successfully following existing codebase patterns.

## User Setup Required

None - no external service configuration required. The API endpoints integrate with existing Convex backend and better-auth authentication.

## Next Phase Readiness

- **Convex HTTP API endpoints are ready:** All flow CRUD and version operations can be called via HTTP API
- **TanStack Start routes are ready:** Frontend can call RESTful endpoints via standard HTTP requests
- **TypeScript types are available:** Frontend can use type-safe API requests
- **Authentication is configured:** better-auth cookies flow through TanStack Start routes to Convex
- **Ready for Phase 2:** Flow Builder UI can now consume these API endpoints to manage flows

**No blockers or concerns.** The implementation follows existing patterns and is ready for frontend integration.

---

_Phase: 01-flow-data-model-storage_
_Completed: 2026-02-04_
