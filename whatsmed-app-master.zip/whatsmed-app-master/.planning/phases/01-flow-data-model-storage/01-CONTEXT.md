# Phase 1: Flow Data Model & Storage - Context

**Gathered:** 2026-02-04
**Status:** Ready for planning

<domain>
## Phase Boundary

System securely stores and manages flow definitions with multi-tenant isolation and version tracking. This phase builds the backend foundation — data model, storage layer, access control, audit logging. The visual builder UI comes in Phase 2.

</domain>

<decisions>
## Implementation Decisions

### Flow schema structure

- Nodes stored inline in flow document (simpler reads, single document)
- Flow metadata: Essential fields only (name, description, status, createdAt, updatedAt, createdBy)
- Connections representation: Claude's discretion (optimal for React Flow compatibility)

### Versioning granularity

- New version created on every save (complete history)
- Nothing mutable — once saved, version is read-only; edits create new version
- Version numbering: Sequential integers (1, 2, 3)
- Active version tracked via `activeVersionId` field on flow object

### Access control enforcement

- Multi-tenant isolation enforced at both API layer (adds clinicId filter) and database layer (Convex rules)
- Role-based permissions checked at both API layer (middleware) and database layer (Convex rules)
- Unauthorized access: Silent deny (403 response, no logging)
- Flow activation/deactivation: Admins + staff (both roles can change status)

### Audit log detail level

- Logged operations: All CRUD operations (create, read, update, delete)
- Log entry data: Essential only (timestamp, userId, clinicId, operation, flowId)
- Retention period: 1 year
- Queryable by: Clinic + operation + date range (multiple filters)

### Claude's Discretion

- Variable definition approach (flow-level vs per-node vs hybrid)
- Node connection representation format (optimal for React Flow compatibility)

</decisions>

<specifics>
## Specific Ideas

- Defense in depth for security (both API and DB layers for isolation and RBAC)
- Complete audit trail with all operations logged for healthcare compliance
- 1-year retention for audit logs balances compliance with storage costs

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope.

</deferred>

---

_Phase: 01-flow-data-model-storage_
_Context gathered: 2026-02-04_
