# Phase 4 AI Integration - Verification Guide

**Plan:** 04-04 Integration Verification  
**Date:** 2026-02-05  
**Status:** Ready for Testing

---

## Overview

This document provides test scenarios to verify that all Phase 4 AI Integration components work together correctly. The integration connects:

1. **Flow Context Injection** (04-01) - AI receives flow instructions via system prompts
2. **Default Flow Selector UI** (04-02) - Admin can set default flow via dropdown
3. **Tool Integration** (04-03) - Tools work seamlessly within flow context

---

## Prerequisites

Before running tests, ensure:

1. **Admin Access** - You have admin role for a test clinic
2. **WhatsApp** - WhatsApp Business API is configured and connected
3. **Test Clinic** - A clinic with at least one doctor and procedure configured
4. **Browser Console** - Open to monitor logs
5. **Convex Dashboard** - Access to view server logs

---

## Test Scenarios

### Test 1: Default Flow UI (AIINT-05)

**Purpose:** Verify admin can set/change default flow via UI

**Steps:**

1. Navigate to `/flows` page as admin user
2. Create a new flow with 2-3 nodes:
   - Node 1: Message "Bem-vindo à nossa clínica! Como posso ajudá-lo hoje?"
   - Node 2: Input "Você gostaria de agendar uma consulta?"
   - Node 3: Message "Entendi! Vou verificar a disponibilidade para você."
3. Save the flow
4. Click "Ativar" to activate the flow
5. In the dropdown menu, select "Definir como Padrão"
6. Observe the UI updates

**Expected Results:**

- ✅ Star icon (yellow) appears next to flow name in the table
- ✅ "Padrão" badge appears next to flow name
- ✅ Default flow indicator at top shows the flow name
- ✅ Toast notification confirms "Fluxo padrão atualizado"

**Verification Method:** Visual confirmation of UI elements

---

### Test 2: Flow Context Injection (AIINT-01 Extension)

**Purpose:** Verify AI receives flow instructions when default flow is set

**Steps:**

1. With default flow set (from Test 1), open browser console
2. Send WhatsApp message "Oi" to the clinic
3. Watch console logs for flow-related messages
4. Check Convex dashboard logs (optional)

**Expected Log Entries:**

```
[Flow] Checking for active flow for clinic: <clinicId>
[Flow] Active flow found: <flow-name> (v<version>)
[Flow] Instructions length: <N> characters
[Flow] Instructions preview: FLOW GUIDANCE: Follow this conversation...
[Agent] Creating agent for clinic: <clinicId>
[Agent] Flow instructions included: yes
[Agent] System prompt length: <N> characters
[Agent] Generating response with flow guidance
```

**Expected Results:**

- ✅ Logs show active flow was found
- ✅ Instructions length is > 0
- ✅ Instructions preview shows flow guidance content
- ✅ Agent creation includes flow instructions

**Verification Method:** Check browser console and Convex logs

---

### Test 3: AI Follows Flow Guidance (AIINT-01, AIINT-06)

**Purpose:** Verify AI follows flow structure while maintaining natural conversation

**Steps:**

1. With appointment flow active (from Test 1), send "Oi" via WhatsApp
2. Observe AI response
3. Reply to the AI's question
4. Continue conversation naturally

**Expected Behavior:**

- AI responds with flow's welcome message (not generic greeting)
- AI asks about appointment per flow structure
- AI maintains natural, empathetic tone
- AI can deviate to answer questions outside flow

**Example Flow:**

```
Patient: "Oi"
AI: "Bem-vindo à nossa clínica! Como posso ajudá-lo hoje?" (Flow Node 1)
Patient: "Gostaria de marcar consulta"
AI: "Você gostaria de agendar uma consulta?" (Flow Node 2 - acknowledges)
AI: "Entendi! Vou verificar a disponibilidade para você." (Flow Node 3)
AI: "Tem preferência por algum médico?"
```

**Expected Results:**

- ✅ AI uses flow's welcome message as starting point
- ✅ AI follows flow structure naturally
- ✅ AI maintains conversational flow without being robotic
- ✅ AI can handle patient questions that deviate from flow

**Verification Method:** Conversation transcript analysis

---

### Test 4: Tool Execution in Flow Context (AIINT-04)

**Purpose:** Verify tools execute naturally within flow context

**Steps:**

1. Continue conversation from Test 3
2. Ask about doctor availability: "Tem horário com Dr. [Name]?"
3. Observe AI response and check logs

**Expected Log Entries:**

```
[Tool] Executing: checkDoctorAvailability
[Tool] Result: success
[Tool] Duration: 450ms
[checkDoctorAvailabilityTool] Found doctor: { name, id, totalMatches }
[checkDoctorAvailabilityTool] Received slots: [...]
```

**Expected Behavior:**

- AI uses tool without explicitly saying "vou verificar" or "deixe-me checar"
- AI presents availability naturally: "Encontrei horários disponíveis com Dr. [Name]..."
- Tool execution is hidden from patient view
- AI seamlessly continues flow after tool result

**Example Response:**

```
Patient: "Tem horário com Dr. Josefino?"
AI: "Encontrei horários disponíveis com Dr. Josefino! 🩺

Próximos dias disponíveis:
• Segunda-feira, 10/02 - 09:00, 14:00, 16:00
• Terça-feira, 11/02 - 10:00, 15:00

Qual dia e horário prefere?"
```

**Expected Results:**

- ✅ Logs show tool execution
- ✅ AI response includes actual availability data
- ✅ Response feels natural (not mechanical)
- ✅ No explicit "I will check" type messages

**Verification Method:** Check logs for [Tool] entries and verify response quality

---

### Test 5: Flow Deactivation (AIINT-05)

**Purpose:** Verify removing default flow returns to normal chat

**Steps:**

1. Go to `/flows` page
2. In the Default Flow Selector dropdown, select "Nenhum" (or clear selection)
3. Send new WhatsApp message "Oi" to clinic
4. Check logs

**Expected Log Entries:**

```
[Flow] Checking for active flow for clinic: <clinicId>
[Flow] No active flow, using normal chat
[Agent] Creating agent for clinic: <clinicId>
[Agent] Flow instructions included: no
```

**Expected Behavior:**

- AI responds with normal greeting (not flow-based)
- AI uses standard conversational approach
- No flow guidance appears in system prompt

**Example Response:**

```
Patient: "Oi"
AI: "Olá! Como posso ajudá-lo hoje? 😊"
(Normal greeting, not flow-specific welcome message)
```

**Expected Results:**

- ✅ Logs confirm no active flow
- ✅ AI responds with generic greeting
- ✅ Flow selector shows "Nenhum" or empty state
- ✅ No flow-related logs after deactivation

**Verification Method:** Log analysis and conversation review

---

### Test 6: Role-Based Access (SEC-02, SEC-03)

**Purpose:** Verify non-admin users cannot change default flow

**Steps:**

1. Logout from admin account
2. Login as staff user (non-admin role)
3. Navigate to `/flows` page
4. Attempt to use Default Flow Selector
5. Observe UI state

**Expected UI State:**

- Default Flow Selector is disabled (grayed out)
- Lock icon appears next to selector
- Hovering shows tooltip: "Apenas administradores podem definir o fluxo padrão"
- Dropdown in flow list shows "Definir como Padrão" option disabled

**Expected Log Entries (if attempted via API):**

```
Error: "Apenas administradores podem definir o fluxo padrão"
```

**Expected Results:**

- ✅ Selector appears disabled for non-admin users
- ✅ Tooltip explains restriction
- ✅ Lock icon visible
- ✅ Server-side validation prevents unauthorized changes

**Verification Method:** Visual UI inspection and role testing

---

## Log Format Reference

During verification, look for these log prefixes:

| Prefix         | Meaning                               |
| -------------- | ------------------------------------- |
| `[Flow]`       | Flow loading and context injection    |
| `[Agent]`      | Agent creation and configuration      |
| `[Tool]`       | Tool execution                        |
| `[Escalation]` | Help request detection and escalation |

---

## Success Criteria

Phase 4 integration is successful when all tests pass:

- ✅ **AIINT-05:** Admin can set/change default flow via UI
- ✅ **AIINT-01 Ext:** AI receives flow instructions when default flow active
- ✅ **AIINT-06:** AI follows flow guidance in conversations
- ✅ **AIINT-04:** Tools execute naturally within flow context
- ✅ **SEC-02/03:** Role-based access control enforced

---

## Troubleshooting

### Issue: No flow logs appearing

**Solution:**

- Verify default flow is set in UI
- Check that flow is activated (status = "active")
- Confirm clinicId is correct in logs
- Check Convex dashboard for server-side logs

### Issue: AI not following flow structure

**Solution:**

- Verify flow instructions are being generated (check [Flow] logs)
- Ensure flow has valid nodes and connections
- Check that instructions are being passed to agent creation
- Verify agent is being created fresh (not cached without flow)

### Issue: Tools not executing in flow

**Solution:**

- Verify tools are enabled in AI settings
- Check tool execution logs for errors
- Ensure patient query matches tool triggers
- Verify doctor/procedure data exists in database

### Issue: Default flow selector not working

**Solution:**

- Check user role (must be admin)
- Verify flow status is "active"
- Check browser console for JavaScript errors
- Verify Convex mutation is being called

---

## Post-Verification

After all tests pass:

1. **Document Results** - Note any issues or observations
2. **Update STATE.md** - Mark Phase 4 as complete
3. **Proceed to Phase 5** - Testing & Debugging phase

---

_Generated: 2026-02-05_  
_Plan: 04-04 Integration Verification_
