---
phase: 04-ai-integration
plan: 01
subsystem: ai
tags: [mastra, convex, flows, context-injection, ai-prompts]

# Dependency graph
requires:
  - phase: 03-flow-execution-engine
    provides: Flow loading infrastructure and getActiveFlowByClinic query
provides:
  - Flow-to-LLM formatting utilities (formatFlowForLLM, formatNodeInstructions)
  - Enhanced agent creation with flow context injection
  - WhatsApp handler integration for active flow loading
  - Convex query for formatted flow instructions (getFormattedFlowForAI)
affects:
  - Phase 4 Plan 2 (Default Flow UI)
  - Phase 4 Plan 3 (Tool Integration)
  - WhatsApp AI message processing

# Tech tracking
tech-stack:
  added: []
  patterns:
    - "Flow guidance injection into Mastra agent system prompts"
    - "Graceful degradation when flow system unavailable"
    - "Cache key versioning for flow-aware agents"
    - "Dynamic imports for circular dependency avoidance"

key-files:
  created:
    - packages/backend/convex/flows/formatters.ts
  modified:
    - packages/backend/mastra/agents.ts
    - packages/backend/mastra/index.ts
    - packages/backend/convex/automationAi.ts
    - packages/backend/convex/flows.ts

key-decisions:
  - "Flow instructions positioned after basePrompt but before contextBlock in system prompt"
  - "Agent cache bypassed when flowInstructions provided (dynamic per-request)"
  - "Graceful error handling - WhatsApp processing continues if flow loading fails"
  - "getFormattedFlowForAI query provides clean one-call API for flow instructions"

patterns-established:
  - "Flow guidance as system prompt section with autonomy note"
  - "Pre-formatted flow instructions passed through agent parameter chain"
  - "Cache versioning includes flow state to prevent cross-contamination"

# Metrics
duration: 25 min
completed: 2026-02-05
---

# Phase 4 Plan 1: Flow Context Injection Summary

**Flow formatting utilities and AI agent context injection enabling clinic-defined conversation guidance with natural language formatting**

## Performance

- **Duration:** 25 min
- **Started:** 2026-02-05
- **Completed:** 2026-02-05
- **Tasks:** 4
- **Files modified:** 5

## Accomplishments

1. **Created comprehensive flow formatting utilities** (`formatters.ts`)
   - `formatFlowForLLM()` - Converts flow structure to natural language instructions
   - `formatNodeInstructions()` - Node-type-specific formatting (Message, Input, Condition, Wait)
   - `createFlowInstructions()` - Combines all elements into complete guidance document
   - `formatFlowForSystemPrompt()` - Condensed version for direct system prompt injection
   - Full TypeScript typing with FlowVersionData, FlowNode, FlowEdge interfaces

2. **Enhanced Mastra agent creation** (`agents.ts` + `index.ts`)
   - Added `flowInstructions` parameter to `createClinicAgent()` function signature
   - Modified system prompt construction to inject flow guidance in correct position
   - Flow guidance positioned after basePrompt, before patient context block
   - Added clear "FLOW GUIDANCE:" section marker with autonomy note
   - Updated `getClinicAgent()` to accept and pass flowInstructions to createClinicAgent
   - Cache key includes flow state (v9-{flow|noflow}) to prevent cross-contamination
   - Cache bypassed when flowInstructions provided (dynamic per-request agents)

3. **Integrated flow loading in WhatsApp handler** (`automationAi.ts`)
   - Modified `processIncomingAiMessage()` to load active flow using `getActiveFlowByClinic`
   - Load flow version data when active flow found
   - Format instructions using `formatFlowForLLM()`
   - Pass formatted instructions to `generateAiResponse()` via new `flowInstructions` parameter
   - Added required logging: "[AI] Active flow: {flowName} | Instructions length: {N} chars"
   - Graceful error handling - continues without flow if loading fails
   - `generateAiResponse()` accepts `flowInstructions` and passes to `getClinicAgent()`

4. **Added Convex query for formatted flow** (`flows.ts`)
   - Implemented `getFormattedFlowForAI` query for one-call flow instruction retrieval
   - Returns `{ flowId, flowName, instructions }` or null if no active flow
   - Re-exports formatter functions for convenient access
   - Uses dynamic imports to avoid circular dependencies

## Task Commits

1. **Task 1: Flow formatting utilities** - `55a7cd3`
   - Created `packages/backend/convex/flows/formatters.ts` with 339 lines

2. **Task 2: Agent creation enhancement** - `7b03771`
   - Modified `packages/backend/mastra/agents.ts` (+13 lines)

3. **Task 3: WhatsApp handler integration** - `30cad54`
   - Modified `packages/backend/convex/automationAi.ts` and `packages/backend/mastra/index.ts` (+65/-14 lines)

4. **Task 4: Flow formatting query** - `28a4fe5`
   - Modified `packages/backend/convex/flows.ts` (+57 lines)

**Plan metadata:** `28a4fe5` (docs: complete plan)

## Files Created/Modified

- `packages/backend/convex/flows/formatters.ts` (NEW) - Flow-to-LLM formatting functions
  - formatFlowForLLM: Main conversion function
  - formatNodeInstructions: Node-specific formatting
  - createFlowInstructions: Complete guidance document builder
  - formatFlowForSystemPrompt: Condensed version for system prompt

- `packages/backend/mastra/agents.ts` - Enhanced agent creation
  - Added flowInstructions parameter
  - Modified instructions construction with FLOW GUIDANCE section

- `packages/backend/mastra/index.ts` - Agent caching updates
  - Updated getClinicAgent signature
  - Cache key includes flow state
  - Passes flowInstructions to createClinicAgent

- `packages/backend/convex/automationAi.ts` - WhatsApp integration
  - Added formatFlowForLLM import
  - Modified processIncomingAiMessage to load and format flows
  - Added flowInstructions to generateAiResponse args
  - Passes flowInstructions through to agent creation

- `packages/backend/convex/flows.ts` - Query addition
  - Added getFormattedFlowForAI query
  - Re-exports formatter functions

## Decisions Made

1. **Prompt Positioning:** Flow guidance positioned after basePrompt but before patient context block
   - Rationale: Flow provides conversation structure, patient context provides personalization data

2. **Cache Strategy:** Dynamic agents (with flowInstructions) bypass cache
   - Rationale: Flow instructions are per-request dynamic, caching would cause stale guidance

3. **Graceful Degradation:** WhatsApp processing continues if flow loading fails
   - Rationale: Core AI functionality must not break if flow system has issues

4. **Two-Parameter Approach:** Both flowId (legacy) and flowInstructions (new) in generateAiResponse
   - Rationale: Maintains backward compatibility while enabling direct instruction passing

## Deviations from Plan

None - plan executed exactly as written.

## Issues Encountered

None. All TypeScript compilation errors encountered were pre-existing in:

- `analytics.ts` (implicit any types)
- Mastra node_modules type definitions (module resolution, private identifiers)

These did not affect the new code or its functionality.

## Next Phase Readiness

✅ **Ready for Plan 04-02 (Default Flow UI)**

- Flow formatting utilities available
- Agent context injection working
- WhatsApp handler integration complete

✅ **Foundation for Plan 04-03 (Tool Integration)**

- AI receives flow context and can follow guidance
- Flow context pauses when escalated (handled in Phase 3)

## Observable Success Criteria

All success criteria met:

- ✅ AI agent receives flow instructions when clinic has active default flow (AIINT-01 extended)
- ✅ Flow structure is formatted as natural language guidance (not technical JSON) (AIINT-02 compliance)
- ✅ Flow instructions are pinned early in system prompt (after basePrompt, before context)
- ✅ AI can naturally follow flow while remaining flexible per CONTEXT.md decisions
- ✅ Flow context integration works without breaking existing chat functionality (graceful degradation)

---

_Phase: 04-ai-integration_
_Completed: 2026-02-05_
