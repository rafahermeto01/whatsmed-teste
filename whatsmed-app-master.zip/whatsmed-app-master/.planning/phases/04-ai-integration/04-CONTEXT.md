# Phase 4: AI Integration - Context

**Gathered:** 2026-02-05
**Status:** Ready for planning

<domain>
## Phase Boundary

Flow execution integrates with WhatsApp AI system. AI agents receive flow structure as guidance documents in their context, call existing tools (appointment booking, patient lookup) naturally during conversation, and support clinic-wide default flow activation. Tools are dynamically discovered by AI, failures are handled gracefully, and flow context pauses during human escalation.

</domain>

<decisions>
## Implementation Decisions

### Tool Execution in Flow Context

- AI discovers available tools dynamically from Mastra agent at runtime (already defined in agents.ts)
- Tool calls are hidden from patients - they see natural AI responses, not technical tool executions
- When tools fail, AI handles gracefully with natural explanations (e.g., "That slot is unavailable, here are alternatives")
- No separate tool execution tracking or logging - flows are context injection only

### Multiple Flow Activation Strategies

- **Primary strategy:** Clinic-wide default flow always loaded for all patient conversations
- Single flow per clinic at a time (simplifies activation)
- AI sticks to one flow per conversation but can deviate when situation requires it
- Staff can manually change default flow via dropdown selector in flow settings
- **Transparency:** Clinic can optionally tell patient they're following a process (e.g., "I'm going to guide you through our intake process")

### Flow Execution Results Integration

- No tracking of which flow was used per conversation
- No analytics on flow effectiveness - trust AI autonomy
- No node-level tracking of which parts of flow were followed
- **Escalation handling:** Flow context pauses when escalated to human staff, resumes when handed back to AI
- Keep it simple: flows are guidance documents, not execution tracking systems

### Claude's Discretion

- Specific UI design for flow settings dropdown
- Exact Mastra agent integration patterns
- Error handling implementation details

</decisions>

<specifics>
## Specific Ideas

- "The flow will just be injected into context, no tracking or anything like that is required"
- "Stick to one flow but there are cases where the AI can deviate from it if the situation requires it"
- "AI handles gracefully" when tools fail
- Keep flows as simple guidance documents, not complex execution tracking systems

</specifics>

<deferred>
## Deferred Ideas

- Keyword-based flow activation (e.g., "agendar" triggers appointment flow)
- Time-based flow activation (e.g., morning reminder flows)
- Per-conversation flow assignment
- Analytics dashboard for flow effectiveness
- Node-level tracking of flow usage
- Automatic flow switching mid-conversation
- Advanced activation strategies beyond clinic default

None of these are needed for Phase 4 - the simple "clinic-wide default flow" approach covers the requirement.

</deferred>

---

_Phase: 04-ai-integration_
_Context gathered: 2026-02-05_
