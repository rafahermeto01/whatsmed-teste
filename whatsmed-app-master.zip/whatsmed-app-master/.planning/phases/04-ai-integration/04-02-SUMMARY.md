---
phase: 04-ai-integration
plan: 02
subsystem: ui
tags: [react, convex, hooks, components, role-based-access]

# Dependency graph
requires:
  - phase: 03-flow-execution-engine
    provides: Default flow infrastructure, getActiveFlowByClinic query
  - phase: 02-flow-builder-ui
    provides: Flow list page, UI components
provides:
  - Default flow selector UI component
  - React hooks for clinic settings
  - Role-based access control for admin-only operations
  - Visual indicators for default flow status
affects:
  - Phase 4 AI integration (uses default flow for AI context injection)
  - Future admin dashboard (clinic settings management)

# Tech tracking
tech-stack:
  added: []
  patterns:
    - "React hooks pattern with Convex useQuery/useMutation"
    - "Role-based UI disabling with tooltips"
    - "Optimistic UI updates with toast notifications"

key-files:
  created:
    - apps/web/src/hooks/clinicSettings.ts
    - apps/web/src/components/flows/DefaultFlowSelector.tsx
  modified:
    - apps/web/src/routes/flows/index.tsx
    - packages/backend/convex/clinicSettings.ts

key-decisions:
  - "Used type assertions for Convex API access during development (proper types after codegen)"
  - "Portuguese UI text for Brazilian clinic admin users"
  - "Star icon (yellow) for default flow visual indicator"
  - "Disabled selector with tooltip for non-admin users (not hidden)"

patterns-established:
  - "useDefaultFlow, useSetDefaultFlow, useClinicSettings hook pattern"
  - "Role-based component disabling with explanation tooltips"
  - "Backend validation as security source of truth, frontend for UX"

# Metrics
duration: 25 min
completed: 2026-02-05
---

# Phase 4 Plan 2: Default Flow Selector UI Summary

**Default flow selector UI with role-based access control, enabling clinic admins to visually manage which flow guides AI conversations while providing clear visual feedback and preventing unauthorized changes.**

## Performance

- **Duration:** 25 min
- **Started:** 2026-02-05T07:00:00Z
- **Completed:** 2026-02-05T07:25:00Z
- **Tasks:** 4
- **Files modified:** 4

## Accomplishments

- Created three React hooks (`useDefaultFlow`, `useSetDefaultFlow`, `useClinicSettings`) for managing clinic default flow settings with Convex integration
- Built reusable `DefaultFlowSelector` dropdown component with star icon, badge indicators, and Portuguese UI text
- Integrated default flow UI into flow list page with dedicated column, header selector, and row actions
- Implemented comprehensive role-based access control: disabled for non-admin users with lock icon and tooltip explanation
- Added validation: only active flows can be set as default, backend enforces admin role
- Enhanced error handling with Portuguese toast messages for network errors, permission errors, and validation failures
- Added audit log indicator and default flow status bar in flow list table header

## Task Commits

Each task was committed atomically:

1. **Task 1: Create React hooks for clinic settings** - `0fa91a5` (feat)
2. **Task 2: Create DefaultFlowSelector component** - `12e9496` (feat)
3. **Task 3: Integrate default flow UI into flow list** - `1f53c10` (feat)
4. **Task 4: Add validation and error handling** - Included in previous commits

**Plan metadata:** (to be committed with SUMMARY.md)

## Files Created/Modified

- `apps/web/src/hooks/clinicSettings.ts` - React hooks: useDefaultFlow, useSetDefaultFlow, useClinicSettings
- `apps/web/src/components/flows/DefaultFlowSelector.tsx` - Reusable dropdown component for selecting default flow
- `apps/web/src/routes/flows/index.tsx` - Enhanced flow list with default flow column, selector in header, row actions
- `packages/backend/convex/clinicSettings.ts` - Added getSettings query for frontend access

## Decisions Made

- **Portuguese UI text**: All user-facing text in Portuguese for Brazilian clinic admin users (e.g., "Fluxo Padrão", "Padrão", "Apenas administradores...")
- **Type assertions for Convex API**: Used `(api as any).clinicSettings` pattern during development - proper TypeScript types will be available after running `npx convex codegen`
- **Star icon with yellow badge**: Visual indicator for default flow provides immediate recognition
- **Disabled vs hidden**: Non-admin users see disabled selector with lock icon and tooltip rather than hidden UI - provides transparency about available features
- **Backend as security source of truth**: Frontend disables UI for UX but backend validates all mutations (defense in depth)

## Deviations from Plan

None - plan executed exactly as written.

## Issues Encountered

- **Convex type generation**: The clinicSettings API was added to backend but TypeScript types weren't immediately available in frontend. Used type assertions as workaround, proper types will be generated on next `npx convex codegen` run.
- **Pre-existing TypeScript errors**: Other files in the project had TypeScript errors unrelated to this plan. These didn't affect the functionality of the new code.

## Next Phase Readiness

- ✅ Default flow UI complete and ready for use
- ✅ Clinic admins can visually manage default flow without technical configuration
- ✅ Role-based access ensures only admins can change default flow
- ✅ Visual indicators make default flow status immediately apparent
- ✅ All success criteria met per plan specification
- 🔄 Ready for Phase 4 Plan 3: Tool integration
- 🔄 Backend validation ensures security even if frontend is bypassed

---

_Phase: 04-ai-integration_
_Completed: 2026-02-05_
