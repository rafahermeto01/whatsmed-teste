---
phase: 03-flow-execution-engine
plan: 03-A
type: execute
wave: 3
depends_on: ["03-02"]
files_modified:
  - packages/backend/convex/schema.ts
  - packages/backend/convex/whatsapp/timeout.ts
  - packages/backend/convex/cron.ts
autonomous: true
user_setup: []

must_haves:
  truths:
    - "System tracks chat activity with lastActivityAt timestamp"
    - "System sends nudge message at 75% of timeout threshold"
    - "System marks chat as abandoned after timeout period"
  artifacts:
    - path: "packages/backend/convex/schema.ts"
      provides: "Chats table with timeout tracking fields"
      contains: "lastActivityAt, timeoutSentAt, abandonedAt"
    - path: "packages/backend/convex/whatsapp/timeout.ts"
      provides: "Timeout monitoring and nudge sending functions"
      exports: ["checkConversationTimeouts", "sendNudgeMessage"]
    - path: "packages/backend/convex/cron.ts"
      provides: "Scheduled function for timeout checking"
      exports: ["timeoutCron"]
  key_links:
    - from: "packages/backend/convex/cron.ts"
      to: "packages/backend/convex/whatsapp/timeout.ts"
      via: "checkConversationTimeouts call"
      pattern: "internal\\.whatsapp\\.checkConversationTimeouts"
    - from: "packages/backend/convex/whatsapp/timeout.ts"
      to: "packages/backend/convex/whatsapp.ts"
      via: "sendNudgeMessage action"
      pattern: "internal\\.whatsapp\\.sendNudgeMessage"
    - from: "packages/backend/convex/whatsapp/timeout.ts"
      to: "packages/backend/convex/schema.ts"
      via: "chats table update"
      pattern: "ctx\\.db\\.patch.*status.*abandoned"
---

<objective>
Implement conversation timeout monitoring with proactive nudges.

Purpose: Detect inactive WhatsApp conversations, send proactive nudges before timeout, and mark abandoned chats for cleanup. This provides graceful handling of patient inactivity.

Output: Timeout monitoring system with scheduled checks and nudge messages.
</objective>

<execution_context>
@C:\Users\rafar\.config\opencode/get-shit-done/workflows/execute-plan.md
@C:\Users\rafar\.config\opencode/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/STATE.md
@.planning/ROADMAP.md
@.planning/phases/03-flow-execution-engine/03-CONTEXT.md
@.planning/phases/03-flow-execution-engine/03-RESEARCH.md
@.planning/phases/03-flow-execution-engine/03-02-PLAN.md
@C:\Users\rafar\Desktop Source\WhatsMed\app\whatsmed-app\packages\backend\convex\schema.ts
@C:\Users\rafar\Desktop Source\WhatsMed\app\whatsmed-app\packages\backend\convex\whatsapp.ts
@C:\Users\rafar\Desktop Source\WhatsMed\app\whatsmed-app\packages/backend/convex/whatsappQueries.ts
</context>

<tasks>

<task type="auto">
  <name>Task 1: Add timeout tracking fields to chats table</name>
  <files>packages/backend/convex/schema.ts</files>
  <action>
    Modify chats table definition in schema.ts to add timeout tracking fields:

    1. Add lastActivityAt: v.optional(v.number()) - tracks last activity timestamp
    2. Add timeoutSentAt: v.optional(v.number()) - tracks when nudge was sent
    3. Add abandonedAt: v.optional(v.number()) - tracks when chat was abandoned
    4. Extend status union to include "abandoned": v.union(v.literal("open"), v.literal("resolved"), v.literal("locked"), v.literal("abandoned"))

    5. Add index "by_clinic_lastActivity" for efficient timeout queries:
       .index("by_clinic_lastActivity", ["clinicId", "lastActivityAt"])

    These fields enable tracking conversation inactivity and graceful timeout handling

  </action>
  <verify>
    Run Convex dev to ensure schema migration succeeds: npx convex dev
  </verify>
  <done>
    Chats table has timeout tracking fields and index
  </done>
</task>

<task type="auto">
  <name>Task 2: Create timeout monitoring function</name>
  <files>packages/backend/convex/whatsapp/timeout.ts</files>
  <action>
    Create timeout.ts with checkConversationTimeouts internalMutation:

    checkConversationTimeouts:
    1. Takes no args (called by cron)
    2. Defines constants:
       - TIMEOUT_MS = 24 * 60 * 60 * 1000 (24 hours)
       - NUDGE_MS = 18 * 60 * 60 * 1000 (18 hours, 75% of timeout)
    3. Gets current timestamp: const now = Date.now()
    4. Queries chats with "by_clinic_lastActivity" index where:
       - lastActivityAt < now - NUDGE_MS
       - status === "open"
    5. For each inactive chat:
       a. If now - lastActivityAt >= TIMEOUT_MS:
          - Mark as abandoned: status = "abandoned", abandonedAt = now
          - Log: "[Timeout] Chat marked as abandoned"
       b. Else if !timeoutSentAt and now - lastActivityAt >= NUDGE_MS:
          - Send nudge: call internal.whatsapp.sendNudgeMessage
          - Mark nudge sent: timeoutSentAt = now
          - Log: "[Timeout] Nudge sent"

    sendNudgeMessage:
    1. Takes chatId and message args
    2. Stores nudge message in messages table (direction: "out")
    3. Calls internal.whatsapp.sendTextAction to send via WhatsApp
    4. Returns messageId

    Default nudge message: "Ainda está aí? Posso continuar ajudando com o que estávamos conversando? Se preferir, posso encaminhar para alguém da nossa equipe."

  </action>
  <verify>
    Run TypeScript compilation: npx tsc --noEmit packages/backend/convex/whatsapp/timeout.ts
  </verify>
  <done>
    checkConversationTimeouts and sendNudgeMessage functions exist and compile
  </done>
</task>

<task type="auto">
  <name>Task 3: Update lastActivityAt on chat activity</name>
  <files>packages/backend/convex/whatsappQueries.ts</files>
  <action>
    Modify storeAiMessage and sendWhatsAppMessage mutations to update lastActivityAt:

    storeAiMessage:
    1. After inserting message, add: lastActivityAt: Date.now()
    2. This ensures AI responses count as activity

    sendMessage (existing mutation):
    1. Find existing chat.lastMessageAt update around line ~197
    2. Add lastActivityAt: Date.now() to patch
    3. This ensures human messages also count as activity

    This ensures both AI and human messages reset the timeout timer

  </action>
  <verify>
    Run TypeScript compilation: npx tsc --noEmit packages/backend/convex/whatsappQueries.ts
  </verify>
  <done>
    lastActivityAt is updated on all chat activity
  </done>
</task>

<task type="auto">
  <name>Task 4: Set up scheduled timeout check</name>
  <files>packages/backend/convex/cron.ts</files>
  <action>
    Create cron.ts with timeoutCron scheduled function:

    timeoutCron:
    1. Use cron job syntax: internalMutation with scheduler
    2. Run every hour: cron: "0 * * * *" (every hour at minute 0)
    3. Calls internal.whatsapp.checkConversationTimeouts()
    4. Logs execution: "[Cron] Running timeout check"

    This ensures inactive conversations are monitored proactively

    If cron.ts doesn't exist, create it with timeoutCron as first scheduled function

  </action>
  <verify>
    Run TypeScript compilation: npx tsc --noEmit packages/backend/convex/cron.ts
  </verify>
  <done>
    timeoutCron scheduled function exists and runs hourly
  </done>
</task>

</tasks>

<verification>
- TypeScript compilation passes for all modified files
- Schema migration succeeds with new fields
- lastActivityAt is updated on all chat messages
- Timeout check runs hourly via cron
- Nudge message is sent at 75% threshold
- Chat is marked abandoned after 24-hour timeout
</verification>

<success_criteria>

- Timeout monitoring system is operational
- Patients receive proactive nudges before timeout
- Abandoned chats are tracked with abandonedAt timestamp
- System handles timeout gracefully without data loss
  </success_criteria>

<output>
After completion, create `.planning/phases/03-flow-execution-engine/03-03A-SUMMARY.md`
</output>
