---
phase: 03-flow-execution-engine
plan: 03-B
type: execute
wave: 3
depends_on: ["03-02"]
files_modified:
  - packages/backend/convex/whatsapp/timeout.ts
  - packages/backend/convex/automationAi.ts
autonomous: true
user_setup: []

must_haves:
  truths:
    - "Patients can request help and get connected to human staff"
    - "AI detects patient help requests and escalates conversations"
  artifacts:
    - path: "packages/backend/convex/whatsapp/timeout.ts"
      provides: "Help request detection and escalation functions"
      exports: ["detectHelpRequest", "escalateToStaff"]
    - path: "packages/backend/convex/automationAi.ts"
      provides: "AI response with help request detection"
      exports: ["generateAiResponse"]
  key_links:
    - from: "packages/backend/convex/automationAi.ts"
      to: "packages/backend/convex/whatsapp/timeout.ts"
      via: "detectHelpRequest call in message processing"
      pattern: "detectHelpRequest\\(.*patientMessage"
    - from: "packages/backend/convex/automationAi.ts"
      to: "packages/backend/convex/whatsapp/timeout.ts"
      via: "escalateToStaff call when help requested"
      pattern: "escalateToStaff\\("
---

<objective>
Implement patient help request detection and escalation to human staff.

Purpose: Provide escape mechanism for patients to request help, automatically detect help requests, and escalate conversations to human staff. This covers escape hatch requirements (FEXEC-09).

Output: Help request detection, escalation mechanism, and integration with AI automation.
</objective>

<execution_context>
@C:\Users\rafar\.config\opencode/get-shit-done/workflows/execute-plan.md
@C:\Users\rafar\.config\opencode/get-shit-done/templates/summary.md
</execution_context>

<context>
@.planning/STATE.md
@.planning/ROADMAP.md
@.planning/phases/03-flow-execution-engine/03-CONTEXT.md
@.planning/phases/03-flow-execution-engine/03-RESEARCH.md
@.planning/phases/03-flow-execution-engine/03-02-PLAN.md
@C:\Users\rafar\Desktop Source\WhatsMed\app\whatsmed-app\packages\backend\convex\automationAi.ts
@C:\Users\rafar\Desktop Source\WhatsMed\app\whatsmed-app\packages\backend\convex\whatsapp.ts
@C:\Users\rafar\Desktop Source\WhatsMed\app\whatsmed-app\packages/backend/convex/whatsappQueries.ts
</context>

<tasks>

<task type="auto">
  <name>Task 1: Create patient help request detection function</name>
  <files>packages/backend/convex/whatsapp/timeout.ts</files>
  <action>
    Add detectHelpRequest helper function to timeout.ts:

    detectHelpRequest:
    1. Takes patientMessage (string) as input
    2. Defines help keywords in Portuguese and English:
       - Portuguese: "humano", "pessoa", "falar com alguém", "ajuda", "preciso de ajuda", "quero falar com", "atendente", "funcionário"
       - English: "human", "person", "speak to someone", "help", "need help", "i want to speak", "agent", "staff"
    3. Normalizes message to lowercase
    4. Checks if any help keyword appears in message
    5. Returns true if keyword found, false otherwise

    This function will be used in automationAi.ts to detect when patients request help

  </action>
  <verify>
    Run TypeScript compilation: npx tsc --noEmit packages/backend/convex/whatsapp/timeout.ts
  </verify>
  <done>
    detectHelpRequest function exists and identifies help keywords
  </done>
</task>

<task type="auto">
  <name>Task 2: Create escalation mechanism to human staff</name>
  <files>packages/backend/convex/whatsapp/timeout.ts</files>
  <action>
    Add escalateToStaff internalMutation to timeout.ts:

    escalateToStaff:
    1. Takes { clinicId, chatId, patientId, reason, context } as args
    2. Creates escalation message (direction: "out") with text:
        "📢 Este chat foi encaminhado para nossa equipe de suporte.\n\nMotivo: {reason}\n\nUm membro da equipe entrará em contato em breve."
    3. Stores message in messages table
    4. Patches chat status to "escalated"
    5. Logs escalation: "[Escalation] Chat {chatId} escalated to human staff: {reason}"
    6. Returns messageId of escalation message

    This provides the escalation mechanism referenced in key_links (FEXEC-09)

  </action>
  <verify>
    Run TypeScript compilation: npx tsc --noEmit packages/backend/convex/whatsapp/timeout.ts
  </verify>
  <done>
    escalateToStaff function exists and creates escalation messages
  </done>
</task>

<task type="auto">
  <name>Task 3: Wire help request detection into AI automation</name>
  <files>packages/backend/convex/automationAi.ts</files>
  <action>
    Modify generateAiResponse action to detect help requests and escalate:

    1. After loading patient message (args.message), add help request detection:
       const needsEscalation = await ctx.runMutation(internal.whatsapp.detectHelpRequest, {
         patientMessage: args.message,
       });

    2. If help requested, escalate immediately before AI processing:
       if (needsEscalation) {
         await ctx.runMutation(internal.whatsapp.escalateToStaff, {
           clinicId: args.clinicId,
           chatId: args.threadId as any,
           patientId: args.patientId,
           reason: "Patient requested help via WhatsApp message",
           context: args.message,
         });

         console.log(`[generateAiResponse] Chat escalated due to help request`);
         return { escalated: true, message: null };
       }

    3. This ensures patient help requests are immediately routed to human staff (FEXEC-09)

  </action>
  <verify>
    Run TypeScript compilation: npx tsc --noEmit packages/backend/convex/automationAi.ts
  </verify>
  <done>
    generateAiResponse detects help requests and escalates to human staff
  </done>
</task>

</tasks>

<verification>
- TypeScript compilation passes for all modified files
- detectHelpRequest identifies help keywords in patient messages
- escalateToStaff creates escalation messages and updates chat status
- generateAiResponse calls detectHelpRequest and escalateToStaff when patient requests help
- Escalation happens immediately, bypassing AI processing when help is requested
</verification>

<success_criteria>

- Patient help requests are detected automatically
- System provides escape hatches for patients to request help (FEXEC-09)
- Help requests connect patients to human staff immediately
- Escalation mechanism provides escape from flow when requested
  </success_criteria>

<output>
After completion, create `.planning/phases/03-flow-execution-engine/03-03B-SUMMARY.md`
</output>
