---
phase: 03-flow-execution-engine
plan: 03-A
subsystem: whatsapp-automation
tags: [convex, cron, timeout-monitoring, scheduling]

# Dependency graph
requires:
  - phase: 03-02
    provides: Flow context integration with Mastra AI agent
provides:
  - Timeout monitoring system with 24-hour inactivity detection
  - Proactive nudge messages at 18-hour mark (75% threshold)
  - Automatic chat abandonment after 24-hour timeout
  - Hourly cron job for timeout checks
  - Activity tracking on all chat messages (human and AI)
affects: [03-04-flow-execution-tracking, flow-execution-engine]

# Tech tracking
tech-stack:
  added: []
  patterns:
    - Cron-based scheduled jobs for background processing
    - Proactive patient engagement via timeout nudges
    - Graceful chat lifecycle management (open → nudge → abandoned)

key-files:
  created:
    - packages/backend/convex/whatsapp/timeout.ts
  modified:
    - packages/backend/convex/whatsappQueries.ts
    - packages/backend/convex/cron.ts

key-decisions:
  - "24-hour timeout with 18-hour nudge threshold (75% of timeout)"
  - "Nudge message in Portuguese: 'Ainda está aí? Posso continuar ajudando...'"
  - "Hourly cron schedule for timeout checks balances responsiveness and performance"
  - "Both human and AI messages reset lastActivityAt timer"

patterns-established:
  - "Pattern: Scheduled background jobs using Convex cronJobs()"
  - "Pattern: Proactive patient engagement before timeout"
  - "Pattern: Activity tracking on message mutations for timeout monitoring"

# Metrics
duration: 20min
completed: 2026-02-05
---

# Phase 3 Plan 03-A: Wait Node Timeout Handling Summary

**Timeout monitoring system with 24-hour inactivity detection, proactive nudges at 75% threshold, and automatic chat abandonment via hourly cron job**

## Performance

- **Duration:** 20 min
- **Started:** 2026-02-05T03:00:00Z
- **Completed:** 2026-02-05T03:20:00Z
- **Tasks:** 3 (Tasks 2-4, Task 1 completed previously)
- **Files modified:** 3

## Accomplishments

- Created timeout monitoring system with checkConversationTimeouts function
- Implemented proactive nudge messaging at 75% of timeout threshold (18 hours)
- Added automatic chat abandonment after 24-hour timeout
- Set up hourly cron job for timeout checks
- Integrated activity tracking into all chat message mutations

## Task Commits

Each task was committed atomically:

1. **Task 1: Add timeout tracking fields to chats table** - `35d5525` (feat)
   _(Completed in previous session)_

2. **Task 2: Create timeout monitoring function** - `b12855d` (feat)
   _(Combined with Task 3)_

3. **Task 3: Update lastActivityAt on chat activity** - `b12855d` (feat)

4. **Task 4: Set up scheduled timeout check** - `86813eb` (feat)

**Plan metadata:** [To be committed after summary creation]

## Files Created/Modified

- `packages/backend/convex/whatsapp/timeout.ts` - Timeout monitoring and nudge functions (NEW FILE)
  - checkConversationTimeouts: Scans inactive chats and triggers nudges/abandonment
  - sendNudgeMessage: Creates and sends nudge message to patient

- `packages/backend/convex/whatsappQueries.ts` - Updated activity tracking
  - sendMessage: Added lastActivityAt update on human messages
  - storeAiMessage: Added lastActivityAt update on AI messages
  - sendMessageAction: Added lastActivityAt update for automation messages

- `packages/backend/convex/cron.ts` - Added scheduled job
  - timeoutCron: Hourly check calling checkConversationTimeouts

## Decisions Made

- **24-hour timeout threshold**: Reasonable window for patient engagement without being too aggressive
- **18-hour nudge threshold (75%)**: Provides proactive outreach 6 hours before abandonment
- **Portuguese nudge message**: "Ainda está aí? Posso continuar ajudando com o que estávamos conversando? Se preferir, posso encaminhar para alguém da nossa equipe."
- **Hourly cron schedule**: Balances responsiveness (max 60-min delay) with performance (no overwhelming queries)
- **Both human and AI messages reset timer**: Ensures any conversation activity extends timeout period

## Deviations from Plan

None - plan executed exactly as written.

## Issues Encountered

None - all tasks completed smoothly without issues.

## User Setup Required

None - no external service configuration required. Timeout monitoring runs automatically via Convex cron jobs.

## Next Phase Readiness

- Timeout monitoring system is operational and ready for integration
- Chat lifecycle management complete (open → nudge → abandoned)
- No blockers or concerns for next phase (03-04: Flow execution tracking)
- Ready to implement flow execution tracking with timeout-aware chat management

---

_Phase: 03-flow-execution-engine_
_Completed: 2026-02-05_
