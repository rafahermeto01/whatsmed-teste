---
phase: 03-flow-execution-engine
plan: 04
subsystem: flow-management
tags: [convex, mutations, flow-activation, clinic-settings]

# Dependency graph
requires:
  - phase: 03-02
    provides: Flow context integration with Mastra AI agent
provides:
  - Flow activation mutations (activateFlow, deactivateFlow)
  - Clinic settings table with default flow configuration
  - Default flow lookup in flow queries
affects: [04-ai-integration]

# Tech tracking
tech-stack:
  added: []
  patterns: [admin-only mutations, clinic-isolated settings]

key-files:
  created: [packages/backend/convex/flows/mutations.ts, packages/backend/convex/clinicSettings.ts]
  modified: [packages/backend/convex/schema.ts, packages/backend/convex/flows/queries.ts]

key-decisions:
  - "Clinic admin role required for flow activation and default flow setting"
  - "Default flow checked first in getActiveFlowByClinic, falling back to active flows"
  - 'clinicSettings table uses Id<"clinics"> for reference to ensure referential integrity'

patterns-established:
  - "Admin-only mutations using checkFlowRole helper"
  - "Clinic settings pattern with unique clinicId reference"
  - "Default lookup pattern: check explicit setting, then fallback to filtered query"

# Metrics
duration: 10min
completed: 2026-02-05
---

# Phase 3: Flow Execution Engine - Plan 04 Summary

**Flow activation mutations with admin role enforcement and clinic-wide default flow configuration**

## Performance

- **Duration:** 10 min
- **Started:** 2026-02-05T06:17:27Z
- **Completed:** 2026-02-05T06:27:15Z
- **Tasks:** 3
- **Files modified:** 4

## Accomplishments

- Implemented `activateFlow` mutation to activate flows and deactivate all other clinic flows
- Implemented `deactivateFlow` mutation to archive flows and clear active version
- Added `clinicSettings` table to schema for storing default flow per clinic
- Implemented `setDefaultFlow` mutation for admins to set clinic's default active flow
- Implemented `getDefaultFlow` query to retrieve clinic's default flow
- Modified `getActiveFlowByClinic` to check default flow first, then fallback to active flows

## Task Commits

Each task was committed atomically:

1. **Task 1: Create flow activation mutations** - `3435b7f` (feat)
2. **Task 2: Create clinic settings with default flow** - `b589f3f` (feat)
3. **Task 3: Update flow lookup to use default flow** - `63cbab9` (feat)

**Plan metadata:** (pending final docs commit)

## Files Created/Modified

### Created

- `packages/backend/convex/flows/mutations.ts` - Flow activation mutations (activateFlow, deactivateFlow)
- `packages/backend/convex/clinicSettings.ts` - Clinic settings mutations and queries (setDefaultFlow, getDefaultFlow)

### Modified

- `packages/backend/convex/schema.ts` - Added clinicSettings table with clinicId (unique) and defaultFlowId fields
- `packages/backend/convex/flows/queries.ts` - Modified getActiveFlowByClinic to use default flow when available

## Decisions Made

- **Admin role enforcement**: Both flow activation and default flow setting require admin role in the clinic, preventing staff from changing active flows
- **Single active flow per clinic**: activateFlow deactivates all other clinic flows before activating the target flow, ensuring only one active flow at a time
- **Default flow fallback pattern**: getActiveFlowByClinic checks clinicSettings for defaultFlowId first, then falls back to querying flows with status="active", providing flexibility for clinics to either specify a default or rely on active status

## Deviations from Plan

None - plan executed exactly as written.

## Issues Encountered

- **Schema parsing error during Task 2 commit**: Initial placement of clinicSettings table caused ESLint parsing error. Fixed by moving clinicSettings table definition after clinics table in schema.ts to ensure proper type resolution (clinics must be defined before clinicSettings which references it via v.id("clinics")).

## User Setup Required

None - no external service configuration required.

## Next Phase Readiness

- Flow activation and deactivation mutations are ready for use in flow builder UI
- Default flow configuration is ready for clinic settings UI
- Flow lookup now respects clinic default flow settings
- Ready for Phase 4: AI Integration (Mastra agent context injection with active flow)

---

_Phase: 03-flow-execution-engine_
_Completed: 2026-02-05_
