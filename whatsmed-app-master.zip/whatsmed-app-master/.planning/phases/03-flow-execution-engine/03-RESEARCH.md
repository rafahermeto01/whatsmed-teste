# Phase 3: Flow Execution Engine - Research

**Researched:** 2026-02-05
**Domain:** AI context injection, conversation management, flow guidance
**Confidence:** MEDIUM

## Summary

Phase 3 implements flow loading as AI guidance documents (not state machines). The system loads flow definitions from Convex, formats them for LLM consumption, injects into Mastra agent context, and handles escape mechanisms through escalation and timeout detection.

Research focused on: (1) Mastra context injection patterns, (2) React Flow serialization for AI consumption, (3) flow-to-LLM formatting best practices, (4) frustration detection and timeout patterns.

**Primary recommendation:** Use Mastra's `context` parameter with formatted Markdown+JSON structure, leverage existing escalation detection tools, implement 24-hour timeout with nudges for WhatsApp conversations.

## Standard Stack

### Core

| Library        | Version | Purpose                                   | Why Standard                                                                     |
| -------------- | ------- | ----------------------------------------- | -------------------------------------------------------------------------------- |
| @mastra/core   | ^0.24.9 | AI agent framework with context injection | Already installed in codebase, provides `context` parameter for ModelMessage[]   |
| @ai-sdk/openai | ^0.0.47 | AI SDK for model interaction              | Already installed, used by Mastra internally                                     |
| React Flow     | 12.x    | Flow serialization (toObject)             | Already installed in frontend, nodes/edges stored in Convex in React Flow format |

### Supporting

| Library    | Version | Purpose                                                         | When to Use                                   |
| ---------- | ------- | --------------------------------------------------------------- | --------------------------------------------- |
| Not needed | N/A     | No additional libraries required for guidance document approach | All functionality available in existing stack |

### Alternatives Considered

| Instead of                     | Could Use             | Tradeoff                                               |
| ------------------------------ | --------------------- | ------------------------------------------------------ |
| State machine library (XState) | Direct state tracking | Adds complexity, violates "guidance document" decision |
| Custom context formatter       | Markdown templates    | Already using Mastra's context parameter effectively   |

**Installation:**

```bash
# No additional packages needed - all dependencies already installed
npm install  # Ensure existing packages are up to date
```

## Architecture Patterns

### Recommended Project Structure

```
packages/backend/convex/
├── flows/
│   ├── execution.ts       # Flow loading and context formatting
│   ├── versions.ts        # Already exists (version management)
│   ├── contextFormatter.ts # Flow → LLM format conversion
│   └── timeout.ts        # Timeout monitoring and nudges
├── whatsapp/
│   ├── actions.ts         # WhatsApp message handling (existing)
│   └── queries.ts         # Chat queries (existing)
└── mastra/
    ├── agents.ts         # Already exists (agent creation with context)
    └── tools.ts          # Already exists (Convex tool wrappers)
```

### Pattern 1: Flow Context Injection via Mastra

**What:** Load flow definition from Convex, format as Markdown+JSON, inject into Mastra agent's `context` parameter
**When to use:** When patient conversation starts with active flow
**Example:**

```typescript
// Source: Mastra docs, automationAi.ts (existing pattern)
import { Agent } from "@mastra/core/agent";

// Load flow version from Convex
const flowVersion = await ctx.runQuery(internal.flows.getActiveVersion, {
  flowId: activeFlowId,
});

// Format flow for LLM consumption
const flowContext = formatFlowForLlm(flowVersion);

// Inject into agent's context (ModelMessage[])
const agent = getClinicAgent(settings, tools);

const result = await agent.generate(patientMessage, {
  context: [
    // Flow guidance as system message
    {
      role: "system",
      content: flowContext,
    },
    // Conversation history from getChatMessagesInternal
    ...conversationHistory,
  ],
  maxSteps: 10,
});
```

### Pattern 2: Flow-to-LLM Formatting

**What:** Convert React Flow JSON structure to Markdown+LLM-friendly format
**When to use:** Before injecting flow into agent context
**Example:**

```typescript
// Source: Web search on JSON → LLM formatting best practices
function formatFlowForLlm(flowVersion: FlowVersion): string {
  const { nodes, connections, variables } = flowVersion;

  // Build node descriptions by type
  const nodeGuides = nodes
    .map((node) => {
      switch (node.type) {
        case "message":
          return `- [${node.id}] SEND MESSAGE: ${node.data.text}`;
        case "condition":
          return `- [${node.id}] CHECK: ${node.data.condition}`;
        case "input":
          return `- [${node.id}] COLLECT INPUT: ${node.data.prompt}`;
        default:
          return `- [${node.id}] ${node.type}`;
      }
    })
    .join("\n");

  // Build connection paths
  const connections = flowVersion.connections
    .map((conn) => {
      return `  ${conn.source} → ${conn.target}`;
    })
    .join("\n");

  // Variables reference
  const variableDefs =
    variables
      ?.map((v) => {
        return `  - {{${v.name}}} (${v.type}): ${v.description || v.defaultValue}`;
      })
      .join("\n") || "  (No variables)";

  // Markdown+JSON structure for LLM parsing
  return `
# FLOW GUIDANCE
This flow is a guide, not a strict script. Use nodes as reference points
but maintain natural, autonomous conversation with the patient.

## Available Variables
\`\`\`json
{
${variableDefs}
}
\`\`\`

## Flow Structure
\`\`\`json
{
  "flowPurpose": "${flowVersion.nodes[0]?.data?.title || "Patient flow"}",
  "startNode": "${connections[0]?.source}",
  "nodes": [
${nodeGuides}
  ],
  "connections": [
${connections}
  ]
}
\`\`\`

## Instructions for AI
1. Nodes are GUIDANCE, not mandatory steps
2. Deviate naturally to answer patient questions
3. Use connections as suggested paths, not rules
4. Feel autonomous and conversational
5. If patient seems frustrated, use escalateToStaff tool
`;
}
```

### Pattern 3: React Flow Serialization

**What:** Existing React Flow format already stored in Convex, ready for LLM consumption
**When to use:** When loading flow from Convex for AI context
**Example:**

```typescript
// Source: React Flow docs (toObject), existing flowVersions.ts schema
// Convex already stores flows in React Flow format:
interface FlowVersion {
  nodes: Array<{
    id: string;
    type: string;
    data: unknown;
    position: { x: number; y: number };
  }>;
  connections: Array<{
    id: string;
    source: string;
    target: string;
    sourceHandle?: string;
    targetHandle?: string;
  }>;
}

// No conversion needed - ready for direct JSON serialization
const flowJson = JSON.stringify(flowVersion, null, 2);
// Can be directly inserted into Markdown code blocks
```

### Pattern 4: Timeout Detection with Nudges

**What:** Monitor last activity, send nudges before timeout, mark as abandoned
**When to use:** WhatsApp/asynchronous conversations
**Example:**

```typescript
// Source: Web search on conversation timeout best practices
// WhatsApp conversations: 24+ hour timeout recommended

// In Convex schema, add to chats table:
// lastActivityAt: number (timestamp)
// timeoutSentAt: number | null (when nudge was sent)
// status: "active" | "timed_out"

// Cron job (runs every hour):
export const checkChatTimeouts = internalMutation({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();
    const TIMEOUT_MS = 24 * 60 * 60 * 1000; // 24 hours
    const NUDGE_MS = 18 * 60 * 60 * 1000; // 18 hours (75% of timeout)

    // Find chats inactive since nudge threshold
    const staleChats = await ctx.db
      .query("chats")
      .withIndex("by_lastActivity", (q) => q.lt("lastActivityAt", now - NUDGE_MS))
      .filter((q) => q.eq("status", "active"))
      .collect();

    for (const chat of staleChats) {
      if (now - chat.lastActivityAt >= TIMEOUT_MS) {
        // Mark as abandoned
        await ctx.db.patch(chat._id, { status: "abandoned" });
      } else if (!chat.timeoutSentAt && now - chat.lastActivityAt >= NUDGE_MS) {
        // Send nudge (75% of timeout)
        await ctx.runMutation(internal.whatsapp.sendNudgeMessage, {
          chatId: chat._id,
          message:
            "Você ainda está aí? Posso continuar ajudando ou prefere falar com alguém da nossa equipe?",
        });
        await ctx.db.patch(chat._id, { timeoutSentAt: now });
      }
    }
  },
});
```

### Pattern 5: Escalation Detection

**What:** Leverage existing escalation tools in Mastra agents
**When to use:** Patient expresses frustration or requests help
**Example:**

```typescript
// Source: Existing agents.ts escalationInstruction pattern
// Already implemented in mastra/agents.ts:

// Escalation topics configured in AI settings
const escalationInstruction = `
⚠️ PROTOCOLOS DE SEGURANÇA - USE 'escalate-to-staff' ⚠️

Você DEVE usar a ferramenta 'escalate-to-staff' IMEDIATAMENTE quando detectar:
- **Jurídico**: processo, advogado, procon, justiça
- **Emergência Médica**: emergência, urgente, dor forte, sangramento
- **Reclamações Graves**: reclamação, insatisfeito, péssimo
- **Palavras Personalizadas**: (configurable em settings)

QUANDO ESCALAR:
1. Detectar qualquer um dos tópicos acima na mensagem
2. Encontrar um problema que você NÃO consegue resolver
3. O paciente expressar frustração ou raiva extrema
4. Situações que envolvam riscos legais ou médicos
`;

// Tool already available in agents.ts
const escalateToStaff = createTool({
  id: "escalateToStaff",
  description: "Escalar conversa para equipe humana",
  execute: async ({ context }) => {
    // Log escalation, notify staff
    return { escalated: true };
  },
});
```

### Anti-Patterns to Avoid

- **State machine execution:** Don't track per-node state, execute step-by-step. Flows are guidance, not strict scripts
- **Manual state persistence:** Don't create execution tracking tables. AI infers state from conversation history
- **Rigid validation:** Don't enforce node completion order. Trust AI to use flows as guidance
- **Hard-coded timeouts:** Don't use fixed values without configuration. Allow clinics to adjust (pending Claude's discretion)

## Don't Hand-Roll

Problems that look simple but have existing solutions:

| Problem                 | Don't Build                 | Use Instead                                       | Why                                            |
| ----------------------- | --------------------------- | ------------------------------------------------- | ---------------------------------------------- |
| Flow execution tracking | Custom state machine tables | Mastra agent context                              | Flows are guidance, not state to track         |
| Context serialization   | Custom JSON-to-text logic   | Markdown+JSON pattern                             | Proven LLM-friendly format, already documented |
| Timeout monitoring      | Cron + manual timestamps    | Convex scheduled functions + existing chat schema | Leverages Convex infrastructure                |
| Frustration detection   | Custom sentiment analysis   | Existing escalation tools                         | Already implemented in agents.ts               |
| Conversation history    | Custom message storage      | getChatMessagesInternal query                     | Existing, optimized for LLM context            |

**Key insight:** Existing Mastra agent infrastructure (agents.ts, automationAi.ts) already provides context injection, escalation tools, and conversation history. Phase 3 is primarily about wiring these together with flow loading and timeout monitoring.

## Common Pitfalls

### Pitfall 1: Treating flows as strict state machines

**What goes wrong:** System tracks node-by-node execution, forces patient through rigid path, creates robotic experience
**Why it happens:** Confusion between "flow" terminology (usually state machines) vs. CONTEXT.md decision (guidance documents)
**How to avoid:** Remember CONTEXT.md decision: "Nodes are tools to help AI keep track of what to do, not strict steps that must be completed"
**Warning signs:** Creating flowExecution table with currentNodeId tracking, complex state transition logic

### Pitfall 2: Over-engineering flow-to-LLM formatting

**What goes wrong:** Complex custom serializers, binary format, or non-JSON structures that LLM struggles to parse
**Why it happens:** Assuming LLM needs special format when standard Markdown+JSON works best
**How to avoid:** Use proven pattern: Markdown headers + JSON code blocks with semantic keys
**Warning signs:** Creating custom DSL, XML-only formats, complex parsing logic

### Pitfall 3: Missing timeout nudges

**What goes wrong:** Patient returns after timeout, confused about where conversation left off, poor UX
**Why it happens:** Using simple timeout without warning stages
**How to avoid:** Implement three-stage graceful degradation (nudge at 70-80%, close at 100%, re-entry greeting)
**Warning signs:** Single cron job that marks timeout immediately without nudges

### Pitfall 4: Not reusing existing escalation tools

**What goes wrong:** Duplicate escalation logic, inconsistent with existing AI behavior
**Why it happens:** Not reviewing existing agents.ts implementation
**How to avoid:** Leverage escalateToStaff tool already configured in agents.ts
**Warning signs:** Creating new escalationMutation when escalateToStaff exists

### Pitfall 5: Blocking AI autonomy

**What goes wrong:** System validates every AI action against flow structure, slows response, feels robotic
**Why it happens:** Misunderstanding "guidance" as "validation"
**How to avoid:** Trust model approach (CONTEXT.md: "No guardrails or anchor validation")
**Warning signs:** Pre/post-processing every AI response, rejecting non-flow responses

## Code Examples

Verified patterns from official sources:

### Flow Loading and Context Injection

```typescript
// Source: Mastra docs (context parameter), existing automationAi.ts pattern
export const loadFlowForConversation = internalAction({
  args: {
    clinicId: v.string(),
    flowId: v.id("flows"),
    patientId: v.id("patients"),
  },
  handler: async (ctx, args) => {
    // 1. Get active flow version
    const flowVersion = await ctx.runQuery(internal.flows.getActiveVersion, {
      flowId: args.flowId,
    });

    if (!flowVersion) {
      return { error: "No active flow version" };
    }

    // 2. Format flow for LLM consumption
    const flowContext = formatFlowForLlm(flowVersion);

    // 3. Get conversation history
    const messages = await ctx.runQuery(internal.whatsappQueries.getChatMessagesInternal, {
      clinicId: args.clinicId,
      chatId: args.patientId as any,
      limit: 20,
    });

    const conversationHistory = messages.map((m) => ({
      role: m.direction === "out" ? "assistant" : "user",
      content: m.body || "[Media Message]",
    }));

    // 4. Get AI settings and agent
    const settings = await ctx.runQuery(internal.automation.getAiSettingsInternal, {
      clinicId: args.clinicId,
    });

    const tools = mastraModule.createConvexTools(ctx, args.clinicId);
    const agent = mastraModule.getClinicAgent(settings, tools);

    // 5. Generate response with flow context
    // First message injects flow, subsequent messages include history
    const context: ModelMessage[] = [
      {
        role: "system",
        content: flowContext, // Formatted flow guide
      },
      ...conversationHistory, // Previous messages
    ];

    // Return for next message processing
    return {
      agent,
      context,
      flowVersionId: flowVersion._id,
    };
  },
});
```

### React Flow to LLM Conversion

```typescript
// Source: Web search (JSON in Markdown best practices), React Flow docs
function formatFlowForLlm(flow: FlowVersion): string {
  const { nodes, connections, variables } = flow;

  // Build semantic node descriptions
  const nodeDescriptions = nodes
    .filter((n) => n.type !== "start" && n.type !== "end")
    .map((node) => {
      const data = node.data as any;
      switch (node.type) {
        case "message":
          return `## Node: ${data.title || "Message"}
Tipo: ENVIAR MENSAGEM
Conteúdo: "${data.text || ""}"
Instrução: Use este texto quando apropriado na conversa
`;
        case "condition":
          return `## Node: ${data.title || "Condition"}
Tipo: VERIFICAR CONDICÃO
Condição: "${data.condition || ""}"
Instrução: Verifique se a condição é verdadeira e siga o caminho correspondente
`;
        case "input":
          return `## Node: ${data.title || "Input"}
Tipo: COLETAR DADO DO PACIENTE
Pergunta: "${data.prompt || ""}"
Campo: "${data.field || "value"}"
Tipo: ${data.inputType || "text"}
Instrução: Pergunte ao paciente de forma natural
`;
        default:
          return `## Node: ${data.title || node.type}
Tipo: ${node.type}
Dados: ${JSON.stringify(data)}
`;
      }
    })
    .join("\n---\n");

  // Build connection paths
  const connectionPaths = connections
    .map((conn) => {
      const sourceNode = nodes.find((n) => n.id === conn.source);
      const targetNode = nodes.find((n) => n.id === conn.target);
      return `${sourceNode?.data?.title || conn.source} → ${targetNode?.data?.title || conn.target}`;
    })
    .join("\n");

  // Variables reference
  const variablesList =
    variables
      ?.map(
        (v) => `- \`\`${v.name}\`\` (${v.type}): ${v.description || "default=" + v.defaultValue}`,
      )
      .join("\n") || "(Nenhuma variável)";

  // Final Markdown+JSON structure
  return `
# FLOW DE PACIENTE - GUIA PARA IA

## Visão Geral
Este fluxo serve como guia de referência para a IA durante a conversa com o paciente.
A IA tem autonomia completa para desviar da estrutura quando necessário.
Os nós são ferramentas para ajudar a IA se organizar, não etapas obrigatórias.

## Variáveis Disponíveis
${variablesList}

## Estrutura do Fluxo

### Nós do Fluxo
${nodeDescriptions}

### Conexões
${connectionPaths}

## Dados do Fluxo (JSON)
\`\`\`json
${JSON.stringify(
  {
    flowId: flow._id,
    versionNumber: flow.versionNumber,
    nodeCount: nodes.length,
    connectionCount: connections.length,
    nodes: nodes.map((n) => ({
      id: n.id,
      type: n.type,
      title: (n.data as any)?.title,
    })),
    connections: connections,
  },
  null,
  2,
)}
\`\`\`

## Instruções para a IA
1. **Autonomia**: Você tem completa liberdade para seguir ou desviar deste fluxo
2. **Naturalidade**: Mantenha conversa natural e empática, não robótica
3. **Flexibilidade**: Se paciente fizer uma pergunta fora do fluxo, responda naturalmente
4. **Referência**: Use os nós como pontos de referência para saber o que fazer
5. **Escalada**: Se detectar frustração ou pedido de ajuda, use 'escalateToStaff'
6. **Retorno**: Quando paciente retornar à conversa após inatividade, analise histórico para inferir posição
`;
}
```

### Timeout Nudge Implementation

```typescript
// Source: Web search (timeout best practices), existing cron.ts pattern
export const checkConversationTimeouts = internalMutation({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();
    const TIMEOUT_HOURS = 24;
    const NUDGE_HOURS = 18; // 75% of timeout

    // Check for inactive conversations needing nudge
    const inactiveChats = await ctx.db
      .query("chats")
      .filter((q) =>
        q.and(q.eq("status", "active"), q.lt("lastMessageAt", now - NUDGE_HOURS * 60 * 60 * 1000)),
      )
      .collect();

    for (const chat of inactiveChats) {
      const hoursInactive = (now - chat.lastMessageAt) / (60 * 60 * 1000);

      if (hoursInactive >= TIMEOUT_HOURS) {
        // Mark as abandoned
        await ctx.db.patch(chat._id, {
          status: "abandoned",
          abandonedAt: now,
        });
        console.log(
          `[Timeout] Chat ${chat._id} marked as abandoned after ${hoursInactive.toFixed(1)}h`,
        );
      } else if (!chat.nudgeSentAt && hoursInactive >= NUDGE_HOURS) {
        // Send nudge message
        const nudgeMessage = `
Ainda está aí? Posso continuar ajudando com o que estávamos conversando?

Se preferir, posso encaminhar para alguém da nossa equipe.
`;
        await ctx.runMutation(internal.whatsapp.sendNudgeMessage, {
          chatId: chat._id,
          text: nudgeMessage,
        });

        await ctx.db.patch(chat._id, {
          nudgeSentAt: now,
        });
        console.log(`[Timeout] Nudge sent to chat ${chat._id} after ${hoursInactive.toFixed(1)}h`);
      }
    }
  },
});
```

## State of the Art

| Old Approach            | Current Approach                 | When Changed                     | Impact                                     |
| ----------------------- | -------------------------------- | -------------------------------- | ------------------------------------------ |
| State machine execution | Guidance document approach       | CONTEXT.md decision (2026-02-05) | Simpler implementation, better AI autonomy |
| Per-node state tracking | Conversation history inference   | CONTEXT.md decision              | Less storage, more natural conversations   |
| Rigid flow validation   | Trust model approach             | CONTEXT.md decision              | Faster responses, better UX                |
| Fixed timeout           | Configurable timeout with nudges | Industry best practices          | Better patient retention, clearer UX       |

**Deprecated/outdated:**

- State machine libraries (XState, Zustand machines) for flows: Flows are now guidance documents, not state machines
- Execution checkpoint tables: AI infers state from history instead
- Flow validation middleware: Trust model, no guardrails

## Open Questions

Things that couldn't be fully resolved:

1. **Frustration keyword lists**
   - What we know: Existing escalation topics in agents.ts (legal, medical, complaints)
   - What's unclear: Additional frustration keywords for patients (LOW confidence)
   - Recommendation: Start with existing escalation topics, add Portuguese frustration phrases like "não consigo", "chateado", "não está funcionando"

2. **Optimal timeout duration for medical chatbots**
   - What we know: Web search recommends 5-15 minutes for live chat, 24+ hours for async
   - What's unclear: Specific to WhatsApp medical context (LOW confidence)
   - Recommendation: Start with 24-hour timeout (matches async nature), allow clinic configuration

3. **Flow-to-LLM complexity limits**
   - What we know: Standard Markdown+JSON pattern works well
   - What's unclear: How many nodes before context becomes too large (LOW confidence)
   - Recommendation: Start with simple formatting, monitor token usage, consider flow summarization if large

## Sources

### Primary (HIGH confidence)

- @mastra/core v0.24.9 - Context injection via `context` parameter (ModelMessage[])
  - WebFetch: Search results confirmed Mastra context parameter usage
  - Existing code: automationAi.ts shows context pattern with conversation history
- React Flow 12.x - Serialization via `toObject() method
  - WebFetch: https://reactflow.dev/examples/interaction/save-and-restore
  - ReactFlowJsonObject structure: { nodes, edges, viewport }
- JSON in Markdown best practices
  - WebSearch: Confirmed Markdown headers + JSON code blocks for LLM parsing
  - Semantic key naming improves LLM understanding

### Secondary (MEDIUM confidence)

- Conversation timeout patterns with nudges
  - WebSearch: 70-80% nudge threshold, three-stage graceful degradation
  - Recommended: 24+ hours for async channels, nudges before timeout
- Flow guidance document approach
  - CONTEXT.md decision: "Flows are NOT executed as state machines"
  - AI autonomy and trust model approach

### Tertiary (LOW confidence)

- Frustration detection keywords
  - WebSearch: No definitive list found for Portuguese medical chat
  - Recommended: Start with existing escalation topics, iterate based on real conversations
- Optimal medical chatbot timeout
  - WebSearch: 5-15 min for live chat, 24+ for async
  - Recommended: 24-hour default for WhatsApp, configurable per clinic

## Metadata

**Confidence breakdown:**

- Standard stack: HIGH - All libraries already verified in codebase (@mastra/core, React Flow)
- Architecture: MEDIUM - Mastra context injection verified, patterns based on existing code
- Pitfalls: MEDIUM - Timeout patterns verified, flow guidance approach documented in CONTEXT.md

**Research date:** 2026-02-05
**Valid until:** 30 days (standard libraries stable, but AI patterns evolve quickly)
