# Phase 3: Flow Execution Engine - Context

**Gathered:** 2026-02-05
**Status:** Ready for planning

<domain>
## Phase Boundary

Flows serve as guidance documents loaded into AI context during patient conversations. The system manages loading flows into AI context at conversation start, handling message flow through Mastra, and providing escape mechanisms for patients to request help or exit conversations. Flows are NOT executed state machines — they're guides that help the AI understand how to proceed.

</domain>

<decisions>
## Implementation Decisions

### AI-flow balance

- AI has full autonomy to optimize flow freely
- AI decides contextually when to deviate from flow structure
- No guardrails or anchor validation — trust model approach
- Nodes are tools to help the AI keep track of what to do, not strict steps that must be completed

### State persistence

- No checkpoint data storage — flows are guidance, not state to track
- No retention policy needed
- AI-driven resumption: AI analyzes conversation history and flow map to determine current state
- No ID tracking per conversation

### Execution model

- Flows are NOT activated as executions — they're loaded into AI context as guidance documents
- Load entire flow definition once at conversation start
- Mastra handles message synchronization between patient and AI
- Mastra handles concurrency across multiple simultaneous conversations

### Escape mechanisms

- Both explicit patient requests AND AI monitoring for frustration/signals
- Direct to human staff immediately when patient requests help
- Mark as abandoned when patient stops responding
- Resume from last position when patient returns (AI infers position)

### Claude's Discretion

- How to format flows for AI consumption during loading
- How Mastra integrates with flow context injection
- How AI detects frustration/signals for proactive exit
- Timeout thresholds for marking conversations as abandoned

</decisions>

<specifics>
## Specific Ideas

- Flows should be presented to AI in a way it understands as a general guide on how to proceed
- Nodes are tools to help AI stay on track, not a rigid execution path
- AI should feel autonomous and conversational, not robotic or constrained

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope

</deferred>

---

_Phase: 03-flow-execution-engine_
_Context gathered: 2026-02-05_
