# Codebase Concerns

**Analysis Date:** 2026-02-04

## Tech Debt

**Unimplemented Features:**

- Issue: SMS, email, and call channels are referenced but not implemented in reminder system
- Files: `packages/backend/convex/automationActions.ts` (line 213)
- Impact: Campaigns and reminders only work via WhatsApp; other channels are dead code
- Fix approach: Implement SMS gateway integration (e.g., Twilio), email templates, and call scheduling logic

**Incomplete Campaign Filtering:**

- Issue: Procedure-based campaign trigger exists but procedure filter is not implemented
- Files: `packages/backend/convex/automationActions.ts` (line 491)
- Impact: "time_after_procedure" trigger returns empty results; campaigns targeting specific procedures don't work
- Fix approach: Add procedure field to appointments schema and implement filtering logic

**Global State Pollution:**

- Issue: Using `global as any` to store Convex internal modules for Mastra AI tools
- Files: `packages/backend/convex/automationActions.ts` (line 14), `packages/backend/convex/automationAi.ts` (line 29)
- Impact: Brittle dependency injection pattern; breaks if multiple actions run concurrently; difficult to test
- Fix approach: Refactor Mastra tools to accept Convex context as constructor parameter

**TypeScript Type Safety Erosion:**

- Issue: Extensive use of `any` type (100+ matches) bypassing TypeScript's type checking
- Files: `packages/backend/convex/automationAi.ts`, `packages/backend/convex/automationHelpers.ts`, `packages/backend/convex/nps.ts`, `packages/backend/convex/lib/rbac.ts`, `packages/backend/convex/lib/rateLimits.ts`
- Impact: Runtime type errors; no autocomplete; difficult refactoring
- Fix approach: Define proper interfaces for Convex query/mutation results, auth contexts, and database queries

## Known Bugs

**WhatsApp Phone Number Formatting:**

- Issue: Comment indicates Brazilian phone format but implementation doesn't fully handle edge cases
- Files: `apps/web/src/routes/whatsapp.tsx` (line 88)
- Symptoms: Phone numbers may display incorrectly for edge cases (9-digit vs 8-digit mobile, international numbers)
- Trigger: Viewing WhatsApp inbox with phone numbers from different Brazilian states or countries
- Workaround: None; users see potentially incorrect formats

**Timezone Hardcoding:**

- Issue: Brazil timezone offset (UTC-3) is hardcoded; assumes no DST which changed in 2019
- Files: `packages/backend/convex/appointments.ts` (lines 35-89)
- Symptoms: Appointments may be off by 1 hour if Brazil changes DST policy again
- Trigger: Any appointment scheduling around DST transition dates
- Workaround: None; would require code update if Brazil implements DST again

**Race Condition in User Creation:**

- Issue: After creating auth user, code waits 200ms for trigger to complete before updating user record
- Files: `packages/backend/convex/http.ts` (line 278)
- Symptoms: User record may not be updated with correct clinicId/role if trigger is slow
- Trigger: High load or slow Convex trigger execution
- Workaround: Retry user creation or manually update user record via admin panel

## Security Considerations

**Exposed API Keys in Source Control:**

- Risk: Evolution API key is visible in `.env.local` file
- Files: `.env.local` (line 7)
- Impact: If repository is public, anyone can use the WhatsApp instance; credentials may have been leaked
- Current mitigation: File should be in `.gitignore` (check `.gitignore` for `*.local` pattern)
- Recommendations: Immediately rotate API key; ensure `.env.local` is gitignored; use secret management (Convex secrets, environment variables in CI)

**Extensive Console Logging:**

- Risk: Sensitive data logged via console.log/warn/error in production
- Files: `packages/backend/convex/automationAi.ts` (lines 26-694), `packages/backend/convex/nps.ts`, `packages/backend/convex/whatsappInternal.ts`, `apps/web/src/` (57 matches)
- Impact: Patient names, phone numbers, conversation history may be exposed in logs; potential PII violation (GDPR/LGPD)
- Current mitigation: None; logs likely accessible in production
- Recommendations: Replace all console statements with structured logging library (e.g., Winston, Pino); implement log levels; redact PII in production logs

**Missing Input Validation:**

- Risk: User inputs not thoroughly validated before database operations
- Files: `packages/backend/convex/http.ts` (webhook payload), `packages/backend/convex/patients.ts`, `packages/backend/convex/users.ts`
- Impact: Potential SQL injection (unlikely with Convex), XSS, or malicious data injection
- Current mitigation: Basic Convex validation with v.\* types
- Recommendations: Implement comprehensive input validation with Zod; sanitize webhook payloads; add rate limiting on public endpoints

**Hardcoded Error Messages in Portuguese:**

- Risk: Error messages exposing system internals and not internationalized
- Files: `packages/backend/convex/checkin.ts` (lines 81-495), `packages/backend/convex/appointments.ts` (lines 1360-1467)
- Impact: Information disclosure to attackers; poor UX for Portuguese-speaking users; inconsistent error handling
- Current mitigation: None
- Recommendations: Create error code system; internationalize error messages; use generic messages for public errors

## Performance Bottlenecks

**Large Source Files:**

- Problem: Several files exceed 800 lines, indicating high complexity and potential maintenance issues
- Files: `packages/backend/convex/appointments.ts` (1797 lines), `packages/backend/convex/checkin.ts` (1003 lines), `packages/backend/convex/http.ts` (911 lines), `packages/backend/convex/nps.ts` (890 lines), `packages/backend/convex/billing.ts` (835 lines)
- Cause: Monolithic files handling multiple concerns (e.g., appointments mixes scheduling, validation, Google Calendar integration, NPS, rescheduling)
- Improvement path: Split into smaller modules by concern; extract validation logic; separate integration code; use barrel files for organization

**N+1 Query Pattern:**

- Problem: Potential N+1 queries in list operations with related data
- Files: `packages/backend/convex/appointments.ts` (line 162-200), `packages/backend/convex/whatsappQueries.ts`
- Cause: Looping through results and fetching related data one-by-one
- Improvement path: Use Convex's query optimization patterns; batch related queries; consider denormalizing frequently accessed data

**AI Response Generation Retry Loop:**

- Problem: Up to 3 retries with full tool execution on each failure; no exponential backoff
- Files: `packages/backend/convex/automationAi.ts` (lines 309-571)
- Cause: Retry logic for AI tool validation without proper backoff strategy
- Improvement path: Implement exponential backoff; cache successful tool results; limit retry attempts based on error type; add circuit breaker pattern

**No Caching Strategy:**

- Problem: Frequently accessed data (clinic settings, user permissions) queried on every request
- Files: `packages/backend/convex/automationAi.ts` (line 57), `packages/backend/convex/lib/rbac.ts`, `packages/backend/convex/lib/planEnforcement.ts`
- Cause: No caching layer; every query hits Convex database
- Improvement path: Implement in-memory cache with TTL for static data; use Convex's built-in caching; cache user permissions per session

## Fragile Areas

**Automation AI System:**

- Files: `packages/backend/convex/automationAi.ts` (703 lines), `packages/backend/convex/mastra/tools.ts`, `packages/backend/convex/mastra/agents.ts`
- Why fragile: Complex retry logic, global state dependency, AI hallucination risk, tool validation errors
- Safe modification: Thoroughly test all AI responses; add integration tests; log all tool executions; implement human-in-the-loop for escalations
- Test coverage: No tests for AI system; high risk area

**WhatsApp Webhook Handler:**

- Files: `packages/backend/convex/http.ts` (911 lines), `packages/backend/convex/whatsappInternal.ts`, `packages/backend/convex/whatsappQueries.ts`
- Why fragile: Parses untrusted external payloads; media handling with multiple fallback paths; depends on third-party API (Evolution API)
- Safe modification: Add webhook signature validation; test all message types; add idempotency keys; implement circuit breaker for Evolution API failures
- Test coverage: No integration tests for webhook handling

**Billing/Payment System:**

- Files: `packages/backend/convex/billing.ts`, `packages/backend/convex/billing_internal.ts`, `packages/backend/convex/lib/asaas.ts`
- Why fragile: External API dependencies (Asaas); payment state management; webhooks from payment provider; currency conversion
- Safe modification: Implement payment state machine; add idempotency to payment operations; test sandbox-to-production flow; monitor payment failures
- Test coverage: Limited tests; no end-to-end payment flow tests

**Check-in QR Code System:**

- Files: `packages/backend/convex/checkin.ts` (1003 lines), `apps/web/src/components/checkin/QRScanner.tsx`, `apps/web/src/components/checkin/ConsentForm.tsx`
- Why fragile: Time-sensitive tokens; mobile camera permissions; public-facing check-in links; consent form state
- Safe modification: Add token expiration handling; test on multiple devices; implement offline fallback; add consent tracking
- Test coverage: No automated tests for check-in flow

## Scaling Limits

**Convex Function Limits:**

- Current capacity: 1,297 lines of generated API; 21,879 lines of total Convex code
- Limit: Convex limits function complexity and query depth; large functions may hit execution time limits
- Scaling path: Split large functions into smaller chunks; use internal functions for complex logic; optimize queries with indexes; consider moving heavy computation to actions

**WhatsApp Message Volume:**

- Current capacity: Single Evolution API instance per clinic
- Limit: Evolution API has rate limits; no queueing for outbound messages
- Scaling path: Implement message queue; add rate limiting per clinic; use multiple Evolution instances; implement retry with exponential backoff

**AI Token Usage:**

- Current capacity: No visible rate limiting on AI calls; credit system exists but not enforced for AI
- Limit: OpenAI/Mastra API rate limits and costs; may incur unexpected charges
- Scaling path: Implement per-clinic AI token quotas; cache AI responses; add cost tracking; implement request batching

**Document Storage:**

- Current capacity: Using Convex storage; no visible size limits configured
- Limit: Convex storage has per-file and total limits; documents may accumulate
- Scaling path: Implement document retention policy; use external storage (S3) for large files; add document archiving

## Dependencies at Risk

**Evolution API (WhatsApp):**

- Risk: Third-party WhatsApp API; potential shutdown; rate limits; API changes; requires QR code scanning for new instances
- Impact: Core messaging functionality broken; patients can't communicate via WhatsApp
- Migration plan: Evaluate official WhatsApp Business API; maintain abstraction layer; implement fallback to email/SMS; support multiple WhatsApp providers

**Asaas (Payments):**

- Risk: Brazilian payment gateway; limited to Brazil; API changes; sandbox vs production differences
- Impact: Billing, subscriptions, and wallet functionality broken; clinics can't pay for service
- Migration plan: Abstract payment provider interface; support multiple gateways (Stripe, Pagar.me); maintain payment state independent of provider

**Google Calendar:**

- Risk: OAuth token expiration; API rate limits; quota limits
- Impact: Appointment sync fails; double booking risk
- Migration plan: Implement token refresh logic; add sync conflict resolution; consider alternative calendar integrations

**Convex Database:**

- Risk: Vendor lock-in; limits on query complexity; potential pricing changes
- Impact: All data storage broken; application unusable
- Migration plan: Document data models thoroughly; implement repository pattern; consider PostgreSQL backup for critical data; design for multi-database support

**Mastra AI Framework:**

- Risk: New/experimental framework; potential breaking changes; AI model availability
- Impact: AI features broken; automation not working; degraded customer experience
- Migration plan: Abstract AI provider interface; support multiple AI backends (OpenAI, Anthropic); implement fallback rule-based system

## Missing Critical Features

**Observability Infrastructure:**

- Problem: No centralized logging; no error tracking (Sentry); no metrics/monitoring
- Blocks: Production debugging; performance optimization; error alerting; SLA monitoring
- Risk: Silent failures; poor incident response time; difficulty diagnosing issues

**Internationalization (i18n):**

- Problem: Mix of Portuguese and English error messages; hardcoded strings in UI
- Blocks: Expansion beyond Brazilian market; inconsistent user experience
- Risk: Confusion for users; maintenance burden for multi-language support

**Backup and Recovery:**

- Problem: No documented backup strategy; no disaster recovery plan
- Blocks: Data loss recovery; regulatory compliance (LGPD requires backups); business continuity
- Risk: Permanent data loss; regulatory penalties; clinic trust damage

**Admin Audit Trail:**

- Problem: Audit logs exist but no admin interface to view them
- Blocks: Compliance auditing; security incident investigation; user activity monitoring
- Risk: Inability to trace unauthorized actions; compliance violations

**Feature Flags System:**

- Problem: New features deployed to all clinics at once; no gradual rollout capability
- Blocks: Safe feature rollout; A/B testing; quick rollback of problematic features
- Risk: Widespread outages from bad deployments; inability to test features with subset of users

## Test Coverage Gaps

**No Frontend Tests:**

- What's not tested: All React components; user flows; form validation; error handling in UI
- Files: `apps/web/src/components/`, `apps/web/src/routes/`
- Risk: UI regressions; broken user flows; inconsistent behavior across browsers
- Priority: High - test critical flows (appointment creation, check-in, billing, WhatsApp messaging)

**No Integration Tests:**

- What's not tested: Webhook processing; external API integrations (Evolution, Asaas, Google); end-to-end workflows
- Files: `packages/backend/convex/http.ts`, `packages/backend/convex/integrations.ts`, `packages/backend/convex/whatsappInternal.ts`
- Risk: External API changes break application silently; webhook parsing errors; integration failures
- Priority: High - test all third-party integrations with mocked responses

**No AI System Tests:**

- What's not tested: AI response generation; tool execution; escalation logic; context building
- Files: `packages/backend/convex/automationAi.ts`, `packages/backend/convex/mastra/`
- Risk: AI hallucinations; incorrect tool calls; inappropriate automated responses
- Priority: High - test AI safety, tool validation, escalation triggers

**Limited Backend Unit Tests:**

- What's not tested: Automation system; billing flows; NPS survey; check-in flow; kanban logic; analytics; document processing
- Files: `packages/backend/convex/automation.ts`, `packages/backend/convex/billing.ts`, `packages/backend/convex/nps.ts`, `packages/backend/convex/checkin.ts`, `packages/backend/convex/kanban.ts`, `packages/backend/convex/analytics.ts`
- Risk: Business logic regressions; calculation errors; workflow bugs
- Priority: Medium - add tests for complex business logic first

**No Performance Tests:**

- What's not tested: Load testing for message volume; concurrent appointment booking; database query performance
- Risk: Performance degradation under load; database timeouts; race conditions
- Priority: Medium - test before scaling to larger clinic counts

---

_Concerns audit: 2026-02-04_
