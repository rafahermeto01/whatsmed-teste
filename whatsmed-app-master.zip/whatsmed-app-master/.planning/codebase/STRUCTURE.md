# Codebase Structure

**Analysis Date:** 2026-02-04

## Directory Layout

```
whatsmed-app/
├── apps/
│   └── web/                      # Frontend React application
│       ├── src/
│       │   ├── components/       # React components
│       │   ├── hooks/            # Custom React hooks
│       │   ├── lib/              # Utility libraries
│       │   ├── routes/           # TanStack Router file-based routes
│       │   ├── tests/            # Frontend tests
│       │   ├── __tests__/        # Test utilities
│       │   ├── router.tsx        # Router configuration
│       │   ├── routeTree.gen.ts  # Generated route tree (TanStack)
│       │   └── index.css         # Global styles
│       ├── public/               # Static assets
│       ├── package.json
│       ├── vite.config.ts
│       └── vitest.config.ts
├── packages/
│   ├── backend/                  # Convex backend code
│   │   ├── convex/               # Convex functions and schema
│   │   │   ├── lib/              # Backend utility libraries
│   │   │   │   ├── patients/     # Patient-related helpers
│   │   │   │   └── whatsapp/     # WhatsApp provider implementations
│   │   │   ├── _generated/       # Generated Convex types and API
│   │   │   ├── schema.ts         # Database schema definition
│   │   │   ├── http.ts           # HTTP routes (webhooks, API)
│   │   │   ├── auth.ts           # Better-auth configuration
│   │   │   ├── appointments.ts   # Appointment functions
│   │   │   ├── patients.ts       # Patient functions
│   │   │   ├── chats.ts          # Chat management
│   │   │   ├── messages.ts       # Message functions
│   │   │   ├── billing.ts        # Billing and wallet functions
│   │   │   ├── automation.ts     # Marketing automation
│   │   │   └── [other modules]   # Various feature modules
│   │   ├── tests/                # Backend tests
│   │   └── package.json
│   └── config/                   # Shared TypeScript configuration
│       ├── tsconfig.base.json
│       └── package.json
├── convex/                       # Generated Convex types (symlink)
├── .planning/                    # Planning and documentation
│   └── codebase/                 # Codebase analysis documents
├── .husky/                       # Git hooks
├── turbo.json                    # Turborepo configuration
├── package.json                  # Root package.json (workspaces)
└── bun.lock                      # Bun lockfile (package manager)
```

## Directory Purposes

**apps/web/**:

- Purpose: Main frontend React application
- Contains: All client-side code, UI components, routes, hooks
- Key files: `src/router.tsx`, `src/routes/__root.tsx`, `vite.config.ts`

**packages/backend/convex/**:

- Purpose: Backend business logic and database schema
- Contains: Convex functions (queries, mutations, actions), HTTP routes, schema definition
- Key files: `schema.ts`, `http.ts`, `auth.ts`, `lib/` utilities

**packages/backend/convex/lib/**:

- Purpose: Shared backend utilities and helper functions
- Contains: Authentication helpers, validation, error handling, rate limiting, external API clients
- Key files: `authContext.ts`, `errors.ts`, `validators.ts`, `rateLimit.ts`, `asaas.ts`, `evolution.ts`

**packages/backend/convex/lib/whatsapp/**:

- Purpose: WhatsApp API provider implementations
- Contains: Factory and providers for Evolution API and Meta Cloud API
- Key files: `factory.ts`, `evolutionProvider.ts`, `metaPhantom.ts`

**apps/web/src/components/**:

- Purpose: React UI components
- Contains: Feature-specific components (appointments, billing, automation, etc.), UI primitives
- Key files: `MainLayout.tsx`, `AppointmentDetailsModal.tsx`, `AddPatientModal.tsx`, `ui/` (Radix components)

**apps/web/src/hooks/**:

- Purpose: Custom React hooks for state management and data fetching
- Contains: Feature-specific hooks for appointments, patients, billing, etc.
- Key files: `appointments.ts`, `patients.ts`, `automation.ts`, `useAutoSave.ts`

**apps/web/src/routes/**:

- Purpose: TanStack Router file-based routes
- Contains: Page components and route definitions
- Key files: `__root.tsx` (root route with auth), `appointments.tsx`, `patients.tsx`, `whatsapp.tsx`, `api/` (API routes)

**apps/web/src/lib/**:

- Purpose: Frontend utility libraries
- Contains: API clients, auth clients, utilities
- Key files: `auth-client.ts`, `auth-server.ts`, `api.ts`, `utils.ts`

**apps/web/src/components/ui/**:

- Purpose: Reusable UI component library (Radix UI primitives)
- Contains: Button, Dialog, Input, Select, Form, etc.
- Key files: `button.tsx`, `dialog.tsx`, `input.tsx`, `form.tsx`, `calendar.tsx`

**packages/config/**:

- Purpose: Shared TypeScript configuration across monorepo
- Contains: Base TSConfig with strict settings
- Key files: `tsconfig.base.json`

**.planning/codebase/**:

- Purpose: Codebase analysis documents (this directory)
- Contains: ARCHITECTURE.md, STRUCTURE.md, and other analysis docs

## Key File Locations

**Entry Points:**

- `apps/web/src/router.tsx`: Creates TanStack Router with Convex integration
- `apps/web/src/routes/__root.tsx`: Root route with authentication check
- `apps/web/src/routes/index.tsx`: Root path redirect to `/login`
- `packages/backend/convex/convex.config.ts`: Convex app configuration
- `packages/backend/convex/http.ts`: HTTP routes for webhooks and API

**Configuration:**

- `package.json`: Root monorepo configuration with workspaces
- `turbo.json`: Turborepo task configuration and pipelines
- `apps/web/vite.config.ts`: Vite bundler configuration with SSR plugins
- `apps/web/package.json`: Frontend dependencies and scripts
- `packages/backend/package.json`: Backend dependencies and scripts
- `packages/config/tsconfig.base.json`: Shared TypeScript config

**Core Logic (Backend):**

- `packages/backend/convex/schema.ts`: Database schema (all tables, indexes)
- `packages/backend/convex/auth.ts`: Authentication with better-auth
- `packages/backend/convex/appointments.ts`: Appointment CRUD and slot management
- `packages/backend/convex/patients.ts`: Patient management
- `packages/backend/convex/chats.ts`: Chat/session management
- `packages/backend/convex/messages.ts`: Message handling
- `packages/backend/convex/billing.ts`: Wallet, transactions, subscriptions
- `packages/backend/convex/automation.ts`: Marketing campaigns and automation

**Core Logic (Frontend):**

- `apps/web/src/routes/appointments.tsx`: Appointments page
- `apps/web/src/routes/patients.tsx`: Patients page
- `apps/web/src/routes/whatsapp.tsx`: WhatsApp messaging interface
- `apps/web/src/routes/billing.tsx`: Billing and wallet UI
- `apps/web/src/routes/automation.tsx`: Automation builder
- `apps/web/src/components/MainLayout.tsx`: Main app layout with sidebar

**Testing:**

- `apps/web/src/tests/`: Frontend test files (not commonly used)
- `packages/backend/tests/`: Backend unit and integration tests

**External Integrations:**

- `packages/backend/convex/lib/asaas.ts`: Asaas payment gateway client
- `packages/backend/convex/lib/evolution.ts`: Evolution WhatsApp API client
- `packages/backend/convex/googleCalendar.ts`: Google Calendar integration
- `packages/backend/convex/integrations.ts`: Integration management functions

## Naming Conventions

**Files:**

- Components: PascalCase (e.g., `AppointmentDetailsModal.tsx`, `MainLayout.tsx`)
- Hooks: camelCase with `use` prefix (e.g., `appointments.ts`, `useAutoSave.ts`)
- Routes: camelCase (e.g., `appointments.tsx`, `patients.tsx`)
- Convex modules: camelCase (e.g., `appointments.ts`, `patients.ts`)
- Tests: camelCase with `.test.ts` or `.spec.ts` suffix
- Libraries: camelCase (e.g., `api.ts`, `utils.ts`, `auth-client.ts`)

**Directories:**

- Feature directories: lowercase or camelCase (e.g., `patients/`, `whatsapp/`, `billing/`)
- UI primitives: lowercase (e.g., `ui/`, `hooks/`, `lib/`)
- System directories: lowercase with underscores (e.g., `__tests__/`)

**Convex Functions:**

- Queries: camelCase, descriptive (e.g., `list`, `getById`, `search`)
- Mutations: camelCase, action-oriented (e.g., `create`, `update`, `softDelete`)
- Actions: camelCase, compound words (e.g., `createGoogleMeet`, `sendMessage`)
- Internal functions: Prefixed with underscore or in separate `*Internal.ts` files

## Where to Add New Code

**New Feature:**

- Primary code (backend): `packages/backend/convex/[featureName].ts`
- Primary code (frontend): `apps/web/src/routes/[featureName].tsx`
- Components: `apps/web/src/components/[featureName]/`
- Tests: `packages/backend/tests/[featureName].test.ts`

**New API Endpoint:**

- HTTP route: `packages/backend/convex/http.ts`
- Frontend API route: `apps/web/src/routes/api/[resource]/[action].tsx`

**New Component/Module:**

- Implementation: `apps/web/src/components/[ComponentName].tsx`
- UI primitive: `apps/web/src/components/ui/[primitive].tsx`

**Utilities:**

- Shared helpers: `apps/web/src/lib/[utilityName].ts`
- Backend helpers: `packages/backend/convex/lib/[utilityName].ts`
- Hooks: `apps/web/src/hooks/[hookName].ts`

**Database Changes:**

- Schema modifications: `packages/backend/convex/schema.ts`
- Generated types: Automatically regenerated by `npx convex dev`

**External Integration:**

- API client: `packages/backend/convex/lib/[providerName].ts`
- Integration functions: `packages/backend/convex/[integrationName].ts`

## Special Directories

**\_generated/**:

- Purpose: Auto-generated Convex types and API
- Generated: Yes (by `npx convex dev`)
- Committed: Yes
- Location: `packages/backend/convex/_generated/`, `convex/_generated/` (symlink)

**node_modules/**:

- Purpose: Installed dependencies
- Generated: Yes (by package manager)
- Committed: No

**.turbo/**:

- Purpose: Turborepo build cache
- Generated: Yes (by Turborepo)
- Committed: No

**.vercel/**:

- Purpose: Vercel deployment output
- Generated: Yes (by Vercel build)
- Committed: Yes (for deployment)

**dist/**:

- Purpose: Frontend build output
- Generated: Yes (by Vite build)
- Committed: No

**.husky/**:

- Purpose: Git hooks configuration
- Generated: No
- Committed: Yes

**public/**:

- Purpose: Static assets served by frontend
- Generated: No
- Committed: Yes
- Location: `apps/web/public/`

---

_Structure analysis: 2026-02-04_
