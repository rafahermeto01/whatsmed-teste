# Architecture

**Analysis Date:** 2026-02-04

## Pattern Overview

**Overall:** Monorepo with Separated Frontend/Backend

**Key Characteristics:**

- Monorepo using Turbo for orchestration
- TanStack Router for file-based routing with SSR support (Vite + Nitro)
- Convex as backend-as-a-service providing database, functions, and real-time
- Multi-tenant SaaS architecture with clinic-based isolation
- Role-based access control (RBAC) with clinic membership

## Layers

**Frontend (apps/web):**

- Purpose: React SPA with file-based routing, real-time updates, and UI components
- Location: `apps/web/`
- Contains: Routes, components, hooks, styles
- Depends on: Convex client SDK, TanStack Query, Radix UI, Tailwind CSS
- Used by: End users via browser

**Backend (packages/backend):**

- Purpose: Business logic, database schema, API endpoints, webhooks
- Location: `packages/backend/convex/`
- Contains: Database schema, queries, mutations, actions, HTTP routes, library functions
- Depends on: Convex server SDK, better-auth, AI SDKs, external APIs (Evolution, Asaas, Google Calendar)
- Used by: Frontend via Convex SDK, external webhooks

**Shared Configuration (packages/config):**

- Purpose: TypeScript configuration shared across packages
- Location: `packages/config/`
- Contains: Base TypeScript config
- Depends on: None
- Used by: web, backend packages

## Data Flow

**Client-to-Server (Queries/Mutations):**

1. Frontend calls `useQuery(api.{module}.{function})` or `useMutation(api.{module}.{function})`
2. TanStack Query integrates with ConvexQueryClient to manage caching and reactivity
3. Convex client SDK sends request to Convex deployment via WebSocket
4. Convex server executes query/mutation in backend package
5. Database read/write occurs in Convex's managed database
6. Result flows back through Convex client, updates TanStack Query cache
7. React components re-render with new data

**Webhook Inflow (External → Convex):**

1. External service (WhatsApp provider, Asaas, Google Calendar) sends HTTP POST to Convex HTTP routes
2. Route defined in `packages/backend/convex/http.ts` receives request
3. Middleware: CORS, rate limiting, authentication
4. HTTP action handler processes payload
5. May trigger mutations (create message, update appointment, process payment)
6. Database updated via Convex SDK
7. Frontend automatically receives update via Convex real-time subscription

**Real-time Updates:**

1. Client subscribes to queries via `useQuery()`
2. Convex maintains WebSocket connection
3. When database changes affect subscribed query results
4. Convex pushes update to client
5. TanStack Query cache updates
6. Components re-render

**State Management:**

- **Client state**: TanStack Query (query cache, mutations, optimistic updates)
- **Server state**: Convex managed database (CRDT-based, ACID transactions)
- **Auth state**: better-auth with Convex plugin, session stored in cookies
- **Form state**: React Hook Form + TanStack Form

## Key Abstractions

**Multi-Tenant Isolation (Clinic-scoped):**

- Purpose: Enforce data separation between medical clinics
- Examples: `packages/backend/convex/schema.ts` (all tables have `clinicId` index), `packages/backend/convex/lib/multiTenant.ts`
- Pattern: All queries/mutations require `clinicId` parameter, database indexes enforce scoping

**Role-Based Access Control (RBAC):**

- Purpose: Restrict actions based on user role (admin, staff, viewer, doctor, super_admin)
- Examples: `packages/backend/convex/lib/rbac.ts`, `packages/backend/convex/lib/planEnforcement.ts`
- Pattern: Role checked before operations, plan limits enforced by `checkFeatureAccess()`

**WhatsApp Provider Abstraction:**

- Purpose: Support multiple WhatsApp API providers (Evolution API, Meta Cloud API)
- Examples: `packages/backend/convex/lib/whatsapp/evolutionProvider.ts`, `packages/backend/convex/lib/whatsapp/metaPhantom.ts`, `packages/backend/convex/lib/whatsapp/factory.ts`
- Pattern: Factory pattern to create provider instance based on configuration

**Better-Auth Integration:**

- Purpose: Handle authentication, session management, OAuth flows
- Examples: `packages/backend/convex/auth.ts`, `packages/backend/convex/auth.config.ts`, `packages/backend/convex/lib/authContext.ts`
- Pattern: Triggers on user creation to sync with `users` table, Convex plugin for backend integration

**Feature Access Gates:**

- Purpose: Enforce plan-based feature availability
- Examples: `packages/backend/convex/lib/planEnforcement.ts`, `apps/web/src/components/PlanGate.tsx`
- Pattern: `checkFeatureAccess()` function returns `{allowed: boolean, reason?: string}`, frontend gates UI based on result

**Audit Logging:**

- Purpose: Track all write operations for compliance and debugging
- Examples: `packages/backend/convex/lib/audit.ts`, `packages/backend/convex/auditLogs.ts`
- Pattern: `writeAudit()` function called after mutations, stores action, user, timestamp, metadata

**Rate Limiting:**

- Purpose: Prevent abuse of API endpoints and resources
- Examples: `packages/backend/convex/lib/rateLimit.ts`, `packages/backend/convex/lib/rateLimits.ts`
- Pattern: Sliding window algorithm with configurable limits per category (auth, health, etc.)

## Entry Points

**Frontend Router:**

- Location: `apps/web/src/router.tsx`
- Triggers: Application initialization (Vite entry)
- Responsibilities: Creates TanStack Router with Convex integration, sets up QueryClient, wraps app in ConvexProvider

**Frontend Root Route:**

- Location: `apps/web/src/routes/__root.tsx`
- Triggers: Initial page load
- Responsibilities: Authentication check (beforeLoad), public/private route handling, MainLayout wrapper, Toaster setup

**Frontend Route File:**

- Location: `apps/web/src/routes/index.tsx`
- Triggers: Access to root path `/`
- Responsibilities: Redirects to `/login`

**Backend Convex App:**

- Location: `packages/backend/convex/convex.config.ts`
- Triggers: Convex deployment
- Responsibilities: Configures Convex app with better-auth plugin

**Backend HTTP Router:**

- Location: `packages/backend/convex/http.ts`
- Triggers: Incoming HTTP requests to Convex
- Responsibilities: Defines HTTP routes for health checks, webhooks, API endpoints, CORS handling, rate limiting

**Backend Schema:**

- Location: `packages/backend/convex/schema.ts`
- Triggers: Convex deployment
- Responsibilities: Defines all database tables, indexes, and search indexes

**Backend Auth Trigger:**

- Location: `packages/backend/convex/auth.ts`
- Triggers: Better-auth user creation/update events
- Responsibilities: Syncs auth users with `users` table, sets default clinic and role

## Error Handling

**Strategy:** Centralized error types, HTTP response helpers, user-facing error UI

**Patterns:**

1. **Backend Error Helpers** (`packages/backend/convex/lib/errors.ts`):

   ```typescript
   notFound(message, metadata);
   badRequest(message, metadata);
   forbidden(message, metadata);
   unauthorized(message, metadata);
   ```

2. **HTTP Response Helpers** (`packages/backend/convex/lib/httpHelpers.ts`):

   ```typescript
   jsonResponse(data, status);
   errorResponse(error, requestId);
   withCors(handler);
   withRateLimit(handler, options);
   ```

3. **Frontend Error Boundary** (`apps/web/src/components/ErrorBoundary.tsx`):
   - Catches React errors, displays fallback UI

4. **Convex Error Propagation**:
   - Query/Mutation errors thrown in backend flow to frontend
   - TanStack Query's `error` state exposes thrown errors
   - Components check `isError` and display `error.message`

5. **Mutation Error Handling**:
   - `useMutation()` returns `{mutate, isPending, error}`
   - Success/error callbacks can be provided to `mutate({...}, {onSuccess, onError})`

6. **Toast Notifications** (`sonner`):
   - Used throughout app for success/error feedback
   - `toast.success()`, `toast.error()`, `toast.warning()`

## Cross-Cutting Concerns

**Logging:** Console logging with structured prefixes for debugging (e.g., `[Auth Trigger]`, `[sanitizeMessagePayload]`). No external logging service currently used.

**Validation:**

- Input validation using `convex/values` (v.string(), v.number(), v.union(), etc.) in schema and function arguments
- Zod schemas for form validation in frontend
- `packages/backend/convex/lib/validators.ts` contains validation helpers for appointments, dates, etc.

**Authentication:**

- better-auth for authentication (email/password, OAuth)
- Session stored in HTTP-only cookie
- ConvexBetterAuthProvider wraps application for session context
- Authentication checked in `__root.tsx` beforeLoad for all non-public routes
- HTTP routes authenticate via `authenticate()` helper in `http.ts`

**Rate Limiting:**

- Applied to HTTP routes via `withRateLimit()` decorator
- Configurable per route category (auth: 10 req/window, health: 100 req/window)
- Stored in `rateLimits` table with sliding window
- Checked before executing protected operations

**Multi-tenancy:**

- All data scoped by `clinicId`
- `packages/backend/convex/lib/multiTenant.ts` provides utility functions
- Frontend `useClinicId()` hook provides current clinic context
- RBAC enforces role-based permissions within clinics

**Plan Enforcement:**

- Feature access checked via `checkFeatureAccess()` in backend
- Plan limits enforced on quotas (messages, appointments, storage)
- Frontend gates UI elements based on feature availability
- Subscriptions managed via Asaas payment gateway

**Audit Trail:**

- All write operations logged via `writeAudit()`
- Stored in `auditLogs` table
- Tracks action, user, timestamp, user-agent, metadata
- Viewable via AuditLogs component in UI

---

_Architecture analysis: 2026-02-04_
