# Coding Conventions

**Analysis Date:** 2026-02-04

## Naming Patterns

**Files:**

- Components: `PascalCase.tsx` (e.g., `AddPatientModal.tsx`, `AppointmentDetailsModal.tsx`)
- Hooks: `camelCase.ts` (e.g., `patients.ts`, `appointments.ts`)
- Utilities: `camelCase.ts` (e.g., `utils.ts`, `api.ts`, `auth-client.ts`)
- Backend modules: `camelCase.ts` (e.g., `appointments.ts`, `analytics.ts`)
- Tests: `*.test.ts` or `*.test.tsx` (e.g., `validation.test.ts`, `login.test.tsx`)

**Functions:**

- camelCase for all functions: `useClinicId()`, `formatCPF()`, `sanitizeString()`
- React hooks start with `use`: `usePatientsList()`, `useCreatePatient()`, `useUpdateAppointment()`
- Event handlers: `handleChange()`, `handleSave()`, `handleAddTag()`

**Variables:**

- camelCase: `formData`, `clinicId`, `patientEmail`, `isLoading`
- Booleans: `isOpen`, `isDoctor`, `hasEmail`, `canRun`
- State setters: `setFormData()`, `setLoading()`, `setSearchTerm()`

**Types:**

- PascalCase for interfaces and type aliases: `Patient`, `Clinic`, `Appointment`
- Generic types: `T`, `K` for generics
- Convex IDs: `v.id("tableName")`

## Code Style

**Formatting:**

- Tool: Prettier 3.7.4
- Configuration: `.prettierrc.json`
- Settings:
  - Semi-colons: `true`
  - Quotes: Double (`"`)
  - Trailing commas: `all`
  - Print width: `100`
  - Tab width: `2` (spaces)
  - End of line: `lf` (Unix)

**Linting:**

- Tool: ESLint 9.39.1
- Configuration: `eslint.config.js`
- Parser: TypeScript parser with JSX support
- Key rules:
  - `no-console`: `warn` (allows `console.warn`, `console.error`)
  - `@typescript-eslint/no-unused-vars`: `warn` (ignores `_` prefixed vars)
  - `react/react-in-jsx-scope`: `off` (React 17+ automatic)
  - `import/order`: Alphabetical within groups

**TypeScript:**

- Strict mode: `true`
- No unused locals/parameters: `true`
- No fallthrough cases: `true`
- Module resolution: `bundler`
- JSX transform: `react-jsx`

## Import Organization

**Order:**

1. External packages (npm dependencies)
2. Internal/monorepo packages (e.g., `@whatsmed-app/backend`)
3. Local imports (`@/` aliases)
4. Type imports (explicit `import type`)

**Path Aliases:**

- `@/*` → `apps/web/src/*` (configured in `apps/web/tsconfig.json`)
- `@whatsmed-app/backend` → `packages/backend`

**Example:**

```typescript
import * as router from "@tanstack/react-router";
import { MoreVertical } from "lucide-react";
import { useState, useEffect } from "react";

import { Button } from "@/components/ui/button";
import { useClinicId } from "@/hooks/patients";

import type { ColumnDef } from "@/components/ColumnVisibility";
```

## Error Handling

**Patterns:**

- Custom `ApiError` class in `packages/backend/convex/lib/errors.ts`
- Error codes as constants: `VALIDATION_ERROR`, `NOT_FOUND`, `FORBIDDEN`, `UNAUTHORIZED`, `CONFLICT`, `RATE_LIMITED`, `INTERNAL_ERROR`
- Helper functions: `badRequest()`, `notFound()`, `forbidden()`, `unauthorized()`, `conflict()`, `rateLimited()`, `internalError()`

**Example:**

```typescript
import { notFound, badRequest } from "./lib/errors";

// Validation error
if (!isValidDateRange(startAt, endAt)) {
  throw notFound("Horário de início deve ser anterior ao horário de término");
}

// Feature access error
const access = await checkFeatureAccess(ctx, clinicId, "appointments");
if (!access.allowed) {
  throw badRequest(`Recurso disponível a partir do plano ${access.requiredPlan}.`);
}
```

**Try-Catch Pattern:**

```typescript
try {
  await onSave(formData);
} catch (error) {
  console.error(error);
} finally {
  setLoading(false);
}
```

## Logging

**Framework:** `console` (warn and error only allowed by ESLint)

**Patterns:**

- Use `console.error()` for errors in catch blocks
- Use `console.warn()` for non-fatal issues (e.g., `[sendRescheduleConfirmation] Patient has no phone`)
- No `console.log()` in production code (ESLint warning)
- Timestamp/context prefixes in backend: `[updateAppointment]`, `[sendRescheduleConfirmation]`

## Comments

**When to Comment:**

- Complex timezone/date calculations (see Brazil timezone helpers in `packages/backend/convex/appointments.ts`)
- Non-obvious business logic (e.g., DST handling, validation edge cases)
- Idempotency notes
- Workarounds or known limitations

**JSDoc/TSDoc:**

- Used extensively in utility functions
- Format: JSDoc with parameter and return types
- Example:

```typescript
/**
 * Validates Brazilian CPF (Cadastro de Pessoas Físicas) using Luhn algorithm
 * @param cpf - CPF string (can include formatting or not)
 * @returns true if valid CPF, false otherwise
 */
export function isValidCPF(cpf: string): boolean {
  // ...
}
```

**TODO/FIXME:**

- Found in `packages/backend/convex/automationActions.ts`: `// TODO: Implement SMS, email, call channels`
- Portuguese comments for user-facing error messages
- English comments for code documentation

## Function Design

**Size:** No explicit size limit observed. Functions are typically 20-100 lines. Very long functions (>200 lines) exist in complex handlers (e.g., `appointments.ts` handlers).

**Parameters:**

- Destructured objects for multiple params: `{ clinicId, status, patientId, ... }`
- Optional params with `?` or `v.optional()` for Convex
- Default values: `maxLength: number = 1000`

**Return Values:**

- Async functions return `Promise<T>` or `Promise<void>`
- Query functions return objects with pagination: `{ items: T[], cursor: string, total: number }`
- Mutation functions return the created/updated document or void

**Example:**

```typescript
export const list = query({
  args: {
    clinicId: v.string(),
    status: v.optional(
      v.union(
        v.literal("pending"),
        v.literal("confirmed"),
        // ...
      ),
    ),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const { clinicId, status, limit = 50 } = args;
    // ...
    return {
      items: results,
      cursor: continueCursor,
      total: results.length,
    };
  },
});
```

## Module Design

**Exports:**

- Named exports preferred: `export function useClinicId()`, `export const list = query()`
- Default exports for components: `export function AddPatientModal() { ... }`
- Type exports: `export type Patient = { ... }`

**Barrel Files:**

- Components often export from `index.ts`: `export * from './AddPatientModal'`
- Hooks barrel: `export * from './patients'`

**Convex Module Pattern:**

```typescript
// Named exports for queries, mutations, actions
export const list = query({ ... });
export const create = mutation({ ... });
export const update = mutation({ ... });
export const softDelete = mutation({ ... });

// Internal functions (not exposed to client)
export const listInternal = internalQuery({ ... });
export const updateMeetingData = internalMutation({ ... });
export const createGoogleMeetEvent = internalAction({ ... });
```

---

_Convention analysis: 2026-02-04_
