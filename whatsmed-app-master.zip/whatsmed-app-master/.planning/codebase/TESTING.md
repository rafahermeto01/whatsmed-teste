# Testing Patterns

**Analysis Date:** 2026-02-04

## Test Framework

**Runner:**

- Vitest (version from package.json: latest)
- Config files:
  - `apps/web/vitest.config.ts` (frontend tests)
  - `packages/backend/vitest.config.ts` (backend tests)

**Assertion Library:**

- Vitest built-in `expect`
- `@testing-library/jest-dom` for DOM assertions

**Run Commands:**

```bash
bun test                # Run all tests via turbo
bun run test            # Run all tests
cd apps/web && bun test # Run web tests only
cd packages/backend && bun test # Run backend tests only
```

**Coverage:**

- Configured in `packages/backend/vitest.config.ts`
- Provider: `v8`
- Reporters: `text`, `json`, `html`
- Thresholds:
  - Lines: 70%
  - Functions: 70%
  - Branches: 60%
  - Statements: 70%

## Test File Organization

**Location:**

- Mixed approach - both co-located and separate directories
- Frontend: `apps/web/src/__tests__/` and `apps/web/src/tests/`
- Backend: `packages/backend/tests/`

**Naming:**

- Pattern: `*.test.ts` or `*.test.tsx`
- Examples:
  - `validation.test.ts` (backend)
  - `phoneUtils.test.ts` (backend)
  - `patients.test.tsx` (frontend)
  - `appointments.test.tsx` (frontend)

**Structure:**

```
apps/web/src/
├── __tests__/
│   ├── appointments.test.tsx
│   ├── doctor-assignment.test.tsx
│   └── patients.test.tsx
├── tests/
│   ├── auth.test.tsx
│   └── login.test.tsx
└── routes/
    └── appointments.tsx (component file)

packages/backend/
├── tests/
│   ├── setup.ts
│   ├── validation.test.ts
│   ├── phoneUtils.test.ts
│   └── smoke.test.ts
└── convex/
    └── lib/
        └── validators.ts (source file)
```

## Test Structure

**Suite Organization:**

```typescript
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";

describe("ComponentName", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("does something", () => {
    // Arrange
    render(<Component />);

    // Act
    // ...

    // Assert
    expect(screen.getByText("Content")).toBeInTheDocument();
  });

  describe("specific feature", () => {
    it("handles edge case", async () => {
      // ...
    });
  });
});
```

**Patterns:**

**Setup:**

- `beforeEach()` to clear mocks: `vi.clearAllMocks()`
- Mock resets before each test
- Global setup in `packages/backend/tests/setup.ts`

**Teardown:**

- Manual cleanup not typically needed (Vitest handles this)
- Test isolation by default

**Assertion:**

- Use `expect()` for standard assertions
- `expect().toBe()` for primitive equality
- `expect().toEqual()` for object deep equality
- `expect().toHaveBeenCalledWith()` for mock calls
- `expect().toHaveLength()` for array length
- `expect().toBeInTheDocument()` from jest-dom for DOM queries

## Mocking

**Framework:** Vitest (vi.mock, vi.fn, vi.spyOn)

**Patterns:**

**Module Mocking:**

```typescript
// Mock entire module
vi.mock("../lib/auth-client", () => ({
  authClient: {
    useSession: vi.fn(),
    signIn: {
      email: vi.fn(),
    },
  },
}));

// Mock React Query/Convex
vi.mock("convex/react", () => ({
  useQuery: vi.fn(),
  useMutation: vi.fn(),
  Authenticated: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  Unauthenticated: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));
```

**Partial Mock with Actual Import:**

```typescript
vi.mock("date-fns", async (importOriginal) => {
  const actual = await importOriginal<typeof import("date-fns")>();
  return {
    ...actual,
    isBefore: () => false, // Override specific function
  };
});
```

**Spy and Mock:**

```typescript
vi.spyOn(convexReact, "useQuery").mockImplementation((fn: any, args?: any) => {
  if (fn === api.patients.list) {
    return { items: [{ _id: "p1", name: "Maria" }] };
  }
  return undefined;
});
```

**Mock Functions:**

```typescript
const mockNavigate = vi.fn();
const mockCreateAppointment = vi.fn();

// In beforeEach
beforeEach(() => {
  vi.clearAllMocks();
  mockCreateAppointment.mockResolvedValue({});
});
```

**What to Mock:**

- External APIs (fetch, database calls)
- React Router (`useNavigate`, `useLocation`)
- Convex hooks (`useQuery`, `useMutation`)
- Third-party libraries that have side effects
- Date/time functions (`Date.now`, `new Date()`)

**What NOT to Mock:**

- Pure utility functions
- React components being tested
- Business logic in the same module

## Fixtures and Factories

**Test Data:**

```typescript
// Inline fixtures
const mockDoctors = [
  { _id: "user-1", name: "Dr. House", email: "house@clinic.com" },
  { _id: "user-2", name: "Dr. Wilson", email: "wilson@clinic.com" },
];

const mockAppointment = {
  _id: "apt-1",
  patientName: "John Doe",
  startAt: Date.now(),
  status: "pending",
  doctorId: "user-1",
  doctor: "Dr. House",
};
```

**Mock Return Values:**

```typescript
// Mock hook return values
(convexReact.useQuery as any).mockReturnValue({
  items: [{ _id: "p1", name: "Maria", phone: "123", status: "active" }],
  cursor: null,
  total: 1,
});

// Mock function behavior
mockCreateAppointment.mockResolvedValue({ _id: "apt-1" });
```

**Location:**

- Most fixtures are inline within test files
- No central fixture directory observed
- Some shared mock patterns in test files

## Coverage

**Requirements:** Enforced thresholds in `packages/backend/vitest.config.ts`:

- Lines: 70%
- Functions: 70%
- Branches: 60%
- Statements: 70%

**View Coverage:**

```bash
cd packages/backend
bun test --coverage
```

**Coverage Report:**

- Text output to console
- JSON and HTML reports generated
- Coverage excludes:
  - `node_modules/`
  - `**/_generated/**`
  - `**/*.test.ts`
  - `tests/`
  - `convex.config.ts`

## Test Types

**Unit Tests:**

- Utility functions (e.g., `isValidCPF`, `formatBrazilianPhone`)
- Small, focused tests
- No external dependencies
- Example: `packages/backend/tests/validation.test.ts`

**Integration Tests:**

- Component integration with mocked APIs
- Test user flows (e.g., login, patient creation)
- Test interaction between components
- Example: `apps/web/src/tests/auth.test.tsx`

**E2E Tests:**

- Not observed in this codebase
- Tests appear to be unit + integration only

## Common Patterns

**Async Testing:**

```typescript
it("redirects to dashboard when authenticated", async () => {
  (authClient.useSession as any).mockReturnValue({
    data: { user: { id: "1" } },
    isPending: false,
  });

  render(<LoginPage />);

  await waitFor(() => {
    expect(navigateMock).toHaveBeenCalledWith({ to: "/dashboard" });
  });
});
```

**Error Testing:**

```typescript
it("rejects invalid CPF numbers", () => {
  const invalidCPFs = [
    "111.111.111-11", // All same digits
    "123.456.789-00", // Invalid check digits
    "123.456.789", // Wrong length
  ];

  invalidCPFs.forEach((cpf) => {
    expect(isValidCPF(cpf)).toBe(false);
  });
});
```

**Event Testing:**

```typescript
it("opens create appointment modal", () => {
  render(<Component />);

  const createBtn = screen.getByText("Novo Agendamento");
  fireEvent.click(createBtn);

  expect(screen.getByRole("dialog")).toBeTruthy();
  expect(screen.getByText("Criar Novo Agendamento")).toBeInTheDocument();
});
```

**Mock Testing:**

```typescript
it("should call createAppointment with correct doctor", async () => {
  render(<CreateAppointmentModal open={true} onOpenChange={() => {}} />);

  // Fill required fields
  fireEvent.click(screen.getByText("Buscar paciente..."));
  fireEvent.click(screen.getByText("John Doe"));

  // Select doctor
  const doctorTrigger = screen.getByText("Selecione um médico");
  fireEvent.click(doctorTrigger);
  fireEvent.click(screen.getByText("Dr. House"));

  // Submit
  fireEvent.click(screen.getByText("Confirmar Agendamento"));

  await waitFor(() => {
    expect(mockCreateAppointment).toHaveBeenCalledWith(
      expect.objectContaining({
        doctorId: "user-1",
        doctor: "Dr. House",
      }),
    );
  });
});
```

**Loading State Testing:**

```typescript
it("renders loading state", () => {
  (convexReact.useQuery as any).mockImplementationOnce((fn: any) => {
    if (fn === api.auth.getCurrentUser) return { clinicId: undefined };
    return undefined;
  });

  render(<Component />);
  expect(screen.getByText("Carregando...")).toBeTruthy();
});
```

---

_Testing analysis: 2026-02-04_
