# External Integrations

**Analysis Date:** 2026-02-04

## APIs & External Services

**Communication & Messaging:**

- **Evolution API** - WhatsApp Business API integration
  - SDK/Client: Custom client in `packages/backend/convex/lib/evolution.ts`
  - Auth: `EVOLUTION_API_URL`, `EVOLUTION_API_KEY`
  - Purpose: WhatsApp messaging, QR code generation, media handling, webhook events
  - Implementation: `EvolutionClient` class with methods for instance management, sending messages, fetching contacts/media

**Calendar & Scheduling:**

- **Google Calendar API** - Google Calendar synchronization
  - SDK/Client: Custom OAuth implementation in `packages/backend/convex/googleCalendar.ts`
  - Auth: `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`
  - Purpose: Sync external calendar events, block appointment slots based on Google Calendar
  - OAuth flow: Implemented via TanStack Start route `apps/web/src/routes/api/oauth/google/callback.tsx`
  - Implementation: Token storage, sync operations, calendar settings management

**Payments:**

- **Asaas** - Brazilian payment gateway (PIX, boleto, credit card)
  - SDK/Client: Custom client in `packages/backend/convex/lib/asaas.ts`
  - Auth: `ASAAS_API_KEY`, `ASAAS_ENVIRONMENT` (sandbox/production)
  - Purpose: Customer management, subscription billing, one-time payments, card tokenization
  - Environments: Sandbox (https://api-sandbox.asaas.com/v3), Production (https://api.asaas.com/v3)
  - Webhooks: `ASAAS_WEBHOOK_SECRET`
  - Implementation: Functions for creating customers, subscriptions, payments, tokenizing cards

**Email:**

- **SMTP** - Email sending via Nodemailer
  - SDK/Client: nodemailer 6.9.15
  - Auth: `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM`, `SMTP_SECURE`
  - Purpose: Sending transactional emails (notifications, reminders)
  - Implementation: Used in backend functions for email dispatch

**AI & LLM Services:**

- **OpenAI** - GPT models for AI agents, document analysis, and audio transcription
  - SDK/Client: @ai-sdk/openai 0.0.47
  - Auth: `OPENAI_API_KEY`
  - Models: gpt-5-mini (main agent), gpt-4o-mini (reminders, vision), whisper-1 (audio)
  - Purpose: Conversational AI agents, document analysis, voice transcription
  - Implementation: Via Mastra framework in `packages/backend/mastra/`

- **Anthropic** - Claude models (available)
  - SDK/Client: @ai-sdk/anthropic 0.0.28
  - Purpose: Alternative LLM provider for AI agents
  - Implementation: Available via Mastra model router

- **Google AI** - Gemini models (available)
  - SDK/Client: @ai-sdk/google 0.0.37
  - Purpose: Alternative LLM provider for AI agents
  - Implementation: Available via Mastra model router

## Data Storage

**Databases:**

- **Convex Database** - Primary data store
  - Connection: `CONVEX_URL` (auto-managed by Convex CLI)
  - Client: Convex SDK
  - Purpose: Real-time database for all application data (users, clinics, appointments, patients, messages, etc.)
  - Schema: Defined in `packages/backend/convex/schema.ts`
  - Features: Real-time queries, automatic reactivity, ACID transactions

- **LibSQL** - Potential secondary database
  - Client: @libsql/client 0.5.0
  - Purpose: Not actively used in current implementation (likely future use case)

**File Storage:**

- **Convex File Storage** - Built-in file storage
  - Purpose: Storing uploaded documents, patient files, images
  - Implementation: Via Convex storage API
  - Features: Automatic CDN, file type handling

**Caching:**

- **None detected** - Direct real-time queries via Convex
  - React Query provides client-side caching

## Authentication & Identity

**Auth Provider:**

- **Better Auth** - Authentication framework
  - Implementation: @convex-dev/better-auth integration
  - Auth: `BETTER_AUTH_SECRET` (shared secret for session validation)
  - Purpose: Session management, user authentication, OAuth providers
  - Configuration: `packages/backend/convex/auth.config.ts`, `packages/backend/convex/auth.ts`
  - Session storage: Convex database
  - Features: Email/password authentication, social OAuth (via providers)

- **Custom Auth Helpers** - Client-side auth utilities
  - Implementation: `apps/web/src/lib/auth-client.ts`, `apps/web/src/lib/auth-server.ts`
  - Purpose: Auth state management, session handling, protected routes

## Monitoring & Observability

**Error Tracking:**

- **None detected** - No Sentry or similar error tracking service configured
  - Errors logged to console

**Logs:**

- **Console logging** - Standard output
  - Implementation: console.log() throughout codebase
  - Convex logs: Available via Convex dashboard
  - No centralized logging service configured

## CI/CD & Deployment

**Hosting:**

- **Vercel** - Frontend hosting
  - Config: `apps/web/vercel.json`, `apps/web/netlify.toml`
  - Build output: `.vercel/output/` directory
  - Features: SSR via Nitro, automatic deployments from git
  - Deployment: SPA rewrites configured (all routes to index.html)

- **Convex Cloud** - Backend hosting
  - Deployment: Convex CLI (`convex dev` / `convex deploy`)
  - Configuration: `packages/backend/convex/convex.config.ts`
  - Features: Serverless functions, real-time database, webhooks

**CI Pipeline:**

- **None detected** - No GitHub Actions, CircleCI, or similar configured
  - Git hooks via Husky for pre-commit linting
  - Manual deployments via Vercel/Convex CLI

## Environment Configuration

**Required env vars:**

**Application:**

- `SITE_URL` - Public application URL (for auth redirects, webhooks)
- `VITE_CONVEX_URL` - Convex deployment URL (client-side)
- `VITE_SITE_URL` - Fallback SITE_URL (client-side)
- `CONVEX_SITE_URL` - Application URL for Convex (server-side)

**Authentication:**

- `BETTER_AUTH_SECRET` - Secret key for Better Auth sessions

**Convex:**

- `CONVEX_DEPLOYMENT` - Convex deployment ID
- `CONVEX_URL` - Convex instance URL (auto-managed)

**WhatsApp (Evolution API):**

- `EVOLUTION_API_URL` - Evolution API instance URL
- `EVOLUTION_API_KEY` - Evolution API authentication key

**Payments (Asaas):**

- `ASAAS_API_KEY` - Asaas API key
- `ASAAS_ENVIRONMENT` - Environment: "sandbox" or "production"
- `ASAAS_WEBHOOK_SECRET` - Secret for validating Asaas webhooks

**Email:**

- `SMTP_HOST` - SMTP server hostname
- `SMTP_PORT` - SMTP port (default: 587)
- `SMTP_USER` - SMTP username
- `SMTP_PASS` - SMTP password
- `SMTP_FROM` - From email address
- `SMTP_SECURE` - Whether to use SSL/TLS

**Google Calendar:**

- `GOOGLE_CLIENT_ID` - OAuth 2.0 client ID
- `GOOGLE_CLIENT_SECRET` - OAuth 2.0 client secret

**AI (OpenAI):**

- `OPENAI_API_KEY` - OpenAI API key
- `OPENAI_WHISPER_MODEL` - Whisper model (default: whisper-1)

**Backend defaults:**

- `DEFAULT_CLINIC_ID` - Default clinic ID for new users (default: clinic-demo)

**Secrets location:**

- Local: `.env.local` (gitignored)
- Environment-specific: Managed via platform (Vercel environment variables, Convex secrets)
- Example: `packages/backend/.env.example`, `apps/web/.env.example`

## Webhooks & Callbacks

**Incoming:**

- **Evolution API** - WhatsApp webhook events
  - Events: MESSAGES_UPSERT, MESSAGES_UPDATE, MESSAGES_DELETE, SEND_MESSAGE, CONNECTION_UPDATE, CHATS_UPSERT, CHATS_UPDATE, QRCODE_UPDATED
  - Handler: Convex HTTP actions in `packages/backend/convex/http.ts`
  - Purpose: Receive real-time WhatsApp messages, connection status updates

- **Asaas** - Payment webhook events
  - Events: Payment confirmations, subscription status changes
  - Handler: Convex HTTP actions
  - Secret validation: `ASAAS_WEBHOOK_SECRET`
  - Purpose: Sync payment status, handle subscription renewals/cancellations

**Outgoing:**

- **None detected** - Application initiates API calls but doesn't expose webhook endpoints for external consumption (except auth callbacks)

**Auth Callbacks:**

- **Google OAuth Callback** - `apps/web/src/routes/api/oauth/google/callback.tsx`
  - Purpose: Handle OAuth 2.0 callback from Google Calendar integration
  - Flow: Exchange authorization code for tokens, store tokens in Convex database

---

_Integration audit: 2026-02-04_
