# Technology Stack

**Analysis Date:** 2026-02-04

## Languages

**Primary:**

- TypeScript 5.7.2 - All application code (frontend and backend)
  - Target: ES2022
  - JSX: react-jsx

**Secondary:**

- JavaScript - Configuration files and build tooling

## Runtime

**Environment:**

- Bun 1.3.3 - Package manager and runtime
  - Lockfile: `bun.lock` (present)
  - Linker: isolated

**Package Manager:**

- Bun 1.3.3 - Primary package manager
  - Workspaces: monorepo structure with apps/_ and packages/_

## Frameworks

**Core:**

- React 19.1.2 - UI framework
  - React DOM 19.1.2
- TanStack Start 1.132.31 - Full-stack React framework (server components, routing, SSR)
- Convex 1.29.3 - Serverless backend platform (functions + real-time database)

**Testing:**

- Vitest 4.0.15 - Unit and integration testing
- Testing Library 16.2.0 - Component testing
  - @testing-library/react
  - @testing-library/jest-dom
  - @testing-library/dom
- jsdom 27.3.0 - DOM environment for tests
- convex-test - Convex testing utilities

**Build/Dev:**

- Vite 7.0.2 - Build tool and dev server
- Turbo 2.5.4 - Monorepo build system
- Nitro 3.0.1-alpha.1 - Server runtime (via @tanstack/nitro-v2-vite-plugin)
- @vitejs/plugin-react 5.0.4 - React plugin for Vite

## Key Dependencies

**Critical:**

- @convex-dev/better-auth 0.9.7 - Authentication provider integrated with Convex
- better-auth 1.3.34 - Authentication framework
- @mastra/core 0.24.9 - AI agent orchestration framework
- ai 6.0.6 - AI SDK for LLM integration

**Infrastructure:**

- convex - Core Convex SDK for backend functions and database
- @libsql/client 0.5.0 - LibSQL client (potential database integration)

**Frontend State & Data:**

- @tanstack/react-query 5.80.6 - Server state management
- @tanstack/react-router 1.132.31 - File-based routing
- @tanstack/react-form 1.23.5 - Form state management
- @hookform/resolvers 5.2.2 - Form validation resolvers
- react-hook-form 7.70.0 - Form library

**UI Components:**

- @radix-ui/react-\* - Headless UI component library
  - avatar, dialog, label, popover, progress, radio-group, scroll-area, select, separator, slider, slot, switch, tabs, tooltip
- lucide-react 0.525.0 - Icon library
- recharts 3.5.1 - Charting library

**Styling:**

- tailwindcss 4.1.3 - Utility-first CSS
- @tailwindcss/vite 4.1.8 - Tailwind Vite plugin
- clsx 2.1.1 - Conditional className utility
- tailwind-merge 3.3.1 - Tailwind class merging
- class-variance-authority 0.7.1 - Component variant management
- tw-animate-css 1.2.5 - Tailwind animations

**Validation:**

- zod 4.1.13 (web), zod 3.23.8 (backend) - Schema validation

**Date & Time:**

- date-fns 4.1.0 - Date manipulation
- react-day-picker 9.12.0 - Calendar component

**Drag & Drop:**

- @dnd-kit/core 6.3.1 - Drag and drop system
- @dnd-kit/sortable 10.0.0 - Sortable utilities
- @dnd-kit/utilities 3.2.2 - DnD utilities

**AI SDKs:**

- @ai-sdk/anthropic 0.0.28 - Anthropic Claude integration
- @ai-sdk/google 0.0.37 - Google AI integration
- @ai-sdk/openai 0.0.47 - OpenAI integration

**Specialized Features:**

- @zxing/library 0.21.3 - QR code scanning
- @zxing/browser 0.1.5 - Browser barcode scanning
- qrcode.react 4.2.0 - QR code generation
- react-phone-number-input 3.4.14 - Phone input component
- signature_pad 5.1.3 - Digital signature capture
- sonner 2.0.3 - Toast notifications
- cmdk 1.1.1 - Command palette
- next-themes 0.4.6 - Theme management

**Backend-specific:**

- jsonwebtoken 9.0.2 - JWT token handling
- nodemailer 6.9.15 - Email sending
- @zxcvbn-ts/core 3.0.4 - Password strength
- @zxcvbn-ts/language-en 3.0.2 - English dictionary
- @zxcvbn-ts/language-pt-br 3.0.2 - Portuguese-Brazil dictionary

## Configuration

**Environment:**

- Vite environment variables
  - Client-side vars: `VITE_*` prefix
  - Server-side vars: No prefix (TanStack Start Nitro)
- turbo.json - Turborepo configuration
- .env.local - Environment secrets (gitignored)
- .prettierrc.json - Code formatting rules

**Build:**

- vite.config.ts - Vite configuration
- Nitro preset: vercel (for deployment)
- TypeScript strict mode enabled
- Module resolution: bundler mode
- Path aliases: `@/*` → `apps/web/src/*`

**Linting/Formatting:**

- eslint.config.js - ESLint configuration (ESLint 9.39.1)
- Prettier 3.7.4 with specific rules:
  - Semi: true
  - Single quotes: false (double quotes)
  - Trailing commas: all
  - Print width: 100
  - Tab width: 2

**Git Hooks:**

- Husky 9.1.7 - Git hooks
- lint-staged 16.2.7 - Pre-commit linting

## Platform Requirements

**Development:**

- Node.js compatible runtime (Bun 1.3.3 recommended)
- Convex CLI for backend development
- TypeScript 5.7.2
- Modern browser (React 19 features)

**Production:**

- Vercel - Primary deployment target
  - Configured via `vercel.json` and `netlify.toml`
  - SSR support via Nitro
- Convex cloud - Backend hosting (functions + database)

---

_Stack analysis: 2026-02-04_
