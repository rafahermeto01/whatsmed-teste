# Requirements: WhatsMed AI Flow Builder

**Defined:** 2026-02-04
**Core Value:** Clinics can efficiently communicate with patients via WhatsApp and automate patient interactions while maintaining professional service quality.

## v1 Requirements

Requirements for AI Flow Builder milestone. Each maps to roadmap phases.

### Flow Builder UI

- [ ] **FBUI-01**: Clinic admin can create flows using visual drag-and-drop canvas
- [ ] **FBUI-02**: Clinic admin can add node types to flow (Message, Condition, Input, Wait)
- [ ] **FBUI-03**: Clinic admin can connect nodes to create flow logic
- [ ] **FBUI-04**: Clinic admin can configure node properties (message text, conditions, wait duration, input prompts)
- [ ] **FBUI-05**: Clinic admin can navigate canvas with zoom and pan
- [ ] **FBUI-06**: Clinic admin sees validation errors when flow is incomplete or broken
- [ ] **FBUI-07**: Clinic admin can delete nodes and connections

### Flow Management

- [ ] **FMAN-01**: Clinic admin can create new flow with name and description
- [ ] **FMAN-02**: Clinic admin can edit existing flows
- [ ] **FMAN-03**: Clinic admin can delete flows
- [ ] **FMAN-04**: Clinic admin can list all flows in their clinic
- [x] **FMAN-05**: Clinic admin can activate a flow to make it available for conversations
- [x] **FMAN-06**: Clinic admin can deactivate a flow to stop it from being used
- [ ] **FMAN-07**: Clinic admin can define variables in flows (e.g., patient name, appointment date)
- [ ] **FMAN-08**: Flow can reference variables in message text with substitution syntax (e.g., {{patient.name}})
- [ ] **FMAN-09**: Clinic admin can see which flows are currently active

### Flow Execution

- [x] **FEXEC-01**: System executes flow using state machine pattern (not rigid step-by-step)
- [x] **FEXEC-02**: System follows node connections and handles branching logic (Condition nodes)
- [x] **FEXEC-03**: System waits for specified duration in Wait nodes
- [x] **FEXEC-04**: System collects user input in Input nodes
- [x] **FEXEC-05**: System persists flow execution state in database after each step
- [x] **FEXEC-06**: System can resume flow execution from saved state
- [x] **FEXEC-07**: System handles execution errors with retry logic or fallback
- [x] **FEXEC-08**: AI manages flow execution by following flow structure but deviating to answer patient questions
- [x] **FEXEC-09**: System provides escape hatches for patients to request help or cancel flow
- [x] **FEXEC-10**: System enforces multi-tenant isolation (clinic cannot access other clinics' flows)

### AI Integration

- [x] **AIINT-01**: System injects flow structure into WhatsApp AI system prompt as instructions
- [x] **AIINT-02**: System pins system prompt and flow instructions to prevent context window overflow
- [x] **AIINT-03**: System triggers flow when patient sends message to clinic's WhatsApp
- [x] **AIINT-04**: System can execute existing AI tools within flow context (appointment booking, patient lookup, etc.)
- [x] **AIINT-05**: System supports multiple flow activation strategies (per conversation, clinic-wide default)
- [x] **AIINT-06**: System integrates flow execution results back into WhatsApp conversation

### Testing & Debugging

- [ ] **TEST-01**: Clinic admin can manually test flow by simulating patient conversation
- [ ] **TEST-02**: System shows flow progress and variable values during manual testing
- [ ] **TEST-03**: System logs all flow executions with timestamp, flow version, patient, and result
- [ ] **TEST-04**: Clinic admin can view execution history for a flow
- [ ] **TEST-05**: System logs errors and exceptions from flow execution

### Versioning & Data Integrity

- [ ] **VERS-01**: System tracks flow versions when flows are updated
- [ ] **VERS-02**: Active flow executions are pinned to the flow version they started with
- [ ] **VERS-03**: Only new conversations use the latest active flow version
- [ ] **VERS-04**: System prevents breaking changes from affecting in-flight executions

### Security & Compliance

- [ ] **SEC-01**: All flow data is scoped to clinic (multi-tenant isolation)
- [ ] **SEC-02**: Only users with admin/staff role can create and edit flows
- [ ] **SEC-03**: Only users with admin role can activate and deactivate flows
- [ ] **SEC-04**: System logs all flow CRUD operations for audit trail
- [ ] **SEC-05**: System logs all flow executions for compliance tracking
- [ ] **SEC-06**: Variable substitution sanitizes patient data to prevent injection attacks

## v2 Requirements

Deferred to future release. Tracked but not in current roadmap.

### Healthcare Nodes

- **HNODE-01**: Symptom checker node for triage
- **HNODE-02**: Appointment scheduling node
- **HNODE-03**: Prescription management node
- **HNODE-04**: Clinical handoff node with context summary

### Advanced Flow Features

- **ADV-01**: Natural language flow templates ("Prompt-to-Flow")
- **ADV-02**: Campaign flow mode with scheduled triggers
- **ADV-03**: WhatsApp Flows integration (native in-chat forms)
- **ADV-04**: Subflows for reusable logic
- **ADV-05**: Flow analytics dashboard with engagement metrics

### Advanced Testing

- **TEST-P2-01**: AI Persona testing (agent-to-agent simulation)
- **TEST-P2-02**: Real-time step-through debugging
- **TEST-P2-03**: Flow performance analytics and optimization suggestions

## Out of Scope

| Feature                             | Reason                                                     |
| ----------------------------------- | ---------------------------------------------------------- |
| Video/telemedicine integration      | Not in scope for flow builder milestone                    |
| Prescription management             | Defer to healthcare nodes in v2                            |
| Real-time video consultations       | Not related to WhatsApp flow automation                    |
| Mobile applications                 | Web-only for this milestone                                |
| Natural language flow generation    | Defer to v2 advanced features                              |
| Flow versioning UI (rollback, diff) | Basic versioning in v1, UI in v2                           |
| Complex branching with loops        | Basic conditional branching in v1, advanced patterns in v2 |
| WhatsApp Flows (native forms)       | Defer to v2 after provider compatibility verified          |

## Traceability

Which phases cover which requirements. Updated during roadmap creation.

| Requirement | Phase   | Status   |
| ----------- | ------- | -------- |
| VERS-01     | Phase 1 | Pending  |
| VERS-02     | Phase 1 | Pending  |
| VERS-03     | Phase 1 | Pending  |
| VERS-04     | Phase 1 | Pending  |
| SEC-01      | Phase 1 | Pending  |
| SEC-02      | Phase 1 | Pending  |
| SEC-03      | Phase 1 | Pending  |
| SEC-04      | Phase 1 | Pending  |
| SEC-05      | Phase 1 | Pending  |
| SEC-06      | Phase 1 | Pending  |
| FMAN-01     | Phase 1 | Pending  |
| FMAN-09     | Phase 1 | Pending  |
| FMAN-02     | Phase 1 | Pending  |
| FMAN-03     | Phase 1 | Pending  |
| FMAN-04     | Phase 1 | Pending  |
| FBUI-01     | Phase 2 | Pending  |
| FBUI-02     | Phase 2 | Pending  |
| FBUI-03     | Phase 2 | Pending  |
| FBUI-04     | Phase 2 | Pending  |
| FBUI-05     | Phase 2 | Pending  |
| FBUI-06     | Phase 2 | Pending  |
| FBUI-07     | Phase 2 | Pending  |
| FMAN-07     | Phase 2 | Pending  |
| FMAN-08     | Phase 2 | Pending  |
| FEXEC-01    | Phase 3 | Complete |
| FEXEC-02    | Phase 3 | Complete |
| FEXEC-03    | Phase 3 | Complete |
| FEXEC-04    | Phase 3 | Complete |
| FEXEC-05    | Phase 3 | Complete |
| FEXEC-06    | Phase 3 | Complete |
| FEXEC-07    | Phase 3 | Complete |
| FEXEC-08    | Phase 3 | Complete |
| FEXEC-09    | Phase 3 | Complete |
| FEXEC-10    | Phase 3 | Complete |
| AIINT-01    | Phase 3 | Complete |
| AIINT-02    | Phase 3 | Complete |
| AIINT-03    | Phase 3 | Complete |
| AIINT-04    | Phase 4 | Complete |
| AIINT-05    | Phase 4 | Complete |
| AIINT-06    | Phase 4 | Complete |
| TEST-01     | Phase 5 | Pending  |
| TEST-02     | Phase 5 | Pending  |
| TEST-03     | Phase 5 | Pending  |
| TEST-04     | Phase 5 | Pending  |
| TEST-05     | Phase 5 | Pending  |

**Coverage:**

- v1 requirements: 47 total
- Mapped to phases: 47
- Unmapped: 0 ✓

---

_Requirements defined: 2026-02-04_
_Last updated: 2026-02-05 after Phase 4 completion_
