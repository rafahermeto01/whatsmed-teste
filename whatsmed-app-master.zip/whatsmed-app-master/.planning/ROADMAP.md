# WhatsMed Roadmap: v1.0 AI Flow Builder

**Milestone:** v1.0
**Depth:** Standard (balanced approach)
**Start Date:** 2026-02-04
**Status:** Planning

## Overview

Create a visual drag-and-drop flow builder that enables clinic admins to create proactive AI-driven conversation flows for WhatsApp. The roadmap follows a data-first approach, establishing secure storage foundation before building the UI, execution engine, and AI integration. Each phase delivers a complete, verifiable capability while avoiding horizontal layer anti-patterns.

## Phases

### Phase 1: Flow Data Model & Storage

**Goal:** System securely stores and manages flow definitions with multi-tenant isolation and version tracking.

**Dependencies:** None (foundation phase)

**Requirements:**

- VERS-01, VERS-02, VERS-03, VERS-04 (Versioning & Data Integrity)
- SEC-01, SEC-02, SEC-03, SEC-04, SEC-05, SEC-06 (Security & Compliance)
- FMAN-01, FMAN-02, FMAN-03, FMAN-04 (Flow Management basics)
- FMAN-09 (Active flow visibility)

**Success Criteria:**

1. Clinic admin can create, edit, delete, and list flows scoped to their clinic
2. System tracks flow versions and pins active executions to their starting version
3. Only users with admin/staff role can create/edit flows; only admin can activate/deactivate
4. All flow CRUD operations are logged for audit trail compliance
5. Variable substitution sanitizes patient data to prevent injection attacks

**Anti-Pitfalls Avoided:**

- ✅ Cross-tenant flow access (SEC-01 enforces tenant scoping from day one)
- ✅ Flow version mismatch (VERS-02 implements sticky versioning)

**Status:** Complete

**Plans:** 7 plans in 4 waves

**Wave 1 (Foundation):**

- [x] 01-01-PLAN.md — Define Convex data model for flows, versions, and executions

**Wave 2 (Backend Functions):**

- [x] 01-02-PLAN.md — Implement flow CRUD operations with multi-tenant isolation
- [x] 01-03-PLAN.md — Implement version management with immutable design

**Wave 3 (Security & Compliance):**

- [x] 01-04-PLAN.md — Add Convex access control rules for defense-in-depth
- [x] 01-05-PLAN.md — Implement audit logging for compliance
- [x] 01-06-PLAN.md — Implement variable sanitization to prevent injection attacks

**Wave 4 (API Layer):**

- [x] 01-07-PLAN.md — Create HTTP API endpoints for flow management

---

### Phase 2: Flow Builder UI

**Goal:** Clinic admin can visually create and configure flows using drag-and-drop interface.

**Dependencies:** Phase1 (requires flow storage)

**Requirements:**

- FBUI-01, FBUI-02, FBUI-03, FBUI-04, FBUI-05, FBUI-06, FBUI-07 (Flow Builder UI)
- FMAN-07, FMAN-08 (Variables and substitution)

**Success Criteria:**

1. Clinic admin can create flows by dragging node types (Message, Condition, Input, Wait) onto canvas
2. Clinic admin can connect nodes to create flow logic and configure node properties
3. Clinic admin can define variables in flows and reference them in message text with {{variable}} syntax
4. Clinic admin sees validation errors when flow is incomplete or broken
5. Clinic admin can navigate canvas with zoom/pan and delete nodes/connections

**Status:** Complete

**Plans:** 12 plans in 7 waves

**Wave 1 (Foundation):**

- [x] 02-01-PLAN.md — Install @xyflow/react and create route structure

**Wave 2 (Backend Functions):**

- [x] 02-02-PLAN.md — Create FlowCanvas component with basic React Flow setup
- [x] 02-03-PLAN.md — Create NodePalette with drag-and-drop node types

**Wave 3 (Node Types - Part 1):**

- [x] 02-04-PLAN.md — Create MessageNode component (with variable support for FMAN-08)
- [x] 02-05-PLAN.md — Create ConditionNode component

**Wave 3 (Node Types - Part 2):**

- [x] 02-06-PLAN.md — Create InputNode component
- [x] 02-11-PLAN.md — Create WaitNode component

**Wave 4 (Connections):**

- [x] 02-07-PLAN.md — Implement node connections with bezier curves and 'x' button removal

**Wave 5 (Canvas Controls, Validation & Configuration):**

- [x] 02-08-PLAN.md — Implement zoom/pan, delete, and flow validation with inline errors
- [x] 02-12-PLAN.md — Create NodePropertiesPanel with tabbed interface and integrate with canvas

**Wave 6 (Flow Settings & Convex Integration):**

- [x] 02-09-PLAN.md — Create FlowSettingsPanel and integrate with Convex backend

**Wave 7 (Integration & Verification):**

- [x] 02-10-PLAN.md — Complete integration and user verification checkpoint

**Implementation Notes:**

- Uses @xyflow/react (React Flow) for drag-and-drop canvas
- Integrates with Convex for real-time flow storage
- Builds on Radix UI components from existing codebase

---

### Phase 3: Flow Execution Engine

**Goal:** Flows serve as guidance documents loaded into AI context during patient conversations. The system manages loading flows into AI context at conversation start, handling message flow through Mastra, and providing escape mechanisms for patients to request help or exit conversations.

**Dependencies:** Phase 1 (storage), Phase 2 (flow definitions)

**Requirements:**

- FEXEC-01, FEXEC-02, FEXEC-03, FEXEC-04, FEXEC-05, FEXEC-06, FEXEC-07, FEXEC-08, FEXEC-09, FEXEC-10 (Flow Execution)
- FMAN-05, FMAN-06 (Flow activation)
- AIINT-01, AIINT-02, AIINT-03 (AI Integration basics - injection, pinning, triggering)

**Note:** FEXEC-06 (state progression) and FEXEC-07 (error handling) are covered by AI-driven state inference as per CONTEXT.md decision "Flows are NOT executed as state machines".

**Success Criteria:**

1. Flows are loaded as guidance documents into AI context at conversation start
2. Flow structure is formatted for LLM consumption using Markdown+JSON
3. AI has full autonomy to deviate from flow structure when needed
4. System tracks chat activity with timeout monitoring
5. System sends proactive nudges before marking conversations as abandoned
6. System provides escape mechanisms through escalation and timeout detection

**Anti-Pitfalls Avoided:**

- ✅ Happy path trap (AI has autonomy to deviate from flow)
- ✅ State machine execution (flows are guidance, not strict scripts)

**Status:** Complete

**Plans:** 5 plans in 4 waves

**Wave 1 (Foundation):**

- [x] 03-01-PLAN.md — Create flow loading and context formatting infrastructure

**Wave 2 (Context Injection):**

- [x] 03-02-PLAN.md — Integrate flow context injection into Mastra AI agent

**Wave 3 (Timeout & Escalation):**

- [x] 03-03A-PLAN.md — Implement conversation timeout monitoring with nudge escalation
- [x] 03-03B-PLAN.md — Implement patient help request detection and escalation

**Wave 4 (Flow Activation):**

- [x] 03-04-PLAN.md — Implement flow activation and clinic-wide default flow setting

---

### Phase 4: AI Integration

**Goal:** Flow execution integrates with WhatsApp AI system by injecting flow structure into agent prompts.

**Dependencies:** Phase 3 (execution engine)

**Requirements:**

- AIINT-04, AIINT-05, AIINT-06 (AI Integration - advanced features)

**Note:** AIINT-01 (flow injection), AIINT-02 (context pinning), AIINT-03 (flow triggering) are covered in Phase 3.

**Success Criteria:**

1. System triggers flow when patient sends message to clinic's WhatsApp
2. System injects flow structure into WhatsApp AI system prompt as instructions
3. System pins system prompt and flow instructions to prevent context window overflow
4. System can execute existing AI tools within flow context (appointment booking, patient lookup)
5. System integrates flow execution results back into WhatsApp conversation
6. System supports multiple flow activation strategies (per conversation, clinic-wide default)

**Anti-Pitfalls Avoided:**

- ✅ AI context window overflow (AIINT-02 implements pinned system prompts)
- ✅ AI Integration verified with 6 end-to-end test scenarios (AIINT-04, AIINT-05, AIINT-06)
- ✅ Role-based access control enforced for default flow management (SEC-02, SEC-03)

**Research Flags:**

- ✅ Mastra agent runtime system prompt modification capabilities - VERIFIED: Flow instructions successfully injected via createClinicAgent with systemPromptOverride

**Status:** Complete

**Plans:** 4 plans in 2 waves

**Wave 1 (Core Integration):**

- [x] 04-01-PLAN.md — Flow context injection into AI system prompt
- [x] 04-02-PLAN.md — Default flow selector UI

**Wave 2 (Tool Integration & Verification):**

- [x] 04-03-PLAN.md — Tool execution within flow context
- [x] 04-04-PLAN.md — Integration verification with user checkpoint (all tests passed)

---

### Phase 5: Testing & Debugging

**Goal:** Clinic admin can test and monitor flows to ensure reliability and debug issues.

**Dependencies:** Phase 3 (execution engine), Phase 4 (AI integration)

**Requirements:**

- TEST-01, TEST-02, TEST-03, TEST-04, TEST-05 (Testing & Debugging)

**Success Criteria:**

1. Clinic admin can manually test flow by simulating patient conversation
2. System shows flow progress and variable values during manual testing
3. System logs all flow executions with timestamp, flow version, patient, and result
4. Clinic admin can view execution history for a flow
5. System logs errors and exceptions from flow execution

**Implementation Notes:**

- Uses Convex real-time subscriptions for live testing updates
- Real AI responses during testing (not mocks) for accurate validation
- WhatsApp-style chat interface for realistic simulation
- Full debugging controls: play/pause/reset/step through

**Status:** Ready for Execution

**Plans:** 6 plans in 5 waves

**Wave 1 (Execution Logging Foundation):**

- [ ] 05-01-PLAN.md — Create execution logging schema and Convex functions

**Wave 2 (Manual Testing UI - Part 1):**

- [ ] 05-02-PLAN.md — Create manual testing page with WhatsApp-style chat interface

**Wave 3 (Variable Inspector):**

- [ ] 05-03-PLAN.md — Create variable inspector panel for real-time editing

**Wave 4 (AI Integration):**

- [ ] 05-04-PLAN.md — Integrate real AI service into testing with flow context

**Wave 5 (Controls & History):**

- [ ] 05-05-PLAN.md — Add testing controls (play/pause/step/reset) with verification
- [ ] 05-06-PLAN.md — Create execution history viewer page

**Anti-Pitfalls Avoided:**

- ✅ Mock AI responses (using real AI for accurate testing)
- ✅ Missing execution tracking (all runs logged with full context)
- ✅ No debugging controls (play/pause/step/reset for node-by-node inspection)

---

## Progress

| Phase | Name                      | Status          | Requirements | Success Criteria |
| ----- | ------------------------- | --------------- | ------------ | ---------------- |
| 1     | Flow Data Model & Storage | Complete        | 19           | 5                |
| 2     | Flow Builder UI           | Complete        | 9            | 5                |
| 3     | Flow Execution Engine     | Complete        | 12           | 6                |
| 4     | AI Integration            | Complete        | 6            | 6                |
| 5     | Testing & Debugging       | Ready (6 plans) | 5            | 5                |

**Total Requirements:** 47
**Requirements Mapped:** 47 (100%)
**Success Criteria:** 27

## Phase Dependencies

```
Phase 1: Flow Data Model & Storage
    ↓
Phase 2: Flow Builder UI ← requires storage for flow definitions
    ↓
Phase 3: Flow Execution Engine ← requires storage and flow definitions
    ↓
Phase 4: AI Integration ← requires execution engine
    ↓
Phase 5: Testing & Debugging ← requires execution engine and AI integration
```

## Key Design Decisions

| Decision                   | Rationale                                                                                                |
| -------------------------- | -------------------------------------------------------------------------------------------------------- |
| Data model first (Phase 1) | Multi-tenant isolation and version tracking must be foundational to avoid security and versioning issues |
| State machine execution    | Allows flexible, resumable flows with error handling (vs rigid step-by-step)                             |
| AI manages execution       | Enables natural dialogue while following flow structure (avoids conversational robots)                   |
| Sticky versioning          | Active sessions pinned to flow version at start prevents breaking changes during updates                 |
| Pinned system prompts      | Prevents context window overflow from causing flow ejection                                              |
| Vertical slices            | Each phase delivers a complete capability (data → UI → execution → AI → testing)                         |

## Risk Mitigation

| Risk                                           | Mitigation Strategy                                                 | Phase |
| ---------------------------------------------- | ------------------------------------------------------------------- | ----- |
| Cross-tenant data access                       | Enforce `WHERE clinicId = ?` on ALL database queries from day one   | 1     |
| Flow version mismatch breaking active sessions | Pin sessions to flow version at start; only new sessions use latest | 1     |
| AI context window overflow                     | Pin system prompt and flow instructions; monitor token usage        | 4     |
| Happy path trap (patients getting stuck)       | Implement escape hatches and AI flexibility for deviating from flow | 3     |
| Mastra ↔ React Flow conversion complexity      | Design adapter layer during Phase 3 planning                        | 3     |

---

_Roadmap created: 2026-02-04_
_Updated: 2026-02-05 (Phase 5 planning complete - 6 plans ready)_
