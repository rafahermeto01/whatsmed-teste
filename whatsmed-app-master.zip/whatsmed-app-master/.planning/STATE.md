# WhatsMed Project State

**Milestone:** v1.0 AI Flow Builder
**Last Updated:** 2026-02-05 (Phase 4 Plan 03 complete - Tool execution within flow context)

---

## Project Reference

### Core Value

Clinics can efficiently communicate with patients via WhatsApp and automate patient interactions while maintaining professional service quality.

### Current Focus

Building a visual drag-and-drop flow builder that enables clinic admins to create proactive AI-driven conversation flows for WhatsApp. Flows guide conversations while allowing AI to answer questions that arise, balancing structure with conversational flexibility.

---

## Current Position

### Phase

**Current Phase:** Phase 4 (AI Integration) - **COMPLETE**
**Status:** Complete (4 of 4 plans)
**Last activity:** 2026-02-05 - Completed 04-04 Integration Verification (all tests passed)

### Plan

**Phase 2: Flow Builder UI** (COMPLETE — pending verification)
Implements drag-and-drop interface for creating flows with nodes, connections, and configuration panels.

**Goal:** Clinic admin can visually create and configure flows using drag-and-drop interface.
**Requirements:** 9 (FBUI-01 to FBUI-07, FMAN-07, FMAN-08)
**Success Criteria:** 5
**Plans:** 12 of 12 complete

**Phase 1: Flow Data Model & Storage** (COMPLETE)
Implements secure storage foundation for flows with multi-tenant isolation, version tracking, and audit logging.
**Requirements:** 19
**Success Criteria:** 5
**Plans:** 7 of 7 complete

**Phase 3: Flow Execution Engine** (COMPLETE — 5/5 plans complete, verified)
Implements flow loading, context formatting, timeout monitoring, and help request detection for AI-driven conversation guidance.
**Requirements:** 12 (FEXEC-01 to FEXEC-10, FMAN-05, FMAN-06)
**Success Criteria:** 6
**Plans:** 5 of 5 complete

### Progress Bar

```
Phase 1: Flow Data Model & Storage      [████████] 100% (7/7 plans)
Phase 2: Flow Builder UI                [████████] 100% (12/12 plans)
Phase 3: Flow Execution Engine          [████████] 100% (5/5 plans)
Phase 4: AI Integration                 [████████] 100% (4/4 plans)
Phase 5: Testing & Debugging            [░░░░░░░░] 0%

Overall Progress: [████████████████] 100% (28/31 plans)
```

Phase 1: Flow Data Model & Storage [████████] 100% (7/7 plans)
Phase 2: Flow Builder UI [████████░░░] 75% (9/12 plans)
Phase 3: Flow Execution Engine [░░░░░░░░] 0%
Phase 4: AI Integration [░░░░░░░░] 0%
Phase 5: Testing & Debugging [░░░░░░░░] 0%

Overall Progress: [████████░░░] 52% (16/31 plans)

```

Phase 1: Flow Data Model & Storage [████████] 100% (7/7 plans)
Phase 2: Flow Builder UI [█░░░░░░░] 8% (1/12 plans)
Phase 3: Flow Execution Engine [░░░░░░░░] 0%
Phase 4: AI Integration [░░░░░░░░] 0%
Phase 5: Testing & Debugging [░░░░░░░░] 0%

Overall Progress: [███░░░░░░░░] 26% (8/31 plans)

```

Phase 1: Flow Data Model & Storage [██████░░░] 86% (6/7 plans)
Phase 2: Flow Builder UI [░░░░░░░░] 0%
Phase 3: Flow Execution Engine [░░░░░░░░] 0%
Phase 4: AI Integration [░░░░░░░░] 0%
Phase 5: Testing & Debugging [░░░░░░░░] 0%

Overall Progress: [██░░░░░░░] 19% (5/31 plans)

```

Phase 1: Flow Data Model & Storage [████░░░░░] 57% (4/7 plans)
Phase 2: Flow Builder UI [░░░░░░░░░] 0%
Phase 3: Flow Execution Engine [░░░░░░░░░] 0%
Phase 4: AI Integration [░░░░░░░░░] 0%
Phase 5: Testing & Debugging [░░░░░░░░░] 0%

Overall Progress: [██░░░░░░░░] 13% (4/31 plans)

```

Phase 1: Flow Data Model & Storage [████░░░░░] 57% (4/7 plans)
Phase 2: Flow Builder UI [░░░░░░░░░] 0%
Phase 3: Flow Execution Engine [░░░░░░░░░] 0%
Phase 4: AI Integration [░░░░░░░░░] 0%
Phase 5: Testing & Debugging [░░░░░░░░░] 0%

Overall Progress: [██░░░░░░░] 13% (4/31 plans)

```

Phase 1: Flow Data Model & Storage [██░░░░░░░░] 14% (1/7 plans)
Phase 2: Flow Builder UI [░░░░░░░░░░] 0%
Phase 3: Flow Execution Engine [░░░░░░░░░░] 0%
Phase 4: AI Integration [░░░░░░░░░░] 0%
Phase 5: Testing & Debugging [░░░░░░░░░░] 0%

Overall Progress: [█░░░░░░░░░░] 3% (1/31 plans)

```

---

## Performance Metrics

**Requirements:** 47 total (v1.0)
**Completed:** 0
**In Progress:** 0
**Blocked:** 0

**Phases:** 5 total
**Completed:** 0
**In Progress:** 0
**Blocked:** 0

**Success Criteria:** 27 total
**Met:** 0

---

## Accumulated Context

### Decisions Made

| Decision                                          | Date       | Rationale                                                                                                                                       |
| ------------------------------------------------- | ---------- | ----------------------------------------------------------------------------------------------------------------------------------------------- | -------------------- | --------------------------------------------- |
| Data model first (Phase 1)                        | 2026-02-04 | Multi-tenant isolation and version tracking must be foundational to avoid security and versioning issues                                        |
| State machine execution pattern                   | 2026-02-04 | Research shows this allows flexible, resumable flows with error handling (vs rigid step-by-step)                                                |
| AI manages execution (not rigid)                  | 2026-02-04 | Enables natural dialogue while following flow structure (avoids conversational robots)                                                          |
| Vertical slices (not horizontal layers)           | 2026-02-04 | Each phase delivers complete capability (data → UI → execution → AI → testing)                                                                  |
| Sticky versioning for flows                       | 2026-02-04 | Prevents breaking changes from affecting active patient conversations                                                                           |
| Nodes stored inline in flowVersions               | 2026-02-04 | Simpler reads, single document retrieval rather than separate collection                                                                        |
| Flow-level variable definitions                   | 2026-02-04 | Easier to manage and reference across nodes compared to per-node variables                                                                      |
| Sequential version numbering (integers)           | 2026-02-04 | Simpler than semantic versioning for flows, clear ordering (1, 2, 3...)                                                                         |
| Immutable versioning (no updatedAt)               | 2026-02-04 | Enforces complete audit trail, prevents accidental mutations on flow versions                                                                   |
| Sticky versioning (flowVersionId)                 | 2026-02-04 | Flow executions pinned to version at start prevents breaking changes during active sessions                                                     |
| Direct ctx.auth.getUserIdentity() approach        | 2026-02-04 | Used direct Convex identity approach instead of lib/getAuthenticatedUser to avoid type conflicts with generated types                           |
| Embedded authorization in handlers                | 2026-02-04 | Authorization logic embedded directly in mutation/query handlers instead of using external helper functions to maintain type safety with Convex |
| Append-only audit logging                         | 2026-02-04 | Audit logs cannot be updated or deleted to ensure complete audit trail compliance                                                               |
| Variable sanitization for templates               | 2026-02-04 | Simplified sanitization to focus on XSS, template injection, and HTML entities rather than SQL patterns for template context                    |
| Audit before delete operations                    | 2026-02-04 | Log operation before deletion to preserve flow metadata in audit trail                                                                          |
| Date range filtering for audit queries            | 2026-02-04 | Supports 1-year retention queries with pagination (default 100, max 1000 entries)                                                               |
| TanStack Start routing structure                  | 2026-02-04 | Used src/routes/api/ with $id for dynamic parameters instead of app/api/ with [id] (matches existing pattern)                                   |
| Proxy pattern for API routes                      | 2026-02-04 | TanStack Start routes forward to Convex HTTP API with auth tokens (matches existing pattern)                                                    |
| Dual-layer authentication                         | 2026-02-04 | Keep authentication in both HTTP layer and Convex function layer for defense-in-depth security                                                  |
| Three-column layout for flow builder              | 2026-02-05 | Left nav (280px)                                                                                                                                | center canvas (flex) | right sidebar (320px) per CONTEXT.md decision |
| React Flow CSS import requirement                 | 2026-02-05 | Required per RESEARCH.md Pitfall 1 to ensure proper canvas styling                                                                              |
| @xyflow/react v12.10.0 installed                  | 2026-02-05 | Industry-standard visual drag-and-drop flow builder with React 19 support                                                                       |
| Import React Flow CSS in FlowCanvas               | 2026-02-05 | Prevents Pitfall 1 (missing CSS causes broken canvas rendering)                                                                                 |
| NodePalette horizontal toolbar layout             | 2026-02-05 | Positioned above FlowCanvas since MainLayout already uses 280px left sidebar; horizontal toolbar maximizes canvas space                         |
| useNodesState/useEdgesState hooks                 | 2026-02-05 | Prevents Pitfall 2 (re-render cascades during node dragging)                                                                                    |
| screenToFlowPosition for drop handler             | 2026-02-04 | Converts screen coordinates to flow canvas coordinates for accurate node placement on drop                                                      |
| Hidden input handle with visibility:hidden        | 2026-02-04 | Per Pitfall 5, uses CSS visibility instead of display:none to maintain handle hit testing while hiding visual                                   |
| Blue color scheme for message nodes               | 2026-02-04 | Per CONTEXT.md decision, distinguishes message nodes from other node types (Condition=orange, Input=green, Wait=purple)                         |
| Green color scheme for input nodes                | 2026-02-05 | Per CONTEXT.md decision, distinguishes input nodes from other node types with green color scheme                                                |
| Orange color scheme for condition nodes           | 2026-02-05 | Per CONTEXT.md decision, distinguishes condition nodes from other node types with orange color scheme                                           |
| Multiple output handles (yes/no)                  | 2026-02-05 | Condition nodes have two source handles (yes at Right, no at Bottom) with unique IDs for branching logic                                        |
| Custom edge component with hover-based 'x' button | 2026-02-05 | Edge deletion via red 'x' button that appears on hover, per CONTEXT.md locked decision for intuitive connection removal                         |
| 24-hour timeout threshold for inactive chats      | 2026-02-05 | Reasonable window for patient engagement without being too aggressive                                                                           |
| 18-hour nudge threshold (75%)                     | 2026-02-05 | Provides proactive outreach 6 hours before abandonment                                                                                          |
| Portuguese nudge message text                     | 2026-02-05 | "Ainda está aí? Posso continuar ajudando com o que estávamos conversando? Se preferir, posso encaminhar para alguém da nossa equipe."           |
| Hourly cron schedule for timeout checks           | 2026-02-05 | Balances responsiveness (max 60-min delay) with performance (no overwhelming queries)                                                           |
| Admin role required for flow activation           | 2026-02-05 | Flow activation and default flow setting require admin role to prevent staff from changing active flows                                         |
| Single active flow per clinic                     | 2026-02-05 | activateFlow deactivates all other clinic flows before activating target, ensuring only one active flow at a time                               |
| Default flow fallback pattern                     | 2026-02-05 | getActiveFlowByClinic checks clinicSettings first, then falls back to querying active flows                                                     |
| ClinicSettings uses Id<"clinics"> for reference   | 2026-02-05 | Using Id<"clinics"> ensures referential integrity, table must be defined after clinics in schema                                                |
| Portuguese UI text for default flow selector      | 2026-02-05 | All user-facing text in Portuguese for Brazilian clinic admin users (e.g., "Fluxo Padrão", "Padrão", "Apenas administradores...")               |
| Disabled vs hidden for non-admin users            | 2026-02-05 | Non-admin users see disabled selector with lock icon and tooltip rather than hidden UI - provides transparency about available features         |
| Star icon (yellow) for default flow indicator     | 2026-02-05 | Visual indicator for default flow provides immediate recognition in flow list and selector dropdown                                             |
| Flow guidance position in system prompt           | 2026-02-05 | Position after basePrompt but before patient context - flow provides structure, context provides personalization                                |
| Flow-aware agent cache bypass                     | 2026-02-05 | Dynamic per-request flow instructions bypass cache to prevent stale guidance; static agents (no flow) remain cached                             |
| Pre-formatted flow instructions parameter chain   | 2026-02-05 | processIncomingAiMessage → generateAiResponse → getClinicAgent → createClinicAgent passes formatted instructions for direct injection           |
| Graceful flow loading degradation                 | 2026-02-05 | WhatsApp processing continues without flow guidance if flow loading fails - core AI functionality must not break                                |
| Tool execution within flow context                | 2026-02-05 | Existing Mastra tool system already supports flow context - enhanced descriptions guide AI without code changes                                 |
| Flow-TOOLS INTEGRATION section in system prompt   | 2026-02-05 | Documents that tool calls are invisible to patients and don't disrupt flow context                                                              |
| User checkpoint verification for Phase 4          | 2026-02-05 | Manual testing validates AI behavior quality (tone, naturalness, flow adherence) that automated tests cannot capture                            |
| All 6 test scenarios must pass for phase complete | 2026-02-05 | No partial credit for integration - end-to-end requires all scenarios working (AIINT-04, AIINT-05, AIINT-06, SEC-02/03)                         |

### Technical Constraints

- **Tech Stack:** React, TanStack Start, Convex, TypeScript (existing)
- **Database:** Convex with multi-tenant isolation
- **Authentication:** better-auth with existing session management
- **Performance:** Flow execution must not block AI response times
- **Plans:** Flow builder features gated by subscription tiers
- **UI/UX:** Must be intuitive for non-technical clinic admins

### Architecture Decisions

- **@xyflow/react** for visual drag-and-drop flow builder (industry standard, 35.1k GitHub stars)
- **@mastra/core** (existing) for flow execution orchestration with graph-based workflows
- **Zod v4.1.13** for schema validation with native JSON Schema conversion
- **Convex** for flow storage and real-time sync
- **Pinned system prompts** to prevent AI context window overflow
- **Expand/contract versioning** pattern for flow schema migrations

### Research Findings

**High Confidence:**

- State machine-driven flow execution is 2025-2026 standard
- @xyflow/react provides mature, well-documented capabilities
- Multi-tenant patterns with Convex are well-established
- Five critical pitfalls identified with specific prevention strategies

**Medium Confidence:**

- Flow-to-AI prompt injection format optimal patterns (may need iteration during Phase 4)
- Mastra agent runtime system prompt modification capabilities (requires A/B testing during Phase 4)

**Gaps to Address:**

- Mastra ↔ React Flow conversion patterns (complex integration, handle during Phase 3 planning)
- Healthcare compliance audit logging requirements (legal review needed during Phase 1)
- Flow schema migration strategy for active sessions (Convex schema design question, Phase 1 planning)

### Known Anti-Patterns

**Avoid:**

- Horizontal layers (all models, then all APIs, then all UI)
- Arbitrary phase counts (let work determine structure)
- Task-based success criteria (use observable user behaviors)
- Vague success criteria (be specific and verifiable)
- Project management artifacts (time estimates, Gantt charts, risk matrices)

**Embrace:**

- Vertical slices (complete capabilities per phase)
- Goal-backward thinking (what must be TRUE for users when phase completes)
- Requirements-driven structure (derive phases from requirements)
- Honest gaps (surface issues, don't hide them)
- Observable success criteria (verifiable by humans using the application)

---

## Session Continuity

### Last Session

2026-02-05

### Stopped at

Completed 04-04 Integration Verification (Phase 4 complete - 4/4 plans, all 6 tests passed)

### Resume File

None

### Next Steps

1. Plan 04-04: Integration verification with user checkpoint
2. Plan 04-04: Integration verification with user checkpoint
3. Continue through phases 4 and 5
4. Validate all success criteria for v1.0 milestone
5. Plan 01-01 completed: Convex data model for flows (2026-02-04)
6. Plan 01-03 completed: Flow version management with immutable design (2026-02-04)
7. Plan 01-02 completed: Implement flow CRUD operations with multi-tenant isolation (2026-02-04)
8. Plan 01-05 completed: Implement audit logging for compliance (2026-02-04)
9. Plan 01-06 completed: Implement variable sanitization to prevent injection attacks (2026-02-04)
10. Plan 01-07 completed: Create HTTP API endpoints for flow management (2026-02-04)
11. Plan 02-01 completed: Install @xyflow/react and create route structure (2026-02-05)
12. Plan 02-02 completed: Create FlowCanvas component with basic React Flow setup (2026-02-05)
13. Plan 02-03 completed: Create NodePalette component with drag-and-drop node types (2026-02-05)
14. Plan 02-04 completed: Create MessageNode component with variable support (2026-02-04)
15. Plan 02-05 completed: Create ConditionNode component and register in FlowCanvas (2026-02-04)
16. Plan 02-06 completed: Create InputNode component and register in FlowCanvas (2026-02-05)
17. Plan 02-07 completed: Implement node connections with bezier curves and 'x' button removal (2026-02-05)
18. Plan 02-08 completed: Implement zoom/pan, delete, and flow validation with inline errors (2026-02-05)
19. Plan 02-09 completed: Create FlowSettingsPanel and integrate with Convex backend (2026-02-05)
20. Plan 02-11 completed: Create WaitNode component and register in FlowCanvas (2026-02-05)
21. Plan 02-12 completed: Create NodePropertiesPanel with tabbed interface and integrate with canvas (2026-02-05)
22. Plan 03-01 completed: Flow loading and context formatting infrastructure (2026-02-05)
23. Plan 03-02 completed: Flow context integration with Mastra AI agent (2026-02-05)
24. Plan 03-03A completed: Wait node timeout handling (2026-02-05)
25. Plan 03-03B completed: Patient help request detection and escalation (2026-02-05)
26. Plan 03-04 completed: Flow execution tracking (2026-02-05)
27. Plan 02-02 completed: Create FlowCanvas component with basic React Flow setup (2026-02-05)
28. Plan 02-03 completed: Create NodePalette component with drag-and-drop node types (2026-02-05)
29. Plan 02-04 completed: Create MessageNode component with variable support (2026-02-04)
30. Plan 02-05 completed: Create ConditionNode component and register in FlowCanvas (2026-02-04)
31. Plan 02-06 completed: Create InputNode component and register in FlowCanvas (2026-02-05)
32. Plan 02-07 completed: Implement node connections with bezier curves and 'x' button removal (2026-02-05)
33. Plan 02-12 completed: Create NodePropertiesPanel with tabbed interface and integrate with canvas (2026-02-05)
34. Plan 02-08 completed: Implement zoom/pan, delete, and flow validation with inline errors (2026-02-05)
35. Plan 02-08 completed: Implement zoom/pan, delete, and flow validation with inline errors (2026-02-05)
36. Plan 02-11 completed: Create WaitNode component and register in FlowCanvas (2026-02-05)
37. Plan 02-12 completed: Create NodePropertiesPanel with tabbed interface and integrate with canvas (2026-02-05)
38. Plan 04-02 completed: Default flow selector UI with role-based access control (2026-02-05)
39. Plan 04-01 completed: Flow context injection with formatting utilities and AI agent integration (2026-02-05)
40. Plan 04-03 completed: Tool execution within flow context with diagnostic logging (2026-02-05)
41. Plan 04-04 completed: Integration verification with user checkpoint - all 6 tests passed (2026-02-05)

### Next Steps

1. Phase 5: Testing & Debugging
2. Validate all success criteria for v1.0 milestone
3. v1.0 AI Flow Builder release preparation

### Blockers

None.

### Todos

**Phase 1 (Complete):**

- [x] Plan 01-01: Define Convex data model for flows
- [x] Plan 01-02: Implement flow CRUD operations with multi-tenant isolation
- [x] Plan 01-03: Implement version management with immutable design
- [x] Plan 01-04: Add Convex access control rules for defense-in-depth
- [x] Plan 01-05: Implement audit logging for compliance
- [x] Plan 01-06: Implement variable sanitization to prevent injection attacks
- [x] Plan 01-07: Create HTTP API endpoints for flow management

**Phase 2 (Complete — pending verification):**

- [x] Plan 02-01: Install @xyflow/react and create route structure
- [x] Plan 02-02: Create FlowCanvas component with basic React Flow setup
- [x] Plan 02-03: Create NodePalette component with drag-and-drop node types
- [x] Plan 02-04: Create MessageNode component with variable support
- [x] Plan 02-05: Create ConditionNode component and register in FlowCanvas
- [x] Plan 02-06: Create InputNode component and register in FlowCanvas
- [x] Plan 02-07: Implement node connections with bezier curves and 'x' button removal
- [x] Plan 02-08: Implement zoom/pan, delete, and flow validation
- [x] Plan 02-11: Create WaitNode component and register in FlowCanvas
- [x] Plan 02-12: Complete flow builder UI phase verification
- [ ] Manual verification: Complete testing.md checklist in .planning/phases/02-flow-builder-ui/testing.md

**Phase 3 (Complete):**

- [x] Plan 03-01: Flow loading and context formatting infrastructure
- [x] Plan 03-02: Flow context integration with Mastra AI agent
- [x] Plan 03-03A: Timeout monitoring with nudge escalation
- [x] Plan 03-03B: Patient help request detection and escalation
- [x] Plan 03-04: Flow execution tracking

**Phase 4 (Complete):**

- [x] Plan 04-01: Flow context injection into AI system prompt
- [x] Plan 04-02: Default flow selector UI
- [x] Plan 04-03: Tool execution within flow context
- [x] Plan 04-04: Integration verification with user checkpoint (all 6 tests passed)

**Phase 5 (Planned):**

- [ ] Plan Phase 5: Testing & Debugging
- [ ] Validate all success criteria for v1.0 milestone

---

## Traceability

**Milestone:** v1.0 AI Flow Builder

**Total Requirements:** 47
**Completed:** 0
**In Progress:** 0

**Phase Breakdown:**

- Phase 1: Flow Data Model & Storage — 19 requirements
- Phase 2: Flow Builder UI — 9 requirements
- Phase 3: Flow Execution Engine — 12 requirements
- Phase 4: AI Integration — 6 requirements
- Phase 5: Testing & Debugging — 5 requirements

**Coverage:** 100% (all v1 requirements mapped to exactly one phase)

---

_This state file serves as project memory for continuity across sessions. Updated after each phase completion._

```

```

```

```

```

```

```

```
