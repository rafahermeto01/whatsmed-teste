# Feature Research

**Domain:** AI Flow Builder for Healthcare WhatsApp Automation
**Researched:** 2026-02-04
**Confidence:** HIGH

## Feature Landscape

### Table Stakes (Users Expect These)

Features users assume exist. Missing these = product feels incomplete.

| Feature                                            | Why Expected                                           | Complexity | Notes                                                                   |
| -------------------------------------------------- | ------------------------------------------------------ | ---------- | ----------------------------------------------------------------------- |
| Visual drag-and-drop canvas                        | Non-technical admins need intuitive flow creation      | MEDIUM     | Standard expectation since 2024; React Flow or similar library required |
| Basic node types (Message, Condition, Input, Wait) | Core building blocks for any flow builder              | LOW        | These are the minimum viable node types                                 |
| Flow save/load & management                        | Users need to create, edit, delete, and activate flows | LOW        | Standard CRUD operations for flow entities                              |
| Variable system with patient data substitution     | Personalized messages require dynamic content          | LOW        | Must integrate with existing patient data model                         |
| Real-time preview/testing                          | Users must verify flows before activation              | MEDIUM     | Requires execution engine simulation                                    |
| Connection validation                              | Prevent broken flows from saving                       | MEDIUM     | Ensure all nodes connect properly before activation                     |
| Flow activation toggles                            | Enable/disable specific flows                          | LOW        | Simple boolean state per flow                                           |
| WhatsApp message types (text, media, buttons)      | WhatsApp supports multiple message formats             | MEDIUM     | Must support at least text, images, and interactive buttons             |
| Flow execution history                             | Debugging and compliance require audit trails          | HIGH       | Need to track flow activations and outcomes                             |
| Multi-node connections (branching)                 | Non-linear flows require decision branches             | MEDIUM     | Multiple outgoing edges from condition nodes                            |

### Differentiators (Competitive Advantage)

Features that set the product apart. Not required, but valuable.

| Feature                                                    | Value Proposition                                                                       | Complexity | Notes                                                                       |
| ---------------------------------------------------------- | --------------------------------------------------------------------------------------- | ---------- | --------------------------------------------------------------------------- |
| AI-managed flow execution with flexibility                 | Unlike rigid decision trees, AI interprets flow intent while handling patient questions | HIGH       | Flow is injected into system prompt; AI follows goals, not strict steps     |
| Conversational vs Campaign flow modes                      | Single platform handles both real-time dialogue and scheduled outreach                  | MEDIUM     | Same builder, different execution semantics                                 |
| Natural language flow templates                            | Admins describe goal in Portuguese, AI generates flow structure                         | HIGH       | "Prompt-to-Flow" pattern reduces learning curve                             |
| Healthcare-specific node library                           | Built-in nodes for appointments, prescriptions, triage, consent                         | MEDIUM     | Leverages existing WhatsMed data model (appointments, patients, procedures) |
| Smart variable inserter                                    | Context-aware suggestions show available patient data                                   | LOW        | Already exists in CampaignBuilderModal; extend to flow builder              |
| AI Persona testing                                         | Simulate conversations with different patient personas                                  | HIGH       | Agent-to-Agent testing using LLM to play patient roles                      |
| Flow activation strategies (per-conversation, clinic-wide) | Targeted activation allows A/B testing and gradual rollout                              | MEDIUM     | Multiple trigger modes for different use cases                              |
| Real-time flow debugging with step-through                 | See AI reasoning and state at each flow step                                            | HIGH       | Requires exposing AI thought process and execution state                    |
| WhatsApp Flows integration                                 | Native in-chat forms for structured data collection                                     | HIGH       | Meta's 2026 feature reduces friction vs open-ended text                     |
| Clinical handoff with context summary                      | Seamless transition to human staff with conversation summary                            | MEDIUM     | Already have reactive WhatsApp AI; extend with flow-aware handoff           |

### Anti-Features (Commonly Requested, Often Problematic)

Features that seem good but create problems.

| Feature                                | Why Requested                             | Why Problematic                                                       | Alternative                                                     |
| -------------------------------------- | ----------------------------------------- | --------------------------------------------------------------------- | --------------------------------------------------------------- |
| Rigid step-by-step execution           | Appears predictable and controllable      | Frustrates patients who ask off-script questions; breaks conversation | AI-managed execution with flexible goal following               |
| General-purpose AI assistant           | Competitors offer "talk to anything" bots | **Banned by Meta (Jan 2026)** - violates WhatsApp Business API terms  | Domain-specific AI for healthcare/clinic workflows only         |
| Complex logic nodes (JavaScript/Lua)   | Developers want custom computation        | Increases complexity; violates "non-technical admin" target           | Pre-built healthcare nodes + API/Webhook node for extensibility |
| Unlimited branching depth              | "If we can model any business process..." | Creates "Mega-Flows" that are unmaintainable and hard to debug        | Subflows for reusable logic; limit main flow to 20-30 nodes max |
| Real-time collaboration (Figma-style)  | "Admins want to build flows together"     | Adds significant complexity; low usage in single-clinic context       | Flow versioning with comments; admin can share flow via export  |
| Voice-first flow builder               | "Siri-like natural conversation creation" | 2026 tech is immature; high hallucination risk                        | Natural language text prompts for flow generation               |
| Auto-optimization (AI rewriting flows) | "Make flows better automatically"         | Loss of admin control; unpredictable behavior changes                 | AI suggestions with explicit admin approval                     |
| Template marketplace                   | "Share flows with other clinics"          | HIPAA/PHI compliance issues; flows contain patient data templates     | Private clinic flow library with admin curation                 |

## Feature Dependencies

```
[Visual Flow Builder Canvas]
    ├──requires──> [Node Types System]
    ├──requires──> [Flow Storage API]
    ├──requires──> [Flow Validation Logic]
    └──enhances──> [Existing WhatsApp AI System]

[Flow Execution Engine]
    ├──requires──> [Flow Storage API]
    ├──requires──> [Flow State Management]
    ├──requires──> [WhatsApp Message API]
    ├──requires──> [Patient Data Access]
    └──enhances──> [Existing WhatsApp AI System]

[AI-Managed Execution]
    ├──requires──> [Flow Execution Engine]
    ├──requires──> [Flow-to-Prompt Translation]
    ├──requires──> [Existing WhatsApp AI System]
    └──enhances──> [Patient Experience]

[Conversational Flow Mode]
    ├──requires──> [AI-Managed Execution]
    └──enhances──> [Existing WhatsApp AI System]

[Campaign Flow Mode]
    ├──requires──> [Flow Execution Engine]
    ├──requires──> [Existing Marketing Automation System]
    └──enhances──> [Campaign Engagement Rates]

[Testing & Debugging]
    ├──requires──> [Flow Execution Engine]
    ├──requires──> [Flow State Management]
    └──enhances──> [Flow Builder Usability]

[Healthcare Node Library]
    ├──requires──> [Node Types System]
    ├──requires──> [Existing Patient/Appointment APIs]
    └──enhances──> [Time to Value]
```

### Dependency Notes

- **Visual Flow Builder Canvas requires Node Types System:** Cannot build UI without defining node schema first
- **AI-Managed Execution requires Existing WhatsApp AI System:** Critical integration point; flow must be injected into existing reactive AI prompts
- **Conversational Flow Mode requires AI-Managed Execution:** Real-time dialogue needs flexible AI interpretation, not rigid execution
- **Campaign Flow Mode requires Existing Marketing Automation System:** Must integrate with current trigger system (time_after_appointment, birthday, etc.)
- **Testing & Debugging enhances Flow Builder Usability:** Without testing, admins cannot confidently activate flows
- **Healthcare Node Library enhances Time to Value:** Pre-built nodes reduce setup time compared to generic nodes

## MVP Definition

### Launch With (v1)

Minimum viable product — what's needed to validate the concept.

- [ ] **Visual drag-and-drop canvas** — Core builder interface required for flow creation
- [ ] **Basic node types**: Message, Condition, Input, Wait — Minimum building blocks
- [ ] **Flow storage and management** — CRUD operations for flows
- [ ] **Flow validation** — Prevent broken flows from saving
- [ ] **Variable system with patient data substitution** — Personalized messages
- [ ] **Simple testing mode** — Manual conversation simulation
- [ ] **AI-managed execution for conversational flows** — Core differentiator
- [ ] **Flow activation toggles** — Enable/disable flows
- [ ] **Flow execution history** — Basic audit trail

**Rationale:** This provides a functional flow builder that allows clinic admins to create simple conversational flows. The AI-managed execution differentiates from rigid decision trees. Testing mode ensures confidence before activation. Execution history provides basic compliance tracking.

### Add After Validation (v1.x)

Features to add once core is working.

- [ ] **Healthcare node library** — Pre-built nodes for appointments, prescriptions, triage
- [ ] **Natural language flow templates** — Reduce learning curve with AI generation
- [ ] **Advanced testing with AI personas** — Automated stress testing
- [ ] **Campaign flow mode** — Leverage existing marketing automation
- [ ] **WhatsApp Flows integration** — Native in-chat forms
- [ ] **Real-time debugging with step-through** — Better troubleshooting
- [ ] **Clinical handoff with context summary** — Seamless human escalation
- [ ] **Smart variable inserter** — Context-aware data suggestions

**Triggers:** Add these after validating that admins can successfully create and deploy flows. Healthcare nodes and templates increase adoption. Campaign mode expands use cases. Advanced testing and debugging reduce support burden.

### Future Consideration (v2+)

Features to defer until product-market fit is established.

- [ ] **Multi-node connections with complex branching** — Advanced logic patterns
- [ ] **Subflows for reusable logic** — Reduce flow duplication
- [ ] **Flow versioning and rollback** — Production safety
- [ ] **Flow export/import** — Share flows between clinics
- [ ] **A/B testing for flow variants** — Optimize conversion rates
- [ ] **Flow analytics dashboard** — Engagement metrics and drop-off points
- [ ] **WhatsApp Username/BSUID support** — Meta's 2026 identifier system
- [ ] **Portfolio Pacing awareness** — Dynamic messaging limits handling

**Why defer:** These are nice-to-have features that increase complexity without addressing core value proposition. Wait until customers validate the concept and request these specific capabilities.

## Feature Prioritization Matrix

| Feature                                            | User Value | Implementation Cost | Priority |
| -------------------------------------------------- | ---------- | ------------------- | -------- |
| Visual drag-and-drop canvas                        | HIGH       | MEDIUM              | P1       |
| Basic node types (Message, Condition, Input, Wait) | HIGH       | LOW                 | P1       |
| Flow storage and management                        | HIGH       | LOW                 | P1       |
| Flow validation                                    | HIGH       | MEDIUM              | P1       |
| AI-managed execution                               | HIGH       | HIGH                | P1       |
| Variable system with patient data substitution     | HIGH       | LOW                 | P1       |
| Flow activation toggles                            | HIGH       | LOW                 | P1       |
| Flow execution history                             | HIGH       | HIGH                | P1       |
| Simple testing mode                                | MEDIUM     | MEDIUM              | P1       |
| Healthcare node library                            | HIGH       | MEDIUM              | P2       |
| Natural language flow templates                    | MEDIUM     | HIGH                | P2       |
| Campaign flow mode                                 | MEDIUM     | MEDIUM              | P2       |
| WhatsApp Flows integration                         | MEDIUM     | HIGH                | P2       |
| Advanced testing with AI personas                  | MEDIUM     | HIGH                | P2       |
| Clinical handoff with context summary              | HIGH       | MEDIUM              | P2       |
| Real-time debugging with step-through              | MEDIUM     | HIGH                | P2       |
| Smart variable inserter                            | LOW        | LOW                 | P3       |
| Multi-node connections with complex branching      | MEDIUM     | MEDIUM              | P3       |
| Subflows for reusable logic                        | MEDIUM     | HIGH                | P3       |
| Flow versioning and rollback                       | MEDIUM     | HIGH                | P3       |
| Flow analytics dashboard                           | MEDIUM     | HIGH                | P3       |

**Priority key:**

- P1: Must have for launch (MVP)
- P2: Should have, add when possible (v1.x)
- P3: Nice to have, future consideration (v2+)

## Competitor Feature Analysis

| Feature              | Voiceflow                                | Salesforce Flow Builder            | Our Approach                                                  |
| -------------------- | ---------------------------------------- | ---------------------------------- | ------------------------------------------------------------- |
| Visual canvas        | ✓ Highly polished with React Flow        | ✓ Salesforce proprietary           | Use React Flow (proven, mature)                               |
| Node types           | ✓ Extensive library                      | ✓ Record-triggered, screens        | Start with basic 4 types, add healthcare nodes                |
| AI integration       | ✓ AI-first platform with LLM integration | ✓ Agentforce with Prompt Builder   | Inject flow into existing WhatsApp AI prompt                  |
| Testing              | ✓ AI Persona simulation (Agent-to-Agent) | ✓ Sandbox with mock data           | Start with manual testing, add AI personas later              |
| Execution model      | ✗ Mostly rigid (unless using Agent)      | ✓ Can be flexible with custom code | AI-managed execution as core differentiator                   |
| Healthcare focus     | ✗ Generic platform                       | ✓ Health Cloud has medical nodes   | Healthcare-specific nodes from day 1 (P2)                     |
| WhatsApp integration | ✓ WhatsApp API support                   | ✗ Limited WhatsApp support         | Deep integration with existing Evolution/Meta providers       |
| Target users         | Both technical & non-technical           | Mostly Salesforce admins           | Non-technical clinic admins (must be simpler than Salesforce) |
| Pricing              | SaaS subscription                        | Per Salesforce user                | Included in WhatsMed subscription tiers                       |

**Key differentiator:** We're not building a generic flow platform. Our differentiator is **healthcare-specific nodes** + **AI-managed execution** + **WhatsApp-native integration** in a simple interface for non-technical clinic admins.

## Healthcare-Specific Considerations

### PHI Compliance

- Flow execution history must track all AI-generated messages for audit trails
- Variable substitution must redact sensitive data from logs (PHI Redaction pattern)
- Flow templates should not include actual patient data; use placeholders only

### Clinical Safety

- Urgent care detection node (sentiment analysis for distress/suicidal ideation)
- Clinical handoff with context summary to human staff
- Evidence validation node to ensure AI responses stay within safe clinical boundaries

### Integration with Existing WhatsMed Features

- Appointment booking nodes must integrate with existing appointment system
- Patient data nodes must respect multi-tenant isolation (clinic-based)
- Campaign flow mode must work with existing trigger system (time_after_appointment, birthday, no_show)

## WhatsApp-Specific Constraints and Opportunities

### Constraints (Meta 2026 Policies)

- **General-purpose AI ban:** Cannot build "talk to anything" assistant. Must be domain-specific (healthcare/clinic workflows only)
- **Portfolio Pacing:** Dynamic messaging limits based on quality score. High spam reports = mid-send pause
- **Per-message pricing:** Template messages charged per message, not per 24-hour window. Discourages batch-blasting
- **File size limits:** Documents 100MB, Video 16MB, Images 5MB
- **Cloud API mandatory:** Must use Cloud API, not local on-premise installations

### Opportunities

- **WhatsApp Flows:** Native in-chat forms for structured data collection (birth year, time picker, dropdowns)
- **Interactive buttons:** Quick replies and call-to-action buttons reduce friction vs typing
- **Carousels:** Display multiple options (appointment slots, procedure types) in swipeable format
- **BSUID transition:** Business-scoped user IDs provide better privacy (phone number masking)

## Sources

### HIGH Confidence (Official/Authoritative)

- React Flow Documentation (https://reactflow.dev/docs/introduction/) — Verified capabilities and API
- Meta WhatsApp Business Platform 2026 Policy Documentation — Verified constraints and restrictions
- WhatsMed Existing Codebase — CampaignBuilderModal.tsx demonstrates current variable system

### MEDIUM Confidence (WebSearch Verified)

- 2026 Flow Builder UX Patterns — Multiple sources confirming intelligent assembly, animated connectors
- Healthcare Chatbot Node Types 2026 — Multiple healthcare AI sources confirming specialized nodes
- Flow Execution State Management 2026 — Multiple technical sources confirming durable execution patterns
- Conversational vs Campaign Flow Differences 2026 — Multiple marketing/automation sources

### LOW Confidence (Single Source/Unverified)

- Flow activation strategies 2026 — Single source discussing intent-based activation; need to verify with implementation testing

---

_Feature research for: AI Flow Builder for Healthcare WhatsApp Automation_
_Researched: 2026-02-04_
