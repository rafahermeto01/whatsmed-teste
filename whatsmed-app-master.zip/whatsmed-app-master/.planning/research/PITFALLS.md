# Pitfalls Research

**Domain:** AI Flow Builder for Healthcare WhatsApp Automation
**Researched:** 2026-02-04
**Confidence:** MEDIUM

## Critical Pitfalls

### Pitfall 1: Flow Version Mismatch with Active Sessions

**What goes wrong:**
Deploying a new flow version causes active patient conversations to break or behave unpredictably because they're running on outdated flow definitions.

**Why it happens:**
Developers deploy flow changes without considering that sessions may be mid-conversation. The system retrieves the latest flow definition instead of preserving the version the session started with, causing patients to experience jumps in logic, missing questions, or state mismatches.

**How to avoid:**

- Implement "sticky versioning": pin each session to the flow version at session start
- Store flow version in session state and always use that version for the session's lifetime
- Use a flow definition registry keyed by `(flowId, version)` pairs
- When deploying new flows, ensure only NEW sessions use the new version

**Warning signs:**

- Users report "the bot forgot what we were talking about"
- Patients complain about skipped questions or confusing jumps
- Error logs show state names that no longer exist in current flow
- Support tickets spike after flow deployments

**Phase to address:**
Phase 1 (Flow Storage) - Must include version tracking in the data model from the start

---

### Pitfall 2: AI Context Window Overflow Leading to Flow Ejection

**What goes wrong:**
Long conversations or large flow definitions cause the AI system prompt (including flow instructions) to be truncated, allowing patients to bypass flow controls or the AI to "forget" the flow entirely.

**Why it happens:**
LLMs have finite context windows. When conversation history + flow definition + system prompt exceeds the limit, most implementations use FIFO truncation that drops the oldest tokens first. Since system prompts are added first, they're ejected first, removing flow constraints.

**How to avoid:**

- Pin system prompt and flow instructions so they're never truncated
- Implement strict token limits on conversation history
- Use context summarization for long conversations
- Monitor token usage and trigger graceful flow termination before overflow
- Consider separate short-term and long-term memory systems

**Warning signs:**

- AI stops following flow structure mid-conversation
- Responses ignore previously established constraints
- Model starts giving responses that contradict flow rules
- Token count monitoring shows approaching limits

**Phase to address:**
Phase 2 (AI Integration) - Must implement prompt architecture before connecting flows to AI

---

### Pitfall 3: Cross-Tenant Flow Access via State Injection

**What goes wrong:**
Malicious or buggy flow execution allows one clinic to access another clinic's patient data or flow definitions through state manipulation.

**Why it happens:**
Flow execution doesn't properly scope all database queries by `tenant_id`. If a flow references patient data or includes dynamic patient selection, the absence of tenant scoping creates data leakage vulnerabilities. Attackers could craft flows or manipulate state to access other tenants' data.

**How to avoid:**

- Enforce tenant scoping at the ORM/database level (RLS in PostgreSQL)
- Every database query MUST include `WHERE tenant_id = ?`
- Use policy engines (OPA, Cerbos) for authorization decisions
- Inject tenant context at the flow execution boundary, not within flow nodes
- Audit all data access patterns in flow execution

**Warning signs:**

- Any database query without explicit tenant filtering
- Flow nodes that accept patient IDs as input
- Direct SQL execution nodes in the builder
- Logs showing data access patterns inconsistent with tenant boundaries

**Phase to address:**
Phase 1 (Flow Storage) + Phase 3 (Execution Engine) - Foundation security, execution enforcement

---

### Pitfall 4: State Machine "Happy Path Trap" Leaving Patients Stranded

**What goes wrong:**
Patients who deviate from the expected flow (e.g., ask questions, go off-topic, provide unexpected answers) get stuck in error loops or dead ends because the flow only handles the happy path.

**Why it happens:**
State machines are deterministic by design but human conversation is probabilistic. Developers implement linear flows without considering that patients naturally digress, ask clarifying questions, or provide answers in unexpected formats. Without fallback mechanisms, these inputs cause generic errors or infinite loops.

**How to avoid:**

- Implement global "intent listeners" for help, cancel, and digression handling
- Use hybrid AI orchestration: state machine for structure, LLM for natural language handling within states
- Design every state with explicit error and fallback branches
- Always provide escape hatches (e.g., "Talk to a human", "Start over")
- Use slot-filling/frames instead of rigid linear progression where possible

**Warning signs:**

- Users report "the bot doesn't understand me"
- Support tickets increase for "bot not working"
- Session logs show repeated error messages
- High drop-off rates at specific flow nodes

**Phase to address:**
Phase 3 (Execution Engine) - Must design flexible execution model before building complex flows

---

### Pitfall 5: WhatsApp Message Type Mismatches Causing Silent Failures

**What goes wrong:**
Flows send message types or formats not supported by specific WhatsApp providers (Evolution API vs Meta Cloud API) or that violate API constraints, causing messages to fail silently or with unclear errors.

**Why it happens:**
WhatsApp providers have different capabilities and limits. A flow built and tested on one provider may fail when switched to another. Additionally, interactive messages have strict constraints (button character limits, button counts) that, if exceeded, cause validation errors.

**How to avoid:**

- Build provider-agnostic abstraction layer with capability detection
- Validate message formats before sending (client-side + server-side)
- Implement provider-specific fallbacks for unsupported features
- Monitor webhook notifications for delivery failures (not just API responses)
- Log all `fbtrace_id` values for support debugging
- Maintain compatibility matrix of provider capabilities

**Warning signs:**

- Messages not being delivered without error feedback
- Delivery failures after switching WhatsApp providers
- Error logs with Meta API codes (131000 series) or provider-specific errors
- Patient reports of missing messages

**Phase to address:**
Phase 3 (Execution Engine) + Phase 4 (WhatsApp Integration) - Must handle provider differences

---

## Technical Debt Patterns

| Shortcut                                               | Immediate Benefit                       | Long-term Cost                                                         | When Acceptable                             |
| ------------------------------------------------------ | --------------------------------------- | ---------------------------------------------------------------------- | ------------------------------------------- |
| Storing flow as JSON without validation schema         | Fast to implement, flexible             | Cannot validate structure, harder to maintain, breaking changes common | Never for production flows                  |
| Using flow ID only (no versioning)                     | Simpler database schema                 | Impossible to debug issues, breaks active sessions on updates          | Never - sessions must be pinned to versions |
| Ignoring tenant scoping in "internal" helper functions | Faster development, less code           | Critical security vulnerability, data leakage risk                     | Never - security must be pervasive          |
| Skipping error handling in flow nodes                  | Faster flow creation, cleaner UI        | Patients get stuck, poor experience, higher support burden             | Only in PoC/MVP, with TODO comments         |
| Hardcoding WhatsApp provider selection                 | Simpler integration, less abstraction   | Cannot switch providers, vendor lock-in                                | Only in MVP, plan to abstract later         |
| Storing flow execution logs in same DB as active state | Single data store, simpler architecture | Performance issues at scale, difficult to query for analytics          | Small MVP (under 100 clinics)               |
| Using global variables for flow state                  | Easy to implement, fast access          | Debugging nightmares, cross-talk between flows                         | Never - explicit state passing only         |

---

## Integration Gotchas

| Integration         | Common Mistake                                               | Correct Approach                                                              |
| ------------------- | ------------------------------------------------------------ | ----------------------------------------------------------------------------- |
| **Evolution API**   | Assuming it supports all Meta Cloud API features             | Check capability matrix before using features; implement graceful degradation |
| **Meta Cloud API**  | Ignoring webhook delivery failures (status: failed)          | Monitor both API response AND webhook notifications for complete picture      |
| **LLM (AI)**        | Not pinning system prompt, allowing truncation               | Always pin system prompt and flow instructions, implement context management  |
| **Convex Database** | Missing tenant_id in queries, relying on app-level filtering | Use Row-Level Security (RLS) where available, enforce at ORM level            |
| **Google Calendar** | Assuming flow execution identity has calendar access         | Use service accounts with proper permissions, not user tokens                 |
| **Asaas Payments**  | Assuming synchronous payment responses                       | Handle async webhooks for payment status updates                              |

---

## Performance Traps

| Trap                       | Symptoms                                                               | Prevention                                                                        | When It Breaks                               |
| -------------------------- | ---------------------------------------------------------------------- | --------------------------------------------------------------------------------- | -------------------------------------------- |
| **Canvas Re-render Storm** | Drag-and-drop lags with 50+ nodes, UI becomes unresponsive             | Use requestAnimationFrame, store drag coords in useRef, wrap nodes in React.memo  | 30+ nodes on canvas                          |
| **N+1 Query in Flows**     | Flow execution slow when collecting patient data from multiple sources | Batch queries, use joins, cache data in context, avoid loops that trigger queries | Flows with 10+ data collection steps         |
| **State Sync Bottleneck**  | Every keystroke in builder triggers state save to DB                   | Debounce saves (300-500ms), use optimistic UI updates                             | Multiple concurrent editors or rapid changes |
| **Context Window Bloat**   | AI response time increases as conversation grows                       | Summarize old context, implement context window monitoring                        | Conversations over 20 turns                  |
| **Lock Contention**        | Concurrent flow executions slow down due to session locks              | Use optimistic locking with retries, minimize critical sections                   | 10+ concurrent sessions per clinic           |

---

## Security Mistakes

| Mistake                               | Risk                                                   | Prevention                                                                           |
| ------------------------------------- | ------------------------------------------------------ | ------------------------------------------------------------------------------------ |
| **Missing Tenant Scoping**            | Cross-tenant data leakage, compliance violation        | Enforce RLS, every query MUST have WHERE tenant_id                                   |
| **Flow Creator Privilege Escalation** | User builds flow with admin actions, gets admin access | Execute flows with triggerer's permissions or scoped service account                 |
| **Unrestricted External URLs**        | SSRF attacks, internal network access                  | Egress filtering with proxy (Smokescreen), whitelist only allowed domains            |
| **Exposed API Keys in Flow Logs**     | Credential theft, unauthorized access                  | Never log secrets, redact sensitive data, use structured logging                     |
| **Prompt Injection via Flow**         | AI bypasses safety rules, inappropriate responses      | Sanitize all flow content, pin system prompt, validate against known attack patterns |
| **LGPD Violation - Health Data**      | Regulatory fines, legal liability                      | Treat health data as sensitive, explicit consent, data minimization, DPO appointment |
| **Missing Audit Trail**               | Cannot investigate incidents, compliance failure       | Log all flow executions: tenant, user, actions, data modified                        |
| **Weak Session ID Generation**        | Session hijacking, unauthorized access                 | Use cryptographically secure random IDs, bind to tenant + user                       |

---

## UX Pitfalls

| Pitfall                                 | User Impact                                      | Better Approach                                                                  |
| --------------------------------------- | ------------------------------------------------ | -------------------------------------------------------------------------------- |
| **Monolithic Flow (200+ nodes)**        | Impossible to debug, maintenance nightmare       | Break into subflows, use composition, max 20-30 nodes per flow                   |
| **Inconsistent Node Naming**            | Confusion, can't understand intent               | Use prefix/verb system: `msg_SendWelcome`, `dec_HasAppointment`, `tool_BookSlot` |
| **Missing Node Documentation**          | "Why does this branch exist?" questions          | Add description field to every node explaining business logic                    |
| **"Passive-Aggressive" Errors**         | User clicks next, nothing happens, frustration   | Clear validation messages explaining what's wrong and how to fix                 |
| **No Visual Path Indicator**            | Can't see how conversation flows                 | Show path taken during execution with highlighting                               |
| **Hidden Logic in AI Prompts**          | Can't debug AI behavior, unpredictable responses | Make AI instructions explicit in flow nodes, visible in builder                  |
| **Keyboard/Screen Reader Inaccessible** | Excludes users with disabilities                 | Ensure all drag-drop has keyboard alternatives, ARIA labels                      |
| **No Undo in Builder**                  | Accidental deletions require rebuilding          | Implement undo/redo with history stack                                           |

---

## "Looks Done But Isn't" Checklist

- [ ] **Flow Versioning**: Often missing version pinning for active sessions — verify sessions use version from start, not latest
- [ ] **Tenant Scoping**: Often missing WHERE tenant_id clauses in flow execution — verify ALL database queries
- [ ] **Error Handling**: Often missing fallback branches in flow nodes — verify every node has error path
- [ ] **Provider Differences**: Often assuming Evolution API = Meta Cloud — verify feature compatibility matrix
- [ ] **WhatsApp Delivery**: Often only checking API response, not webhook status — verify both success confirmations
- [ ] **Context Management**: Often missing overflow protection — verify token limits and truncation handling
- [ ] **Audit Logging**: Often missing who triggered what flow — verify execution logs include tenant, user, timestamp
- [ ] **State Recovery**: Often no way to recover from stuck states — verify timeout mechanisms and restart capability
- [ ] **LGPD Consent**: Often missing explicit health data consent — verify consent capture before collecting health info
- [ ] **Human Escalation**: Often no way to transfer to human staff — verify every flow has "Talk to human" option

---

## Recovery Strategies

| Pitfall                 | Recovery Cost | Recovery Steps                                                                                                                                                                                                                               |
| ----------------------- | ------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Version Mismatch**    | HIGH          | 1. Identify all affected sessions by version lookup. 2. Write migration script to map old states to new flow states. 3. Notify affected patients of disruption. 4. Consider forcing session restart for complex mismatches.                  |
| **Context Overflow**    | MEDIUM        | 1. Implement context summarization immediately. 2. Pin system prompt. 3. Add token monitoring with early termination. 4. Educate clinic admins on conversation length limits.                                                                |
| **Cross-Tenant Access** | CRITICAL      | 1. Immediately revoke all flow execution permissions. 2. Audit all data access since deployment. 3. Fix missing tenant scoping. 4. Notify affected clinics and regulatory bodies if required. 5. Rotate all credentials potentially exposed. |
| **Happy Path Trap**     | MEDIUM        | 1. Add global intent listeners for help/cancel. 2. Implement AI fallback for unexpected inputs. 3. Add escape hatches to all flows. 4. Train support staff on manual intervention.                                                           |
| **WhatsApp Failures**   | MEDIUM        | 1. Monitor webhook failures in real-time. 2. Implement automatic retry with exponential backoff for retryable errors. 3. Switch to alternative provider for persistent failures. 4. Notify clinics of delivery issues proactively.           |

---

## Pitfall-to-Phase Mapping

| Pitfall                 | Prevention Phase                             | Verification                                                                     |
| ----------------------- | -------------------------------------------- | -------------------------------------------------------------------------------- |
| Flow Version Mismatch   | Phase 1 (Flow Storage)                       | Write test: Start session on v1, deploy v2, verify session still runs v1         |
| Context Window Overflow | Phase 2 (AI Integration)                     | Load test: Create conversation until token limit, verify system prompt preserved |
| Cross-Tenant Access     | Phase 1 (Flow Storage) + Phase 3 (Execution) | Security test: Try to access other tenant's data via flow, verify blocked        |
| Happy Path Trap         | Phase 3 (Execution Engine)                   | Usability test: Deviate from flow, verify graceful handling                      |
| WhatsApp Mismatches     | Phase 4 (WhatsApp Integration)               | Test flows on both Evolution and Meta Cloud, verify identical behavior           |
| Canvas Performance      | Phase 1 (Builder UI)                         | Load test: Create 100-node flow, verify drag-drop remains smooth                 |
| State Sync Bottleneck   | Phase 1 (Builder UI)                         | Test: Rapid edits with auto-save, verify UI stays responsive                     |
| LGPD Violations         | Phase 1 (Flow Storage)                       | Compliance review: Verify health data handling per LGPD requirements             |
| Missing Audit Trail     | Phase 3 (Execution)                          | Verify execution logs contain all required fields for compliance                 |
| No Human Escalation     | Phase 4 (WhatsApp Integration)               | Test: Attempt to transfer to human, verify handoff works                         |

---

## Sources

- Flow builder UX research: Common mistakes in drag-and-drop builders (Salesforce Flow, Power Automate patterns)
- State machine pitfalls: "The State Explosion" problem and N+1 transition issues in chatbot workflows
- React drag-drop performance: Canvas optimization strategies, requestAnimationFrame, React.memo
- Multi-tenant RBAC: Security architecture for workflow builders, action-level permissions, policy externalization (OPA, Cerbos)
- WhatsApp API error handling: Meta Cloud API error codes (131000 series), webhook delivery failures
- LGPD healthcare compliance: ANPD guidelines, health data classification, automated decision requirements
- LLM context overflow: Context Window Overflow (CWO) prompt injection attacks, system prompt pinning
- State machine persistence: Multi-tenant session management, sticky versioning, optimistic locking
- Chatbot debugging: Session replay patterns, variable state tracking, visual flow path indicators

---

_Pitfalls research for: AI Flow Builder for Healthcare WhatsApp Automation_
_Researched: 2026-02-04_
