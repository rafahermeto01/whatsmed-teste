# Project Research Summary

**Project:** AI Flow Builder Milestone (WhatsMed)
**Domain:** Healthcare Practice Management SaaS with WhatsApp Automation
**Researched:** 2026-02-04
**Confidence:** HIGH

## Executive Summary

The AI Flow Builder is a node-based visual editor for creating WhatsApp conversation workflows that integrate with the existing WhatsMed healthcare SaaS platform. Expert implementations in 2025-2026 use state machine-driven flow execution (not simple DAGs) combined with AI-managed conversation orchestration, allowing flows to guide patient interactions while maintaining flexibility for natural dialogue. The recommended approach extends the existing validated stack (React, TanStack Start, Convex, Mastra) with a single strategic addition: **@xyflow/react** (React Flow) for the visual builder, leveraging the already-installed **@mastra/core** framework for flow execution.

Key risks identified include flow version mismatches breaking active patient conversations, AI context window overflow causing flow ejection, and cross-tenant data access vulnerabilities. Mitigation strategies include sticky versioning (pinning sessions to flow versions), pinned system prompts with context monitoring, and enforced tenant scoping at the database level. The architecture must balance healthcare compliance (audit trails, PHI redaction) with conversational flexibility (AI-managed execution vs rigid decision trees).

## Key Findings

### Recommended Stack

The stack extends the existing WhatsMed platform with minimal additions: **@xyflow/react** (v12.10.0) for the node-based visual builder, **@xyflow/react-ui** for pre-built AI workflow editor components, and a backend **Zod** upgrade to v4.1.13 for native JSON Schema conversion. Flow execution leverages the existing **@mastra/core** (v0.24.9) framework with its graph-based workflow orchestration, while **Convex** handles flow storage and real-time sync.

**Core technologies:**

- **@xyflow/react** — Node-based visual flow builder UI — Industry standard for workflow builders (35.1k GitHub stars), supports React 19, SSR, and Tailwind CSS 4
- **@mastra/core** (existing) — Graph-based workflow orchestration — Already installed with state machine support, parallel execution, conditional branching, and human-in-the-loop
- **Zod v4.1.13** — Schema validation with JSON Schema conversion — Native `toJSONSchema()`/`fromJSONSchema()` API eliminates external dependencies
- **Convex** (existing) — Flow storage and real-time sync — Multi-tenant isolation, indexed queries for performance, state persistence

### Expected Features

**Must have (table stakes):**

- Visual drag-and-drop canvas — Non-technical admins expect intuitive flow creation
- Basic node types (Message, Condition, Input, Wait) — Core building blocks for any flow
- Flow storage and management — CRUD operations for flows (create, edit, delete, activate)
- Variable system with patient data substitution — Personalized messages require dynamic content
- Flow validation — Prevent broken flows from saving
- Simple testing mode — Manual conversation simulation before activation
- Flow execution history — Audit trails for compliance and debugging
- AI-managed execution — Core differentiator: flow guides AI, not rigid step-by-step
- Flow activation toggles — Enable/disable specific flows

**Should have (competitive):**

- Healthcare node library — Pre-built nodes for appointments, prescriptions, triage
- Natural language flow templates — "Prompt-to-Flow" reduces learning curve
- Campaign flow mode — Integrates with existing marketing automation triggers
- WhatsApp Flows integration — Native in-chat forms for structured data collection
- Clinical handoff with context summary — Seamless human escalation

**Defer (v2+):**

- Complex branching and subflows — Advanced logic patterns (nice-to-have)
- Flow versioning and rollback — Production safety (implement basic versioning first)
- Flow analytics dashboard — Engagement metrics (after validation)
- Multi-node connections — Beyond basic branching

### Architecture Approach

The recommended architecture follows a state machine-driven pattern (2025 standard) with strict multi-tenant isolation. Flow execution is orchestrated through the existing Mastra framework, with flow definitions injected into the AI agent's system prompt via a `createClinicAgentWithFlow` factory pattern. The data model extends Convex with four new tables: `flows` (definitions), `flowVersions` (expand/contract versioning), `flowExecutions` (state tracking), and `flowTests` (isolated test data).

**Major components:**

1. **Flow Builder UI** — React Flow-based drag-and-drop editor with node palette, validation, and testing interface
2. **Flow Execution Engine** — State machine executor that traverses nodes, persists state, handles errors, and integrates with Mastra agents
3. **AI Flow Injector** — Converts flow definitions to structured prompt instructions and injects into Mastra agent system prompts
4. **Flow State Storage** — Convex-based persistence for active executions with real-time subscriptions for UI updates

### Critical Pitfalls

1. **Flow Version Mismatch** — Deploying new flow versions breaks active sessions. Avoid with sticky versioning: pin each session to the flow version at session start, store version in session state, and ensure only new sessions use new versions.
2. **AI Context Window Overflow** — Long conversations or large flows cause system prompt truncation, allowing patients to bypass flow controls. Avoid by pinning system prompt and flow instructions, implementing strict token limits, and monitoring token usage.
3. **Cross-Tenant Flow Access** — Missing tenant scoping allows one clinic to access another's data. Avoid by enforcing `WHERE clinicId = ?` on ALL database queries, using policy engines (OPA, Cerbos), and injecting tenant context at execution boundaries.
4. **Happy Path Trap** — Patients who deviate from expected flow get stuck in error loops. Avoid by implementing global intent listeners for help/cancel, using hybrid AI orchestration (state machine + LLM), and always providing escape hatches.
5. **WhatsApp Message Type Mismatches** — Provider differences (Evolution API vs Meta Cloud) cause silent failures. Avoid by building provider-agnostic abstraction layers, validating message formats, and monitoring both API responses and webhook notifications.

## Implications for Roadmap

Based on research, suggested phase structure:

### Phase 1: Flow Data Model & Storage

**Rationale:** All other phases depend on storage structure. This establishes the foundation for multi-tenant isolation, version tracking, and audit compliance.
**Delivers:** Convex tables (flows, flowVersions, flowExecutions), flow CRUD operations with RBAC enforcement, expand/contract versioning pattern
**Addresses:** Table stakes features (flow storage, variable system, flow execution history)
**Avoids:** Critical pitfall 3 (Cross-Tenant Access) by enforcing tenant scoping from day one, Critical pitfall 1 (Flow Version Mismatch) with sticky versioning in data model

### Phase 2: Flow Builder UI

**Rationale:** Users need to create flows before they can execute them. React Flow provides industry-standard capabilities for visual node-based editing.
**Delivers:** Drag-and-drop canvas using @xyflow/react, node palette (Message, Condition, Input, Wait), flow validation UI, basic testing interface
**Uses:** @xyflow/react, Tailwind CSS 4 (existing), Radix UI components (existing)
**Implements:** Architecture component "Flow Builder UI"
**Addresses:** Table stakes features (visual canvas, basic node types, validation, testing)

### Phase 3: Flow Execution Engine

**Rationale:** Flow engine must work independently before AI enhancement. This phase builds the state machine executor that handles node traversal, state persistence, and error recovery.
**Delivers:** State machine execution engine, flow orchestrator with Mastra agent integration, flow state persistence with Convex, error handling and retry logic
**Uses:** @mastra/core (existing), Convex (existing), Zod v4.1.13 (upgraded)
**Implements:** Architecture component "Flow Execution Engine"
**Addresses:** Table stakes features (AI-managed execution, variable substitution), Should-have features (Healthcare nodes)
**Avoids:** Critical pitfall 4 (Happy Path Trap) by implementing fallback branches and escape hatches

### Phase 4: Flow-AI Integration

**Rationale:** Flow execution engine must exist before AI enhancement. This phase injects flow definitions into the existing WhatsApp AI system prompts.
**Delivers:** `createClinicAgentWithFlow` factory pattern, flow-to-prompt instruction conversion, WhatsApp trigger system (message events, scheduled triggers), flow execution within conversation context
**Uses:** Existing Mastra agents, WhatsApp API (Evolution/Meta), Convex scheduler
**Implements:** Architecture component "AI Flow Injector"
**Addresses:** Table stakes feature (AI-managed execution), Should-have features (Campaign flow mode)
**Avoids:** Critical pitfall 2 (AI Context Window Overflow) by pinning system prompts and implementing token monitoring

### Phase 5: Flow Testing & Monitoring

**Rationale:** Monitoring tools provide feedback for all previous phases. Testing framework ensures confidence before activation.
**Delivers:** Flow testing framework with mock data, execution monitoring dashboard, flow performance analytics, error tracking and alerting
**Uses:** Convex real-time subscriptions, React Flow DevTools (built-in)
**Implements:** Architecture component "Flow Testing & Monitoring"
**Addresses:** Should-have features (Advanced testing with AI personas, Real-time debugging), Defer features (Flow analytics dashboard)

### Phase Ordering Rationale

- **Data model first (Phase 1):** All other phases depend on storage structure. Multi-tenant isolation and version tracking must be foundational.
- **UI before execution (Phase 2 → Phase 3):** Users need to create flows before they can run them. React Flow provides mature, well-documented capabilities.
- **Execution before AI integration (Phase 3 → Phase 4):** Flow engine must work independently before AI enhancement. This enables debugging execution logic separately from AI complexity.
- **Testing last (Phase 5):** Monitoring tools provide feedback for all previous phases. Testing framework builds on execution engine and state storage.
- **Grouping by architecture:** Each phase implements a major architectural component, enabling incremental validation and reducing risk.

### Research Flags

Phases likely needing deeper research during planning:

- **Phase 3 (Flow Execution Engine):** Mastra ↔ React Flow conversion optimal patterns (how to serialize React Flow JSON to Mastra Workflow definitions). Complex integration requiring adapter layer design.
- **Phase 4 (Flow-AI Integration):** Mastra agent runtime system prompt modification capabilities (can agents accept dynamic system prompt modifications at runtime without cache invalidation?). A/B testing needed for optimal prompt format.

Phases with standard patterns (skip research-phase):

- **Phase 1 (Flow Storage):** Convex schema patterns and multi-tenant isolation are well-documented. Expand/contract versioning is a standard pattern.
- **Phase 2 (Flow Builder UI):** React Flow is mature with extensive documentation (35.1k GitHub stars). AI Workflow Editor template exists as starting point.
- **Phase 5 (Flow Testing & Monitoring):** React Flow DevTools are built-in. Performance monitoring patterns for flows are well-established.

## Confidence Assessment

| Area         | Confidence | Notes                                                                                                                                                                                              |
| ------------ | ---------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Stack        | HIGH       | Official docs for @xyflow/react, @mastra/core, and Convex. Zod v4 features verified via web search. Package.json analysis confirms existing installations.                                         |
| Features     | HIGH       | React Flow documentation confirms table stakes capabilities. Competitor analysis (Voiceflow, Salesforce Flow) validates feature expectations. Meta 2026 policies verified via official docs.       |
| Architecture | HIGH       | State machine patterns and Mastra integration are standard. Convex multi-tenant patterns are well-documented. Flow injection pattern is technically feasible but requires runtime verification.    |
| Pitfalls     | HIGH       | Five critical pitfalls identified with specific prevention strategies. Technical debt patterns and security mistakes documented with alternatives. Warning signs and recovery strategies provided. |

**Overall confidence:** HIGH

### Gaps to Address

- **Mastra ↔ React Flow conversion:** How to optimally serialize React Flow JSON to Mastra Workflow definitions? Complex integration requiring adapter layer design. Handle during Phase 3 planning.
- **Mastra agent runtime system prompt modification:** Can Mastra agents accept dynamic system prompt modifications at runtime, or does agent recreation cause cache invalidation issues? Requires A/B testing during Phase 4.
- **Flow-to-AI prompt injection format:** What's the optimal format for injecting flows into AI system prompts without overwhelming context window? Dependent on LLM provider, may need iteration during Phase 4.
- **Flow versioning strategy for active sessions:** How to handle flow schema migrations while preserving in-flight executions? Convex schema design question to resolve during Phase 1 planning.
- **Healthcare compliance audit logging:** Additional audit logging requirements for flow executions in healthcare context (HIPAA/LGPD)? Legal review needed during Phase 1.

## Sources

### Primary (HIGH confidence)

- React Flow Official Documentation — Visual flow builder capabilities, DevTools, performance optimization, AI Workflow Editor template
- Mastra Framework Documentation — Workflow orchestration, agent factory pattern, system prompt injection, graph-based execution
- Convex Official Documentation — Multi-tenant patterns, schema design, indexing strategies, real-time subscriptions
- Zod v4 GitHub Repository — `toJSONSchema()`/`fromJSONSchema()` API, GlobalRegistry, Zod Mini for edge validation
- Meta WhatsApp Business Platform 2026 Policy — General-purpose AI ban, Portfolio Pacing, message type constraints, pricing changes
- WhatsMed Existing Codebase — CampaignBuilderModal.tsx (variable system), automation.ts (multi-tenant patterns), agents.ts (Mastra integration)

### Secondary (MEDIUM confidence)

- 2026 Flow Builder UX Patterns (WebSearch) — Intelligent assembly, animated connectors, undo/redo expectations
- Healthcare Chatbot Node Types 2026 (WebSearch) — Specialized nodes for appointments, prescriptions, triage
- Flow Execution State Management 2026 (WebSearch) — Durable execution patterns, event sourcing, state persistence
- Conversational vs Campaign Flow Differences 2026 (WebSearch) — Real-time dialogue vs scheduled outreach semantics
- React Flow vs dnd-kit Comparison 2026 (WebSearch) — Why dnd-kit is unsuitable for node-based flows
- Graph Traversal Engines 2026 (WebSearch) — State machine vs DAG approaches, cycle handling
- JSON Schema Validation 2026 (WebSearch) — Schema evolution, bi-directional conversion patterns

### Tertiary (LOW confidence)

- Flow activation strategies 2026 — Single source discussing intent-based activation; need to verify with implementation testing
- Mastra agent cache invalidation behavior — Single source suggests runtime prompt modification possible; needs validation

---

_Research completed: 2026-02-04_
_Ready for roadmap: yes_
