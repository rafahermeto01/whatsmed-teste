# Architecture Research

**Domain:** AI Flow Builder for Healthcare Practice Management SaaS
**Researched:** 2025-02-04
**Overall confidence:** HIGH

## Executive Summary

AI Flow Builder must integrate seamlessly into the existing WhatsMed healthcare SaaS platform, which uses TanStack Start for the frontend, Convex for the backend, and Mastra framework for the WhatsApp AI system. The integration requires careful architectural planning to ensure:

1. **Flow data model** extends the existing Convex schema without breaking changes
2. **Flow execution engine** leverages the existing WhatsApp AI infrastructure (Mastra agents and tools)
3. **Multi-tenant isolation** maintains the clinic-scoped architecture pattern used throughout the platform
4. **Flow-AI integration** injects flow definitions into the existing AI agent system prompts
5. **State management** for active flows uses Convex's real-time subscriptions and query capabilities

The recommended architecture follows a **state-machine-driven approach** (2025 standard) rather than simple DAGs, enabling loops, human-in-the-loop scenarios, and error recovery. Flow execution is orchestrated through the existing Mastra framework with new flow-specific tools and a flow execution layer that handles state persistence, error recovery, and flow injection into AI prompts.

## Key Findings

**Stack:** TanStack Start (React), Convex backend, Mastra AI framework, TypeScript
**Architecture:** State machine-driven flow execution with tenant-scoped isolation
**Critical integration point:** Flow injection into existing Mastra agent system prompts via system prompt enhancement
**Primary challenge:** Balancing flow flexibility (dynamic branching) with healthcare compliance (audit trails, deterministic behavior)

## Implications for Roadmap

Based on research, suggested phase structure:

1. **Phase 1: Flow Data Model & Storage** - Addresses: Convex schema extensions, multi-tenant isolation, flow versioning
   - Create flow definitions, flow versions, flow executions, flow state tables
   - Implement flow CRUD operations with RBAC enforcement
   - Add flow versioning support (expand/contract pattern)

2. **Phase 2: Flow Builder UI** - Addresses: Flow editor, node palette, drag-drop interface
   - Build React-based flow builder with TanStack Router integration
   - Implement node library (triggers, AI actions, database actions, branching)
   - Create flow validation and testing interface

3. **Phase 3: Flow Execution Engine** - Addresses: State machine execution, error handling, flow injection into AI
   - Build flow orchestrator that integrates with Mastra agents
   - Implement flow state persistence and recovery
   - Create flow-to-AI prompt injection mechanism

4. **Phase 4: Flow-AI Integration** - Addresses: WhatsApp AI enhancement, flow triggering, context injection
   - Extend Mastra agents to support flow-based instructions
   - Implement flow trigger system (message events, scheduled triggers, webhook triggers)
   - Create flow execution within WhatsApp conversation context

5. **Phase 5: Flow Testing & Monitoring** - Addresses: Flow testing tools, execution monitoring, analytics
   - Build flow testing framework with mock data
   - Create execution monitoring dashboard
   - Add flow performance analytics and error tracking

**Phase ordering rationale:**

- Data model first: All other phases depend on storage structure
- UI before execution: Users need to create flows before they can run them
- Execution before AI integration: Flow engine must work independently before AI enhancement
- Testing last: Monitoring tools provide feedback for all previous phases

**Research flags for phases:**

- Phase 3: Likely needs deeper research on Convex's internal action scheduling capabilities for long-running flows
- Phase 4: Standard patterns exist for AI flow integration, but healthcare compliance may require additional audit logging
- Phase 5: Performance monitoring patterns for flows are well-established, but healthcare-specific metrics need consideration

## Confidence Assessment

| Area                   | Confidence | Notes                                                                                                                               |
| ---------------------- | ---------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| Data Model             | HIGH       | Convex schema patterns are well-documented; flow tables follow existing multi-tenant patterns                                       |
| Execution Engine       | HIGH       | State machine patterns and Mastra integration are standard (HIGH confidence from multiple sources)                                  |
| AI Integration         | MEDIUM     | Flow injection into AI prompts is technically feasible, but Mastra's extensibility for dynamic system prompts requires verification |
| Multi-tenant Isolation | HIGH       | Existing clinic-scoped patterns can be applied to flows (Row-Level Security is documented)                                          |
| Performance            | MEDIUM     | Flow execution performance depends on Convex limits; real-world benchmarks needed for high-volume scenarios                         |

## Gaps to Address

- **Convex internal actions scheduling**: How to schedule long-running flow executions (Convex doesn't have native workflow orchestration like Temporal)
- **Mastra agent extensibility**: Can Mastra agents accept dynamic system prompt modifications at runtime, or does agent recreation cause cache invalidation issues?
- **Flow-to-AI prompt injection**: Best practice for injecting flow definitions into AI prompts without overwhelming context window
- **Flow testing framework**: How to mock Convex database for flow testing in CI/CD pipelines
- **Healthcare compliance**: Additional audit logging requirements for flow executions in a healthcare context (HIPAA/GDPR considerations)

---

# Architecture Patterns

**Domain:** AI Flow Builder for Healthcare Practice Management SaaS
**Researched:** 2025-02-04
**Confidence:** HIGH

## Standard Architecture

### System Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    Frontend Layer                         │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐ │
│  │ Flow    │  │ Flow    │  │ Admin   │  │ Chat    │ │
│  │ Builder │  │ Tester  │  │ Dashboard│  │ UI      │ │
│  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘ │
│       │            │            │            │          │     │
├───────┴────────────┴────────────┴────────────┴──────────┤
│                    API Layer                            │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────┐  │
│  │         Convex Backend Server                    │  │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  │  │
│  │  │ Flow    │  │ Flow    │  │ AI Flow  │  │  │
│  │  │ CRUD    │  │ Exec    │  │ Inject   │  │  │
│  │  └────┬────┘  └────┬────┘  └────┬────┘  │  │
│  │       │            │            │          │      │  │
│  │  ┌────┴────────────┴────────────┴──────────┐  │  │
│  │  │         Mastra AI Framework            │  │  │
│  │  │  (Agents + Tools + Workflow)        │  │  │
│  │  └────┬──────────────┬────────────────┘  │  │
│  │       │              │                   │      │
│  │  ┌────┴─────┐  ┌────┴─────┐        │      │
│  │  │ Existing  │  │  Flow     │        │      │
│  │  │ Agents   │  │ Tools     │        │      │
│  │  └──────────┘  └───────────┘        │      │
├─────────────────────────────────────────────────────────────┤
│                  Convex Database                        │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────┐  ┌─────────┐  ┌─────────┐        │
│  │ flows    │  │ flow     │  │ flow     │        │
│  │          │  │ versions │  │ executions│        │
│  └──────────┘  └──────────┘  └──────────┘        │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐        │
│  │ flow     │  │ existing │  │ existing │        │
│  │ state    │  │ tables  │  │ tables  │        │
│  └──────────┘  └──────────┘  └──────────┘        │
└─────────────────────────────────────────────────────────────┘
```

### Component Responsibilities

| Component             | Responsibility                                                  | Typical Implementation                                                        |
| --------------------- | --------------------------------------------------------------- | ----------------------------------------------------------------------------- |
| Flow Builder UI       | Drag-and-drop flow editor, node palette, validation             | React components with TanStack Router state management                        |
| Flow Tester UI        | Mock data injection, step-by-step execution, debugging          | React component with Convex queries for test data                             |
| Flow CRUD Operations  | Create/read/update/delete flows with RBAC enforcement           | Convex queries and mutations with multi-tenant checks                         |
| Flow Execution Engine | State machine execution, error handling, state persistence      | Convex internal actions with Mastra agent integration                         |
| AI Flow Injector      | Enhances Mastra agent system prompts with flow definitions      | Mastra agent factory modification with flow context                           |
| Flow Orchestrator     | Manages active flow executions, handles retries, triggers flows | Convex scheduler for time-based triggers, webhook handlers for event triggers |
| Flow State Storage    | Persist flow execution state, supports time-travel debugging    | Convex table with clinicId-scoped queries                                     |
| Flow Versioning       | Manages flow schema versions, enables rollback                  | Expand/contract pattern with migration tables                                 |

## Recommended Project Structure

```
packages/backend/convex/
├── flows.ts                    # Flow CRUD operations (queries/mutations)
├── flowsInternal.ts            # Internal flow operations (no auth)
├── flowExecutions.ts           # Flow execution tracking
├── flowExecutionsInternal.ts    # Internal execution operations
├── flowVersions.ts             # Flow version management
├── flowTriggers.ts            # Flow trigger handling
├── flowTesting.ts             # Flow test execution
├── lib/
│   ├── flow/
│   │   ├── executor.ts        # Flow execution engine
│   │   ├── stateManager.ts    # Flow state persistence
│   │   ├── aiInjector.ts      # Flow-to-AI prompt integration
│   │   ├── validator.ts      # Flow validation logic
│   │   ├── versioning.ts      # Flow version management
│   │   └── types.ts         # Flow type definitions
│   └── flowNodes/
│       ├── triggers.ts         # Trigger node implementations
│       ├── aiActions.ts       # AI action node implementations
│       ├── dbActions.ts       # Database action node implementations
│       ├── branching.ts       # Branching node implementations
│       └── testing.ts        # Testing node implementations
├── flowTools.ts              # Mastra tools for flow execution
└── schema.ts                  # Add flow tables to existing schema
```

apps/web/
├── app/
│ ├── routes/
│ │ ├── flows/
│ │ │ ├── index.tsx # Flow list view
│ │ │ ├── new.tsx # New flow creation
│ │ │ ├── $id.tsx # Flow detail/edit view
│ │ │ ├── $id/
│ │ │ │ ├── test.tsx # Flow testing interface
│ │ │ │ ├── versions.tsx # Flow version history
│ │ │ │ └── executions.tsx # Execution history
│ │ │ └── templates.tsx # Flow template library
│ │ └── ...
│ └── ...
├── components/
│ └── flowBuilder/
│ ├── FlowCanvas.tsx # Main flow canvas (React Flow)
│ ├── NodePalette.tsx # Draggable node library
│ ├── NodeEditor.tsx # Individual node editor
│ ├── EdgeEditor.tsx # Connection editor
│ ├── FlowValidator.tsx # Flow validation UI
│ ├── FlowTester.tsx # Test execution UI
│ └── nodes/
│ ├── TriggerNode.tsx
│ ├── AIActionNode.tsx
│ ├── DBActionNode.tsx
│ ├── BranchNode.tsx
│ └── ...
├── lib/
│ └── flow/
│ ├── flowTypes.ts # Shared flow TypeScript types
│ ├── flowClient.ts # Convex flow client wrappers
│ └── flowValidation.ts # Client-side validation
└── packages/backend/mastra/
├── flowAgents.ts # Mastra agents with flow integration
└── flowTools.ts # Flow-specific Mastra tools

````

### Structure Rationale

- **convex/flows.ts, flowsInternal.ts**: Follow existing pattern (automation.ts, automationInternal.ts) for public/internal operation separation
- **lib/flow/**: Shared flow logic isolated from individual feature files, reusability across execution, testing, and validation
- **lib/flowNodes/**: Node implementations organized by type (triggers, actions, branching) - easy to extend with new node types
- **flowTools.ts**: Flow-specific Mastra tools integrate with existing tools.ts pattern
- **apps/web/app/routes/flows/**: Follow TanStack Router conventions, nested routes for flow management
- **components/flowBuilder/**: React Flow-based builder components, organized by UI element
- **lib/flow/**: Shared client-side logic, TypeScript types shared between frontend and backend via import
- **packages/backend/mastra/flowAgents.ts**: Mastra agent extensions for flow integration, parallel to existing agents.ts

## Architectural Patterns

### Pattern 1: State Machine-Driven Flow Execution

**What:** Flows are modeled as state machines rather than DAGs (Directed Acyclic Graphs). Each node represents a state transition, and the execution engine tracks current state, allowing loops, retries, and human-in-the-loop scenarios.

**When to use:**
- Flows require conditional branching based on runtime values
- Flows need to handle errors and retry specific nodes
- Flows include loops (e.g., retry payment 3 times)
- Flows require human approval mid-execution

**Trade-offs:**
- **Pros:** Supports cycles, error recovery, long-running workflows, clear audit trail (event sourcing)
- **Cons:** More complex to implement than DAGs, requires careful state management

**Example:**
```typescript
// Flow execution state machine
type FlowState =
  | { type: "idle" }
  | { type: "executing"; currentNodeId: string; context: Record<string, any> }
  | { type: "waiting_for_input"; nodeId: string; context: Record<string, any> }
  | { type: "completed"; result: any }
  | { type: "error"; error: string; nodeId?: string };

// Flow executor with state persistence
async function executeFlow(flowId: string, ctx: MutationCtx) {
  let state: FlowState = { type: "executing", currentNodeId: flow.startNodeId, context: {} };

  // Persist initial state
  await ctx.db.insert("flowExecutions", { flowId, state, timestamp: Date.now() });

  while (state.type === "executing") {
    const node = await getNode(state.currentNodeId);
    const result = await executeNode(node, state.context);

    if (result.type === "next_node") {
      state = { type: "executing", currentNodeId: result.nextNodeId, context: result.context };
    } else if (result.type === "wait_for_input") {
      state = { type: "waiting_for_input", nodeId: state.currentNodeId, context: result.context };
    } else if (result.type === "error") {
      state = { type: "error", error: result.error, nodeId: state.currentNodeId };
    } else if (result.type === "complete") {
      state = { type: "completed", result: result.value };
    }

    // Persist state after each transition
    await ctx.db.patch(executionId, { state, timestamp: Date.now() });
  }
}
````

### Pattern 2: Flow Injection into AI Prompts

**What:** Flow definitions are converted into structured instructions and injected into the Mastra agent's system prompt, allowing the AI to follow flow logic while maintaining natural conversation.

**When to use:**

- Flows guide AI conversations (e.g., qualification flows, triage flows)
- Flows need to be flexible (AI interprets flow context rather than rigid step-by-step execution)
- Flows require natural language understanding while maintaining structure

**Trade-offs:**

- **Pros:** Maintains AI flexibility, flows adapt to patient responses, leverages existing Mastra infrastructure
- **Cons:** Flow instructions consume token budget, may cause conflicting instructions with agent base prompt

**Example:**

```typescript
// Mastra agent factory with flow injection (modification of existing createClinicAgent)
export function createClinicAgentWithFlow(
  settings: any,
  tools: any,
  flow: FlowDefinition | null,
  systemPromptOverride?: string,
  context?: any,
) {
  // Base instructions from existing agent
  const basePrompt = getBasePrompt(settings, context);

  // Inject flow instructions if flow provided
  let flowInstructions = "";
  if (flow) {
    flowInstructions = `
CONTEXTO DO FLUXO DE CONVERSA:
Você deve seguir este fluxo de conversa estruturado enquanto atende o paciente:

${flowToPromptInstructions(flow)}

REGRAS CRÍTICAS:
- Siga os passos do fluxo em ordem
- Se o paciente der uma resposta inesperada, tente adaptar mantendo o objetivo do passo atual
- Se o fluxo indicar uma ação (ex: agendar), execute-a usando as ferramentas disponíveis
- Se o fluxo tiver condições (if/else), avalie a resposta do paciente para determinar o caminho
- Sempre mantenha empatia e profissionalismo
`;
  }

  // Combine instructions
  const instructions = systemPromptOverride || basePrompt + flowInstructions;

  // Create agent with enhanced instructions
  const agent = new Agent({
    name: `clinic-agent-${settings.clinicId}${flow ? "-flow" : ""}`,
    instructions,
    model: MASTRA_CONFIG.models.agent,
    tools: filterTools(tools, flow?.enabledTools),
  });

  return agent;
}

// Convert flow definition to prompt instructions
function flowToPromptInstructions(flow: FlowDefinition): string {
  let prompt = "";

  // Traverse flow and build instructions
  for (const node of flow.nodes) {
    if (node.type === "ai_message") {
      prompt += `PASSO ${node.id}: Enviar esta mensagem: "${node.data.message}"\n`;
    } else if (node.type === "condition") {
      prompt += `PASSO ${node.id}: Avaliar condição: "${node.data.condition}"\n`;
      prompt += `  - Se verdadeiro: vá para ${node.data.trueBranch}\n`;
      prompt += `  - Se falso: vá para ${node.data.falseBranch}\n`;
    } else if (node.type === "ai_action") {
      prompt += `PASSO ${node.id}: Executar ação de IA: ${node.data.action}\n`;
    }
  }

  return prompt;
}
```

### Pattern 3: Multi-Tenant Flow Isolation

**What:** Flows are strictly isolated per clinic using Convex's query patterns and RBAC enforcement, preventing cross-clinic flow access or execution.

**When to use:**

- Multi-tenant SaaS platform (already established pattern in WhatsMed)
- Healthcare data compliance requires strict tenant isolation
- Flows contain clinic-specific business logic or PII

**Trade-offs:**

- **Pros:** Security by design, compliance-ready, scales with existing patterns
- **Cons:** Every query must include clinicId, potential for query mistakes

**Example:**

```typescript
// Flow CRUD with multi-tenant isolation (pattern from existing automation.ts)
export const createFlow = mutation({
  args: {
    clinicId: v.string(), // Enforced by RBAC
    name: v.string(),
    description: v.optional(v.string()),
    nodes: v.array(
      v.object({
        /* ... */
      }),
    ),
    edges: v.array(
      v.object({
        /* ... */
      }),
    ),
  },
  handler: async (ctx, args) => {
    // Get authenticated user and clinic
    const { clinicId, user } = await getAuth(ctx);

    // Enforce: user can only create flows for their own clinic
    if (args.clinicId !== clinicId) {
      throw forbidden("Cannot create flow for different clinic");
    }

    // Enforce RBAC: only admin/staff can create flows
    if (!["admin", "staff", "super_admin"].includes(user.role)) {
      throw forbidden("Insufficient permissions to create flows");
    }

    // Insert flow with clinicId (multi-tenant isolation)
    const flowId = await ctx.db.insert("flows", {
      clinicId,
      name: args.name,
      description: args.description,
      nodes: args.nodes,
      edges: args.edges,
      status: "draft",
      version: 1,
      createdAt: Date.now(),
      createdBy: user._id,
    });

    return flowId;
  },
});

// Flow query with multi-tenant filtering
export const listFlows = query({
  args: {
    clinicId: v.string(),
    status: v.optional(v.union(v.literal("draft"), v.literal("active"), v.literal("archived"))),
  },
  handler: async (ctx, args) => {
    const { clinicId } = await getAuth(ctx);

    // Enforce: user can only list their own clinic's flows
    if (args.clinicId !== clinicId) {
      return []; // Return empty instead of error for security
    }

    // Query flows with clinicId index
    let query = ctx.db
      .query("flows")
      .withIndex("by_clinic_status", (q) => q.eq("clinicId", clinicId));

    if (args.status) {
      query = query.eq("status", args.status);
    }

    const flows = await query.collect();
    return flows;
  },
});
```

### Pattern 4: Flow Versioning with Expand/Contract

**What:** Flow schema changes are managed with expand/contract pattern to support multiple flow versions running simultaneously without breaking changes.

**When to use:**

- Flows are long-running (may span hours or days)
- Flow execution engine is deployed independently from flow editor
- Need to support flow rollback without affecting active executions

**Trade-offs:**

- **Pros:** Zero-downtime deployments, supports in-flight flows, easy rollback
- **Cons:** Requires migration strategy, increases storage complexity

**Example:**

```typescript
// Flow versioning schema
export const flowVersions = defineTable({
  clinicId: v.string(),
  flowId: v.id("flows"),
  version: v.number(),
  nodes: v.array(
    v.object({
      /* ... */
    }),
  ),
  edges: v.array(
    v.object({
      /* ... */
    }),
  ),
  schemaVersion: v.number(), // For flow data structure migrations
  status: v.union(v.literal("draft"), v.literal("published"), v.literal("deprecated")),
  createdAt: v.number(),
  createdBy: v.id("users"),
})
  .index("by_flow_version", ["flowId", "version"])
  .index("by_clinic_status", ["clinicId", "status"]);

// Flow version manager
export const createFlowVersion = internalMutation({
  args: {
    clinicId: v.string(),
    flowId: v.id("flows"),
    nodes: v.array(
      v.object({
        /* ... */
      }),
    ),
    edges: v.array(
      v.object({
        /* ... */
      }),
    ),
  },
  handler: async (ctx, args) => {
    // Get current version
    const currentVersion = await ctx.db
      .query("flowVersions")
      .withIndex("by_flow_version", (q) => q.eq("flowId", args.flowId).order("desc"))
      .first();

    const newVersion = currentVersion ? currentVersion.version + 1 : 1;

    // Insert new version
    await ctx.db.insert("flowVersions", {
      clinicId: args.clinicId,
      flowId: args.flowId,
      version: newVersion,
      nodes: args.nodes,
      edges: args.edges,
      schemaVersion: CURRENT_FLOW_SCHEMA_VERSION,
      status: "draft",
      createdAt: Date.now(),
      createdBy: await getCurrentUserId(ctx),
    });

    return newVersion;
  },
});

// Flow retrieval respects active version
export const getActiveFlow = internalQuery({
  args: {
    clinicId: v.string(),
    flowId: v.id("flows"),
  },
  handler: async (ctx, args) => {
    const flow = await ctx.db.get(args.flowId);
    if (!flow || flow.clinicId !== args.clinicId) {
      return null;
    }

    // Get published version
    const publishedVersion = await ctx.db
      .query("flowVersions")
      .withIndex("by_flow_version", (q) => q.eq("flowId", args.flowId).eq("status", "published"))
      .first();

    if (!publishedVersion) {
      return flow; // Return draft if no published version
    }

    return {
      ...flow,
      nodes: publishedVersion.nodes,
      edges: publishedVersion.edges,
      version: publishedVersion.version,
    };
  },
});
```

## Data Flow

### Request Flow: Flow Creation

```
User (Admin/Staff)
    ↓
[Flow Builder UI] → Validates flow (client + server)
    ↓                         ↓
[Flow CRUD] → Insert flows table (with clinicId)
    ↓              ↓
[Flow Version Manager] → Create initial version (draft)
    ↓
[Response] ← Flow ID and version
```

### Request Flow: Flow Execution via WhatsApp

```
Incoming WhatsApp Message
    ↓
[Webhook Handler] → Identify clinic
    ↓                    ↓
[Flow Trigger Handler] → Check for active flow triggers
    ↓                    ↓
[Match Found?] → Yes → [Flow Executor]
    ↓                    ↓         ↓
[Flow State Manager] → Persist execution state
    ↓                    ↓
[AI Flow Injector] → Enhance agent prompt with flow
    ↓                    ↓
[Mastra Agent] → Generate response (follows flow)
    ↓                    ↓
[WhatsApp Sender] → Send response
    ↓                    ↓
[Flow State Manager] → Update state (complete/wait/error)
    ↓
[Response] ← Flow execution result
```

### State Management: Active Flow Execution

```
[Convex Database: flowExecutions table]
    ↓ (real-time subscription)
[Flow Builder UI: Flow Monitor]
    ← (updates)
    ↓
[Execution Status] → Running/Completed/Errored/Waiting
    ↓
[State Display] → Current node, variables, logs
```

### Key Data Flows

1. **Flow Definition Flow:** User creates flow in UI → Validation → Insert into flows table → Create initial version in flowVersions table → Return flow ID to UI
2. **Flow Publishing Flow:** User publishes flow → Validate → Insert new version with status="published" → Update flows table with activeVersionId → Flow becomes executable
3. **Flow Execution Flow:** Trigger fires → Load flow definition → Create flowExecution record → Execute nodes sequentially → Update state after each node → Complete or error → Mark execution finished
4. **Flow-AI Integration Flow:** WhatsApp message received → Check for active flow trigger → Load flow → Convert to prompt instructions → Create agent with flow-enhanced prompt → Generate response → Send response
5. **Flow Testing Flow:** User initiates test → Load flow → Create test execution → Execute with mock data → Display step-by-step results → Allow debugging and variable inspection

## Scaling Considerations

| Scale                    | Architecture Adjustments                                                                                                   |
| ------------------------ | -------------------------------------------------------------------------------------------------------------------------- |
| 0-1k flows per clinic    | Single Convex database is sufficient; use clinicId indexes for all queries                                                 |
| 1k-100k flows per clinic | Consider partitioning flowExecutions by timestamp for efficient cleanup; add caching for frequently-used flow definitions  |
| 100k+ flows per clinic   | Migrate flow definitions to separate storage (e.g., dedicated table or external cache); use read replicas for flow queries |

### Scaling Priorities

1. **First bottleneck: Flow execution state persistence** - Every node transition writes to flowExecutions table. Solution: Batch state updates, use Convex's vector writes for multiple state changes.
2. **Second bottleneck: Flow trigger evaluation** - Every WhatsApp message may trigger flow evaluation. Solution: Cache active flow triggers per clinic, use indexed queries for fast matching.
3. **Third bottleneck: AI prompt injection** - Large flows generate long prompt instructions. Solution: Summarize flow for AI, only inject relevant sub-flows based on conversation state.

## Anti-Patterns

### Anti-Pattern 1: Embedding Flow Logic in Agent System Prompt

**What people do:** Store entire flow definition (all nodes, edges, logic) in the Mastra agent's system prompt as text instructions.

**Why it's wrong:**

- Consumes excessive tokens (large flows can exceed context window)
- Cannot dynamically adapt flow at runtime without recreating agent
- Conflicts with agent's base instructions, causing unpredictable behavior
- Hard to debug (prompt is opaque, errors are vague)

**Do this instead:**
Use flow injection pattern: Convert flow to structured instructions, inject only relevant parts based on conversation state, maintain agent separation from flow logic. Use flow context variables to track position in flow without re-injecting entire flow.

### Anti-Pattern 2: Global Flow Execution Without Tenant Isolation

**What people do:** Create a single flow executor that doesn't filter by clinicId, allowing cross-tenant flow access.

**Why it's wrong:**

- **Security risk:** Clinic A could access Clinic B's flows
- **Compliance violation:** Healthcare data isolation is mandatory (HIPAA/LGPD)
- **Performance impact:** Unbounded queries across all tenant data
- **Auditability:** Cannot track which clinic executed which flow

**Do this instead:**
Enforce clinicId on ALL flow operations: queries, mutations, executions, triggers. Use Convex's index patterns (by_clinic_status) for filtering. Validate clinicId at every entry point (RBAC enforcement).

### Anti-Pattern 3: Synchronous Flow Execution in Webhook Handler

**What people do:** Execute entire flow synchronously in the WhatsApp webhook handler, blocking the webhook response until flow completes.

**Why it's wrong:**

- **Timeout risk:** Webhooks have short timeouts (30-60s), flows may take longer
- **Blocking:** Incoming messages queue behind long-running flow executions
- **No progress visibility:** UI cannot show flow status until it completes
- **Error recovery:** If webhook fails, flow state is lost

**Do this instead:**
Asynchronous execution pattern: Webhook receives message → Creates flowExecution record with status="pending" → Returns 200 immediately → Flow executor processes in background → Updates execution state → UI polls for status via Convex real-time subscriptions.

### Anti-Pattern 4: No Flow Versioning for Active Executions

**What people do:** Update flow definition directly, affecting in-flight executions immediately.

**Why it's wrong:**

- **Inconsistent behavior:** In-flight executions use mixed old/new logic
- **Debugging nightmare:** Cannot reproduce bugs because flow changed
- **No rollback:** If new flow has bugs, all executions fail
- **Compliance issue:** Cannot audit which flow version was used for which patient interaction

**Do this instead:**
Version all flow changes: Create new version in flowVersions table → Mark as "published" → Update flows table with activeVersionId → In-flight executions continue with their version → New executions use new version → Support rollback by switching activeVersionId.

## Integration Points

### Internal Boundaries

| Boundary                                   | Communication                                                 | Notes                                                        |
| ------------------------------------------ | ------------------------------------------------------------- | ------------------------------------------------------------ |
| Flow Builder UI ↔ Flow CRUD                | Convex mutations (createFlow, updateFlow, deleteFlow)         | Enforce RBAC, validate clinicId before operations            |
| Flow Execution Engine ↔ Mastra Agents      | Agent factory with flow injection (createClinicAgentWithFlow) | Cache agents per flow version, invalidate on flow publish    |
| Flow Execution Engine ↔ Flow State Storage | Convex mutations (createExecution, updateExecutionState)      | Use indexed queries for efficient state retrieval            |
| WhatsApp AI ↔ Flow Triggers                | Hook into processIncomingAiMessage, check for active flows    | Trigger evaluation must be fast (cached per clinic)          |
| Flow Tester UI ↔ Flow Testing              | Test execution with mock data (testFlow mutation)             | Isolate test data from production, no WhatsApp messages sent |
| Flow Executor ↔ Convex Scheduler           | Scheduled triggers via ctx.scheduler.runAfter                 | Use for time-based triggers (e.g., follow-up flows)          |

### External Services

| Service                            | Integration Pattern                   | Notes                                                          |
| ---------------------------------- | ------------------------------------- | -------------------------------------------------------------- |
| WhatsApp Provider (Evolution/Meta) | Existing whatsapp.ts actions          | Flow can send messages via existing sendWhatsApp tool          |
| Convex Storage                     | File storage for flow exports/imports | Use storage API for flow template sharing                      |
| OpenAI (GPT-4o)                    | Existing Mastra integration           | Flow instructions injected into system prompt, model unchanged |

## Database Schema Extensions

### New Tables for Flow Builder

```typescript
// Flow definitions (tenant-scoped)
flows: defineTable({
  clinicId: v.string(), // Multi-tenant isolation
  name: v.string(),
  description: v.optional(v.string()),
  status: v.union(v.literal("draft"), v.literal("active"), v.literal("archived")),
  activeVersionId: v.optional(v.id("flowVersions")),
  triggerType: v.union(
    v.literal("message"),
    v.literal("schedule"),
    v.literal("webhook"),
    v.literal("manual"),
  ),
  triggerConfig: v.optional(v.any()), // JSON config based on triggerType
  tags: v.optional(v.array(v.string())),
  createdAt: v.number(),
  updatedAt: v.optional(v.number()),
  createdBy: v.id("users"),
  updatedBy: v.optional(v.id("users")),
})
  .index("by_clinic_status", ["clinicId", "status"])
  .index("by_clinic_createdAt", ["clinicId", "createdAt"])
  .searchIndex("search_name", {
    searchField: "name",
    filterFields: ["clinicId"],
  }),

// Flow versions (expand/contract pattern)
flowVersions: defineTable({
  clinicId: v.string(),
  flowId: v.id("flows"),
  version: v.number(),
  nodes: v.array(v.object({
    id: v.string(),
    type: v.string(),
    position: v.object({ x: v.number(), y: v.number() }),
    data: v.any(), // Node-specific config
  })),
  edges: v.array(v.object({
    id: v.string(),
    source: v.string(),
    target: v.string(),
    condition: v.optional(v.any()), // Branch condition
  })),
  schemaVersion: v.number(), // Flow data structure version
  status: v.union(v.literal("draft"), v.literal("published"), v.literal("deprecated")),
  changelog: v.optional(v.string()),
  createdAt: v.number(),
  createdBy: v.id("users"),
  publishedAt: v.optional(v.number()),
})
  .index("by_flow_version", ["flowId", "version"])
  .index("by_clinic_status", ["clinicId", "status"]),

// Flow executions (state tracking)
flowExecutions: defineTable({
  clinicId: v.string(),
  flowId: v.id("flows"),
  flowVersionId: v.id("flowVersions"),
  executionId: v.string(), // External ID for tracking
  status: v.union(
    v.literal("pending"),
    v.literal("running"),
    v.literal("waiting"),
    v.literal("completed"),
    v.literal("error"),
    v.literal("cancelled"),
  ),
  currentNodeId: v.optional(v.string()),
  state: v.any(), // Flow execution state (variables, context)
  logs: v.array(v.object({
    nodeId: v.string(),
    timestamp: v.number(),
    level: v.union(v.literal("info"), v.literal("warn"), v.literal("error")),
    message: v.string(),
    data: v.optional(v.any()),
  })),
  error: v.optional(v.object({
    nodeId: v.string(),
    error: v.string(),
    stack: v.optional(v.string()),
  })),
  triggerType: v.union(
    v.literal("message"),
    v.literal("schedule"),
    v.literal("webhook"),
    v.literal("manual"),
  ),
  triggerContext: v.optional(v.any()), // Trigger-specific data (message, schedule, etc.)
  startedAt: v.number(),
  completedAt: v.optional(v.number()),
  createdBy: v.id("users"),
})
  .index("by_flow_createdAt", ["flowId", "startedAt"])
  .index("by_clinic_status", ["clinicId", "status"])
  .index("by_executionId", ["executionId"]),

// Flow tests (isolated test data)
flowTests: defineTable({
  clinicId: v.string(),
  flowId: v.id("flows"),
  flowVersionId: v.id("flowVersions"),
  testId: v.string(),
  status: v.union(v.literal("running"), v.literal("passed"), v.literal("failed")),
  mockData: v.any(), // Test input data
  results: v.optional(v.array(v.object({
    nodeId: v.string(),
    status: v.union(v.literal("success"), v.literal("skipped"), v.literal("error")),
    output: v.optional(v.any()),
    executionTime: v.number(),
  }))),
  createdAt: v.number(),
  createdBy: v.id("users"),
})
  .index("by_flow_createdAt", ["flowId", "createdAt"])
  .index("by_testId", ["testId"]),
```

### Schema Integration Points

**Integration with existing tables:**

```typescript
// Extend messages table to link flow executions
messages: {
  // ... existing fields ...
  flowExecutionId: v.optional(v.id("flowExecutions")), // Link to flow execution
  flowNodeId: v.optional(v.string()), // Which flow node generated this message
}

// Extend chats table to track active flows
chats: {
  // ... existing fields ...
  activeFlowExecutionId: v.optional(v.id("flowExecutions")), // Currently executing flow
  flowState: v.optional(v.any()), // Flow state for this conversation
}

// Extend aiSettings table to enable/disable flow integration
aiSettings: {
  // ... existing fields ...
  flowsEnabled: v.optional(v.boolean()), // Enable flow-based AI
  defaultFlowId: v.optional(v.id("flows")), // Default flow to use
}
```

## Performance Considerations

### Flow Execution Performance

| Concern                       | Impact                                         | Mitigation                                                                 |
| ----------------------------- | ---------------------------------------------- | -------------------------------------------------------------------------- |
| **State persistence latency** | Every node transition writes to DB             | Batch state updates, use Convex vector writes                              |
| **Flow trigger evaluation**   | Every message checks triggers                  | Cache active flows per clinic, use indexed queries                         |
| **AI prompt injection**       | Large flows consume tokens                     | Compress flow instructions, inject only relevant sub-flows                 |
| **Concurrent executions**     | Multiple flows running simultaneously          | Use Convex's optimistic concurrency, limit per clinic via plan enforcement |
| **Flow complexity**           | Nested branches, loops increase execution time | Limit flow complexity (max nodes, max depth), validate before publishing   |

### State Management Performance

| Scale                              | Approach                                                           |
| ---------------------------------- | ------------------------------------------------------------------ |
| 0-100 active executions per clinic | Direct Convex queries, real-time subscriptions for UI              |
| 100-1000 active executions         | Cache execution state in memory, sync to DB periodically           |
| 1000+ active executions            | Partition executions by clinicId or time window, use read replicas |

### Query Optimization

```typescript
// Efficient trigger evaluation (cache + indexed query)
const activeFlows = await ctx.runQuery(internal.flows.getActiveForClinic, {
  clinicId,
});

// Cached in memory for subsequent messages
flowTriggerCache.set(clinicId, activeFlows, 60000); // 1 minute cache

// Fast trigger matching
for (const flow of activeFlows) {
  if (matchesTrigger(flow, message)) {
    return flow; // Found match, stop searching
  }
}

// Efficient state retrieval (indexed query + pagination)
const executions = await ctx.db
  .query("flowExecutions")
  .withIndex(
    "by_flow_createdAt",
    (q) => q.eq("flowId", flowId).gte("startedAt", Date.now() - 86400000), // Last 24 hours
  )
  .take(50)
  .collect();
```

## Security & Compliance

### Multi-Tenant Isolation

**Enforcement Points:**

1. **RBAC**: Only admin/staff/super_admin can create/edit flows
2. **ClinicId validation**: All queries must match authenticated user's clinicId
3. **Index-based filtering**: Use by*clinic*\* indexes for all flow queries
4. **Execution isolation**: Flows cannot access data from other clinics (enforced in flow executor)

```typescript
// Example: RBAC enforcement for flow operations
export const updateFlow = mutation({
  args: {
    /* ... */
  },
  handler: async (ctx, args) => {
    // Get authenticated user
    const { clinicId, user } = await getAuth(ctx);

    // Verify user has permission
    if (!["admin", "staff", "super_admin"].includes(user.role)) {
      throw forbidden("Insufficient permissions");
    }

    // Verify flow belongs to user's clinic
    const flow = await ctx.db.get(args.flowId);
    if (!flow || flow.clinicId !== clinicId) {
      throw notFound("Flow not found");
    }

    // Update flow
    await ctx.db.patch(args.flowId, {
      /* ... */
    });
  },
});
```

### Healthcare Compliance

**Audit Logging:**

- All flow executions logged to flowExecutions table
- Node-level logging for debugging and compliance
- User attribution (createdBy, updatedBy) on all flow changes
- Timestamp tracking for all state transitions

**Data Privacy:**

- Flow definitions stored per clinic (no cross-tenant access)
- Flow variables sanitized before storage (no PII in logs unless explicitly needed)
- Test data isolated from production (flowTests table)

```typescript
// Audit logging for flow execution
export const executeFlow = internalAction({
  args: {
    /* ... */
  },
  handler: async (ctx, args) => {
    const executionId = generateExecutionId();

    // Create audit log entry
    await ctx.runMutation(internal.auditLogs.insert, {
      action: "flow_execution_started",
      clinicId: args.clinicId,
      flowId: args.flowId,
      executionId,
      metadata: {
        flowVersion: args.flowVersionId,
        triggerType: args.triggerType,
        triggeredBy: args.userId,
      },
      createdAt: Date.now(),
    });

    // Execute flow...
    const result = await runFlow(/* ... */);

    // Log completion
    await ctx.runMutation(internal.auditLogs.insert, {
      action: "flow_execution_" + result.status,
      clinicId: args.clinicId,
      flowId: args.flowId,
      executionId,
      metadata: {
        duration: result.duration,
        nodesExecuted: result.nodesExecuted,
        error: result.error,
      },
      createdAt: Date.now(),
    });

    return result;
  },
});
```

## Sources

- **Convex Documentation:** Multi-tenant patterns, indexing strategies, schema design (2025)
- **Mastra Framework:** Agent factory pattern, tools integration, system prompt injection (2025)
- **State Machine Patterns:** Stateful microservices, event sourcing, durable execution (2025)
- **Workflow Engine Best Practices:** Expand/contract versioning, human-in-the-loop, error recovery (2025)
- **React Flow Documentation:** Flow builder UI patterns, node-based editors (2025)
- **Existing WhatsMed Codebase:** automation.ts, agents.ts, tools.ts, rbac.ts, schema.ts

---

_Architecture research for: AI Flow Builder for Healthcare Practice Management SaaS_
_Researched: 2025-02-04_
