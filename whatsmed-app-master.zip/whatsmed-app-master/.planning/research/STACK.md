# Technology Stack - AI Flow Builder Milestone

**Project:** WhatsMed - AI Flow Builder
**Researched:** 2026-02-04
**Overall confidence:** HIGH

## Executive Summary

The AI Flow Builder leverages the existing validated stack (React, TanStack Start, Convex, Mastra) with a single strategic addition: **@xyflow/react** (React Flow) for the visual drag-and-drop flow builder UI. The flow execution engine is already provided by the installed **@mastra/core** framework, which includes a graph-based workflow orchestration system.

This approach minimizes stack surface area while providing enterprise-grade capabilities for visual workflow construction, execution, and AI integration.

---

## Stack Additions (NEW for this milestone)

### 1. Visual Flow Builder UI

| Technology           | Version  | Purpose                          | Why                                                                                                                         |
| -------------------- | -------- | -------------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| **@xyflow/react**    | ^12.10.0 | Node-based visual flow builder   | Industry-standard for node-based UIs; purpose-built for workflow builders; supports React 19, SSR, and Tailwind integration |
| **@xyflow/react-ui** | ^12.0.0  | Pre-built flow editor components | Provides AI Workflow Editor template and reusable components (nodes, edges, controls) to accelerate development             |

#### Integration Points

**React Flow ↔ TanStack Start:**

- Use `<ReactFlowProvider>` wrapper around the flow builder route
- Store flow state in React Query for optimistic updates and caching
- Leverage TanStack Start's file-based routing for flow editor routes (`/flows/:id/edit`)

**React Flow ↔ Tailwind CSS:**

- React Flow UI components have native Tailwind CSS 4 support
- Custom nodes styled with Tailwind classes
- Existing shadcn/ui components can be embedded within flow nodes

**React Flow ↔ Convex:**

- Serialize flows to Convex documents via `toObject()` API
- Real-time sync for collaborative editing (multiple admins editing flows simultaneously)
- Convex v.id("flows") for strongly-typed flow IDs

---

### 2. Flow Execution Engine

| Technology       | Version            | Purpose                            | Why                                                                                                                 |
| ---------------- | ------------------ | ---------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| **@mastra/core** | ^0.24.9 (existing) | Graph-based workflow orchestration | Already installed; provides state machine approach with steps, branching, parallel execution, and human-in-the-loop |

#### Architecture

**Mastra Workflows already provide:**

- **Steps:** Individual units of work with `inputSchema` and `outputSchema` (Zod)
- **Workflows:** Graph orchestration with linear paths, branching, cycles
- **Parallel execution:** Run multiple steps concurrently with `parallel()`
- **Conditional branching:** Route based on step outputs
- **Human-in-the-loop:** Suspend/resume workflows for approval
- **State management:** Persistent state across execution runs

**Integration Pattern:**

```typescript
// 1. Visual flow (React Flow) → Mastra Workflow definition
const flowGraph = ({ nodes, edges } = useReactFlow());
const mastraWorkflow = convertReactFlowToMastra(flowGraph);

// 2. Mastra Workflow → Convex persistence
await ctx.db.insert("workflowExecutions", {
  workflowId: flowId,
  state: mastraWorkflow.getState(),
  status: "running",
  // ...
});

// 3. Mastra → AI prompt injection
const flowContext = serializeForPrompt(mastraWorkflow);
const aiPrompt = buildSystemPrompt({
  baseInstructions: "You are a WhatsApp assistant for a clinic...",
  flowContext,
});
```

---

### 3. Flow Schema Validation

| Technology | Version                   | Purpose                                      | Why                                                                                                   |
| ---------- | ------------------------- | -------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| **zod**    | ^4.1.13 (backend upgrade) | Schema validation and JSON Schema conversion | Already in frontend (4.1.13); backend has 3.23.8; upgrade for `toJSONSchema()`/`fromJSONSchema()` API |

#### Why Upgrade to Zod v4?

Zod v4 (late 2025) provides **bi-directional JSON Schema conversion**:

```typescript
// Visual builder → JSON Schema → Mastra Workflow
const visualFlow = {
  /* React Flow JSON */
};
const flowSchema = z.object({
  nodes: z.array(
    z.object({
      /* ... */
    }),
  ),
  edges: z.array(
    z.object({
      /* ... */
    }),
  ),
});
const jsonSchema = flowSchema.toJSONSchema();

// Store in Convex as JSON Schema
await ctx.db.insert("flows", {
  definition: jsonSchema,
  // ...
});

// Hydrate back for execution
const hydratedSchema = z.fromJSONSchema(storedFlowDefinition);
const result = hydratedSchema.parse(executionData);
```

**Key features for AI Flow Builder:**

- **Native `toJSONSchema()`** - No external `zod-to-json-schema` library needed
- **Native `fromJSONSchema()`** - Hydrate stored schemas for runtime validation
- **Zod GlobalRegistry** - Share node types across workflows
- **Zod Mini** - Edge-ready validation for instant feedback in flow editor

---

### 4. Flow Testing & Debugging Tools

| Technology                         | Version          | Purpose                            | Why                                                                          |
| ---------------------------------- | ---------------- | ---------------------------------- | ---------------------------------------------------------------------------- |
| **React Flow DevTools** (built-in) | ^12.0.0          | Flow inspection and change logging | Built-in components: `<NodeInspector>`, `<ChangeLogger>`, `<ViewportLogger>` |
| **Custom test harness**            | (built in-house) | Flow execution simulation          | Wrap Mastra workflows with test runner for dry-run validation                |

#### Built-in React Flow DevTools

React Flow provides three debugging components (copy into project and customize):

**1. `<NodeInspector />`**

- Shows state of each node (id, type, position, dimensions, selected)
- Uses `useNodes()` hook (intentionally re-renders on any node change)
- Renders via `<ViewportPortal />` for positioning within flow canvas

**2. `<ChangeLogger />`**

- Wraps `onNodesChange` and `onEdgesChange` handlers
- Logs each change as it's dispatched
- Reveals internal React Flow change types (NodeChange, EdgeChange)
- Helps understand flow structure and validate changes

**3. `<ViewportLogger />`**

- Shows current viewport state (x, y, zoom)
- Extracts `transform` state from React Flow store
- Useful for debugging zoom/pan interactions

#### Custom Debugging Components

**Flow Execution Simulator:**

```typescript
// Dry-run a flow without sending WhatsApp messages
async function simulateFlow(flowId: string, testInput: any) {
  const flow = await ctx.db.get("flows", flowId);
  const mastraWorkflow = hydrateMastraWorkflow(flow.definition);

  // Mock external services
  const mockContext = {
    whatsapp: mockWhatsAppService(),
    ai: mockAIService(),
  };

  // Execute in test mode
  const result = await mastraWorkflow.execute(testInput, {
    context: mockContext,
    dryRun: true,
  });

  return {
    steps: result.executionLog,
    errors: result.errors,
    finalState: result.state,
  };
}
```

**Flow Step Debugger:**

- Highlight currently executing step in React Flow
- Show step input/output in a side panel
- Allow stepping through flow execution (pause/resume using Mastra's HITL)

---

## Stack Changes Summary

### Additions

```bash
# Visual flow builder
npm install @xyflow/react@^12.10.0 @xyflow/react-ui@^12.0.0

# Upgrade Zod in backend for v4 features
npm install zod@^4.1.13
```

### No Changes (Keep existing)

**Frontend:**

- React 19.1.2 ✓ (React Flow supports React 19)
- TanStack Start 1.132.31 ✓ (routing, server components)
- Tailwind CSS 4.1.3 ✓ (React Flow has native support)
- Radix UI components ✓ (embed in flow nodes)
- Zod 4.1.13 ✓ (already installed in frontend)
- @tanstack/react-query 5.80.6 ✓ (cache flow state)

**Backend:**

- Convex 1.29.3 ✓ (flow storage, real-time sync)
- @mastra/core 0.24.9 ✓ (flow execution engine)
- AI SDK (OpenAI, Anthropic, Google) ✓ (AI integration)
- better-auth 1.3.34 ✓ (authentication for flow builder)

**Drag & Drop (NOT for flow builder):**

- @dnd-kit/core 6.3.1 ✓ (keep for sortable lists, kanban boards)
- @dnd-kit/sortable 10.0.0 ✓ (keep for other UI needs)
- @dnd-kit/utilities 3.2.2 ✓ (keep for other UI needs)

---

## What NOT to Add and Why

### 1. dnd-kit for Flow Building

**Why NOT:**

- dnd-kit is designed for sortable lists, kanban boards, and dashboard widgets
- It lacks node-based graph capabilities (edges, connections, handles)
- Would require building complex edge/connection logic from scratch

**What to use instead:**

- **@xyflow/react** - Purpose-built for node-based flows

### 2. React DnD

**Why NOT:**

- Deprecated and unmaintained since 2023
- Complex API with high learning curve
- Poor TypeScript support
- Performance issues with large diagrams

**What to use instead:**

- **@xyflow/react** - Modern, actively maintained (35.1k GitHub stars, 4.1M weekly installs)

### 3. Custom Flow Execution Engine

**Why NOT:**

- @mastra/core already provides graph-based workflow execution
- Building from scratch introduces risk and maintenance burden
- Would need to implement state management, branching, cycles, error handling

**What to use instead:**

- **@mastra/core Workflows** - Proven framework for AI agent orchestration

### 4. Separate JSON Schema Library

**Why NOT:**

- Zod v4 provides native `toJSONSchema()` and `fromJSONSchema()`
- No need for external `zod-to-json-schema` or similar libraries
- Single source of truth for schema validation

**What to use instead:**

- **Zod v4** - Built-in JSON Schema conversion

### 5. External Workflow Engines (Temporal, LangGraph.js)

**Why NOT:**

- Adds infrastructure complexity (Temporal requires dedicated cluster)
- LangGraph.js is Python-first (JS version is experimental)
- Over-engineering for this use case (flows are bounded to WhatsApp, not distributed systems)

**What to use instead:**

- **@mastra/core** - TypeScript-native, integrates with existing AI SDK, Convex-compatible

---

## Performance Considerations

### 1. React Flow Performance

**Best practices from official docs:**

| Optimization                      | Implementation                                                                     |
| --------------------------------- | ---------------------------------------------------------------------------------- |
| **Memoize custom nodes**          | Use `React.memo()` or declare outside parent component                             |
| **Memoize handlers**              | Use `useCallback()` for `onNodesChange`, `onEdgesChange`                           |
| **Avoid accessing `nodes` array** | Don't filter `nodes` in components; use React Flow's internal store for selections |
| **Collapse large flows**          | Use node `hidden` property for sub-flows; expand on demand                         |
| **Simplify styles**               | Avoid complex animations, shadows, gradients on high node counts (100+ nodes)      |

**Performance at scale:**

- **< 50 nodes:** No special optimization needed
- **50-200 nodes:** Enable `hidden` for sub-flows, simplify node styles
- **200+ nodes:** Consider virtualization or flow splitting

### 2. Flow Execution Performance

**Mastra Workflows:**

- **Parallel execution** for independent steps reduces overall latency
- **State persistence** in Convex allows resuming interrupted flows
- **Durable execution** survives server crashes (via Convex's state machine pattern)

**AI Integration:**

- Cache flow definitions in React Query to avoid re-fetching
- Pre-serialize flows for prompt injection (avoid runtime serialization)
- Use Convex's real-time sync for collaborative flow editing

---

## Integration Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Frontend (TanStack Start)              │
├─────────────────────────────────────────────────────────────┤
│  Flow Builder Route                                       │
│  ├── @xyflow/react (Canvas)                             │
│  │   ├── Custom Nodes (Question, Message, Condition...)      │
│  │   ├── Edges (Connections)                            │
│  │   └── DevTools (NodeInspector, ChangeLogger)           │
│  └── React Query (Cache flows, optimistic updates)          │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ Real-time sync
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Backend (Convex)                        │
├─────────────────────────────────────────────────────────────┤
│  Flows Collection                                        │
│  ├── definition: JSON Schema (from React Flow)              │
│  ├── metadata: { name, description, createdBy, ... }       │
│  └── version: Incremented on changes                     │
│                                                          │
│  FlowExecutions Collection                                  │
│  ├── workflowId: v.id("flows")                          │
│  ├── state: Execution state (from Mastra)                  │
│  ├── status: "running" | "paused" | "completed" | ...   │
│  └── logs: Step execution logs                          │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ Execute
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                Flow Execution (@mastra/core)                 │
├─────────────────────────────────────────────────────────────┤
│  Steps (createStep())                                     │
│  ├── inputSchema: z.object({ ... })                        │
│  ├── outputSchema: z.object({ ... })                       │
│  └── execute: async ({ context }) => { ... }             │
│                                                          │
│  Workflow                                                 │
│  ├── Graph: Steps → Edges (conditional, parallel)          │
│  ├── State: Persistent execution state                       │
│  └── HITL: suspend/resume for approvals                   │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ Call tools
                            ▼
┌─────────────────────────────────────────────────────────────┐
│               External Services                             │
├─────────────────────────────────────────────────────────────┤
│  • WhatsApp (Evolution API / Meta Cloud API)               │
│  • AI SDK (OpenAI, Anthropic, Google)                     │
│  • Clinic Data (Convex queries/mutations)                   │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ Inject into prompt
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              AI System Prompt Builder                       │
├─────────────────────────────────────────────────────────────┤
│  const prompt = `                                         │
│    You are a WhatsApp assistant for a clinic...             │
│                                                          │
│    Available flows:                                          │
│    ${serializedFlows}                                       │
│                                                          │
│    When user message arrives, check if flow applies...         │
│  `;                                                      │
└─────────────────────────────────────────────────────────────┘
```

---

## Phase 1 Stack Installation

```bash
# 1. Install React Flow
cd apps/web
bun add @xyflow/react@^12.10.0 @xyflow/react-ui@^12.0.0

# 2. Upgrade Zod in backend
cd packages/backend
bun add zod@^4.1.13

# 3. Verify installation
cd ../..
bun install
```

---

## Sources

| Source                                                                                          | Type                   | Confidence |
| ----------------------------------------------------------------------------------------------- | ---------------------- | ---------- |
| [React Flow Official Docs](https://reactflow.dev/)                                              | Official documentation | HIGH       |
| [React Flow Performance Guide](https://reactflow.dev/learn/advanced-use/performance)            | Official docs          | HIGH       |
| [React Flow State Management](https://reactflow.dev/learn/advanced-use/state-management)        | Official docs          | HIGH       |
| [React Flow DevTools](https://reactflow.dev/learn/advanced-use/devtools-and-debugging)          | Official docs          | HIGH       |
| [React Flow AI Workflow Editor Template](https://reactflow.dev/ui/templates/ai-workflow-editor) | Official docs          | HIGH       |
| [Convex Official Site](https://convex.dev/)                                                     | Official docs          | HIGH       |
| [Mastra Workflow Documentation](https://mastra.ai/docs/workflows/overview)                      | Official docs          | HIGH       |
| [Zod v4 Features](https://github.com/colinhacks/zod) (verified via web search)                  | Official docs          | HIGH       |
| [React Flow vs dnd-kit Comparison 2026](web search)                                             | WebSearch              | MEDIUM     |
| [Graph Traversal Engines 2026](web search)                                                      | WebSearch              | MEDIUM     |
| [JSON Schema Validation 2026](web search)                                                       | WebSearch              | MEDIUM     |
| [Package.json analysis](local file)                                                             | Direct inspection      | HIGH       |

---

## Confidence Assessment

| Area                            | Confidence | Notes                                                                      |
| ------------------------------- | ---------- | -------------------------------------------------------------------------- |
| React Flow for visual builder   | HIGH       | Official docs; 35.1k GitHub stars; industry standard for node-based UIs    |
| Mastra Workflows for execution  | HIGH       | Already installed; official docs confirm graph-based workflow capabilities |
| Zod v4 for schema validation    | HIGH       | Official docs confirm `toJSONSchema()`/`fromJSONSchema()` API              |
| Integration with existing stack | HIGH       | React Flow supports React 19, SSR, Tailwind; Mastra integrates with Convex |
| DevTools for debugging          | HIGH       | React Flow provides built-in components; extendable                        |
| Performance optimization        | HIGH       | Official docs provide clear guidance for large flows                       |

---

## Open Questions for Phase-Specific Research

1. **Mastra ↔ React Flow conversion:** How to optimally serialize React Flow JSON to Mastra Workflow definitions? (Phase-specific, likely resolved by building adapter layer)
2. **Flow versioning strategy:** How to handle flow versioning and migrations? (Convex schema design question)
3. **AI prompt template format:** What's the optimal format for injecting flows into AI system prompts? (Depends on LLM provider; may need A/B testing)
4. **Flow testing patterns:** Should we use Mastra's built-in testing or build custom harness? (Evaluate during Phase 2: Flow Execution Engine)

---

_Stack research: 2026-02-04_
