# Sprint 2: AI Agent Guide Flow & Export

**Duration:** Weeks 3-4 (2 weeks)
**Focus:** Create AI Agent Guide Flow with all tool nodes and export to system prompt format
**Status:** Not Started

---

## Sprint Goals

### Primary Goals

1. **AI Agent Guide Flow** - Create a master flow that guides AI agent through all available tools
2. **System Prompt Export** - Export flow as JSON with general instructions for AI system prompt

### Success Criteria

- ✅ AI Agent Guide Flow created with complete structure
- ✅ Flow includes nodes for all AI tools (sendMessage, scheduleAppointment, patientLookup, escalateToHuman)
- ✅ Flow includes wait nodes for pausing
- ✅ Flow exported as JSON
- ✅ General instructions added above flow JSON
- ✅ System prompt format ready for AI integration

---

## Week 3: Create AI Agent Guide Flow

### Task 3.1: Design AI Agent Guide Flow Structure 🔥 CAN PARALLELIZE

**Priority:** CRITICAL
**Estimate:** 4-6 hours
**Owner:** Backend Engineer
**Can be executed by:** Subagent

**Description:**
Design the complete structure of the AI Agent Guide Flow that will serve as the master guide for the AI agent.

**Implementation Steps:**

1. Define flow structure with the following nodes:
   - **Start Node**: Entry point for AI conversations
   - **Analyze Intent Node**: Determine user's intent (message, schedule, lookup, escalate, general)
   - **Send Message Tool Node**: For sending WhatsApp messages
   - **Schedule Appointment Tool Node**: For scheduling appointments
   - **Patient Lookup Tool Node**: For retrieving patient data
   - **Wait Node**: For pausing and waiting for user response
   - **Escalate to Human Tool Node**: For calling humans/escalating conversations
   - **End Node**: For completing the flow

2. Define connections between nodes based on intent and flow logic
3. Document the flow structure and decision points

**Acceptance Criteria:**

- ✅ Flow structure documented
- ✅ All required nodes identified
- ✅ Connections defined for all paths
- ✅ Decision points documented

---

### Task 3.2: Create AI Agent Guide Flow JSON 🔄 DEPENDENCY (depends on Task 3.1)

**Priority:** CRITICAL
**Estimate:** 6-8 hours
**Owner:** Backend Engineer
**Can be executed by:** Subagent

**Description:**
Create the AI Agent Guide Flow as a JSON file that can be imported into the flow builder or used directly.

**Implementation Steps:**

1. Create `ai-agent-guide-flow.json` in `packages/backend/convex/flows/`
2. Define flow metadata (name, description)
3. Define all nodes with their properties:
   - Start node with description
   - Analyze Intent condition node with intent types
   - Send Message tool node with parameters
   - Schedule Appointment tool node with parameters
   - Patient Lookup tool node with parameters
   - Wait node with duration and resume conditions
   - Escalate to Human tool node with parameters
   - End node with description
4. Define connections between all nodes
5. Ensure proper flow structure (no unreachable nodes)

**Flow JSON Structure:**

```json
{
  "name": "AI Agent Guide Flow",
  "description": "Master flow that guides the AI agent through all available tools and procedures",
  "nodes": [
    {
      "id": "start",
      "type": "start",
      "data": {
        "description": "Entry point for AI agent conversations"
      },
      "position": { "x": 100, "y": 50 }
    },
    {
      "id": "analyze-intent",
      "type": "condition",
      "data": {
        "description": "Analyze user message to determine intent and required action",
        "conditionType": "intent",
        "variable": "userIntent",
        "possibleValues": ["message", "schedule", "patient_lookup", "escalation", "general"]
      },
      "position": { "x": 100, "y": 200 }
    },
    {
      "id": "send-message",
      "type": "tool",
      "data": {
        "tool": "sendMessage",
        "description": "Send a WhatsApp message to patient",
        "parameters": {
          "patientId": "{{patientId}}",
          "message": "{{responseMessage}}"
        }
      },
      "position": { "x": 350, "y": 100 }
    },
    {
      "id": "schedule-appointment",
      "type": "tool",
      "data": {
        "tool": "scheduleAppointment",
        "description": "Schedule an appointment for patient",
        "parameters": {
          "patientId": "{{patientId}}",
          "date": "{{preferredDate}}",
          "time": "{{preferredTime}}",
          "doctorId": "{{doctorId}}"
        }
      },
      "position": { "x": 350, "y": 200 }
    },
    {
      "id": "lookup-patient",
      "type": "tool",
      "data": {
        "tool": "patientLookup",
        "description": "Retrieve patient information from database",
        "parameters": {
          "identifier": "{{patientIdentifier}}",
          "lookupType": "phone"
        }
      },
      "position": { "x": 350, "y": 300 }
    },
    {
      "id": "wait-response",
      "type": "wait",
      "data": {
        "description": "Wait for user response before proceeding",
        "duration": 60,
        "unit": "seconds",
        "timeoutAction": "escalate",
        "resumeCondition": "userResponseReceived"
      },
      "position": { "x": 600, "y": 200 }
    },
    {
      "id": "escalate-human",
      "type": "tool",
      "data": {
        "tool": "escalateToHuman",
        "description": "Escalate conversation to human staff member",
        "parameters": {
          "reason": "{{escalationReason}}",
          "urgency": "medium",
          "context": "{{conversationContext}}",
          "assignTo": "{{availableStaffId}}"
        }
      },
      "position": { "x": 600, "y": 350 }
    },
    {
      "id": "end",
      "type": "end",
      "data": {
        "description": "End of conversation or flow completion"
      },
      "position": { "x": 850, "y": 250 }
    }
  ],
  "connections": [
    { "id": "e1", "source": "start", "target": "analyze-intent" },
    { "id": "e2", "source": "analyze-intent", "target": "send-message", "sourceHandle": "message" },
    {
      "id": "e3",
      "source": "analyze-intent",
      "target": "schedule-appointment",
      "sourceHandle": "schedule"
    },
    {
      "id": "e4",
      "source": "analyze-intent",
      "target": "lookup-patient",
      "sourceHandle": "patient_lookup"
    },
    { "id": "e5", "source": "send-message", "target": "wait-response" },
    { "id": "e6", "source": "schedule-appointment", "target": "wait-response" },
    { "id": "e7", "source": "wait-response", "target": "end", "sourceHandle": "resume" },
    {
      "id": "e8",
      "source": "wait-response",
      "target": "escalate-human",
      "sourceHandle": "timeout"
    },
    {
      "id": "e9",
      "source": "analyze-intent",
      "target": "escalate-human",
      "sourceHandle": "escalation"
    },
    { "id": "e10", "source": "escalate-human", "target": "end" }
  ]
}
```

**Acceptance Criteria:**

- ✅ AI Agent Guide Flow JSON created
- ✅ All required nodes included (start, analyze-intent, send-message, schedule-appointment, lookup-patient, wait-response, escalate-human, end)
- ✅ All tool nodes have correct tool names and parameters
- ✅ Connections defined for all flow paths
- ✅ Wait node included with proper configuration
- ✅ No unreachable nodes

---

### Task 3.3: Import Flow into Builder 🔥 CAN PARALLELIZE

**Priority:** HIGH
**Estimate:** 3-4 hours
**Owner:** Frontend Engineer
**Can be executed by:** Subagent

**Description:**
Add functionality to import the AI Agent Guide Flow JSON into the flow builder so users can visualize and edit it.

**Implementation Steps:**

1. Create import flow button in flow list page
2. Read `ai-agent-guide-flow.json` file
3. Parse JSON and create flow in database
4. Create flow version with nodes and connections from JSON
5. Navigate to flow editor with imported flow

**Acceptance Criteria:**

- ✅ Import button available in flow list
- ✅ AI Agent Guide Flow can be imported
- ✅ Flow displays correctly in builder with all nodes and connections
- ✅ Flow can be edited after import

---

## Week 4: System Prompt Export

### Task 4.1: Create System Prompt Export Function 🔥 CAN PARALLELIZE

**Priority:** CRITICAL
**Estimate:** 4-6 hours
**Owner:** Backend Engineer
**Can be executed by:** Subagent

**Description:**
Create a function that exports the AI Agent Guide Flow as a formatted system prompt with general instructions and flow JSON.

**Implementation Steps:**

1. Create `aiFlowExporter.ts` in `packages/backend/convex/flows/`
2. Implement `generateSystemPrompt()` function:
   - Load AI Agent Guide Flow JSON
   - Generate general instructions for AI agent
   - Format flow JSON for inclusion
   - Return complete system prompt string
3. Implement `exportFlowAsJSON()` function:
   - Load flow JSON
   - Return as string for export
4. Implement `getToolMappings()` function:
   - Extract tool nodes from flow
   - Map tool names to their configurations
   - Return tool mapping object

**System Prompt Format:**

```typescript
// packages/backend/convex/flows/aiFlowExporter.ts

import { readFileSync } from "fs";
import { join } from "path";

interface Node {
  id: string;
  type: string;
  data: any;
  position: { x: number; y: number };
}

interface Connection {
  id: string;
  source: string;
  target: string;
  sourceHandle?: string;
  targetHandle?: string;
}

interface Flow {
  name: string;
  description: string;
  nodes: Node[];
  connections: Connection[];
}

/**
 * Generate system prompt with AI Agent Guide Flow
 * This includes general instructions followed by flow structure in JSON
 */
export function generateSystemPrompt(): string {
  // Load AI Agent Guide Flow
  const flowPath = join(__dirname, "ai-agent-guide-flow.json");
  const flow: Flow = JSON.parse(readFileSync(flowPath, "utf-8"));

  // Build node descriptions for reference
  const nodeDescriptions = flow.nodes
    .map((node) => {
      return `
### Node: ${node.id} (${node.type})

**Purpose:** ${node.data.description || "No description"}

${node.data.tool ? `**Tool:** ${node.data.tool}` : ""}

${
  node.data.parameters
    ? `**Parameters:**
${Object.entries(node.data.parameters)
  .map(([key, value]) => `- ${key}: ${value}`)
  .join("\n")}`
    : ""
}
    `.trim();
    })
    .join("\n\n");

  // Build complete system prompt
  const systemPrompt = `
# AI Agent Guide Flow

You are an AI assistant for a medical clinic system. Follow this flow guide to assist patients effectively.

## General Instructions

1. Always be helpful, professional, and empathetic
2. Protect patient privacy and comply with healthcare regulations
3. Use the tools available to you according to the flow
4. When uncertain, escalate to human staff
5. Maintain conversation context and follow the defined flow
6. Wait for user responses when the flow indicates to pause
7. Escalate to humans only when necessary or when explicitly requested

## Available Tools

### sendMessage
Send WhatsApp messages to patients.

### scheduleAppointment
Schedule appointments for patients.

### patientLookup
Retrieve patient information from the database.

### escalateToHuman
Transfer the conversation to a human staff member.

## Flow Structure

${flow.description}

### Flow Graph (JSON)

\`\`\`json
${JSON.stringify(flow, null, 2)}
\`\`\`

### Node Reference

${nodeDescriptions}

## Execution Rules

1. Start at the 'start' node
2. Follow connections based on conditions and user responses
3. When you encounter a 'wait' node, pause and wait for a user response
4. Use the wait timeout configuration to determine when to escalate
5. Each tool node maps to an actual function you can call
6. Always validate parameters before calling tools
7. When waiting, return the wait message to the user and pause

## Escalation Criteria

Escalate to a human when:
- The user explicitly asks to speak to a human
- Wait timeout expires without a response
- A medical emergency is detected
- The situation is unclear or ambiguous and requires human judgment
- Tool execution fails repeatedly
- The patient expresses distress or concern
  `.trim();

  return systemPrompt;
}

/**
 * Export flow as JSON for external use
 */
export function exportFlowAsJSON(): string {
  const flowPath = join(__dirname, "ai-agent-guide-flow.json");
  return readFileSync(flowPath, "utf-8");
}

/**
 * Get tool mappings from flow nodes
 * Returns a map of tool names to their node configurations
 */
export function getToolMappings(): Record<string, any> {
  const flowPath = join(__dirname, "ai-agent-guide-flow.json");
  const flow: Flow = JSON.parse(readFileSync(flowPath, "utf-8"));

  const mappings: Record<string, any> = {};

  flow.nodes.forEach((node) => {
    if (node.data.tool) {
      mappings[node.data.tool] = {
        nodeId: node.id,
        description: node.data.description,
        parameters: node.data.parameters,
        connections: flow.connections
          .filter((c) => c.source === node.id)
          .map((c) => ({
            target: c.target,
            handle: c.sourceHandle,
          })),
      };
    }
  });

  return mappings;
}
```

**Acceptance Criteria:**

- ✅ `generateSystemPrompt()` function implemented
- ✅ System prompt includes general instructions
- ✅ System prompt includes flow JSON
- ✅ System prompt includes node descriptions
- ✅ System prompt includes tool mappings
- ✅ `exportFlowAsJSON()` function implemented
- ✅ `getToolMappings()` function implemented

---

### Task 4.2: Add Export Button to Flow UI 🔥 CAN PARALLELIZE

**Priority:** HIGH
**Estimate:** 3-4 hours
**Owner:** Frontend Engineer
**Can be executed by:** Subagent

**Description:**
Add a button to export flows (especially the AI Agent Guide Flow) to JSON format.

**Implementation Steps:**

1. Add "Export" button in flow editor toolbar
2. When clicked, generate JSON export of current flow
3. Download JSON file to user's computer
4. Add option to export as system prompt format (with instructions)
5. Show success toast after export

**Acceptance Criteria:**

- ✅ Export button available in flow editor
- ✅ Export to JSON works
- ✅ Export to system prompt format works
- ✅ Download starts immediately
- ✅ Success toast shown

---

### Task 4.3: Integrate System Prompt with AI 🔄 DEPENDENCY (depends on Task 4.1)

**Priority:** CRITICAL
**Estimate:** 4-6 hours
**Owner:** Backend Engineer
**Can be executed by:** Subagent

**Description:**
Integrate the generated system prompt with the AI generation process so the AI agent follows the flow guide.

**Implementation Steps:**

1. Review `automationAi.ts` where AI generates responses
2. Import `generateSystemPrompt()` and `getToolMappings()` functions
3. When initializing AI for a conversation:
   - Call `generateSystemPrompt()` to get the full system prompt
   - Call `getToolMappings()` to get available tools
   - Pass system prompt to AI model
   - Pass tool definitions to AI model for function calling
4. Test that AI follows the flow structure
5. Test that AI uses tools correctly

**Integration Example:**

```typescript
// In packages/backend/convex/automationAi.ts

import { generateSystemPrompt, getToolMappings } from "./flows/aiFlowExporter";

export const generateAiResponse = action({
  args: {
    clinicId: v.string(),
    threadId: v.id("chats"),
    patientId: v.optional(v.id("patients")),
    message: v.string(),
    // ... other args
  },
  handler: async (ctx, args) => {
    // ... existing setup

    // Load AI Agent Guide Flow into system prompt
    const systemPrompt = generateSystemPrompt();
    const toolMappings = getToolMappings();

    // Pass system prompt to AI model
    const aiResponse = await callOpenAI({
      messages: [
        {
          role: "system",
          content: systemPrompt,
        },
        // ... conversation history
      ],
      tools: Object.keys(toolMappings).map((toolName) => ({
        type: "function",
        function: {
          name: toolName,
          description: toolMappings[toolName].description,
          parameters: toolMappings[toolName].parameters,
        },
      })),
      // ... other config
    });

    // ... rest of implementation
  },
});
```

**Acceptance Criteria:**

- ✅ System prompt generated and passed to AI
- ✅ Tool definitions extracted from flow and passed to AI
- ✅ AI follows flow structure when responding
- ✅ AI uses tools correctly when flow indicates
- ✅ AI handles wait nodes correctly (pauses, waits, resumes)

---

### Task 4.4: Create Initial AI Agent Guide Flow 🔄 DEPENDENCY (depends on Task 3.2)

**Priority:** HIGH
**Estimate:** 2-3 hours
**Owner:** Backend Engineer
**Can be executed by:** Subagent

**Description:**
Create and save the AI Agent Guide Flow in the database so it's available to use immediately.

**Implementation Steps:**

1. Create script or mutation to import `ai-agent-guide-flow.json`
2. Create flow record in database
3. Create flow version with nodes and connections
4. Mark flow as active
5. Verify flow is visible in flow list

**Acceptance Criteria:**

- ✅ AI Agent Guide Flow created in database
- ✅ Flow version created with all nodes and connections
- ✅ Flow visible in flow list
- ✅ Flow can be opened in editor

---

## Sprint 2 Deliverables

### Completed Features

1. ✅ AI Agent Guide Flow created (Tasks 3.1, 3.2)
2. ✅ Flow imported into builder (Task 3.3)
3. ✅ System prompt export function implemented (Task 4.1)
4. ✅ Export button added to UI (Task 4.2)
5. ✅ System prompt integrated with AI (Task 4.3)
6. ✅ Initial AI Agent Guide Flow saved in database (Task 4.4)

### What's NOT Included

- ❌ No execution tracking
- ❌ No analytics
- ❌ No reporting
- ❌ No version management
- ❌ No audit logging

---

## Sprint 2 Acceptance Criteria

The sprint is complete when:

### AI Agent Guide Flow

- ✅ AI Agent Guide Flow created with all required nodes:
  - Start node
  - Analyze Intent condition node
  - Send Message tool node
  - Schedule Appointment tool node
  - Patient Lookup tool node
  - Wait node
  - Escalate to Human tool node
  - End node
- ✅ Flow structure is logical and complete
- ✅ Flow can be visualized in builder
- ✅ Flow can be edited if needed

### System Prompt Export

- ✅ System prompt generated with general instructions
- ✅ Flow JSON embedded in system prompt
- ✅ Node descriptions included
- ✅ Tool mappings included
- ✅ Export button works

### AI Integration

- ✅ AI receives system prompt on initialization
- ✅ AI receives tool definitions from flow
- ✅ AI follows flow structure
- ✅ AI uses tools correctly
- ✅ AI handles wait nodes properly

---

**Sprint 2 Status:** Not Started
**Start Date:** TBD (after Sprint 1)
**End Date:** TBD (2 weeks)
**Overall Progress:** 0/7 tasks completed (0%)
