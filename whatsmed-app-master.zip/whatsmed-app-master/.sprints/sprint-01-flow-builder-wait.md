# Sprint 1: Flow Builder & Wait System

**Duration:** Weeks 1-2 (2 weeks)
**Focus:** Fix flow builder functionality and implement wait system for flow execution
**Status:** Not Started

---

## Sprint Goals

### Primary Goals

1. **Flow Builder Functionality** - Make flow builder fully functional for creating and editing flows
2. **Wait System** - Implement pause/resume mechanism for AI agent flow execution

### Success Criteria

- ✅ Flow builder allows creating flows visually
- ✅ All node properties editable
- ✅ Save validates and persists flows
- ✅ Wait system pauses execution with configurable timeout
- ✅ Wait system resumes on user response or timeout
- ✅ No critical bugs in flow builder

---

## Week 1: Fix Flow Builder

### Task 1.1: Complete Node Property Editing 🔥 CAN PARALLELIZE

**Priority:** CRITICAL
**Estimate:** 4-6 hours
**Owner:** Frontend Engineer
**Can be executed by:** Subagent

**Description:**
The `NodePropertiesPanel` has a stub implementation - `onUpdateNodeData` is empty. Users can see node properties but cannot edit them.

**Implementation Steps:**

1. Review node data structure in `apps/web/src/routes/flows/$flowId.tsx`
2. Review node property forms in `apps/web/src/components/flow-builder/NodePropertiesPanel.tsx`
3. Implement `onUpdateNodeData` callback to update `nodes` state
4. Ensure property form changes reflect immediately on canvas
5. Test all node types: message, condition, input, wait

**Acceptance Criteria:**

- ✅ Message node text can be edited and reflects on canvas
- ✅ Condition node fields (type, variable, value) can be edited
- ✅ Input node fields (prompt, variableName) can be edited
- ✅ Wait node fields (duration, unit) can be edited
- ✅ Changes appear immediately on canvas
- ✅ No console errors during editing

---

### Task 1.2: Add Save Validation 🔥 CAN PARALLELIZE

**Priority:** HIGH
**Estimate:** 3-4 hours
**Owner:** Frontend Engineer
**Can be executed by:** Subagent

**Description:**
Users can save flows with critical validation errors (missing required fields). This allows broken flows to be activated.

**Implementation Steps:**

1. Review validation errors state in `apps/web/src/routes/flows/$flowId.tsx`
2. Modify `handleSave` function to check for critical validation errors
3. Show error toast if critical errors exist
4. Disable save button if critical errors present

**Acceptance Criteria:**

- ✅ Save button disabled when critical errors exist
- ✅ Error toast shown if save attempted with critical errors
- ✅ Save allowed with warnings (non-critical errors)
- ✅ Success toast shown on successful save
- ✅ Validation summary bar shows error count

---

### Task 1.3: Fix Edge Deletion 🔥 CAN PARALLELIZE

**Priority:** MEDIUM
**Estimate:** 2-3 hours
**Owner:** Frontend Engineer
**Can be executed by:** Subagent

**Description:**
The `CustomEdge` component dispatches a "delete-edge" custom event when X button is clicked, but no listener is registered in `FlowCanvas`. Edge deletion doesn't work.

**Implementation Steps:**

1. Review `CustomEdge` component in `apps/web/src/components/flow-builder/nodes/CustomEdge.tsx`
2. Locate where "delete-edge" event is dispatched
3. Add event listener in `FlowCanvas.tsx` component
4. Delete edge from `edges` state when event triggered
5. Test edge deletion via hover button

**Acceptance Criteria:**

- ✅ Hovering over edge shows X button
- ✅ Clicking X button deletes the edge
- ✅ Edge disappears from canvas immediately
- ✅ No console errors on deletion

---

## Week 2: Implement Wait System

### Task 2.1: Design Wait Node Data Structure 🔄 DEPENDENCY (depends on Task 1.1-1.3)

**Priority:** CRITICAL
**Estimate:** 2-3 hours
**Owner:** Backend Engineer
**Can be executed by:** Subagent

**Description:**
Define the data structure for wait nodes that will be used by the AI agent to pause execution.

**Implementation Steps:**

1. Define wait node schema with fields:
   - `duration`: number (how long to wait)
   - `unit`: "seconds" | "minutes" | "hours"
   - `timeoutAction`: "resume" | "escalate" (what to do after timeout)
   - `resumeCondition`: string (condition to resume early, e.g., "userResponseReceived")
2. Add to node type definitions
3. Document wait node behavior

**Acceptance Criteria:**

- ✅ Wait node schema defined
- ✅ All required fields specified
- ✅ Documentation complete

---

### Task 2.2: Implement Wait System Logic 🔄 DEPENDENCY (depends on Task 2.1)

**Priority:** CRITICAL
**Estimate:** 6-8 hours
**Owner:** Backend Engineer
**Can be executed by:** Subagent

**Description:**
Implement the wait system logic that will be called by the AI agent when it encounters a wait node. This is NOT execution tracking - just a simple pause/resume mechanism.

**Implementation Steps:**

1. Create `waitSystem.ts` in `packages/backend/convex/flows/`
2. Implement `startWait()` function:
   - Takes wait parameters (duration, unit, timeoutAction, resumeCondition)
   - Stores wait state in a simple object (not database)
   - Returns wait expiration time
3. Implement `checkWaitStatus()` function:
   - Takes a wait state ID
   - Checks if wait has expired
   - Returns status (waiting, expired, resumed)
4. Implement `cancelWait()` function:
   - Takes a wait state ID
   - Clears the wait
   - Returns success
5. No database persistence needed - just in-memory

**Acceptance Criteria:**

- ✅ Wait system starts a wait with given parameters
- ✅ Wait status can be checked (waiting, expired, resumed)
- ✅ Wait can be cancelled early
- ✅ No database usage (simple in-memory)

---

### Task 2.3: Add Wait Node to Flow Builder 🔥 CAN PARALLELIZE

**Priority:** HIGH
**Estimate:** 4-6 hours
**Owner:** Frontend Engineer
**Can be executed by:** Subagent

**Description:**
Add wait node to the flow builder palette and implement its property panel.

**Implementation Steps:**

1. Add wait node to node palette in `FlowBuilder.tsx`
2. Create wait node icon/visual (clock icon)
3. Create wait node property panel with fields:
   - Duration (number input)
   - Unit (dropdown: seconds, minutes, hours)
   - Timeout Action (dropdown: resume, escalate)
   - Resume Condition (text input, optional)
4. Add wait node to flow validation (duration > 0)
5. Test wait node creation and editing

**Acceptance Criteria:**

- ✅ Wait node available in palette
- ✅ Wait node can be added to canvas
- ✅ Wait node properties editable
- ✅ Duration must be greater than 0 (validation)
- ✅ Wait node saves correctly

---

### Task 2.4: Integrate Wait System with AI 🔄 DEPENDENCY (depends on Task 2.2)

**Priority:** CRITICAL
**Estimate:** 4-6 hours
**Owner:** Backend Engineer
**Can be executed by:** Subagent

**Description:**
Integrate the wait system with the AI agent so it can pause execution when it encounters a wait node.

**Implementation Steps:**

1. Review `automationAi.ts` where AI generates responses
2. When AI encounters a wait node in the flow:
   - Call `startWait()` with wait node parameters
   - Return wait status to AI (e.g., "Waiting for user response...")
3. When AI needs to check if wait is expired:
   - Call `checkWaitStatus()`
   - If expired, handle timeout action (resume or escalate)
4. When user responds during wait:
   - Call `cancelWait()` to clear the wait
   - Resume flow execution

**Acceptance Criteria:**

- ✅ AI can start a wait when encountering wait node
- ✅ AI can check wait status
- ✅ AI resumes flow after wait expires or user responds
- ✅ No execution tracking, just simple wait logic

---

## Sprint 1 Deliverables

### Completed Features

1. ✅ Flow builder fully functional (Tasks 1.1, 1.2, 1.3)
2. ✅ Wait system implemented (Tasks 2.1, 2.2)
3. ✅ Wait node added to builder (Task 2.3)
4. ✅ Wait system integrated with AI (Task 2.4)

### What's NOT Included

- ❌ No execution tracking
- ❌ No database persistence for wait states
- ❌ No analytics or reporting
- ❌ No audit logging
- ❌ No version management

---

## Sprint 1 Acceptance Criteria

The sprint is complete when:

### Flow Builder

- ✅ Users can create flows visually
- ✅ All node types editable
- ✅ Save validates before persisting
- ✅ Edge deletion works
- ✅ No critical bugs

### Wait System

- ✅ Wait system implemented (simple, in-memory)
- ✅ Wait node available in builder
- ✅ Wait node properties configurable
- ✅ AI can pause execution at wait node
- ✅ AI resumes after timeout or user response
- ✅ No database usage

---

**Sprint 1 Status:** Not Started
**Start Date:** TBD
**End Date:** TBD (2 weeks)
**Overall Progress:** 0/7 tasks completed (0%)
