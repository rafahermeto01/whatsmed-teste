# Flows System - Implementation Guide (Simplified)

**Purpose:** Guide for executing the 4-week flows system roadmap

---

## Quick Start

### For Task Execution

1. **Read the current sprint file** (e.g., `.sprints/sprint-01-flow-builder-wait.md`)
2. **Identify 🔥 CAN PARALLELIZE tasks** - These can be executed simultaneously by separate subagents
3. **Deploy subagents** to parallelizable tasks
4. **Execute 🔄 DEPENDENCY tasks** - Wait for predecessors to complete
5. **Verify deliverables** before moving to next sprint

### For Sprint Planning

```
Week 1-2: Sprint 1 (Flow Builder & Wait System)
  ↓
Week 3-4: Sprint 2 (AI Agent Guide Flow & Export)
```

---

## Sprint Overview

| Sprint       | Weeks | Focus                                     | Key Deliverable           |
| ------------ | ----- | ----------------------------------------- | ------------------------- |
| **Sprint 1** | 1-2   | Flow builder fixes, wait system           | Functional builder + wait |
| **Sprint 2** | 3-4   | AI Agent Guide Flow, system prompt export | Complete AI flow + export |

---

## What This System Is (and Is NOT)

### What It Is

✅ **A visual flow builder** - Create and edit flows using drag-and-drop UI
✅ **A guide for AI agent** - Flow structure tells AI what to do and when
✅ **Tool nodes** - Nodes that map to AI tools (sendMessage, scheduleAppointment, etc.)
✅ **Wait system** - Pause AI execution and wait for user response
✅ **Export to system prompt** - Flow JSON formatted as instructions for AI
✅ **Simple and focused** - No unnecessary complexity

### What It Is NOT

❌ **No execution tracking** - We don't need to track every flow execution
❌ **No analytics** - No reporting on flow performance
❌ **No audit logging** - No tracking of who changed what
❌ **No version management** - No versioning or rollback needed
❌ **No multi-tenant complexity** - Simple, single-use flow system

---

## System Architecture

```
┌─────────────────────────────────────────────────┐
│          Flow Builder (Frontend)               │
│  ┌─────────────┐    ┌──────────────┐       │
│  │ Node Palette│ →  │  Canvas      │       │
│  └─────────────┘    └──────┬───────┘       │
│                            │                 │
│                            ▼                 │
│                     ┌─────────────┐          │
│                     │ Properties  │          │
│                     │   Panel     │          │
│                     └─────────────┘          │
└────────────────────────┬────────────────────────┘
                     │
                     │ Save Flow
                     ▼
┌─────────────────────────────────────────────────┐
│           Flow Storage (Backend)               │
│  ┌──────────────────────────────────┐        │
│  │ flows table                     │        │
│  │ - id, name, description        │        │
│  │ - activeVersionId               │        │
│  └──────────────────────────────────┘        │
│  ┌──────────────────────────────────┐        │
│  │ flowVersions table               │        │
│  │ - nodes (array)                 │        │
│  │ - connections (array)            │        │
│  │ - variables (array)              │        │
│  └──────────────────────────────────┘        │
└────────────────────────┬──────────────────────┘
                     │
                     │ Export
                     ▼
┌─────────────────────────────────────────────────┐
│        AI Agent System Prompt                  │
│  ┌──────────────────────────────────┐        │
│  │ General Instructions            │        │
│  │ 1. Be helpful and professional │        │
│  │ 2. Protect patient privacy     │        │
│  │ 3. Follow the flow structure   │        │
│  │ 4. Use tools appropriately     │        │
│  └──────────────────────────────────┘        │
│  ┌──────────────────────────────────┐        │
│  │ Flow Structure (JSON)           │        │
│  │ {                             │        │
│  │   "nodes": [...],              │        │
│  │   "connections": [...]          │        │
│  │ }                             │        │
│  └──────────────────────────────────┘        │
│  ┌──────────────────────────────────┐        │
│  │ Tool Mappings                  │        │
│  │ - sendMessage: {...}           │        │
│  │ - scheduleAppointment: {...}    │        │
│  │ - patientLookup: {...}         │        │
│  │ - escalateToHuman: {...}       │        │
│  └──────────────────────────────────┘        │
└─────────────────────────────────────────────────┘
```

---

## Parallel Execution Strategy

### Sprint 1 Parallel Opportunities

**Week 1 - Parallel Tasks:**

These 3 tasks can be executed simultaneously:

- Subagent 1: Node Property Editing (Task 1.1)
- Subagent 2: Save Validation (Task 1.2)
- Subagent 3: Edge Deletion (Task 1.3)

**Week 2 - Parallel Tasks:**

These 2 tasks can be executed in parallel:

- Subagent 1: Wait Node Data Structure (Task 2.1)
- Subagent 2: Wait Node UI (Task 2.3)

Then sequential:

- Task 2.2: Wait System Logic (depends on Task 2.1)
- Task 2.4: Integrate Wait with AI (depends on Task 2.2)

### Sprint 2 Parallel Opportunities

**Week 3 - Parallel Tasks:**

These 2 tasks can be executed simultaneously:

- Subagent 1: Design AI Flow Structure (Task 3.1)
- Subagent 2: Import Flow to Builder (Task 3.3)

Then sequential:

- Task 3.2: Create AI Flow JSON (depends on Task 3.1)

**Week 4 - Parallel Tasks:**

These 2 tasks can be executed simultaneously:

- Subagent 1: System Prompt Export Function (Task 4.1)
- Subagent 2: Export Button UI (Task 4.2)

Then sequential:

- Task 4.3: Integrate System Prompt with AI (depends on Task 4.1)
- Task 4.4: Create Initial AI Flow (depends on Task 3.2)

---

## Quality Gates

### Before Moving to Sprint 2

Each task in Sprint 1 must meet these criteria:

**Flow Builder:**

- [ ] Users can create flows visually
- [ ] All node types editable
- [ ] Save validates before persisting
- [ ] Edge deletion works
- [ ] No critical bugs

**Wait System:**

- [ ] Wait system implemented (simple, in-memory)
- [ ] Wait node available in builder
- [ ] Wait node properties configurable
- [ ] AI can pause execution at wait node
- [ ] AI resumes after timeout or user response

### Before Launch

Each task in Sprint 2 must meet these criteria:

**AI Agent Guide Flow:**

- [ ] AI Agent Guide Flow created with all required nodes
- [ ] Flow structure is logical and complete
- [ ] Flow can be visualized in builder
- [ ] Flow can be edited if needed

**System Prompt Export:**

- [ ] System prompt generated with general instructions
- [ ] Flow JSON embedded in system prompt
- [ ] Node descriptions included
- [ ] Tool mappings included
- [ ] Export button works

**AI Integration:**

- [ ] AI receives system prompt on initialization
- [ ] AI receives tool definitions from flow
- [ ] AI follows flow structure
- [ ] AI uses tools correctly
- [ ] AI handles wait nodes properly

---

## Risk Management

### High-Risk Items

| Risk                    | Impact                     | Mitigation                              |
| ----------------------- | -------------------------- | --------------------------------------- |
| Wait system complexity  | AI might get stuck waiting | Keep it simple, in-memory, no database  |
| System prompt too large | AI context limit exceeded  | Minimize JSON, use concise descriptions |
| Tool mapping errors     | AI calls wrong tool        | Test each tool individually             |

### Low-Risk Items

| Risk                   | Impact                 | Mitigation                   |
| ---------------------- | ---------------------- | ---------------------------- |
| Flow structure changes | AI might get confused  | Provide clear documentation  |
| UI bugs                | Users can't edit flows | Test flow builder thoroughly |

---

## Getting Help

### Blocked on a Task?

If you're blocked:

1. **Check dependencies** - Are predecessor tasks complete?
2. **Review acceptance criteria** - Are you meeting all requirements?
3. **Consult documentation** - Sprint files have detailed requirements
4. **Ask for clarification** - Specific questions about requirements

### Technical Issues?

If you encounter technical issues:

1. **Review error messages** - What's the exact error?
2. **Check codebase** - Are there similar implementations to reference?
3. **Ask for help** - Team lead or documentation

---

## Success Definition

The Flows system is **production-ready** when:

### Core Functionality

- ✅ Flow builder allows creating flows visually
- ✅ All node properties editable
- ✅ Save/Load flows working
- ✅ Wait system pauses execution and resumes after timeout or user response

### AI Agent Guide Flow

- ✅ AI Agent Guide Flow created
- ✅ Flow includes nodes for all AI tools:
  - sendMessage
  - scheduleAppointment
  - patientLookup
  - escalateToHuman
- ✅ Wait node implemented and working
- ✅ Flow exported as JSON
- ✅ General instructions added above flow JSON
- ✅ System prompt ready for AI integration

### Simplicity

- ✅ No execution tracking
- ✅ No analytics/reporting
- ✅ No version management
- ✅ No audit logging
- ✅ Clean, focused codebase

---

## Timeline Visualization

```
Week 1  Week 2  Week 3  Week 4
┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐
│Sprint│ │Sprint│ │Sprint│ │Sprint│
│  1   │ │  1   │ │  2   │ │  2   │
│ (Week│ │ (Week│ │ (Week│ │ (Week│
│  1)  │ │  2)  │ │  3)  │ │  4)  │
└──────┘ └──────┘ └──────┘ └──────┘

    🚀 LAUNCH 🚀
```

---

## Final Notes

### Keep It Simple

This is NOT a complex enterprise flow system. It's a simple guide for AI.

**Do:**

- Visual flow builder
- Wait system for pausing
- Export to JSON
- Add to AI system prompt

**Don't:**

- Execution tracking
- Analytics
- Reporting
- Version management
- Audit logging

---

**Start Today:**

1. Read `sprint-01-flow-builder-wait.md`
2. Identify Week 1 parallel tasks (Tasks 1.1, 1.2, 1.3)
3. Deploy 3 subagents
4. Begin Sprint 1 execution

---

**Good luck!** 🚀
