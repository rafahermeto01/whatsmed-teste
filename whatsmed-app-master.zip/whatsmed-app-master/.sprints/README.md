# Flows System - Production Readiness Roadmap (Simplified)

**Status:** Active
**Timeline:** 4 weeks (1 month)
**Goal:** Simple flow builder to guide AI agent with wait system and JSON export for system prompt

---

## Roadmap Overview

A simplified roadmap for the Flows system focused on:

1. Creating and editing flows through a visual builder
2. Implementing wait system for pausing AI execution
3. Creating AI Agent Guide Flow with nodes for all tools
4. Exporting flow as JSON to be added to AI's system prompt

### Current State Assessment

- ✅ Phase 1: Data Model & Storage (passed)
- ✅ Phase 3: Flow Execution Engine (passed)
- ❌ Flow builder needs node property editing
- ❌ No wait system implemented
- ❌ No AI Agent Guide Flow created
- ❌ No export to system prompt format

### Target State (4 Weeks)

- ✅ Flow builder fully functional (create, edit, save)
- ✅ Wait system working (pause/resume with configurable timeout)
- ✅ AI Agent Guide Flow created with all tool nodes
- ✅ Flow exported as JSON for system prompt integration
- ✅ AI agent can follow flow structure
- ✅ Simple, clean, functional system

---

## Sprint Structure

| Sprint       | Duration  | Focus                        | Key Deliverable                  |
| ------------ | --------- | ---------------------------- | -------------------------------- |
| **Sprint 1** | Weeks 1-2 | Flow Builder & Wait System   | Functional flow builder + wait   |
| **Sprint 2** | Weeks 3-4 | AI Agent Guide Flow & Export | Complete AI flow + system prompt |

---

## Success Criteria

The system is production-ready when:

### Core Functionality

- ✅ Flow builder allows creating flows visually
- ✅ Node properties fully editable
- ✅ Save/Load flows working
- ✅ Wait system pauses execution and resumes after timeout or user response

### AI Agent Guide Flow

- ✅ AI Agent Guide Flow created
- ✅ Flow includes nodes for all AI tools:
  - sendMessage (send WhatsApp messages)
  - scheduleAppointment (schedule appointments)
  - patientLookup (retrieve patient data)
  - escalateToHuman (call humans, escalate conversations)
- ✅ Wait node implemented and working
- ✅ Flow structure exported as JSON
- ✅ General instructions added above flow JSON in system prompt

### Simplicity

- ✅ No execution tracking
- ✅ No analytics/reporting
- ✅ No version management
- ✅ No audit logging
- ✅ Clean, focused codebase

---

## Getting Started

**Current Position:** Start of Sprint 1, Week 1

**Next Steps:**

1. Read `sprint-01-flow-builder-wait.md`
2. Week 1 Tasks: Fix flow builder (node editing, save validation, edge deletion)
3. Week 2 Tasks: Implement wait system

**First Parallel Opportunity:**
Week 1 Tasks can be executed simultaneously by separate subagents.

---

**Last Updated:** Feb 12, 2026
**Next Review:** End of Sprint 1 (Week 2)
