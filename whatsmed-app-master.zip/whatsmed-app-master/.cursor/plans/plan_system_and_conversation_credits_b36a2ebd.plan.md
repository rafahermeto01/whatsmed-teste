---
name: Plan System and Conversation Credits
overview: Implement new plan structure with updated pricing, conversation credits system, credit purchase capability, and plan-based feature enforcement (user limits, conversation limits, feature gates).
todos:
  - id: schema-updates
    content: "Update schema: Add clinic fields for credit tracking (conversationCreditsUsed, conversationCreditsPurchased, billingCycleStart)"
    status: pending
  - id: plan-config
    content: Create plan configuration file with features, limits, and pricing
    status: pending
  - id: credits-system
    content: Create conversation credits system (queries, mutations, actions)
    status: pending
  - id: billing-updates
    content: Update billing system with new prices (497, 697) and credit purchase action
    status: pending
  - id: enforcement-utils
    content: Create plan enforcement utilities (user limits, conversation limits, feature gates)
    status: pending
  - id: enforce-user-limits
    content: Enforce user limits in users.ts and invites.ts
    status: pending
  - id: enforce-conversation-limits
    content: Enforce conversation limits in whatsappInternal.ts (lock chats without credits)
    status: pending
  - id: enforce-feature-gates
    content: Add feature gates to appointments, AI, integrations, NPS, check-in, telemedicine
    status: pending
  - id: credit-purchase-backend
    content: Implement credit purchase action and webhook handling
    status: pending
  - id: credit-purchase-ui
    content: Create PurchaseCreditsModal component
    status: pending
  - id: update-plan-modal
    content: Update PlanSelectionModal with new prices and features
    status: pending
  - id: update-billing-page
    content: Add credits widget to billing page
    status: pending
  - id: create-credits-widget
    content: Create CreditsWidget component for displaying credit status
    status: pending
  - id: create-plan-gate
    content: Create PlanGate component for feature gating
    status: pending
  - id: add-feature-gates-ui
    content: Add PlanGate to routes (appointments, integrations, NPS, check-in, telemedicine)
    status: pending
  - id: update-chat-list
    content: Update chat list to show locked chats and disable AI for locked chats
    status: pending
  - id: update-navigation
    content: Update MainLayout sidebar to hide/disable menu items based on plan
    status: pending
  - id: billing-cycle-reset
    content: Implement billing cycle reset logic (cron + webhook)
    status: pending
  - id: credit-analytics
    content: Add credit usage analytics and reporting
    status: pending
isProject: false
---

# Plan System and Conversation Credits Implementation

## Overview

This plan implements:

1. Updated plan structure with new pricing (Starter: R$497, Professional: R$697, Enterprise: custom)
2. Conversation credits system (one new chat = one credit, resets per billing cycle)
3. Purchase additional conversation credits (separate non-expiring pool)
4. Plan-based feature enforcement (user limits, conversation limits, feature gates)
5. UI updates for plan display and credit management

## Existing Infrastructure (DO NOT recreate)

The following systems already exist and should be leveraged:

- **Wallet/Transaction system**: `wallets` and `transactions` tables with balance tracking, top-ups, refunds
- **Subscription system**: `subscriptions` table with Asaas integration, status tracking
- **Payment provider**: Asaas (`packages/backend/convex/lib/asaas.ts`) with credit card, PIX, 3DS support
- **Payment methods**: `paymentMethods` table with card tokenization via Asaas
- **Plan fields on clinics**: `plan` (free|starter|professional|enterprise), `planStatus`, `asaasSubscriptionId`, `planValue`, `planNextDueDate`, `planCycle`
- **Current prices** (to be updated): free=0, starter=97, professional=197, enterprise=497
- **Cron infrastructure**: `packages/backend/convex/cron.ts` with existing hourly/daily jobs
- **Lib utilities**: `packages/backend/convex/lib/` has `asaas.ts`, `errors.ts`, `rbac.ts`, `multiTenant.ts`, `authContext.ts`, etc.
- **Frontend billing hooks**: `apps/web/src/hooks/billing.ts` with `useBillingWallet`, `useBillingSubscription`, etc.
- **Frontend billing components**: `PlanSelectionModal.tsx`, `AddFundsModal.tsx`, `ManageCardsModal.tsx`, `AutoRechargeModal.tsx`

## Architecture

### Data Model Changes

**Add to `clinics` table** (`packages/backend/convex/schema.ts` line 5-37):

```typescript
// Add these fields to the existing clinics defineTable:
conversationCreditsUsed: v.optional(v.number()),      // Credits used in current billing cycle
conversationCreditsPurchased: v.optional(v.number()),  // Purchased credits pool (never expires)
billingCycleStart: v.optional(v.number()),             // Timestamp of current cycle start
```

> **Note**: No separate `conversationCredits` table needed. Track everything on the `clinics` table directly to avoid joins and simplify queries.

**Plan Configuration:**

| Plan         | Price  | Users | Conversations/cycle |
| ------------ | ------ | ----- | ------------------- |
| Free         | R$0    | 1     | 10                  |
| Starter      | R$497  | 1     | 100                 |
| Professional | R$697  | 3     | 1,000               |
| Enterprise   | Custom | ∞     | ∞                   |

### Feature Gates

Features gated by plan:

- **Agenda/Appointments**: Professional+
- **Advanced AI**: Professional+
- **Integrations**: Professional+
- **NPS**: Professional+
- **Early Check-in**: Professional+
- **Teleconsulta**: Professional+
- **API Access**: Enterprise only
- **Unlimited users**: Enterprise only

---

## Execution Strategy — Using `parallel-execution-agent`

> **IMPORTANT**: Each batch below MUST be executed using the `parallel-execution-agent` (`.cursor/agents/parallel-execution-agent.md`). The agent analyzes dependencies within each batch and runs all independent steps simultaneously via parallel tool calls.
>
> Between batches, wait for completion before proceeding — batches have sequential dependencies on prior batches.

---

### BATCH 1 — Schema + Backend Core

**Agent**: `parallel-execution-agent`
**Dependencies**: None (all 4 steps are independent)
**Parallel steps**: 1.1, 1.2, 1.3, 1.4

**1.1 Update Schema** (`packages/backend/convex/schema.ts`)

- Add `conversationCreditsUsed`, `conversationCreditsPurchased`, `billingCycleStart` fields to `clinics` table (after line 34, before `createdAt`)
- All fields `v.optional(v.number())` for backward compatibility

**1.2 Create Plan Configuration** (`packages/backend/convex/lib/plans.ts` — NEW FILE)

- Define `PLAN_CONFIG` constant with per-plan: `price`, `maxUsers`, `maxConversations`, `features[]`
- Export `getPlanConfig(plan)`, `getPlanFeatures(plan)`, `hasPlanFeature(plan, feature)`
- Feature keys: `"appointments"`, `"advancedAi"`, `"integrations"`, `"nps"`, `"checkin"`, `"telemedicine"`, `"apiAccess"`
- Type exports: `PlanType`, `PlanFeature`, `PlanConfig`

**1.3 Create Conversation Credits System** (`packages/backend/convex/conversationCredits.ts` — NEW FILE)

- **Queries**:
  - `getCreditStatus(clinicId)` → returns `{ used, planLimit, purchased, available }`
- **Internal mutations**:
  - `consumeCredit(clinicId)` — increments `conversationCreditsUsed`, falls back to `conversationCreditsPurchased` if plan limit reached
  - `addPurchasedCredits(clinicId, amount)` — increments purchased pool
  - `resetBillingCycle(clinicId)` — resets `conversationCreditsUsed` to 0, updates `billingCycleStart`
- **Internal query**:
  - `checkCreditAvailability(clinicId)` → returns `{ hasCredit: boolean, source: "plan" | "purchased" | "none" }`

**1.4 Update Billing System** (`packages/backend/convex/billing.ts`)

- Update `PLAN_PRICES` (line 380-385): `starter: 497`, `professional: 697`, `enterprise: 997`
- Update `PLAN_NAMES` (line 387-392) if needed
- In `subscribeToPlan` handler (line 406-486): after `updateClinicPlan` call (line 461), add mutation to set `billingCycleStart: Date.now()` and reset `conversationCreditsUsed: 0`
- Add new action `purchaseConversationCredits(clinicId, quantity, billingType, cardId?)`:
  - Reuse existing `createTopUp` pattern (wallet lookup, card lookup, `asaas.createPayment`, `insertTransaction`)
  - Set transaction `reason: "credit_purchase"` and `meta: { creditQuantity: quantity }`
  - Return same `TopUpResult` shape (paymentId, status, pixQrCode, requires3DS, authorizationUrl)

---

### BATCH 2 — Plan Enforcement (Backend)

**Agent**: `parallel-execution-agent`
**Dependencies**: Batch 1 must be complete
**Parallel steps**: 2.1, 2.2, 2.3, 2.4

**2.1 Create Plan Enforcement Utilities** (`packages/backend/convex/lib/planEnforcement.ts` — NEW FILE)

- Import `PLAN_CONFIG` from `./plans`
- `async checkUserLimit(ctx, clinicId)` — count `clinicMembers` by clinicId, compare to plan's `maxUsers`, return `{ allowed: boolean, current, max }`
- `async checkConversationCredit(ctx, clinicId)` — read clinic's credit fields + plan config, return `{ hasCredit, source }`
- `async checkFeatureAccess(ctx, clinicId, feature)` — read clinic plan, check `hasPlanFeature`, return `{ allowed, requiredPlan }`
- All functions take `ctx` (QueryCtx or MutationCtx) as first arg to query DB directly (no action needed)

**2.2 Enforce User Limits**

- `packages/backend/convex/users.ts` — in `create` function: call `checkUserLimit` before inserting, throw `badRequest("Limite de usuários atingido. Faça upgrade do plano.")` if exceeded
- `packages/backend/convex/invites.ts` — in `create` function (invite creation): same check before inserting invite

**2.3 Enforce Conversation Limits** (`packages/backend/convex/whatsappInternal.ts`)

- In `handleIncomingMessage` where new chat is created (`ctx.db.insert("chats", {...})`): call `checkConversationCredit`
- If `hasCredit`: call `consumeCredit` after chat creation
- If `!hasCredit`: still create chat but with `status: "locked"` instead of `"open"`, add `lockedReason: "no_credits"`
- In AI processing: skip AI analysis for locked chats

**2.4 Enforce Feature Gates** (Multiple backend files)

For each file, add a check at the top of relevant mutations/queries:

- `packages/backend/convex/appointments.ts` — gate appointment creation
- `packages/backend/convex/automationAi.ts` — gate AI processing
- `packages/backend/convex/nps.ts` — gate NPS survey creation
- `packages/backend/convex/checkin.ts` — gate check-in creation

Pattern:

```typescript
const access = await checkFeatureAccess(ctx, clinicId, "appointments");
if (!access.allowed)
  throw badRequest(`Recurso disponível a partir do plano ${access.requiredPlan}.`);
```

---

### BATCH 3 — Credit Purchase + Webhook (Backend + Frontend)

**Agent**: `parallel-execution-agent`
**Dependencies**: Batch 1 must be complete
**Parallel steps**: 3.1, 3.2, 3.3

**3.1 Update Webhook Handler** (`packages/backend/convex/billing.ts`)

- In `processPaymentConfirmed` (line 598-627): check if transaction has `reason === "credit_purchase"` in meta
- If credit purchase: call `internal.conversationCredits.addPurchasedCredits` with `meta.creditQuantity` instead of adding to wallet balance
- If regular top-up: keep existing wallet balance logic

**3.2 Update `billing_internal.ts**`

- No new mutations needed for credits (handled in `conversationCredits.ts`)
- Add internal query `getTransactionByPaymentId(paymentId)` if not already available (currently uses filter, not index — consider adding index `by_asaas_payment_id` on transactions)

**3.3 Create Credit Purchase UI** (`apps/web/src/components/billing/PurchaseCreditsModal.tsx` — NEW FILE)

- Follow existing `AddFundsModal.tsx` pattern for structure, 3DS, and PIX flows
- Show current credit status (used/limit/purchased)
- Quantity selector: 50, 100, 200, custom input
- Price per credit (define constant, e.g., R$2/credit)
- Payment method selection reusing `useBillingPaymentMethods`
- Call `purchaseConversationCredits` action on submit

---

### BATCH 4 — Frontend Updates

**Agent**: `parallel-execution-agent`
**Dependencies**: Batch 1 must be complete (needs new queries)
**Parallel steps**: 4.1, 4.2, 4.3, 4.4

**4.1 Update Plan Selection Modal** (`apps/web/src/components/billing/PlanSelectionModal.tsx`)

- Update hardcoded prices to match new `PLAN_PRICES` (497, 697, custom)
- Update feature list per plan to include conversation limits and user limits
- Add conversation limit badges per plan card

**4.2 Update Billing Page** (`apps/web/src/routes/billing.tsx`)

- Add `CreditsWidget` component between wallet balance and plan status sections
- Add "Comprar Créditos" button that opens `PurchaseCreditsModal`

**4.3 Create Credits Widget** (`apps/web/src/components/billing/CreditsWidget.tsx` — NEW FILE)

- Display: `{used} / {planLimit} conversas usadas neste ciclo`
- Progress bar (green → yellow → red as usage increases)
- If `purchased > 0`: show `+ {purchased} créditos extras disponíveis`
- "Comprar Mais" button

**4.4 Update Billing Hooks** (`apps/web/src/hooks/billing.ts`)

- Add `useConversationCredits(clinicId)` — wraps `useQuery(api.conversationCredits.getCreditStatus, { clinicId })`
- Add `usePurchaseCredits()` — wraps `useAction(api.billing.purchaseConversationCredits)`

---

### BATCH 5 — UI Feature Gates + Navigation

**Agent**: `parallel-execution-agent`
**Dependencies**: Batch 1 must be complete
**Parallel steps**: 5.1, 5.2, 5.3, 5.4

**5.1 Create PlanGate Component** (`apps/web/src/components/PlanGate.tsx` — NEW FILE)

- Props: `feature: PlanFeature`, `children`, `fallback?`
- Uses `useConversationCredits` or a new `usePlanAccess(feature)` hook
- If feature allowed: render children
- If not: render upgrade prompt card with plan name required and "Fazer Upgrade" button linking to `PlanSelectionModal`

**5.2 Add Feature Gates to Routes**

- `apps/web/src/routes/appointments.tsx` — wrap content with `<PlanGate feature="appointments">`
- Integrations, NPS, check-in routes — same pattern
- Telemedicine modal — gate inside `TelehealthModal.tsx`

**5.3 Update Navigation** (`apps/web/src/components/MainLayout.tsx`)

- Sidebar `navItems` array (currently at component level): add `requiredFeature?` field
- For items with `requiredFeature`: check plan access, show lock icon or disable if not available
- Keep items visible but visually indicate locked state (drives upgrade interest)

**5.4 Update Chat List** (`apps/web/src/routes/whatsapp.tsx`)

- In chat list rendering: check chat `status === "locked"`
- Show lock icon overlay on locked chats
- When locked chat selected: show banner "Sem créditos de conversa. Compre mais créditos para desbloquear."
- Disable AI toggle for locked chats

---

### BATCH 6 — Billing Cycle Reset

**Agent**: `parallel-execution-agent`
**Dependencies**: Batch 1 must be complete
**Parallel steps**: 6.1, 6.2

**6.1 Add Billing Cycle Cron** (`packages/backend/convex/cron.ts`)

- Add daily job (e.g., `"0 4 * * *"` — 4 AM): `internal.conversationCredits.checkAndResetCycles`
- Implementation in `conversationCredits.ts`: query all clinics with `billingCycleStart` older than 30 days, call `resetBillingCycle` for each

**6.2 Update Subscription Webhook** (`packages/backend/convex/billing.ts`)

- In `processSubscriptionEvent` (line 679-728): when subscription renews (status changes to ACTIVE with new `nextDueDate`), also reset `conversationCreditsUsed` to 0 and update `billingCycleStart`
- This handles the primary reset path; the cron in 6.1 is a safety net

---

### BATCH 7 — Analytics

**Agent**: `parallel-execution-agent`
**Dependencies**: Batch 1 must be complete
**Parallel steps**: 7.1

**7.1 Add Credit Usage to Analytics**

- In `packages/backend/convex/conversationCredits.ts`: add `getCreditUsageStats(clinicId)` query returning current cycle usage, historical trend data
- Optionally extend dashboard in `apps/web/src/routes/dashboard.tsx` with credit usage summary

---

## File Changes Summary

### New Files (6)

| File                                                       | Purpose                                            |
| ---------------------------------------------------------- | -------------------------------------------------- |
| `packages/backend/convex/lib/plans.ts`                     | Plan config, limits, feature definitions           |
| `packages/backend/convex/lib/planEnforcement.ts`           | DB-level enforcement helpers                       |
| `packages/backend/convex/conversationCredits.ts`           | Credit queries, mutations, cycle reset             |
| `apps/web/src/components/billing/PurchaseCreditsModal.tsx` | Credit purchase UI (follows AddFundsModal pattern) |
| `apps/web/src/components/billing/CreditsWidget.tsx`        | Credit status display widget                       |
| `apps/web/src/components/PlanGate.tsx`                     | Feature gate wrapper component                     |

### Modified Files (15+)

| File                                                     | Change                                                     |
| -------------------------------------------------------- | ---------------------------------------------------------- |
| `packages/backend/convex/schema.ts`                      | Add 3 fields to clinics table                              |
| `packages/backend/convex/billing.ts`                     | Update prices, add credit purchase action, update webhooks |
| `packages/backend/convex/billing_internal.ts`            | Minor: transaction index or query helpers                  |
| `packages/backend/convex/cron.ts`                        | Add daily billing cycle reset job                          |
| `packages/backend/convex/users.ts`                       | Add user limit check in create                             |
| `packages/backend/convex/invites.ts`                     | Add user limit check in create                             |
| `packages/backend/convex/whatsappInternal.ts`            | Add credit check/consume on chat creation, locked status   |
| `packages/backend/convex/appointments.ts`                | Feature gate check                                         |
| `packages/backend/convex/automationAi.ts`                | Feature gate check                                         |
| `packages/backend/convex/nps.ts`                         | Feature gate check                                         |
| `packages/backend/convex/checkin.ts`                     | Feature gate check                                         |
| `apps/web/src/components/billing/PlanSelectionModal.tsx` | Update prices and feature lists                            |
| `apps/web/src/routes/billing.tsx`                        | Add CreditsWidget and PurchaseCreditsModal                 |
| `apps/web/src/hooks/billing.ts`                          | Add credit hooks                                           |
| `apps/web/src/components/MainLayout.tsx`                 | Lock/disable nav items by plan                             |
| `apps/web/src/routes/whatsapp.tsx`                       | Locked chat indicators                                     |
| `apps/web/src/routes/appointments.tsx`                   | PlanGate wrapper                                           |

---

## Batch Execution Summary

```
BATCH 1 ─── parallel-execution-agent ─── [1.1, 1.2, 1.3, 1.4] ─── No dependencies
    │
    ├── BATCH 2 ─── parallel-execution-agent ─── [2.1, 2.2, 2.3, 2.4] ─── Depends on Batch 1
    │
    ├── BATCH 3 ─── parallel-execution-agent ─── [3.1, 3.2, 3.3] ─── Depends on Batch 1
    │
    ├── BATCH 4 ─── parallel-execution-agent ─── [4.1, 4.2, 4.3, 4.4] ─── Depends on Batch 1
    │
    ├── BATCH 5 ─── parallel-execution-agent ─── [5.1, 5.2, 5.3, 5.4] ─── Depends on Batch 1
    │
    ├── BATCH 6 ─── parallel-execution-agent ─── [6.1, 6.2] ─── Depends on Batch 1
    │
    └── BATCH 7 ─── parallel-execution-agent ─── [7.1] ─── Depends on Batch 1
```

> Batches 2–7 are independent of each other and CAN be run as a single large parallel-execution-agent batch if desired. The only hard dependency is Batch 1 completing first.

## Testing Considerations

- Verify credit consumption: new chat decrements plan credits, then purchased credits
- Verify locked chat creation when all credits exhausted
- Verify billing cycle reset (both cron and webhook paths)
- Verify feature gates block correctly per plan tier
- Verify user limit enforcement on invite/user creation
- Verify credit purchase flow end-to-end (card + PIX)
- Verify plan upgrade resets cycle and updates limits
- Verify downgrade behavior (what happens to excess users/locked features)
