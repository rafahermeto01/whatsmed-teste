---
name: Remove Custom Auth Endpoints
overview: Remove custom HTTP auth endpoints and JWT system, keeping only Convex with BetterAuth. Migrate all API authentication to use BetterAuth sessions and update password reset to use native BetterAuth functionality.
todos:
  - id: update-auth-ts
    content: Add sendResetPassword callback to auth.ts for BetterAuth native password reset emails
    status: completed
  - id: clean-http-routes
    content: Remove custom auth endpoints from http.ts (/api/auth/login, logout, refresh, me, reset/*) and simplify authenticate()
    status: completed
  - id: delete-authhttp
    content: Delete packages/backend/convex/authHttp.ts file
    status: completed
  - id: delete-password-reset
    content: Delete packages/backend/convex/passwordReset.ts file
    status: completed
  - id: update-users
    content: Remove ensureOnLogin mutation from users.ts
    status: completed
  - id: update-schema
    content: Remove passwordResetTokens table from schema.ts
    status: completed
  - id: update-forgot-modal
    content: Update ForgotPasswordModal.tsx to use authClient.forgetPassword.email()
    status: completed
  - id: update-reset-page
    content: Update reset-password.tsx to use authClient.resetPassword()
    status: completed
---

# Remove Custom Auth Endpoints - Keep Convex + BetterAuth

## Overview

Remove the duplicated custom HTTP authentication system while keeping the Convex + BetterAuth integration as the single authentication mechanism.

## Changes Required

### 1. Backend: Update `auth.ts` - Add Password Reset Email Handler

Add `sendResetPassword` callback to send password reset emails via BetterAuth native functionality.

```typescript
// packages/backend/convex/auth.ts
emailAndPassword: {
  enabled: true,
  requireEmailVerification: false,
  sendResetPassword: async ({ user, url, token }, request) => {
    // Use existing email functionality
    void sendMail({
      to: user.email,
      subject: "Redefinir Senha - WhatsMed",
      html: passwordResetEmail({ resetUrl: url }).html,
    });
  },
},
```

### 2. Backend: Update `http.ts` - Remove Custom Auth Endpoints

**Remove these routes:**

- `/api/auth/login` (lines 140-225)
- `/api/auth/refresh` (lines 227-264)
- `/api/auth/logout` (lines 266-283)
- `/api/auth/reset/request` (lines 285-331)
- `/api/auth/reset/confirm` (lines 333-373)
- `/api/auth/me` (lines 375-398)

**Remove these helper functions:**

- `setAuthCookies`
- `getRefreshToken`
- `generateId`

**Simplify `authenticate` function** - Only use BetterAuth session:

```typescript
async function authenticate(ctx: any, request: Request) {
  const auth = createAuth(ctx);
  const session = await (auth as any).api.getSession({
    headers: request.headers,
  });

  if (session?.user) {
    return {
      sub: session.user.id,
      clinicId: session.user.clinicId,
      role: session.user.role,
      email: session.user.email,
    };
  }

  return null;
}
```

### 3. Backend: Remove `authHttp.ts`

Delete the entire file `packages/backend/convex/authHttp.ts` since JWT issuing/decoding is no longer needed.

### 4. Backend: Remove `passwordReset.ts`

Delete `packages/backend/convex/passwordReset.ts` - BetterAuth handles password reset tokens internally.

### 5. Backend: Update `users.ts` - Remove `ensureOnLogin`

The `ensureOnLogin` mutation was called from the custom login endpoint. The existing `onCreate` trigger in `auth.ts` already handles user creation on signup.

### 6. Backend: Clean up Schema

Remove `passwordResetTokens` table from `schema.ts` (BetterAuth manages reset tokens in its internal tables).

### 7. Frontend: Update `ForgotPasswordModal.tsx`

Use BetterAuth's native `authClient.forgetPassword.email()`:

```typescript
import { authClient } from "@/lib/auth-client";

const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  try {
    await authClient.forgetPassword.email({
      email,
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setSubmitted(true);
    setTimeout(() => onClose(), 2000);
  } catch (err) {
    console.error(err);
    // Show error toast
  }
};
```

### 8. Frontend: Update `reset-password.tsx`

Use BetterAuth's native `authClient.resetPassword()`:

```typescript
mport { authClient } from "@/lib/auth-client";

const onSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  if (!isFormValid) return;
  try {
    const { error } = await authClient.resetPassword({
      newPassword,
      token: search.token,
    });
    if (error) throw new Error(error.message);
    navigate({ to: "/login" });
  } catch (err) {
    console.error(err);
    // Show error toast
  }
};
```

## Files to Modify

| File | Action |

|------|--------|

| `packages/backend/convex/auth.ts` | Add `sendResetPassword` callback |

| `packages/backend/convex/http.ts` | Remove auth endpoints, simplify authenticate() |

| `packages/backend/convex/authHttp.ts` | **DELETE** |

| `packages/backend/convex/passwordReset.ts` | **DELETE** |

| `packages/backend/convex/users.ts` | Remove `ensureOnLogin` mutation |

| `packages/backend/convex/schema.ts` | Remove `passwordResetTokens` table |

| `apps/web/src/components/ForgotPasswordModal.tsx` | Use `authClient.forgetPassword.email()` |

| `apps/web/src/routes/reset-password.tsx` | Use `authClient.resetPassword()` |

## Architecture After Changes

```mermaid
flowchart TD
    subgraph Frontend
        A[Login Page] --> B[authClient.signIn.email]
        C[Forgot Password Modal] --> D[authClient.forgetPassword.email]
        E[Reset Password Page] --> F[authClient.resetPassword]
    end

    subgraph BetterAuth
        B --> G[/api/auth/*]
        D --> G
        F --> G
        G --> H[Session Cookie]
    end

    subgraph ConvexHTTP
        I[/api/users] --> J[authenticate via session]
        K[/api/patients] --> J
        L[Other APIs] --> J
        J --> H
    end
```

## Notes

- The `AUTH_JWT_SECRET` environment variable can be removed after this migration
- All existing users will continue to work since BetterAuth manages user sessions
- The `onCreate` trigger in auth.ts handles creating app users on signup
- HTTP API authentication now relies solely on BetterAuth session cookies
