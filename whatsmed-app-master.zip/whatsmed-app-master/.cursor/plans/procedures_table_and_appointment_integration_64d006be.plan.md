---
name: Procedures table and appointment integration
overview: Add a procedures table with RBAC (doctors/admins only), integrate with appointment creation and availability checking, add UI in settings for doctors to manage their procedures, and update agent tools.
todos:
  - id: schema-procedures
    content: Add procedures table to schema.ts with indexes (by_clinic, by_clinic_doctor, by_clinic_active) and search index. Add procedureId field to appointments table.
    status: pending
  - id: procedures-crud
    content: Create procedures.ts with list (paginated), create, update, delete mutations. Implement RBAC checks using requireRole helper.
    status: pending
    dependencies:
      - schema-procedures
  - id: appointments-integration
    content: Update appointments.create to accept procedureId, validate procedure, and auto-calculate endAt. Update getDoctorAvailability and getAvailableSlots to filter by procedure duration.
    status: pending
    dependencies:
      - schema-procedures
      - procedures-crud
  - id: procedures-ui
    content: Create ProceduresSettings.tsx component mirroring WorkingHoursSettings patterns. Add to settings page preferences tab for doctors only.
    status: pending
    dependencies:
      - procedures-crud
  - id: appointment-modal
    content: Update CreateAppointmentModal to add procedure dropdown after doctor selection, auto-set duration from procedure, pass procedureId to create mutation.
    status: pending
    dependencies:
      - appointments-integration
  - id: agent-tools
    content: Update checkDoctorAvailabilityTool to accept procedureName parameter. Add listProceduresTool for agents to discover available procedures.
    status: pending
    dependencies:
      - appointments-integration
---

# Procedures Table and Appointment Integration

## Overview

Add a procedures table to track medical procedures that doctors can perform, along with their durations. Integrate procedures into appointment creation and availability checking. Add UI in settings for doctors to manage procedures.

---

## 1. Database Schema Changes

### Add `procedures` table to `packages/backend/convex/schema.ts`

```typescript
procedures: defineTable({
  clinicId: v.string(),
  doctorId: v.id("users"),
  name: v.string(),
  description: v.optional(v.string()),
  durationMinutes: v.number(),
  price: v.optional(v.number()),
  isActive: v.boolean(),
  createdAt: v.number(),
  updatedAt: v.optional(v.number()),
  deletedAt: v.optional(v.number()),
})
  .index("by_clinic", ["clinicId"])
  .index("by_clinic_doctor", ["clinicId", "doctorId"])
  .index("by_clinic_active", ["clinicId", "isActive"])
  .searchIndex("search_name", {
    searchField: "name",
    filterFields: ["clinicId", "doctorId", "isActive"],
  }),
```

**Fields explained:**

- `clinicId`: String for multi-tenancy (following existing pattern)
- `doctorId`: Reference to the doctor who performs this procedure
- `name`: Procedure name (e.g., "Limpeza Dental", "Implante")
- `description`: Optional detailed description
- `durationMinutes`: Duration in minutes (e.g., 30, 60, 120)
- `price`: Optional price for the procedure
- `isActive`: Boolean to enable/disable without deleting
- `createdAt`, `updatedAt`, `deletedAt`: Standard timestamps (milliseconds)

### Update `appointments` table

Add after existing fields:

```typescript
procedureId: v.optional(v.id("procedures")),
```

---

## 2. Backend Functions

### Create `packages/backend/convex/procedures.ts`

```typescript
import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { requireRole } from "./lib/rbac";
import { notFound, forbidden } from "./lib/errors";
import { sanitizeString } from "./lib/validation";
import { paginationOptsValidator } from "convex/server";

// ===== QUERIES =====

export const list = query({
  args: {
    doctorId: v.optional(v.id("users")),
    includeInactive: v.optional(v.boolean()),
    paginationOpts: paginationOptsValidator,
  },
  handler: async (ctx, args) => {
    const { clinicId, role, identity } = await requireRole(ctx, [
      "admin",
      "staff",
      "doctor",
      "viewer",
    ]);

    let q = ctx.db.query("procedures").withIndex("by_clinic_doctor");

    // If user is doctor, only show their procedures
    const effectiveDoctorId =
      role === "doctor"
        ? (
            await ctx.db
              .query("users")
              .withIndex("by_email", (q) => q.eq("email", identity.email as string))
              .first()
          )?._id
        : args.doctorId;

    if (effectiveDoctorId) {
      q = q.filter((q) =>
        q.and(
          q.eq(q.field("clinicId"), clinicId),
          q.eq(q.field("doctorId"), effectiveDoctorId),
          q.eq(q.field("deletedAt"), undefined),
        ),
      );
    } else {
      q = q.filter((q) =>
        q.and(q.eq(q.field("clinicId"), clinicId), q.eq(q.field("deletedAt"), undefined)),
      );
    }

    // Filter inactive if not requested
    if (!args.includeInactive) {
      q = q.filter((q) => q.eq(q.field("isActive"), true));
    }

    return await q.paginate(args.paginationOpts);
  },
});

export const getById = query({
  args: { id: v.id("procedures") },
  handler: async (ctx, args) => {
    const { clinicId } = await requireRole(ctx, ["admin", "staff", "doctor", "viewer"]);

    const procedure = await ctx.db.get(args.id);
    if (!procedure || procedure.deletedAt || procedure.clinicId !== clinicId) {
      return null;
    }

    return procedure;
  },
});

export const listByDoctor = query({
  args: { doctorId: v.id("users") },
  handler: async (ctx, args) => {
    const { clinicId } = await requireRole(ctx, ["admin", "staff", "doctor", "viewer"]);

    return await ctx.db
      .query("procedures")
      .withIndex("by_clinic_doctor", (q) =>
        q.eq("clinicId", clinicId).eq("doctorId", args.doctorId),
      )
      .filter((q) => q.and(q.eq(q.field("isActive"), true), q.eq(q.field("deletedAt"), undefined)))
      .collect();
  },
});

// ===== MUTATIONS =====

export const create = mutation({
  args: {
    doctorId: v.optional(v.id("users")), // Optional for admins
    name: v.string(),
    description: v.optional(v.string()),
    durationMinutes: v.number(),
    price: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const { clinicId, role, identity } = await requireRole(ctx, ["admin", "doctor"]);

    // Get current user for doctor role
    const currentUser = await ctx.db
      .query("users")
      .withIndex("by_email", (q) => q.eq("email", identity.email as string))
      .first();

    // Determine doctor ID
    let doctorId = args.doctorId;
    if (role === "doctor") {
      // Doctors can only create for themselves
      doctorId = currentUser?._id;
    } else if (!doctorId) {
      throw forbidden("Admin must specify doctorId");
    }

    // Validate doctor exists and belongs to clinic
    const doctor = await ctx.db.get(doctorId!);
    if (!doctor || doctor.clinicId !== clinicId || doctor.role !== "doctor") {
      throw notFound("Doctor not found");
    }

    // Validate duration (15 min to 480 min / 8 hours)
    if (args.durationMinutes < 15 || args.durationMinutes > 480) {
      throw forbidden("Duration must be between 15 and 480 minutes");
    }

    return await ctx.db.insert("procedures", {
      clinicId,
      doctorId: doctorId!,
      name: sanitizeString(args.name, 100),
      description: args.description ? sanitizeString(args.description, 500) : undefined,
      durationMinutes: args.durationMinutes,
      price: args.price,
      isActive: true,
      createdAt: Date.now(),
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("procedures"),
    name: v.optional(v.string()),
    description: v.optional(v.string()),
    durationMinutes: v.optional(v.number()),
    price: v.optional(v.number()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const { clinicId, role, identity } = await requireRole(ctx, ["admin", "doctor"]);

    const procedure = await ctx.db.get(args.id);
    if (!procedure || procedure.deletedAt || procedure.clinicId !== clinicId) {
      throw notFound("Procedure not found");
    }

    // Doctors can only update their own procedures
    if (role === "doctor") {
      const currentUser = await ctx.db
        .query("users")
        .withIndex("by_email", (q) => q.eq("email", identity.email as string))
        .first();

      if (procedure.doctorId !== currentUser?._id) {
        throw forbidden("You can only update your own procedures");
      }
    }

    // Validate duration if provided
    if (args.durationMinutes !== undefined) {
      if (args.durationMinutes < 15 || args.durationMinutes > 480) {
        throw forbidden("Duration must be between 15 and 480 minutes");
      }
    }

    const updateData: Record<string, any> = { updatedAt: Date.now() };
    if (args.name !== undefined) updateData.name = sanitizeString(args.name, 100);
    if (args.description !== undefined)
      updateData.description = sanitizeString(args.description, 500);
    if (args.durationMinutes !== undefined) updateData.durationMinutes = args.durationMinutes;
    if (args.price !== undefined) updateData.price = args.price;
    if (args.isActive !== undefined) updateData.isActive = args.isActive;

    await ctx.db.patch(args.id, updateData);
    return args.id;
  },
});

export const softDelete = mutation({
  args: { id: v.id("procedures") },
  handler: async (ctx, args) => {
    const { clinicId, role, identity } = await requireRole(ctx, ["admin", "doctor"]);

    const procedure = await ctx.db.get(args.id);
    if (!procedure || procedure.deletedAt || procedure.clinicId !== clinicId) {
      throw notFound("Procedure not found");
    }

    // Doctors can only delete their own procedures
    if (role === "doctor") {
      const currentUser = await ctx.db
        .query("users")
        .withIndex("by_email", (q) => q.eq("email", identity.email as string))
        .first();

      if (procedure.doctorId !== currentUser?._id) {
        throw forbidden("You can only delete your own procedures");
      }
    }

    await ctx.db.patch(args.id, { deletedAt: Date.now() });
    return args.id;
  },
});
```

---

## 3. Appointments Integration

### Update `packages/backend/convex/appointments.ts`

#### Update `create` mutation args:

```typescript
args: {
  // ... existing args
  procedureId: v.optional(v.id("procedures")),
},
```

#### Add procedure validation and duration calculation in create handler:

```typescript
// After doctor validation, before creating appointment:

let calculatedEndAt = endAt;
if (args.procedureId) {
  const procedure = await ctx.db.get(args.procedureId);
  if (!procedure || procedure.deletedAt) {
    throw notFound("Procedure not found");
  }
  if (procedure.clinicId !== clinicId) {
    throw forbidden("Procedure does not belong to this clinic");
  }
  if (procedure.doctorId !== args.doctorId) {
    throw forbidden("Procedure does not belong to this doctor");
  }
  if (!procedure.isActive) {
    throw forbidden("Procedure is not active");
  }

  // Calculate endAt from procedure duration
  calculatedEndAt = startAt + procedure.durationMinutes * 60 * 1000;
}

// Use calculatedEndAt when inserting the appointment
```

#### Update `getAvailableSlots` query:

```typescript
args: {
  // ... existing args
  procedureId: v.optional(v.id("procedures")),
},

// In handler:
let slotDuration = 30; // default 30 minutes
if (args.procedureId) {
  const procedure = await ctx.db.get(args.procedureId);
  if (procedure && !procedure.deletedAt && procedure.isActive) {
    slotDuration = procedure.durationMinutes;
  }
}

// Use slotDuration when calculating available slots
// Filter slots to ensure enough consecutive time for the procedure
```

#### Update `getDoctorAvailability` query:

```typescript
args: {
  // ... existing args
  procedureId: v.optional(v.id("procedures")),
},

// In handler, same pattern as getAvailableSlots
```

---

## 4. Frontend Components

### Create `apps/web/src/components/settings/ProceduresSettings.tsx`

```tsx
import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, Clock } from "lucide-react";
import { toast } from "sonner";

interface Procedure {
  _id: Id<"procedures">;
  name: string;
  description?: string;
  durationMinutes: number;
  price?: number;
  isActive: boolean;
}

export function ProceduresSettings() {
  const currentUser = useQuery(api.auth.getCurrentUserWithClinic);
  const procedures = useQuery(api.procedures.list, {
    includeInactive: true,
    paginationOpts: { numItems: 100, cursor: null },
  });

  const createProcedure = useMutation(api.procedures.create);
  const updateProcedure = useMutation(api.procedures.update);
  const deleteProcedure = useMutation(api.procedures.softDelete);

  const [isOpen, setIsOpen] = useState(false);
  const [editingProcedure, setEditingProcedure] = useState<Procedure | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    durationMinutes: 30,
    price: 0,
  });

  // Only show for doctors
  if (currentUser?.role !== "doctor") {
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      if (editingProcedure) {
        await updateProcedure({
          id: editingProcedure._id,
          name: formData.name,
          description: formData.description || undefined,
          durationMinutes: formData.durationMinutes,
          price: formData.price || undefined,
        });
        toast.success("Procedimento atualizado");
      } else {
        await createProcedure({
          name: formData.name,
          description: formData.description || undefined,
          durationMinutes: formData.durationMinutes,
          price: formData.price || undefined,
        });
        toast.success("Procedimento criado");
      }

      setIsOpen(false);
      setEditingProcedure(null);
      setFormData({ name: "", description: "", durationMinutes: 30, price: 0 });
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar procedimento");
    }
  };

  const handleEdit = (procedure: Procedure) => {
    setEditingProcedure(procedure);
    setFormData({
      name: procedure.name,
      description: procedure.description || "",
      durationMinutes: procedure.durationMinutes,
      price: procedure.price || 0,
    });
    setIsOpen(true);
  };

  const handleDelete = async (id: Id<"procedures">) => {
    if (!confirm("Tem certeza que deseja excluir este procedimento?")) return;

    try {
      await deleteProcedure({ id });
      toast.success("Procedimento excluído");
    } catch (error: any) {
      toast.error(error.message || "Erro ao excluir procedimento");
    }
  };

  const handleToggleActive = async (procedure: Procedure) => {
    try {
      await updateProcedure({
        id: procedure._id,
        isActive: !procedure.isActive,
      });
      toast.success(procedure.isActive ? "Procedimento desativado" : "Procedimento ativado");
    } catch (error: any) {
      toast.error(error.message || "Erro ao atualizar procedimento");
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Procedimentos</CardTitle>
        <Dialog
          open={isOpen}
          onOpenChange={(open) => {
            setIsOpen(open);
            if (!open) {
              setEditingProcedure(null);
              setFormData({
                name: "",
                description: "",
                durationMinutes: 30,
                price: 0,
              });
            }
          }}
        >
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Adicionar
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingProcedure ? "Editar" : "Novo"} Procedimento</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Nome</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ex: Limpeza Dental"
                  required
                />
              </div>
              <div>
                <Label htmlFor="description">Descrição (opcional)</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Descrição do procedimento..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="duration">Duração (minutos)</Label>
                  <Input
                    id="duration"
                    type="number"
                    min={15}
                    max={480}
                    value={formData.durationMinutes}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        durationMinutes: parseInt(e.target.value) || 30,
                      })
                    }
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="price">Preço (opcional)</Label>
                  <Input
                    id="price"
                    type="number"
                    min={0}
                    step={0.01}
                    value={formData.price}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        price: parseFloat(e.target.value) || 0,
                      })
                    }
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">Salvar</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        {procedures?.page?.length === 0 ? (
          <p className="text-muted-foreground text-center py-4">Nenhum procedimento cadastrado</p>
        ) : (
          <div className="space-y-2">
            {procedures?.page?.map((procedure) => (
              <div
                key={procedure._id}
                className={`flex items-center justify-between p-3 border rounded-lg ${
                  !procedure.isActive ? "opacity-50" : ""
                }`}
              >
                <div className="flex items-center gap-3">
                  <Switch
                    checked={procedure.isActive}
                    onCheckedChange={() => handleToggleActive(procedure)}
                  />
                  <div>
                    <p className="font-medium">{procedure.name}</p>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {procedure.durationMinutes} min
                      {procedure.price && ` • R$ ${procedure.price.toFixed(2)}`}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="icon" variant="ghost" onClick={() => handleEdit(procedure)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => handleDelete(procedure._id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
```

### Update `apps/web/src/routes/settings.tsx`

Add import and component:

```tsx
import { ProceduresSettings } from "@/components/settings/ProceduresSettings";

// In the "preferences" tab content, after WorkingHoursSettings:
<ProceduresSettings />;
```

---

## 5. Update CreateAppointmentModal

### Add to `apps/web/src/components/CreateAppointmentModal.tsx`

```tsx
// Add query for procedures based on selected doctor
const procedures = useQuery(
  api.procedures.listByDoctor,
  selectedDoctor ? { doctorId: selectedDoctor } : "skip",
);

// Add state for selected procedure
const [selectedProcedure, setSelectedProcedure] = useState<Id<"procedures"> | null>(null);

// Add procedure selection after doctor dropdown:
{
  selectedDoctor && procedures && procedures.length > 0 && (
    <div>
      <Label>Procedimento (opcional)</Label>
      <Select
        value={selectedProcedure || "none"}
        onValueChange={(value) => {
          if (value === "none") {
            setSelectedProcedure(null);
            setDuration(30); // Reset to default
          } else {
            const procedure = procedures.find((p) => p._id === value);
            setSelectedProcedure(value as Id<"procedures">);
            if (procedure) {
              setDuration(procedure.durationMinutes);
            }
          }
        }}
      >
        <SelectTrigger>
          <SelectValue placeholder="Selecione um procedimento" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="none">Nenhum</SelectItem>
          {procedures.map((procedure) => (
            <SelectItem key={procedure._id} value={procedure._id}>
              {procedure.name} ({procedure.durationMinutes} min)
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

// Disable duration input when procedure is selected
<Input
  type="number"
  value={duration}
  onChange={(e) => setDuration(parseInt(e.target.value))}
  disabled={!!selectedProcedure}
  min={15}
  max={480}
/>;

// Pass procedureId to create mutation
await createAppointment({
  // ... existing args
  procedureId: selectedProcedure || undefined,
});

// Pass procedureId to getAvailableSlots query
const availableSlots = useQuery(
  api.appointments.getAvailableSlots,
  selectedDoctor && selectedDate
    ? {
        doctorId: selectedDoctor,
        date: selectedDate,
        procedureId: selectedProcedure || undefined,
      }
    : "skip",
);
```

---

## 6. Agent Tools Updates

### Update `packages/backend/mastra/tools.ts`

#### Add `listProceduresTool`:

```typescript
export const listProceduresTool = (ctx: any, clinicId: string) =>
  createTool({
    id: "list-procedures",
    description:
      "List available medical procedures for a specific doctor. Returns procedure names and durations.",
    inputSchema: z.object({
      doctorName: z.string().describe("Name of the doctor to list procedures for"),
    }),
    execute: async ({ context }) => {
      const { doctorName } = context;

      // Find doctor by name
      const doctors = await ctx.runQuery(api.users.searchUsers, {
        clinicId,
        query: doctorName,
        role: "doctor",
      });

      if (!doctors || doctors.length === 0) {
        return { success: false, message: "Doctor not found" };
      }

      const doctor = doctors[0];

      // Get procedures for this doctor
      const procedures = await ctx.runQuery(api.procedures.listByDoctor, {
        doctorId: doctor._id,
      });

      return {
        success: true,
        doctor: { id: doctor._id, name: doctor.name },
        procedures: procedures.map((p: any) => ({
          id: p._id,
          name: p.name,
          durationMinutes: p.durationMinutes,
          description: p.description,
        })),
      };
    },
  });
```

#### Update `checkDoctorAvailabilityTool`:

```typescript
inputSchema: z.object({
  doctorName: z.string().describe("Name of the doctor to check availability for"),
  startDate: z.string().describe("Start date in YYYY-MM-DD format"),
  endDate: z.string().describe("End date in YYYY-MM-DD format"),
  procedureName: z.string().optional().describe("Optional: Name of the procedure to check availability for (affects slot duration)"),
}),

execute: async ({ context }) => {
  const { doctorName, startDate, endDate, procedureName } = context;

  // ... existing doctor lookup code ...

  // If procedure name provided, find the procedure
  let procedureId = undefined;
  if (procedureName) {
    const procedures = await ctx.runQuery(api.procedures.listByDoctor, {
      doctorId: doctor._id,
    });
    const procedure = procedures.find(
      (p: any) => p.name.toLowerCase().includes(procedureName.toLowerCase())
    );
    if (procedure) {
      procedureId = procedure._id;
    }
  }

  // Pass procedureId to availability query
  const availability = await ctx.runQuery(api.appointments.getDoctorAvailability, {
    doctorId: doctor._id,
    startDate,
    endDate,
    procedureId,
  });

  // ... rest of the function ...
};
```

#### Add to `createConvexTools`:

```typescript
export function createConvexTools(ctx: any, clinicId: string) {
  return {
    // ... existing tools ...
    listProcedures: listProceduresTool(ctx, clinicId),
  };
}
```

---

## Files to Modify

| File | Action | Description |

|------|--------|-------------|

| `packages/backend/convex/schema.ts` | Modify | Add `procedures` table, update `appointments` table |

| `packages/backend/convex/procedures.ts` | Create | New file with CRUD operations |

| `packages/backend/convex/appointments.ts` | Modify | Add procedureId support to create, getAvailableSlots, getDoctorAvailability |

| `apps/web/src/components/settings/ProceduresSettings.tsx` | Create | New settings component for procedures |

| `apps/web/src/routes/settings.tsx` | Modify | Import and add ProceduresSettings |

| `apps/web/src/components/CreateAppointmentModal.tsx` | Modify | Add procedure selection dropdown |

| `packages/backend/mastra/tools.ts` | Modify | Add listProceduresTool, update checkDoctorAvailabilityTool |

---

## Key Implementation Notes

1. **Multi-tenancy**: All queries/mutations validate `clinicId` matches
2. **RBAC**: Use `requireRole` helper; doctors can only manage their own procedures
3. **Soft delete**: Set `deletedAt` field, never hard delete
4. **Duration validation**: 15 min minimum, 480 min (8 hours) maximum
5. **Procedure override**: When `procedureId` is provided, it overrides manual duration
6. **Search index**: Enables fuzzy search for procedure names
7. **isActive flag**: Allows disabling procedures without deleting
8. **Price field**: Optional, for future billing integration
9. **Agent tools**: Support procedure-aware availability checking
10. **Portuguese UI**: All user-facing text in Portuguese (as per existing convention)
