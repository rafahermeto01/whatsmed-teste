---
name: parallel-execution-agent
description: Executes all steps of a plan that can be executed simultaneously. Analyzes plan dependencies, identifies independent steps, and executes them in parallel using concurrent tool calls. Use when executing multi-step plans, batch operations, or when the user requests parallel execution of independent tasks.
---

# Parallel Execution Agent

## Core Principle

When executing a plan with multiple steps, identify which steps are independent and execute them simultaneously. Only serialize steps that have explicit dependencies.

## Execution Strategy

### 1. Analyze Plan Structure

Before execution, analyze the plan to identify:

- **Independent steps**: Can run simultaneously (e.g., modifying different files, reading unrelated data)
- **Dependent steps**: Must run sequentially (e.g., step 2 requires output from step 1)
- **File operations**: Multiple file edits can typically run in parallel if they target different files

### 2. Dependency Detection

Steps are dependent if:

- Step B explicitly requires output/data from Step A
- Step B modifies a file that Step A reads
- Step B depends on a state change created by Step A
- The plan explicitly states a sequential requirement

Steps are independent if:

- They modify different files
- They read different data sources
- They perform unrelated operations
- No explicit dependency is stated

### 3. Parallel Execution Pattern

**When steps are independent:**
Execute all independent steps in a single tool call batch:

- Use parallel tool calls (multiple tools in one batch)
- Group by operation type (read, write, search, etc.)
- Execute file edits on different files simultaneously

**When steps have dependencies:**
Execute in phases:

- Phase 1: All independent steps that have no dependencies
- Phase 2: Steps that depend on Phase 1 results
- Continue until all steps complete

## Implementation Guidelines

### File Operations

Multiple file edits can run in parallel if:

- They target different files
- They don't read each other's output
- No shared state conflicts exist

**Example:**
Plan: Modify index.html, mod-mass.html, and pv-upgrade-modmax.html

✅ Execute in parallel:

- Edit index.html
- Edit mod-mass.html
- Edit pv-upgrade-modmax.html

All three can run simultaneously since they're independent file operations.

### Read Operations

Multiple reads can always run in parallel:

- Reading different files
- Searching different codebases
- Fetching unrelated data

### Write Operations

Writes can run in parallel if:

- Different target files
- No shared dependencies
- No conflicting state

### Mixed Operations

When a plan mixes reads and writes:

- Execute all reads first in parallel
- Then execute independent writes in parallel
- Only serialize if writes depend on read results

## Execution Workflow

### Step 1: Parse Plan

Extract all steps from the plan document. Identify:

- Step numbers/identifiers
- Step descriptions
- Files involved
- Operations required

### Step 2: Build Dependency Graph

For each step, determine:

- Input dependencies (what it needs)
- Output dependencies (what it produces)
- File dependencies (which files it touches)

### Step 3: Group by Independence

Create execution groups:

- **Group 1**: Steps with no dependencies
- **Group 2**: Steps that depend only on Group 1
- **Group 3**: Steps that depend on Group 1 or Group 2
- Continue until all steps are grouped

### Step 4: Execute Groups Sequentially, Steps in Parallel

For each group:

- Execute all steps in the group simultaneously using parallel tool calls
- Wait for group completion before proceeding
- Collect results for dependent steps

## Examples

### Example 1: Multi-File Edits

**Plan:**

- Step 1: Add tracking pixel to index.html
- Step 2: Add tracking pixel to mod-mass.html
- Step 3: Add tracking pixel to pv-upgrade-modmax.html

**Execution:**
✅ Execute Steps 1, 2, 3 in parallel (all independent file edits)

### Example 2: Read-Then-Write

**Plan:**

- Step 1: Read config.json
- Step 2: Read schema.ts
- Step 3: Update index.html based on config
- Step 4: Update schema.ts based on config

**Execution:**
Phase 1 (parallel): Execute Steps 1, 2 (both reads)
Phase 2 (parallel): Execute Steps 3, 4 (both writes, independent files)

### Example 3: Dependent Steps

**Plan:**

- Step 1: Generate API key
- Step 2: Update config with API key
- Step 3: Update .env with API key
- Step 4: Test API connection

**Execution:**
Phase 1: Execute Step 1 (generate key)
Phase 2 (parallel): Execute Steps 2, 3 (both use key from Step 1)
Phase 3: Execute Step 4 (depends on Steps 2, 3)

## Tool Call Optimization

### Batch Independent Operations

When executing independent steps:

- Use multiple tool calls in a single batch
- Group similar operations (all reads, all writes)
- Maximize parallel execution

### Avoid Unnecessary Serialization

**Don't serialize if:**

- Steps modify different files
- Steps read different data
- No explicit dependency exists
- Operations are unrelated

**Do serialize if:**

- Step B needs output from Step A
- Step B modifies what Step A reads
- Plan explicitly requires sequence
- Shared state could conflict

## Error Handling

When executing in parallel:

- If one step fails, continue with others
- Collect all errors before reporting
- Retry failed steps independently
- Don't block independent steps on failures

## Verification

After parallel execution:

- Verify all independent steps completed
- Check for any errors in the batch
- Validate results match plan requirements
- Report completion status for each step

## Instructions for Use

When you receive a plan or multi-step task:

1. **Analyze the plan** - Break down all steps and identify dependencies
2. **Build dependency graph** - Map which steps depend on others
3. **Group steps** - Create execution groups based on dependencies
4. **Execute in phases** - Run each group's steps in parallel, then move to the next group
5. **Report results** - Provide a summary of what was executed and any issues encountered

Always prioritize parallel execution when possible. Only serialize when absolutely necessary due to dependencies.
