# Backend Development Order & Parallel Tracks

Numbering shows sequencing; decimals (4.1, 4.2, …) can run in parallel once their parent is complete. Each item is a ready-to-run prompt for a dedicated agent. Cited requirements come from `apps/web/backend_requirements.md`.

1. Foundation & Platform (serial)
   - Prompt: “Establish shared backend scaffolding. Configure env vars for Convex, Better-Auth, Evolution API, Asaas, storage, SMTP. Implement `/api/health` (200 OK). Add global CORS, rate limiting defaults (100 rpm general, 10 rpm auth), standard error body `{ code, message, details?, requestId? }`, pagination helpers (limit/cursor, default 50, max 1000), logging/monitoring stubs, and multi-tenant enforcement helpers to require `clinicId` on every request.”

   ```5:20:apps/web/backend_requirements.md

   ```

## Auth

- Endpoints
  - POST `/api/auth/login`
    ...
- Notes: Full auth already implemented via Better-Auth + Convex at `packages/backend/convex/auth.ts` and `apps/web/src/routes/api/auth/$.ts`
  ````
  ```5:11:apps/web/backend_requirements.md
  ````

## Tenancy & Clinic Context

- Multi-tenant: every record is scoped by `clinicId`; no cross-clinic access.
  ...
- Errors: deny cross-clinic access with `403 { code: "FORBIDDEN" }` or `404` when appropriate to avoid enumeration.
  ````
  ```249:263:apps/web/backend_requirements.md
  ````

## Authentication Requirements

- Use `Authorization: Bearer <token>` for API calls; set via login
  ...
- Rate limiting: 100 requests per minute per IP (Stricter for auth endpoints: 10/m)

  ```

  ```

2. Auth & RBAC (serial)
   - Prompt: “Wire Better-Auth + Convex for login/reset/refresh; expose HTTP endpoints; set bearer and optional http-only cookie. Enforce roles admin/staff/viewer per clinic; tokens carry `clinicId`. Ensure password policy (>=8, number, special), session expiry/refresh, CORS, and cross-clinic isolation. Add audit events for login/reset.”

   ```195:214:apps/web/backend_requirements.md

   ```

## User Management

- GET `/api/users?role=&search=` → list users
  ...
- RBAC:
  - `admin`: Full access...

  ```

  ```

3. Data Model & Indexing (serial, short)
   - Prompt: “Define/adjust Convex schemas and indices for users, patients, appointments, chats/messages, billing wallet/transactions/payment methods, API keys, webhooks/events, uploads, audit logs. Add `clinicId` to every table; enforce uniqueness per clinic (phone/email, API key prefix, payment method). Ensure UUID v4 IDs (or Convex ids) and cursor pagination indices. Seed minimal fixtures for local dev.”

   ```264:274:apps/web/backend_requirements.md

   ```

## Data Validation Rules

- Email: RFC 5322 compliant, unique per clinic
  ...
- IDs: UUID v4 format (or Convex auto-generated)
  ````
  ```5:11:apps/web/backend_requirements.md
  ````

## Tenancy & Clinic Context

- Multi-tenant: every record is scoped by `clinicId`; no cross-clinic access.
  ...

  ```

  ```

4. Parallel Feature Tracks (begin after 1–3)

   4.1 Patients (parallel)
   - Prompt: “Implement Convex HTTP endpoints: list/search/filter (`search`, `status`, `limit`, `cursor`), create, update, delete, CSV import (multipart). Scope every query/mutation by `clinicId` from token; return 403/404 on cross-clinic access. Validate E.164 phone, min 2-char name, RFC5322 email; normalize phone to canonical; 409 on per-clinic duplicates; 404 on missing id. Return `{ items, page/total or cursor }`. Surface validation errors as 422 with fieldErrors. Add audit events for create/update/delete/import.”

   ```20:45:apps/web/backend_requirements.md

   ```

## Patients

- Endpoints
  - GET `/api/patients?search=&status=` → `{ items: Patient[], page: number, total: number }`
    ...
- Notes: Patient listing with search/filtering, bulk CSV import support needed

  ````

  4.2 Appointments (parallel) - Prompt: “Build list by date/patient/status (cursor/limit), get by id, create/update/cancel with ISO 8601 date/time stored UTC; enforce not in past; ensure patient exists within same `clinicId`; statuses confirmed/pending/cancelled/completed; support calendar/timeline queries. Add reminders-ready fields (notes, doctor, procedure). Scope all access by `clinicId` and emit audit events for CRUD.”
  ```70:93:apps/web/backend_requirements.md
  ````

## Appointments

- Endpoints
  - GET `/api/appointments?date=YYYY-MM-DD&patientId=&status=` → list
    ...
- Notes: Calendar views for month/week/day, timeline view, appointment status tracking

  ````

  4.3 WhatsApp Messaging & Connection Health (parallel) - Prompt: “Integrate Evolution API for chats list (status/search, unread counts), messages list (`limit`, `cursor`), send message (text + attachments ids), resolve chat. Scope chats/messages/status by `clinicId`. Implement webhook handler for inbound messages/status; verify signatures if available. Add `/api/whatsapp/status` and `/api/health/whatsapp` (poll) plus optional SSE/WebSocket for real-time connection. Apply 429 rate limiting and map upstream 502. Persist avatars/online, link to patientId when available. Add audit for message sent/resolved.”
  ```46:69:apps/web/backend_requirements.md
  ````

## WhatsApp Messaging

- Endpoints
  - GET `/api/whatsapp/chats` → chat list with unread counts
    ...
- Notes: Integration with Evolution API, requires webhook handler for incoming messages
  `
  `216:225:apps/web/backend_requirements.md

## WhatsApp Connection Health

- WebSocket/SSE endpoint for real-time connection status
  ...
- UI Alert: Show reconnect button when disconnected

  ````

  4.4 Billing & Wallet (parallel) - Prompt: “Expose wallet balance + transactions, top-up, payment methods CRUD (card), auto-recharge settings, transactions list (`limit`, `cursor`, `type`) — all scoped to `clinicId`. Integrate Asaas (ASAAS_API_KEY/URL); support idempotency for top-ups; map provider errors to standard error shape. Return new balance and transactionId on top-up. Enforce card validation. Emit audit logs for billing actions.”
  ```94:125:apps/web/backend_requirements.md
  ````

## Billing & Wallet

- Endpoints
  - GET `/api/billing/wallet` → `{ balance: number, currency: string, transactions: Transaction[] }`
    ...
- Errors: `402 PAYMENT_REQUIRED`, `409 CONFLICT`, `422 VALIDATION_ERROR`

  ````

  4.5 File Uploads (parallel) - Prompt: “Add multipart upload endpoint (`/api/uploads`) and delete, scoped by `clinicId`. Enforce 10MB/file, 100MB/clinic, store id/url/filename/size/mimeType. Integrate storage provider (Convex). Reuse for WhatsApp media, patient attachments, clinic logo. Return 413 on size limit, 415 on mime type if needed.”
  ```237:247:apps/web/backend_requirements.md
  ````

## File Uploads (Media)

- POST `/api/uploads` → upload files (images, documents)
  ...
- Limits: 10MB per file, 100MB per clinic

  ````

  4.6 Integrations (API Keys & Webhooks) (parallel) - Prompt: “API keys: list/create/revoke; keys start with `wm_`, min 32 chars, store prefix/createdAt/lastUsed, scoped by `clinicId`. Webhooks: get/update config, test sender, events log (`limit`, `cursor`); enforce HTTPS URL; HMAC-SHA256 signature verification helper; return latency/statusCode on test; scope to `clinicId`. Emit audit for key create/delete and webhook updates.”
  ```126:156:apps/web/backend_requirements.md
  ````

## Integrations

- API Keys Management
  - GET `/api/integrations/api-keys` → list keys
    ...
- Notes: Webhook endpoint URL format `https://api.whatsmed.com/v1/clinic/webhook/{webhookId}`

  ````

  4.7 Automation (parallel after messaging + appointments) - Prompt: “Persist automation settings per `clinicId`: reminders (sevenDay, twentyFourHour) with enabled/message/hoursBefore 1–72; AI agent config (enabled, model?, prompt?). Create scheduler hook to send WhatsApp reminders using templates with variables `{{patient_name}}`, `{{appointment_date}}`, `{{appointment_time}}`. Provide update endpoint. Guard with messaging availability.”
  ```158:169:apps/web/backend_requirements.md
  ````

## Automation Settings

- GET `/api/automation/settings` → get automation rules
  ...
- Trigger: Automated reminders sent via WhatsApp integration

  ````

  4.8 Settings & Preferences (parallel) - Prompt: “Implement clinic settings CRUD (name, address, phone, email, timezone, logoUrl) scoped by `clinicId` and user preferences (theme, locale, notifications) tied to user within clinic. Validate timezone (IANA), locale (ISO 639-1), email/phone per global rules. Support logo upload via uploads service.”
  ```170:182:apps/web/backend_requirements.md
  ````

## Clinic Settings

- GET `/api/settings/clinic` → get clinic profile
  ...
- Validation: Timezone must be IANA timezone format, locale ISO 639-1

  ````

  4.9 Analytics & Dashboard (parallel after data exists) - Prompt: “Provide appointment analytics endpoints: totals, status breakdown, funnel; and efficiency metrics (confirmationRate, cancellationRate, manualIntervention, trends) scoped to `clinicId`. Respect dateFrom/dateTo; cache for ~5 minutes; invalidate on appointment changes. Ensure outputs match dashboard expectations.”
  ```226:236:apps/web/backend_requirements.md
  ````

## Dashboard Analytics

- GET `/api/analytics/appointments?dateFrom=&dateTo=` → appointment metrics
  ...
- Caching: Cache for 5 minutes, invalidate on appointment changes

  ````

  4.10 Audit Logging (parallel; wire as features ship) - Prompt: “Create audit log store with cursor pagination and filters (userId, action, dateFrom/To), scoped by `clinicId`. Record actions: LOGIN, CREATE/UPDATE/DELETE_PATIENT, CREATE/UPDATE/DELETE_APPOINTMENT, EXPORT_PATIENTS, UPDATE_CLINIC_SETTINGS, CREATE/DELETE_API_KEY, billing actions, webhook tests, messaging sends/resolves. Add Convex cron to delete >90 days. Include metadata and IP.”
  ```183:194:apps/web/backend_requirements.md
  ````

## Audit Logs

- GET `/api/audit/logs?limit=&cursor=&userId=&action=` → query logs
  ...
- Notes: Expandable rows for metadata, IP geolocation optional
  ```

  ```

5. Hardening, Monitoring, QA (serial wrap-up)
   - Prompt: “Apply rate limits per endpoint category, ensure standard error shape, CORS, and HMAC verification for webhooks. Add Idempotency-Key support for payments and webhook tests. Enforce cross-clinic isolation (all responses scoped to `clinicId`). Instrument latency/error metrics. Write Vitest API tests with Convex mocks covering auth, patients, appointments, messaging, billing, uploads, integrations, automation, analytics. Run smoke tests for end-to-end flows.”

   ```257:302:apps/web/backend_requirements.md

   ```

## Error Handling Specifications

- Standard error body: `{ code: string, message: string, details?: any, requestId?: string }`
  ...
- Monitor WhatsApp connection status and webhook delivery success rate

  ```

  ```
