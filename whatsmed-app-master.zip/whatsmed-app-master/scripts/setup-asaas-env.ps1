# Script para configurar variáveis de ambiente do Asaas no Convex
# Uso: .\scripts\setup-asaas-env.ps1

Write-Host "Configurando variáveis de ambiente do Asaas no Convex..." -ForegroundColor Cyan
Write-Host ""

# ASAAS_API_KEY
$apiKey = Read-Host "Digite sua ASAAS_API_KEY (ex: `$aact_YTU5...)"
npx convex env set ASAAS_API_KEY $apiKey

# ASAAS_ENVIRONMENT
$environment = Read-Host "Digite o ambiente (sandbox ou production) [sandbox]"
if ([string]::IsNullOrWhiteSpace($environment)) {
    $environment = "sandbox"
}
npx convex env set ASAAS_ENVIRONMENT $environment

# ASAAS_WEBHOOK_SECRET
$webhookSecret = Read-Host "Digite o ASAAS_WEBHOOK_SECRET (mesmo token configurado no webhook do Asaas)"
npx convex env set ASAAS_WEBHOOK_SECRET $webhookSecret

Write-Host ""
Write-Host "✅ Variáveis de ambiente configuradas com sucesso!" -ForegroundColor Green
Write-Host ""
Write-Host "Variáveis configuradas:"
Write-Host "  - ASAAS_API_KEY: $($apiKey.Substring(0, [Math]::Min(20, $apiKey.Length)))..."
Write-Host "  - ASAAS_ENVIRONMENT: $environment"
Write-Host "  - ASAAS_WEBHOOK_SECRET: $($webhookSecret.Substring(0, [Math]::Min(10, $webhookSecret.Length)))..."

