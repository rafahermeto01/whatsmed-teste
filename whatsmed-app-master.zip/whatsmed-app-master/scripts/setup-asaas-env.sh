#!/bin/bash

# Script para configurar variáveis de ambiente do Asaas no Convex
# Uso: ./scripts/setup-asaas-env.sh

echo "Configurando variáveis de ambiente do Asaas no Convex..."
echo ""

# ASAAS_API_KEY
read -p "Digite sua ASAAS_API_KEY (ex: \$aact_YTU5...): " api_key
npx convex env set ASAAS_API_KEY "$api_key"

# ASAAS_ENVIRONMENT
read -p "Digite o ambiente (sandbox ou production) [sandbox]: " environment
environment=${environment:-sandbox}
npx convex env set ASAAS_ENVIRONMENT "$environment"

# ASAAS_WEBHOOK_SECRET
read -p "Digite o ASAAS_WEBHOOK_SECRET (mesmo token configurado no webhook do Asaas): " webhook_secret
npx convex env set ASAAS_WEBHOOK_SECRET "$webhook_secret"

echo ""
echo "✅ Variáveis de ambiente configuradas com sucesso!"
echo ""
echo "Variáveis configuradas:"
echo "  - ASAAS_API_KEY: ${api_key:0:20}..."
echo "  - ASAAS_ENVIRONMENT: $environment"
echo "  - ASAAS_WEBHOOK_SECRET: ${webhook_secret:0:10}..."

