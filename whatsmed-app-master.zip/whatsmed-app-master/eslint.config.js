import js from "@eslint/js";
import tseslint from "@typescript-eslint/eslint-plugin";
import tsparser from "@typescript-eslint/parser";
import react from "eslint-plugin-react";
import reactHooks from "eslint-plugin-react-hooks";
import a11y from "eslint-plugin-jsx-a11y";
import importPlugin from "eslint-plugin-import";
import globals from "globals";

export default [
  {
    ignores: [
      "node_modules",
      "dist",
      "build",
      ".turbo",
      ".vercel",
      "apps/web/.nitro",
      "apps/web/dist",
      "apps/web/.vercel",
      "apps/web/.vercel/**",
      "apps/web/e2e/**",
      "apps/web/playwright.config.ts",
      "apps/web/vitest.config.ts",
      "e2e/**",
      "playwright.config.ts",
      "vitest.config.ts",
      "convex/_generated",
      "packages/backend/convex/_generated",
      "worktrees/*/packages/backend/convex/_generated",
      "**/_generated/**",
      "packages/backend/tests",
      "packages/backend/vitest.config.ts",
      "eslint.config.js",
      "**/.vercel/**",
    ],
  },
  js.configs.recommended,
  {
    files: ["**/*.{ts,tsx,js,jsx}", "apps/**", "packages/**"],
    languageOptions: {
      parser: tsparser,
      ecmaVersion: "latest",
      sourceType: "module",
      globals: {
        ...globals.browser,
        ...globals.node,
        React: "readonly",
      },
      parserOptions: {
        ecmaFeatures: { jsx: true },
        projectService: {
          allowDefaultProject: ["packages/backend/*.js"],
        },
      },
    },
    plugins: {
      "@typescript-eslint": tseslint,
      react,
      "react-hooks": reactHooks,
      "jsx-a11y": a11y,
      import: importPlugin,
    },
    settings: {
      react: { version: "detect" },
      "import/resolver": {
        typescript: {
          alwaysTryTypes: true,
          project: [
            "apps/web/tsconfig.json",
            "packages/backend/convex/tsconfig.json",
            "packages/config/tsconfig.base.json",
            "worktrees/*/apps/web/tsconfig.json",
            "worktrees/*/packages/backend/convex/tsconfig.json",
          ],
        },
      },
    },
    rules: {
      "no-console": ["warn", { allow: ["warn", "error"] }],
      "no-unused-vars": "off",
      "react/react-in-jsx-scope": "off",
      "react/prop-types": "off",
      "@typescript-eslint/no-unused-vars": [
        "warn",
        { argsIgnorePattern: "^_", varsIgnorePattern: "^_" },
      ],
      "import/order": [
        "warn",
        {
          groups: [["builtin", "external"], ["internal", "parent", "sibling", "index"], ["type"]],
          "newlines-between": "always",
          alphabetize: { order: "asc", caseInsensitive: true },
        },
      ],
    },
  },
  {
    files: ["packages/backend/convex/**/*.ts", "packages/backend/mastra/**/*.ts"],
    rules: {
      "no-console": "off",
      "@typescript-eslint/no-unused-vars": "off",
      "import/order": "off",
    },
  },
];
